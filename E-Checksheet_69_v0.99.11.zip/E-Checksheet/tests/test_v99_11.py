"""v0.99.11 เอกสารรายงานรายเดือน · รายการผิดปกติและการแก้ไข
- NG / ช่วงเตือนที่ลบออกจากรายการแจ้งเตือนแล้ว (พร้อมเหตุผล) → ไม่อยู่ในรายการผิดปกติ และไม่นับในสรุป
- ช่วงเครื่องสำรอง / ไม่ได้เดิน → ไม่ใช่ความผิดปกติ (ซ่อม / PM ยังแสดง)"""
import json
from datetime import date, datetime, timedelta

from conftest import GOOD, uid
from test_submissions import submit

from ecs import anomaly as A
from ecs import sheet_report as SR

NG = dict(GOOD, oil={"value": "2.45", "remark": "สูง"})     # Oil Pressure ช่วงเตือน (2.4–2.5) — ไม่ต้องแนบรูป
F = "%Y-%m-%d %H:%M:%S"


def _sheet(db, form):
    return SR.build_month_sheet(db, form["form_id"], date.today().replace(day=1), "s")


def _ng_rows(sheet):
    return [n for n in sheet["ng_list"] if n["judgement"] in ("ng", "warn")]


def test_deleted_ng_alert_is_not_in_report(app, db, published_form):
    res, _ = submit(app, db, published_form, NG)
    sh = _sheet(db, published_form)
    assert [n["item"] for n in _ng_rows(sh)] == ["Oil Pressure"] and sh["summary"]["warn"] == 1
    code0 = sh.get("doc_no"), json.dumps(sh.get("verify") or "", default=str)
    al = db.execute("SELECT id FROM cs_alerts WHERE alert_type='warn' AND submission_id=?", (res["id"],)).fetchone()
    assert al, "ต้องมีแจ้งเตือน NG"
    assert A.delete_alerts(db, [al["id"]], uid(db, "t_admin"), "ค่ามิเตอร์อ่านผิด ตรวจซ้ำแล้วปกติ", any_type=True) == 1
    db.commit()
    sh = _sheet(db, published_form)
    assert _ng_rows(sh) == [] and sh["summary"]["warn"] == 0
    # ค่าที่บันทึกยังอยู่ครบ (เอกสารยังแสดงค่าในตาราง)
    assert db.execute("SELECT judgement FROM cs_answers WHERE submission_id=? AND item_key='oil'", (res["id"],)).fetchone()[0] == "warn"
    assert code0 is not None


def test_repeat_occurrences_in_same_alert_are_all_dismissed_but_later_ng_shows(app, db, published_form):
    submit(app, db, published_form, NG)
    submit(app, db, published_form, dict(NG, hour={"value": "1010"}))
    al = db.execute("SELECT id, occurrences FROM cs_alerts WHERE alert_type='warn'").fetchone()
    assert al["occurrences"] == 2
    A.delete_alerts(db, [al["id"]], uid(db, "t_admin"), "เซนเซอร์เสีย", any_type=True)
    db.commit()
    assert _ng_rows(_sheet(db, published_form)) == []
    submit(app, db, published_form, dict(NG, hour={"value": "1020"}))       # NG ใหม่หลังลบ → ต้องแสดง
    assert len(_ng_rows(_sheet(db, published_form))) == 1


def test_alerts_deleted_before_upgrade_are_backfilled_from_audit(app, db, published_form):
    res, _ = submit(app, db, published_form, NG)
    al = dict(db.execute("SELECT * FROM cs_alerts WHERE alert_type='warn'").fetchone())
    # เวอร์ชันเก่า: ลบแจ้งเตือน = บันทึก Audit + ลบแถว (ไม่มีตาราง dismiss)
    db.execute("""INSERT INTO cs_audit(actor_id, action, entity, entity_id, before_json, after_json, created_at)
                  VALUES (?, 'delete', 'cs_alerts', ?, ?, ?, ?)""",
               (uid(db, "t_admin"), al["id"], json.dumps(al), json.dumps({"reason": "ค่าผิด"}), datetime.now().strftime(F)))
    db.execute("DELETE FROM cs_alert_events WHERE alert_id=?", (al["id"],))
    db.execute("DELETE FROM cs_alerts WHERE id=?", (al["id"],))
    db.execute("DELETE FROM cs_meta WHERE key='ng_dismiss_backfill'")
    db.commit()
    assert _ng_rows(_sheet(db, published_form)) == []
    assert db.execute("SELECT reason FROM cs_ng_dismiss WHERE submission_id=?", (res["id"],)).fetchone()[0] == "ค่าผิด"


def test_closed_alert_still_listed(app, db, published_form):
    """ปิดแจ้งเตือน (แก้ไขปัญหาแล้ว) ≠ ลบ → ยังเป็นรายการผิดปกติที่มีการแก้ไข"""
    submit(app, db, published_form, NG)
    db.execute("UPDATE cs_alerts SET status='closed' WHERE alert_type='warn'")
    db.commit()
    assert len(_ng_rows(_sheet(db, published_form))) == 1


def test_standby_downtime_not_abnormal_but_repair_is(app, db, published_form):
    eq = published_form["equipment_id"]
    now = datetime.now()
    base = now.replace(day=1, hour=8, minute=0, second=0, microsecond=0)
    if now - base < timedelta(hours=10):
        base = now - timedelta(hours=10)
    for cat, st, en, why in (("standby", base, base + timedelta(hours=3), "สำรอง"),
                             ("repair", base + timedelta(hours=4), base + timedelta(hours=6), "ลูกปืนเสีย")):
        db.execute("INSERT INTO cs_downtime(equipment_id, start_at, end_at, reason, category) VALUES (?,?,?,?,?)",
                   (eq, st.strftime(F), en.strftime(F), why, cat))
    db.commit()
    sh = _sheet(db, published_form)
    downs = [n for n in sh["ng_list"] if n["judgement"] == "down"]
    assert len(downs) == 1 and "ซ่อม" in downs[0]["item"] and "ลูกปืนเสีย" in downs[0]["remark"]
    assert len(sh["grid"]["downtime"]) == 2                 # ตารางยังแสดงช่วงสำรอง (เทาในช่องวัน) ครบ
