"""v0.54: ใบบันทึกรายเดือน — แรเงาช่องรอบที่เครื่องหยุด/PM (รายรอบ กะเช้า/กะดึก) + รายการผิดปกติ: หยุดตั้งแต่…ถึง… โดยใคร"""
from datetime import date, datetime, timedelta

from conftest import login, uid

from ecs import downtime as DT
from ecs import services as S
from ecs import sheet_report as SR


def _setup(db, fid):
    S.create_schedule(db, fid, {"freq_type": "shift", "times": "08:30,20:30", "window_min": 240}, uid(db, "t_admin"))
    db.commit()


def test_downtime_shading_and_issue(app, client, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    _setup(db, fid)
    now = S.now_dt()
    d0 = (now - timedelta(days=2)).date()
    if d0.month != now.month:                                   # ต้นเดือน: ใช้เดือนก่อน
        pass
    start = datetime.combine(d0, datetime.min.time()) + timedelta(hours=22, minutes=9)    # หยุดกะดึก 22:09
    # v0.99.11 สำรอง/ไม่ได้เดิน ไม่อยู่ในรายการผิดปกติแล้ว → ทดสอบแถวรายการผิดปกติด้วยการหยุดซ่อม
    DT.set_down(db, eq, uid(db, "t_tech"), "มอเตอร์ร้อน", "repair", start_at=start)
    db.commit()
    DT.set_running(db, eq, uid(db, "t_tech2"), now=start + timedelta(hours=10, minutes=50))   # เดินเครื่องกะเช้า 08:59
    db.commit()
    month = d0.replace(day=1)
    sh = SR.build_month_sheet(db, fid, month, "k")
    lines = next(r for r in sh["rows"] if r["kind"] == "slots")["lines"]
    night = next(ln for ln in lines if ln["label"] == "20:30")
    morning = next(ln for ln in lines if ln["label"] == "08:30")
    assert night["down"][d0.day - 1] is True                  # รอบ 20:30 ของวันหยุด (หยุด 22:09 ยังอยู่ในช่วงรอบ)
    nd = start + timedelta(days=1)
    if nd.month == d0.month:
        assert morning["down"][nd.day - 1] is False   # v0.55 เดินเครื่อง 08:59 ก่อนครบกำหนด 12:30 → ยังต้องตรวจ
    assert morning["down"][d0.day - 1] is False                 # รอบเช้าวันเริ่ม = ยังเดินอยู่
    iss = sh["ng_list"][0]
    assert iss["judgement"] == "down" and "กดหยุดโดย ทดสอบ t_tech" in iss["remark"] and "กดเดินเครื่องโดย ทดสอบ t_tech2" in iss["remark"]
    assert "(กะดึก)" in iss["remark"] and "(กะเช้า)" in iss["remark"]
    login(client, "t_admin")
    html = client.get(f"/reports/sheets?form={fid}&month={month:%Y-%m}").get_data(as_text=True)
    assert "เครื่องหยุด /" in html and "กดหยุดโดย" in html and 'class="dn">หยุด' in html
    x = client.get(f"/reports/sheets?form={fid}&month={month:%Y-%m}&format=xlsx")
    assert x.status_code == 200


def test_backfill_and_ack_fill_empty_cells(app, client, db, published_form):
    from conftest import GOOD, payload

    from ecs import shiftsign as SSG
    from ecs import submissions as SUB
    fid = published_form["form_id"]
    sid = S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00", "window_min": 240}, uid(db, "t_admin"))
    db.commit()
    now = S.now_dt()
    d0 = (now - timedelta(days=3)).date()
    if d0.month != now.month:
        d0 = now.date().replace(day=1) if now.day > 1 else d0
    due = datetime.combine(d0, datetime.min.time()) + timedelta(hours=8)
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    rid = db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                        VALUES (?,?,?,?,?,'missed',?)""", (sid, fid, S.ts(due), S.ts(due + timedelta(hours=4)),
                                                            S.ts(due + timedelta(hours=8)), S.ts(due))).lastrowid
    db.commit()
    month = d0.replace(day=1)
    miss = SSG.missing(db, fid, month)
    row = next(r for r in miss if r["day"] == d0)
    assert row["rounds"] and row["rounds"][0]["id"] == rid
    # กรอกย้อนหลังรอบที่ขาด → ค่าลงช่องวันของรอบ (ไม่ใช่วันนี้) + ช่องผู้ตรวจของวันนั้นมีชื่อ
    if (now - due) > timedelta(hours=12):
        from ecs import backfill as BF                     # v0.55 ต้องได้สิทธิ์รายวันก่อน
        BF.grant(db, [uid(db, "t_tech")], [due.date().isoformat()], 0, "", uid(db, "t_admin"))
        res = SUB.create_submission(db, payload(published_form, GOOD, round_id=rid), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
        db.commit()
        assert res["round_status"] == "done_late"
        sh = SR.build_month_sheet(db, fid, month, "k")
        line = next(r for r in sh["rows"] if r["it"]["item_key"] == "oil")["lines"][0]
        assert line["cells"][d0.day - 1] is not None
        assert not any(r["day"] == d0 for r in SSG.missing(db, fid, month))
    # ลงนามรับทราบวันอื่นที่ว่าง
    other = next((r for r in SSG.missing(db, fid, month) if r["day"] != d0), None)
    tok = login(client, "t_tech2")
    page = client.get(f"/reports/sheets/sign?form={fid}&month={month:%Y-%m}").get_data(as_text=True)
    assert "ลงนามรับทราบ" in page
    if other:
        r = client.post("/reports/sheets/sign", data={"csrf_token": tok, "form": fid, "month": f"{month:%Y-%m}",
                                                      "cell": f"{other['day'].isoformat()}|{other['shift']}", "note": "รับทราบ"})
        assert r.status_code == 302
        sh = SR.build_month_sheet(db, fid, month, "k")
        c = sh["days"][other["day"].day - 1]
        assert any(n == "ทดสอบ" or "t_tech2" in n for _u, n in c["insp"]) or c["insp"]
        aid = db.execute("SELECT id FROM cs_sheet_acks").fetchone()[0]
        client.post("/reports/sheets/sign", data={"csrf_token": tok, "form": fid, "month": f"{month:%Y-%m}", "undo": aid})
        assert db.execute("SELECT COUNT(*) FROM cs_sheet_acks").fetchone()[0] == 0
    import pytest
    with pytest.raises(S.ValidationError):
        SSG.sign(db, fid, now.date() + timedelta(days=1), "all", uid(db, "t_tech"))


def test_v55_shading_only_while_down_at_deadline(app, db, published_form):
    """หยุด 21:00 → เดินเครื่อง 08:41 วันถัดไป: แรเงาเฉพาะรอบ 20:30 คืนนั้น · รอบ 20:30 คืนถัดไปไม่แรเงา · รอบที่มีผลตรวจไม่แรเงา"""
    from conftest import GOOD, payload

    from ecs import submissions as SUB
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    _setup(db, fid)
    now = S.now_dt()
    d0 = (now - timedelta(days=3)).date()
    start = datetime.combine(d0, datetime.min.time()) + timedelta(hours=21)
    end = start + timedelta(hours=11, minutes=41)
    db.execute("""INSERT INTO cs_downtime(equipment_id, start_at, end_at, reason, category, started_by, ended_by, skipped_rounds)
                  VALUES (?,?,?,?,?,?,?,0)""", (eq, S.ts(start), S.ts(end), "หยุดตามแผน", "standby", uid(db, "t_tech"), uid(db, "t_tech2")))
    sid = db.execute("SELECT id FROM cs_schedules WHERE form_id=?", (fid,)).fetchone()[0]
    d1 = d0 + timedelta(days=1)
    stale = datetime.combine(d1, datetime.min.time()) + timedelta(hours=20, minutes=30)     # งดผิด (สร้างตอนเครื่องหยุด)
    db.execute("""INSERT OR REPLACE INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                  VALUES (?,?,?,?,?,'skipped',?)""", (sid, fid, S.ts(stale), S.ts(stale + timedelta(hours=4)),
                                                      S.ts(stale + timedelta(hours=12)), S.ts(stale)))
    db.commit()
    # ตรวจรอบ 08:30 วันถัดไป (ก่อนเดินเครื่อง 08:41)
    p = payload(published_form, GOOD, finished_at=S.ts(datetime.combine(d1, datetime.min.time()) + timedelta(hours=8, minutes=35)),
                scanned_at=S.ts(datetime.combine(d1, datetime.min.time()) + timedelta(hours=8, minutes=30)))
    SUB.create_submission(db, p, {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"], now=now)
    db.commit()
    sh = SR.build_month_sheet(db, fid, d0.replace(day=1), "k") if d1.month == d0.month else None
    if sh:
        lines = next(r for r in sh["rows"] if r["kind"] == "slots")["lines"]
        n20 = next(ln for ln in lines if ln["label"] == "20:30")
        m08 = next(ln for ln in lines if ln["label"] == "08:30")
        assert n20["down"][d0.day - 1] is True
        assert n20["down"][d1.day - 1] is False                     # คืนถัดไป เครื่องเดินแล้ว
        assert m08["down"][d1.day - 1] is False                     # มีผลตรวจ → ไม่แรเงา
    n = DT.fix_stale_skipped(db, now)
    db.commit()
    assert n >= 1 and db.execute("SELECT status FROM cs_rounds WHERE due_at=? AND form_id=?", (S.ts(stale), fid)).fetchone()[0] == "missed"
