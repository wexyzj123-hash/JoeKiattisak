/* หน้ากรอกผลตรวจ (มือถือ/แท็บเล็ต)
   - ข้อมูลที่กรอกบันทึกลงเครื่องทุกครั้งที่แตะ → ปิดแอป/รีเฟรช/แบตหมด ก็ไม่หาย
   - ตัดสินผล ปกติ/เตือน/NG ทันทีตามเกณฑ์ (ฝั่งเซิร์ฟเวอร์ตรวจซ้ำอีกครั้ง)
   - NG บังคับหมายเหตุ + รูป · ส่งไม่ได้ถ้าหัวข้อบังคับยังไม่ครบ
   - กดส่งตอนไม่มีสัญญาณ → เข้าคิว ส่งเองเมื่อสัญญาณกลับมา */
(function () {
  'use strict';
  const { esc, fmt, fmtDate } = ECS;
  const app = document.getElementById('app');
  const camera = document.getElementById('camera');
  const gallery = document.getElementById('gallery');
  let P = Object.fromEntries(new URLSearchParams(location.hash.slice(1)));
  let OFFMODE = false; try { OFFMODE = sessionStorage.getItem('m_offmode') === '1'; } catch (e) { /* */ }
  let pkg = null, draft = null, draftKey = null, photoTarget = null, saveTimer = null;
  let sending = false;   // v0.99.10 กำลังส่ง (รอคำตอบจากเซิร์ฟเวอร์)
  let thumbs = {};   // photoId -> objectURL

  const J = { ok: ['ปกติ', 'b-ok'], warn: ['เตือน', 'b-warn'], ng: ['NG', 'b-ng'], na: ['', ''] };

  // ── ความถี่รายหัวข้อ (ต้องตรงกับ ecs/itemfreq.py) ──
  const FREQ_TH = { shift: 'กะละ 1 ครั้ง', day: 'วันละ 1 ครั้ง', week: 'สัปดาห์ละ 1 ครั้ง', month: 'เดือนละ 1 ครั้ง' };
  function parseTimes(t) {
    const out = String(t || '').split(/[,\s;/]+/).map(p => {
      const m = /^([01]?\d|2[0-3])[:.]([0-5]\d)$/.exec(p); return m ? Number(m[1]) * 60 + Number(m[2]) : null;
    }).filter(x => x != null);
    return [...new Set(out)].sort((a, b) => a - b);
  }
  function hhmm(m) { return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); }
  function freqLabel(it) {
    if (!it.check_freq) return '';
    if (it.check_freq === 'times') { const t = parseTimes(it.check_times); return t.length + ' ครั้ง/วัน: ' + t.map(hhmm).join(', '); }
    const fq = (pkg.calendar && pkg.calendar.freqs) || {};
    return fq[it.check_freq] || FREQ_TH[it.check_freq] || ivLabel(it.check_freq);
  }
  // v0.32 ความถี่แบบช่วง d:N / w:N / m:N (ต้องตรงกับ itemfreq.interval)
  function ivOf(f) { const m = /^([dwm]):(\d{1,3})$/.exec(f || ''); return m && Number(m[2]) >= 1 ? { u: m[1], n: Number(m[2]) } : null; }
  function ivLabel(f) { const v = ivOf(f); if (!v) return ''; const u = { d: 'วัน', w: 'สัปดาห์', m: 'เดือน' }[v.u];
    return v.n === 1 ? u + 'ละ 1 ครั้ง' : 'ทุก ' + v.n + ' ' + u; }
  function slotMins(it) {
    const c = pkg.calendar || {};
    const m = it.check_freq === 'shift' ? parseTimes(c.shift_times || '08:00,20:00')
      : it.check_freq === 'times' ? parseTimes(it.check_times) : parseTimes(c.day_start || '08:00');
    return m.length ? m : [480];
  }
  function graceMin(it) {
    if (it.check_freq === 'shift' || it.check_freq === 'times') {
      const m = slotMins(it);
      if (m.length > 1) {
        const gaps = m.slice(1).map((x, i) => x - m[i]).concat(m[0] + 1440 - m[m.length - 1]);
        return Math.min(30, Math.min(...gaps) / 4);
      }
    }
    return 30;
  }
  function at(base, days, mins) { const d = new Date(base); d.setDate(d.getDate() + days); d.setMinutes(d.getMinutes() + mins); return d; }
  function midnight(d) { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; }
  function slotStart(it, ref) {
    const f = it.check_freq, mins = slotMins(it), base = midnight(ref);
    if (f === 'shift' || f === 'times' || f === 'day') {
      const c = []; [0, -1].forEach(d => mins.forEach(m => c.push(at(base, d, m))));
      return new Date(Math.max(...c.filter(x => x <= ref)));
    }
    const iv = ivOf(f);
    if (iv) {
      if (iv.u === 'm') {
        let first = new Date(base); first.setDate(1); first = at(first, 0, mins[0]);
        if (first > ref) { const p = new Date(first); p.setDate(1); p.setMonth(p.getMonth() - 1); first = p; }
        let k = (first.getFullYear() - 2024) * 12 + first.getMonth(); k -= k % iv.n;
        return new Date(2024 + Math.floor(k / 12), k % 12, 1, Math.floor(mins[0] / 60), mins[0] % 60);
      }
      const step = iv.n * (iv.u === 'w' ? 7 : 1), s0 = new Date(2024, 0, 1, Math.floor(mins[0] / 60), mins[0] % 60);
      const k = Math.floor((ref - s0) / (step * 86400000));
      return at(s0, k * step, 0);
    }
    if (f === 'week') { const s = at(base, -((ref.getDay() + 6) % 7), mins[0]); return s <= ref ? s : at(s, -7, 0); }
    if (f === 'month') {
      const first = new Date(base); first.setDate(1);
      const s = at(first, 0, mins[0]); if (s <= ref) return s;
      const prev = new Date(first); prev.setMonth(prev.getMonth() - 1); return at(prev, 0, mins[0]);
    }
    return null;
  }
  function nextSlot(it, ref) {
    const cur = slotStart(it, ref); if (!cur) return null;
    const f = it.check_freq;
    if (f === 'week') return at(cur, 7, 0);
    const iv = ivOf(f);
    if (iv) { if (iv.u !== 'm') return at(cur, iv.n * (iv.u === 'w' ? 7 : 1), 0); const n = new Date(cur); n.setMonth(n.getMonth() + iv.n); return n; }
    if (f === 'month') { const n = new Date(cur); n.setMonth(n.getMonth() + 1); return n; }
    const base = midnight(cur), c = [];
    [0, 1].forEach(d => slotMins(it).forEach(m => c.push(at(base, d, m))));
    return c.filter(x => x > cur).sort((a, b) => a - b)[0];
  }
  function lastDone(it) { const p = pkg.previous[it.item_key]; return p && p.at ? ECS.parseTs(p.at) : null; }
  function isDue(it, ref) {
    if (!it.check_freq) return true;
    const g = graceMin(it) * 60000, start = slotStart(it, new Date(ref.getTime() + g)), last = lastDone(it);
    return !last || last < new Date(start.getTime() - g);
  }
  function hasInput(a) { return !!(a && (String(a.value || '').trim() || (a.photos || []).length || String(a.remark || '').trim())); }
  // คำนวณว่าหัวข้อไหนต้องตรวจในครั้งนี้ (เวลาอ้างอิง = ตอนนี้ หรือเวลาเริ่มรอบ ถ้ารอบยังไม่ถึงเวลา)
  function computeVisible() {
    const now = new Date(), rd = draft.round && draft.round.due_at ? ECS.parseTs(draft.round.due_at) : null;
    const ref = rd && rd > now ? rd : now;
    const extra = new Set(draft.extra || []);
    pkg.items.forEach(it => {
      it._due = isDue(it, ref);
      it._show = it._due || hasInput(draft.answers[it.item_key]) || extra.has(it.item_key);
      it._next = it.check_freq && !it._due ? nextSlot(it, ref) : null;
    });
  }
  const visible = () => pkg.items.filter(it => it._show);

  // ── ยืนยันจุดตรวจด้วย QR (แบบฟอร์มที่ตั้ง "ต้องสแกน QR ที่จุดตรวจ") ──
  // v0.82 ลงข้อมูลย้อนหลัง (รอบที่ตัดรอบไปแล้ว) ไม่ต้องสแกน QR ที่จุดตรวจ
  const isBackfill = () => { const r = pkg.round; if (!r || !r.close_at || r.status === 'returned') return false;
    return new Date(String(r.close_at).replace(' ', 'T')).getTime() <= Date.now(); };
  const needScan = () => !!(pkg.form && pkg.form.require_point_scan) && !isBackfill();
  const normCode = c => { c = String(c || '').trim(); if (c.includes('/p/')) c = c.replace(/\/+$/, '').split('/').pop(); return c.toUpperCase().replace(/[\s-]/g, '').slice(0, 12); };
  function scanned(sec) { return !needScan() || !!(draft.scans && draft.scans[sec || '']); }
  function locked(it) { return !scanned(it.section || ''); }
  // คืนชื่อจุดที่รหัสนี้ใช้ได้ (null = ไม่ตรงจุดใดของแบบฟอร์มนี้)
  function matchPoint(code, onlySec) {
    const h = window.ECS_SHA256(normCode(code));
    const s = sections().find(x => x.code_sha === h && (onlySec == null || x.name === onlySec));
    return s ? s.name : null;
  }
  async function confirmPoint(sec, code) {
    draft.scans = draft.scans || {};
    draft.scans[sec] = { code: normCode(code), at: ECS.nowTs() };
    await saveNow();
  }

  function num(v) { if (v === '' || v == null) return null; const n = Number(String(v).replace(/,/g, '')); return Number.isFinite(n) ? n : NaN; }
  function g(n) { return Number.isInteger(n) ? String(n) : String(+n.toFixed(6)); }

  // ── ตัดสินผล (ตรงกับ services.evaluate ฝั่งเซิร์ฟเวอร์) ──
  function evaluate(it, raw) {
    const v = raw == null ? '' : String(raw).trim();
    if (v === '') return { j: 'na', msg: '' };
    if (it.item_type === 'ok_ng') return v === 'NG' ? { j: 'ng', msg: 'ผลตรวจ NG' } : { j: 'ok', msg: '' };
    if (it.item_type === 'number' || it.item_type === 'counter' || it.item_type === 'calc') {
      const x = num(v); if (Number.isNaN(x)) return { j: 'invalid', msg: 'ต้องเป็นตัวเลข' };
      const u = it.unit ? ' ' + it.unit : '';
      if (it.min_value != null && x < it.min_value) return { j: 'ng', msg: `ต่ำกว่าเกณฑ์ ${g(it.min_value)}${u}` };
      if (it.max_value != null && x > it.max_value) return { j: 'ng', msg: `สูงกว่าเกณฑ์ ${g(it.max_value)}${u}` };
      if (it.item_type === 'counter') {
        const prev = (pkg.previous[it.item_key] || {}).value_num;
        if (prev != null && x < prev) return { j: 'ng', msg: `น้อยกว่าครั้งก่อน (${g(prev)}) ตรวจสอบมิเตอร์` };
        if (prev != null && it.counter_max_step != null && x - prev > it.counter_max_step)
          return { j: 'warn', msg: `เพิ่มขึ้น ${g(x - prev)} มากกว่าปกติ` };
      }
      if (it.warn_low != null && x < it.warn_low) return { j: 'warn', msg: `ใกล้ขีดต่ำ (เตือนที่ ${g(it.warn_low)})` };
      if (it.warn_high != null && x > it.warn_high) return { j: 'warn', msg: `ใกล้ขีดสูง (เตือนที่ ${g(it.warn_high)})` };
      return { j: 'ok', msg: '' };
    }
    if (it.item_type === 'choice') {
      const o = (it.options || []).find(o => o.label === v);
      return o && o.ng ? { j: 'ng', msg: `เลือก "${v}"` } : { j: 'ok', msg: '' };
    }
    return { j: 'ok', msg: '' };
  }

  // ── กราฟแนวโน้ม 5 ครั้งล่าสุด (เล็ก ๆ ข้างช่องกรอก) ──
  // จุดทึบ = ค่าที่ส่งไปแล้ว (สีตามผล) · วงกลมกลวง = ค่าที่กำลังกรอก · เส้นประแดง/เหลือง = เกณฑ์/ขีดเตือน (แสดงเมื่ออยู่ใกล้ค่า)
  function histOf(it) { return it.item_type === 'number' ? ((pkg.history || {})[it.item_key] || []) : []; }
  function sparkPoints(it, raw) {
    const pts = histOf(it).map(h => ({ v: Number(h.v), j: h.j || 'ok' }));
    const x = num(raw);
    if (x != null && !Number.isNaN(x)) pts.push({ v: x, j: evaluate(it, raw).j, cur: true });
    return pts;
  }
  function sparkSvg(it, raw) {
    const pts = sparkPoints(it, raw);
    if (!pts.length) return '';
    const W = 88, H = 40, P = 5;
    const vals = pts.map(p => p.v);
    let lo = Math.min(...vals), hi = Math.max(...vals);
    const span0 = Math.max(hi - lo, Math.abs(hi) * 0.02, 1e-6);
    const lims = [['lim', it.min_value], ['lim', it.max_value], ['wlim', it.warn_low], ['wlim', it.warn_high]]
      .filter(l => l[1] != null && l[1] >= lo - span0 && l[1] <= hi + span0);   // วาดเฉพาะเกณฑ์ที่อยู่ใกล้ค่า
    lims.forEach(l => { lo = Math.min(lo, l[1]); hi = Math.max(hi, l[1]); });
    // สเกลขั้นต่ำ = 25% ของช่วงเกณฑ์ — ค่าที่แกว่งนิดหน่อยจะดูเรียบ ไม่ตกใจเกินจริง
    const floor = it.min_value != null && it.max_value != null ? (it.max_value - it.min_value) * 0.25 : 0;
    const need = Math.max(floor, span0) - (hi - lo);
    if (need > 0) { lo -= need / 2; hi += need / 2; }
    const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
    const n = Math.max(pts.length, 2);
    const X = i => P + (W - 2 * P) * (pts.length === 1 ? 0.5 : i / (n - 1));
    const Y = v => +(P + (H - 2 * P) * (1 - (v - lo) / (hi - lo))).toFixed(1);
    const lines = lims.map(l => `<line class="${l[0]}" x1="0" x2="${W}" y1="${Y(l[1])}" y2="${Y(l[1])}"/>`).join('');
    const path = pts.length > 1 ? `<polyline class="ln" points="${pts.map((p, i) => X(i).toFixed(1) + ',' + Y(p.v)).join(' ')}"/>` : '';
    const dots = pts.map((p, i) => p.cur
      ? `<circle class="cur d-${p.j}" cx="${X(i).toFixed(1)}" cy="${Y(p.v)}" r="4"/>`
      : `<circle class="d-${p.j}" cx="${X(i).toFixed(1)}" cy="${Y(p.v)}" r="2.8"/>`).join('');
    const label = 'ค่าล่าสุด: ' + pts.map(p => g(p.v) + (p.cur ? ' (ค่าที่กรอก)' : '')).join(' → ');
    return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="${esc(label)}">${lines}${path}${dots}</svg>`;
  }
  // แนวโน้ม: ขึ้น/ลงต่อเนื่องอย่างน้อย 3 ค่า และคาดว่าอีกกี่รอบจะหลุดเกณฑ์
  function trendOf(it, raw) {
    const pts = sparkPoints(it, raw);
    if (pts.length < 3) return null;
    const last = pts[pts.length - 1];
    if (last.j === 'ng') return null;                     // หลุดเกณฑ์แล้ว ข้อความแดงบอกอยู่แล้ว
    let k = 1;                                             // จำนวนช่วงที่ไปทางเดียวกันต่อเนื่อง (นับจากท้าย)
    const dir = Math.sign(last.v - pts[pts.length - 2].v);
    if (!dir) return null;
    while (k < pts.length - 1 && Math.sign(pts[pts.length - 1 - k].v - pts[pts.length - 2 - k].v) === dir) k++;
    if (k < 2) return null;
    const step = (last.v - pts[pts.length - 1 - k].v) / k;
    const limit = dir < 0 ? it.min_value : it.max_value;
    const word = (dir < 0 ? '↘ ลดลง' : '↗ เพิ่มขึ้น') + ` ${k} รอบติดกัน`;
    if (limit != null) {
      const rounds = Math.ceil(Math.abs((limit - last.v) / step));
      if (rounds <= 3) return { lv: 'warn', text: `${word} — อีกราว ${rounds} รอบอาจ${dir < 0 ? 'ต่ำ' : 'สูง'}กว่าเกณฑ์ ${g(limit)}${it.unit ? ' ' + it.unit : ''}` };
    }
    return { lv: 'info', text: word };
  }
  function trendHtml(it, raw) {
    const t = trendOf(it, raw);
    return t ? `<span class="${t.lv}">${esc(t.text)}</span>` : '';
  }
  function updateSpark(sec, it, raw) {
    const sp = sec.querySelector('.m-spark'); if (sp) sp.innerHTML = sparkSvg(it, raw);
    const tr = sec.querySelector('.m-trend'); if (tr) tr.innerHTML = trendHtml(it, raw);
  }

  function spec(it) {
    if (it.item_type === 'number' || it.item_type === 'counter' || it.item_type === 'calc') {
      const u = it.unit ? ' ' + esc(it.unit) : '';
      if (it.min_value != null && it.max_value != null) return `เกณฑ์ ${g(it.min_value)} – ${g(it.max_value)}${u}`;
      if (it.min_value != null) return `เกณฑ์ ≥ ${g(it.min_value)}${u}`;
      if (it.max_value != null) return `เกณฑ์ ≤ ${g(it.max_value)}${u}`;
      return it.item_type === 'counter' ? `มิเตอร์สะสม${u} (ต้องไม่น้อยกว่าครั้งก่อน)` : (it.unit ? esc(it.unit) : '');
    }
    return '';
  }

  function ans(key) { return draft.answers[key] || (draft.answers[key] = { value: '', remark: '', photos: [] }); }

  function problems(it) {
    if (locked(it) && it.required && it._due !== false) return ['ยังไม่ได้สแกน QR ที่จุดตรวจ'];
    const a = draft.answers[it.item_key] || { value: '', remark: '', photos: [] };
    const r = evaluate(it, a.value);
    const out = [];
    if (r.j === 'invalid') out.push('ค่าต้องเป็นตัวเลข');
    else if (r.j === 'na' && it.required && it._due !== false) out.push('ยังไม่ได้กรอก');
    if (it.photo_required && r.j !== 'na' && r.j !== 'invalid' && !(a.photos || []).length) out.push('ต้องแนบรูปหลักฐาน');
    if (r.j === 'ng') {
      if (!String(a.remark || '').trim()) out.push('NG ต้องใส่หมายเหตุ');
      if (it.photo_on_ng && !(a.photos || []).length) out.push('NG ต้องแนบรูป');
    }
    if (suspect(it, a)) out.push('ค่าต่างจากปกติมาก — กดยืนยันหรือแก้ค่า');            // v0.49
    if (a.src === 'scada' && a.scada != null && !a.scadaOk) out.push('ดูหน้าปัดแล้วกด ✓ ตรงกับหน้าปัด');
    return out;
  }

  // v0.49 ดักค่าที่น่าจะพิมพ์ผิด: ลืม/เกินจุดทศนิยม (ค่าย้ายจุดแล้วเข้าเกณฑ์) · ต่างจากครั้งก่อน ≥ 5 เท่า
  function suspect(it, a) {
    if (!a || !(it.item_type === 'number' || it.item_type === 'counter')) return null;
    const raw = String(a.value || '').trim(), x = num(raw);
    if (raw === '' || x == null || Number.isNaN(x) || a.okVal === raw) return null;
    const lo = it.min_value, hi = it.max_value, inSpec = v => (lo == null || v >= lo) && (hi == null || v <= hi);
    if ((lo != null || hi != null) && !inSpec(x)) {
      for (const f of [0.1, 0.01, 10, 100]) {
        const c = +(x * f).toFixed(6);
        if (inSpec(c)) return { msg: `อาจพิมพ์จุดทศนิยมผิด — หมายถึง ${g(c)} ใช่ไหม?`, fix: g(c) };
      }
    }
    const p = (pkg.previous[it.item_key] || {}).value_num;
    if (it.item_type === 'number' && p != null && p !== 0 && x !== 0) {
      const ratio = Math.abs(x / p);
      if (ratio >= 5 || ratio <= 0.2) return { msg: `ต่างจากครั้งก่อน (${g(p)}) มาก — ตรวจค่าอีกครั้ง`, fix: null };
    }
    return null;
  }
  function suspectHtml(it, a) {
    const s = suspect(it, a);
    if (!s) return '';
    return `<div class="m-susp" role="alert">⚠ ${esc(s.msg)}<div class="m-susp-btns">
      ${s.fix ? `<button type="button" class="m-btn m-btn-sm m-btn-primary" data-fixval="${esc(s.fix)}">ใช่ ใช้ ${esc(s.fix)}</button>` : ''}
      <button type="button" class="m-btn m-btn-sm" data-okval>ค่า ${esc(String(a.value).trim())} ถูกต้อง</button></div></div>`;
  }

  // ── บันทึกแบบร่างลงเครื่อง ──
  // saveNow: ปุ่ม/รูป บันทึกทันที · save: ระหว่างพิมพ์ หน่วง 250 ms · ออกจากหน้า/จอดับ: บันทึกทันที
  function saveNow() {
    clearTimeout(saveTimer); saveTimer = null;
    if (!draft || !draftKey) return Promise.resolve();
    draft.updated_at = ECS.nowTs();
    try { draft.meta = draftMeta(); } catch (e) { /* ข้อมูลประกอบ ไม่กระทบการบันทึก */ }
    return ECS.drafts.put(draftKey, draft);
  }
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveNow, 250);
  }
  const flush = () => { if (saveTimer) saveNow(); };
  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });

  // v0.39 ประวัติเครื่อง (สรุป 1 บรรทัด แตะเพื่อดูรายละเอียด) — เปิดให้เองถ้ามีใบแจ้งซ่อมค้างหรือ NG ซ้ำ
  function histHtml(m) {
    if (!m || !(m.last || (m.ngs || []).length || (m.wos || []).length || (m.actions || []).length || (m.pm || []).length || m.down)) return '';
    const rep = Object.keys(m.repeat || {}).length, openWo = (m.wos || []).length + (m.actions || []).length;
    const bits = [];
    if (m.last) bits.push(`ตรวจล่าสุด ${fmt(m.last.finished_at, true)}${m.last.inspector ? ' (' + esc(m.last.inspector) + ')' : ''}`);
    if ((m.ngs || []).length) bits.push(`NG ล่าสุด ${fmt(m.ngs[0].at, true)}`);
    if (openWo) bits.push(`<b style="color:var(--warn)">งานซ่อมค้าง ${openWo}</b>`);
    if (rep) bits.push(`<b style="color:var(--ng)">NG ซ้ำ ${rep} หัวข้อ</b>`);
    if ((m.pm || []).length) bits.push(`PM ถัดไป ${esc(fmtDate(m.pm[0].due))}`);
    const li = (arr, f) => arr && arr.length ? '<ul>' + arr.map(f).join('') + '</ul>' : '';
    return `<details class="m-hist${openWo || rep ? ' alert' : ''}"${openWo || rep ? ' open' : ''}><summary>🕘 <b>ประวัติเครื่อง</b> · ${bits.join(' · ')}</summary><div class="hbody">
      ${(m.wos || []).length ? '<h4>ใบแจ้งซ่อม UT-CMMS ที่ยังเปิด</h4>' + li(m.wos, w => `<li><b>${esc(w.no)}</b> ${esc(w.status)} · ${fmt(w.at, true)}${w.assignee ? ' · ' + esc(w.assignee) : ''}</li>`) : ''}
      ${(m.actions || []).length ? '<h4>งานแก้ไข (CAPA) ที่ยังเปิด</h4>' + li(m.actions, a => `<li><b>${esc(a.code || '')}</b> ${esc(a.title)}${a.due ? ' · กำหนด ' + esc(fmtDate(a.due)) : ''}</li>`) : ''}
      ${(m.ngs || []).length ? '<h4>NG ล่าสุด</h4>' + li(m.ngs, n => `<li>${fmt(n.at, true)} · <b>${esc(n.item)}</b> ${esc(n.value)}${n.unit ? ' ' + esc(n.unit) : ''}${n.remark ? ' — ' + esc(n.remark) : ''}${n.by ? ' <span class="muted">(' + esc(n.by) + ')</span>' : ''}</li>`) : ''}
      ${(m.pm || []).length ? '<h4>แผน PM</h4>' + li(m.pm, p => `<li>${esc(fmtDate(p.due))} · ${esc(p.task)} <span class="muted">(${esc(p.freq)} · ${esc(p.state_th)})</span></li>`) : ''}
      ${m.down ? `<h4>หยุดครั้งล่าสุด</h4><ul><li>${fmt(m.down.start, true)}${m.down.end ? ' – ' + fmt(m.down.end, true) : ' (ยังหยุดอยู่)'} · ${esc(m.down.cat)}${m.down.reason ? ': ' + esc(m.down.reason) : ''}</li></ul>` : ''}
      ${pkg.form.equipment_id ? `<a class="m-btn m-btn-sm" style="margin-top:8px" href="${U('/machines/' + pkg.form.equipment_id)}">📋 ดูประวัติเครื่องทั้งหมด ›</a>` : ''}
      ${m.last ? `<div class="small muted" style="margin-top:6px">ตรวจล่าสุด ${fmt(m.last.finished_at, true)}${m.last.ng_count ? ' · NG ' + m.last.ng_count : ' · ปกติ'}</div>` : ''}
    </div></details>`;
  }

  // v0.40 เลื่อนไปข้อถัดไปอัตโนมัติ (ตอบ OK / ตัวเลือกที่ไม่ NG / กด "ถัดไป" ที่ช่องตัวเลข) — ปิดได้ จำไว้ในเครื่อง
  let AUTO = true; try { AUTO = localStorage.getItem('m_autoadv') !== '0'; } catch (e) { /* */ }
  const autoBtn = () => `<button type="button" class="m-autoadv${AUTO ? ' on' : ''}" data-autoadv aria-pressed="${AUTO}">${AUTO ? '⤵ เลื่อนข้อถัดไปอัตโนมัติ: เปิด' : '⤵ เลื่อนข้อถัดไปอัตโนมัติ: ปิด'}</button>`;
  function advance(fromIdx) {
    if (!AUTO) return;
    const secs = Array.from(document.querySelectorAll('section.m-item'));
    const pos = secs.findIndex(el => el.id === 'it-' + fromIdx);
    const empty = el => { const it = pkg.items[Number(el.id.slice(3))]; return it && it._show && !el.classList.contains('locked')
      && it.item_type !== 'calc' && evaluate(it, (draft.answers[it.item_key] || {}).value).j === 'na'; };
    const next = secs.slice(pos + 1).find(empty) || secs.slice(0, pos).find(empty);
    if (!next) { const b = document.getElementById('btnSubmit'); if (b) { b.classList.add('pulse'); setTimeout(() => b.classList.remove('pulse'), 1600); } return; }
    setTimeout(() => {
      next.scrollIntoView({ behavior: 'smooth', block: 'center' });
      next.classList.add('m-next'); setTimeout(() => next.classList.remove('m-next'), 1200);
      const num = next.querySelector('[data-num]');
      if (num) setTimeout(() => { try { num.focus({ preventScroll: true }); } catch (e) { num.focus(); } }, 420);
    }, 180);
  }

  // v0.45 ฟอร์มผสม: เติมค่าจาก SCADA (≤ 3 ชม.) ในหัวข้อตัวเลขที่ยังว่าง — ช่างดูหน้าปัดแล้วยืนยันหรือแก้
  function scadaOf(it) {
    const v = (pkg.scada || {})[it.item_key];
    if (!v || !(it.item_type === 'number' || it.item_type === 'counter')) return null;
    if (pkg.scada_slot) return v;                 // v0.82 ค่าของเวลารอบนั้น (รวมลงข้อมูลย้อนหลัง) — ไม่จำกัดอายุ
    const age = (Date.now() - new Date(String(v.at).replace(' ', 'T') + ':00').getTime()) / 60000;
    return age <= 180 && age > -10 ? v : null;
  }
  function applyScada() {
    if (!pkg.scada) return;
    pkg.items.forEach(it => {
      const v = scadaOf(it); if (!v) return;
      const a = ans(it.item_key);
      if (String(a.value || '').trim()) return;
      a.value = g(v.value); a.src = 'scada'; a.scada = v.value; a.scadaAt = v.at; a.scadaTag = v.tag;
      if (pkg.scada_slot) a.scadaOk = true;       // v0.82 ค่าของรอบที่ระบบดึงไว้แล้ว — ไม่ต้องกดยืนยันทีละข้อ (แก้ได้)
    });
  }
  function scadaChip(a) {
    if (a.scada == null) return '';
    const t = String(a.scadaAt || '').slice(11, 16);
    if (a.src !== 'scada') return `<div class="m-scada edited">✎ แก้จากค่า SCADA (${esc(g(a.scada))} เวลา ${esc(t)})</div>`;
    if (pkg.scada_slot) return `<div class="m-scada ok">📡 ค่าจาก SCADA รอบ ${esc(t)} · ตรวจดู แก้ได้ถ้าไม่ถูกต้อง</div>`;
    return a.scadaOk
      ? `<div class="m-scada ok">📡 ค่าจาก SCADA ${esc(t)} · ✓ ยืนยันตรงกับหน้าปัดแล้ว</div>`
      : `<div class="m-scada">📡 ค่าจาก SCADA ${esc(t)} — ดูหน้าปัดที่เครื่องแล้วกดยืนยัน หรือแก้ค่า
          <button type="button" class="m-btn m-btn-sm m-btn-primary m-scadaok" data-scadaok>✓ ตรงกับหน้าปัด</button></div>`;
  }

  // ── แสดงผล ──
  // ── v0.95 หัวข้อคำนวณ (calc): ไวยากรณ์เดียวกับ ecs/formula.py — ไม่ใช้ eval ──
  const FN = { abs: [1, 1], min: [1, 20], max: [1, 20], avg: [1, 20], round: [1, 2], sqrt: [1, 1] };
  function fParse(src) {
    const re = /\s*(?:(\d+(?:\.\d+)?|\.\d+)|\{([A-Za-z0-9_\-]+)\}|([A-Za-z_]+)|(\S))/y, t = [];
    let m; re.lastIndex = 0;
    while (re.lastIndex < src.length && (m = re.exec(src))) {
      if (m[1] != null) t.push(['num', Number(m[1])]); else if (m[2] != null) t.push(['ref', m[2]]);
      else if (m[3] != null) { if (!FN[m[3].toLowerCase()]) throw 0; t.push(['fn', m[3].toLowerCase()]); }
      else if (m[4] != null) { if (!'+-*/(),'.includes(m[4])) throw 0; t.push(['op', m[4]]); }
    }
    let i = 0;
    const pk = () => t[i] || [null, null], is = (k, v) => pk()[0] === k && pk()[1] === v;
    const take = (k, v) => { if (k && !is(k, v)) throw 0; return t[i++]; };
    function expr() { let n = term(); while (is('op', '+') || is('op', '-')) n = ['bin', take()[1], n, term()]; return n; }
    function term() { let n = fac(); while (is('op', '*') || is('op', '/')) n = ['bin', take()[1], n, fac()]; return n; }
    function fac() {
      const [k, v] = pk();
      if (k === 'op' && (v === '-' || v === '+')) { i++; const f = fac(); return v === '-' ? ['neg', f] : f; }
      if (k === 'num' || k === 'ref') { i++; return [k, v]; }
      if (k === 'fn') { i++; take('op', '('); const a = [expr()]; while (is('op', ',')) { i++; a.push(expr()); } take('op', ')');
        if (a.length < FN[v][0] || a.length > FN[v][1]) throw 0; return ['fn', v, a]; }
      if (k === 'op' && v === '(') { i++; const n = expr(); take('op', ')'); return n; }
      throw 0;
    }
    const n = expr(); if (i !== t.length) throw 0; return n;
  }
  function fEval(n, V) {
    switch (n[0]) {
      case 'num': return n[1];
      case 'ref': { const v = V(n[1]); if (v == null || Number.isNaN(v)) throw 0; return v; }
      case 'neg': return -fEval(n[1], V);
      case 'bin': { const a = fEval(n[2], V), b = fEval(n[3], V);
        if (n[1] === '/' && b === 0) throw 0; return n[1] === '+' ? a + b : n[1] === '-' ? a - b : n[1] === '*' ? a * b : a / b; }
      default: { const a = n[2].map(x => fEval(x, V));
        if (n[1] === 'abs') return Math.abs(a[0]); if (n[1] === 'min') return Math.min(...a); if (n[1] === 'max') return Math.max(...a);
        if (n[1] === 'avg') return a.reduce((p, q) => p + q, 0) / a.length;
        if (n[1] === 'round') { const k = Math.pow(10, a[1] || 0); return Math.round(a[0] * k) / k; }
        if (a[0] < 0) throw 0; return Math.sqrt(a[0]); }
    }
  }
  const fCache = {};
  function calcOf(it, depth) {
    if ((depth || 0) > 12) return null;
    try {
      const ast = fCache[it.formula] || (fCache[it.formula] = fParse(String(it.formula || '')));
      const V = k => { const x = pkg.items.find(i => i.item_key === k); if (!x) return null;
        if (x.item_type === 'calc') return calcOf(x, (depth || 0) + 1);
        const r = num(String((draft.answers[k] || {}).value || '').trim()); return r == null || Number.isNaN(r) ? null : r; };
      const v = fEval(ast, V);
      return Number.isFinite(v) ? Math.round(v * 1e4) / 1e4 : null;
    } catch (e) { return null; }
  }
  function formulaLabel(it) {
    return esc(String(it.formula || '')).replace(/\{([A-Za-z0-9_\-]+)\}/g, (m, k) => { const x = pkg.items.find(i => i.item_key === k); return x ? '<b>' + esc(x.name) + '</b>' : '?'; });
  }
  // คำนวณใหม่ทุกครั้งที่ค่าเปลี่ยน · dom=true วาดเฉพาะหัวข้อคำนวณที่ค่าเปลี่ยน
  function syncCalcs(dom) {
    (pkg.items || []).forEach((it, idx) => {
      if (it.item_type !== 'calc') return;
      const v = calcOf(it), sv = v == null ? '' : String(v), a = ans(it.item_key);
      if (a.value === sv) return;
      a.value = sv;
      const el = dom && document.getElementById('it-' + idx);
      if (el) el.outerHTML = renderItem(it, idx);
    });
  }

  function renderItem(it, idx) {
    const a = ans(it.item_key), r = evaluate(it, a.value), prev = pkg.previous[it.item_key];
    let input = '';
    if (it.item_type === 'ok_ng') {
      input = `<div class="m-seg">
        <button type="button" class="m-seg-btn ok ${a.value === 'OK' ? 'on' : ''}" data-set="OK">✓ OK</button>
        <button type="button" class="m-seg-btn ng ${a.value === 'NG' ? 'on' : ''}" data-set="NG">✕ NG</button></div>`;
    } else if (it.item_type === 'number' || it.item_type === 'counter') {
      input = `<div class="m-numrow"><input class="m-input m-num" type="text" inputmode="decimal" enterkeyhint="next" autocomplete="off"
        data-num value="${esc(a.value)}" placeholder="กรอกค่า" aria-label="${esc(it.name)}">${it.unit ? `<span class="m-unit">${esc(it.unit)}</span>` : ''}${histOf(it).length ? `<span class="m-spark" title="แนวโน้ม 5 ครั้งล่าสุด">${sparkSvg(it, a.value)}</span>` : ''}</div>`;
    } else if (it.item_type === 'calc') {
      input = `<div class="m-calcbox"><span class="m-calcv">${a.value === '' ? '–' : esc(a.value)}</span>${it.unit ? `<span class="m-unit">${esc(it.unit)}</span>` : ''}
        <div class="m-calcf">🧮 คำนวณอัตโนมัติ = ${formulaLabel(it)}${a.value === '' ? ' <span class="muted">(กรอกหัวข้อที่อ้างให้ครบ)</span>' : ''}</div></div>`;
    } else if (it.item_type === 'choice') {
      input = '<div class="m-choices">' + (it.options || []).map(o =>
        `<button type="button" class="m-seg-btn ${o.ng ? 'ng' : 'ok'} ${a.value === o.label ? 'on' : ''}" data-set="${esc(o.label)}">${esc(o.label)}</button>`).join('') + '</div>';
    } else {
      input = `<textarea class="m-input" data-text rows="2" placeholder="พิมพ์ข้อความ">${esc(a.value)}</textarea>`;
    }
    const isNg = r.j === 'ng';
    const showRemark = isNg || a.remark || a.showRemark;
    const needPhoto = (isNg && it.photo_on_ng) || !!it.photo_required;
    const photos = (a.photos || []).map(pid => `<div class="m-thumb"><img src="${thumbs[pid] || ''}" data-pid="${pid}" alt="">
      <button type="button" data-delphoto="${pid}" aria-label="ลบรูป">✕</button></div>`).join('');
    return `<section class="m-item j-${r.j}${locked(it) ? ' locked' : ''}" id="it-${idx}" data-key="${esc(it.item_key)}" data-sec="${esc(it.section || '')}">
      <div class="m-item-head"><span class="m-no">${idx + 1}</span>
        <div class="m-item-name">${esc(it.name)}${it.item_type === 'calc' ? ' <span class="muted small">(คำนวณให้)</span>' : it.required && it._due !== false ? '' : ' <span class="muted small">(ไม่บังคับ)</span>'}${it.critical ? ' <span class="badge b-ng">วิกฤต</span>' : ''}${it.check_freq ? ` <span class="m-freq">⏱ ${esc(freqLabel(it))}</span>` : ''}</div>
        ${r.j !== 'na' && r.j !== 'invalid' ? `<span class="badge ${J[r.j][1]}">${J[r.j][0]}</span>` : ''}</div>
      ${spec(it) ? `<div class="m-spec">${spec(it)}</div>` : ''}
      ${pkg.machine && pkg.machine.repeat && pkg.machine.repeat[it.item_key] ? `<span class="m-repeat">⚠ NG ซ้ำ ${pkg.machine.repeat[it.item_key]} ครั้งใน 30 วัน — ดูประวัติเครื่องด้านบน</span>` : ''}
      ${it.guide ? `<div class="m-guide">${esc(it.guide)}</div>` : ''}
      ${input}
      ${scadaChip(a)}
      ${suspectHtml(it, a)}
      <div class="m-msg">${esc(r.msg || (r.j === 'invalid' ? 'ต้องเป็นตัวเลข' : ''))}</div>
      ${histOf(it).length ? `<div class="m-trend">${trendHtml(it, a.value)}</div>` : ''}
      ${prev ? `<div class="m-prev">ครั้งก่อน: <strong>${esc(prev.value_text)}</strong>${it.unit && prev.value_num != null ? ' ' + esc(it.unit) : ''} · ${fmt(prev.at, true)}</div>` : ''}
      ${showRemark ? `<textarea class="m-input m-remark ${isNg && !a.remark ? 'need' : ''}" data-remark rows="2"
          placeholder="${isNg ? 'หมายเหตุ (บังคับ): อาการ / สาเหตุ / สิ่งที่ทำไปแล้ว' : 'หมายเหตุ'}">${esc(a.remark)}</textarea>` : ''}
      <div class="m-item-tools">
        ${showRemark ? '' : '<button type="button" class="linkbtn" data-addremark>+ หมายเหตุ</button>'}
        <button type="button" class="m-btn m-btn-sm ${needPhoto && !(a.photos || []).length ? 'need' : ''}" data-photo>📷 ${needPhoto ? (it.photo_required && !isNg ? 'ถ่ายรูปหลักฐาน (บังคับ)' : 'ถ่ายรูป (บังคับ)') : 'ถ่ายรูป'}</button>
        <button type="button" class="m-btn m-btn-sm" data-gallery title="เลือกรูปจากเครื่อง (ไฟล์ใหญ่ / HEIC ได้)">🖼 เลือกรูป</button>
        <button type="button" class="linkbtn m-chreq-btn" data-chreq="${esc(it.item_key)}" title="แจ้งหัวหน้า/ผู้ดูแลให้แก้หัวข้อนี้">✏️ แจ้งแก้ไข</button>
      </div>
      ${photos ? `<div class="m-thumbs">${photos}</div>` : ''}
    </section>`;
  }

  const liveScan = ECS.canLiveScan;
  const canCamScan = true;                                     // v0.31 ไม่มีกล้องสด (http://) → ถ่ายรูป QR แล้วอ่านในหน้าเว็บ
  async function camScan() {
    if (!liveScan) return ECS.photoQR();
    const box = document.createElement('div'); box.className = 'm-camwrap';
    box.innerHTML = '<video playsinline muted></video><button type="button" class="m-btn">ปิด</button>';
    document.body.appendChild(box);
    const video = box.querySelector('video');
    let stream = null, stop = false;
    const close = () => { stop = true; if (stream) stream.getTracks().forEach(t => t.stop()); box.remove(); };
    box.querySelector('button').onclick = close;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      video.srcObject = stream; await video.play();
      const det = new BarcodeDetector({ formats: ['qr_code'] });
      return await new Promise(resolve => {
        const tick = async () => {
          if (stop) return resolve(null);
          try { const c = await det.detect(video); if (c.length) { close(); return resolve(c[0].rawValue); } } catch (e) { /* */ }
          requestAnimationFrame(tick);
        };
        tick();
      });
    } catch (e) { close(); alert('เปิดกล้องไม่ได้ — พิมพ์รหัสใต้ QR แทน'); return null; }
  }
  // ── ป็อปอัปสแกน QR ที่จุดตรวจ (เปิดเช็คชีทตรงโดยไม่ได้สแกน → ขึ้นให้สแกนก่อน ไม่ต้องเดาว่าทำไมกรอกไม่ได้) ──
  const pointSecs = () => sections().filter(s => pkg.items.some(it => it._show && (it.section || '') === s.name));
  const pendingPoints = () => needScan() ? pointSecs().filter(s => !scanned(s.name)) : [];
  function closePopup() {
    const m = document.querySelector('.m-modal'); if (m) m.remove();
    document.body.classList.remove('m-modal-open');
  }
  function toast(text, ok) {
    const bar = document.createElement('div');
    bar.className = 'm-toast ' + (ok ? 'ok' : 'err'); bar.textContent = text;
    document.body.appendChild(bar); setTimeout(() => bar.remove(), 3500);
  }
  function goPoint(sec) {
    const s = sections().find(x => x.name === sec);
    const el = s && (document.getElementById('pt-' + s.no) || document.querySelector(`.m-item[data-sec="${CSS.escape(sec)}"]`));
    if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 64, behavior: 'smooth' });
  }
  function scanPopup(sec, msg) {
    closePopup();
    const secs = pointSecs();
    const s = secs.find(x => x.name === sec) || { no: 1, name: sec, hint: '' };
    const pos = secs.indexOf(s) + 1;
    const title = s.name || [pkg.form.eq_code, pkg.form.eq_name].filter(Boolean).join(' · ') || 'จุดตรวจ';
    const wrap = document.createElement('div');
    wrap.className = 'm-modal';
    wrap.innerHTML = `<div class="m-sheet" role="dialog" aria-modal="true" aria-labelledby="popTitle">
      <div class="m-sheet-ic" aria-hidden="true">⌗</div>
      <h2 id="popTitle">สแกน QR ที่จุดตรวจก่อนเริ่ม</h2>
      <p class="m-sheet-sub">แบบฟอร์มนี้ต้องยืนยันว่าอยู่ที่จุดตรวจจริง จึงจะกรอกหัวข้อได้</p>
      <div class="m-sheet-pt"><span class="m-point-no">${s.no || 1}</span><div>
        <b>${esc(title)}</b>${secs.length > 1 ? `<div class="small muted">จุดที่ ${pos} จาก ${secs.length} · สแกนแล้ว ${secs.length - pendingPoints().length} จุด</div>` : ''}
        ${s.hint ? `<div class="small">📍 ${esc(s.hint)}</div>` : ''}</div></div>
      <button type="button" class="m-btn m-btn-primary m-btn-block m-btn-lg" data-pcam>📷 ${liveScan ? 'เปิดกล้องสแกน QR' : 'ถ่ายรูป QR ที่จุดตรวจ'}</button>
      ${liveScan ? '' : '<div class="small muted" style="margin-top:6px;text-align:center">กดแล้วถ่ายรูปป้าย QR — ระบบอ่านรหัสในหน้านี้เลย ไม่ต้องออกไปแอปกล้อง</div>'}
      <div class="m-sheet-or"><span>หรือพิมพ์รหัส 6 ตัวใต้ QR</span></div>
      <div class="m-scanrow"><input class="m-input" data-pcode placeholder="รหัส 6 ตัว" maxlength="12" autocomplete="off" autocapitalize="characters" aria-label="รหัสจุดตรวจ">
        <button type="button" class="m-btn m-btn-primary" data-pok>ยืนยัน</button></div>
      <div class="m-msg" data-pmsg>${esc(msg || '')}</div>
      <div class="m-sheet-foot"><button type="button" class="m-btn" data-pclose>ดูหัวข้อก่อน</button>
        <a class="m-btn" href="${U('/m/')}">กลับงานของฉัน</a></div>
    </div>`;
    document.body.appendChild(wrap); document.body.classList.add('m-modal-open');
    const input = wrap.querySelector('[data-pcode]'), out = wrap.querySelector('[data-pmsg]');
    const attempt = async code => {
      if (!normCode(code)) { out.textContent = 'พิมพ์รหัสใต้ QR ก่อน'; input.focus(); return; }
      let hit = matchPoint(code, sec);
      if (hit == null) {
        const other = matchPoint(code);
        if (other != null && !scanned(other)) hit = other;               // สแกนจุดอื่นของแบบฟอร์มนี้ → รับจุดนั้นแทน
        else {
          out.textContent = other != null ? `จุด "${other || 'ทั่วไป'}" ยืนยันไปแล้ว — ไปที่จุด "${title}"` : 'รหัสไม่ถูกต้อง — ตรวจว่าอยู่ที่เครื่อง/จุดที่ถูกต้อง';
          const sh = wrap.querySelector('.m-sheet'); sh.classList.add('shake'); setTimeout(() => sh.classList.remove('shake'), 600);
          return;
        }
      }
      await confirmPoint(hit, code);
      closePopup(); renderAll();
      toast(`✓ ยืนยันจุด "${hit || title}" แล้ว — เริ่มตรวจได้`, true);
      goPoint(hit);
    };
    wrap.addEventListener('click', async e => {
      const b = e.target.closest('button');
      if (e.target === wrap || (b && b.hasAttribute('data-pclose'))) return closePopup();
      if (!b) return;
      if (b.hasAttribute('data-pok')) return attempt(input.value);
      if (b.hasAttribute('data-pcam')) { const v = await camScan(); if (v) attempt(v); }
    });
    input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); attempt(input.value); } });
    wrap.addEventListener('keydown', e => { if (e.key === 'Escape') closePopup(); });
    const first = wrap.querySelector('[data-pcam]') || input; setTimeout(() => first.focus({ preventScroll: true }), 50);
  }

  async function tryPoint(box, code) {
    const sec = box.dataset.sec;
    const hit = matchPoint(code, sec);
    const msg = box.querySelector('[data-ptmsg]');
    if (hit == null) {
      const other = matchPoint(code);
      msg.textContent = other != null ? `รหัสนี้เป็นของจุด "${other || 'ทั่วไป'}" ไม่ใช่จุดนี้` : 'รหัสไม่ถูกต้อง — ตรวจว่าอยู่ที่เครื่อง/จุดที่ถูกต้อง';
      box.classList.add('shake'); setTimeout(() => box.classList.remove('shake'), 600); return;
    }
    await confirmPoint(sec, code);
    const y = window.scrollY; renderAll(); window.scrollTo(0, y);
  }

  function sections() {
    if (pkg.sections && pkg.sections.length) return pkg.sections;
    const out = [];
    pkg.items.forEach(it => { const n = it.section || ''; if (!out.find(s => s.name === n)) out.push({ name: n, hint: '', no: out.length + 1 }); });
    return out;
  }

  // v0.28 แจ้งแก้ไขหัวข้อ / แบบฟอร์ม → หัวหน้างาน / ผู้ดูแลระบบ
  const CHREQ_KINDS = { name: 'ชื่อหัวข้อ / คำอธิบายไม่ตรงหน้างาน', criteria: 'เกณฑ์ / ค่ามาตรฐาน / หน่วยไม่ถูกต้อง',
    options: 'ตัวเลือกไม่ครบ / ไม่เหมาะสม', add: 'ขอเพิ่มหัวข้อตรวจ', remove: 'หัวข้อนี้ไม่ใช้แล้ว / ควรลบ',
    data: 'ข้อมูลกรอกผิด / ไม่ครบ (จุดตรวจ รูป เครื่อง ฯลฯ)', freq: 'ความถี่ / เวลาตรวจไม่เหมาะสม', other: 'อื่น ๆ' };
  function chreqPopup(key) {
    closePopup();
    const it = key ? pkg.items.find(x => x.item_key === key) : null;
    const kinds = Object.keys(CHREQ_KINDS).filter(k => it ? k !== 'add' : true);
    const wrap = document.createElement('div');
    wrap.className = 'm-modal';
    wrap.innerHTML = `<div class="m-sheet" role="dialog" aria-modal="true" aria-labelledby="crTitle">
      <h2 id="crTitle">✏️ แจ้งแก้ไข${it ? 'หัวข้อ' : 'แบบฟอร์ม'}</h2>
      <p class="m-sheet-sub">${it ? `<b>${esc(it.name)}</b>` : esc(pkg.form.name)} — ส่งถึงหัวหน้างาน/ผู้ดูแลระบบ (ไม่กระทบผลตรวจที่กำลังกรอก)</p>
      <label class="small">เรื่องที่ต้องการแก้</label>
      <select class="m-input" data-crkind>${kinds.map(k => `<option value="${k}">${esc(CHREQ_KINDS[k])}</option>`).join('')}</select>
      <label class="small" style="margin-top:8px;display:block">รายละเอียด (บังคับ)</label>
      <textarea class="m-input" data-crdetail rows="3" placeholder="เช่น หน้างานจริงไม่มีจุดนี้ / เกณฑ์ควรเป็น 0.1–0.3 / ควรมีตัวเลือก หยุดระบบชั่วคราว"></textarea>
      <label class="small" style="margin-top:8px;display:block">ค่าที่เสนอ (ถ้ามี)</label>
      <input class="m-input" data-crprop maxlength="200" placeholder="เช่น ชื่อใหม่ / ค่าเกณฑ์ใหม่ / ตัวเลือกที่ควรมี">
      <div class="m-msg" data-crmsg></div>
      <div class="m-sheet-foot"><button type="button" class="m-btn" data-crclose>ยกเลิก</button>
        <button type="button" class="m-btn m-btn-primary" data-crsend>ส่งคำขอ</button></div></div>`;
    document.body.appendChild(wrap); document.body.classList.add('m-modal-open');
    wrap.addEventListener('click', async ev => {
      if (ev.target === wrap || ev.target.closest('[data-crclose]')) { closePopup(); return; }
      if (!ev.target.closest('[data-crsend]')) return;
      const msg = wrap.querySelector('[data-crmsg]'), detail = wrap.querySelector('[data-crdetail]').value.trim();
      if (detail.length < 3) { msg.textContent = 'กรุณาอธิบายสิ่งที่ต้องการให้แก้'; return; }
      if (!navigator.onLine) { msg.textContent = 'ไม่มีสัญญาณ — ส่งคำขอได้เมื่อออนไลน์'; return; }
      const btn = ev.target.closest('[data-crsend]'); btn.disabled = true;
      try {
        const r = await fetch(U('/api/m/change-requests'), { method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': ECS.csrf() },
          body: JSON.stringify({ form_id: pkg.form.id, item_key: key || '', kind: wrap.querySelector('[data-crkind]').value,
            detail, proposed: wrap.querySelector('[data-crprop]').value.trim() }) });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(d.error || ('ส่งไม่สำเร็จ (' + r.status + ')'));
        closePopup(); toast('✓ ส่งคำขอแก้ไขแล้ว — ติดตามได้ที่ "คำขอแก้ไขของฉัน"', true);
      } catch (err) { msg.textContent = err.message; btn.disabled = false; }
    });
  }

  // v0.51 หัวฟอร์มเด่น + เตือนเปิดผิดรอบ / ผิดเครื่อง
  const TT = s => s ? new Date(String(s).replace(' ', 'T')).getTime() : NaN;
  function roundState(rnd) {
    if (!rnd || !rnd.due_at) return null;
    const now = Date.now();
    if (pkg.round_done && pkg.round && pkg.round.id === rnd.id) return ['done', 'b-ok', '✓ ส่งแล้ว'];
    if (TT(rnd.close_at) <= now) return ['closed', 'b-ng', '✕ ปิดรอบแล้ว'];
    if (TT(rnd.deadline_at) <= now) return ['overdue', 'b-warn', '⏰ เลยกำหนด'];
    if (TT(rnd.due_at) - now > 120 * 60000) return ['early', 'b-none', '🕒 ยังไม่ถึงเวลา'];
    return ['due', 'b-info', '⏱ ถึงเวลาตรวจ'];
  }
  function roundWarn() {
    const rnd = draft.round, st = roundState(rnd), f = pkg.form, out = [];
    if (draft.eq_bad) out.push(`<div class="m-warnbox ng"><b>⛔ QR ที่สแกนเป็นของเครื่องอื่น${draft.eq_bad.code ? ' (' + esc(draft.eq_bad.code) + ')' : ''}</b>
      <div>แบบฟอร์มนี้เป็นของ <b>${esc(f.eq_code || f.name)}</b> — ตรวจสอบว่ายืนอยู่ที่เครื่องถูกต้อง</div>
      ${draft.eq_bad.href ? `<a class="m-btn m-btn-block" href="${esc(draft.eq_bad.href)}" style="margin-top:6px">เปิดแบบฟอร์มของเครื่องที่สแกน ›</a>` : ''}</div>`);
    const cur = pkg.current_round;
    if (cur && (!rnd || cur.id !== rnd.id) && TT(cur.close_at) > Date.now())
      out.push(`<div class="m-warnbox info">${TT(cur.deadline_at) <= Date.now() ? 'มีรอบที่ค้างอยู่ (เลยกำหนด)' : 'มีรอบที่ถึงเวลาตอนนี้'}: <b>รอบ ${fmt(cur.due_at)}</b> (ต้องเสร็จ ${fmt(cur.deadline_at, true)})
        <a class="m-btn m-btn-block" href="#f=${f.id}&r=${cur.id}${draft.eq_ok ? '&qr=1' : ''}" style="margin-top:6px">▶ เปลี่ยนไปรอบนี้</a></div>`);
    return out.join('');
  }
  // v0.53 สถานะการจับรอบ: นับเป็นรอบไหน · ส่งก่อนเมื่อไรจึงตรงเวลา · ปิดรอบ (ตัด) เมื่อไร · เหลือกี่นาที
  function left(ms) {
    const m = Math.max(0, Math.round(ms / 60000));
    if (m >= 2880) return `${Math.floor(m / 1440)} วัน`;
    return m < 60 ? `${m} นาที` : `${Math.floor(m / 60)} ชม.${m % 60 ? ' ' + (m % 60) + ' น.' : ''}`;
  }
  const hm = ms => { const d = new Date(ms); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  function roundCard() {
    const rnd = draft.round, st = roundState(rnd), now = Date.now();
    if (pkg.down) return '';
    if (!rnd || !rnd.due_at) {
      const nx = pkg.next_round;
      return `<div class="m-rcard none" id="rcard"><div class="k">สถานะการตรวจ</div><b>ℹ ตรวจนอกรอบ — ไม่นับเป็นรอบตรวจ</b>
        <div class="s">ตอนนี้ไม่มีรอบที่ต้องตรวจของเครื่องนี้ (ส่งได้ บันทึกเป็นประวัติ)${nx ? ` · รอบถัดไป <b>${fmt(nx.due_at, true)}</b>` : ''}</div></div>`;
    }
    const due = fmt(rnd.due_at), dl = fmt(rnd.deadline_at, true), cl = fmt(rnd.close_at, true);
    const C = {
      due: ['ok', `✓ จับรอบแล้ว — นับเป็นรอบ ${due}`, `ส่งก่อน <b>${dl}</b> = ตรวจตรงเวลา (เหลือ ${left(TT(rnd.deadline_at) - now)}) · ตัดรอบ ${cl}`],
      overdue: ['warn', `⏰ เลยกำหนดแล้ว — ยังส่งได้ นับเป็น “ตรวจล่าช้า” (รอบ ${due})`, `ตัดรอบ <b>${cl}</b> (อีก ${left(TT(rnd.close_at) - now)}) หลังจากนั้นเป็นขาดตรวจ`],
      early: ['none', `🕒 ยังไม่ถึงเวลารอบ ${due}`, `เริ่มตรวจได้ ${hm(TT(rnd.due_at) - 120 * 60000)} (อีก ${left(TT(rnd.due_at) - 120 * 60000 - now)}) · ต้องเสร็จ ${dl}`],
      closed: ['ng', `✕ ตัดรอบแล้ว (${cl}) — รอบ ${due} เป็นขาดตรวจ`, pkg.can_backfill
        ? '📝 คุณมีสิทธิ์ลงข้อมูลย้อนหลัง — ส่งได้ บันทึกเป็นตรวจล่าช้าของรอบนั้น (บันทึก Audit)'
        : '🔒 ลงข้อมูลย้อนหลังไม่ได้ — ต้องได้รับสิทธิ์จากผู้ดูแลระบบหรือหัวหน้างาน FM/SV'],
      done: ['ng', `✓ รอบ ${due} ส่งผลแล้ว${pkg.round_done && pkg.round_done.inspector_name ? ' โดย ' + esc(pkg.round_done.inspector_name) : ''}`,
        `เวลา ${pkg.round_done ? fmt(pkg.round_done.finished_at, true) : ''} — ส่งอีกจะเป็นการตรวจซ้ำ ตรวจสอบว่าเปิดรอบถูกต้อง`],
    }[st ? st[0] : 'due'];
    return `<div class="m-rcard ${C[0]}" id="rcard"><div class="k">สถานะการตรวจ</div><b>${C[1]}</b><div class="s">${C[2]}</div></div>`;
  }
  setInterval(() => { const el = document.getElementById('rcard'); if (el && pkg && draft) el.outerHTML = roundCard(); }, 30000);

  function eqConfirm() {
    if (!pkg.form.equipment_id) return '';
    if (draft.eq_ok) return '<span class="m-eqok">✓ ยืนยันเครื่องแล้ว</span>';
    return pkg.eq_qr ? '<button type="button" class="m-eqscan" data-eqscan>📷 สแกนยืนยันเครื่อง</button>' : '';
  }
  async function scanConfirm() {
    const v = await ECS.photoQR(); if (!v) return;
    const m = String(v).match(/\/(e\/[A-Za-z0-9_-]+|p\/\d+\/[A-Za-z0-9-]+)\/?$/);
    const f = pkg.form;
    if (m && ((m[1].charAt(0) === 'e' && m[1].slice(2) === pkg.eq_qr) || (m[1].charAt(0) === 'p' && Number(m[1].split('/')[1]) === f.id))) {
      draft.eq_ok = 1; delete draft.eq_bad;
    } else {
      let code = '', href = '';
      if (m && m[1].charAt(0) === 'e') {
        const tok = m[1].slice(2), ids = ((await ECS.kv.get('eqtok')) || {})[tok] || [];
        const forms = Object.fromEntries(((await ECS.kv.get('forms')) || []).map(x => [x.id, x]));
        code = ids.length && forms[ids[0]] ? (forms[ids[0]].eq_code || forms[ids[0]].name) : '';
        href = ids.length === 1 ? `#f=${ids[0]}&qr=1` : U('/' + m[1]);
      }
      draft.eq_bad = { code, href }; draft.eq_ok = 0;
    }
    await ECS.drafts.put(draftKey, draft); renderAll();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // v0.56 แถบสถานะเครื่อง (ติดด้านบนตลอด ไม่ต้องเลื่อน) + หน้าสถานะหลังสแกน QR
  function eqJson() {
    const f = pkg.form;
    return esc(JSON.stringify({ id: f.equipment_id, code: f.eq_code || '', name: f.eq_name || '',
      reason: (pkg.down || {}).down_reason || '', since: (pkg.down || {}).down_since || '' }));
  }
  function eqStatusBar() {
    if (!pkg.form.equipment_id) return '';
    const d = pkg.down, j = eqJson();
    return d
      ? `<div class="m-eqbar down" role="status"><span class="m-eqdot"></span><div class="m-eqbar-t"><b>⛔ หยุดเดินอยู่</b>
           <small>${esc(d.down_reason || '')}${d.down_since ? ' · ตั้งแต่ ' + fmt(d.down_since, true) : ''}</small></div>
           <button type="button" class="m-eqbar-btn run" data-eqrun="${j}">▶ เดินเครื่อง</button></div>`
      : `<div class="m-eqbar run" role="status"><span class="m-eqdot"></span><div class="m-eqbar-t"><b>✅ เครื่องเดินอยู่</b>
           <small>${esc(pkg.form.eq_code || '')} · ใช้งานปกติ</small></div>
           <button type="button" class="m-eqbar-btn" data-eqdown="${j}">⛔ หยุด / PM</button></div>`;
  }
  function statusGate() {
    const f = pkg.form, d = pkg.down, j = eqJson();
    app.innerHTML = `<div class="m-gate ${d ? 'down' : 'run'}">
      <div class="m-gate-eq"><span class="m-eqcode">${esc(f.eq_code || '')}</span> ${esc(f.eq_name || '')}
        <div class="small muted">${esc([f.factory_name, f.area_name].filter(Boolean).join(' · '))}</div></div>
      <div class="m-gate-ic">${d ? '⛔' : '✅'}</div>
      <h1>${d ? 'เครื่องนี้แจ้งหยุดเดินอยู่' : 'เครื่องนี้เดินใช้งานอยู่'}</h1>
      ${d ? `<p><b>${esc(d.down_reason || '')}</b><br>ตั้งแต่ ${fmt(d.down_since, true)}${d.down_by_name ? ' · แจ้งโดย ' + esc(d.down_by_name) : ''}</p>`
          : '<p>ตรวจสอบสถานะเครื่องหน้างานก่อนเริ่มตรวจ</p>'}
      <div class="m-gate-q">สถานะเครื่องตอนนี้?</div>
      ${d ? `<button type="button" class="m-btn m-btn-primary m-btn-block m-gate-big" data-gate="go">▶ เครื่องเดินแล้ว — เริ่มตรวจ</button>
             <div class="small muted" style="margin:-4px 0 10px">ส่งผลตรวจแล้วระบบปลดสถานะหยุดเป็น “เดินเครื่อง” ในชื่อคุณอัตโนมัติ</div>
             <button type="button" class="m-btn m-btn-block" data-eqrun="${j}">▶ แจ้งเดินเครื่องทันที</button>
             <a class="m-btn m-btn-block" href="${U('/m/')}">ยังหยุดอยู่ — กลับงานของฉัน</a>`
          : `<button type="button" class="m-btn m-btn-primary m-btn-block m-gate-big" data-gate="go">✅ เครื่องเดินอยู่ — เริ่มตรวจ</button>
             <button type="button" class="m-btn m-btn-block m-gate-stop" data-eqdown="${j}">⛔ เครื่องหยุด / PM — ไม่ต้องตรวจรอบนี้</button>`}
    </div>`;
    app.querySelector('[data-gate="go"]').onclick = async () => {
      draft.status_ok = 1; await ECS.drafts.put(draftKey, draft); renderAll(); window.scrollTo(0, 0);
      afterRender();
    };
  }

  function renderAll() {
    syncCalcs(false);
    const items = pkg.items;
    let html = eqStatusBar();
    const f = pkg.form, rnd = draft.round, rst = roundState(rnd);
    html += `<div class="m-formhead">
      ${f.eq_code ? `<div class="m-eqhead"><span class="m-eqcode">${esc(f.eq_code)}</span><div class="m-eqmeta"><div class="m-eqname">${esc(f.eq_name || '')}</div>
        <div class="small muted">${esc([f.factory_name, f.area_name].filter(Boolean).join(' · '))}</div></div>${eqConfirm()}</div>` : ''}
      <div class="m-card-title">${esc(f.name)}</div>
      <div class="small muted">${f.eq_code ? '' : esc(f.area_name || f.factory_name || '') + ' · '}v${pkg.version.version_no}</div>
      ${roundCard()}
      ${roundWarn()}
      <div class="small muted">เริ่มตรวจ ${fmt(draft.scanned_at)}${pkg._cached ? ' · ใช้แบบฟอร์มที่เก็บไว้ในเครื่อง' : ''}</div>
      ${pkg.down ? `<div class="m-downnote">⛔ เครื่องแจ้งหยุด/ซ่อม: ${esc(pkg.down.down_reason || '')}<br><span class="small">ถ้าเครื่องเดินแล้วและส่งผลตรวจ → ระบบปลดสถานะหยุดเป็น <b>เดินเครื่องอัตโนมัติ</b> ในชื่อคุณ (เวลาเดินอ้างอิงเริ่มกะของคุณ) และนับเป็นรอบของกะนี้</span></div>` : ''}
      ${pkg.tpm && pkg.tpm.length ? `<div class="m-tpmnote">📅 ส่งผลตรวจนี้ = บันทึกทำงานแผน TPM${pkg.tpm.map(t => `<div><b>${esc(t.task)}</b> <span class="badge ${t.state === 'overdue' ? 'b-ng' : 'b-warn'}">${esc(t.state_th)}</span> <span class="small">กำหนด ${esc(fmtDate(t.next_due))}${t.items && t.items.length ? ` · ต้องตรวจ ${t.items.length} หัวข้อที่กำหนดให้ครบ` : ''}</span></div>`).join('')}</div>` : ''}
      ${pkg.returned ? `<div class="m-note">ถูกตีกลับ: ${esc(pkg.returned.approval_note || '')}</div>` : ''}
      ${draft.error ? `<div class="m-err">ส่งไม่ผ่าน:<br>${draft.error.map(esc).join('<br>')}</div>` : ''}
      ${draft.queued_at ? `<div class="m-warnbox"><b>📤 รอบนี้กดส่งไปแล้วเมื่อ ${fmt(draft.queued_at)} — ยังรอส่งถึงระบบ</b><br><span class="small">ไม่ต้องกรอกซ้ำ ระบบส่งให้อัตโนมัติเมื่อมีสัญญาณ · ถ้ากรอกใหม่และส่ง จะใช้ผลล่าสุด</span></div>` : ''}
      ${histHtml(pkg.machine)}
      ${pkg.form.equipment_id ? `<a class="m-reportbtn" href="${U('/m/report')}?eq=${pkg.form.equipment_id}">⚠ แจ้งปัญหาที่พบ (นอกเช็คชีท)</a>` : ''}
      ${pkg.form.equipment_id ? `<div class="m-fillbtns">${(() => { const j = esc(JSON.stringify({ id: pkg.form.equipment_id, code: f.eq_code || '', name: f.eq_name || '',
        reason: (pkg.down || {}).down_reason || '', since: (pkg.down || {}).down_since || '' }));
        return pkg.down ? `<button type="button" class="m-eqbtn run" data-eqrun="${j}">✅ แจ้งเครื่องกลับมาเดินแล้ว</button>`
          : `<button type="button" class="m-eqbtn" data-eqdown="${j}">⛔ แจ้งเครื่องหยุด / PM (ไม่ต้องตรวจรอบนี้)</button>`; })()}</div>` : ''}
      <button type="button" class="linkbtn m-chreq-btn" data-chreq="" style="margin-top:6px">✏️ แจ้งแก้ไขแบบฟอร์ม (หัวข้อไม่ตรงหน้างาน / ขอเพิ่มหัวข้อ / ข้อมูลผิด)</button>
      <div style="margin-top:6px">${autoBtn()}${OFFMODE ? ' <a class="m-autoadv" href="#pick"><i class=ei-phoneoff aria-hidden=true></i> รายการเครื่อง</a>' : ''}</div></div>`;
    computeVisible();
    const secs = sections();
    const points = secs.length > 1 || (secs[0] && secs[0].name);
    if (points) {
      html += '<nav class="m-pointnav" id="pointnav">' + secs.filter(s => items.some(it => it._show && (it.section || '') === s.name))
        .map(s => `<a href="#pt-${s.no}" data-goto="${s.no}" class="m-pchip" id="pc-${s.no}"><b>${s.no}</b>${esc(s.name || 'ทั่วไป')}<i></i></a>`).join('') + '</nav>';
    }
    let sec = null, shown = 0;
    items.forEach((it, i) => {
      if (!it._show) return;
      if ((it.section || '') !== sec) {
        sec = it.section || '';
        const s = secs.find(x => x.name === sec) || { no: '', name: sec, hint: '' };
        html += points
          ? `<div class="m-point${scanned(sec) ? '' : ' need-scan'}" id="pt-${s.no}"><span class="m-point-no">${s.no}</span><div class="m-point-body">
               <div class="m-point-name">${esc(s.name || 'ทั่วไป')}</div>${s.hint ? `<div class="m-point-hint">📍 ${esc(s.hint)}</div>` : ''}
               ${needScan() && scanned(sec) ? `<div class="m-point-ok">✓ ยืนยันที่จุดแล้ว ${fmt(draft.scans[sec].at)}</div>` : ''}</div>
               <span class="m-point-prog" id="pp-${s.no}"></span></div>
             ${scanned(sec) ? '' : `<div class="m-scanbox" data-sec="${esc(sec)}">
               <div class="small"><b>ไปที่จุดนี้แล้วสแกน QR ที่ติดไว้</b> ด้วยกล้องมือถือ — หรือพิมพ์รหัสใต้ QR</div>
               <div class="m-scanrow"><input class="m-input" data-ptcode placeholder="รหัส 6 ตัว" maxlength="12" autocomplete="off" autocapitalize="characters">
                 <button type="button" class="m-btn m-btn-primary" data-ptok>ยืนยัน</button>
                 ${canCamScan ? '<button type="button" class="m-btn" data-ptcam aria-label="สแกนด้วยกล้อง">📷</button>' : ''}</div>
               <div class="m-msg" data-ptmsg></div></div>`}`
          : `<h2 class="m-h">${esc(sec || 'ทั่วไป')}</h2>${scanned(sec) ? '' : `<button type="button" class="m-scanbanner" data-openscan>
               <span>📷</span><span><b>สแกน QR ที่จุดตรวจก่อนเริ่ม</b><small>แตะเพื่อสแกน หรือพิมพ์รหัสใต้ QR</small></span></button>`}`;
      }
      html += renderItem(it, i); shown++;
    });
    const later = items.filter(it => !it._show);
    if (!shown) {
      html += `<div class="m-card m-allset"><div class="m-done-ic">✓</div><strong>ทุกหัวข้อตรวจครบแล้วสำหรับช่วงเวลานี้</strong>
        ${later.length ? `<div class="small muted">หัวข้อถัดไปถึงเวลาตรวจ ${fmt(ECS.nowTs(new Date(Math.min(...later.map(it => it._next ? it._next.getTime() : Infinity)))), true)}
          · กด "ตรวจเพิ่ม" ด้านล่างถ้าต้องการตรวจก่อนเวลา</div>` : ''}</div>`;
    }
    if (later.length) {
      html += `<details class="m-card m-later"${shown ? '' : ' open'}><summary>ยังไม่ถึงเวลาตรวจ <b>${later.length}</b> หัวข้อ
          <span class="small muted">(ตรวจไปแล้วในช่วงนี้)</span></summary>` +
        later.map(it => {
          const p = pkg.previous[it.item_key] || {};
          return `<div class="m-later-row"><div><div class="m-later-name">${pkg.items.indexOf(it) + 1}. ${esc(it.name)}</div>
            <div class="small muted">⏱ ${esc(freqLabel(it))} · ตรวจล่าสุด ${fmt(p.at, true)}${p.value_text ? ' (' + esc(p.value_text) + ')' : ''}
            · ครั้งถัดไป ${it._next ? fmt(ECS.nowTs(it._next), true) : '–'}</div></div>
            <button type="button" class="m-btn m-btn-sm" data-extra="${esc(it.item_key)}">ตรวจเพิ่ม</button></div>`;
        }).join('') + '</details>';
    }
    html += `<div class="m-card"><label class="small muted" for="note">หมายเหตุรวม (ถ้ามี)</label>
      <textarea id="note" class="m-input" rows="2">${esc(draft.note || '')}</textarea></div>
      <div class="m-bottom-space"></div>
      <div class="m-submitbar"><div class="m-progress"><div id="pbar"></div></div>
        <div class="m-submitrow"><div id="sumtxt" class="small"></div>
        <button type="button" class="m-btn m-btn-primary m-send" id="btnSubmit">${sendLabel('ส่งผลตรวจ')}</button></div></div>`;
    app.innerHTML = html;
    updateSummary();
  }

  let rendering = false;
  function rerenderItem(idx) {
    const el = document.getElementById('it-' + idx);
    if (!el || !el.isConnected || rendering) return;   // กันวาดซ้อน (blur → change ระหว่างวาดใหม่)
    rendering = true;
    try { rerenderInner(el, idx); } finally { rendering = false; }
  }
  function rerenderInner(el, idx) {
    const focusedNum = document.activeElement && el.contains(document.activeElement) ? document.activeElement : null;
    const caret = focusedNum && focusedNum.selectionStart;
    const which = focusedNum ? (focusedNum.hasAttribute('data-num') ? '[data-num]' : focusedNum.hasAttribute('data-remark') ? '[data-remark]' : focusedNum.hasAttribute('data-text') ? '[data-text]' : null) : null;
    el.outerHTML = renderItem(pkg.items[idx], idx);
    if (which) { const n = document.getElementById('it-' + idx).querySelector(which); if (n) { n.focus(); try { n.setSelectionRange(caret, caret); } catch (e) { /* */ } } }
    updateSummary();
  }

  // v0.95 ข้อมูลสรุปของแบบร่าง — หน้างานของฉันใช้แสดง “กรอกค้างไว้ n/m ข้อ · ทำต่อ”
  function draftMeta() {
    const items = visible(), req = items.filter(it => it.required && it._due);
    const val = it => evaluate(it, (draft.answers[it.item_key] || {}).value).j;
    return { form_id: pkg.form.id, round_id: draft.round ? draft.round.id : null, form_name: pkg.form.name,
      eq_code: pkg.form.eq_code || '', area: pkg.form.area_name || pkg.form.factory_name || '',
      n_req: req.length, n_done: req.filter(it => val(it) !== 'na').length, ng: items.filter(it => val(it) === 'ng').length,
      due_at: draft.round ? draft.round.due_at || null : null, deadline_at: draft.round ? draft.round.deadline_at || null : null };
  }
  // v0.95 เปิดแบบร่างที่กรอกค้าง → เลื่อนไปข้อแรกที่ยังไม่กรอก
  function resumePoint() {
    const items = visible(), req = items.filter(it => it.required && it._due);
    const val = it => evaluate(it, (draft.answers[it.item_key] || {}).value).j;
    const done = req.filter(it => val(it) !== 'na').length;
    if (!done || done >= req.length) return null;
    const first = req.find(it => val(it) === 'na');
    return { idx: pkg.items.indexOf(first), done, total: req.length, name: first.name };
  }
  function goResume() {
    const r = resumePoint(); if (!r) return;
    const el = document.getElementById('it-' + r.idx); if (!el) return;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.classList.add('m-resume');
    setTimeout(() => el.classList.remove('m-resume'), 2600);
    toast(`▶ กรอกต่อจากที่ค้างไว้ · กรอกแล้ว ${r.done}/${r.total} ข้อ`, true);
  }

  function updateSummary() {
    syncCalcs(true);
    const items = visible();
    const req = items.filter(it => it.required && it._due);
    const done = req.filter(it => evaluate(it, (draft.answers[it.item_key] || {}).value).j !== 'na').length;
    const ng = items.filter(it => evaluate(it, (draft.answers[it.item_key] || {}).value).j === 'ng').length;
    const bad = items.map((it, i) => [i, problems(it)]).filter(x => x[1].length);
    const pct = req.length ? Math.round(100 * done / req.length) : 100;
    const bar = document.getElementById('pbar'); if (bar) bar.style.width = pct + '%';
    const s = document.getElementById('sumtxt');
    if (s) s.innerHTML = `กรอกแล้ว <strong>${done}/${req.length}</strong>` + (ng ? ` · <span style="color:var(--ng);font-weight:700">NG ${ng}</span>` : '') +
      (bad.length ? ` · <span class="muted">ต้องแก้ ${bad.length} ข้อ</span>` : '');
    // ความคืบหน้ารายจุดตรวจ
    sections().forEach(sc => {
      const its = items.filter(it => (it.section || '') === sc.name); if (!its.length) return;
      const need = its.filter(it => it.required && it._due);
      const got = need.filter(it => evaluate(it, (draft.answers[it.item_key] || {}).value).j !== 'na').length;
      const hasNg = its.some(it => evaluate(it, (draft.answers[it.item_key] || {}).value).j === 'ng');
      const st = hasNg ? 'ng' : got === need.length ? 'done' : got ? 'part' : '';
      const pp = document.getElementById('pp-' + sc.no);
      if (pp) { pp.textContent = (st === 'done' ? '✓ ' : '') + got + '/' + need.length; pp.className = 'm-point-prog ' + st; }
      const pc = document.getElementById('pc-' + sc.no);
      if (pc) { pc.className = 'm-pchip ' + st; pc.querySelector('i').textContent = hasNg ? '!' : st === 'done' ? '✓' : got + '/' + need.length; }
    });
    const b = document.getElementById('btnSubmit');
    if (b && !sending) {
      b.classList.toggle('has-ng', ng > 0); b.classList.toggle('incomplete', bad.length > 0);
      b.innerHTML = sendLabel(bad.length ? `ตรวจให้ครบ (${bad.length})` : (ng ? `ส่งผล (NG ${ng})` : 'ส่งผลตรวจ'));
    }
  }
  // v0.99.10 ปุ่มส่ง: ไอคอนเครื่องบินกระดาษ + ข้อความ
  function sendLabel(text) { return (window.SendFx ? SendFx.PLANE : '') + `<span>${esc(text)}</span>`; }

  // ── เหตุการณ์ ──
  function itemOf(el) {
    const sec = el.closest('.m-item'); if (!sec) return null;
    const idx = Number(sec.id.slice(3));
    return { idx, it: pkg.items[idx] };
  }
  app.addEventListener('click', async e => {
    if (e.target.closest('[data-eqscan]')) { e.preventDefault(); scanConfirm(); return; }   // v0.51
    const sv = e.target.closest('[data-fixval],[data-okval],[data-scadaok]');     // v0.49
    if (sv) {
      e.preventDefault();
      const x = itemOf(sv); if (!x) return;
      const a = ans(x.it.item_key);
      if (sv.hasAttribute('data-fixval')) { a.value = sv.dataset.fixval; if (a.scada != null) a.src = num(a.value) === a.scada ? 'scada' : ''; }
      else if (sv.hasAttribute('data-okval')) a.okVal = String(a.value || '').trim();
      else a.scadaOk = true;
      saveNow(); rerenderItem(x.idx); updateSummary();
      if (AUTO && !problems(x.it).length) advance(x.idx);
      return;
    }
    const go = e.target.closest('[data-goto]');
    if (go) {
      e.preventDefault();
      const el = document.getElementById('pt-' + go.dataset.goto);
      if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 64, behavior: 'smooth' });
      return;
    }
    const aa = e.target.closest('[data-autoadv]');
    if (aa) { e.preventDefault(); AUTO = !AUTO; try { localStorage.setItem('m_autoadv', AUTO ? '1' : '0'); } catch (x) { /* */ }
      aa.outerHTML = autoBtn(); return; }
    const cr = e.target.closest('[data-chreq]');
    if (cr) { e.preventDefault(); chreqPopup(cr.dataset.chreq); return; }
    const lk = e.target.closest('.m-item.locked');
    if (lk) { const x = itemOf(lk); if (x) scanPopup(x.it.section || ''); return; }
    if (e.target.closest('[data-openscan]')) { const p = pendingPoints()[0]; if (p) scanPopup(p.name); return; }
    const t = e.target.closest('button'); if (!t) return;
    if (t.id === 'btnSubmit') return submit();
    const sbox = t.closest('.m-scanbox');
    if (sbox && t.hasAttribute('data-ptok')) return tryPoint(sbox, sbox.querySelector('[data-ptcode]').value);
    if (sbox && t.hasAttribute('data-ptcam')) { const v = await camScan(); if (v) tryPoint(sbox, v); return; }
    if (t.dataset.extra) {
      draft.extra = [...new Set((draft.extra || []).concat(t.dataset.extra))];
      await saveNow(); renderAll();
      const idx = pkg.items.findIndex(it => it.item_key === t.dataset.extra);
      const el = document.getElementById('it-' + idx); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    const x = itemOf(t); if (!x) return;
    const a = ans(x.it.item_key);
    if (t.dataset.set != null) { a.value = a.value === t.dataset.set ? '' : t.dataset.set; await saveNow(); rerenderItem(x.idx);
      if (evaluate(x.it, a.value).j === 'ng') { const r = document.querySelector(`#it-${x.idx} [data-remark]`); if (r) r.focus(); }
      else if (a.value) advance(x.idx); }
    else if (t.hasAttribute('data-addremark')) { a.showRemark = true; rerenderItem(x.idx); const r = document.querySelector(`#it-${x.idx} [data-remark]`); if (r) r.focus(); }
    else if (t.hasAttribute('data-photo')) { photoTarget = x; camera.value = ''; camera.click(); }
    else if (t.hasAttribute('data-gallery')) { photoTarget = x; gallery.value = ''; gallery.click(); }
    else if (t.dataset.delphoto) {
      if (!confirm('ลบรูปนี้?')) return;
      a.photos = a.photos.filter(p => p !== t.dataset.delphoto); await saveNow(); await ECS.photos.del(t.dataset.delphoto); rerenderItem(x.idx);
    }
  });
  app.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.hasAttribute('data-ptcode')) { e.preventDefault(); tryPoint(e.target.closest('.m-scanbox'), e.target.value); }
    if (e.key === 'Enter' && e.target.hasAttribute('data-num')) {           // v0.40 ปุ่ม "ถัดไป" ที่แป้นตัวเลข
      e.preventDefault();
      const x = itemOf(e.target); if (!x) return;
      const j = evaluate(x.it, (draft.answers[x.it.item_key] || {}).value).j;
      if (j === 'ng') { const r = document.querySelector(`#it-${x.idx} [data-remark]`); if (r) r.focus(); return; }
      if (j === 'invalid' || j === 'na') return;
      if (AUTO) advance(x.idx); else e.target.blur();
    }
  });
  app.addEventListener('input', e => {
    const x = itemOf(e.target);
    if (e.target.id === 'note') { draft.note = e.target.value; save(); return; }
    if (!x) return;
    const a = ans(x.it.item_key);
    if (e.target.hasAttribute('data-num') || e.target.hasAttribute('data-text')) {
      a.value = e.target.value;
      if (a.scada != null) {                     // v0.45 แก้ค่าที่เติมจาก SCADA → ไม่นับเป็นค่าจาก SCADA
        const was = a.src; a.src = num(a.value) === a.scada ? 'scada' : '';
        const chip = e.target.closest('.m-item').querySelector('.m-scada');
        if (was !== a.src && chip) chip.outerHTML = scadaChip(a);
      }
      save();
      const before = e.target.closest('.m-item').className;
      const r = evaluate(x.it, a.value);
      const sec = e.target.closest('.m-item');
      // อัปเดตเฉพาะสี/ข้อความ ไม่วาดใหม่ทั้งหัวข้อ (แป้นพิมพ์จะได้ไม่หุบ)
      sec.className = 'm-item j-' + r.j;
      sec.querySelector('.m-msg').textContent = r.msg || (r.j === 'invalid' ? 'ต้องเป็นตัวเลข' : '');
      updateSpark(sec, x.it, a.value);
      if ((before.includes('j-ng')) !== (r.j === 'ng')) { rerenderItem(x.idx); return; }
      updateSummary();
    } else if (e.target.hasAttribute('data-remark')) {
      a.remark = e.target.value; e.target.classList.toggle('need', !a.remark.trim() && evaluate(x.it, a.value).j === 'ng'); save(); updateSummary();
    }
  });
  app.addEventListener('change', e => {
    // ออกจากช่องตัวเลขแล้ววาดใหม่ เพื่อแสดงป้าย ปกติ/เตือน (ไม่ทำระหว่างพิมพ์ แป้นพิมพ์จะได้ไม่หุบ)
    const x = itemOf(e.target);
    if (x && e.target.hasAttribute('data-num')) {
      const next = document.activeElement;
      rerenderItem(x.idx);
      if (next && next !== document.body && document.contains(next)) next.focus();
    }
  });

  async function addPhotos(input) {
    const files = [...(input.files || [])]; if (!files.length || !photoTarget) return;
    const { idx, it } = photoTarget; photoTarget = null;
    const a = ans(it.item_key);
    const room = 5 - (a.photos || []).length;
    if (room <= 0) { alert('แนบได้ไม่เกิน 5 รูปต่อหัวข้อ'); return; }
    if (files.length > room) alert('แนบได้อีก ' + room + ' รูป — ใช้ ' + room + ' รูปแรก');
    for (const file of files.slice(0, room)) {
      try {
        const blob = await ECS.resizeImage(file);
        const pid = 'p' + ECS.uuid().replace(/-/g, '').slice(0, 16);
        await ECS.photos.put(pid, { blob, created_at: ECS.nowTs() });
        thumbs[pid] = URL.createObjectURL(blob);
        a.photos = (a.photos || []).concat(pid);
      } catch (e) { alert('บันทึกรูปไม่สำเร็จ: ' + e.message); }
    }
    await saveNow(); rerenderItem(idx);
  }
  camera.addEventListener('change', () => addPhotos(camera));
  gallery.addEventListener('change', () => addPhotos(gallery));

  // ── ส่ง ──
  async function submit() {
    const bad = pkg.items.map((it, i) => [i, it._show ? problems(it) : []]).filter(x => x[1].length);
    if (bad.length) {
      const [i, msgs] = bad[0];
      if (locked(pkg.items[i])) return scanPopup(pkg.items[i].section || '', 'ยังมีจุดที่ไม่ได้สแกน QR — สแกนก่อนจึงจะกรอกและส่งได้');
      const el = document.getElementById('it-' + i);
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('shake'); setTimeout(() => el.classList.remove('shake'), 600);
      el.querySelector('.m-msg').textContent = msgs.join(' · ');
      return;
    }
    return reviewSheet();                                // v0.49 ตรวจทานก่อนส่ง
  }

  // v0.49 หน้าสรุปก่อนส่ง: ปกติ / เตือน / NG + รายการที่ผิดปกติ (แตะเพื่อกลับไปแก้)
  function reviewSheet() {
    closePopup();
    const vis = visible(), rows = vis.map(it => ({ it, idx: pkg.items.indexOf(it), a: draft.answers[it.item_key] || {} }))
      .map(x => Object.assign(x, { r: evaluate(x.it, x.a.value) }));
    const n = j => rows.filter(x => x.r.j === j).length;
    const bad = rows.filter(x => x.r.j === 'ng' || x.r.j === 'warn');
    const scada = rows.filter(x => x.a.src === 'scada').length, blank = rows.filter(x => x.r.j === 'na').length;
    const f = pkg.form, rnd = draft.round;
    const wrap = document.createElement('div');
    wrap.className = 'm-modal';
    wrap.innerHTML = `<div class="m-sheet m-review" role="dialog" aria-modal="true" aria-labelledby="rvTitle">
      <h2 id="rvTitle">ตรวจทานก่อนส่ง</h2>
      <p class="m-sheet-sub"><b>${esc(f.eq_code || f.name)}</b>${rnd && rnd.due_at ? ` · รอบ ${fmt(rnd.due_at)}` : ' · ตรวจนอกรอบ'}</p>
      <div class="m-rv-tiles"><div class="ok"><b>${n('ok')}</b><span>ปกติ</span></div><div class="warn"><b>${n('warn')}</b><span>เตือน</span></div>
        <div class="ng"><b>${n('ng')}</b><span>NG</span></div>${blank ? `<div><b>${blank}</b><span>ไม่ได้กรอก</span></div>` : ''}</div>
      ${bad.length ? `<div class="m-rv-list">${bad.map(x => `<button type="button" class="m-rv-row ${x.r.j}" data-rvgo="${x.idx}">
          <span class="badge ${J[x.r.j][1]}">${J[x.r.j][0]}</span><span class="nm">${esc(x.it.name)}</span>
          <b>${esc(String(x.a.value))}${x.it.unit && num(x.a.value) != null ? ' ' + esc(x.it.unit) : ''}</b>
          <span class="why small">${esc(x.r.msg || '')}${x.a.remark ? ' · ' + esc(x.a.remark) : ''}</span></button>`).join('')}</div>`
        : '<div class="m-rv-allok">✓ ทุกหัวข้อปกติ</div>'}
      ${scada ? `<div class="small muted" style="margin-top:8px">📡 ค่าจาก SCADA ที่ยืนยันตรงกับหน้าปัด ${scada} หัวข้อ</div>` : ''}
      <div style="margin-top:8px">${roundCard().replace('id="rcard"', '')}${draft.eq_bad ? roundWarn() : ''}</div>
      ${window.SendFx ? `<div style="margin-top:14px">${SendFx.html('ส่งผลตรวจ', 'data-rvsend')}</div>`
        : '<button type="button" class="m-btn m-btn-primary m-btn-block m-btn-lg" data-rvsend style="margin-top:14px">✓ ส่งผลตรวจ</button>'}
      <button type="button" class="m-btn m-btn-block" data-rvback style="margin-top:8px">กลับไปแก้</button></div>`;
    document.body.appendChild(wrap); document.body.classList.add('m-modal-open');
    wrap.addEventListener('click', e => {
      if (sending) return;                               // กำลังส่ง → ปิด/ย้อนกลับไม่ได้จนกว่าจะรู้ผลจริง
      const go = e.target.closest('[data-rvgo]');
      if (e.target === wrap || e.target.closest('[data-rvback]')) return closePopup();
      if (go) {
        closePopup();
        const el = document.getElementById('it-' + go.dataset.rvgo);
        if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('shake'); setTimeout(() => el.classList.remove('shake'), 600); }
        return;
      }
      const sb = e.target.closest('[data-rvsend]');
      if (sb) { if (window.SendFx && sb.classList.contains('sx')) doSubmit(sb); else { closePopup(); doSubmit(); } }
    });
  }

  // fx = ปุ่มเครื่องบินในหน้าตรวจทาน: ภาพเคลื่อนไหวระหว่างส่ง แล้วแสดงผลจริงจากเซิร์ฟเวอร์ก่อนไปหน้าสรุป
  async function doSubmit(fx) {
    if (sending) return;
    sending = true;
    const btn = document.getElementById('btnSubmit'); if (btn) { btn.disabled = true; btn.innerHTML = sendLabel('กำลังส่ง…'); }
    const flying = fx ? SendFx.launch(fx) : Promise.resolve();
    const finished = ECS.nowTs();
    const photoIds = [];
    const answers = visible().map(it => {
      const a = draft.answers[it.item_key] || {};
      (a.photos || []).forEach(p => photoIds.push(p));
      return { item_key: it.item_key, value: a.value || '', remark: a.remark || '', photos: a.photos || [], src: a.src || '' };
    });
    const item = {
      client_uuid: draft.client_uuid, created_at: finished, form_name: pkg.form.name, photoIds, status: 'queued',
      queued_offline: !navigator.onLine,
      payload: { client_uuid: draft.client_uuid, form_id: pkg.form.id, form_version_id: pkg.version.id,
        round_id: draft.round ? draft.round.id : null, scanned_at: draft.scanned_at, finished_at: finished,
        note: draft.note || '', answers, route_id: P.rt ? Number(P.rt) : null,
        point_scans: Object.entries(draft.scans || {}).map(([section, v]) => ({ section, code: v.code, at: v.at })),
        client_info: (navigator.onLine ? 'online' : 'offline') + ' · ' + navigator.userAgent.slice(0, 200) },
    };
    submitted = true;               // ส่งแล้ว (หรืออยู่ในคิว) → ไม่ต้องหยุดนับตอนออกจากหน้า เซิร์ฟเวอร์ปิดให้ตอนรับผล
    await ECS.outbox.put(item.client_uuid, item);
    await ECS.drafts.del(draftKey);
    await rememberDone(answers, finished);
    let res = await ECS.sendOne(item);
    if (res.state === 'retry') res = await ECS.sendOne(item);      // CSRF หมดอายุ → ขอใหม่แล้วส่งอีกครั้ง
    await flying;
    if (res.state === 'sent') {
      if (fx) await SendFx.land(fx, 'sent', res.result && res.result.duplicate ? 'ถึงระบบแล้ว (ส่งซ้ำ)' : 'ส่งถึงระบบแล้ว');
      closePopup(); sending = false;
      return done(res.result, false, item);
    }
    if (res.state === 'rejected') {
      if (fx) await SendFx.land(fx, 'error', 'ส่งไม่ผ่าน — ต้องแก้ไข');
      closePopup(); sending = false;
      // เซิร์ฟเวอร์ไม่รับ → เอากลับมาเป็นแบบร่างให้แก้ต่อ
      await ECS.outbox.del(item.client_uuid);
      submitted = false;
      draft.error = res.errors; await ECS.drafts.put(draftKey, draft);
      renderAll(); window.scrollTo(0, 0); return;
    }
    if (fx) await SendFx.land(fx, 'queued', res.state === 'login' ? 'เก็บในเครื่อง · รอเข้าสู่ระบบ' : 'เก็บในเครื่อง · รอสัญญาณ');
    closePopup(); sending = false;
    done(null, res.state === 'login' ? 'login' : 'offline', item);
    ECS.sync();
  }

  // v0.99.10 ใบรับผลตรวจ: บอกช่างตามจริงว่าผลตรวจถึงระบบแล้วหรือยัง (ยืนยันซ้ำจากฐานข้อมูล · รอส่ง → อัปเดตเองเมื่อส่งได้)
  function receiptHtml(result, queued, item) {
    const f = pkg.form;
    const steps = (a, b, c) => `<div class="m-receipt-steps"><span class="on">① บันทึกในเครื่อง</span>
      <span class="${b ? 'on' : ''}" data-rs2>${b ? '② ส่งถึงระบบ' : '② รอส่ง'}</span><span class="${c ? 'on' : ''}" data-rs3>${a}</span></div>`;
    if (!queued && result) {
      return `<div class="m-receipt ok" id="rcpt" data-uuid="${esc(item ? item.client_uuid : '')}"><div class="m-receipt-hd"><span class="dot"></span>
        <span>ระบบรับผลตรวจแล้ว</span></div>
        <dl><dt>เลขที่รับ</dt><dd>#${esc(result.id)}</dd><dt>ระบบรับเมื่อ</dt><dd>${result.received_at ? fmt(result.received_at, true) : '–'}</dd>
        <dt>เครื่อง</dt><dd>${esc(f.eq_code || f.name)}</dd><dt>ข้อมูล</dt><dd data-rcn>${visible().length} หัวข้อ</dd></dl>
        ${steps('③ กำลังตรวจสอบซ้ำ…', true, false)}</div>`;
    }
    return `<div class="m-receipt wait" id="rcpt" data-uuid="${esc(item ? item.client_uuid : '')}"><div class="m-receipt-hd"><span class="dot"></span>
      <span data-rch>ยังไม่ถึงระบบ — เก็บอยู่ในเครื่องนี้</span></div>
      <dl><dt>เครื่อง</dt><dd>${esc(f.eq_code || f.name)}</dd><dt>กดส่งเมื่อ</dt><dd>${item ? fmt(item.created_at, true) : '–'}</dd>
      <dt>สถานะ</dt><dd data-rcs>${queued === 'login' ? 'รอเข้าสู่ระบบใหม่' : 'รอสัญญาณ — ส่งให้อัตโนมัติ'}</dd></dl>
      ${steps('③ ยืนยันในระบบ', false, false)}</div>`;
  }

  async function verifyReceipt() {
    const box = document.getElementById('rcpt'); if (!box || !box.dataset.uuid) return;
    const uuid = box.dataset.uuid, s3 = box.querySelector('[data-rs3]');
    let r = null, net = true;
    try {
      const resp = await fetch(U('/api/m/receipt/' + encodeURIComponent(uuid)), { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
      if (resp.ok) r = await resp.json(); else if (resp.status !== 404) net = false;
    } catch (e) { net = false; }
    if (!document.body.contains(box)) return;
    if (r && r.found) {
      s3.classList.add('on'); s3.textContent = '③ ยืนยันในฐานข้อมูลแล้ว ✓';
      const n = box.querySelector('[data-rcn]'); if (n) n.textContent = `${r.answers} หัวข้อ${r.ng_count ? ` · NG ${r.ng_count}` : ''}`;
    } else if (net) {
      box.className = 'm-receipt err'; s3.textContent = '③ ไม่พบในระบบ — แจ้งหัวหน้างาน';
    } else s3.textContent = '③ ตรวจสอบซ้ำไม่ได้ตอนนี้ (สัญญาณหลุด) — ระบบรับแล้วตามเลขที่รับ';
  }

  // ผลตรวจที่รอส่ง: ติดตามคิว → ส่งได้เมื่อไร เปลี่ยนเป็น "ถึงระบบแล้ว" พร้อมเลขที่รับ / ส่งไม่ผ่าน → ลิงก์แก้ไข
  function watchQueued() {
    const box = document.getElementById('rcpt'); if (!box || !box.dataset.uuid) return;
    const uuid = box.dataset.uuid;
    let timer = null;
    const check = async () => {
      if (!document.body.contains(box)) { document.removeEventListener('ecs:sync', check); clearInterval(timer); return; }
      const it = await ECS.outbox.get(uuid);
      if (it && it.status === 'rejected') {
        box.className = 'm-receipt err';
        box.querySelector('[data-rch]').textContent = 'ส่งไม่ผ่าน — ต้องแก้ไข';
        box.querySelector('[data-rcs]').innerHTML = `<a href="${U('/m/fill')}#o=${encodeURIComponent(uuid)}">แตะเพื่อแก้ไขแล้วส่งใหม่</a>`;
        return;
      }
      if (it) return;                                   // ยังอยู่ในคิว
      let r = null;
      try { const resp = await fetch(U('/api/m/receipt/' + encodeURIComponent(uuid)), { credentials: 'same-origin', cache: 'no-store' }); if (resp.ok) r = await resp.json(); } catch (e) { /* */ }
      if (!r || !r.found || !document.body.contains(box)) return;
      document.removeEventListener('ecs:sync', check); clearInterval(timer);
      box.className = 'm-receipt ok';
      box.querySelector('[data-rch]').textContent = 'ส่งถึงระบบแล้ว';
      box.querySelector('dl').innerHTML = `<dt>เลขที่รับ</dt><dd>#${esc(r.id)}</dd><dt>ระบบรับเมื่อ</dt><dd>${fmt(r.received_at, true)}</dd>
        <dt>เครื่อง</dt><dd>${esc(r.eq_code || r.form_name)}</dd><dt>ข้อมูล</dt><dd>${r.answers} หัวข้อ${r.ng_count ? ` · NG ${r.ng_count}` : ''}</dd>`;
      const s2 = box.querySelector('[data-rs2]'), s3 = box.querySelector('[data-rs3]');
      s2.classList.add('on'); s2.textContent = '② ส่งถึงระบบ'; s3.classList.add('on'); s3.textContent = '③ ยืนยันในฐานข้อมูลแล้ว ✓';
      const h = document.querySelector('.m-done h1'); if (h) h.textContent = 'ส่งผลตรวจถึงระบบแล้ว';
      const d = document.querySelector('.m-done'); if (d) { d.classList.remove('warn'); d.classList.add('ok'); const ic = d.querySelector('.m-done-ic'); if (ic) ic.textContent = '✓'; }
    };
    document.addEventListener('ecs:sync', check);
    timer = setInterval(() => { if (navigator.onLine) ECS.sync(); else check(); }, 20000);
  }

  // จำว่าหัวข้อไหนตรวจแล้ว (ใช้ตอนออฟไลน์: รอบถัดไปในกะ/วันเดียวกันจะไม่ขึ้นหัวข้อที่ตรวจแล้วซ้ำ)
  async function rememberDone(answers, finished) {
    answers.forEach(a => {
      if (!String(a.value || '').trim()) return;
      const n = num(a.value);
      pkg.previous[a.item_key] = { value_text: a.value, value_num: Number.isFinite(n) ? n : null, judgement: '', at: finished };
      const it = pkg.items.find(i => i.item_key === a.item_key);
      if (it && it.item_type === 'number' && Number.isFinite(n)) {
        pkg.history = pkg.history || {};
        const h = (pkg.history[a.item_key] || []).concat([{ v: n, j: evaluate(it, a.value).j, at: finished }]);
        pkg.history[a.item_key] = h.slice(-5);
      }
    });
    try {
      const copy = Object.assign({}, pkg, { items: pkg.items.map(it => { const c = Object.assign({}, it); delete c._due; delete c._show; delete c._next; return c; }) });
      delete copy._cached;
      await ECS.kv.put('pkg:' + pkg.form.id, copy);
    } catch (e) { /* ไม่สำคัญ */ }
  }

  function done(result, queued, item) {
    Object.values(thumbs).forEach(u => URL.revokeObjectURL(u));
    const ng = result ? result.ng_count : visible().filter(it => evaluate(it, (draft.answers[it.item_key] || {}).value).j === 'ng').length;
    let title, sub, cls;
    if (!queued) { title = ng ? `ส่งแล้ว — พบ NG ${ng} หัวข้อ` : 'ส่งผลตรวจเรียบร้อย'; sub = ng ? 'หัวหน้างานจะได้รับรายการเพื่อพิจารณา' : 'ขอบคุณครับ'; cls = ng ? 'ng' : 'ok'; }
    else if (queued === 'login') { title = 'บันทึกไว้ในเครื่องแล้ว'; sub = 'ต้องเข้าสู่ระบบใหม่ก่อน ระบบจึงจะส่งได้'; cls = 'warn'; }
    else { title = 'บันทึกไว้ในเครื่องแล้ว'; sub = 'ยังไม่มีสัญญาณ — ระบบจะส่งให้อัตโนมัติเมื่อสัญญาณกลับมา ไม่ต้องกรอกใหม่'; cls = 'warn'; }
    if (result && result.cmms_wo) sub += ` · เปิดใบแจ้งซ่อม ${esc(result.cmms_wo)} ใน UT-CMMS ให้แล้ว`;
    if (result && result.status_minutes != null) sub += `<br>⏱ ปิดสถานะ "ตรวจเช็ค" ใน UT-CMMS แล้ว (${result.status_minutes} นาที)`;
    if (result && result.tpm && result.tpm.length) sub += `<br>📅 บันทึกทำงานแผน TPM แล้ว: ${result.tpm.map(esc).join(', ')} (รอหัวหน้ายืนยัน)`;
    const warns = result && result.warnings && result.warnings.length ? `<div class="m-note">${result.warnings.map(esc).join('<br>')}</div>` : '';
    if (result && result.auto_running) sub += `<br><span class="badge b-ok">▶ ${esc(result.auto_running.code)} ปลดสถานะหยุด → เดินเครื่องแล้ว (ตั้งแต่ ${fmt(result.auto_running.at, true)} · ${esc(result.auto_running.shift)})</span>`;
    if (result && !result.duplicate) {                  // v0.53 บอกผลการนับรอบ
      const rs = result.round_status, rd = result.round_due ? fmt(result.round_due) : '';
      sub += rs === 'done_on_time' ? `<br><span class="badge b-ok">✓ นับเป็นรอบ ${rd} · ตรวจตรงเวลา</span>`
        : rs === 'done_late' ? `<br><span class="badge b-warn">นับเป็นรอบ ${rd} · ตรวจล่าช้า</span>`
        : '<br><span class="badge b-none">บันทึกเป็นตรวจนอกรอบ (ไม่นับรอบ)</span>';
    }
    app.innerHTML = `<div class="m-done ${cls}"><div class="m-done-ic">${cls === 'ok' ? '✓' : cls === 'ng' ? '!' : '⇅'}</div>
      <h1>${title}</h1>${receiptHtml(result, queued, item)}<p>${sub}</p>${warns}
      <div id="routeNext"></div>
      ${OFFMODE || navigator.onLine === false ? `<a class="m-btn ${P.rt ? '' : 'm-btn-primary '}m-btn-block" href="#pick"><i class=ei-phoneoff aria-hidden=true></i> เลือกเครื่องถัดไป (โหมดออฟไลน์)</a>` : ''}
      <a class="m-btn ${P.rt || OFFMODE ? '' : 'm-btn-primary '}m-btn-block" href="${U('/m/')}">กลับไปงานของฉัน</a>
      <a class="m-btn m-btn-block" href="${U('/m/scan')}">ตรวจเครื่องถัดไป (สแกน QR)</a>
      ${queued === 'login' ? `<a class="m-btn m-btn-block" href="${U('/login')}?next=${encodeURIComponent(U('/m/'))}">เข้าสู่ระบบ</a>` : ''}</div>`;
    window.scrollTo(0, 0);
    if (P.rt) showRouteNext();
    if (queued) watchQueued(); else verifyReceipt();
  }

  // เส้นทางเดินตรวจ: ส่งแล้วพาไปเครื่องถัดไปทันที (ออฟไลน์ใช้ข้อมูลเส้นทางที่เก็บไว้)
  async function showRouteNext() {
    const rid = Number(P.rt), box = document.getElementById('routeNext'); if (!box) return;
    let d = null;
    try { d = await ECS.getJson('/api/m/routes/' + rid); await ECS.kv.put('route:' + rid, d); }
    catch (e) {
      d = await ECS.kv.get('route:' + rid);
      if (d) { d.stops.forEach(s => { if (s.form_id === pkg.form.id) s.status = 'done'; }); await ECS.kv.put('route:' + rid, d); }
    }
    if (!d) return;
    const todo = d.stops.filter(s => ['returned', 'overdue', 'due', 'free'].includes(s.status) && s.form_id !== pkg.form.id);
    const done = d.stops.filter(s => s.status === 'done' || s.form_id === pkg.form.id).length;
    const nx = todo[0];
    box.innerHTML = `<div class="m-card" style="text-align:left"><div class="small muted">เส้นทาง ${esc(d.route.name)} · ตรวจแล้ว ${done}/${d.total}</div>
      <div class="m-routebar"><div style="width:${d.total ? Math.round(100 * done / d.total) : 0}%"></div></div></div>` +
      (nx ? `<a class="m-btn m-btn-primary m-btn-block" href="${U('/m/fill')}#f=${nx.form_id}${nx.round_id ? '&r=' + nx.round_id : ''}&rt=${rid}">▶ ต่อไป: ${esc(nx.eq_code || nx.code)} · ${esc(nx.name)}</a>`
        : `<div class="m-card"><strong>✓ ตรวจครบทุกจุดที่ถึงเวลาแล้ว</strong>${(() => {
            const up = d.stops.filter(s => s.status === 'upcoming' && s.due_at).map(s => s.due_at).sort()[0];
            return up ? `<div class="small muted">จุดถัดไปถึงเวลาตรวจ ${fmt(up, true)}</div>` : ''; })()}</div>`) +
      `<a class="m-btn m-btn-block" href="${U('/m/route')}#id=${rid}">ดูเส้นทางทั้งหมด</a>`;
  }

  // ── เริ่มต้น ──
  // v0.38 แจ้งเครื่องหยุด → กลับหน้างานของฉัน (ไม่ต้องตรวจรอบนี้) · แจ้งเดินแล้ว → โหลดแบบฟอร์มใหม่ให้ตรวจต่อ
  document.addEventListener('ecs:eqstatus', () => {
    if (pkg && pkg.down) {                                // เดินเครื่องแล้ว → โหลดใหม่เข้าหน้ากรอกเลย (ไม่ต้องผ่านหน้าสถานะซ้ำ)
      (async () => { if (draft) { draft.status_ok = 1; await ECS.drafts.put(draftKey, draft); } location.reload(); })(); return;
    }
    setTimeout(() => { location.href = U('/m/'); }, 900);
  });
  async function loadPackage(formId, roundId) {
    const key = 'pkg:' + formId;
    try {
      const d = await ECS.getJson(`/api/m/forms/${formId}/package` + (roundId ? `?round=${roundId}` : ''));
      await ECS.kv.put(key, d);
      return d;
    } catch (e) {
      if (e.status === 401) { location.href = U('/login') + '?next=' + encodeURIComponent(U('/m/fill') + location.hash); throw e; }
      if (e.status === 404) throw e;
      const c = await ECS.kv.get(key);
      if (c) { c._cached = true; return c; }
      throw new Error('ไม่มีสัญญาณ และแบบฟอร์มนี้ยังไม่เคยถูกโหลดไว้ในเครื่อง — เปิดหน้า "งานของฉัน" ตอนมีสัญญาณเพื่อโหลดเก็บไว้ก่อน');
    }
  }

  let afterRender = () => {};
  async function init() {
    try {
      if ('pick' in P) {                    // v0.40 โหมดออฟไลน์: เลือกเครื่องในหน้าเดิม
        OFFMODE = true; try { sessionStorage.setItem('m_offmode', '1'); } catch (e) { /* */ }
        document.getElementById('hTitle').textContent = 'โหมดออฟไลน์';
        await ECSOffline.renderPicker(app);
        return;
      }
      if (P.o) {   // เปิดรายการที่ส่งไม่ผ่านกลับมาแก้ไข
        const item = await ECS.outbox.get(P.o);
        if (!item) { app.innerHTML = '<div class="m-empty">ไม่พบรายการนี้ (อาจส่งสำเร็จแล้ว)</div>'; return; }
        pkg = await loadPackage(item.payload.form_id, item.payload.round_id);
        draftKey = `d:${item.payload.form_id}:${item.payload.round_id || 0}`;
        draft = { client_uuid: item.client_uuid, scanned_at: item.payload.scanned_at, note: item.payload.note,
          round: item.payload.round_id ? (pkg.round && pkg.round.id === item.payload.round_id ? pkg.round : { id: item.payload.round_id }) : null,
          answers: Object.fromEntries(item.payload.answers.map(a => [a.item_key, { value: a.value, remark: a.remark, photos: a.photos, src: a.src || '' }])),
          error: item.error };
        await ECS.drafts.put(draftKey, draft); await ECS.outbox.del(item.client_uuid);
        history.replaceState(null, '', U('/m/fill') + `#f=${item.payload.form_id}` + (item.payload.round_id ? `&r=${item.payload.round_id}` : ''));
      } else {
        const formId = Number(P.f); if (!formId) { app.innerHTML = '<div class="m-empty">ไม่ได้ระบุแบบฟอร์ม</div>'; return; }
        const roundId = Number(P.r) || null;
        pkg = await loadPackage(formId, roundId);
        let rnd = pkg.round && (!roundId || pkg.round.id === roundId) ? pkg.round : null;
        if (!rnd && roundId) {
          // แพ็กเกจในเครื่องเป็นของรอบอื่น → หาเวลาของรอบนี้จากรายการงานที่เก็บไว้
          const tasks = await ECS.kv.get('tasks');
          const all = tasks ? Object.values(tasks.groups).flat() : [];
          const t = all.find(r => r.id === roundId);
          rnd = t ? { id: t.id, due_at: t.due_at, deadline_at: t.deadline_at, close_at: t.close_at, status: t.status } : { id: roundId };
        }
        draftKey = `d:${formId}:${rnd ? rnd.id : 0}`;
        draft = await ECS.drafts.get(draftKey);
        if (draft && draft.version_id && draft.version_id !== pkg.version.id) {
          // แบบฟอร์มเปลี่ยนเวอร์ชันระหว่างกรอก → เก็บค่าหัวข้อที่ยังมีอยู่
          const keys = new Set(pkg.items.map(i => i.item_key));
          Object.keys(draft.answers).forEach(k => { if (!keys.has(k)) delete draft.answers[k]; });
        }
        if (!draft) draft = { client_uuid: ECS.uuid(), scanned_at: ECS.nowTs(), answers: {}, note: '', round: rnd };
        draft.version_id = pkg.version.id;
        if (P.qr) { draft.eq_ok = 1; delete draft.eq_bad; }                  // v0.51 เปิดจากการสแกน QR ที่เครื่อง
        try {                                                                 // v0.95 รอบนี้อยู่ในคิวรอส่งแล้ว?
          const q = (await ECS.status()).items.find(i => i.status !== 'rejected' && i.payload.form_id === formId && (i.payload.round_id || 0) === (rnd ? rnd.id : 0));
          if (q && rnd) draft.queued_at = q.payload.finished_at || q.created_at; else delete draft.queued_at;
        } catch (e) { /* */ }
        applyScada();
        await ECS.drafts.put(draftKey, draft);
      }
      document.getElementById('hTitle').textContent = pkg.form.eq_code || 'กรอกผลตรวจ';
      let ptNote = null;
      if (P.pt && needScan()) {
        const hit = matchPoint(P.pt);
        if (hit != null) { await confirmPoint(hit, P.pt); ptNote = { ok: true, sec: hit }; }
        else ptNote = { ok: false };
      }
      for (const a of Object.values(draft.answers)) for (const pid of a.photos || []) {
        const p = await ECS.photos.get(pid); if (p) thumbs[pid] = URL.createObjectURL(p.blob); else a.photos = a.photos.filter(x => x !== pid);
      }
      afterRender = () => {
        const pend = pendingPoints();
        if (pend.length && !(ptNote && ptNote.ok) && !pkg.down)
          scanPopup(pend[0].name, ptNote && !ptNote.ok ? 'QR ที่สแกนมาไม่ใช่จุดตรวจของแบบฟอร์มนี้' : '');
        if (ptNote && ptNote.ok) {
          toast(`✓ ยืนยันจุด "${ptNote.sec || 'ทั่วไป'}" แล้ว`, true);
          goPoint(ptNote.sec);
        }
      };
      if (P.qr && pkg.form.equipment_id && !draft.status_ok && !Object.keys(draft.answers || {}).length) {
        statusGate(); if (!P.o) techStatus(true); return;              // v0.56 สแกน QR → หน้าสถานะเครื่องก่อน
      }
      renderAll();
      if (!P.o) techStatus(true);
      afterRender();
      if (!P.pt && resumePoint()) setTimeout(goResume, 350);           // v0.95 กรอกต่อจากที่ค้าง
    } catch (e) {
      app.innerHTML = `<div class="m-empty"><strong>เปิดแบบฟอร์มไม่ได้</strong><br>${esc(e.message)}</div>
        <a class="m-btn m-btn-block" href="${U('/m/')}">กลับไปงานของฉัน</a>`;
    }
  }
  // ── สถานะช่างใน UT-CMMS: เปิดหน้ากรอก = "ตรวจเช็ค" · ออกโดยไม่ส่ง = หยุดนับ (ส่งแล้วเซิร์ฟเวอร์ปิดให้เอง) ──
  let statusOn = false, submitted = false;
  async function techStatus(on) {
    if (!pkg || !navigator.onLine) return;
    const body = JSON.stringify(on ? { form_id: pkg.form.id, client_uuid: draft && draft.client_uuid } : { form_id: pkg.form.id });
    try {
      if (on) {
        await ECS.ping();
        const r = await fetch(U('/api/m/status/start'), { method: 'POST', body, credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': ECS.csrf(), Accept: 'application/json' } });
        const d = await r.json().catch(() => ({}));
        if (r.ok && d.status) {
          statusOn = true;
          const head = document.querySelector('.m-formhead');
          if (head && !document.getElementById('techChip')) head.insertAdjacentHTML('beforeend',
            `<div class="m-techchip" id="techChip">⏱ สถานะช่าง UT-CMMS: <b>กำลังตรวจเช็ค</b> — ส่งผลแล้วปิดให้อัตโนมัติ</div>`);
        }
      } else if (statusOn && !submitted) {
        statusOn = false;
        fetch(U('/api/m/status/stop'), { method: 'POST', body, credentials: 'same-origin', keepalive: true,
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': ECS.csrf() } }).catch(() => {});
      }
    } catch (e) { /* สถานะช่างเป็นส่วนเสริม — ห้ามกระทบการกรอก */ }
  }
  window.addEventListener('pagehide', () => techStatus(false));
  window.addEventListener('pageshow', e => { if (e.persisted && !submitted) techStatus(true); });
  // v0.40 เปลี่ยนแบบฟอร์มในหน้าเดิม (ไม่โหลดหน้าใหม่ → ใช้ได้ตอนไม่มีสัญญาณ แม้ไม่มี service worker)
  window.addEventListener('hashchange', async () => {
    try { if (saveTimer) await saveNow(); } catch (e) { /* */ }
    if (!submitted) techStatus(false);
    Object.values(thumbs).forEach(u => { try { URL.revokeObjectURL(u); } catch (e) { /* */ } });
    P = Object.fromEntries(new URLSearchParams(location.hash.slice(1)));
    pkg = null; draft = null; draftKey = null; photoTarget = null; thumbs = {};
    submitted = false; statusOn = false;
    document.querySelectorAll('.m-modal').forEach(m => m.remove()); document.body.classList.remove('m-modal-open');
    app.innerHTML = '<div class="m-empty">กำลังเปิด…</div>'; window.scrollTo(0, 0);
    init();
  });
  init();
  ECS.sync();
})();
