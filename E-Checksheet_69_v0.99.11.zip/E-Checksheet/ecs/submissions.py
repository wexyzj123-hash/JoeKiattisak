"""ecs/submissions.py — Phase 2: งานของฉัน, แพ็กเกจแบบฟอร์ม, รับผลตรวจ, รูปถ่าย, อนุมัติ/ตีกลับ"""
from __future__ import annotations

import json
import os
import re
import uuid
from datetime import datetime, time, timedelta
from typing import Any

from . import services as S
from .itemfreq import get_calendar, is_due, reference_time
from .services import ValidationError, audit, parse_ts, row_dict, ts

UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
OPEN_ROUND_STATUSES = ("pending", "in_progress", "overdue", "returned")
EARLY_START_MIN = 120          # เปิดตรวจก่อนเวลาเริ่มได้ไม่เกิน 2 ชม.
MAX_PHOTOS_PER_ITEM = 5
MAX_CLIENT_CLOCK_SKEW = timedelta(minutes=10)
MAX_OFFLINE_AGE = timedelta(days=7)

# ───────────────────────── scope ─────────────────────────

def user_scope(db, user_id: int) -> dict:
    u = db.execute("SELECT id, role, factory_id, name FROM users WHERE id=?", (user_id,)).fetchone()
    return dict(u) if u else {"id": user_id, "role": "", "factory_id": None, "name": ""}


def _round_visible_sql(user: dict) -> tuple[str, list]:
    """เงื่อนไขรอบตรวจที่ผู้ใช้คนนี้ต้องเห็นใน 'งานของฉัน'"""
    cond, params = [], []
    fids = user.get("factories", [user["factory_id"]] if user.get("factory_id") else None)   # v0.50 มอบหมายหลายโรงงาน
    if fids:
        cond.append(f"(f.factory_id IS NULL OR f.factory_id IN ({','.join('?' * len(fids))}))")
        params.extend(fids)
    if user.get("role") == "technician":
        cond.append("(s.assignee_user_id=? OR (s.assignee_user_id IS NULL AND COALESCE(s.assignee_role,'') IN ('', 'technician')))")
        params.append(user["id"])
    return (" AND " + " AND ".join(cond)) if cond else "", params


# ───────────────────────── my tasks ─────────────────────────

def receipt(db, client_uuid: str, user_id: int) -> dict | None:
    """v0.99.10 ใบรับผลตรวจ — อ่านจากฐานข้อมูลอีกครั้งว่าผลตรวจ (client_uuid) ถึงระบบแล้วจริง (เฉพาะของผู้ส่งเอง)"""
    cu = str(client_uuid or "").strip().lower()
    if not UUID_RE.match(cu):
        return None
    r = db.execute("""SELECT s.id, s.received_at, s.finished_at, s.ng_count, s.warn_count, s.status, s.approval_status,
                             s.round_id, r.status AS round_status, r.due_at, e.code AS eq_code, f.name AS form_name,
                             (SELECT COUNT(*) FROM cs_answers a WHERE a.submission_id=s.id) AS answers
                      FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id LEFT JOIN equipment e ON e.id=s.equipment_id
                      LEFT JOIN cs_rounds r ON r.id=s.round_id WHERE s.client_uuid=? AND s.inspector_id=?""",
                   (cu, user_id)).fetchone()
    return dict(r) if r else None


def sent_today(db, user_id: int, now: datetime | None = None, limit: int = 60) -> list[dict]:
    """v0.95 ผลตรวจของฉันที่ “ถึงระบบแล้ว” วันนี้ (ยืนยันจากเซิร์ฟเวอร์) — ใช้บอกช่างว่าข้อมูลเข้าแล้วจริง
    late_sync = ส่งถึงเซิร์ฟเวอร์ช้ากว่าเวลากดส่งเกิน 5 นาที (บันทึกตอนไม่มีสัญญาณ)"""
    now = now or S.now_dt()
    start = datetime.combine(now.date(), time(0, 0))
    rows = db.execute("""
        SELECT s.id, s.client_uuid, s.form_id, s.round_id, s.finished_at, s.received_at, s.ng_count, s.warn_count,
               s.status, s.approval_status, s.approval_note, f.name AS form_name, e.code AS eq_code,
               r.status AS round_status, r.due_at
        FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
        LEFT JOIN equipment e ON e.id=s.equipment_id LEFT JOIN cs_rounds r ON r.id=s.round_id
        WHERE s.inspector_id=? AND s.received_at>=? AND s.status<>'superseded'
        ORDER BY s.received_at DESC LIMIT ?""", (user_id, S.ts(start), limit)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        fin, rec = S.parse_ts(d["finished_at"]), S.parse_ts(d["received_at"])
        d["late_sync"] = bool(fin and rec and (rec - fin).total_seconds() > 300)
        out.append(d)
    return out


def my_tasks(db, user_id: int, now: datetime | None = None) -> dict:
    now = now or S.now_dt()
    user = user_scope(db, user_id)
    from . import roster as RO
    user["factories"] = RO.factories_of(db, user_id)
    day_start = datetime.combine(now.date(), time(0, 0))
    day_end = day_start + timedelta(days=1)
    extra, params = _round_visible_sql(user)
    rows = db.execute(f"""
        SELECT r.*, f.name AS form_name, f.code AS form_code, f.equipment_id, e.code AS eq_code, e.name AS eq_name,
               f.category, e.eq_type, f.factory_id,
               fa.name AS factory_name, ar.name AS area_name, e.location AS eq_location, e.down_reason, e.down_since,
               COALESCE(e.run_status, 'running') AS run_status,
               sb.finished_at, sb.ng_count, sb.inspector_id, sb.approval_status, sb.approval_note,
               iu.name AS inspector_name,
               (SELECT COUNT(*) FROM cs_form_items i WHERE i.version_id=f.current_version_id) AS item_count
        FROM cs_rounds r
        JOIN cs_schedules s ON s.id=r.schedule_id
        JOIN cs_forms f ON f.id=r.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN areas ar ON ar.id=f.area_id
        LEFT JOIN cs_submissions sb ON sb.id=r.submission_id
        LEFT JOIN users iu ON iu.id=sb.inspector_id
        WHERE f.active=1 AND f.current_version_id IS NOT NULL
          AND ( (r.due_at >= ? AND r.due_at < ?)
             OR (r.status IN ('pending','in_progress','overdue','returned') AND r.due_at < ? AND r.close_at > ?) )
          AND (s.active=1 OR r.status IN ('done_on_time','done_late','returned'))   -- v0.48 ปิดรอบตรวจแล้ว → ไม่ขึ้นเป็นงาน
          {extra}
        ORDER BY r.due_at, fa.sort_no, f.name""",
        [ts(day_start), ts(day_end), ts(day_end), ts(now)] + params).fetchall()
    groups: dict[str, list] = {"returned": [], "overdue": [], "due": [], "upcoming": [], "done": [], "missed": [], "skipped": [],
                               "other": []}
    early = now + timedelta(minutes=EARLY_START_MIN)
    dicts = [dict(r) for r in rows]
    dicts, others = RO.split_rounds(db, user, dicts, now)      # v0.50 ตารางกะ: งานของกะอื่นแยกไว้
    seen_o: set = set()
    for d in others:
        if d["form_id"] not in seen_o and not (d["status"] in ("pending", "in_progress", "overdue") and d.get("run_status") == "down"):
            seen_o.add(d["form_id"])
            d["cat"] = S.form_category(d)
            groups["other"].append(d)
    for d in dicts:
        d["cat"] = S.form_category(d)
        st = d["status"]
        if st in ("pending", "in_progress", "overdue") and d["run_status"] == "down":
            st = "skipped"                              # v0.48 เครื่องแจ้งหยุด/PM → ไม่ต้องตรวจ (แม้รอบยังไม่ถูกปรับสถานะ)
        if st in ("pending", "in_progress", "overdue") and parse_ts(d["close_at"]) and parse_ts(d["close_at"]) <= now:
            st = "missed"
        elif st in ("pending", "in_progress") and parse_ts(d["deadline_at"]) and parse_ts(d["deadline_at"]) <= now:
            st = "overdue"
        d["status"] = st
        if st == "returned":
            groups["returned"].append(d)
        elif st == "overdue":
            groups["overdue"].append(d)
        elif st in ("pending", "in_progress"):
            (groups["due"] if parse_ts(d["due_at"]) <= early else groups["upcoming"]).append(d)
        elif st in ("done_on_time", "done_late"):
            groups["done"].append(d)
        elif st == "missed":
            groups["missed"].append(d)
        elif st == "skipped":
            groups["skipped"].append(d)
    # v0.48 เครื่องละ 1 การ์ดในงานที่ต้องทำ (ด่วนสุดก่อน: ตีกลับ → เลยกำหนด → ถึงเวลา → ถัดไป) · รอบที่ซ้อนนับเป็น "+N รอบ"
    seen: dict[int, dict] = {}
    for key in ("returned", "overdue", "due", "upcoming"):
        keep = []
        for d in groups[key]:
            first = seen.get(d["form_id"])
            if first:
                first["more"] = first.get("more", 0) + 1
                continue
            seen[d["form_id"]] = d
            keep.append(d)
        groups[key] = keep
    sk: dict = {}
    for d in groups["skipped"]:                         # เครื่องหยุด: 1 การ์ดต่อแบบฟอร์ม
        if d["form_id"] in sk:
            sk[d["form_id"]]["more"] = sk[d["form_id"]].get("more", 0) + 1
        else:
            sk[d["form_id"]] = d
    groups["skipped"] = list(sk.values())
    todo = len(groups["returned"]) + len(groups["overdue"]) + len(groups["due"])
    try:
        duty = RO.my_duty(db, user_id, now) if user.get("role") in RO.TEAM_ROLES else None
    except Exception:                                          # noqa: BLE001 — ตารางกะอ่านไม่ได้ ไม่ให้หน้างานล่ม
        duty = None
    try:
        from .handover import pending_for
        hand = pending_for(db, user_id, now)
    except Exception:                                          # noqa: BLE001
        hand = []
    return {"now": ts(now), "user": user, "groups": groups, "todo": todo, "duty": duty, "my_ng": my_ng(db, user_id, now),
            "handover": hand,
            "done_count": len(groups["done"]), "total": sum(len(v) for v in groups.values())}


def my_ng(db, user_id: int, now: datetime | None = None, days: int = 14, limit: int = 12) -> list[dict]:
    """v0.50 NG ที่ฉันแจ้ง — ช่างเห็นว่าเรื่องไปถึงไหนแล้ว ใครรับ ทำอะไรไป (ปิดวงจร NG)"""
    now = now or S.now_dt()
    rows = db.execute("""
        SELECT a.id, a.title, a.severity, a.status, a.item_key, a.updated_at, a.created_at, a.closed_at, a.action_taken,
               a.root_cause, a.wo_id, a.occurrences, f.name AS form_name, e.code AS eq_code,
               ua.name AS ack_name, a.ack_at, uo.name AS owner_name,
               (SELECT ev.detail FROM cs_alert_events ev WHERE ev.alert_id=a.id AND ev.detail<>'' ORDER BY ev.id DESC LIMIT 1) AS last_note,
               (SELECT uu.name FROM cs_alert_events ev JOIN users uu ON uu.id=ev.actor_id
                 WHERE ev.alert_id=a.id ORDER BY ev.id DESC LIMIT 1) AS last_actor
        FROM cs_alerts a
        JOIN cs_submissions sb ON sb.id=a.submission_id
        LEFT JOIN cs_forms f ON f.id=a.form_id
        LEFT JOIN equipment e ON e.id=a.equipment_id
        LEFT JOIN users ua ON ua.id=a.ack_by
        LEFT JOIN users uo ON uo.id=a.assigned_to
        WHERE sb.inspector_id=? AND a.alert_type IN ('ng','warn') AND a.created_at >= ?
          AND (a.status<>'closed' OR a.closed_at >= ?)
        ORDER BY CASE a.status WHEN 'open' THEN 0 WHEN 'acknowledged' THEN 1 WHEN 'in_progress' THEN 2
                 WHEN 'resolved' THEN 3 ELSE 4 END, a.updated_at DESC LIMIT ?""",
        (user_id, ts(now - timedelta(days=days)), ts(now - timedelta(days=3)), limit)).fetchall()
    return [dict(r) for r in rows]


def mobile_forms(db, user_id: int) -> list[dict]:
    """แบบฟอร์มทั้งหมดที่ผู้ใช้ตรวจได้ (สำหรับแท็บ 'แบบฟอร์มทั้งหมด' บนมือถือ — ตรวจนอกรอบ/หาเช็คชีทตามโรงงาน-หมวดหมู่)"""
    user = user_scope(db, user_id)
    out = []
    eqs = {r[0]: (r[1], r[2], r[3]) for r in db.execute(
        "SELECT id, COALESCE(run_status,'running'), COALESCE(down_reason,''), down_since FROM equipment")}
    for f in S.list_forms(db, user.get("factory_id") or None):
        if not f["current_version_id"] or f.get("is_template"):
            continue
        out.append({"id": f["id"], "name": f["name"], "code": f["code"], "eq_code": f["eq_code"], "eq_name": f["eq_name"],
                    "factory_id": f["factory_id"], "factory_name": f["factory_name"], "area_name": f["area_name"],
                    "cat": S.form_category(f), "items": f["item_count"], "last": f["last_submitted"],
                    "equipment_id": f.get("equipment_id"),                       # v0.38 แจ้งหยุด/PM จากรายการ
                    "run_status": eqs.get(f.get("equipment_id"), ("running",))[0],
                    "down_reason": eqs.get(f.get("equipment_id"), ("", ""))[1] if f.get("equipment_id") else "",
                    "down_since": eqs.get(f.get("equipment_id"), ("", "", None))[2] if f.get("equipment_id") else None})
    return out


def open_round_for_form(db, form_id: int, now: datetime | None = None) -> dict | None:
    """รอบตรวจที่เปิดอยู่ของแบบฟอร์ม (สำหรับการสแกน QR ที่ไม่ได้เลือกรอบ)"""
    now = now or S.now_dt()
    # v0.53 เฉพาะรอบตรวจที่ยังเปิดใช้งาน · ตีกลับก่อน → รอบปัจจุบัน (ยังไม่เลยกำหนด) → รอบที่เลยกำหนดล่าสุด
    row = db.execute("""
        SELECT r.* FROM cs_rounds r JOIN cs_schedules s ON s.id=r.schedule_id
        WHERE r.form_id=? AND s.active=1 AND r.status IN ('pending','in_progress','overdue','returned')
          AND r.due_at <= ? AND r.close_at > ?
        ORDER BY CASE WHEN r.status='returned' THEN 0 WHEN r.deadline_at > ? THEN 1 ELSE 2 END,
                 CASE WHEN r.deadline_at > ? THEN r.due_at END, r.due_at DESC LIMIT 1""",
        (form_id, ts(now + timedelta(minutes=EARLY_START_MIN)), ts(now), ts(now), ts(now))).fetchone()
    return row_dict(row)


# ───────────────────────── form package (ใช้ได้แบบออฟไลน์) ─────────────────────────

def previous_values(db, form_id: int, item_keys: list[str], before: str | None = None) -> dict[str, dict]:
    """ค่าล่าสุดของแต่ละหัวข้อ (จากผลตรวจที่ไม่ถูกตีกลับ) — ใช้แสดง 'ครั้งก่อน' และตรวจมิเตอร์สะสม"""
    if not item_keys:
        return {}
    out: dict[str, dict] = {}
    ph = ",".join("?" for _ in item_keys)
    params: list[Any] = [form_id] + list(item_keys)
    cond = ""
    if before:
        cond = " AND s.finished_at <= ?"
        params.append(before)
    rows = db.execute(f"""
        SELECT a.item_key, a.value_num, a.value_text, a.judgement, s.finished_at
        FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
        WHERE s.form_id=? AND a.item_key IN ({ph}) AND s.status='submitted'
          AND a.judgement<>'na' {cond}
        ORDER BY s.finished_at DESC, s.id DESC""", params).fetchall()
    for r in rows:
        if r["item_key"] not in out:
            out[r["item_key"]] = {"value_num": r["value_num"], "value_text": r["value_text"],
                                  "judgement": r["judgement"], "at": r["finished_at"]}
    return out


def recent_values(db, form_id: int, item_keys: list[str], n: int = 5) -> dict[str, list[dict]]:
    """ค่าตัวเลข n ครั้งล่าสุดของแต่ละหัวข้อ (เก่า → ใหม่) — ใช้วาดกราฟแนวโน้มเล็ก ๆ ข้างช่องกรอกบนมือถือ"""
    if not item_keys:
        return {}
    out: dict[str, list[dict]] = {}
    ph = ",".join("?" for _ in item_keys)
    rows = db.execute(f"""
        SELECT item_key, value_num, judgement, finished_at FROM (
          SELECT a.item_key, a.value_num, a.judgement, s.finished_at,
                 ROW_NUMBER() OVER (PARTITION BY a.item_key ORDER BY s.finished_at DESC, s.id DESC) AS rn
          FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
          WHERE s.form_id=? AND a.item_key IN ({ph}) AND s.status='submitted'
            AND a.judgement<>'na' AND a.value_num IS NOT NULL)
        WHERE rn<=? ORDER BY item_key, finished_at, rn DESC""", [form_id, *item_keys, n]).fetchall()
    for r in rows:
        out.setdefault(r["item_key"], []).append({"v": r["value_num"], "j": r["judgement"], "at": r["finished_at"]})
    return out


def _package_sections(form: dict, sections: list[dict]) -> list[dict]:
    """จุดตรวจสำหรับมือถือ — ถ้าบังคับสแกน ใส่ค่า SHA-256 ของรหัสจุดไว้ตรวจตอนออฟไลน์ (ไม่ส่งรหัสจริง)"""
    if not form.get("require_point_scan"):
        return sections
    from .points import code_hash, point_code
    return [dict(s, code_sha=code_hash(point_code(form["id"], s["name"]))) for s in sections]


def _down_info(db, form_id: int) -> dict | None:
    from .downtime import is_down
    return is_down(db, form_id)


def form_package(db, form_id: int, round_id: int | None = None) -> dict:
    form = S.get_form(db, form_id)
    if not form or not form["active"] or not form["current_version_id"]:
        raise ValidationError("แบบฟอร์มนี้ยังไม่พร้อมใช้งาน (ยังไม่ Publish หรือถูกปิด)")
    version = S.get_version(db, form["current_version_id"])
    items = S.get_items(db, version["id"])
    public_items = [{k: it[k] for k in ("id", "item_key", "section", "order_no", "name", "item_type", "unit",
                                        "min_value", "max_value", "warn_low", "warn_high", "counter_max_step",
                                        "options", "required", "critical", "photo_on_ng", "guide",
                                        "check_freq", "check_times", "photo_required", "formula")}
                    for it in items]
    rnd = None
    if round_id:
        rnd = row_dict(db.execute("SELECT * FROM cs_rounds WHERE id=? AND form_id=?", (round_id, form_id)).fetchone())
    if rnd is None:
        rnd = open_round_for_form(db, form_id)
    # v0.51 เตือนเปิดผิดรอบ: รอบนี้ส่งแล้วโดยใคร · รอบที่ถึงเวลาตอนนี้ (ถ้าเปิดรอบอื่นไว้)
    done_by = None
    if rnd and rnd["status"] in ("done_on_time", "done_late") and rnd["submission_id"]:
        done_by = row_dict(db.execute("""SELECT s.finished_at, u.name AS inspector_name FROM cs_submissions s
                                         LEFT JOIN users u ON u.id=s.inspector_id WHERE s.id=?""", (rnd["submission_id"],)).fetchone())
    cur = open_round_for_form(db, form_id)
    current = {k: cur[k] for k in ("id", "due_at", "deadline_at", "close_at", "status")} if cur and (not rnd or cur["id"] != rnd["id"]) else None
    nx = db.execute("""SELECT r.id, r.due_at, r.deadline_at FROM cs_rounds r JOIN cs_schedules s ON s.id=r.schedule_id
                       WHERE r.form_id=? AND s.active=1 AND r.status='pending' AND r.due_at>? ORDER BY r.due_at LIMIT 1""",
                    (form_id, ts())).fetchone()                  # v0.53 รอบถัดไป (แสดงเมื่อตรวจนอกรอบ)
    returned = None
    if rnd and rnd["status"] == "returned" and rnd["submission_id"]:
        returned = row_dict(db.execute(
            "SELECT id, approval_note, approved_at FROM cs_submissions WHERE id=?", (rnd["submission_id"],)).fetchone())
    return {
        "form": {k: form.get(k) for k in ("id", "code", "name", "description", "equipment_id", "eq_code", "eq_name",
                                          "factory_name", "area_name", "require_point_scan")},
        "version": {"id": version["id"], "version_no": version["version_no"]},
        "items": public_items,
        "previous": previous_values(db, form_id, [i["item_key"] for i in items]),
        "history": recent_values(db, form_id, [i["item_key"] for i in items if i["item_type"] == "number"]),
        "sections": _package_sections(form, S.get_sections(db, version["id"], items)),
        "calendar": get_calendar(db),
        "down": _down_info(db, form_id),
        "round": rnd and {k: rnd[k] for k in ("id", "due_at", "deadline_at", "close_at", "status")},
        "round_done": done_by,
        "current_round": current,
        "next_round": dict(nx) if nx else None,
        "eq_qr": form.get("eq_qr_token") or "",
        "returned": returned,
        **_scada_prefill(db, form_id, rnd),                   # v0.45 ฟอร์มผสม · v0.82 ค่าของรอบนั้น (รวมลงย้อนหลัง)
        "fetched_at": ts(),
    }


def _scada_prefill(db, form_id: int, rnd: dict | None = None) -> dict:
    """รอบที่เลยเวลาแล้ว (รวมรอบย้อนหลัง) → ค่าจาก SCADA ของเวลารอบนั้น (scada_slot) · ไม่มีรอบ/ยังไม่ถึงเวลา → ค่าล่าสุด ≤ 3 ชม."""
    try:
        from .srcmap import prefill_slot, prefill_values
        if rnd and rnd.get("due_at"):
            due = parse_ts(rnd["due_at"])
            if due <= S.now_dt() + timedelta(minutes=5):
                return {"scada": prefill_slot(db, form_id, due), "scada_slot": rnd["due_at"]}
        return {"scada": prefill_values(db, form_id), "scada_slot": None}
    except Exception:                                       # noqa: BLE001 — ไม่ให้การเปิดฟอร์มล้มเพราะข้อมูล SCADA
        return {"scada": {}, "scada_slot": None}


# ───────────────────────── photos ─────────────────────────

def detect_image(head: bytes) -> str | None:
    from .imaging import sniff
    return sniff(head)


def _store_photo(file_storage, upload_dir: str, max_bytes: int) -> dict:
    data = file_storage.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise ValidationError(f"รูป {file_storage.filename or ''} มีขนาดเกิน {max_bytes // (1024 * 1024)} MB")
    if not data:
        raise ValidationError("ไฟล์รูปว่างเปล่า")
    from .imaging import ImageError, process
    try:
        data, ext = process(data)          # รับได้ทุกรูปแบบ/ไฟล์ใหญ่ → ย่อ ≤1600px เป็น JPEG
    except ImageError as exc:
        raise ValidationError(f"{file_storage.filename or 'รูป'}: {exc}") from None
    now = S.now_dt()
    rel = os.path.join("cs", now.strftime("%Y"), now.strftime("%m"), f"{uuid.uuid4().hex}.{ext}")
    full = os.path.join(upload_dir, rel)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "wb") as fh:
        fh.write(data)
    return {"rel": rel.replace(os.sep, "/"), "full": full, "size_kb": max(1, len(data) // 1024)}


# ───────────────────────── submit ─────────────────────────

def _route_id(db, value, form_id: int) -> int | None:
    try:
        rid = int(value or 0)
    except (TypeError, ValueError):
        return None
    if rid and db.execute("SELECT 1 FROM cs_route_stops WHERE route_id=? AND form_id=?", (rid, form_id)).fetchone():
        return rid
    return None


def _client_time(value, now: datetime, label: str, warnings: list) -> datetime | None:
    dt = parse_ts(value) if value else None
    if dt is None:
        return None
    if dt > now + MAX_CLIENT_CLOCK_SKEW:
        warnings.append(f"เวลา{label}ของเครื่องล้ำหน้าเวลาเซิร์ฟเวอร์ — ใช้เวลาเซิร์ฟเวอร์แทน")
        return now
    if dt < now - MAX_OFFLINE_AGE:
        warnings.append(f"เวลา{label}เก่ากว่า 7 วัน — ใช้เวลาเซิร์ฟเวอร์แทน")
        return now
    return dt


def create_submission(db, payload: dict, photos: dict, user_id: int, upload_dir: str,
                      max_photo_bytes: int = 8 * 1024 * 1024, now: datetime | None = None) -> dict:
    """บันทึกผลตรวจ 1 ครั้ง — ตรวจความครบถ้วน/เกณฑ์ที่ฝั่งเซิร์ฟเวอร์เสมอ และกันการส่งซ้ำด้วย client_uuid

    payload = {client_uuid, form_id, form_version_id, round_id?, scanned_at, finished_at, note,
               client_info, answers: [{item_key, value, remark, photos: [photo_field_name, ...]}]}
    photos  = {photo_field_name: FileStorage}
    """
    now = now or S.now_dt()
    client_uuid = str(payload.get("client_uuid") or "").strip().lower()
    if not UUID_RE.match(client_uuid):
        raise ValidationError("client_uuid ไม่ถูกต้อง")
    dup = db.execute("SELECT id, ng_count, warn_count, round_id, received_at FROM cs_submissions WHERE client_uuid=?",
                     (client_uuid,)).fetchone()
    if dup:
        return {"id": dup["id"], "duplicate": True, "ng_count": dup["ng_count"], "warn_count": dup["warn_count"],
                "received_at": dup["received_at"], "warnings": []}

    try:
        form_id = int(payload.get("form_id"))
        version_id = int(payload.get("form_version_id"))
    except (TypeError, ValueError):
        raise ValidationError("ข้อมูลแบบฟอร์มไม่ครบ")
    form = S.get_form(db, form_id)
    version = S.get_version(db, version_id)
    if not form or not version or version["form_id"] != form_id or version["status"] == "draft":
        raise ValidationError("ไม่พบแบบฟอร์ม/เวอร์ชันที่ใช้ตรวจ")
    if not form["active"]:
        raise ValidationError("แบบฟอร์มนี้ถูกปิดใช้งานแล้ว")

    warnings: list[str] = []
    user = user_scope(db, user_id)
    if user.get("factory_id") and form["factory_id"] and user["factory_id"] != form["factory_id"] \
            and user.get("role") == "technician":
        raise ValidationError("แบบฟอร์มนี้อยู่นอกโรงงานที่คุณรับผิดชอบ")

    # ── เวลา ──
    finished = _client_time(payload.get("finished_at"), now, "ส่ง", warnings) or now
    scanned = _client_time(payload.get("scanned_at"), now, "เริ่ม", warnings) or finished
    if scanned > finished:
        scanned = finished

    # v0.56 เครื่องแจ้งหยุดอยู่ + ช่างส่งผลตรวจ → เดินเครื่องอัตโนมัติ (ก่อนหารอบ เพื่อให้นับเป็นรอบของกะนี้)
    from .downtime import auto_run_on_check
    auto_run = auto_run_on_check(db, form_id, user_id, scanned, now)

    # ── รอบตรวจ ──
    rnd = None
    resubmit_of = None
    if payload.get("round_id"):
        rnd = row_dict(db.execute("SELECT * FROM cs_rounds WHERE id=? AND form_id=?",
                                  (int(payload["round_id"]), form_id)).fetchone())
        if rnd is None:
            warnings.append("ไม่พบรอบตรวจที่อ้างถึง — บันทึกเป็นการตรวจนอกรอบ")
        elif rnd["submission_id"] and rnd["status"] != "returned":
            warnings.append("รอบนี้มีผู้ส่งผลแล้ว — บันทึกเป็นการตรวจเพิ่มนอกรอบ")
            rnd = None
        elif rnd["status"] == "returned":
            resubmit_of = rnd["submission_id"]
    if rnd is None and not payload.get("round_id"):
        rnd = open_round_for_form(db, form_id, now)
        if rnd and rnd["submission_id"] and rnd["status"] != "returned":
            rnd = None
        elif rnd and rnd["status"] == "returned":
            resubmit_of = rnd["submission_id"]

    from . import backfill as BF                        # v0.55 รอบที่ตัดรอบแล้ว → ต้องมีสิทธิ์ลงย้อนหลัง
    BF.check(db, user_id, rnd, finished, now)
    backfilled = BF.is_backfill(rnd, finished, now)
    duration = int((finished - scanned).total_seconds())

    # ── คำตอบ ──
    items = S.get_items(db, version_id)
    answers_in = {str(a.get("item_key")): a for a in (payload.get("answers") or []) if isinstance(a, dict)}
    prev = previous_values(db, form_id, [i["item_key"] for i in items], before=ts(finished))
    # หัวข้อที่ตรวจไม่ทุกรอบ (กะละครั้ง/วันละครั้ง/ตามเวลา): ถ้ายังไม่ถึงเวลาและไม่ได้กรอก → ข้าม ไม่นับว่าขาด
    cal = get_calendar(db)
    ref = reference_time(scanned, parse_ts(rnd["due_at"]) if rnd else None)
    errors: list[str] = []
    evaluated = []
    if any(i["item_type"] == "calc" for i in items):     # v0.95 หัวข้อคำนวณ: เซิร์ฟเวอร์คำนวณเองจากค่าที่กรอก (ไม่เชื่อค่าจากเครื่อง)
        from . import formula as FM
        nums = {i["item_key"]: S._num((answers_in.get(i["item_key"]) or {}).get("value"))
                for i in items if i["item_type"] in ("number", "counter")}
        calc = FM.compute_all(items, nums)
        for i in items:
            if i["item_type"] == "calc":
                a = dict(answers_in.get(i["item_key"]) or {})
                a["value"] = "" if calc.get(i["item_key"]) is None else ("%g" % calc[i["item_key"]])
                answers_in[i["item_key"]] = a
    for idx, it in enumerate(items, start=1):
        ans = answers_in.get(it["item_key"], {})
        raw = ans.get("value")
        if it.get("check_freq") and (raw is None or str(raw).strip() == ""):
            done_at = parse_ts((prev.get(it["item_key"]) or {}).get("at"))
            if not is_due(it["check_freq"], it.get("check_times") or "", done_at, ref, cal):
                continue
        remark = str(ans.get("remark") or "").strip()[:500]
        photo_keys = [str(p) for p in (ans.get("photos") or [])][:MAX_PHOTOS_PER_ITEM]
        label = f"{idx}. {it['name']}"
        try:
            prev_num = prev.get(it["item_key"], {}).get("value_num") if it["item_type"] == "counter" else None
            res = S.evaluate(it, raw, prev_value=prev_num)
        except ValidationError as exc:
            errors.append(f"{label}: {exc.errors[0].split(': ', 1)[-1]}")
            continue
        if res["judgement"] == "na" and it["required"]:
            errors.append(f"{label}: ยังไม่ได้กรอก")
            continue
        missing_photos = [p for p in photo_keys if p not in photos]
        if missing_photos:
            errors.append(f"{label}: รูปถ่ายไม่ครบ ({len(missing_photos)} รูป) กรุณาส่งใหม่")
            continue
        if it.get("photo_required") and res["judgement"] != "na" and not photo_keys:
            errors.append(f"{label}: ต้องแนบรูปหลักฐานการตรวจอย่างน้อย 1 รูป")
            continue
        if res["judgement"] == "ng":
            if not remark:
                errors.append(f"{label}: ผล NG ต้องใส่หมายเหตุ")
            if it["photo_on_ng"] and not photo_keys:
                errors.append(f"{label}: ผล NG ต้องแนบรูปอย่างน้อย 1 รูป")
        src_tag = "scada" if str(ans.get("src") or "") == "scada" else ""   # v0.45 ค่าที่เติมจาก SCADA และช่างไม่ได้แก้
        evaluated.append((it, res, remark, photo_keys, src_tag))
    scans_ok: list[dict] = []
    if form.get("require_point_scan") and evaluated and not backfilled:   # v0.82 ลงย้อนหลังไม่ต้องสแกนจุดตรวจ
        from .points import check_scans
        answered = list(dict.fromkeys((it.get("section") or "") for it, res, *_ in evaluated if res["judgement"] != "na"))
        scans_ok, missing = check_scans(form_id, answered, payload.get("point_scans"))
        for sec in missing:
            errors.append(f"จุดตรวจ '{sec or 'ทั่วไป'}': ยังไม่ได้สแกน QR ยืนยันที่จุดตรวจ (หรือรหัสไม่ถูกต้อง)")
    if errors:
        raise ValidationError(errors)

    # ── บันทึกรูปก่อน แล้วค่อยเขียนฐานข้อมูล (ถ้าล้มจะลบรูปที่บันทึกไปแล้ว) ──
    stored: dict[str, dict] = {}
    try:
        for _, _, _, keys, _s in evaluated:
            for key in keys:
                if key not in stored:
                    stored[key] = _store_photo(photos[key], upload_dir, max_photo_bytes)
        ng = sum(1 for _, r, *_ in evaluated if r["judgement"] == "ng")
        warn = sum(1 for _, r, *_ in evaluated if r["judgement"] == "warn")
        cur = db.execute("""
            INSERT INTO cs_submissions(client_uuid, round_id, form_id, form_version_id, equipment_id, inspector_id,
                scanned_at, finished_at, received_at, duration_sec, status, ng_count, warn_count, approval_status,
                resubmit_of, note, client_info, source, point_scans, route_id)
            VALUES (?,?,?,?,?,?,?,?,?,?,'submitted',?,?,'pending',?,?,?,'v3',?,?)""",
            (client_uuid, rnd["id"] if rnd else None, form_id, version_id, form["equipment_id"], user_id,
             ts(scanned), ts(finished), ts(now), duration, ng, warn, resubmit_of,
             str(payload.get("note") or "").strip()[:1000], str(payload.get("client_info") or "")[:300],
             json.dumps(scans_ok, ensure_ascii=False) if scans_ok else "", _route_id(db, payload.get("route_id"), form_id)))
        sub_id = cur.lastrowid
        for it, res, remark, keys, src_tag in evaluated:
            aid = db.execute("""INSERT INTO cs_answers(submission_id, item_id, item_key, value_num, value_text,
                                judgement, remark, value_src) VALUES (?,?,?,?,?,?,?,?)""",
                             (sub_id, it["id"], it["item_key"], res["value_num"], res["value_text"],
                              res["judgement"], remark, src_tag)).lastrowid
            for key in keys:
                p = stored[key]
                db.execute("""INSERT INTO cs_photos(answer_id, submission_id, file_path, taken_at, size_kb, created_at)
                              VALUES (?,?,?,?,?,?)""", (aid, sub_id, p["rel"], ts(finished), p["size_kb"], ts(now)))
        round_status = None
        if rnd:
            round_status = S.round_status_for_submission(rnd, finished)
            db.execute("UPDATE cs_rounds SET submission_id=?, status=?, updated_at=? WHERE id=?",
                       (sub_id, round_status, ts(now), rnd["id"]))
        if resubmit_of:
            db.execute("UPDATE cs_submissions SET status='superseded' WHERE id=? AND status='returned'",
                       (resubmit_of,))
        audit(db, user_id, "submit", "cs_submissions", sub_id,
              after={"form_id": form_id, "round_id": rnd["id"] if rnd else None, "ng": ng, "warn": warn})
        if backfilled:
            audit(db, user_id, "backfill_submit", "cs_submissions", sub_id,
                  after={"form_id": form_id, "round_id": rnd["id"], "round_due": rnd["due_at"], "finished_at": ts(finished)})
        if rnd:                                        # v0.82 รวมค่าจาก SCADA ที่ระบบลงไว้ของรอบนี้เข้ากับผลของช่าง
            from .srcmap import absorb_auto
            if absorb_auto(db, sub_id, user_id):
                row = db.execute("SELECT ng_count, warn_count FROM cs_submissions WHERE id=?", (sub_id,)).fetchone()
                ng, warn = row[0], row[1]
        from .anomaly import check_submission          # Phase 3: ตรวจความผิดปกติทันทีที่รับผล
        anomalies = check_submission(db, sub_id)
        from .anomaly import raise_approval
        raise_approval(db, sub_id, now=now)            # v0.19: รายการ "รออนุมัติ" ในหน้าแจ้งเตือน
        from .signoffs import sync_sub                 # v0.26 แถวหัวหน้างานรายสัปดาห์ (ผลตรวจใหม่ = สัปดาห์ยังอนุมัติไม่ครบ)
        sync_sub(db, sub_id)
        _old = db.execute("SELECT resubmit_of FROM cs_submissions WHERE id=?", (sub_id,)).fetchone()
        if _old and _old[0]:
            sync_sub(db, _old[0])
    except Exception:
        for p in stored.values():
            try:
                os.remove(p["full"])
            except OSError:
                pass
        raise
    return {"id": sub_id, "duplicate": False, "ng_count": ng, "warn_count": warn, "received_at": ts(now),
            "round_status": round_status, "round_due": rnd["due_at"] if rnd else None, "warnings": warnings,
            "auto_running": auto_run,
            "anomalies": [{k: a[k] for k in ("alert_id", "type", "severity", "message", "new")} for a in anomalies]}


# ───────────────────────── read ─────────────────────────

def get_submission(db, sub_id: int) -> dict | None:
    sub = row_dict(db.execute("""
        SELECT s.*, f.name AS form_name, f.code AS form_code, f.factory_id, v.version_no,
               e.code AS eq_code, e.name AS eq_name, fa.name AS factory_name,
               u.name AS inspector_name, ap.name AS approver_name,
               r.due_at, r.deadline_at, r.status AS round_status, rt.name AS route_name
        FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
        LEFT JOIN cs_routes rt ON rt.id=s.route_id
        JOIN cs_form_versions v ON v.id=s.form_version_id
        LEFT JOIN equipment e ON e.id=s.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN users u ON u.id=s.inspector_id
        LEFT JOIN users ap ON ap.id=s.approved_by
        LEFT JOIN cs_rounds r ON r.id=s.round_id
        WHERE s.id=?""", (sub_id,)).fetchone())
    if not sub:
        return None
    answers = [dict(r) for r in db.execute("""
        SELECT a.*, i.name, i.section, i.item_type, i.unit, i.min_value, i.max_value, i.warn_low, i.warn_high,
               i.critical, i.order_no
        FROM cs_answers a JOIN cs_form_items i ON i.id=a.item_id
        WHERE a.submission_id=? ORDER BY i.order_no, i.id""", (sub_id,))]
    photos: dict[int, list] = {}
    for p in db.execute("SELECT * FROM cs_photos WHERE submission_id=? ORDER BY id", (sub_id,)):
        photos.setdefault(p["answer_id"], []).append(dict(p))
    for a in answers:
        a["photos"] = photos.get(a["id"], [])
    sub["answers"] = answers
    sub["history"] = [dict(r) for r in db.execute("""
        SELECT s.id, s.finished_at, s.status, s.approval_status, s.approval_note, u.name AS inspector_name
        FROM cs_submissions s LEFT JOIN users u ON u.id=s.inspector_id
        WHERE s.id=? OR s.resubmit_of=? OR s.id=(SELECT resubmit_of FROM cs_submissions WHERE id=?)
        ORDER BY s.finished_at""", (sub_id, sub_id, sub_id))]
    return sub


def list_submissions(db, *, factory_id=None, form_id=None, equipment_id=None, inspector_id=None,
                     approval=None, only_ng=False, date_from=None, date_to=None,
                     limit=50, offset=0, source=None) -> tuple[list[dict], int]:
    where, params = ["s.status<>'superseded'"], []
    if source == "auto":                                    # v0.45 ค่าอัตโนมัติจาก SCADA
        where.append("s.source='auto'")
    elif source == "manual":
        where.append("COALESCE(s.source,'')<>'auto'")
    if factory_id:
        where.append("f.factory_id=?"); params.append(factory_id)
    if form_id:
        where.append("s.form_id=?"); params.append(form_id)
    if equipment_id:
        where.append("s.equipment_id=?"); params.append(equipment_id)
    if inspector_id:
        where.append("s.inspector_id=?"); params.append(inspector_id)
    if approval:
        where.append("s.approval_status=?"); params.append(approval)
    if only_ng:
        where.append("s.ng_count>0")
    if date_from:
        where.append("s.finished_at >= ?"); params.append(f"{date_from} 00:00:00")
    if date_to:
        where.append("s.finished_at <= ?"); params.append(f"{date_to} 23:59:59")
    from .view_scope import sql as _vs_sql                  # v0.29 บัญชีที่ถูกจำกัดการดู
    vs, vp = _vs_sql("s.form_id")
    if vs:
        where.append(vs[5:]); params += vp
    w = " AND ".join(where)
    total = db.execute(f"SELECT COUNT(*) FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id WHERE {w}",
                       params).fetchone()[0]
    rows = db.execute(f"""
        SELECT s.id, s.form_id, s.finished_at, s.duration_sec, s.ng_count, s.warn_count, s.status,
               s.approval_status, s.source, s.round_id, f.name AS form_name, f.code AS form_code,
               e.code AS eq_code, fa.name AS factory_name, u.name AS inspector_name,
               r.status AS round_status,
               (SELECT COUNT(*) FROM cs_photos p WHERE p.submission_id=s.id) AS photo_count
        FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
        LEFT JOIN equipment e ON e.id=s.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN users u ON u.id=s.inspector_id
        LEFT JOIN cs_rounds r ON r.id=s.round_id
        WHERE {w} ORDER BY s.finished_at DESC, s.id DESC LIMIT ? OFFSET ?""",
        params + [limit, offset]).fetchall()
    return [dict(r) for r in rows], total


# ───────────────────────── approval ─────────────────────────

APPROVER_POSITIONS = ("srtech", "fm", "sv", "ssv", "dm")      # v0.38 ตำแหน่งที่อนุมัติผลตรวจได้ (แม้บทบาทเป็นช่าง)


def can_approve(db, user_id) -> bool:
    """สิทธิ์อนุมัติผลตรวจ: หัวหน้างาน/ผู้ดูแลระบบ · ผู้ที่ผู้ดูแลระบบติ๊กให้ (v0.26) · ตำแหน่ง Sr.Tech/FM/SV/SSV/DM (v0.38)"""
    u = db.execute("SELECT role, active, COALESCE(can_approve, 0) ca, COALESCE(position, '') pos FROM users WHERE id=?",
                   (user_id,)).fetchone() if user_id else None
    return bool(u and u["active"] and (u["role"] in ("admin", "supervisor") or u["ca"] or u["pos"] in APPROVER_POSITIONS))


def _check_approver(db, sub: dict, actor_id: int) -> None:
    actor = user_scope(db, actor_id)
    if actor["role"] not in ("admin", "supervisor") and not can_approve(db, actor_id):
        raise ValidationError("เฉพาะหัวหน้างาน ผู้ดูแลระบบ หรือผู้ที่ได้รับสิทธิ์อนุมัติ")
    if actor["role"] != "admin" and actor.get("factory_id") and sub.get("factory_id") \
            and actor["factory_id"] != sub["factory_id"]:
        raise ValidationError("ผลตรวจนี้อยู่นอกโรงงานที่คุณรับผิดชอบ")
    if sub["status"] != "submitted":
        raise ValidationError("ผลตรวจนี้ถูกตีกลับหรือถูกส่งใหม่แล้ว")


def approve(db, sub_id: int, actor_id: int, note: str = "") -> None:
    sub = get_submission(db, sub_id)
    if not sub:
        raise ValidationError("ไม่พบผลตรวจ")
    _check_approver(db, sub, actor_id)
    if sub["approval_status"] == "approved":
        return
    db.execute("""UPDATE cs_submissions SET approval_status='approved', approved_by=?, approved_at=?,
                  approval_note=? WHERE id=?""", (actor_id, ts(), str(note or "")[:500], sub_id))
    from .anomaly import close_approval
    close_approval(db, sub_id, actor_id, "อนุมัติผลตรวจแล้ว" + (f": {note}" if note else ""))
    audit(db, actor_id, "approve", "cs_submissions", sub_id, after={"note": note})
    from .signoffs import sync_sub
    sync_sub(db, sub_id)                               # v0.26 อนุมัติครบทั้งสัปดาห์ → แถวหัวหน้างานรายสัปดาห์


def return_submission(db, sub_id: int, actor_id: int, note: str) -> None:
    note = str(note or "").strip()
    if len(note) < 3:
        raise ValidationError("กรุณาระบุเหตุผลที่ตีกลับ เพื่อให้ผู้ตรวจแก้ไขได้ถูกต้อง")
    sub = get_submission(db, sub_id)
    if not sub:
        raise ValidationError("ไม่พบผลตรวจ")
    _check_approver(db, sub, actor_id)
    db.execute("""UPDATE cs_submissions SET status='returned', approval_status='rejected', approved_by=?,
                  approved_at=?, approval_note=? WHERE id=?""", (actor_id, ts(), note[:500], sub_id))
    if sub["round_id"]:
        db.execute("UPDATE cs_rounds SET status='returned', updated_at=? WHERE id=? AND submission_id=?",
                   (ts(), sub["round_id"], sub_id))
    from .anomaly import close_approval
    close_approval(db, sub_id, actor_id, f"ตีกลับให้แก้ไข: {note}")
    audit(db, actor_id, "return", "cs_submissions", sub_id, after={"note": note})
    from .signoffs import sync_sub
    sync_sub(db, sub_id)


def auto_pending(db, factory_id=None) -> dict:
    """v0.45 ค่าอัตโนมัติ (SCADA) ที่รอยืนยัน: จำนวน · NG · id ที่ปกติ (ยืนยันแบบกลุ่มได้) · จำนวนเครื่อง"""
    from .view_scope import sql as _vs_sql
    vs, vp = _vs_sql("s.form_id")
    rows = db.execute(f"""SELECT s.id, s.ng_count, s.form_id FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
                          WHERE s.source='auto' AND s.approval_status='pending' AND s.status='submitted'
                            AND (? IS NULL OR f.factory_id=?){vs}""", [factory_id, factory_id] + vp).fetchall()
    return {"total": len(rows), "ng": sum(1 for r in rows if r["ng_count"]), "forms": len({r["form_id"] for r in rows}),
            "ok_ids": [r["id"] for r in rows if not r["ng_count"]]}


def bulk_approve_ok(db, sub_ids: list[int], actor_id: int, note: str = "อนุมัติแบบกลุ่ม (ไม่มี NG)") -> dict:
    done, skipped = 0, 0
    for sid in sub_ids:
        row = db.execute("SELECT ng_count, approval_status, status FROM cs_submissions WHERE id=?", (sid,)).fetchone()
        if not row or row["ng_count"] or row["approval_status"] != "pending" or row["status"] != "submitted":
            skipped += 1
            continue
        try:
            approve(db, sid, actor_id, note)
            done += 1
        except ValidationError:
            skipped += 1
    return {"approved": done, "skipped": skipped}


def pending_counts(db, actor_id: int) -> dict:
    actor = user_scope(db, actor_id)
    params: list[Any] = []
    cond = ""
    if actor["role"] != "admin" and actor.get("factory_id"):
        cond = " AND f.factory_id=?"
        params.append(actor["factory_id"])
    from .view_scope import sql as _vs_sql
    vs, vp = _vs_sql("s.form_id")
    row = db.execute(f"""SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN s.ng_count>0 THEN 1 ELSE 0 END),0) AS ng
                         FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
                         WHERE s.approval_status='pending' AND s.status='submitted' {cond}{vs}""", params + vp).fetchone()
    return {"total": row["total"], "ng": row["ng"]}


# ───────────────────────── ลบผลตรวจ (ผู้ดูแลระบบ / ผู้ที่ได้รับสิทธิ์) ─────────────────────────

def can_delete_results(db, user_id) -> bool:
    """ผู้ดูแลระบบลบได้เสมอ · ผู้ใช้อื่นต้องได้รับสิทธิ์ 'ลบผลตรวจ' จากผู้ดูแลระบบ"""
    if not user_id:
        return False
    u = db.execute("SELECT role, active, can_delete_results FROM users WHERE id=?", (user_id,)).fetchone()
    return bool(u and u["active"] and (u["role"] == "admin" or u["can_delete_results"]))


def delete_submissions(db, ids: list[int], actor_id, reason: str, check_perm: bool = True) -> dict:
    """ลบผลตรวจถาวร (คำตอบ รูป และการอ้างอิง) พร้อมบันทึก Audit Trail ทั้งฉบับ

    - รอบตรวจที่ผูกกับผลตรวจนี้กลับเป็น "ยังไม่ตรวจ" (ถ้าเลยเวลาปิดรอบแล้วจะเป็น "ขาดตรวจ")
    - งานแก้ไข (CAPA) / แจ้งเตือนที่สร้างจากผลตรวจนี้ยังอยู่ (ตัดการอ้างอิง + บันทึกเหตุผล)
    - คืนรายการรูปที่ต้องย้ายไป uploads/_deleted/ (เรียก trash_photos หลัง commit) ยกเว้นรูปที่งานแก้ไขยังใช้อยู่
    """
    from .analytics import refresh_daily_stats
    reason = str(reason or "").strip()
    if len(reason) < 3:
        raise ValidationError("กรุณาระบุเหตุผลที่ลบ (อย่างน้อย 3 ตัวอักษร)")
    if check_perm and not can_delete_results(db, actor_id):
        raise ValidationError("คุณไม่มีสิทธิ์ลบผลตรวจ — ติดต่อผู้ดูแลระบบ")
    ids = sorted({int(i) for i in ids if str(i).isdigit() or isinstance(i, int)})
    if not ids:
        raise ValidationError("ยังไม่ได้เลือกผลตรวจ")
    now = S.now_dt()
    stamp = ts(now)
    moved, days, deleted = [], set(), 0
    for sid in ids:
        s = db.execute("SELECT * FROM cs_submissions WHERE id=?", (sid,)).fetchone()
        if not s:
            continue
        s = dict(s)
        answers = [dict(r) for r in db.execute("SELECT * FROM cs_answers WHERE submission_id=?", (sid,))]
        photos = [dict(r) for r in db.execute("SELECT * FROM cs_photos WHERE submission_id=?", (sid,))]
        S.audit(db, actor_id, "delete", "cs_submissions", sid,
                before={"submission": s, "answers": answers, "photos": [p["file_path"] for p in photos]},
                after={"reason": reason[:500]})
        for p in photos:
            still_used = db.execute("SELECT 1 FROM cs_action_photos WHERE file_path=?", (p["file_path"],)).fetchone()
            if not still_used:
                moved.append(p["file_path"])
        db.execute("DELETE FROM cs_photos WHERE submission_id=?", (sid,))
        db.execute("DELETE FROM cs_answers WHERE submission_id=?", (sid,))
        note = f"ผลตรวจ #{sid} ถูกลบ: {reason[:200]}"
        from .anomaly import close_approval
        close_approval(db, sid, actor_id, note)
        for a in db.execute("SELECT id FROM cs_alerts WHERE submission_id=?", (sid,)).fetchall():
            db.execute("INSERT INTO cs_alert_events(alert_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
                       (a["id"], "comment", actor_id, note, stamp))
        db.execute("UPDATE cs_alerts SET submission_id=NULL WHERE submission_id=?", (sid,))
        for c in db.execute("SELECT id FROM cs_actions WHERE submission_id=?", (sid,)).fetchall():
            db.execute("INSERT INTO cs_action_events(action_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
                       (c["id"], "comment", actor_id, note, stamp))
        db.execute("UPDATE cs_actions SET submission_id=NULL WHERE submission_id=?", (sid,))
        db.execute("UPDATE cs_submissions SET resubmit_of=NULL WHERE resubmit_of=?", (sid,))
        # ถ้าลบฉบับส่งใหม่ ฉบับเดิมที่ถูกแทนกลับมาเป็นฉบับที่ใช้ (สถานะตีกลับ)
        if s.get("resubmit_of"):
            db.execute("UPDATE cs_submissions SET status='returned' WHERE id=? AND status='superseded'", (s["resubmit_of"],))
        db.execute("UPDATE cs_rounds SET submission_id=NULL, status='pending', updated_at=? WHERE submission_id=?", (stamp, sid))
        db.execute("DELETE FROM cs_submissions WHERE id=?", (sid,))
        d = S.parse_ts(s["finished_at"]) or now
        days.add(d.date())
        from .signoffs import sync_sub
        sync_sub(db, None, s["form_id"], s["finished_at"])
        if s.get("resubmit_of"):
            sync_sub(db, s["resubmit_of"])
        deleted += 1
    S.refresh_round_statuses(db, now)
    for d in days:
        refresh_daily_stats(db, d, d)
    return {"deleted": deleted, "photos": moved}


def trash_photos(upload_dir: str, rels: list[str]) -> int:
    """ย้ายรูปของผลตรวจที่ลบไป uploads/_deleted/<วันที่>/ — เรียกหลัง commit แล้วเท่านั้น"""
    trash = os.path.join(upload_dir, "_deleted", S.now_dt().strftime("%Y%m%d"))
    n = 0
    for rel in rels:
        src = os.path.join(upload_dir, rel)
        if not os.path.exists(src):
            continue
        try:
            os.makedirs(trash, exist_ok=True)
            os.replace(src, os.path.join(trash, rel.replace("/", "_")))
            n += 1
        except OSError:
            pass
    return n
