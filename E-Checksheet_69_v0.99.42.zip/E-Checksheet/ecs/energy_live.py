"""ecs/energy_live.py — v0.87 Dashboard รายช่วงเวลา (ทุก 15 นาที) แยกตามแหล่งพลังงาน

Sum ค่าต่อช่วงจาก en_intervals ตามระดับ โรงงาน › Project › Section › Line › มิเตอร์
- โหลดรายวัน 96 ช่วง (15 นาที) + เทียบเมื่อวาน / สัปดาห์ก่อน
- Stacked ตามระดับถัดไป (Top 8 + อื่น ๆ)
- Heatmap วัน × เวลา ทั้งเดือน
- ตาราง drill-down (กดลงระดับถัดไป)
"""
from __future__ import annotations

import calendar
from datetime import date, datetime, time, timedelta

from . import energy as EN
from . import energy_interval as EI
from .services import ts

SLOT_MIN = 15
NSLOT = 24 * 60 // SLOT_MIN
LEVELS = ("factory", "project", "grp", "line", "meter")
LEVEL_TH = {"factory": "โรงงาน", "project": "Project", "grp": "Section", "line": "Line", "meter": "มิเตอร์"}
TOP_N = 8
LIVE_KINDS = [k for k in EN.KIND_ORDER if k != "hours"]


def slot_labels() -> list[str]:
    return [f"{(i * SLOT_MIN) // 60:02d}:{(i * SLOT_MIN) % 60:02d}" for i in range(NSLOT)]


def _level(fid, project_id, grp, line) -> str:
    if line:
        return "meter"
    if grp:
        return "line"
    if project_id:
        return "grp"
    if fid:
        return "project"
    return "factory"


def _key(m: dict, level: str) -> tuple:
    """(key, ชื่อ, สี, พารามิเตอร์ drill-down)"""
    if level == "factory":
        return (m.get("factory_id"), m.get("factory_name") or "ไม่ระบุโรงงาน", None, {"factory": m.get("factory_id")})
    if level == "project":
        pid = m.get("project_id") or -1
        return (pid, m.get("project_name") or "ยังไม่กำหนด Project", m.get("project_color"), {"project": pid})
    if level == "grp":
        g = m.get("grp") or ""
        return (g, g or "ไม่ระบุ Section", None, {"grp": g or "-"})
    if level == "line":
        ln = m.get("line") or ""
        return (ln, ln or "ไม่ระบุ Line", None, {"line": ln or "-"})
    return (m["id"], EN.label(m), None, {"meter": m["id"]})


def _sums(db, ids: list[int], a: datetime, b: datetime) -> dict[int, list[float | None]]:
    """{meter_id: [ค่าต่อช่วง 15 นาที × 96]} ของช่วง [a, b) — ช่วงที่ไม่มีค่า = None"""
    out: dict[int, list] = {}
    for i in range(0, len(ids), 800):
        ch = ids[i:i + 800]
        for mid, stamp, v in db.execute(
                f"""SELECT meter_id, ts, value FROM en_intervals WHERE ts>=? AND ts<? AND meter_id IN ({','.join('?' * len(ch))})""",
                [ts(a), ts(b), *ch]):
            k = (int(stamp[11:13]) * 60 + int(stamp[14:16])) // SLOT_MIN
            row = out.setdefault(mid, [None] * NSLOT)
            row[k] = (row[k] or 0.0) + v
    rest = [i for i in ids if i not in out]                  # v0.99.41 มิเตอร์แบบเลขสะสม → ผลต่างราย 15 นาทีจาก en_profile
    if rest:
        from . import energy_profile as PR
        out.update(PR.slots(db, rest, a, b))
    return out


def _add(acc: list, row: list) -> None:
    for i, v in enumerate(row):
        if v is not None:
            acc[i] = (acc[i] or 0.0) + v


def _resolution(series: list) -> int:
    """ความละเอียดของข้อมูล (นาที) จากช่วงที่มีค่า: 15 / 30 / 60 …"""
    idx = [i for i, v in enumerate(series) if v is not None]
    if len(idx) < 2:
        return SLOT_MIN
    gaps = [b - a for a, b in zip(idx, idx[1:]) if b > a]
    return SLOT_MIN * (min(gaps) if gaps else 1)


def data(db, kind: str, day: date, fid=None, project_id=None, grp=None, line=None, cmp: str = "yday") -> dict:
    EI.ensure(db)
    kind = kind if kind in EN.KINDS else "elec"
    meta = EN.KINDS[kind]
    ms_all = EN.meters(db, fid, kind, True, project_id, grp, line)
    # กันนับซ้ำ: มีมิเตอร์ย่อย → รวมเฉพาะมิเตอร์ย่อย (เหมือนรายงานรายวัน) · มิเตอร์ "หักออก" ไม่รวม
    ms = [m for m in EN.counted(ms_all) if m["is_main"] != -1]      # v0.90 กติกาเดียวทั้งระบบ (ค่าต่อช่วงไม่หัก Solar)
    level = _level(fid, project_id, grp, line)
    ids = [m["id"] for m in ms]
    a = datetime.combine(day, time(0, 0))
    per = _sums(db, ids, a, a + timedelta(days=1)) if ids else {}
    total = [None] * NSLOT
    for row in per.values():
        _add(total, row)
    cday = day - timedelta(days=7 if cmp == "week" else 1)
    ca = datetime.combine(cday, time(0, 0))
    cmp_total = [None] * NSLOT
    for row in (_sums(db, ids, ca, ca + timedelta(days=1)) if ids else {}).values():
        _add(cmp_total, row)
    res = _resolution(total) if any(v is not None for v in total) else SLOT_MIN
    rate = 60 / res                                         # ค่าต่อช่วง → ต่อชั่วโมง (kW / m³/h)
    # ── กลุ่มตามระดับถัดไป ──
    groups: dict = {}
    for m in ms:
        k, name, color, q = _key(m, level)
        g = groups.setdefault(k, {"key": k, "name": name, "color": color, "q": q, "series": [None] * NSLOT, "n": 0, "n_data": 0,
                                  "meter_id": m["id"] if level == "meter" else None})
        g["n"] += 1
        if m["id"] in per:
            g["n_data"] += 1
            _add(g["series"], per[m["id"]])
    tot_sum = sum(v for v in total if v is not None)
    rows = []
    for g in groups.values():
        s = sum(v for v in g["series"] if v is not None)
        pk = max((v for v in g["series"] if v is not None), default=None)
        rows.append({**{k: g[k] for k in ("key", "name", "color", "q", "n", "n_data", "meter_id")}, "sum": s,
                     "share": round(100 * s / tot_sum, 1) if tot_sum else 0.0, "peak_rate": pk * rate if pk is not None else None,
                     "hourly": [sum(v for v in g["series"][h * 4:(h + 1) * 4] if v is not None) for h in range(24)]})
    rows.sort(key=lambda r: (-r["sum"], str(r["name"])))
    ranked = [g for g in sorted(groups.values(), key=lambda g: -sum(v for v in g["series"] if v is not None))
              if any(v is not None for v in g["series"])]
    stack = [{"name": g["name"], "color": g["color"], "data": [round(v, 3) if v is not None else 0 for v in g["series"]]} for g in ranked[:TOP_N]]
    if len(ranked) > TOP_N:
        other = [0.0] * NSLOT
        for g in ranked[TOP_N:]:
            for i, v in enumerate(g["series"]):
                other[i] += v or 0.0
        stack.append({"name": f"อื่น ๆ ({len(ranked) - TOP_N})", "color": None, "data": [round(v, 3) for v in other], "other": True})
    # ── KPI ──
    vals = [(i, v) for i, v in enumerate(total) if v is not None]
    peak = max(vals, key=lambda x: x[1]) if vals else None
    cmp_sum = sum(v for v in cmp_total if v is not None)
    last_slot = max((i for i, _ in vals), default=None)
    cmp_same = sum(v for i, v in enumerate(cmp_total) if v is not None and last_slot is not None and i <= last_slot)
    from . import energy_profile as PR
    last_ts = PR.last_ts(db, ids) if ids else None
    if ids:
        for i in range(0, len(ids), 800):
            ch = ids[i:i + 800]
            r = db.execute(f"SELECT MAX(ts) FROM en_intervals WHERE meter_id IN ({','.join('?' * len(ch))})", ch).fetchone()[0]
            if r and (not last_ts or r > last_ts):
                last_ts = r
    kpi = {"sum": tot_sum, "peak": peak[1] * rate if peak else None, "peak_at": slot_labels()[peak[0]] if peak else None,
           "avg": (tot_sum / len(vals)) * rate if vals else None, "cmp_sum": cmp_sum, "cmp_same": cmp_same,
           "diff_pct": round(100 * (tot_sum - cmp_same) / cmp_same, 1) if cmp_same else None,
           "n": len(ms), "n_data": sum(1 for m in ms if m["id"] in per), "res": res, "last_ts": last_ts,
           "n_main": len(ms_all) - len(ms)}
    if last_slot is not None:                                 # v0.99.41 ชั่วโมงล่าสุดที่มีข้อมูล + ชั่วโมงก่อนหน้า (เทียบช่วงเดียวกันของวันที่เทียบ)
        h0 = last_slot // 4 * 4

        def _s(arr, i0, i1):
            xs = [v for v in arr[max(i0, 0):i1] if v is not None]
            return sum(xs) if xs else None
        hr, hr_c = _s(total, h0, last_slot + 1), _s(cmp_total, h0, last_slot + 1)
        kpi.update({"hour": hr, "hour_lbl": f"{h0 // 4:02d}:00–{slot_labels()[last_slot + 1] if last_slot + 1 < NSLOT else '24:00'}",
                    "hour_cmp": hr_c, "hour_pct": round(100 * (hr - hr_c) / hr_c, 1) if hr is not None and hr_c else None,
                    "prev_hour": _s(total, h0 - 4, h0) if h0 else None, "prev_hour_lbl": f"{max(h0 // 4 - 1, 0):02d}:00–{h0 // 4:02d}:00"})
    # ── v0.88 Target ต่อวันของระดับที่กำลังดู ──
    try:
        from . import energy_summary as SMY
        lv, key = (("line", f"{grp or '-'}|{line}") if line else ("grp", grp) if grp else ("project", str(project_id)) if project_id
                   else ("factory", str(fid)) if fid else (None, None))
        tg = SMY.target_for(db, kind, lv, key, fid, ms_all, day) if lv and ms_all else {"daily": None, "src": None}
    except Exception:                                     # noqa: BLE001
        tg = {"daily": None, "src": None}
    kpi["target"] = tg["daily"]
    kpi["target_src"] = tg["src"]
    kpi["target_pct"] = round(100 * tot_sum / tg["daily"], 1) if tg["daily"] else None
    # ── Heatmap ทั้งเดือน (วัน × ช่วงเวลา) ──
    first = day.replace(day=1)
    last_d = calendar.monthrange(day.year, day.month)[1]
    heat, hmax = [], 0.0
    if ids:
        hm: dict[tuple[int, int], float] = {}
        ha = datetime.combine(first, time(0, 0))
        for i in range(0, len(ids), 800):
            ch = ids[i:i + 800]
            for d_, hhmm, v in db.execute(
                    f"""SELECT CAST(substr(ts, 9, 2) AS INTEGER), substr(ts, 12, 5), SUM(value) FROM en_intervals
                        WHERE ts>=? AND ts<? AND meter_id IN ({','.join('?' * len(ch))}) GROUP BY substr(ts, 1, 16)""",
                    [ts(ha), ts(ha + timedelta(days=last_d)), *ch]):
                k = (d_, (int(hhmm[:2]) * 60 + int(hhmm[3:5])) // SLOT_MIN)
                hm[k] = hm.get(k, 0.0) + (v or 0.0)
        prof_ids = [i for i in ids if not db.execute("SELECT 1 FROM en_intervals WHERE meter_id=? LIMIT 1", (i,)).fetchone()]
        if prof_ids:                                          # v0.99.41 มิเตอร์แบบเลขสะสม
            per_d = PR.slots(db, prof_ids, ha, ha + timedelta(days=last_d))
            for row in per_d.values():
                for i_, v in enumerate(row):
                    if v is not None:
                        k = (i_ // NSLOT + 1, i_ % NSLOT)
                        hm[k] = hm.get(k, 0.0) + v
        for (d_, s_), v in hm.items():
            heat.append([s_, d_ - 1, round(v, 3)])
            hmax = max(hmax, v)
    return {"kind": kind, "meta": meta, "unit": meta["unit"], "rate_unit": "kW" if kind == "elec" else f"{meta['unit']}/ชม.",
            "day": day.isoformat(), "cmp_day": cday.isoformat(), "cmp": cmp, "level": level, "level_th": LEVEL_TH[level],
            "slots": slot_labels(), "total": [round(v, 3) if v is not None else None for v in total],
            "cmp_total": [round(v, 3) if v is not None else None for v in cmp_total], "rate": rate,
            "stack": stack, "rows": rows, "kpi": kpi, "heat": heat, "heat_max": hmax,
            "heat_days": [f"{d:02d}" for d in range(1, last_d + 1)], "month": first.isoformat()}


def has_intervals(db) -> dict[str, int]:
    """จำนวนมิเตอร์ที่มีค่าต่อช่วงเวลา แยกหมวด (ใช้แสดงแท็บ / ข้อความแนะนำ)"""
    from . import energy_profile as PR
    EI.ensure(db)
    out = {r[0]: r[1] for r in db.execute("""SELECT m.kind, COUNT(DISTINCT m.id) FROM en_meters m
                                              WHERE EXISTS (SELECT 1 FROM en_intervals i WHERE i.meter_id=m.id) GROUP BY m.kind""")}
    for k, n in PR.has_profile(db).items():                  # v0.99.41 + มิเตอร์แบบเลขสะสม
        out[k] = out.get(k, 0) + n
    return out
