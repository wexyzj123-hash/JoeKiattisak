"""v0.99.42: Energy — ดึงข้อมูลจาก SQL ครบไม่ตกหล่น
· ทุกฟังก์ชันที่ดึงช่วงเวลา (เติมค่ารายวัน / ประมาณค่า / ค่าราย 15 นาที / ค่าต่อช่วง / ตรวจวินิจฉัย) อ่านต่อเป็นชุดเมื่อถึงเพดานแถว
· ค่าราย 15 นาทีเติมเฉพาะมิเตอร์ที่ยังขาด (เดิม: ขาดไม่ถึง 10% ไม่เติม) ย้อนหลัง 35 วัน · แหล่งค่าต่อช่วงเติมช่วงที่ขาดเอง
· หน้าแหล่งข้อมูลแสดงความครบถ้วน 14 วัน + ปุ่มดึงวันนั้นใหม่"""
import json
import sqlite3
from datetime import datetime, time, timedelta

from conftest import login
from ecs import connectors as CN
from ecs import energy as EN
from ecs import energy_profile as PR
from ecs import energy_src as ES
from ecs import services as S

RATE = 40.0


def _plant(app, db, tmp_path, n_tags=12, days=3, kind="reading", late_tags=0, late_h=5):
    """SQL จำลอง: Tag × ค่าทุก 15 นาที (เลขสะสม หรือ ค่าต่อช่วง) · late_tags ตัวท้ายเขียนช้า late_h ชม. (คืน: แถวที่ยังไม่ปรากฏ)"""
    now = S.now_dt().replace(second=0, microsecond=0)
    end = now - timedelta(minutes=now.minute % 15)
    start = datetime.combine((end - timedelta(days=days)).date(), time(0, 0))
    path = str(tmp_path / "plant.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE T (TagName TEXT, LogTime TEXT, Value REAL)")
    tags = [f"PM{i:02d}" for i in range(n_tags)]
    held = []
    t = start
    while t <= end:
        for i, tg in enumerate(tags):
            v = RATE / 4 if kind == "interval" else 1000.0 * (i + 1) + RATE * (t - start).total_seconds() / 3600
            row = (tg, t.strftime("%Y-%m-%d %H:%M:%S"), v)
            if i >= n_tags - late_tags and t > end - timedelta(hours=late_h):
                held.append(row)
            else:
                con.execute("INSERT INTO T VALUES (?,?,?)", row)
        t += timedelta(minutes=15)
    con.commit()
    con.close()
    data = {"name": "SQL", "kind": "sqlite", "active": "1", "config": json.dumps({
        "path": path, "query": "SELECT TagName AS tag, LogTime AS ts, Value AS value FROM T WHERE LogTime > ? ORDER BY LogTime", "backfill_days": 1})}
    if kind == "interval":
        data["value_kind"] = "interval"
    sid = ES.save_source(db, data, None)
    ms = {tg: EN.save_meter(db, None, {"factory_id": app.config["F1"], "kind": "elec", "code": tg, "name": tg,
                                       "scada_source_id": str(sid), "scada_tag": tg}, None) for tg in tags}
    db.commit()
    return now, start, end, path, sid, ms, held


def test_fetch_all_pages_past_row_cap(app, db, tmp_path, monkeypatch):
    now, start, _end, _p, sid, _ms, _h = _plant(app, db, tmp_path, n_tags=12, days=2)
    monkeypatch.setattr(CN, "MAX_ROWS", 50)
    src = ES.get_source(db, sid)
    a, b = start + timedelta(days=1), start + timedelta(days=2)
    one, _k, _b = ES.fetch(db, dict(src), now, tags=None, since=a, until=b)
    rows, _k, _b = ES.fetch_all(db, dict(src), now, tags=None, since=a, until=b)
    assert len(one) <= 50                                                     # เดิม: ได้แค่ชุดแรก
    assert len(rows) == 12 * 96 and len({(r[0], r[1]) for r in rows}) == len(rows)   # ครบทุกแถว ไม่ซ้ำ
    assert rows == sorted(rows, key=lambda r: r[1])


def test_profile_and_daily_complete_with_small_row_cap(app, db, tmp_path, monkeypatch):
    _now, start, end, _p, sid, ms, _h = _plant(app, db, tmp_path, n_tags=12, days=3)
    monkeypatch.setattr(CN, "MAX_ROWS", 60)
    for k in range(6):                                                        # รอบดึงปกติไม่กี่รอบ → เติมย้อนหลังเองจนครบ
        ES.run_source(db, sid, now=end + timedelta(minutes=2 + k))
        db.execute("UPDATE en_sources SET last_heal_at=NULL")
        db.commit()
    a = start + timedelta(minutes=15)
    b = end - timedelta(minutes=30)
    sl = PR.slots(db, list(ms.values()), a, b)
    n = int((b - a).total_seconds() // 900)
    assert all(len([v for v in sl[m] if v is not None]) == n for m in ms.values())
    assert all(abs(v - RATE / 4) < 1e-6 for m in ms.values() for v in sl[m])
    comp = ES.completeness(db, sid, days=3, now=end + timedelta(minutes=2))
    assert all(c["pct"] == 100.0 for c in comp[:2]) and all(not c["rd_miss"] for c in comp if c["rd_due"])


def test_profile_late_tags_refilled_even_when_gap_is_small(app, db, tmp_path):
    _now, _start, end, path, sid, ms, held = _plant(app, db, tmp_path, n_tags=20, days=2, late_tags=1, late_h=4)
    clock = end + timedelta(minutes=2)
    ES.run_source(db, sid, now=clock)
    db.commit()
    late = ms["PM19"]
    assert PR.gaps(db, [late], end.date(), clock) == {late}                  # ยังขาด 4 ชม. ล่าสุด (มาช้า)
    con = sqlite3.connect(path)                                               # ข้อมูลมาถึงทีหลัง (เกินช่วงย้อนทับปกติ)
    con.executemany("INSERT INTO T VALUES (?,?,?)", held)
    con.commit()
    con.close()
    later = clock + timedelta(hours=1, minutes=5)
    ES.run_source(db, sid, now=later)
    db.commit()
    assert not PR.gaps(db, list(ms.values()), end.date(), end + timedelta(minutes=30))   # ครบทุกมิเตอร์ถึงค่าล่าสุดใน SQL (เดิม: ขาด < 10% ไม่เติม)


def test_interval_source_heals_late_rows(app, db, tmp_path):
    _now, _start, end, path, sid, ms, held = _plant(app, db, tmp_path, n_tags=6, days=2, kind="interval", late_tags=2, late_h=5)
    clock = end + timedelta(minutes=2)
    ES.run_source(db, sid, now=clock)
    db.commit()
    con = sqlite3.connect(path)
    con.executemany("INSERT INTO T VALUES (?,?,?)", held)
    con.commit()
    con.close()
    db.execute("UPDATE en_sources SET last_heal_at=NULL")
    later = clock + timedelta(hours=1, minutes=5)
    ES.run_source(db, sid, now=later)
    db.commit()
    for tg in ("PM04", "PM05"):
        n = db.execute("SELECT COUNT(*) FROM en_intervals WHERE meter_id=? AND ts>=? AND ts<=?",
                       (ms[tg], S.ts(end - timedelta(hours=5)), S.ts(end))).fetchone()[0]
        assert n == 21, (tg, n)                                               # ค่าที่มาช้า 5 ชม. ถูกเติมครบ


def test_source_page_completeness_and_refetch_day(app, db, client, tmp_path):
    now, _start, _end, _p, sid, ms, _h = _plant(app, db, tmp_path, n_tags=4, days=3)
    ES.run_source(db, sid, now=now)
    yd = (now - timedelta(days=1)).date()
    db.execute("DELETE FROM en_profile WHERE meter_id=? AND ts LIKE ?", (ms["PM01"], yd.isoformat() + " 1%"))
    db.commit()
    tok = login(client, "t_admin")
    html = client.get(f"/energy/sources/{sid}").get_data(as_text=True)
    assert 'id="complete"' in html and "ความครบถ้วนของข้อมูล 14 วัน" in html and "ดึงวันนี้ใหม่" in html
    c = {x["day"]: x for x in ES.completeness(db, sid, now=now)}
    assert c[yd]["pct"] < 100 and ms["PM01"] in c[yd]["gap_ids"]
    r = client.post(f"/energy/sources/{sid}/backfill", data={"csrf_token": tok, "from": yd.isoformat(), "to": yd.isoformat(),
                                                              "mode": "fill", "back": "complete"})
    assert r.status_code in (302, 303) and r.headers["Location"].endswith("#complete")
    c = {x["day"]: x for x in ES.completeness(db, sid, now=now)}
    assert c[yd]["pct"] == 100.0 and not c[yd]["gap_ids"]
