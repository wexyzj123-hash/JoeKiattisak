"""v0.99.2: ผังพื้นที่และสถานะ (หน้าภาพรวม) แบบใหม่ — หมุดมีสัญลักษณ์ · ชิปกรอง · รายการเรียงตามความเร่งด่วน · แถบรายละเอียด"""
import re

from conftest import login


def _render(app, areas, fac=None, admin=False):
    from flask import render_template_string
    fac = fac or {"id": 1, "name": "Factory 1", "code": "F1", "layout_image": "layouts/x.png"}
    with app.test_request_context("/dashboard"):
        from flask import session
        if admin:
            session["role"] = "admin"
        return render_template_string(
            '{% from "dash/_macros.html" import plant_map2 with context %}{{ plant_map2(fac, areas) }}', fac=fac, areas=areas)


def _area(i, name, status, **kw):
    d = {"id": i, "name": name, "factory_id": 1, "factory_name": "Factory 1", "map_x": 10.0 + i * 5, "map_y": 30.0, "eq_count": 3,
         "rounds": 4, "done": 2, "done_pct": 50, "alerts_open": 0, "status": status,
         "status_th": {"critical": "เร่งแก้ไข", "warning": "ต้องติดตาม", "good": "ปกติ", "none": "ไม่มีรอบตรวจ"}[status], "reason": ""}
    d.update(kw)
    return d


def test_rows_sorted_by_urgency_and_all_areas_listed(app):
    areas = [_area(1, "Z-good", "good"), _area(2, "B-warn", "warning", alerts_open=1, reason="NG 1"),
             _area(3, "N-none", "none", rounds=0, done=0, done_pct=None), _area(4, "A-crit", "critical", alerts_open=3, reason="ขาดตรวจ 1"),
             _area(5, "C-warn", "warning", alerts_open=4, reason="เลยกำหนด 2"), _area(6, "Unplaced", "good", map_x=None, map_y=None)]
    html = _render(app, areas)
    rows = re.findall(r'class="pm2-row st-(\w+)"[^>]*data-name="([^"]+)"', html)
    assert [n for _, n in rows] == ["A-crit", "C-warn", "B-warn", "Z-good", "Unplaced", "N-none"]     # วิกฤต → เตือน (มากแจ้งเตือนก่อน) → ปกติ → ไม่มีรอบ
    assert len(rows) == 6                                                                           # ครบทุกพื้นที่ รวมที่ยังไม่วางหมุด
    pins = re.findall(r'class="pm2-pin st-(\w+)( att)?"', html)
    assert len(pins) == 5 and sum(1 for _, a in pins if a) == 3                                      # ไม่วางหมุด = ไม่มีหมุด · att เฉพาะวิกฤต/เตือน
    assert "ยังไม่วางหมุด" in html and 'href="/areas/4/map"' in html
    assert 'left:15.0%' in html or 'left:20.0%' in html


def test_pin_has_symbol_and_aria_not_color_only(app):
    html = _render(app, [_area(1, "A", "critical", reason="ขาดตรวจ 1"), _area(2, "B", "warning"), _area(3, "C", "good"), _area(4, "D", "none")])
    for glyph in ("✕", "!", "✓"):
        assert f'<span class="pm2-dot" aria-hidden="true">{glyph}</span>' in html
    assert 'aria-label="A — เร่งแก้ไข: ขาดตรวจ 1"' in html


def test_no_image_factory_falls_back_to_tiles(app):
    html = _render(app, [_area(1, "A", "good", map_x=None)], fac={"id": 1, "name": "F", "code": "F1", "layout_image": ""})
    assert "pm2-tiles" in html and "pm2-canvas" not in html and 'class="pm2-row st-good"' in html


def test_dashboard_card_chips_and_old_editor_untouched(client):
    login(client, "t_admin")
    html = client.get("/dashboard").get_data(as_text=True)
    assert 'id="pm2"' in html and len(re.findall(r'class="pm2-chip[ "]', html)) == 5 and "js/plantmap.js" in html
    for k in ("all", "critical", "warning", "good", "none"):
        assert f'data-flt="{k}"' in html
    assert "pin_legend" not in html and 'class="area-sum"' not in html                              # คำอธิบายสี/ตัวเลขเดิมรวมเป็นชิปแล้ว
    assert "ต้องติดตาม = เลยกำหนด" in html                                                           # ความหมายสถานะยังอยู่ (คำอธิบายใต้ผัง)
    ed = client.get("/admin/layout").get_data(as_text=True)                                          # หน้าแก้ไขผังยังใช้หมุดเดิม
    assert "pm2-pin" not in ed


def test_pin_and_row_links_keep_area_map_url(client, db):
    login(client, "t_admin")
    html = client.get("/dashboard").get_data(as_text=True)
    for aid in re.findall(r'class="pm2-row[^"]*" data-area="(\d+)"', html):
        assert f'href="/areas/{aid}/map"' in html
