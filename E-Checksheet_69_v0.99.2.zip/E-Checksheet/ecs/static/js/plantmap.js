/* v0.99.2 ผังพื้นที่และสถานะ (หน้าภาพรวม): ชิปกรอง · เลือก/วางเมาส์ซิงก์ผังกับรายการ · แถบรายละเอียด · จัดป้ายชื่อไม่ให้ชนกัน · ขยายเต็มจอ
   ไม่ต้องเรียกเซิร์ฟเวอร์เพิ่ม — ใช้ข้อมูลที่ฝังในหน้า (data-*) */
(function () {
  'use strict';
  const card = document.getElementById('pm2');
  if (!card) return;
  const $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));
  const T = { critical: 'เร่งแก้ไข', warning: 'ต้องติดตาม', good: 'ปกติ', none: 'ไม่มีรอบตรวจ' };
  let flt = 'all';

  const pane = () => $$('.map-pane', card).find((p) => !p.hidden) || card;
  const same = (p, id) => $$('[data-area="' + id + '"]', p);

  function counts() {
    const p = pane(), c = { critical: 0, warning: 0, good: 0, none: 0 };
    $$('.pm2-row', p).forEach((r) => { c[r.dataset.st] = (c[r.dataset.st] || 0) + 1; });
    c.all = c.critical + c.warning + c.good + c.none;
    $$('.pm2-chip', card).forEach((b) => { const n = b.querySelector('[data-n]'); if (n) n.textContent = c[b.dataset.flt]; });
    return c;
  }

  function apply() {
    const p = pane(), c = counts();
    $$('.pm2-row', p).forEach((r) => {
      const st = r.dataset.st, show = flt === 'all' ? (st === 'critical' || st === 'warning') : st === flt;
      r.parentNode.hidden = !show;
    });
    $$('.pm2-pin, .pm2-tiles .pm-tile', p).forEach((e) => e.classList.toggle('dim', flt !== 'all' && e.dataset.st !== flt));
    const att = c.critical + c.warning;
    const title = p.querySelector('[data-f="listtitle"]'), foot = p.querySelector('[data-f="foot"]');
    if (title) title.textContent = flt === 'all' ? 'ต้องดูตอนนี้ (' + att + ')' : T[flt] + ' (' + c[flt] + ')';
    if (foot) {
      foot.textContent = flt === 'all'
        ? (att ? '' : 'ไม่มีพื้นที่ที่ต้องติดตาม · ') + 'ปกติ ' + c.good + ' · ไม่มีรอบตรวจ ' + c.none + ' พื้นที่ (กดชิปด้านบนเพื่อดู)'
        : 'กดแถวเพื่อเลือกหมุดบนผัง · กด “ทั้งหมด” เพื่อกลับ';
    }
    const ul = p.querySelector('.pm2-list');
    if (ul) { let em = ul.querySelector('.pm2-empty'); const any = $$('li', ul).some((li) => !li.hidden && !li.classList.contains('pm2-empty'));
      if (!any) { if (!em) { em = document.createElement('li'); em.className = 'pm2-empty small muted'; ul.appendChild(em); } em.hidden = false; em.textContent = flt === 'all' ? 'ไม่มีพื้นที่ที่ต้องติดตาม' : 'ไม่มีพื้นที่ในสถานะนี้'; }
      else if (em) em.hidden = true; }
  }

  function select(id, p) {
    p = p || pane();
    $$('.sel', p).forEach((e) => e.classList.remove('sel'));
    const els = same(p, id); if (!els.length) return;
    els.forEach((e) => e.classList.add('sel'));
    const row = els.find((e) => e.classList.contains('pm2-row')); if (!row) return;
    const d = p.querySelector('[data-detail]'); if (!d) return;
    const f = (k) => d.querySelector('[data-f="' + k + '"]'), st = row.dataset.st;
    d.dataset.st = st;
    f('sym').textContent = row.dataset.sym || '–';
    f('name').textContent = row.dataset.name;
    f('reason').textContent = row.dataset.sth + ' · ' + row.dataset.reason;
    f('rounds').textContent = row.dataset.rounds; f('eq').textContent = row.dataset.eq; f('alerts').textContent = row.dataset.alerts;
    f('open').href = row.getAttribute('href'); f('eqs').href = row.dataset.eqhref || '#';
  }

  function selectFirst(p) {
    p = p || pane();
    if (p.querySelector('.sel.pm2-row') && !p.querySelector('.sel.pm2-row').parentNode.hidden) return;
    const r = $$('.pm2-row', p).find((x) => !x.parentNode.hidden) || $$('.pm2-row', p)[0];
    if (r) select(r.dataset.area, p);
  }

  // จัดป้ายชื่อของพื้นที่ที่ต้องดู: ลอง ขวา → ซ้าย → บน → ล่าง เลือกอันแรกที่ไม่ชนป้ายอื่น/หมุดอื่น และไม่ล้นผัง
  function layoutLabels() {
    $$('.pm2-canvas', card).forEach((cv) => {
      if (!cv.offsetWidth) return;
      const box = cv.getBoundingClientRect();
      const pins = $$('.pm2-pin', cv);
      pins.forEach((p) => { p.classList.remove('lab-r', 'lab-l', 'lab-t', 'lab-b', 'nolabel'); });
      const dots = pins.map((p) => p.querySelector('.pm2-dot').getBoundingClientRect());
      const fb = cv.querySelector('.pm2-full'); const fullBtn = fb && !fb.hidden ? fb.getBoundingClientRect() : null;   // ป้ายต้องไม่ทับปุ่มเต็มจอ
      const placed = [];
      const hit = (r, q) => !(r.right < q.left - 3 || r.left > q.right + 3 || r.bottom < q.top - 3 || r.top > q.bottom + 3);
      const inside = (r) => r.left >= box.left + 2 && r.right <= box.right - 2 && r.top >= box.top + 2 && r.bottom <= box.bottom - 2;
      pins.filter((p) => p.classList.contains('att') && !p.classList.contains('dim'))
        .sort((a, b) => (a.dataset.st === 'critical' ? 0 : 1) - (b.dataset.st === 'critical' ? 0 : 1))
        .forEach((p) => {
          const own = p.querySelector('.pm2-dot').getBoundingClientRect(), name = p.querySelector('.pm2-name');
          let ok = false;
          for (const side of ['r', 'l', 't', 'b']) {
            p.classList.remove('lab-r', 'lab-l', 'lab-t', 'lab-b'); p.classList.add('lab-' + side);
            const r = name.getBoundingClientRect();
            if (inside(r) && !placed.some((q) => hit(r, q)) && !dots.some((d) => d !== own && hit(r, d)) && !(fullBtn && hit(r, fullBtn))) { ok = true; placed.push(r); break; }
          }
          if (!ok) { p.classList.remove('lab-r', 'lab-l', 'lab-t', 'lab-b'); p.classList.add('nolabel', 'lab-r'); }
        });
      pins.filter((p) => !p.classList.contains('att')).forEach((p) => p.classList.add('lab-r'));
    });
  }

  function refresh() { apply(); selectFirst(); layoutLabels(); }

  // ── เหตุการณ์ ──
  card.addEventListener('click', (e) => {
    const chip = e.target.closest('.pm2-chip');
    if (chip) {
      flt = chip.dataset.flt;
      $$('.pm2-chip', card).forEach((b) => { const on = b === chip; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
      apply(); selectFirst(); layoutLabels(); return;
    }
    const full = e.target.closest('.pm2-full');
    if (full) { const cv = full.closest('.pm2-canvas'); if (cv.requestFullscreen) cv.requestFullscreen(); else if (cv.webkitRequestFullscreen) cv.webkitRequestFullscreen(); return; }
    const t = e.target.closest('.pm2-pin, .pm2-row, .pm2-tiles .pm-tile');
    if (!t || e.metaKey || e.ctrlKey || e.shiftKey || e.button) return;   // Ctrl/⌘/Shift+คลิก = เปิดลิงก์ตามปกติ
    e.preventDefault(); select(t.dataset.area, t.closest('.map-pane') || pane());
  });
  const hl = (e, on) => {
    const t = e.target.closest && e.target.closest('.pm2-pin, .pm2-row'); if (!t) return;
    same(t.closest('.map-pane') || pane(), t.dataset.area).forEach((x) => x.classList.toggle('hl', on));
  };
  card.addEventListener('mouseover', (e) => hl(e, true));
  card.addEventListener('mouseout', (e) => hl(e, false));
  card.addEventListener('focusin', (e) => hl(e, true));
  card.addEventListener('focusout', (e) => hl(e, false));

  if (document.fullscreenEnabled || document.webkitFullscreenEnabled) $$('.pm2-full', card).forEach((b) => { b.hidden = false; });
  document.addEventListener('fullscreenchange', () => setTimeout(layoutLabels, 60));
  let rt; window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(layoutLabels, 120); });
  window.addEventListener('load', refresh);
  $$('.map-pane', card).forEach((p) => selectFirst(p));
  apply();
  window.PM2 = { refresh };
})();
