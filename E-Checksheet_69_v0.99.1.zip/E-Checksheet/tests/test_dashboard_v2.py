"""Dashboard v2: ตัวเลขวันนี้, สถานะพื้นที่, หัวข้อสำคัญ, ผังโรงงาน, รายงาน Excel"""
import io
from datetime import date, datetime, timedelta

import pytest

from ecs import analytics as AN
from ecs import anomaly as A
from ecs import masterdata as M
from ecs import submissions as SUB
from ecs.services import ts

from conftest import GOOD, login, payload, png_bytes, uid


def photo():
    from werkzeug.datastructures import FileStorage
    return FileStorage(io.BytesIO(png_bytes()), filename="p.png")


def submit(app, db, form, answers, photos=None):
    res = SUB.create_submission(db, payload(form, answers), photos or {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    return res


@pytest.fixture()
def area_form(app, db, published_form):
    aid = M.get_or_create_area(db, app.config["F1"], "Compressor Room")
    db.execute("UPDATE equipment SET area_id=? WHERE id=?", (aid, published_form["equipment_id"]))
    sid = db.execute("INSERT INTO cs_schedules(form_id, freq_type, times, created_at, updated_at) VALUES (?, 'daily', '08:00', ?, ?)",
                     (published_form["form_id"], ts(datetime.now()), ts(datetime.now()))).lastrowid
    db.commit()
    return {**published_form, "area_id": aid, "schedule_id": sid}


def _round(db, f, due, status):
    db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                  VALUES (?,?,?,?,?,?,?)""", (f["schedule_id"], f["form_id"], ts(due), ts(due), ts(due), status, ts(due)))
    db.commit()


def test_today_summary_and_results(app, db, area_form):
    submit(app, db, area_form, GOOD)
    ng = {**GOOD, "noise": {"value": "NG", "remark": "ดัง", "photos": ["p1"]}, "hour": {"value": "1001"}}
    submit(app, db, area_form, ng, photos={"p1": photo()})
    today = date.today()
    r = AN.results_of_day(db, today)
    assert r["submissions"] == 2 and r["ng"] == 1 and r["item_count"] == 8 and r["pass_rate"] == 87.5
    assert sum(r["hourly"]) == 2
    s = AN.today_summary(db, today)
    assert s["equipment"] == {"active": 1, "inactive": 0}
    assert s["to_fix"] == s["alerts"]["critical"] + s["alerts"]["warning"] >= 1
    assert AN.results_of_day(db, today, app.config["F2"])["submissions"] == 0


def test_area_status_levels(app, db, area_form):
    today = datetime.combine(date.today(), datetime.min.time())
    _round(db, area_form, today + timedelta(hours=8), "done_on_time")
    a = next(x for x in AN.area_status(db, date.today()) if x["id"] == area_form["area_id"])
    assert (a["rounds"], a["done"], a["status"], a["eq_count"]) == (1, 1, "good", 1)
    _round(db, area_form, today + timedelta(hours=9), "overdue")
    a = next(x for x in AN.area_status(db, date.today()) if x["id"] == area_form["area_id"])
    assert a["status"] == "warning" and "เลยกำหนด 1" in a["reason"]
    _round(db, area_form, today + timedelta(hours=10), "missed")
    a = next(x for x in AN.area_status(db, date.today()) if x["id"] == area_form["area_id"])
    assert a["status"] == "critical" and a["status_th"] == "เร่งแก้ไข"
    empty = M.get_or_create_area(db, app.config["F2"], "Empty Yard")
    db.commit()
    assert next(x for x in AN.area_status(db, date.today()) if x["id"] == empty)["status"] == "none"


def test_key_items_auto_and_configured(app, db, area_form):
    for v in (2.0, 2.1, 2.2):
        submit(app, db, area_form, {**GOOD, "oil": {"value": str(v)}, "hour": {"value": str(1000 + int(v * 10))}})
    k = AN.key_items(db, date.today())
    assert [x["item_key"] for x in k] == ["oil"]        # counter ไม่ใช่ตัวเลขวัดค่า
    assert k[0]["spec"] == "1.7 – 2.5" and k[0]["last"] == 2.2 and k[0]["avg"][-1] == pytest.approx(2.1)
    saved = AN.save_dash_items(db, [{"form_id": area_form["form_id"], "item_key": "oil"},
                                    {"form_id": area_form["form_id"], "item_key": "noise"},       # ไม่ใช่ตัวเลข → ตัดทิ้ง
                                    {"form_id": "x", "item_key": "oil"}], None)
    assert saved == [{"form_id": area_form["form_id"], "item_key": "oil"}]
    assert AN.key_items(db, date.today(), app.config["F2"]) == []


def test_seven_day_and_recent_alerts(app, db, area_form):
    d = date.today()
    _round(db, area_form, datetime.combine(d, datetime.min.time()) + timedelta(hours=8), "done_on_time")
    _round(db, area_form, datetime.combine(d, datetime.min.time()) + timedelta(hours=9), "missed")
    w = AN.seven_day(db, d)
    assert len(w["days"]) == 7 and w["due"][-1] == 2 and w["done"][-1] == 1 and w["missed"][-1] == 1
    form = {"id": area_form["form_id"], "equipment_id": area_form["equipment_id"]}
    a1, _ = A.raise_alert(db, alert_type="ng", form=form, title="A", detail="", severity="warning", item_key="oil")
    a2, _ = A.raise_alert(db, alert_type="warn", form=form, title="B", detail="", severity="info", item_key="oil")
    A.set_alert_status(db, a1, "resolve", None, root_cause="ไส้กรองตัน", action_taken="แก้แล้ว")
    rec = A.recent_alerts(db)
    assert [r["id"] for r in rec] == [a2, a1]
    assert rec[0]["pill"] == "warning" and rec[1]["pill_th"] == "แก้ไขแล้ว" and rec[1]["last_seen"]


def test_layout_and_pins(app, db, client):
    f1 = app.config["F1"]
    aid = M.get_or_create_area(db, f1, "Boiler House")
    db.commit()
    with pytest.raises(Exception):
        M.set_factory_layout(db, f1, b"<svg onload=alert(1)>", app.config["UPLOAD_FOLDER"], None)   # ไม่รับ SVG
    rel = M.set_factory_layout(db, f1, png_bytes(), app.config["UPLOAD_FOLDER"], None)
    db.commit()
    assert rel.startswith("layouts/") and rel.endswith(".png")
    tok = login(client, "t_admin")
    h = {"X-CSRF-Token": tok, "Accept": "application/json"}
    assert client.post(f"/api/areas/{aid}/pin", json={"x": 40, "y": 20}, headers=h).status_code == 200
    assert client.post(f"/api/areas/{aid}/pin", json={"x": 140, "y": 20}, headers=h).status_code == 400
    assert db.execute("SELECT map_x, map_y FROM areas WHERE id=?", (aid,)).fetchone()[:] == (40.0, 20.0)
    body = client.get("/dashboard").get_data(as_text=True)
    assert "pm-canvas" in body and "left:40.0%" in body and "Boiler House" in body
    assert client.get(f"/media/{rel}").status_code == 200
    assert "Boiler House" in client.get(f"/admin/layout?factory={f1}").get_data(as_text=True)
    assert client.post(f"/api/areas/{aid}/pin", json={"clear": True}, headers=h).status_code == 200
    assert client.post(f"/admin/layout/{f1}", data={"csrf_token": tok, "action": "remove"}).status_code == 302
    assert db.execute("SELECT layout_image FROM factories WHERE id=?", (f1,)).fetchone()[0] == ""


def test_layout_permissions(client, app, db):
    aid = M.get_or_create_area(db, app.config["F1"], "X")
    db.commit()
    tok = login(client, "t_sup")
    assert client.get("/admin/layout").status_code == 403
    assert client.post(f"/api/areas/{aid}/pin", json={"x": 1, "y": 1},
                       headers={"X-CSRF-Token": tok, "Accept": "application/json"}).status_code == 403
    assert client.get("/admin/dashboard-items").status_code == 403


@pytest.mark.parametrize("kind", ["results", "rounds", "alerts", "compliance"])
def test_excel_reports(app, db, client, area_form, kind):
    from openpyxl import load_workbook
    ng = {**GOOD, "noise": {"value": "NG", "remark": "ดัง", "photos": ["p1"]}}
    submit(app, db, area_form, ng, photos={"p1": photo()})
    login(client, "t_view")
    res = client.get(f"/reports/{kind}.xlsx?date={date.today().isoformat()}")
    assert res.status_code == 200 and res.mimetype.endswith("sheet")
    ws = load_workbook(io.BytesIO(res.data)).active
    assert ws.max_row >= 4 and ws["A4"].value
    if kind == "results":
        vals = [c.value for c in ws[ws.max_row]]
        assert any(r[11].value == "NG" for r in ws.iter_rows(min_row=5)) and "Oil Pressure" in str([c.value for c in ws["H"]])
        assert vals
    assert client.get("/reports/bogus.xlsx").status_code == 404


def test_dashboard_page_renders(client, app, db, area_form):
    submit(app, db, area_form, GOOD)
    login(client, "t_view")
    body = client.get("/dashboard").get_data(as_text=True)
    for text in ("เช็คชีทประจำวัน", "สถานะรายพื้นที่", "ผลการตรวจวัดล่าสุด", "รายงานและเอกสาร", "Oil Pressure", "Compressor Room"):
        assert text in body
    assert "built-in method" not in body
    assert client.get(f"/dashboard?date={(date.today() - timedelta(days=3)).isoformat()}&factory={app.config['F1']}").status_code == 200
    assert client.get("/dashboard?date=bad").status_code == 200


def test_not_found_pages(client):
    login(client, "t_view")
    res = client.get("/alerts/999999")
    assert res.status_code == 404 and "ไม่พบข้อมูล" in res.get_data(as_text=True)
    assert client.get("/no-such-page").status_code == 404
