"""v0.15: รอบตรวจของแม่แบบ → ทุกเครื่อง · การ์ดสถานะรายพื้นที่เลื่อนได้"""
from conftest import login, uid
from test_v10 import _eq, _form

from ecs import formtpl as T
from ecs import services as S


def _active(db, fid):
    return [dict(r) for r in db.execute("SELECT * FROM cs_schedules WHERE form_id=? AND active=1", (fid,))]


def test_template_schedule_pushes_to_children(app, db):
    admin = uid(db, "t_admin")
    src = _form(app, db, "AC-01")
    S.create_schedule(db, src, {"freq_type": "daily", "times": "07:00"}, admin)          # รอบที่เครื่องตั้งเอง
    tpl = T.make_template(db, src, admin)
    T.apply_to_equipment(db, tpl, [_eq(app, db, "AC-02")], admin)
    db.commit()
    kids = [k["id"] for k in T.children(db, tpl)]
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get(f"/forms/{tpl}").get_data(as_text=True)
    assert 'data-tab="schedules"' in page and "รอบตรวจของแม่แบบ" in page
    # ตั้งรอบที่แม่แบบ → ทุกเครื่องได้รอบนี้
    r = c.post(f"/forms/{tpl}/schedules", data={"csrf_token": tok, "freq_type": "shift", "times": "09:00,21:00", "window_min": "240"})
    assert r.status_code == 302
    for k in kids:
        inh = [s for s in _active(db, k) if s["tpl_schedule_id"]]
        assert len(inh) == 1 and inh[0]["times"] == "09:00,21:00"
    assert any(not s["tpl_schedule_id"] for s in _active(db, src))                        # รอบเดิมของเครื่องยังอยู่
    assert not db.execute("SELECT 1 FROM cs_rounds WHERE form_id=?", (tpl,)).fetchone()    # แม่แบบไม่มีรอบตรวจเอง
    assert db.execute(f"SELECT COUNT(*) FROM cs_rounds WHERE form_id IN ({','.join(map(str, kids))})").fetchone()[0] > 0
    # แก้ที่แม่แบบ → เครื่องเปลี่ยนตาม
    tsid = _active(db, tpl)[0]["id"]
    c.post(f"/schedules/{tsid}", data={"csrf_token": tok, "freq_type": "shift", "times": "08:00,20:00", "window_min": "180"})
    assert all(s["times"] == "08:00,20:00" and s["window_min"] == 180 for k in kids for s in _active(db, k) if s["tpl_schedule_id"])
    # หน้าเครื่องลูก: รอบที่สืบทอดแก้ไม่ได้ (แก้ที่แม่แบบ)
    assert "จากแม่แบบ" in c.get(f"/forms/{kids[0]}").get_data(as_text=True)
    # ใช้รอบของแม่แบบอย่างเดียว
    c.post(f"/forms/{tpl}/schedules/push", data={"csrf_token": tok, "replace_own": "1"})
    assert all(s["tpl_schedule_id"] for s in _active(db, src))
    # ปิดที่แม่แบบ → ปิดทุกเครื่อง
    c.post(f"/schedules/{tsid}/delete", data={"csrf_token": tok})
    assert not any(_active(db, k) for k in kids)
    # เครื่องใหม่ได้รอบของแม่แบบอัตโนมัติ
    c.post(f"/forms/{tpl}/schedules", data={"csrf_token": tok, "freq_type": "daily", "times": "10:00", "window_min": "120"})
    T.apply_to_equipment(db, tpl, [_eq(app, db, "AC-03")], uid(db, "t_admin"))
    new = [k["id"] for k in T.children(db, tpl) if k["id"] not in kids][0]
    assert [s["times"] for s in _active(db, new)] == ["10:00"]
    # แยกออกจากแม่แบบ → รอบกลายเป็นของเครื่องเอง
    T.detach(db, new, uid(db, "t_admin"))
    assert not any(s["tpl_schedule_id"] for s in _active(db, new))


def test_dashboard_area_card_scrolls(app, db):
    c = app.test_client()
    login(c, "t_sup")
    html = c.get("/dashboard").get_data(as_text=True)
    assert 'class="dc-scroll"' in html
