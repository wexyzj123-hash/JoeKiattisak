"""v0.11: เครื่องหยุด/ซ่อม · สถานะระบบ + แบ็กอัปอัตโนมัติ · ผังย่อยรายพื้นที่"""
import os
from datetime import date, datetime, timedelta

import pytest
from conftest import login, payload, uid

from ecs import backup as BK
from ecs import downtime as DT
from ecs import masterdata as M
from ecs import services as S
from ecs import submissions as SUB
from ecs.analytics import equipment_status, refresh_daily_stats


def _setup(app, db, code="AC-01", times="00:05"):
    admin = uid(db, "t_admin")
    area = M.save_area(db, {"factory_id": app.config["F1"], "name": f"ห้อง {code}"}, admin) if hasattr(M, "save_area") else None
    eq = M.save_equipment(db, {"code": code, "name": "Compressor", "factory_id": app.config["F1"], "area_id": area}, admin)
    fid = S.create_form(db, {"name": f"Daily {code}", "equipment_id": eq}, admin)
    d = S.get_draft(db, fid)
    S.save_draft_items(db, d["id"], [{"item_key": "a", "name": "ปกติ", "item_type": "ok_ng"}], admin)
    S.publish_version(db, d["id"], admin)
    S.create_schedule(db, fid, {"freq_type": "daily", "times": times, "window_min": 1400}, admin)
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('rounds_start', ?)",
               ((datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d %H:%M:%S"),))
    S.generate_rounds(db)
    S.refresh_round_statuses(db)
    db.commit()
    return eq, fid, area


def test_downtime_skips_and_restores_rounds(app, db):
    eq, fid, _ = _setup(app, db)
    open_before = db.execute("SELECT COUNT(*) FROM cs_rounds WHERE form_id=? AND status IN ('pending','overdue')", (fid,)).fetchone()[0]
    assert open_before >= 1
    admin = uid(db, "t_admin")
    with pytest.raises(S.ValidationError):
        DT.set_down(db, eq, admin, "")
    res = DT.set_down(db, eq, admin, "มอเตอร์ไหม้", "repair", "2030-01-01T08:00")
    db.commit()
    assert res["skipped"] == open_before
    assert DT.is_down(db, fid)["down_reason"].endswith("มอเตอร์ไหม้")
    # รอบที่สร้างใหม่ระหว่างหยุด = skipped
    S.generate_rounds(db, horizon_days=3)
    assert db.execute("SELECT COUNT(*) FROM cs_rounds WHERE form_id=? AND status='pending'", (fid,)).fetchone()[0] == 0
    # ไม่นับในสถิติ
    refresh_daily_stats(db, date.today(), date.today())
    due = db.execute("SELECT COALESCE(SUM(due),0) FROM cs_daily_stats WHERE form_id=?", (fid,)).fetchone()[0]
    assert due == 0
    # มือถือ: งานของฉันแสดงเป็นเครื่องหยุด, แพ็กเกจมีข้อมูลหยุด
    tasks = SUB.my_tasks(db, uid(db, "t_tech"))
    assert tasks["groups"]["skipped"] and not tasks["groups"]["due"]
    assert SUB.form_package(db, fid)["down"]
    with pytest.raises(S.ValidationError):
        DT.set_down(db, eq, admin, "ซ้ำ")
    r = DT.set_running(db, eq, admin, "เปลี่ยนมอเตอร์แล้ว")
    db.commit()
    assert r["restored"] >= 1
    assert db.execute("SELECT COUNT(*) FROM cs_rounds WHERE form_id=? AND status IN ('pending','overdue')", (fid,)).fetchone()[0] >= 1
    h = DT.history(db, eq)
    assert h[0]["end_at"] and h[0]["end_note"] == "เปลี่ยนมอเตอร์แล้ว"


def test_downtime_web(app, db):
    eq, fid, _ = _setup(app, db, "AC-05")
    client = app.test_client()
    tok = login(client, "t_sup")
    r = client.post(f"/equipment/{eq}/down", data={"reason": "PM ประจำปี", "category": "pm", "csrf_token": tok})
    assert r.status_code == 302
    assert "PM ประจำปี" in client.get("/equipment/down").get_data(as_text=True)
    assert "เครื่องหยุด / ซ่อม" in client.get(f"/equipment/{eq}").get_data(as_text=True)
    assert "AC-05" in client.get("/equipment?forms=down").get_data(as_text=True)
    client.post(f"/equipment/{eq}/running", data={"csrf_token": tok})
    assert M.get_equipment(db, eq)["run_status"] == "running"
    c2 = app.test_client()
    tok2 = login(c2, "t_tech")
    c2.post(f"/equipment/{eq}/down", data={"reason": "x", "csrf_token": tok2})
    assert M.get_equipment(db, eq)["run_status"] == "running"


def test_backup_and_health(app, db, tmp_path, monkeypatch):
    monkeypatch.setenv("BACKUP_DIR", str(tmp_path / "bk"))
    monkeypatch.setenv("BACKUP_KEEP", "2")
    db.commit()
    res = BK.run_backup(app.config["DATABASE"], app.config["UPLOAD_FOLDER"], str(tmp_path / "bk"), keep=2)
    assert res["ok"] and os.path.exists(res["file"])
    for _ in range(2):
        import time
        time.sleep(1.1)
        BK.run_backup(app.config["DATABASE"], app.config["UPLOAD_FOLDER"], str(tmp_path / "bk"), keep=2)
    assert len(BK.list_backups(str(tmp_path / "bk"))) == 2
    with app.app_context():
        assert BK.due(app, datetime.now().replace(hour=23, minute=59)) is True
        r = BK.backup_now(app)
        assert r["ok"]
        assert BK.due(app, datetime.now().replace(hour=23, minute=59)) is False
    client = app.test_client()
    tok = login(client, "t_admin")
    body = client.get("/admin/health").get_data(as_text=True)
    assert "แบ็กอัปล่าสุดภายใน 24 ชม." in body and "ข้อมูลที่ควรแก้" in body
    assert client.post("/admin/health/backup", data={"csrf_token": tok}).status_code == 302
    name = BK.list_backups(str(tmp_path / "bk"))[0]["name"]
    r = client.get(f"/admin/health/download/{name}")
    assert r.status_code == 200 and r.data[:15] == b"SQLite format 3"
    assert client.get("/admin/health/download/..%2Fsecret.db").status_code == 404
    assert client.post("/admin/health/integrity", data={"csrf_token": tok}).status_code == 302
    c2 = app.test_client()
    login(c2, "t_sup")
    assert c2.get("/admin/health").status_code in (302, 403)


def test_area_submap(app, db):
    eq, fid, area = _setup(app, db, "AC-09")
    area = area or db.execute("SELECT id FROM areas WHERE factory_id=? LIMIT 1", (app.config["F1"],)).fetchone()[0]
    if M.get_equipment(db, eq)["area_id"] != area:
        S.set_equipment_location(db, eq, app.config["F1"], area, None)
    eq2 = M.save_equipment(db, {"code": "AC-10", "name": "Dryer", "factory_id": app.config["F1"], "area_id": area}, uid(db, "t_admin"))
    db.commit()
    st = {e["code"]: e for e in equipment_status(db, date.today(), area)}
    assert st["AC-09"]["status"] in ("pending", "warning") and st["AC-09"]["rounds"] >= 1
    assert st["AC-10"]["status"] == "none"
    M.set_equipment_pin(db, eq, 30, 40, None)
    with pytest.raises(S.ValidationError):
        M.set_equipment_pin(db, eq, 130, 40, None)
    DT.set_down(db, eq2, None, "สำรอง", "standby")
    db.commit()
    st = {e["code"]: e for e in equipment_status(db, date.today(), area)}
    assert st["AC-10"]["status"] == "down" and st["AC-09"]["map_x"] == 30
    client = app.test_client()
    tok = login(client, "t_sup")
    body = client.get(f"/areas/{area}/map").get_data(as_text=True)
    assert "AC-09" in body and "เครื่องหยุด" in body and "ตรวจแล้ว" in body
    assert client.get(f"/areas/{area}/map?date=2026-01-01&edit=1").status_code == 200
    r = client.post(f"/api/equipment/{eq}/pin", json={"x": 10, "y": 20}, headers={"X-CSRF-Token": tok})
    assert r.status_code == 200 and M.get_equipment(db, eq)["map_x"] == 10
    from conftest import png_bytes
    import io
    r = client.post(f"/areas/{area}/layout", data={"layout": (io.BytesIO(png_bytes()), "room.png"), "csrf_token": tok},
                    content_type="multipart/form-data")
    assert r.status_code == 302
    assert db.execute("SELECT layout_image FROM areas WHERE id=?", (area,)).fetchone()[0]
    body = client.get(f"/areas/{area}/map").get_data(as_text=True)
    assert 'class="pin st-' in body
    tech = app.test_client()
    login(tech, "t_tech")
    assert tech.get(f"/areas/{area}/map").status_code == 200
