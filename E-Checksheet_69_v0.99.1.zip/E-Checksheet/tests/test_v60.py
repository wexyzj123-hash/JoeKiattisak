"""v0.60: สีสถานะงานวันนี้ (มือถือ) + หลอดสถานะรอบตรวจเต็มหัวข้อ (ภาพรวม)"""
from conftest import login


def test_home_status_colors(app, client):
    login(client, "t_tech")
    js = client.get("/static/m/home.js").get_data(as_text=True)
    assert "statusBar" in js and "stPill" in js and "⏳ รอรอบ" in js and "sb-done" in js and "sb-down" in js
    css = client.get("/static/css/m.css").get_data(as_text=True)
    assert ".m-task.done { background: var(--st-done-bg)" in css and ".m-task.skipped { background: var(--st-down-bg)" in css


def test_dashboard_stacked_bar(app, client, published_form):
    login(client, "t_admin")
    html = client.get("/dashboard").get_data(as_text=True)
    assert 'class="stbar"' in html and "stleg" in html
    css = client.get("/static/css/app.css").get_data(as_text=True)
    assert "--st-wait: #facc15" in css and ".st-down" in css
