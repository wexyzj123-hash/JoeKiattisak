"""ecs/formtpl.py — แบบฟอร์มแม่แบบ: 1 แม่แบบ ใช้กับหลายเครื่อง แก้ครั้งเดียวมีผลทุกเครื่อง

- แม่แบบ (cs_forms.is_template=1) ไม่มีเครื่อง ไม่มีรอบตรวจ มีแค่หัวข้อ
- แบบฟอร์มลูก (cs_forms.template_id) = แบบฟอร์มปกติของแต่ละเครื่อง (รอบตรวจ ผลตรวจ แยกตามเครื่อง)
  หัวข้อมาจากแม่แบบเสมอ — Publish แม่แบบ → ทุกเครื่องได้เวอร์ชันใหม่อัตโนมัติ
- เกณฑ์เฉพาะเครื่อง (Min/Max/เตือน) ตั้งแยกได้ต่อเครื่อง (cs_template_overrides) ไม่หายเมื่อแม่แบบเปลี่ยน
- ผูกแบบฟอร์มเดิมเข้าแม่แบบ: หัวข้อชื่อเดียวกันใช้รหัสหัวข้อเดิมของเครื่อง → กราฟแนวโน้ม/มิเตอร์สะสมต่อเนื่อง
"""
from __future__ import annotations

import re

from . import services as S
from .services import ValidationError, audit, ts


def _norm(name: str) -> str:
    return re.sub(r"[\s:：._\-]+", "", str(name or "")).lower()


def get_template(db, form: dict) -> dict | None:
    return S.get_form(db, form["template_id"]) if form and form.get("template_id") else None


def children(db, tpl_id: int) -> list[dict]:
    rows = db.execute("""
        SELECT f.id, f.code, f.name, f.active, f.equipment_id, e.code AS eq_code, e.name AS eq_name, e.eq_type,
               ar.name AS area_name, fa.name AS factory_name, v.version_no, v.template_version_id,
               tv.version_no AS tpl_version_no,
               (SELECT COUNT(*) FROM cs_template_overrides o WHERE o.form_id=f.id AND o.has_limits=1) AS override_count,
               (SELECT COUNT(*) FROM cs_schedules s WHERE s.form_id=f.id AND s.active=1) AS schedule_count,
               (SELECT MAX(finished_at) FROM cs_submissions sb WHERE sb.form_id=f.id) AS last_submitted
        FROM cs_forms f
        LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN areas ar ON ar.id=f.area_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN cs_form_versions v ON v.id=f.current_version_id
        LEFT JOIN cs_form_versions tv ON tv.id=v.template_version_id
        WHERE f.template_id=? ORDER BY fa.sort_no, e.code, f.code""", (tpl_id,)).fetchall()
    return [dict(r) for r in rows]


def overrides(db, form_id: int) -> dict[str, dict]:
    return {r["template_key"]: dict(r) for r in db.execute(
        "SELECT * FROM cs_template_overrides WHERE form_id=?", (form_id,))}


def _require_template(db, tpl_id: int) -> dict:
    tpl = S.get_form(db, tpl_id)
    if not tpl or not tpl.get("is_template"):
        raise ValidationError("ไม่พบแม่แบบ")
    return tpl


def sync_child(db, child_id: int, actor_id: int | None, note: str = "") -> dict | None:
    """สร้างเวอร์ชันใหม่ของแบบฟอร์มลูกจากแม่แบบ (ใช้เกณฑ์เฉพาะเครื่องทับ) แล้ว Publish"""
    child = S.get_form(db, child_id)
    tpl = get_template(db, child)
    if not tpl or not tpl["current_version_id"]:
        return None
    tv = S.get_version(db, tpl["current_version_id"])
    items = S.get_items(db, tv["id"])
    ov = overrides(db, child_id)
    draft = S.get_draft(db, child_id)
    if draft:                                     # แบบฟอร์มลูกไม่มีฉบับร่างของตัวเอง
        db.execute("DELETE FROM cs_form_items WHERE version_id=?", (draft["id"],))
        db.execute("DELETE FROM cs_form_versions WHERE id=?", (draft["id"],))
    last_no = db.execute("SELECT COALESCE(MAX(version_no),0) FROM cs_form_versions WHERE form_id=?",
                         (child_id,)).fetchone()[0]
    vid = db.execute("""INSERT INTO cs_form_versions(form_id, version_no, status, created_by, created_at,
                            sections_json, template_version_id) VALUES (?,?,'draft',?,?,?,?)""",
                     (child_id, last_no + 1, actor_id, ts(), tv.get("sections_json") or "", tv["id"])).lastrowid
    cols = ("section", "order_no", "name", "item_type", "unit", "min_value", "max_value", "warn_low", "warn_high",
            "counter_max_step", "options_json", "required", "critical", "photo_on_ng", "guide", "check_freq",
            "check_times", "photo_required", "formula")
    from .formula import rename_refs
    kmap = {k: o["local_key"] for k, o in ov.items() if o.get("local_key")}
    for it in items:
        o = ov.get(it["item_key"]) or {}
        row = {c: it.get(c) for c in cols}
        if row.get("formula") and kmap:                 # v0.95 สูตรอ้างรหัสหัวข้อของเครื่องนี้
            row["formula"] = rename_refs(row["formula"], kmap)
        row["formula"] = row.get("formula") or ""
        if o.get("has_limits") and it["item_type"] in ("number", "counter", "calc"):
            row.update({k: o.get(k) for k in ("min_value", "max_value", "warn_low", "warn_high")})
        key = o.get("local_key") or it["item_key"]
        db.execute(f"""INSERT INTO cs_form_items(version_id, item_key, {', '.join(cols)})
                       VALUES (?,?,{','.join('?' * len(cols))})""", (vid, key, *[row[c] for c in cols]))
    msg = f"ตามแม่แบบ {tpl['code']} v{tv['version_no']}" + (f": {note}" if note else "")
    return S.publish_version(db, vid, actor_id, msg, tv.get("effective_date"), tv.get("approved_by_name") or "")


def sync_all(db, tpl_id: int, actor_id: int | None, note: str = "") -> int:
    n = 0
    for c in children(db, tpl_id):
        if sync_child(db, c["id"], actor_id, note):
            n += 1
    return n


def make_template(db, source_id: int, actor_id: int | None, name: str = "") -> int:
    """สร้างแม่แบบจากแบบฟอร์มที่มีอยู่ (คัดลอกหัวข้อ) แล้วผูกแบบฟอร์มต้นฉบับเป็นลูก"""
    src = S.get_form(db, source_id)
    if not src or not src["current_version_id"]:
        raise ValidationError("แบบฟอร์มต้นฉบับต้อง Publish แล้ว")
    if src.get("is_template") or src.get("template_id"):
        raise ValidationError("แบบฟอร์มนี้เป็นแม่แบบ/ใช้แม่แบบอยู่แล้ว")
    tpl_name = (name or "").strip() or re.sub(r"\s*[-–—]?\s*" + re.escape(src.get("eq_code") or "\u0000") + r"\s*$", "",
                                               src["name"]).strip() or src["name"]
    tpl_id = S.create_form(db, {"name": tpl_name, "description": src.get("description") or "",
                                "category": src.get("category")}, actor_id)
    db.execute("UPDATE cs_forms SET is_template=1, doc_no=? WHERE id=?", (src.get("doc_no") or "", tpl_id))
    draft = S.get_draft(db, tpl_id)
    S._copy_items(db, src["current_version_id"], draft["id"])
    S.publish_version(db, draft["id"], actor_id, f"สร้างจากแบบฟอร์ม {src['code']}")
    link_forms(db, tpl_id, [source_id], actor_id, sync=False)   # หัวข้อเหมือนกันอยู่แล้ว ยังไม่ต้องออกเวอร์ชันใหม่
    audit(db, actor_id, "make_template", "cs_forms", tpl_id, after={"source": source_id})
    return tpl_id


def new_template(db, data: dict, actor_id: int | None) -> int:
    tpl_id = S.create_form(db, {"name": data.get("name"), "description": data.get("description") or "",
                                "category": data.get("category")}, actor_id)
    db.execute("UPDATE cs_forms SET is_template=1 WHERE id=?", (tpl_id,))
    return tpl_id


def link_forms(db, tpl_id: int, form_ids: list[int], actor_id: int | None, sync: bool = True) -> int:
    """ผูกแบบฟอร์มเดิมเข้าแม่แบบ — หัวข้อชื่อเดียวกันใช้รหัสหัวข้อเดิม (ประวัติ/กราฟต่อเนื่อง)"""
    tpl = _require_template(db, tpl_id)
    t_items = S.get_items(db, tpl["current_version_id"]) if tpl["current_version_id"] else []
    n = 0
    for fid in form_ids:
        f = S.get_form(db, fid)
        if not f or f.get("is_template") or f["id"] == tpl_id:
            continue
        own = {_norm(i["name"]): i for i in (S.get_items(db, f["current_version_id"]) if f["current_version_id"] else [])}
        db.execute("DELETE FROM cs_template_overrides WHERE form_id=?", (fid,))
        for it in t_items:
            mine = own.get(_norm(it["name"]))
            if not mine:
                continue
            limits = mine["item_type"] in ("number", "counter", "calc") and it["item_type"] in ("number", "counter", "calc") and any(
                mine.get(k) != it.get(k) for k in ("min_value", "max_value", "warn_low", "warn_high"))
            db.execute("""INSERT INTO cs_template_overrides(form_id, template_key, local_key, has_limits,
                              min_value, max_value, warn_low, warn_high) VALUES (?,?,?,?,?,?,?,?)""",
                       (fid, it["item_key"], mine["item_key"] if mine["item_key"] != it["item_key"] else "",
                        1 if limits else 0, mine.get("min_value"), mine.get("max_value"),
                        mine.get("warn_low"), mine.get("warn_high")))
        db.execute("UPDATE cs_forms SET template_id=?, updated_at=? WHERE id=?", (tpl_id, ts(), fid))
        if sync:
            sync_child(db, fid, actor_id, "ผูกเข้าแม่แบบ")
        push_schedules(db, tpl_id, actor_id, child_ids=[fid])
        n += 1
    return n


def apply_to_equipment(db, tpl_id: int, equipment_ids: list[int], actor_id: int | None,
                       schedule: dict | None = None) -> dict:
    """สร้างแบบฟอร์มลูกให้เครื่องที่เลือก (ข้ามเครื่องที่มีแบบฟอร์มจากแม่แบบนี้อยู่แล้ว)"""
    tpl = _require_template(db, tpl_id)
    if not tpl["current_version_id"]:
        raise ValidationError("แม่แบบยังไม่ Publish — เพิ่มหัวข้อแล้ว Publish ก่อน")
    if not equipment_ids:
        raise ValidationError("เลือกเครื่องจักรอย่างน้อย 1 เครื่อง")
    have = {r[0] for r in db.execute("SELECT equipment_id FROM cs_forms WHERE template_id=?", (tpl_id,))}
    created, skipped = [], []
    for eid in dict.fromkeys(equipment_ids):
        eq = db.execute("SELECT id, code, name FROM equipment WHERE id=?", (eid,)).fetchone()
        if not eq:
            continue
        if eq["id"] in have:
            skipped.append(eq["code"])
            continue
        fid = S.create_form(db, {"name": f"{tpl['name']} {eq['code']}", "description": tpl.get("description") or "",
                                 "equipment_id": eq["id"], "category": tpl.get("category")}, actor_id)
        db.execute("DELETE FROM cs_form_versions WHERE form_id=? AND status='draft'", (fid,))
        db.execute("UPDATE cs_forms SET template_id=?, doc_no=? WHERE id=?", (tpl_id, tpl.get("doc_no") or "", fid))
        sync_child(db, fid, actor_id)
        push_schedules(db, tpl_id, actor_id, child_ids=[fid])       # รอบตรวจที่ตั้งไว้ในแม่แบบ
        if schedule and schedule.get("times"):
            S.create_schedule(db, fid, schedule, actor_id)
        created.append(eq["code"])
    audit(db, actor_id, "apply_template", "cs_forms", tpl_id, after={"created": created, "skipped": skipped})
    return {"created": created, "skipped": skipped}


def detach(db, child_id: int, actor_id: int | None) -> None:
    db.execute("UPDATE cs_forms SET template_id=NULL, updated_at=? WHERE id=?", (ts(), child_id))
    db.execute("DELETE FROM cs_template_overrides WHERE form_id=?", (child_id,))
    db.execute("UPDATE cs_schedules SET tpl_schedule_id=NULL WHERE form_id=?", (child_id,))   # รอบที่สืบทอดกลายเป็นของเครื่องเอง
    audit(db, actor_id, "detach_template", "cs_forms", child_id)


def save_overrides(db, child_id: int, data: dict, actor_id: int | None) -> int:
    """data = {template_key: {min_value, max_value, warn_low, warn_high, use: bool}} → บันทึกแล้วออกเวอร์ชันใหม่"""
    child = S.get_form(db, child_id)
    tpl = get_template(db, child)
    if not tpl:
        raise ValidationError("แบบฟอร์มนี้ไม่ได้ใช้แม่แบบ")
    t_items = {i["item_key"]: i for i in S.get_items(db, tpl["current_version_id"])}
    cur = overrides(db, child_id)
    errors, n = [], 0
    for key, d in data.items():
        it = t_items.get(key)
        if not it or it["item_type"] not in ("number", "counter", "calc"):
            continue
        use = bool(d.get("use"))
        vals = {k: S._num(d.get(k)) for k in ("min_value", "max_value", "warn_low", "warn_high")}
        if use:
            test = dict(it, **vals)
            try:
                S.normalize_item(test)
            except ValidationError as exc:
                errors += [f"{it['name']}: {e.split(': ', 1)[-1]}" for e in exc.errors]
                continue
            n += 1
        local = (cur.get(key) or {}).get("local_key") or ""
        db.execute("""INSERT INTO cs_template_overrides(form_id, template_key, local_key, has_limits, min_value,
                          max_value, warn_low, warn_high) VALUES (?,?,?,?,?,?,?,?)
                      ON CONFLICT(form_id, template_key) DO UPDATE SET has_limits=excluded.has_limits,
                          min_value=excluded.min_value, max_value=excluded.max_value,
                          warn_low=excluded.warn_low, warn_high=excluded.warn_high""",
                   (child_id, key, local, 1 if use else 0, vals["min_value"], vals["max_value"],
                    vals["warn_low"], vals["warn_high"]))
    if errors:
        raise ValidationError(errors)
    sync_child(db, child_id, actor_id, "ปรับเกณฑ์เฉพาะเครื่อง")
    return n


# ───────────────────────── รอบตรวจของแม่แบบ → ทุกเครื่องที่ใช้แม่แบบ ─────────────────────────

_SCHED_KEYS = ("freq_type", "times", "weekdays", "month_day", "window_min", "skip_holidays",
               "assignee_role", "assignee_user_id", "active", "anchor_date")


def _sched_data(row) -> dict:
    return {k: row[k] for k in _SCHED_KEYS}


def push_schedules(db, tpl_id: int, actor_id: int | None, replace_own: bool = False,
                   child_ids: list[int] | None = None) -> dict:
    """ทำให้รอบตรวจของเครื่องลูกตรงกับรอบตรวจของแม่แบบ
    - รอบที่สืบทอด (tpl_schedule_id) สร้าง/แก้/ปิด ตามแม่แบบ
    - replace_own=True: ปิดรอบตรวจที่ตั้งเองของแต่ละเครื่องด้วย (ให้ทุกเครื่องใช้รอบของแม่แบบเท่านั้น)"""
    _require_template(db, tpl_id)
    tpl_sched = {r["id"]: dict(r) for r in db.execute("SELECT * FROM cs_schedules WHERE form_id=?", (tpl_id,))}
    active_ids = {i for i, r in tpl_sched.items() if r["active"]}
    kids = child_ids if child_ids is not None else [c["id"] for c in children(db, tpl_id)]
    stat = {"created": 0, "updated": 0, "closed": 0, "forms": len(kids)}
    for cid in kids:
        own = [dict(r) for r in db.execute("SELECT * FROM cs_schedules WHERE form_id=? AND active=1", (cid,))]
        inherited = {r["tpl_schedule_id"]: r for r in own if r.get("tpl_schedule_id")}
        for sid in active_ids:
            want = _sched_data(tpl_sched[sid])
            have = inherited.get(sid)
            if not have:                                # เครื่องตั้งรอบเดียวกันไว้เองแล้ว → ใช้รอบนั้นแทน (ไม่สร้างรอบซ้ำ)
                same = next((r for r in own if not r.get("tpl_schedule_id") and all(
                    str(r[k] or "") == str(want[k] or "") for k in ("freq_type", "times", "weekdays", "month_day"))), None)
                if same:
                    db.execute("UPDATE cs_schedules SET tpl_schedule_id=? WHERE id=?", (sid, same["id"]))
                    same["tpl_schedule_id"] = sid
                    have = same
            if not have:
                new_id = S.create_schedule(db, cid, want, actor_id)
                db.execute("UPDATE cs_schedules SET tpl_schedule_id=? WHERE id=?", (sid, new_id))
                stat["created"] += 1
            elif any(str(have[k] or "") != str(want[k] or "") for k in _SCHED_KEYS):
                S.update_schedule(db, have["id"], want, actor_id)
                stat["updated"] += 1
        for r in own:
            gone = r.get("tpl_schedule_id") and r["tpl_schedule_id"] not in active_ids
            if gone or (replace_own and not r.get("tpl_schedule_id")):
                S.delete_schedule(db, r["id"], actor_id)
                stat["closed"] += 1
    return stat
