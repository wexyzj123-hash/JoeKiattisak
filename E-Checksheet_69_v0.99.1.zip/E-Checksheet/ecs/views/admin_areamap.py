"""ecs/views/admin_areamap.py — แยกจาก admin.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

from flask import (abort, current_app, flash, jsonify, redirect, render_template, request, url_for)
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, MANAGE_ROLES, current_user_id, require_role
from ..services import ValidationError

from .admin import bp, _flash_errors  # noqa: E402


# ───────────────────────── ผังย่อยรายพื้นที่ ─────────────────────────

@bp.route("/areas/<int:area_id>/map")
@require_role(*ALL_ROLES)
def area_map(area_id):
    """ผังย่อยของพื้นที่: หมุดรายเครื่องพร้อมสถานะการตรวจของวัน — ดูว่าครบจริงหรือไม่"""
    from datetime import date, timedelta
    from ..analytics import EQ_STATUS_TH, area_status, equipment_status
    db = get_db()
    area = db.execute("""SELECT a.*, f.name AS factory_name, f.id AS fid FROM areas a JOIN factories f ON f.id=a.factory_id
                         WHERE a.id=?""", (area_id,)).fetchone()
    if not area:
        abort(404)
    try:
        day = date.fromisoformat(request.args.get("date", ""))
    except ValueError:
        day = date.today()
    eqs = equipment_status(db, day, area_id)
    summary = {k: sum(1 for e in eqs if e["status"] == k) for k in EQ_STATUS_TH}
    rounds = sum(e["rounds"] for e in eqs)
    done = sum(e["done"] for e in eqs)
    siblings = area_status(db, day, area["factory_id"])
    return render_template("admin/area_map.html", area=dict(area), eqs=eqs, summary=summary, EQ_TH=EQ_STATUS_TH,
                           day=day, today=date.today(), prev=day - timedelta(days=1), next=day + timedelta(days=1),
                           rounds=rounds, done=done, edit=request.args.get("edit") == "1" and session_role() in MANAGE_ROLES,
                           siblings=siblings)


def session_role():
    from flask import session
    return session.get("role")


@bp.route("/areas/<int:area_id>/layout", methods=["POST"])
@require_role(*MANAGE_ROLES)
def area_layout_upload(area_id):
    db = get_db()
    try:
        if request.form.get("action") == "remove":
            M.set_area_layout(db, area_id, None, current_app.config["UPLOAD_FOLDER"], current_user_id())
            flash("ลบผังย่อยแล้ว — แสดงเป็นกล่องรายเครื่องแทน", "ok")
        else:
            f = request.files.get("layout")
            M.set_area_layout(db, area_id, f.read(M.MAX_LAYOUT_BYTES + 1) if f else b"",
                              current_app.config["UPLOAD_FOLDER"], current_user_id())
            flash("อัปโหลดผังย่อยแล้ว — เลือกเครื่องทางขวา แล้วคลิกบนผังเพื่อวางหมุด", "ok")
        db.commit()
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("admin.area_map", area_id=area_id, edit=1))


@bp.route("/api/equipment/<int:equipment_id>/pin", methods=["POST"])
@require_role(*MANAGE_ROLES)
def equipment_pin(equipment_id):
    db = get_db()
    data = request.get_json(silent=True) or {}
    try:
        if data.get("clear"):
            M.set_equipment_pin(db, equipment_id, None, None, current_user_id())
        else:
            M.set_equipment_pin(db, equipment_id, data.get("x"), data.get("y"), current_user_id())
        db.commit()
    except ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0]}), 400
    return jsonify({"ok": True})
