"""ecs/views/forms.py — แบบฟอร์ม, ตัวสร้างแบบฟอร์ม, เวอร์ชัน, รอบตรวจ, หน้าติดตามรอบตรวจ"""
from __future__ import annotations

from datetime import date, datetime

from flask import Blueprint, abort, current_app, flash, jsonify, redirect, render_template, request, session, url_for

from .. import masterdata as M
from .. import services as S
from ..db import get_db
from ..security import INSPECT_ROLES, MANAGE_ROLES, ALL_ROLES, THEME_IDS, THEMES, current_user_id, require_role, safe_next

bp = Blueprint("forms", __name__)

ITEM_TYPE_TH = {"ok_ng": "OK / NG", "number": "ตัวเลข", "counter": "มิเตอร์สะสม", "choice": "ตัวเลือก", "text": "ข้อความ", "calc": "คำนวณจากสูตร"}
from .. import perms as PM   # v0.52 สิทธิ์แก้ไขแบบฟอร์มรายคน
from .. import terms as TR   # v0.50 ภาษากลาง
ROUND_STATUS_TH = TR.th("ROUND")
ROUND_STATUS_CLASS = TR.cls("ROUND")


def _freq_label(it) -> str:
    from ..itemfreq import label
    return label(it.get("check_freq") or "", it.get("check_times") or "") if it else ""


@bp.app_template_global("sched_intervals")
def sched_intervals() -> list[tuple[str, str]]:
    """v0.34 ความถี่แบบช่วงที่ใช้ตั้งรอบตรวจได้ (ในระบบ + ที่ผู้ดูแลระบบเพิ่มในหน้า ตั้งค่า › เวลากะ)"""
    from ..itemfreq import all_freqs, interval
    return [(k, v) for k, v in all_freqs(get_db()).items() if interval(k)]


@bp.app_context_processor
def _inject():
    out = {"ITEM_TYPE_TH": ITEM_TYPE_TH, "ROUND_STATUS_TH": ROUND_STATUS_TH, "ROUND_STATUS_CLASS": ROUND_STATUS_CLASS,
           "can_manage": session.get("role") in MANAGE_ROLES, "cs_user": None, "nav_pending": 0, "nav_signoff": 0, "is_signer": False, "can_group": False, "nav_chreq": 0, "view_limited": False,
           "UI_THEME": "auto", "THEMES": THEMES, "POSITIONS": __import__("ecs.signoffs", fromlist=["POSITIONS"]).POSITIONS, "FREQ_LABEL": _freq_label, "REV": S.rev_label}
    if "user_id" in session:
        db = get_db()
        u = db.execute("SELECT id, username, name, role, factory_id, theme FROM users WHERE id=?",
                       (session["user_id"],)).fetchone()
        out["cs_user"] = dict(u) if u else None
        theme = (u["theme"] if u else "") or ""
        if session.get("cmms_uid"):                 # บัญชีที่ผูก UT-CMMS: ใช้ธีมเดียวกับ UT-CMMS เสมอ
            from ..cmms_bridge import cmms_user_by_id
            cu = cmms_user_by_id(session["cmms_uid"]) or {}
            theme = cu.get("theme") or theme or "ocean"
        out["UI_THEME"] = theme if theme in THEME_IDS else "auto"
        if u:
            from .. import view_scope as VS
            out["view_limited"] = VS.current() is not None         # v0.29 จำกัดการดูเฉพาะเช็คชีทที่มีสิทธิ์อนุมัติ
            from ..submissions import can_approve as _ca
            out["can_group"] = _ca(db, u["id"])          # v0.26 อนุมัติแบบกลุ่ม
        if u:                                        # v0.24 ผู้ลงนามหน่วยงาน: จำนวนช่องที่ลงนามได้ (เดือนนี้ + เดือนก่อน)
            from .. import signoffs as SO
            if SO.is_signer(db, dict(u)):
                from datetime import date as _d, timedelta as _td
                m0 = _d.today().replace(day=1)
                out["is_signer"] = True
                out["nav_signoff"] = SO.pending_count(db, dict(u), [(m0 - _td(days=1)).replace(day=1), m0])
        if session.get("role") in MANAGE_ROLES:
            from ..change_requests import count_open
            out["nav_chreq"] = count_open(db, session.get("factory_id") if session.get("role") == "supervisor" else None)
        if session.get("role") in MANAGE_ROLES or out["can_group"]:       # v0.38 ผู้อนุมัติตามตำแหน่งเห็นจำนวนรออนุมัติด้วย
            from ..submissions import pending_counts
            out["nav_pending"] = pending_counts(db, session["user_id"])["total"]
    return out


def _factory_arg() -> int | None:
    try:
        return int(request.args.get("factory") or 0) or None
    except ValueError:
        return None


def _load_form(db, form_id):
    form = S.get_form(db, form_id)
    if not form:
        abort(404)
    return form


def _flash_errors(exc: S.ValidationError):
    for e in exc.errors:
        flash(e, "error")


# ───────────────────────── forms ─────────────────────────

@bp.route("/forms")
@require_role(*ALL_ROLES)
def forms():
    """รายการแบบฟอร์ม + ตัวกรอง: ผูกเครื่อง/ยังไม่ผูก · สถานะ · พื้นที่ · ประเภทเครื่อง · เรียงลำดับ"""
    db = get_db()
    factory_id = _factory_arg()
    a = request.args
    q = a.get("q", "").strip()
    show_inactive = a.get("inactive") == "1"
    bind, status, area, eq_type, sort = a.get("bind", ""), a.get("status", ""), a.get("area", ""), a.get("type", ""), a.get("sort", "")
    rows = S.list_forms(db, factory_id, q, show_inactive)
    if area == "none":
        rows = [f for f in rows if not f["area_id"]]
    elif area.isdigit():
        rows = [f for f in rows if f["area_id"] == int(area)]
    if eq_type:
        rows = [f for f in rows if (f["eq_type"] or "").strip().lower() == eq_type.lower()]
    cat = a.get("cat", "")
    for f in rows:
        f["cat"] = S.form_category(f)
    if cat:
        rows = [f for f in rows if f["cat"].lower() == cat.lower()]
    types = sorted({(f["eq_type"] or "").strip() for f in S.list_forms(db, factory_id, "", show_inactive) if f["eq_type"]}, key=str.lower)
    is_live = lambda f: f["current_version_id"] and f["schedule_count"]      # noqa: E731
    status_fn = {"live": is_live, "draft": lambda f: not f["current_version_id"],
                 "nosched": lambda f: f["current_version_id"] and not f["schedule_count"],
                 "nodata": lambda f: not f["sub_count"]}
    counts = {"all": len(rows), "yes": sum(1 for f in rows if f["equipment_id"]),
              "no": sum(1 for f in rows if not f["equipment_id"] and not f["is_template"]),
              "tpl": sum(1 for f in rows if f["is_template"])}
    if bind in ("yes", "no"):
        rows = [f for f in rows if bool(f["equipment_id"]) == (bind == "yes") and not f["is_template"]]
    elif bind == "tpl":
        rows = [f for f in rows if f["is_template"]]
    counts.update({k: sum(1 for f in rows if fn(f)) for k, fn in status_fn.items()})
    counts["status_all"] = len(rows)
    if status in status_fn:
        rows = [f for f in rows if status_fn[status](f)]
    keys = {"code": lambda f: (f["code"] or ""), "last": lambda f: (f["last_submitted"] or ""),
            "loc": lambda f: ((f["factory_name"] or "~"), (f["area_name"] or "~"), f["name"]),
            "eq": lambda f: ((f["eq_code"] or "~"), f["name"])}
    if sort in keys:
        rows.sort(key=keys[sort], reverse=(sort == "last"))
    from .. import sign_blocks as SB
    ed = PM.editable_form_ids(db, current_user_id())                      # v0.52
    return render_template("forms/list.html", editable=ed, SB_SPANS=SB.SPANS, SB_ROWS=SB.PRESET_ROWS, SB_BOXES=SB.BOX_TH, SB_STAMPS=SB.STAMP_TH, forms=rows, factory_id=factory_id, q=q, show_inactive=show_inactive,
                           bind=bind, status=status, area=area, eq_type=eq_type, sort=sort, counts=counts, types=types,
                           cat=cat, categories=S.list_categories(db),
                           factories=M.list_factories(db), areas=M.list_areas(db),
                           equipment=M.list_equipment(db))


# ───────────────────────── ส่งออก / นำเข้าแบบฟอร์มเป็น Excel ─────────────────────────

MAX_XLSX = 5 * 1024 * 1024


def _xlsx_upload() -> bytes:
    f = request.files.get("file")
    if not f or not f.filename:
        raise S.ValidationError("เลือกไฟล์ Excel (.xlsx) ก่อน")
    if not f.filename.lower().endswith((".xlsx", ".xlsm")):
        raise S.ValidationError("รองรับเฉพาะไฟล์ .xlsx (ถ้าเป็น .xls ให้เปิดใน Excel แล้วบันทึกเป็น .xlsx)")
    data = f.read(MAX_XLSX + 1)
    if len(data) > MAX_XLSX:
        raise S.ValidationError("ไฟล์ใหญ่เกิน 5 MB")
    return data


@bp.route("/forms/<int:form_id>/export.xlsx")
@require_role(*ALL_ROLES)
def form_export_xlsx(form_id):
    from urllib.parse import quote

    from flask import Response

    from .. import form_xlsx as FX
    db = get_db()
    _load_form(db, form_id)
    body, fname = FX.export_form(db, form_id, use_draft=request.args.get("draft") == "1")
    ascii_name = "".join(ch if 32 < ord(ch) < 127 and ch not in '"\\;' else "_" for ch in fname)
    return Response(body, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(fname)}",
                             "Cache-Control": "no-store"})


@bp.route("/forms/<int:form_id>/import-xlsx", methods=["POST"])
@PM.require_form("edit")
def form_import_xlsx(form_id):
    from .. import form_xlsx as FX
    db = get_db()
    _load_form(db, form_id)
    try:
        res = FX.import_into_form(db, form_id, _xlsx_upload(), current_user_id())
        db.commit()
        flash(f"นำเข้าแล้ว {res['items']} หัวข้อ (เดิม {res['kept']} · ใหม่ {res['new']} · ลบ {res['removed']}) เป็นฉบับร่าง "
              "— ตรวจดูแล้วกด Publish เพื่อใช้งาน", "ok")
        return redirect(url_for("forms.builder", form_id=form_id))
    except S.ValidationError as exc:
        db.rollback()
        flash("นำเข้าไม่สำเร็จ — ยังไม่ได้บันทึกอะไร กรุณาแก้ไฟล์แล้วนำเข้าใหม่", "error")
        _flash_errors(exc)
        return redirect(url_for("forms.form_detail", form_id=form_id) + "#items")


@bp.route("/forms/import-xlsx", methods=["POST"])
@require_role(*MANAGE_ROLES)
def forms_import_new_xlsx():
    from .. import form_xlsx as FX
    db = get_db()
    try:
        fid = FX.import_new_form(db, _xlsx_upload(), current_user_id(), request.form.get("name", ""))
        db.commit()
        flash("สร้างแบบฟอร์มจากไฟล์ Excel แล้ว (ฉบับร่าง) — ผูกเครื่องจักร ตรวจหัวข้อ แล้วกด Publish", "ok")
        return redirect(url_for("forms.form_detail", form_id=fid) + "#settings")
    except S.ValidationError as exc:
        db.rollback()
        flash("นำเข้าไม่สำเร็จ — ยังไม่ได้บันทึกอะไร", "error")
        _flash_errors(exc)
        return redirect(url_for("forms.forms"))


@bp.route("/forms/category", methods=["POST"])
@require_role(*MANAGE_ROLES)
def forms_category():
    """ตั้งหมวดหมู่ให้หลายแบบฟอร์มพร้อมกัน (ใช้กรองบนมือถือ/รายงาน)"""
    db = get_db()
    ids = [int(x) for x in request.form.getlist("ids") if x.isdigit()]
    n = S.set_category(db, ids, request.form.get("category", ""), current_user_id())
    db.commit()
    flash(f"ตั้งหมวดหมู่ให้ {n} แบบฟอร์มแล้ว" if request.form.get("category", "").strip()
          else f"ล้างหมวดหมู่ {n} แบบฟอร์ม (ใช้ประเภทเครื่องจักรแทน)", "ok")
    qs = (request.form.get("qs") or "").lstrip("?")
    return redirect(url_for("forms.forms") + ("?" + qs if qs and "//" not in qs else ""))


@bp.route("/forms/sign-config", methods=["POST"])
@require_role(*MANAGE_ROLES)
def forms_sign_config():
    """ช่องลงนามเพิ่มในใบบันทึก (สิ่งแวดล้อม / Safety) ให้หลายแบบฟอร์มพร้อมกัน"""
    from .. import sign_blocks as SB
    db = get_db()
    ids = [int(x) for x in request.form.getlist("ids") if x.isdigit()]
    n = SB.save(db, ids, SB.from_form(request.form), current_user_id())
    SB.save_spans(db, ids, request.form.get("insp_span", "keep"), request.form.get("sup_span", "keep"), current_user_id())
    if request.form.get("doc_stamp", "keep") != "keep":
        SB.save_stamp(db, ids, request.form.get("doc_stamp", ""), current_user_id())
    db.commit()
    flash(f"ตั้งช่องลงนามในใบบันทึกให้ {n} แบบฟอร์มแล้ว", "ok")
    qs = (request.form.get("qs") or "").lstrip("?")
    return redirect(url_for("forms.forms") + ("?" + qs if qs and "//" not in qs else ""))


@bp.route("/forms/<int:form_id>/sign-config", methods=["POST"])
@require_role(*MANAGE_ROLES)
def form_sign_config(form_id):
    from .. import sign_blocks as SB
    db = get_db()
    _load_form(db, form_id)
    cfg = SB.from_form(request.form)
    SB.save(db, [form_id], cfg, current_user_id())
    if "insp_span" in request.form or "sup_span" in request.form:     # v0.37 ความยาวช่องเซ็นผู้ตรวจ / หัวหน้างาน
        SB.save_spans(db, [form_id], request.form.get("insp_span"), request.form.get("sup_span"), current_user_id())
    if "doc_stamp" in request.form:
        SB.save_stamp(db, [form_id], request.form.get("doc_stamp", ""), current_user_id())
    db.commit()
    spans = {k: request.form.get(k) for k in SB.SPAN_KEYS if request.form.get(k) not in (None, "", "auto")}
    flash("บันทึกช่องลงนามในใบบันทึกแล้ว" + (" (รวมความยาวช่องเซ็นผู้ตรวจ/หัวหน้างาน)" if spans else "")
          if not SB.is_empty(cfg) or spans else "บันทึกแล้ว — ไม่มีแถว/กล่องลงนามเพิ่ม (ใช้ค่าของแม่แบบ ถ้ามี)", "ok")
    return redirect(url_for("forms.form_detail", form_id=form_id) + "#settings")


@bp.route("/forms/<int:form_id>/bind", methods=["POST"])
@require_role(*MANAGE_ROLES)
def form_bind(form_id):
    """ผูกแบบฟอร์มกับเครื่องจักรที่มีอยู่ (จากหน้ารายการแบบฟอร์ม)"""
    db = get_db()
    _load_form(db, form_id)
    key = (request.form.get("equipment") or "").strip()
    code = key.split(" — ", 1)[0].strip()
    row = db.execute("SELECT id FROM equipment WHERE code=? COLLATE NOCASE", (code,)).fetchone() or \
        (db.execute("SELECT id FROM equipment WHERE id=?", (int(key),)).fetchone() if key.isdigit() else None)
    back = safe_next(request.form.get("back"), url_for("forms.forms"))
    if not row:
        flash(f"ไม่พบเครื่องจักร '{key}'", "error")
        return redirect(back)
    try:
        S.update_form_meta(db, form_id, {"equipment_id": row["id"]}, current_user_id())
        db.commit()
        flash("ผูกแบบฟอร์มกับเครื่องจักรแล้ว (ใช้โรงงาน/พื้นที่ของเครื่อง)", "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(back)


@bp.route("/forms", methods=["POST"])
@require_role(*MANAGE_ROLES)
def form_create():
    db = get_db()
    try:
        form_id = S.create_form(db, request.form.to_dict(), current_user_id())
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return redirect(url_for("forms.forms"))
    flash("สร้างแบบฟอร์มแล้ว เพิ่มหัวข้อตรวจแล้วกด Publish", "ok")
    return redirect(url_for("forms.builder", form_id=form_id))


@bp.route("/forms/<int:form_id>")
@require_role(*ALL_ROLES)
def form_detail(form_id):
    db = get_db()
    form = _load_form(db, form_id)
    items = S.get_items(db, form["current_version_id"]) if form["current_version_id"] else []
    from .. import formtpl as T
    tpl = T.get_template(db, form)
    kids = T.children(db, form_id) if form.get("is_template") else []
    ov = T.overrides(db, form_id) if tpl else {}
    tpl_items = S.get_items(db, tpl["current_version_id"]) if tpl and tpl["current_version_id"] else []
    extra = {"tpl": tpl, "children": kids, "overrides": ov, "tpl_items": tpl_items}
    if form.get("is_template"):
        taken = {c["equipment_id"] for c in kids}
        extra["apply_equipment"] = [e for e in M.list_equipment(db) if e["id"] not in taken]
        extra["link_forms"] = [f for f in S.list_forms(db) if not f.get("is_template") and not f.get("template_id")
                               and f["current_version_id"]]
    extra["tpm"] = _tpm_context(db, form, items)
    extra["scada_n"] = (db.execute("SELECT COUNT(DISTINCT item_key) FROM cs_source_tags WHERE form_id=? AND item_key<>''", (form_id,)).fetchone()[0],
                        sum(1 for i in items if i["item_type"] in ("number", "counter", "calc")))      # v0.46
    from .. import change_requests as CR
    extra["chreq_open"] = CR.listing(db, "active", form_id=form_id)
    from .. import sign_blocks as SB
    own_sb = SB.own(db, form_id)
    extra["sb"] = {"own": own_sb, "eff": SB.effective(db, form), "inherited": SB.is_empty(own_sb) and bool(form.get("template_id")),
                   "custom": SB.custom_text(own_sb), "ROWS": SB.PRESET_ROWS, "BOXES": SB.BOX_TH,
                   "stamp": SB.stamp_own(db, form_id), "stamp_eff": SB.stamp_of(db, form), "STAMPS": SB.STAMP_TH,
                   "SPANS": SB.SPANS, "resolved": [SB.SPANS.get(c) or SB.span_th(c) for c in SB.resolve_spans(db, form)],
                   "tpl_spans": SB.own(db, form["template_id"]) if form.get("template_id") else {}}
    extra["fa"] = PM.form_access(db, current_user_id(), form_id)          # v0.52
    return render_template("forms/detail.html", **extra, categories=S.list_categories(db), sections=S.get_sections(db, form["current_version_id"], items), form=form, this_month=datetime.now().strftime("%Y-%m"), items=items, versions=S.list_versions(db, form_id),
                           schedules=S.list_schedules(db, form_id), draft=S.get_draft(db, form_id),
                           factories=M.list_factories(db), areas=M.list_areas(db), equipment=M.list_equipment(db),
                           technicians=[u for u in M.list_users(db, include_inactive=False)
                                        if u["role"] in INSPECT_ROLES])


def _tpm_context(db, form: dict, items: list[dict]) -> dict | None:
    """ข้อมูลแท็บ "แผน TPM" — None = ไม่แสดงแท็บ"""
    from .. import cmms_tpm as TPM
    if form.get("is_template") or not TPM.available(current_app.config):
        return None
    ctx = {"enabled": TPM.get_settings(db)["enabled"], "plans": [], "links": {}, "error": "", "legacy_id": None}
    eq = db.execute("SELECT legacy_id FROM equipment WHERE id=?", (form["equipment_id"],)).fetchone() \
        if form.get("equipment_id") else None
    ctx["legacy_id"] = eq["legacy_id"] if eq else None
    ctx["links"] = {lk["plan_id"]: lk["items"] for lk in TPM.form_links(db, form["id"])}
    if ctx["legacy_id"]:
        try:
            ctx["plans"] = TPM.plans_for_equipment(current_app.config, ctx["legacy_id"])
        except Exception as exc:                        # noqa: BLE001 — UT-CMMS ล็อก/เสีย ต้องไม่ทำให้หน้าแบบฟอร์มเปิดไม่ได้
            ctx["error"] = str(exc)
    for p in ctx["plans"]:
        p["suggest"] = TPM.suggest(items, p)
        p["linked"] = p["id"] in ctx["links"]
        p["items"] = ctx["links"].get(p["id"], [])
    return ctx


@bp.route("/forms/<int:form_id>/tpm-links", methods=["POST"])
@require_role(*MANAGE_ROLES)
def form_tpm_links(form_id):
    from .. import cmms_tpm as TPM
    db = get_db()
    _load_form(db, form_id)
    plan_items = {}
    for v in request.form.getlist("plan"):
        if v.isdigit():
            pid = int(v)
            plan_items[pid] = [k for k in request.form.getlist(f"items_{pid}") if k] \
                if request.form.get(f"scope_{pid}") == "items" else []
    try:
        n = TPM.save_links(db, current_app.config, form_id, plan_items, current_user_id())
        db.commit()
        flash(f"เชื่อมแผน TPM แล้ว {n} แผน — ส่งผลตรวจแบบฟอร์มนี้แล้วแผนจะอัปเดตใน UT-CMMS อัตโนมัติ" if n
              else "ยกเลิกการเชื่อมแผน TPM ทั้งหมดของแบบฟอร์มนี้แล้ว", "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("forms.form_detail", form_id=form_id) + "#tpm")


@bp.route("/forms/<int:form_id>/meta", methods=["POST"])
@require_role(*MANAGE_ROLES)
def form_meta(form_id):
    db = get_db()
    _load_form(db, form_id)
    data = request.form.to_dict()
    data["active"] = 1 if request.form.get("active") else 0
    data["require_point_scan"] = 1 if request.form.get("require_point_scan") else 0
    try:
        S.update_form_meta(db, form_id, data, current_user_id())
        db.commit()
        flash("บันทึกข้อมูลแบบฟอร์มแล้ว", "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("forms.form_detail", form_id=form_id) + "#settings")


def _ids_arg(values) -> list[int]:
    out = []
    for v in values:
        for part in str(v).split(","):
            if part.strip().isdigit():
                out.append(int(part))
    return list(dict.fromkeys(out))


@bp.route("/api/forms/delete-check")
@require_role(*MANAGE_ROLES)
def api_form_delete_check():
    """สรุปสิ่งที่จะหายไปก่อนลบแบบฟอร์ม (หัวหน้างานลบได้เฉพาะแบบฟอร์มที่ยังไม่มีผลตรวจ)"""
    db = get_db()
    impact = S.form_delete_impact(db, _ids_arg(request.args.getlist("ids")))
    is_admin = session.get("role") == "admin"
    for f in impact:
        f["allowed"] = is_admin or f["submissions"] == 0
    return jsonify({"forms": impact, "is_admin": is_admin})


@bp.route("/forms/delete", methods=["POST"])
@require_role(*MANAGE_ROLES)
def forms_delete():
    import os
    from flask import current_app
    db = get_db()
    ids = _ids_arg(request.form.getlist("ids"))
    if not ids:
        flash("ยังไม่ได้เลือกแบบฟอร์ม", "error")
        return redirect(url_for("forms.forms"))
    impact = S.form_delete_impact(db, ids)
    is_admin = session.get("role") == "admin"
    blocked = [f for f in impact if f["submissions"] and not is_admin]
    if blocked:
        flash("แบบฟอร์มที่มีผลตรวจแล้ว ลบได้เฉพาะผู้ดูแลระบบ: " + ", ".join(f["code"] or f["name"] for f in blocked), "error")
        return redirect(url_for("forms.forms"))
    if any(f["submissions"] for f in impact) and request.form.get("confirm_history") != "1":
        flash("ต้องยืนยันการลบผลตรวจเดิมด้วย", "error")
        return redirect(url_for("forms.forms"))
    files, done = [], []
    try:
        for f in impact:
            res = S.delete_form(db, f["id"], current_user_id())
            files += res["files"]
            done.append(res["code"] or res["name"])
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return redirect(url_for("forms.forms"))
    root = os.path.abspath(current_app.config["UPLOAD_FOLDER"])
    for rel in files:                                   # ลบรูปหลังบันทึกฐานข้อมูลสำเร็จ
        path = os.path.abspath(os.path.join(root, rel or ""))
        if rel and path.startswith(root + os.sep) and os.path.isfile(path):
            try:
                os.remove(path)
            except OSError:
                pass
    flash(f"ลบแบบฟอร์มแล้ว {len(done)} รายการ: " + ", ".join(done[:10]) + (" …" if len(done) > 10 else ""), "ok")
    return redirect(url_for("forms.forms"))


@bp.route("/forms/<int:form_id>/versions/<int:version_id>")
@require_role(*ALL_ROLES)
def version_view(form_id, version_id):
    db = get_db()
    form = _load_form(db, form_id)
    version = S.get_version(db, version_id)
    if not version or version["form_id"] != form_id:
        abort(404)
    items = S.get_items(db, version_id)
    return render_template("forms/version.html", form=form, version=version, items=items,
                           sections=S.get_sections(db, version_id, items))


@bp.route("/forms/<int:form_id>/builder")
@PM.require_form("edit")
def builder(form_id):
    db = get_db()
    form = _load_form(db, form_id)
    if form.get("template_id"):
        flash("แบบฟอร์มนี้ใช้หัวข้อจากแม่แบบ — แก้หัวข้อที่แม่แบบ (มีผลทุกเครื่อง) หรือปรับเกณฑ์เฉพาะเครื่องนี้ที่แท็บหัวข้อตรวจ", "ok")
        return redirect(url_for("forms.builder", form_id=form["template_id"]))
    draft = S.get_draft(db, form_id)   # ยังไม่สร้างฉบับร่างจนกว่าจะกดบันทึกครั้งแรก
    next_no = draft["version_no"] if draft else db.execute(
        "SELECT COALESCE(MAX(version_no),0)+1 FROM cs_form_versions WHERE form_id=?", (form_id,)).fetchone()[0]
    approvers = [r[0] for r in db.execute(
        "SELECT name FROM users WHERE active=1 AND role IN ('manager','admin','supervisor') ORDER BY role='supervisor', name")]
    children = db.execute("SELECT COUNT(*) FROM cs_forms WHERE template_id=?", (form_id,)).fetchone()[0]
    from .. import change_requests as CR
    chreqs = []
    for fid in [form_id] + [r[0] for r in db.execute("SELECT id FROM cs_forms WHERE template_id=?", (form_id,))]:
        for r in CR.listing(db, "active", form_id=fid):
            chreqs.append({"id": r["id"], "item_key": r["item_key"], "item_name": r["item_name"], "kind_th": CR.KINDS.get(r["kind"], r["kind"]),
                           "detail": r["detail"], "proposed": r["proposed"], "requester_name": r["requester_name"],
                           "url": url_for("forms.change_request_detail", cid=r["id"])})
    return render_template("forms/builder.html", form=form, draft=draft, next_version_no=next_no,
                           fa=PM.form_access(db, current_user_id(), form_id),
                           approvers=approvers, today=date.today().isoformat(), rev=S.rev_label(next_no),
                           children=children, presets=CR.presets(db), chreqs=chreqs,
                           FREQ_ALL=__import__("ecs.itemfreq", fromlist=["all_freqs"]).all_freqs(db))


# ───────────────────────── ป้าย QR จุดตรวจ ─────────────────────────

@bp.route("/forms/<int:form_id>/point-labels")
@PM.require_form("edit")
def point_labels(form_id):
    from .. import formtpl as T
    from ..points import point_code
    from .admin import qr_base, qr_bases, qr_svg
    db = get_db()
    form = _load_form(db, form_id)
    targets = [S.get_form(db, c["id"]) for c in T.children(db, form_id)] if form.get("is_template") else [form]
    targets = [t for t in targets if t]
    # แบบฟอร์มที่ผูกเครื่องจักร → ไปหน้าพิมพ์ป้ายรวม (อยู่คู่กับป้าย QR เครื่อง แยกหมวดจุดตรวจ)
    if targets and all(t.get("equipment_id") for t in targets) and all(t.get("require_point_scan") for t in targets):
        return redirect(url_for("admin.qr_labels", id=sorted({t["equipment_id"] for t in targets}),
                                form=[t["id"] for t in targets], kind="points", base=request.args.get("base") or None))
    base = qr_base()
    labels = []
    for f in targets:
        if not f or not f["current_version_id"]:
            continue
        for sec in S.get_sections(db, f["current_version_id"]):
            code = point_code(f["id"], sec["name"])
            url = f"{base}/p/{f['id']}/{code}"
            labels.append({"form": f, "sec": sec, "code": code, "url": url, "svg": qr_svg(url, box=5)})
    return render_template("forms/point_labels.html", form=form, labels=labels, qr_bases=qr_bases(), qr_base_now=base,
                           missing_lib=bool(labels) and labels[0]["svg"] is None)


# เส้นทางที่แยกไปไฟล์ย่อย (ต้อง import ท้ายไฟล์ เพราะไฟล์ย่อยอ้างชื่อจากไฟล์นี้)
from . import forms_builder_api  # noqa: E402,F401
from . import forms_schedules  # noqa: E402,F401
from . import forms_templates  # noqa: E402,F401
from . import forms_requests  # noqa: E402,F401
