"""ecs/views/mobile.py — หน้าช่างผู้ตรวจ (มือถือ/แท็บเล็ต): งานของฉัน, สแกน QR, กรอกผลตรวจ, ส่งแบบออฟไลน์"""
from __future__ import annotations

import json
import os

from flask import (Blueprint, Response, current_app, jsonify, redirect, render_template, request, send_from_directory,
                   session, url_for)

from .. import __version__
from .. import masterdata as M
from .. import services as S
from .. import submissions as SUB
from ..db import get_db
from ..security import ALL_ROLES, INSPECT_ROLES, current_user_id, require_role

bp = Blueprint("mobile", __name__)


@bp.route("/m/")
@require_role(*INSPECT_ROLES)
def home():
    return render_template("mobile/home.html", appr=_approver_counts(get_db()))


def _approver_counts(db) -> dict | None:
    """v0.38 ผู้อนุมัติ (หัวหน้างาน / Sr.Tech / FM / SV …) เห็นทางลัดรายการอนุมัติบนหน้างานของฉัน"""
    uid = current_user_id()
    if not SUB.can_approve(db, uid):
        return None
    try:
        from datetime import date, timedelta
        from .review import _week_groups
        pc = SUB.pending_counts(db, uid)
        me = SUB.user_scope(db, uid)
        fac = me["factory_id"] if me["role"] != "admin" else None
        m0 = date.today().replace(day=1)
        weeks, first = [], None
        for m in ((m0 - timedelta(days=1)).replace(day=1), m0):             # เดือนก่อน + เดือนนี้
            gs = [g for g in _week_groups(db, m, fac) if g["pending"]]
            if gs and not first:
                first = m
            weeks += gs
        return {"pending": pc["total"], "ng": pc["ng"], "weeks": len(weeks), "week_subs": sum(g["pending"] for g in weeks),
                "week_month": first.strftime("%Y-%m") if first else None}
    except Exception:                                   # noqa: BLE001 — ทางลัดต้องไม่ทำให้หน้างานเปิดไม่ได้
        current_app.logger.exception("approver counts failed")
        return {"pending": 0, "ng": 0, "weeks": 0, "week_subs": 0, "week_month": None}


@bp.route("/m/fill")
@require_role(*INSPECT_ROLES)
def fill():
    # หน้าเดียวสำหรับทุกแบบฟอร์ม (พารามิเตอร์อยู่หลัง # เช่น /m/fill#f=12&r=40) เพื่อให้เก็บไว้ใช้ออฟไลน์ได้
    return render_template("mobile/fill.html")


@bp.route("/p/<int:form_id>/<code>")
def point_qr(form_id, code):
    """ป้าย QR ที่จุดตรวจ → เปิดหน้ากรอกของแบบฟอร์มนั้น พร้อมยืนยันจุด (ตรวจรหัสในหน้ากรอก/ตอนส่ง)"""
    code = "".join(ch for ch in code.upper() if ch.isalnum())[:12]
    if "user_id" not in session:
        # v0.31 ยังไม่ได้เข้าสู่ระบบ (เช่น แอปกล้องเปิดเบราว์เซอร์อื่น) → login แล้วกลับมาที่ QR นี้
        # (เดิมส่งไป /m/fill#... แล้ว login ทำ #f=… หาย → เปิดแบบฟอร์มไม่เจอ)
        return redirect(url_for("auth.login", next=request.path))
    return redirect(url_for("mobile.fill") + f"#f={form_id}&pt={code}")


@bp.route("/m/scan")
@require_role(*INSPECT_ROLES)
def scan():
    return render_template("mobile/scan.html")


@bp.route("/e/<token>")
def equipment_qr(token):
    """ปลายทางของ QR ที่ติดเครื่องจักร"""
    if "user_id" not in session:
        return redirect(url_for("auth.login", next=request.path))
    db = get_db()
    eq = M.get_equipment_by_token(db, token)
    if not eq:
        return render_template("error.html", code=404,
                               message="ไม่พบเครื่องจักรของ QR นี้ (QR อาจถูกเปลี่ยนใหม่ หรือเครื่องถูกปิดใช้งาน)"), 404
    forms = [f for f in S.list_forms(db, equipment_id=eq["id"]) if f["current_version_id"]]
    if session.get("role") not in INSPECT_ROLES:
        return redirect(url_for("admin.equipment_detail", equipment_id=eq["id"]))
    if len(forms) == 1:
        return redirect(url_for("mobile.fill") + f"#f={forms[0]['id']}&qr=1")      # v0.51 สแกนที่เครื่อง = ยืนยันเครื่องแล้ว
    return render_template("mobile/choose.html", eq=eq, forms=forms)


@bp.route("/m/report")
@require_role(*INSPECT_ROLES)
def report():
    """แจ้งปัญหาที่พบนอกเช็คชีท: ถ่ายรูป + พิมพ์ 1 บรรทัด → เปิดงานแก้ไขให้ทันที"""
    db = get_db()
    try:
        eq_id = int(request.args.get("eq") or 0)
    except ValueError:
        eq_id = 0
    eq = M.get_equipment(db, eq_id) if eq_id else None
    if not eq:
        return redirect(url_for("mobile.scan", report=1))
    recent = [dict(r) for r in db.execute("""SELECT code, title, status, created_at FROM cs_actions
                                             WHERE equipment_id=? AND status IN ('open','in_progress','done')
                                             ORDER BY id DESC LIMIT 3""", (eq_id,))]
    return render_template("mobile/report.html", eq=eq, recent=recent)


@bp.route("/api/m/report", methods=["POST"])
@require_role(*INSPECT_ROLES)
def api_report():
    from .. import capa
    db = get_db()
    try:
        eq_id = int(request.form.get("equipment_id") or 0)
        res = capa.report_problem(db, eq_id, request.form.get("text", ""), current_user_id(),
                                  urgent=request.form.get("urgent") == "1", photos=request.files.getlist("photos"),
                                  upload_dir=current_app.config["UPLOAD_FOLDER"],
                                  max_bytes=current_app.config["MAX_PHOTO_MB"] * 1024 * 1024)
        db.commit()
    except (S.ValidationError, ValueError) as exc:
        db.rollback()
        msg = exc.errors[0] if isinstance(exc, S.ValidationError) else "ข้อมูลไม่ถูกต้อง"
        return jsonify({"error": msg}), 422
    from ..notify import wake
    wake()
    return jsonify({"success": True, **res, "url": url_for("work.action_detail", action_id=res["id"])})


# ───────────────────────── v0.38 ช่างแจ้งเครื่องหยุดเดิน / PM จากมือถือ ─────────────────────────

def _eq_scope(db, eq_id: int):
    eq = db.execute("SELECT * FROM equipment WHERE id=? AND active=1", (eq_id,)).fetchone()
    if not eq:
        return None, (jsonify({"error": "ไม่พบเครื่องจักร"}), 404)
    return dict(eq), None                       # v0.53 แจ้งหยุด/เดินเครื่องได้ทุกคน ทุกโรงงาน (บันทึกชื่อผู้กดไว้ในประวัติ)


def _tell_supervisors(db, eq: dict, title: str, body: str) -> None:
    """แจ้งหัวหน้างาน/ผู้อนุมัติของโรงงานนั้นทางกระดิ่งในระบบ (ไม่ทำให้งานหลักล้มถ้าผิดพลาด)"""
    try:
        from .. import notify as N
        me = current_user_id()
        for u in N.approvers(db):
            if u["id"] == me or (u.get("factory_id") and eq.get("factory_id") and u["factory_id"] != eq["factory_id"]):
                continue
            N.notify_user_app(db, u["id"], "equipment_down", title, body, "/equipment/down", "info",
                              f"eq:{eq['id']}:{S.ts()}:{u['id']}")
    except Exception:                                   # noqa: BLE001
        current_app.logger.exception("notify supervisors (equipment) failed")


@bp.route("/api/m/equipment/<int:eq_id>/down", methods=["POST"])
@require_role(*ALL_ROLES)
def api_equipment_down(eq_id):
    from .. import downtime as DT
    db = get_db()
    eq, err = _eq_scope(db, eq_id)
    if err:
        return err
    data = request.get_json(silent=True) or {}
    cat = data.get("category") if data.get("category") in DT.CATEGORIES else "other"
    reason = str(data.get("reason") or "").strip() or DT.CATEGORIES[cat]      # มือถือ: ไม่กรอกรายละเอียด = ใช้ชื่อสาเหตุ
    since = None
    if data.get("since"):                           # v0.53 หยุดย้อนหลัง (ตัดกะ) ได้ไม่เกิน 24 ชม.
        since = S.parse_ts(str(data["since"]).replace("T", " ")[:16] + ":00")
        now = S.now_dt()
        if not since or since > now + S.timedelta(minutes=5) or since < now - S.timedelta(hours=24):
            return jsonify({"error": "เวลาเริ่มหยุดต้องอยู่ภายใน 24 ชม. ที่ผ่านมา"}), 422
        if since > now:
            since = now
    try:
        res = DT.set_down(db, eq_id, current_user_id(), reason, cat, data.get("expected_end") or None, start_at=since)
    except S.ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0]}), 422
    me = SUB.user_scope(db, current_user_id())
    _tell_supervisors(db, eq, f"⛔ {eq['code']} แจ้งหยุด: {DT.CATEGORIES[cat]}",
                      f"{eq['name'] or ''} · {reason} · แจ้งโดย {me.get('name') or ''} · งดรอบตรวจ {res['skipped']} รอบ")
    db.commit()
    return jsonify({"ok": True, **res})


@bp.route("/api/m/equipment/<int:eq_id>/running", methods=["POST"])
@require_role(*ALL_ROLES)
def api_equipment_running(eq_id):
    from .. import downtime as DT
    db = get_db()
    eq, err = _eq_scope(db, eq_id)
    if err:
        return err
    data = request.get_json(silent=True) or {}
    try:
        res = DT.set_running(db, eq_id, current_user_id(), str(data.get("note") or ""))
    except S.ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0]}), 422
    me = SUB.user_scope(db, current_user_id())
    _tell_supervisors(db, eq, f"✅ {eq['code']} กลับมาเดินแล้ว",
                      f"{eq['name'] or ''} · แจ้งโดย {me.get('name') or ''} · เปิดรอบตรวจคืน {res['restored']} รอบ")
    db.commit()
    return jsonify({"ok": True, **res})


def _down_now(db) -> list[dict]:
    """เครื่องที่แจ้งหยุด/PM อยู่ (ในโรงงานของผู้ใช้) — แสดงในหน้างานของฉัน พร้อมปุ่ม 'กลับมาเดินแล้ว'"""
    from .. import downtime as DT
    me = SUB.user_scope(db, current_user_id())
    fac = me["factory_id"] if me["role"] != "admin" else None
    return [{"id": d["id"], "code": d["code"], "name": d["name"], "reason": d["down_reason"], "since": d["down_since"],
             "until": d["down_until"], "late": d["late"], "factory_id": d["factory_id"], "factory_name": d["factory_name"],
             "area_name": d["area_name"], "by": d["down_by_name"]} for d in DT.down_list(db, fac)]


@bp.route("/api/m/lookup")
@require_role(*INSPECT_ROLES)
def api_lookup():
    """ค้นหาเครื่องจากรหัสที่พิมพ์เอง หรือจาก URL/Token ที่สแกนได้"""
    db = get_db()
    raw = (request.args.get("q") or "").strip()
    token = raw.rsplit("/e/", 1)[-1] if "/e/" in raw else raw
    eq = M.get_equipment_by_token(db, token) or \
        (dict(r) if (r := db.execute("SELECT * FROM equipment WHERE code=? AND active=1", (raw,)).fetchone()) else None)
    if not eq:
        return jsonify({"error": f"ไม่พบเครื่องจักร '{raw}'"}), 404
    forms = [{"id": f["id"], "name": f["name"], "code": f["code"]}
             for f in S.list_forms(db, equipment_id=eq["id"]) if f["current_version_id"]]
    return jsonify({"equipment": {"id": eq["id"], "code": eq["code"], "name": eq["name"]}, "forms": forms})


@bp.route("/api/m/tasks")
@require_role(*INSPECT_ROLES)
def api_tasks():
    db = get_db()
    S.generate_rounds(db)
    S.refresh_round_statuses(db)
    db.commit()
    data = SUB.my_tasks(db, current_user_id())
    form_ids = sorted({r["form_id"] for g in ("returned", "overdue", "due", "upcoming") for r in data["groups"][g]})
    data["prefetch_forms"] = form_ids
    data["tpm"] = _tpm_due(db)
    data["down"] = _down_now(db)
    data["sent"] = SUB.sent_today(db, current_user_id())              # v0.95 ถึงระบบแล้ว (ยืนยันจากเซิร์ฟเวอร์)
    return jsonify(data)


def _tpm_due(db, form_ids: list[int] | None = None) -> list[dict]:
    """แผน TPM ที่ถึงช่วงทำของแบบฟอร์มที่ผู้ใช้ตรวจได้ — ผิดพลาดต้องไม่ทำให้หน้างานโหลดไม่ได้"""
    from .. import cmms_tpm as TPM
    try:
        forms = {f["id"]: f for f in SUB.mobile_forms(db, current_user_id())}
        rows = TPM.due_for_forms(db, current_app.config, list(forms) if form_ids is None else
                                 [i for i in form_ids if i in forms])
    except Exception:                                   # noqa: BLE001
        current_app.logger.exception("tpm due failed")
        return []
    for r in rows:
        f = forms.get(r["form_id"]) or {}
        r.update(cat=f.get("cat", ""), factory_name=f.get("factory_name", ""), area_name=f.get("area_name", ""))
    return rows


@bp.route("/api/m/forms")
@require_role(*INSPECT_ROLES)
def api_forms():
    return jsonify({"forms": SUB.mobile_forms(get_db(), current_user_id())})


@bp.route("/api/m/forms/<int:form_id>/package")
@require_role(*INSPECT_ROLES)
def api_package(form_id):
    db = get_db()
    try:
        round_id = int(request.args.get("round") or 0) or None
        pkg = SUB.form_package(db, form_id, round_id)
    except S.ValidationError as exc:
        return jsonify({"error": exc.errors[0]}), 404
    except ValueError:
        return jsonify({"error": "round ไม่ถูกต้อง"}), 400
    return jsonify(_package_extras(db, form_id, pkg))


# ───────────────────────── v0.40 เตรียมออฟไลน์ทั้งกะ ─────────────────────────

@bp.route("/api/m/offline-pack")
@require_role(*INSPECT_ROLES)
def api_offline_pack():
    """ทุกอย่างที่ต้องใช้ตอนไม่มีสัญญาณ ในคำขอเดียว: งานวันนี้ · เส้นทาง (พร้อมจุด) · รายการแบบฟอร์ม · QR เครื่อง → แบบฟอร์ม
    form_ids = แบบฟอร์มที่ควรโหลดเก็บ (งานที่เหลือของวันนี้ + จุดในเส้นทาง · all=1 = ทุกแบบฟอร์มที่ตรวจได้)"""
    from .. import walkroutes as R
    db = get_db()
    uid = current_user_id()
    S.generate_rounds(db)
    S.refresh_round_statuses(db)
    db.commit()
    tasks = SUB.my_tasks(db, uid)
    tasks["prefetch_forms"] = sorted({r["form_id"] for g in ("returned", "overdue", "due", "upcoming") for r in tasks["groups"][g]})
    tasks["tpm"] = _tpm_due(db)
    tasks["down"] = _down_now(db)
    me = SUB.user_scope(db, uid)
    routes = R.routes_for_user(db, me)
    details = {}
    for r in routes:
        st = R.route_status(db, r["id"])
        if st:
            details[r["id"]] = st
    forms = SUB.mobile_forms(db, uid)
    mine = {f["id"] for f in forms}
    want = set(tasks["prefetch_forms"]) | {s["form_id"] for d in details.values() for s in d.get("stops", [])}
    if request.args.get("all") == "1":
        want |= mine
    want &= mine
    tokens: dict[str, list[int]] = {}
    if mine:
        ids = sorted(mine)
        for r in db.execute(f"""SELECT e.qr_token, f.id FROM cs_forms f JOIN equipment e ON e.id=f.equipment_id
                                WHERE f.id IN ({','.join('?' * len(ids))}) AND COALESCE(e.qr_token,'')<>''""", ids):
            tokens.setdefault(r[0], []).append(r[1])
    return jsonify({"now": S.ts(), "tasks": tasks, "routes": routes, "route_details": details, "forms": forms,
                    "tokens": tokens, "form_ids": sorted(want)})


@bp.route("/api/m/packages")
@require_role(*INSPECT_ROLES)
def api_packages():
    """หลายแบบฟอร์มในคำขอเดียว (สูงสุด 25) — ใช้ตอนเตรียมออฟไลน์ · แบบฟอร์มที่เปิดไม่ได้ส่ง {error}"""
    db = get_db()
    mine = {f["id"] for f in SUB.mobile_forms(db, current_user_id())}
    ids = [int(x) for x in (request.args.get("ids") or "").split(",") if x.strip().isdigit()][:25]
    out = {}
    for fid in ids:
        if fid not in mine:
            out[fid] = {"error": "ไม่มีสิทธิ์แบบฟอร์มนี้"}
            continue
        try:
            out[fid] = _package_extras(db, fid, SUB.form_package(db, fid, None))
        except S.ValidationError as exc:
            out[fid] = {"error": exc.errors[0]}
    return jsonify({"packages": out})


def _package_extras(db, form_id: int, pkg: dict) -> dict:
    from .. import backfill as BF
    rnd = pkg.get("round")                              # v0.55 สิทธิ์ลงข้อมูลย้อนหลัง (รายวัน) ของรอบที่เปิดอยู่
    pkg["can_backfill"] = BF.allowed(db, current_user_id(), {**rnd, "form_id": form_id}) if rnd else BF.can_grant(db, current_user_id())
    pkg["tpm"] = _tpm_due(db, [form_id])
    try:                                                # v0.39 ประวัติเครื่อง (เก็บไปกับแบบฟอร์มในเครื่อง ใช้ได้ตอนออฟไลน์)
        from .. import fieldinfo as FI
        pkg["machine"] = FI.machine_history(db, form_id, current_app.config)
    except Exception:                                   # noqa: BLE001
        current_app.logger.exception("machine history failed")
        pkg["machine"] = {}
    return pkg


# ───────────────────────── v0.39 แผนงาน 7/30 วัน · สถิติของฉัน ─────────────────────────

@bp.route("/m/plan")
@require_role(*INSPECT_ROLES)
def plan():
    from .. import fieldinfo as FI
    days = 30 if request.args.get("days") == "30" else 7
    data = FI.plan(get_db(), current_user_id(), days, current_app.config)
    return render_template("mobile/plan.html", data=data, days=days)


@bp.route("/m/me")
@require_role(*INSPECT_ROLES)
def my_stats():
    from .. import fieldinfo as FI
    db = get_db()
    return render_template("mobile/me.html", st=FI.my_stats(db, current_user_id()))


@bp.route("/api/m/submissions", methods=["POST"])
@require_role(*INSPECT_ROLES)
def api_submit():
    db = get_db()
    try:
        payload = json.loads(request.form.get("payload") or "{}")
    except ValueError:
        return jsonify({"error": "ข้อมูลที่ส่งมาไม่ถูกต้อง"}), 400
    photos = {k: v for k, v in request.files.items()}
    try:
        result = SUB.create_submission(db, payload, photos, current_user_id(), current_app.config["UPLOAD_FOLDER"],
                                       current_app.config["MAX_PHOTO_MB"] * 1024 * 1024)
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        return jsonify({"error": "ส่งผลตรวจไม่สำเร็จ", "errors": exc.errors}), 422
    base_url = request.host_url.rstrip("/") + request.script_root
    if result.get("ng_count"):
        from ..cmms_wo import after_submit
        wo = after_submit(db, current_app.config, result["id"], current_user_id(), base_url)
        if wo:
            result["cmms_wo"] = wo["wo_number"]
    from ..cmms_tpm import after_submit as tpm_after_submit
    tpm = tpm_after_submit(db, current_app.config, result["id"], current_user_id(), base_url)
    if tpm:
        result["tpm"] = [t["task"] for t in tpm]
    from ..cmms_status import after_submit as status_after_submit
    st = status_after_submit(db, current_app.config, result["id"])
    if st:
        result["status_minutes"] = st["minutes"]
    if result.get("anomalies"):
        from ..notify import wake
        wake()          # ส่งแจ้งเตือน L1 ทันที ไม่ต้องรอรอบถัดไป
    return jsonify({"success": True, **result})


@bp.route("/api/m/status/start", methods=["POST"])
@require_role(*INSPECT_ROLES)
def api_status_start():
    """เปิดหน้ากรอก → สถานะช่างใน UT-CMMS เป็น "ตรวจเช็ค" (ไม่ได้เชื่อม/ผิดพลาด = คืนว่าง ไม่กระทบการกรอก)"""
    from .. import cmms_status as ST
    data = request.get_json(silent=True) or {}
    try:
        form_id = int(data.get("form_id") or 0)
    except (TypeError, ValueError):
        form_id = 0
    if not form_id or not S.get_form(get_db(), form_id):
        return jsonify({"error": "ไม่พบแบบฟอร์ม"}), 404
    return jsonify(ST.safe(ST.start, get_db(), current_app.config, current_user_id(), form_id,
                           str(data.get("client_uuid") or "")[:64]) or {})


@bp.route("/api/m/status/stop", methods=["POST"])
@require_role(*INSPECT_ROLES)
def api_status_stop():
    """ออกจากหน้ากรอกโดยไม่ส่ง → หยุดนับเวลา"""
    from .. import cmms_status as ST
    data = request.get_json(silent=True) or {}
    try:
        form_id = int(data.get("form_id") or 0) or None
    except (TypeError, ValueError):
        form_id = None
    return jsonify({"stopped": ST.safe(ST.stop, get_db(), current_app.config, current_user_id(), form_id)})


@bp.route("/api/m/ping")
def api_ping():
    """ตรวจการเชื่อมต่อ + คืน CSRF token ล่าสุด (หน้าที่เปิดจากแคชออฟไลน์อาจถือ token เก่า)"""
    from ..security import csrf_token
    logged_in = "user_id" in session
    resp = jsonify({"ok": True, "logged_in": logged_in, "time": S.ts(), "csrf": csrf_token() if logged_in else ""})
    resp.headers["Cache-Control"] = "no-store"
    return resp


@bp.route("/m/sw.js")
def service_worker():
    path = os.path.join(current_app.static_folder, "m", "sw.js")
    with open(path, encoding="utf-8") as fh:
        body = fh.read().replace("__VERSION__", f"{__version__}-{int(os.path.getmtime(path))}")
    resp = Response(body, mimetype="application/javascript")
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@bp.route("/m/manifest.webmanifest")
def manifest():
    data = {
        "name": current_app.config["APP_NAME"], "short_name": "Checksheet", "lang": "th",
        "start_url": request.script_root + "/m/", "scope": request.script_root + "/m/", "display": "standalone",
        "background_color": "#f4f6f9", "theme_color": "#1d4ed8",
        "icons": [{"src": url_for("static", filename="m/icon.svg"), "sizes": "any", "type": "image/svg+xml"}],
    }
    return Response(json.dumps(data, ensure_ascii=False), mimetype="application/manifest+json")


@bp.route("/media/<path:relpath>")
@require_role(*ALL_ROLES)
def media(relpath):
    resp = send_from_directory(current_app.config["UPLOAD_FOLDER"], relpath)
    resp.headers["Cache-Control"] = "private, max-age=86400"
    return resp


# ───────────────────────── v0.28 คำขอแก้ไขแบบฟอร์มจากหน้างาน ─────────────────────────

@bp.route("/api/m/change-requests", methods=["POST"])
@require_role(*ALL_ROLES)
def api_change_request():
    from .. import change_requests as CR
    db = get_db()
    d = request.get_json(silent=True) or {}
    try:
        cid = CR.create(db, int(d.get("form_id") or 0), current_user_id(), d.get("kind", ""), d.get("detail", ""),
                        d.get("proposed", ""), str(d.get("item_key") or ""))
        db.commit()
    except (CR.ChangeError, ValueError) as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"ok": True, "id": cid})


@bp.route("/m/requests")
@require_role(*ALL_ROLES)
def my_requests():
    from .. import change_requests as CR
    rows = CR.listing(get_db(), "all", requester_id=current_user_id(), limit=100)
    return render_template("mobile/requests.html", rows=rows, KINDS=CR.KINDS, STATUS_TH=CR.STATUS_TH)
