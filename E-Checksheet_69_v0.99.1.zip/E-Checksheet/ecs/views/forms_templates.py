"""ecs/views/forms_templates.py — แยกจาก forms.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

import re
from flask import flash, redirect, request, url_for
from .. import services as S
from ..db import get_db
from ..security import MANAGE_ROLES, current_user_id, require_role

from .forms import bp, _flash_errors, _ids_arg, _load_form  # noqa: E402


# ───────────────────────── แม่แบบ (1 แม่แบบ → หลายเครื่อง) ─────────────────────────

def _tpl_redirect(fid, tab="items"):
    return redirect(url_for("forms.form_detail", form_id=fid) + "#" + tab)


@bp.route("/forms/templates", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_create():
    from .. import formtpl as T
    db = get_db()
    try:
        tid = T.new_template(db, request.form.to_dict(), current_user_id())
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return redirect(url_for("forms.forms"))
    flash("สร้างแม่แบบแล้ว — เพิ่มหัวข้อแล้ว Publish จากนั้นกด 'ใช้กับเครื่องจักร'", "ok")
    return redirect(url_for("forms.builder", form_id=tid))


@bp.route("/forms/<int:form_id>/make-template", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_make(form_id):
    from .. import formtpl as T
    db = get_db()
    _load_form(db, form_id)
    try:
        tid = T.make_template(db, form_id, current_user_id(), request.form.get("name", ""))
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return _tpl_redirect(form_id, "settings")
    flash("สร้างแม่แบบแล้ว แบบฟอร์มนี้เป็นเครื่องแรกของแม่แบบ — กด 'ใช้กับเครื่องจักร' เพื่อเพิ่มเครื่องอื่น", "ok")
    return _tpl_redirect(tid, "children")


@bp.route("/forms/<int:form_id>/apply", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_apply(form_id):
    from .. import formtpl as T
    db = get_db()
    eq_ids = _ids_arg(request.form.getlist("equipment"))
    schedule = None
    if request.form.get("sched_times", "").strip():
        schedule = {"freq_type": request.form.get("sched_freq", "daily"), "times": request.form.get("sched_times"),
                    "window_min": request.form.get("sched_window") or 240}
    try:
        res = T.apply_to_equipment(db, form_id, eq_ids, current_user_id(), schedule)
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return _tpl_redirect(form_id, "children")
    msg = f"สร้างแบบฟอร์มให้ {len(res['created'])} เครื่อง"
    if res["skipped"]:
        msg += f" · ข้าม {len(res['skipped'])} เครื่องที่มีอยู่แล้ว"
    flash(msg, "ok")
    return _tpl_redirect(form_id, "children")


@bp.route("/forms/<int:form_id>/link", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_link(form_id):
    from .. import formtpl as T
    db = get_db()
    try:
        n = T.link_forms(db, form_id, _ids_arg(request.form.getlist("forms")), current_user_id())
        db.commit()
        flash(f"ผูกแบบฟอร์มเดิม {n} ฉบับเข้าแม่แบบแล้ว (หัวข้อชื่อเดียวกันใช้ประวัติเดิมต่อ)", "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return _tpl_redirect(form_id, "children")


@bp.route("/forms/<int:form_id>/detach", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_detach(form_id):
    from .. import formtpl as T
    db = get_db()
    form = _load_form(db, form_id)
    tpl_id = form.get("template_id")
    T.detach(db, form_id, current_user_id())
    db.commit()
    flash("แยกออกจากแม่แบบแล้ว — แบบฟอร์มนี้แก้หัวข้อเองได้ และจะไม่เปลี่ยนตามแม่แบบอีก", "ok")
    return _tpl_redirect(tpl_id if request.form.get("back") == "tpl" and tpl_id else form_id,
                         "children" if request.form.get("back") == "tpl" else "settings")


@bp.route("/forms/<int:form_id>/overrides", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_overrides(form_id):
    from .. import formtpl as T
    db = get_db()
    _load_form(db, form_id)
    data: dict = {}
    for k, v in request.form.items():
        m = re.match(r"^ov\[(.+?)\]\[(\w+)\]$", k)
        if m:
            data.setdefault(m.group(1), {})[m.group(2)] = v
    try:
        n = T.save_overrides(db, form_id, data, current_user_id())
        db.commit()
        flash(f"บันทึกเกณฑ์เฉพาะเครื่องแล้ว ({n} หัวข้อ) — ออกเวอร์ชันใหม่ให้เครื่องนี้แล้ว", "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return _tpl_redirect(form_id, "items")
