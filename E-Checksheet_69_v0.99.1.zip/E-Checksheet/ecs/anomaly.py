"""ecs/anomaly.py — Phase 3: ตรวจจับความผิดปกติ และบันทึกเป็นรายการแจ้งเตือน (cs_alerts)

กฎทั้งหมดตั้งค่าได้จากหน้า Admin (เก็บใน cs_meta key 'anomaly_rules') ไม่ต้องแก้โค้ด
- threshold  : ผลตรวจ NG (ทุกประเภทหัวข้อ) / อยู่ในช่วงเตือน
- roc        : ค่าเปลี่ยนจากครั้งก่อนมากผิดปกติ (Rate of Change)
- spc_sigma  : หลุดขอบควบคุม Mean ± kσ ของ N จุดก่อนหน้า
- spc_run    : n จุดติดกันอยู่ฝั่งเดียวของค่าเฉลี่ย
- spc_trend  : n จุดเพิ่มขึ้น (หรือลดลง) ต่อเนื่อง
- stuck      : ค่าเดิมซ้ำ n ครั้งติดกัน (มิเตอร์ค้าง/จดลอก)
- baseline   : ต่างจากค่าปกติของช่วงเวลาเดียวกันในวันก่อนๆ เกิน kσ
- missed     : ขาดตรวจ (รอบตรวจเลยเวลาปิดโดยไม่มีผล)

รายการซ้ำ (ชนิดเดียวกัน หัวข้อเดียวกัน ที่ยังไม่ปิด) จะนับครั้งเพิ่ม ไม่สร้างใหม่ (deduplication)
"""
from __future__ import annotations

import json
import statistics
from datetime import datetime, timedelta
from typing import Any

from . import services as S
from .services import parse_ts, ts

DEFAULT_RULES: dict[str, dict] = {
    "threshold": {"enabled": True, "warn_band": True},
    "roc": {"enabled": True, "pct": 50},
    "spc_sigma": {"enabled": True, "k": 3.0, "window": 30, "min_points": 10},
    "spc_run": {"enabled": True, "n": 7, "window": 30, "min_points": 10},
    "spc_trend": {"enabled": True, "n": 6},
    "stuck": {"enabled": True, "n": 5},
    "baseline": {"enabled": True, "days": 21, "k": 3.0, "min_points": 10, "hour_window": 2},
    "missed": {"enabled": True},
}
RULE_TH = {
    "threshold": "เกินเกณฑ์ (NG / ช่วงเตือน)",
    "roc": "เปลี่ยนแปลงเร็วผิดปกติ",
    "spc_sigma": "หลุดขอบควบคุม (Mean ± kσ)",
    "spc_run": "อยู่ฝั่งเดียวของค่าเฉลี่ยติดกัน",
    "spc_trend": "เพิ่มขึ้น/ลดลงต่อเนื่อง",
    "stuck": "ค่าค้าง (ซ้ำเดิม)",
    "baseline": "ต่างจากช่วงเวลาเดียวกันวันก่อนๆ",
    "missed": "ขาดตรวจ",
}
TYPE_TH = {"ng": "NG", "warn": "ช่วงเตือน", **{k: v for k, v in RULE_TH.items() if k != "threshold"},
           "approval": "รออนุมัติ"}
NOT_ANOMALY = "approval"          # ประเภทที่เป็นงานรอทำ ไม่ใช่ความผิดปกติ (ไม่นับในสถิติ/รายงานความผิดปกติ)
SEVERITY = {"ng": "warning", "warn": "info", "roc": "warning", "spc_sigma": "warning", "baseline": "info",
            "spc_run": "info", "spc_trend": "info", "stuck": "info", "missed": "warning"}
SEV_RANK = {"info": 0, "warning": 1, "critical": 2}
OPEN_STATUSES = ("open", "acknowledged", "in_progress")


# ───────────────────────── rules config ─────────────────────────

def get_rules(db) -> dict:
    row = db.execute("SELECT value FROM cs_meta WHERE key='anomaly_rules'").fetchone()
    rules = json.loads(json.dumps(DEFAULT_RULES))
    if row and row[0]:
        try:
            saved = json.loads(row[0])
            for k, v in saved.items():
                if k in rules and isinstance(v, dict):
                    rules[k].update({kk: vv for kk, vv in v.items() if kk in rules[k]})
        except ValueError:
            pass
    return rules


def save_rules(db, data: dict, actor_id) -> dict:
    """data: {rule: {param: value}} — ตรวจชนิด/ช่วงค่า แล้วบันทึก"""
    limits = {"pct": (1, 1000), "k": (1.0, 6.0), "window": (5, 500), "min_points": (3, 200), "n": (3, 50),
              "days": (1, 365), "hour_window": (0, 12)}
    current = get_rules(db)
    errors = []
    for rule, params in data.items():
        if rule not in current:
            continue
        for key, raw in params.items():
            if key not in current[rule]:
                continue
            if key in ("enabled", "warn_band"):
                current[rule][key] = raw in (True, 1, "1", "true", "on")
                continue
            lo, hi = limits[key]
            try:
                val = float(raw) if isinstance(lo, float) else int(float(raw))
            except (TypeError, ValueError):
                errors.append(f"{RULE_TH[rule]}: ค่า {key} ต้องเป็นตัวเลข")
                continue
            if not lo <= val <= hi:
                errors.append(f"{RULE_TH[rule]}: ค่า {key} ต้องอยู่ระหว่าง {lo}–{hi}")
                continue
            current[rule][key] = val
    if errors:
        raise S.ValidationError(errors)
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('anomaly_rules', ?)", (json.dumps(current),))
    S.audit(db, actor_id, "update", "anomaly_rules", None, after=current)
    return current


# ───────────────────────── pure rule functions ─────────────────────────

def _g(x: float) -> str:
    return f"{x:.4g}"


def control_limits(values: list[float], k: float) -> dict | None:
    if len(values) < 2:
        return None
    mean = statistics.fmean(values)
    sd = statistics.stdev(values)
    return {"mean": mean, "sd": sd, "ucl": mean + k * sd, "lcl": mean - k * sd, "n": len(values)}


def check_numeric(item: dict, history: list[dict], point: dict, rules: dict) -> list[tuple[str, str]]:
    """ตรวจค่าตัวเลข 1 จุดเทียบกับประวัติก่อนหน้า (เรียงเก่า→ใหม่)
    history/point = {"v": float, "t": datetime}; คืน [(type, message)]"""
    out: list[tuple[str, str]] = []
    x = point["v"]
    vals = [h["v"] for h in history]
    unit = f" {item['unit']}" if item.get("unit") else ""
    is_counter = item["item_type"] == "counter"

    st = rules["stuck"]
    if st["enabled"] and len(vals) >= st["n"] - 1 and all(v == x for v in vals[-(st["n"] - 1):]):
        out.append(("stuck", f"ค่า {_g(x)}{unit} ซ้ำเดิม {st['n']} ครั้งติดกัน — ตรวจสอบว่าอ่านค่าจริง/มิเตอร์ทำงาน"))
    if is_counter:
        return out          # มิเตอร์สะสม: ตรวจเฉพาะค่าค้าง (ค่าลดลง/เพิ่มเกินปกติ ตรวจใน threshold แล้ว)

    roc = rules["roc"]
    if roc["enabled"] and vals:
        prev = vals[-1]
        mn, mx = item.get("min_value"), item.get("max_value")
        base = (mx - mn) if mn is not None and mx is not None and mx > mn else abs(prev)
        if base and abs(x - prev) > base * roc["pct"] / 100.0:
            ref = "ช่วงเกณฑ์" if mn is not None and mx is not None else "ค่าครั้งก่อน"
            out.append(("roc", f"เปลี่ยนจาก {_g(prev)} เป็น {_g(x)}{unit} ({_g(abs(x - prev) / base * 100)}% ของ{ref})"))

    sg = rules["spc_sigma"]
    base_vals = vals[-int(sg["window"]):]
    lim = control_limits(base_vals, float(sg["k"])) if sg["enabled"] and len(base_vals) >= sg["min_points"] else None
    if lim and lim["sd"] > 0 and not (lim["lcl"] <= x <= lim["ucl"]):
        out.append(("spc_sigma", f"{_g(x)}{unit} หลุดขอบควบคุม {_g(lim['lcl'])}–{_g(lim['ucl'])} "
                                 f"(ค่าเฉลี่ย {_g(lim['mean'])} ± {_g(sg['k'])}σ จาก {lim['n']} จุด)"))

    rn = rules["spc_run"]
    run_vals = vals[-int(rn["window"]):]
    if rn["enabled"] and len(run_vals) >= max(rn["min_points"], rn["n"] - 1):
        mean = statistics.fmean(run_vals)
        last = vals[-(rn["n"] - 1):] + [x]
        if all(v > mean for v in last) or all(v < mean for v in last):
            side = "สูงกว่า" if x > mean else "ต่ำกว่า"
            out.append(("spc_run", f"{rn['n']} ครั้งติดกัน{side}ค่าเฉลี่ย {_g(mean)}{unit}"))

    tr = rules["spc_trend"]
    if tr["enabled"] and len(vals) >= tr["n"] - 1:
        seq = vals[-(tr["n"] - 1):] + [x]
        diffs = [b - a for a, b in zip(seq, seq[1:])]
        if all(d > 0 for d in diffs) or all(d < 0 for d in diffs):
            out.append(("spc_trend", f"{'เพิ่มขึ้น' if diffs[0] > 0 else 'ลดลง'}ต่อเนื่อง {tr['n']} ครั้ง "
                                     f"({_g(seq[0])} → {_g(x)}{unit})"))

    bl = rules["baseline"]
    if bl["enabled"] and point.get("t"):
        t = point["t"]
        since = t - timedelta(days=bl["days"])
        same = [h["v"] for h in history if h.get("t") and since <= h["t"] < t - timedelta(hours=12)
                and _hour_dist(h["t"], t) <= bl["hour_window"]]
        if len(same) >= bl["min_points"]:
            lim_b = control_limits(same, float(bl["k"]))
            if lim_b and lim_b["sd"] > 0 and not (lim_b["lcl"] <= x <= lim_b["ucl"]):
                out.append(("baseline", f"{_g(x)}{unit} ต่างจากช่วง {t.strftime('%H:%M')} ของ {bl['days']} วันก่อน "
                                        f"(ปกติ {_g(lim_b['mean'])} ± {_g(bl['k'])}σ)"))
    return out


def _hour_dist(a: datetime, b: datetime) -> float:
    d = abs((a.hour + a.minute / 60) - (b.hour + b.minute / 60))
    return min(d, 24 - d)


# ───────────────────────── data access ─────────────────────────

def item_history(db, form_id: int, item_key: str, until: str | None = None, limit: int = 500,
                 since: str | None = None) -> list[dict]:
    cond, params = "", [form_id, item_key]
    if since:
        cond += " AND s.finished_at >= ?"
        params.append(since)
    if until:
        cond += " AND s.finished_at <= ?"
        params.append(until)
    rows = db.execute(f"""
        SELECT a.value_num, a.value_text, a.judgement, a.remark, s.id AS sub_id, s.finished_at, u.name AS inspector
        FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id LEFT JOIN users u ON u.id=s.inspector_id
        WHERE s.form_id=? AND a.item_key=? AND s.status='submitted' AND a.value_num IS NOT NULL {cond}
        ORDER BY s.finished_at DESC, s.id DESC LIMIT ?""", params + [limit]).fetchall()
    return [{"v": r["value_num"], "t": parse_ts(r["finished_at"]), "sub_id": r["sub_id"], "judgement": r["judgement"],
             "remark": r["remark"], "inspector": r["inspector"], "text": r["value_text"]} for r in reversed(rows)]


def raise_alert(db, *, alert_type: str, form: dict, title: str, detail: str, severity: str,
                item_key: str | None = None, submission_id: int | None = None, round_id: int | None = None,
                now: datetime | None = None) -> tuple[int, bool]:
    """สร้างรายการแจ้งเตือน หรือเพิ่มจำนวนครั้งของรายการเดิมที่ยังเปิดอยู่ → (alert_id, is_new)"""
    now_s = ts(now or S.now_dt())
    key = f"{alert_type}:{form['id']}:{item_key or ''}"
    row = db.execute(f"""SELECT id, severity, occurrences FROM cs_alerts WHERE dedup_key=?
                         AND status IN ({','.join('?' * len(OPEN_STATUSES))}) ORDER BY id DESC LIMIT 1""",
                     (key, *OPEN_STATUSES)).fetchone()
    if row:
        sev = severity if SEV_RANK[severity] > SEV_RANK[row["severity"]] else row["severity"]
        # ระดับรุนแรงขึ้น → ให้ระบบแจ้งเตือนส่งใหม่ตามระดับ (notified_level=0)
        db.execute("""UPDATE cs_alerts SET occurrences=occurrences+1, severity=?, title=?, detail=?, submission_id=COALESCE(?, submission_id),
                      round_id=COALESCE(?, round_id), updated_at=?,
                      notified_level=CASE WHEN ?<>severity THEN 0 ELSE notified_level END WHERE id=?""",
                   (sev, title[:200], detail[:1000], submission_id, round_id, now_s, sev, row["id"]))
        db.execute("INSERT INTO cs_alert_events(alert_id, event, detail, created_at) VALUES (?,?,?,?)",
                   (row["id"], "repeat", detail[:500], now_s))
        return row["id"], False
    aid = db.execute("""INSERT INTO cs_alerts(alert_type, severity, dedup_key, form_id, equipment_id, item_key, submission_id,
                        round_id, title, detail, level, status, occurrences, created_at, updated_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,1,'open',1,?,?)""",
                     (alert_type, severity, key, form["id"], form.get("equipment_id"), item_key, submission_id, round_id,
                      title[:200], detail[:1000], now_s, now_s)).lastrowid
    db.execute("INSERT INTO cs_alert_events(alert_id, event, detail, created_at) VALUES (?,?,?,?)",
               (aid, "created", detail[:500], now_s))
    return aid, True


def check_submission(db, sub_id: int, rules: dict | None = None) -> list[dict]:
    """ตรวจผลตรวจที่เพิ่งบันทึก — เรียกทันทีหลังรับผลตรวจ (อยู่ใน transaction เดียวกัน)"""
    rules = rules or get_rules(db)
    sub = db.execute("SELECT * FROM cs_submissions WHERE id=?", (sub_id,)).fetchone()
    if not sub:
        return []
    form = S.get_form(db, sub["form_id"])
    who = form["eq_code"] or form["name"]
    found: list[dict] = []
    answers = db.execute("""SELECT a.*, i.name, i.item_type, i.unit, i.min_value, i.max_value, i.critical
                            FROM cs_answers a JOIN cs_form_items i ON i.id=a.item_id WHERE a.submission_id=?""",
                         (sub_id,)).fetchall()
    for a in answers:
        item = dict(a)
        hits: list[tuple[str, str]] = []
        if rules["threshold"]["enabled"]:
            if a["judgement"] == "ng":
                hits.append(("ng", f"{a['name']} = {a['value_text']}{(' ' + a['unit']) if a['unit'] else ''} (NG)"
                                   + (f" — {a['remark']}" if a["remark"] else "")))
            elif a["judgement"] == "warn" and rules["threshold"]["warn_band"]:
                hits.append(("warn", f"{a['name']} = {a['value_text']}{(' ' + a['unit']) if a['unit'] else ''} อยู่ในช่วงเตือน"))
        if a["value_num"] is not None and a["item_type"] in ("number", "counter", "calc"):
            history = item_history(db, sub["form_id"], a["item_key"], until=sub["finished_at"], limit=400)
            history = [h for h in history if h["sub_id"] != sub_id]
            stat_hits = check_numeric(item, history, {"v": a["value_num"], "t": parse_ts(sub["finished_at"])}, rules)
            if a["judgement"] == "ng":
                # ค่าที่ NG แล้วมีแจ้งเตือน NG อยู่แล้ว ไม่ต้องแจ้งซ้ำด้วยกฎสถิติ (ลดแจ้งเตือนท่วม) ยกเว้นค่าค้าง
                stat_hits = [h for h in stat_hits if h[0] == "stuck"]
            hits += stat_hits
        for typ, msg in hits:
            sev = SEVERITY[typ]
            if typ == "ng" and a["critical"]:
                sev = "critical"
            title = f"{TYPE_TH[typ]}: {a['name']} — {who}"
            aid, is_new = raise_alert(db, alert_type=typ, form=form, title=title, detail=msg, severity=sev,
                                      item_key=a["item_key"], submission_id=sub_id, round_id=sub["round_id"],
                                      now=parse_ts(sub["received_at"]))
            found.append({"alert_id": aid, "type": typ, "severity": sev, "item_key": a["item_key"],
                          "message": msg, "new": is_new})
    return found


def raise_approval(db, sub_id: int, now: datetime | None = None) -> int | None:
    """ผลตรวจรออนุมัติ → รายการแจ้งเตือน "รออนุมัติ" (ข้อมูล) ให้หัวหน้าเห็นว่ามีการตรวจเสร็จ — ปิดเองเมื่ออนุมัติ/ตีกลับ/ลบ"""
    s = db.execute("""SELECT s.*, u.name AS inspector_name FROM cs_submissions s LEFT JOIN users u ON u.id=s.inspector_id
                      WHERE s.id=?""", (sub_id,)).fetchone()
    if not s or s["status"] != "submitted" or s["approval_status"] != "pending":
        return None
    key = f"approval:sub:{sub_id}"
    if db.execute("SELECT 1 FROM cs_alerts WHERE dedup_key=?", (key,)).fetchone():
        return None
    form = S.get_form(db, s["form_id"])
    if not form:
        return None
    fin = parse_ts(s["finished_at"])
    res = f"พบ NG {s['ng_count']} หัวข้อ" if s["ng_count"] else "ผลปกติ" + (f" (ช่วงเตือน {s['warn_count']})" if s["warn_count"] else "")
    mins = round((s["duration_sec"] or 0) / 60)
    detail = (f"{s['inspector_name'] or 'ผู้ตรวจ'} ส่งผลตรวจ {fin.strftime('%d/%m %H:%M') if fin else ''} · {res}"
              + (f" · ใช้เวลา {mins} นาที" if mins else "") + " — เปิดผลตรวจเพื่ออนุมัติ/ตีกลับ")
    now_s = ts(fin or now or S.now_dt())          # เวลาที่ส่งผลตรวจจริง (รวมที่ส่งจากคิวออฟไลน์ / ข้อมูลเดิม)
    aid = db.execute("""INSERT INTO cs_alerts(alert_type, severity, dedup_key, form_id, equipment_id, submission_id, round_id,
                        title, detail, level, status, occurrences, created_at, updated_at)
                        VALUES ('approval','info',?,?,?,?,?,?,?,1,'open',1,?,?)""",
                     (key, form["id"], form.get("equipment_id"), sub_id, s["round_id"],
                      f"รออนุมัติ: {form['name']}"[:200], detail[:1000], now_s, now_s)).lastrowid
    db.execute("INSERT INTO cs_alert_events(alert_id, event, detail, created_at) VALUES (?,?,?,?)",
               (aid, "created", detail[:500], now_s))
    return aid


def close_approval(db, sub_id: int, actor_id, note: str, now: datetime | None = None) -> int:
    """อนุมัติ/ตีกลับ/ลบผลตรวจ → ปิดรายการ "รออนุมัติ" ของผลตรวจนั้น"""
    now_s = ts(now or S.now_dt())
    n = 0
    for a in db.execute(f"""SELECT id FROM cs_alerts WHERE alert_type='approval' AND submission_id=?
                            AND status IN ({','.join('?' * len(OPEN_STATUSES))})""", (sub_id, *OPEN_STATUSES)).fetchall():
        db.execute("""UPDATE cs_alerts SET status='closed', closed_by=?, closed_at=?, close_note=?, updated_at=? WHERE id=?""",
                   (actor_id, now_s, note[:500], now_s, a["id"]))
        db.execute("INSERT INTO cs_alert_events(alert_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
                   (a["id"], "close", actor_id, note[:500], now_s))
        n += 1
    return n


DELETABLE_TYPES = ("missed",)          # ลบได้โดยไม่ต้องระบุเหตุผล


def delete_alerts(db, ids: list[int], actor_id, reason: str = "", *, any_type: bool = False) -> int:
    """ลบรายการแจ้งเตือน — เก็บข้อมูลเดิมไว้ใน Audit Trail
    · ค่าเริ่มต้น: เฉพาะประเภทขาดตรวจ
    · any_type=True (v0.36): ทุกประเภท แต่ประเภทอื่นต้องระบุเหตุผล และไม่ลบ "รออนุมัติ" ที่ยังค้าง (ต้องอนุมัติ/ตีกลับที่ผลตรวจ)"""
    reason = (reason or "").strip()
    n = 0
    for aid in ids:
        a = db.execute("SELECT * FROM cs_alerts WHERE id=?", (aid,)).fetchone()
        if not a:
            continue
        if a["alert_type"] not in DELETABLE_TYPES:
            if not any_type or not reason:
                continue
            if a["alert_type"] == "approval" and a["status"] in OPEN_STATUSES:
                continue
        S.audit(db, actor_id, "delete", "cs_alerts", aid, before=dict(a), after={"reason": reason[:300]})
        db.execute("UPDATE cs_actions SET alert_id=NULL WHERE alert_id=?", (aid,))
        db.execute("UPDATE cs_msg_outbox SET alert_id=NULL WHERE alert_id=?", (aid,))
        db.execute("DELETE FROM cs_alert_events WHERE alert_id=?", (aid,))
        db.execute("DELETE FROM cs_alerts WHERE id=?", (aid,))
        n += 1
    return n


def check_missed(db, now: datetime | None = None) -> int:
    """รอบที่เพิ่งกลายเป็น 'ขาดตรวจ' → แจ้งเตือน (เรียกจากงานเบื้องหลัง)"""
    rules = get_rules(db)
    if not rules["missed"]["enabled"]:
        return 0
    row = db.execute("SELECT value FROM cs_meta WHERE key='missed_checked_at'").fetchone()
    since = row[0] if row else "1970-01-01 00:00:00"
    now_s = ts(now or S.now_dt())
    rounds = db.execute("""SELECT r.* FROM cs_rounds r JOIN cs_schedules s ON s.id=r.schedule_id
                           WHERE r.status='missed' AND r.updated_at > ? AND r.updated_at <= ? AND s.active=1
                           ORDER BY r.due_at""", (since, now_s)).fetchall()
    n = 0
    for r in rounds:
        form = S.get_form(db, r["form_id"])
        if not form:
            continue
        who = form["eq_code"] or form["name"]
        raise_alert(db, alert_type="missed", form=form, severity="warning", round_id=r["id"],
                    title=f"ขาดตรวจ: {form['name']}",
                    detail=f"รอบ {parse_ts(r['due_at']).strftime('%d/%m %H:%M')} ของ {who} ไม่มีผลตรวจจนเลยเวลาปิดรอบ",
                    now=now)
        n += 1
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('missed_checked_at', ?)", (now_s,))
    return n


# ───────────────────────── list ─────────────────────────

def list_alerts(db, *, status: str = "open", severity: str = "", alert_type: str = "", factory_id=None,
                form_id=None, limit: int = 200) -> list[dict]:
    where, params = ["1=1"], []
    if status == "open":
        where.append(f"a.status IN ({','.join('?' * len(OPEN_STATUSES))})")
        params += list(OPEN_STATUSES)
    elif status == "new":
        where.append("a.status='open'")
    elif status:
        where.append("a.status=?")
        params.append(status)
    if severity:
        where.append("a.severity=?"); params.append(severity)
    if alert_type:
        where.append("a.alert_type=?"); params.append(alert_type)
    if factory_id:
        where.append("f.factory_id=?"); params.append(factory_id)
    if form_id:
        where.append("a.form_id=?"); params.append(form_id)
    rows = db.execute(f"""
        SELECT a.*, f.name AS form_name, fa.name AS factory_name, e.code AS eq_code, ua.name AS assigned_name
        FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN equipment e ON e.id=a.equipment_id LEFT JOIN users ua ON ua.id=a.assigned_to
        WHERE {' AND '.join(where)}
        ORDER BY CASE a.severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END, a.updated_at DESC
        LIMIT ?""", params + [limit]).fetchall()
    return [dict(r) for r in rows]


def recent_alerts(db, factory_id=None, limit: int = 6, days: int = 7) -> list[dict]:
    """แจ้งเตือนล่าสุด: รายการที่ยังค้างก่อน แล้วตามด้วยรายการที่เพิ่งแก้ไข (ภายใน N วัน)"""
    since = ts(S.now_dt() - timedelta(days=days))
    params: list[Any] = [since]
    cond = ""
    if factory_id:
        cond = " AND f.factory_id=?"
        params.append(factory_id)
    rows = db.execute(f"""
        SELECT * FROM (
          SELECT a.*, f.name AS form_name, fa.name AS factory_name, e.code AS eq_code,
                 COALESCE((SELECT MAX(ev.created_at) FROM cs_alert_events ev WHERE ev.alert_id=a.id
                           AND ev.event IN ('created','repeat')), a.created_at) AS last_seen
          FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id LEFT JOIN factories fa ON fa.id=f.factory_id
          LEFT JOIN equipment e ON e.id=a.equipment_id
          WHERE a.updated_at >= ? AND a.alert_type<>'approval' {cond})
        ORDER BY CASE WHEN status IN ('open','acknowledged','in_progress') THEN 0 ELSE 1 END,
                 CASE severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END, last_seen DESC
        LIMIT ?""", params + [limit]).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        if d["status"] in ("resolved", "closed"):
            d["pill"], d["pill_th"] = "good", "แก้ไขแล้ว"
        elif d["status"] == "open" and d["severity"] in ("critical", "warning"):
            d["pill"], d["pill_th"] = "critical", "เร่งแก้ไข"
        else:
            d["pill"], d["pill_th"] = "warning", "ติดตาม" if d["status"] != "open" else "ตรวจสอบ"
        out.append(d)
    return out


def open_alert_counts(db, factory_id=None) -> dict:
    params: list[Any] = list(OPEN_STATUSES)
    cond = ""
    if factory_id:
        cond = " AND f.factory_id=?"
        params.append(factory_id)
    rows = db.execute(f"""SELECT a.severity, COUNT(*) FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id
                          WHERE a.status IN ({','.join('?' * len(OPEN_STATUSES))}) {cond} GROUP BY a.severity""",
                      params).fetchall()
    out = {"critical": 0, "warning": 0, "info": 0}
    out.update({r[0]: r[1] for r in rows})
    out["total"] = sum(out[k] for k in ("critical", "warning", "info"))
    return out


def get_alert(db, alert_id: int) -> dict | None:
    row = db.execute("""SELECT a.*, f.name AS form_name, f.factory_id, fa.name AS factory_name, e.code AS eq_code,
                               u.name AS ack_name, ua.name AS assigned_name, ur.name AS resolved_name, uc.name AS closed_name
                        FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id LEFT JOIN factories fa ON fa.id=f.factory_id
                        LEFT JOIN equipment e ON e.id=a.equipment_id LEFT JOIN users u ON u.id=a.ack_by
                        LEFT JOIN users ua ON ua.id=a.assigned_to LEFT JOIN users ur ON ur.id=a.resolved_by
                        LEFT JOIN users uc ON uc.id=a.closed_by
                        WHERE a.id=?""", (alert_id,)).fetchone()
    if not row:
        return None
    out = dict(row)
    out["events"] = [dict(r) for r in db.execute(
        """SELECT ev.*, u.name AS actor_name FROM cs_alert_events ev LEFT JOIN users u ON u.id=ev.actor_id
           WHERE ev.alert_id=? ORDER BY ev.created_at DESC, ev.id DESC LIMIT 100""", (alert_id,))]
    out["actions"] = [dict(r) for r in db.execute(
        """SELECT c.id, c.code, c.title, c.status, c.due_date, u.name AS owner_name FROM cs_actions c
           LEFT JOIN users u ON u.id=c.owner_id WHERE c.alert_id=? ORDER BY c.id""", (alert_id,))]
    return out


ALERT_FLOW = {
    # action: (สถานะที่ทำได้, สถานะใหม่)
    "ack": (("open",), "acknowledged"),
    "start": (("open", "acknowledged"), "in_progress"),
    "resolve": (("open", "acknowledged", "in_progress"), "resolved"),
    "close": (("resolved",), "closed"),
    "reopen": (("resolved", "closed"), "in_progress"),
    "assign": (("open", "acknowledged", "in_progress"), None),
}
ACTION_TH = {"ack": "รับทราบ", "start": "เริ่มแก้ไข", "resolve": "แก้ไขแล้ว", "close": "ปิดงาน", "reopen": "เปิดใหม่",
             "assign": "มอบหมาย", "created": "เกิดขึ้น", "repeat": "เกิดซ้ำ", "notify": "ส่งแจ้งเตือน",
             "escalate": "ส่งต่อระดับถัดไป", "sla": "เตือนยังไม่แก้ไข", "capa": "สร้างงานแก้ไข (CAPA)",
             "silenced": "อยู่ในช่วงเงียบ"}


def set_alert_status(db, alert_id: int, action: str, actor_id, note: str = "", now: datetime | None = None, *,
                     root_cause: str = "", action_taken: str = "", assign_to: int | None = None) -> dict:
    """ขั้นตอน: ใหม่ → รับทราบ → กำลังแก้ไข → แก้ไขแล้ว (ต้องมีสาเหตุ + การแก้ไข) → ปิดงาน (ตรวจรับ) / เปิดใหม่"""
    a = db.execute("SELECT * FROM cs_alerts WHERE id=?", (alert_id,)).fetchone()
    if not a:
        raise S.ValidationError("ไม่พบรายการแจ้งเตือน")
    if action not in ALERT_FLOW:
        raise S.ValidationError("คำสั่งไม่ถูกต้อง")
    allowed, new_status = ALERT_FLOW[action]
    if a["status"] not in allowed:
        msg = {"ack": "รายการนี้รับทราบแล้ว", "close": "ต้องบันทึกการแก้ไขก่อนปิดงาน",
               "reopen": "รายการนี้ยังไม่ได้แก้ไข"}.get(action, "รายการนี้ปิดแล้ว")
        raise S.ValidationError(msg)
    note = (note or "").strip()[:1000]
    root_cause = (root_cause or "").strip()[:1000]
    action_taken = (action_taken or "").strip()[:1000]
    now_s = ts(now or S.now_dt())
    sets: dict[str, Any] = {"updated_at": now_s}
    if new_status:
        sets["status"] = new_status
    if action in ("ack", "start", "resolve") and not a["ack_at"]:
        sets.update(ack_by=actor_id, ack_at=now_s)
    if action in ("start", "assign") and assign_to:
        sets["assigned_to"] = int(assign_to)
    if action == "assign" and not assign_to:
        raise S.ValidationError("กรุณาเลือกผู้รับผิดชอบ")
    if action == "resolve":
        if not root_cause or not action_taken:
            raise S.ValidationError("กรุณาระบุทั้งสาเหตุและการแก้ไข")
        sets.update(root_cause=root_cause, action_taken=action_taken, resolved_by=actor_id, resolved_at=now_s)
        note = note or f"สาเหตุ: {root_cause} · แก้ไข: {action_taken}"
    if action == "close":
        sets.update(closed_by=actor_id, closed_at=now_s, close_note=note)
    if action == "reopen":
        if not note:
            raise S.ValidationError("กรุณาระบุเหตุผลที่เปิดใหม่")
        sets.update(closed_at=None, closed_by=None, resolved_at=None, resolved_by=None, sla_notified_at=None)
    cols = ", ".join(f"{k}=?" for k in sets)
    db.execute(f"UPDATE cs_alerts SET {cols} WHERE id=?", (*sets.values(), alert_id))
    detail = note
    if action in ("assign", "start") and assign_to:
        u = db.execute("SELECT name FROM users WHERE id=?", (assign_to,)).fetchone()
        detail = (f"ผู้รับผิดชอบ: {u['name']}" if u else "") + (f" · {note}" if note else "")
    db.execute("INSERT INTO cs_alert_events(alert_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
               (alert_id, action, actor_id, detail[:500], now_s))
    S.audit(db, actor_id, action, "cs_alerts", alert_id, before={"status": a["status"]},
            after={k: v for k, v in sets.items() if k != "updated_at"})
    _tell_reporter(db, a, action, sets.get("status") or a["status"], actor_id, detail, now_s)
    return get_alert(db, alert_id)


def _tell_reporter(db, a, action: str, status: str, actor_id, detail: str, now_s: str) -> None:
    """v0.50 ปิดวงจร NG: แจ้งช่างผู้ตรวจที่พบ NG ทุกครั้งที่สถานะเปลี่ยน (กระดิ่ง + รายการ "NG ที่ฉันแจ้ง" บนมือถือ)"""
    if not a["submission_id"] or action == "comment":
        return
    row = db.execute("SELECT inspector_id FROM cs_submissions WHERE id=?", (a["submission_id"],)).fetchone()
    if not row or not row[0] or row[0] == actor_id:
        return
    from . import terms as TR
    from .notify import notify_user_app
    who = db.execute("SELECT name FROM users WHERE id=?", (actor_id,)).fetchone()
    body = f"{a['title']}" + (f"\n{detail}" if detail else "") + (f"\nโดย {who[0]}" if who else "")
    notify_user_app(db, row[0], "ng_update", f"NG ที่คุณแจ้ง → {TR.label('ALERT', status)}", body,
                    url=f"/alerts/{a['id']}", severity="info", ref_key=f"ngu:{a['id']}:{action}:{now_s}")
