/* v0.41 อัปเดตหน้าจอแบบ Real-time: ถามเซิร์ฟเวอร์ทุก N วินาทีว่าข้อมูลเปลี่ยนไหม (รอบตรวจ / ตารางรอบตรวจ / แจ้งเตือน / ผลตรวจ)
   เปลี่ยน → โหลดหน้าใหม่ทันที (คงตำแหน่งเลื่อนเดิม) · ถ้ากำลังพิมพ์/เลือก/เปิดตาราง → แสดงปุ่ม "มีข้อมูลใหม่" ให้กดเอง */
(function () {
  const el = document.querySelector('[data-live]');
  if (!el || !window.fetch) return;
  const url = el.dataset.live, sec = Math.max(5, +el.dataset.liveSec || 15);
  const KEY = 'live_scroll:' + location.pathname + location.search;
  try { const y = sessionStorage.getItem(KEY); if (y) { sessionStorage.removeItem(KEY); window.scrollTo(0, +y); } } catch (e) { /* */ }
  el.classList.add('live');
  el.innerHTML = '<span class="live-dot" aria-hidden="true"></span><span class="live-t">สด</span>' +
    '<button type="button" class="live-new" hidden>มีข้อมูลใหม่ · อัปเดต</button>';
  el.setAttribute('role', 'status');
  const t = el.querySelector('.live-t'), btn = el.querySelector('.live-new');
  let stamp = null, pending = false, busyNow = false;
  function busy() {
    const a = document.activeElement;
    if (a && /^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName) && a.type !== 'checkbox') return true;
    if (document.querySelector('.data-table:not([hidden]), dialog[open], .modal.open')) return true;
    if (document.querySelector('input[type=checkbox]:checked[name="ids"]')) return true;   // กำลังเลือกหลายรายการ
    const s = window.getSelection && window.getSelection();
    return !!(s && String(s).length);
  }
  function reload() {
    try { sessionStorage.setItem(KEY, String(window.scrollY)); } catch (e) { /* */ }
    location.reload();
  }
  btn.addEventListener('click', reload);
  async function tick() {
    if (document.visibilityState !== 'visible' || busyNow) return;
    busyNow = true;
    try {
      const r = await fetch(url, {credentials: 'same-origin', cache: 'no-store', headers: {'Accept': 'application/json'}});
      if (!r.ok) throw new Error(r.status);
      const j = await r.json();
      el.classList.remove('off');
      t.textContent = 'สด · ' + j.at;
      if (stamp && j.stamp !== stamp) pending = true;
      stamp = j.stamp;
    } catch (e) {
      el.classList.add('off');
      t.textContent = 'ขาดการเชื่อมต่อ';
    } finally { busyNow = false; }
    if (pending) { if (busy()) btn.hidden = false; else reload(); }
  }
  tick();
  setInterval(tick, sec * 1000);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') tick(); });
})();
