"""ecs/sheet_report.py — รายงานทางการรายแบบฟอร์ม (Check Sheet) สำหรับใช้เป็นหลักฐานการตรวจ/ตรวจรับรอง

1) ใบบันทึกผลการตรวจรายเดือน (1 แบบฟอร์ม = 1 ชีท) — หัวข้อ × วันที่ เหมือนเช็คชีตกระดาษ
   + สรุปรอบตรวจ ตรงเวลา/ขาดตรวจ, รายการ NG พร้อมงานแก้ไข, ผู้ตรวจ/ผู้อนุมัติรายวัน, ช่องลงนาม
2) ใบบันทึกผลการตรวจรายครั้ง (1 ผลตรวจ) — ทุกหัวข้อ เกณฑ์ ค่าที่วัด ผล หมายเหตุ รูป และประวัติการอนุมัติ

ทุกฉบับมีเลขที่เอกสาร และ "รหัสตรวจสอบ" ที่คำนวณจากข้อมูลจริงในระบบ — ถ้าข้อมูลถูกแก้ภายหลัง รหัสจะเปลี่ยน
(เปิดฉบับออนไลน์ด้วย QR บนเอกสารแล้วเทียบรหัส = ยืนยันว่าเอกสารกระดาษตรงกับระบบ)
"""
from __future__ import annotations

import calendar
import hashlib
import hmac
import json
from datetime import date, datetime, timedelta

from . import services as S

TH_MONTHS = ("มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม",
             "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม")
TYPE_TH = {"ok_ng": "OK/NG", "number": "ค่าวัด", "counter": "มิเตอร์", "choice": "ตัวเลือก", "text": "ข้อความ"}
MAX_COLS_PER_PAGE = 31


def th_month(d: date) -> str:
    return f"{TH_MONTHS[d.month - 1]} {d.year + 543}"


def th_dt(v, with_time: bool = True) -> str:
    dt = S.parse_ts(v) if isinstance(v, str) else v
    if not isinstance(dt, datetime):
        return "–"
    return dt.strftime("%d/%m/") + str(dt.year + 543) + (dt.strftime(" %H:%M") if with_time else "")


def spec_text(it: dict) -> str:
    mn, mx = it.get("min_value"), it.get("max_value")
    unit = it.get("unit") or ""
    if it.get("item_type") in ("number", "counter", "calc"):
        if mn is None and mx is None:
            return unit or "บันทึกค่า"
        if mn is None:
            s = f"≤ {mx:g}"
        elif mx is None:
            s = f"≥ {mn:g}"
        else:
            s = f"{mn:g} – {mx:g}"
        return f"{s} {unit}".strip()
    if it.get("item_type") == "choice":
        try:
            opts = json.loads(it.get("options_json") or "[]")
            return " / ".join(o.get("label", "") for o in opts)[:60]
        except ValueError:
            return ""
    if it.get("item_type") == "text":
        return "บันทึก"
    return "OK / NG"


def cell_text(ans: dict | None, it: dict) -> str:
    if not ans:
        return ""
    j = ans.get("judgement")
    if it.get("item_type") == "ok_ng":
        return "✗" if j == "ng" else "✓"
    if ans.get("value_num") is not None and it.get("item_type") in ("number", "counter", "calc"):
        v = ans["value_num"]
        return f"{v:g}" if abs(v) < 1e7 else f"{v:.3g}"
    return (ans.get("value_text") or "")[:14]


def _short(name: str | None) -> str:
    """ชื่อย่อในช่องลงชื่อรายวัน (ชื่อแรก)"""
    return (name or "").split(" ")[0][:10]


def _sign(secret: str, payload: str) -> str:
    h = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest().upper()
    return f"{h[:4]}-{h[4:8]}-{h[8:12]}"


def _items_for(db, version_ids: list[int], current_version_id) -> list[dict]:
    """หัวข้อของเวอร์ชันปัจจุบันก่อน แล้วต่อด้วยหัวข้อที่มีเฉพาะในเวอร์ชันเก่าที่ใช้ในเดือนนั้น"""
    order = ([current_version_id] if current_version_id else []) + sorted(set(version_ids) - {current_version_id}, reverse=True)
    out, seen = [], set()
    for vid in order:
        for r in db.execute("SELECT * FROM cs_form_items WHERE version_id=? ORDER BY order_no, id", (vid,)):
            if r["item_key"] not in seen:
                seen.add(r["item_key"])
                out.append(dict(r))
    return out


def iso_info(db, form_id: int, version_id: int | None) -> dict:
    """ข้อมูลควบคุมเอกสาร: เลขที่เอกสาร (ของแบบฟอร์ม หรือของแม่แบบ) · Rev. · วันที่มีผล · ผู้อนุมัติ"""
    f = db.execute("SELECT doc_no, template_id FROM cs_forms WHERE id=?", (form_id,)).fetchone()
    doc = (f["doc_no"] or "") if f else ""
    if f and not doc and f["template_id"]:
        t = db.execute("SELECT doc_no FROM cs_forms WHERE id=?", (f["template_id"],)).fetchone()
        doc = (t["doc_no"] or "") if t else ""
    v = db.execute("SELECT version_no, effective_date, published_at, approved_by_name FROM cs_form_versions WHERE id=?",
                   (version_id,)).fetchone() if version_id else None
    return {"doc_no": doc, "rev": S.rev_label(v["version_no"]) if v else "",
            "effective": (v["effective_date"] or (v["published_at"] or "")[:10]) if v else "",
            "approved_by": (v["approved_by_name"] or "") if v else ""}


# ───────────────────────── ตารางรายเดือนตามความถี่ของแต่ละหัวข้อ ─────────────────────────
TH_WD = ("จ", "อ", "พ", "พฤ", "ศ", "ส", "อา")
MAX_SLOTS = 6            # หัวข้อที่ตรวจเกินวันละ 6 ครั้ง → รวมเป็นบรรทัดเดียว (แสดงค่าล่าสุด + จำนวนครั้ง)


def _form_period(db, form_id: int) -> tuple[str, list[int]]:
    """รอบตรวจของแบบฟอร์ม → ('slots', [นาทีของวัน]) / ('week', []) / ('month', []) / ('free', [])"""
    from .itemfreq import parse_times
    sch = [dict(r) for r in db.execute("SELECT * FROM cs_schedules WHERE form_id=? AND active=1", (form_id,))]
    daily = [x for x in sch if x["freq_type"] in ("daily", "shift") or (x["freq_type"] or "").startswith("d:")]
    if daily:
        mins = sorted({m for x in daily for m in parse_times(x["times"])})
        return "slots", mins
    if any(x["freq_type"] == "weekly" or (x["freq_type"] or "").startswith("w:") for x in sch):
        return "week", []
    if any(x["freq_type"] == "semimonthly" for x in sch):
        return "half", []
    if any(x["freq_type"] == "monthly" or (x["freq_type"] or "").startswith("m:") for x in sch):
        return "month", []
    return "free", []


def _item_period(it: dict, form_kind: str, form_mins: list[int], cal: dict) -> tuple[str, list[int]]:
    from .itemfreq import parse_times
    f = it.get("check_freq") or ""
    if f == "times":
        return "slots", parse_times(it.get("check_times")) or [480]
    if f == "shift":
        return "slots", parse_times(cal.get("shift_times")) or [480]
    if f == "day":
        return "slots", parse_times(cal.get("day_start"))[:1] or [480]
    if f in ("week", "month"):
        return f, []
    from .itemfreq import interval
    iv = interval(f)
    if iv:                                            # v0.32 ทุก N วัน/สัปดาห์/เดือน → ช่องรวมตามช่วง
        return ("month" if iv[0] == "m" else "period"), []
    if form_kind == "slots":
        return "slots", form_mins
    if form_kind in ("week", "month", "half"):
        return form_kind, []
    return "free", []


def _hm(m: int) -> str:
    return f"{m // 60:02d}:{m % 60:02d}"


def build_grid(db, form: dict, month: date, items: list[dict], subs: list[dict], answers: dict) -> dict:
    """หัวข้อ × วันที่ ตามความถี่จริงของแต่ละหัวข้อ
      - ตรวจหลายครั้ง/วัน (ตามรอบ/ตามเวลา/กะ) → 1 บรรทัดต่อเวลา (แบ่งแถว) ค่าอยู่ในช่องของรอบที่ตรวจ
      - สัปดาห์ละครั้ง → ช่องรวมเป็นช่วงสัปดาห์ (จ–อา) · เดือนละครั้ง → ช่องเดียวทั้งเดือน
      - วันที่ไม่มีรอบตรวจ = แรเงา · เครื่องหยุด/ซ่อม = แรเงาเทา "หยุด" · วันที่ยังไม่ถึง = ว่าง
    ค่าที่ตรวจก่อนเวลาเล็กน้อย (ผ่อนผัน) นับให้รอบนั้น · ตรวจข้ามเที่ยงคืนของรอบดึก นับเป็นวันของรอบ"""
    from .itemfreq import fmt_times, get_calendar, grace, slot_start
    cal = get_calendar(db)
    last = calendar.monthrange(month.year, month.month)[1]
    today = S.now_dt().date()
    form_kind, form_mins = _form_period(db, form["id"])
    # วันทำงาน/วันหยุดตามรอบตรวจของแบบฟอร์ม
    holidays = S._holidays(db) if hasattr(S, "_holidays") else set()
    sch = [dict(r) for r in db.execute("SELECT * FROM cs_schedules WHERE form_id=? AND active=1 AND (freq_type IN ('daily','shift') OR freq_type LIKE 'd:%')",
                                       (form["id"],))]
    first, end = date(month.year, month.month, 1), date(month.year, month.month, last)
    on_days = {dt.day for x in sch for dt in S.occurrences(x, first, end, holidays)} if sch else set(range(1, last + 1))
    down_days = set()
    for r in db.execute("""SELECT substr(due_at, 9, 2) AS d, SUM(status='skipped') sk, COUNT(*) n FROM cs_rounds
                           WHERE form_id=? AND due_at BETWEEN ? AND ? GROUP BY d""",
                        (form["id"], S.ts(datetime.combine(first, datetime.min.time())), S.ts(datetime.combine(end, datetime.max.time())))):
        if r["n"] and r["sk"] == r["n"]:
            down_days.add(int(r["d"]))
    # v0.54 ช่วงเครื่องหยุด / PM ของเดือนนี้ (ประวัติแจ้งหยุด-เดินเครื่อง) → แรเงารายรอบ (กะเช้า / กะดึก)
    dts = downtime_periods(db, form.get("equipment_id"), first, end)
    now = S.now_dt()
    win = timedelta(minutes=int(sch[0]["window_min"]) if sch and sch[0].get("window_min") else 240)
    skipped_at = {r[0] for r in db.execute("""SELECT due_at FROM cs_rounds WHERE form_id=? AND status='skipped'
                                               AND due_at BETWEEN ? AND ?""", (form["id"], S.ts(datetime.combine(first, datetime.min.time())),
                                                                               S.ts(datetime.combine(end, datetime.max.time()))))}

    # รอบที่มีผลตรวจแล้ว = ไม่แรเงา (v0.55)
    from .itemfreq import fmt_times as _ft, grace as _gr, slot_start as _ss
    done_slots: set = set()
    if form_mins:
        _ts = _ft(form_mins)
        _g = _gr("times", _ts, cal)
        for s_ in subs:
            dt = S.parse_ts(s_.get("place_at") or s_["finished_at"])
            st = _ss("times", _ts, dt + _g, cal) if dt else None
            if st:
                done_slots.add((st.date(), st.hour * 60 + st.minute))

    def slot_down(t: datetime):
        """v0.55 รอบเวลา t = "หยุด" เมื่อเครื่องหยุดอยู่ตอนครบกำหนดของรอบ (เริ่มหยุดก่อนครบกำหนด และยังไม่เดินจนเลยกำหนด)
        — ตรงกับการงดรอบตอนแจ้งหยุด/เดินเครื่อง · รอบที่มีผลตรวจแล้วไม่แรเงา · ไม่มีประวัติหยุด → ใช้รอบที่ถูกงด (skipped)"""
        if t > now or (t.date(), t.hour * 60 + t.minute) in done_slots:
            return None
        dl = t + win
        for x in dts:
            if x["s"] < dl and x["e"] >= min(dl, now):
                return x
        if not dts and S.ts(t) in skipped_at:
            return {"s": t, "e": t, "by": ""}
        return None

    if dts:
        down_days = set()                                    # มีประวัติหยุด/เดินเครื่อง → ใช้ช่วงเวลาจริง ไม่ใช้สถานะรอบ
    if form_mins and dts:
        for d in range(1, last + 1):
            dd = date(month.year, month.month, d)
            if dd > today:
                continue
            base = datetime.combine(dd, datetime.min.time())
            if all(slot_down(base + timedelta(minutes=m)) for m in form_mins):
                down_days.add(d)
    days = []
    for d in range(1, last + 1):
        dd = date(month.year, month.month, d)
        state = "future" if dd > today else ("down" if d in down_days else ("off" if d not in on_days else ""))
        days.append({"day": d, "wd": TH_WD[dd.weekday()], "weekend": dd.weekday() >= 5, "state": state, "subs": [],
                     "label": str(d)})
    # ผลตรวจ → วันที่ (ใช้ผู้ตรวจ/ผู้อนุมัติรายวัน)
    for s_ in subs:
        dt = S.parse_ts(s_.get("place_at") or s_["finished_at"])
        if dt and dt.month == month.month:
            days[dt.day - 1]["subs"].append(s_)
    for c in days:
        c["inspectors"] = "/".join(dict.fromkeys(_short(x["inspector_name"]) for x in c["subs"] if x.get("inspector_name")))
        c["approvers"] = "/".join(dict.fromkeys(_short(x["approver_name"]) for x in c["subs"]
                                                if x.get("approver_name") and x.get("approval_status") == "approved"))
        # v0.24 รายคน (id, ชื่อย่อ) → ใช้รูปลายเซ็นในแถวผู้ตรวจ/หัวหน้างาน
        c["insp"] = list(dict.fromkeys((x.get("inspector_id"), _short(x["inspector_name"])) for x in c["subs"] if x.get("inspector_name")))
        c["appr"] = list(dict.fromkeys((x.get("approved_by"), _short(x["approver_name"])) for x in c["subs"]
                                       if x.get("approver_name") and x.get("approval_status") == "approved"))
    rows = []
    for it in items:
        kind, mins = _item_period(it, form_kind, form_mins, cal)
        if kind == "slots" and len(mins) > MAX_SLOTS:
            kind, mins = "free", []
        row = {"it": it, "spec": spec_text(it), "kind": kind, "freq": _freq_th(it, kind, mins)}
        row["tm"] = tm_text(row)
        key = it["item_key"]
        hits = []                                   # (datetime, sub, ans)
        for s_ in subs:
            a = answers.get(s_["id"], {}).get(key)
            if a and a.get("judgement") != "na" and (a.get("value_text") or a.get("value_num") is not None):
                hits.append((S.parse_ts(s_.get("place_at") or s_["finished_at"]), s_, a))
        if kind == "slots":
            tstr = fmt_times(mins)
            g = grace("times", tstr, cal)
            lines = [{"label": _hm(m), "cells": [None] * last, "count": [0] * last,
                      "down": [bool(slot_down(datetime(month.year, month.month, d) + timedelta(minutes=m))) for d in range(1, last + 1)]}
                     for m in mins]
            for dt, s_, a in hits:
                st = slot_start("times", tstr, dt + g, cal)
                if not st or st.month != month.month or st.year != month.year:
                    continue
                idx = mins.index(st.hour * 60 + st.minute) if (st.hour * 60 + st.minute) in mins else 0
                ln = lines[idx]
                ln["cells"][st.day - 1] = a                 # ค่าล่าสุดของรอบนั้น
                ln["count"][st.day - 1] += 1
            row["lines"] = lines
        elif kind == "free":
            line = {"label": "", "cells": [None] * last, "count": [0] * last}
            for dt, s_, a in hits:
                if dt.month == month.month:
                    line["cells"][dt.day - 1] = a
                    line["count"][dt.day - 1] += 1
            row["lines"] = [line]
        elif kind == "week":
            segs, d = [], 1
            while d <= last:
                dd = date(month.year, month.month, d)
                span = min(7 - dd.weekday(), last - d + 1)
                segs.append({"start": d, "span": span, "ans": None, "at": None, "future": dd > today})
                d += span
            for dt, s_, a in hits:                      # สัปดาห์ตามปฏิทิน (จ–อา) ของวันที่ตรวจ
                if dt.month != month.month:
                    continue
                for sg in segs:
                    if sg["start"] <= dt.day < sg["start"] + sg["span"]:
                        sg["ans"], sg["at"] = a, dt
            row["segs"] = segs
        elif kind == "half":                            # v0.35 ครึ่งเดือน: 1–15 · 16–สิ้นเดือน
            segs = [{"start": 1, "span": 15, "ans": None, "at": None, "future": date(month.year, month.month, 1) > today},
                    {"start": 16, "span": last - 15, "ans": None, "at": None, "future": date(month.year, month.month, 16) > today}]
            for dt, s_, a in hits:
                if dt.month == month.month and dt.year == month.year:
                    sg = segs[0] if dt.day <= 15 else segs[1]
                    sg["ans"], sg["at"] = a, dt
            row["segs"] = segs
        elif kind == "period":                          # v0.32 ช่วงตามความถี่ (เช่น ทุก 2 สัปดาห์) — ตัดตามขอบเดือน
            f_ = it["check_freq"]
            segs = []
            for d in range(1, last + 1):
                dd = date(month.year, month.month, d)
                key_ = slot_start(f_, "", datetime.combine(dd, datetime.min.time()) + timedelta(hours=23, minutes=59), cal)
                if segs and segs[-1]["key"] == key_:
                    segs[-1]["span"] += 1
                else:
                    segs.append({"key": key_, "start": d, "span": 1, "ans": None, "at": None, "future": dd > today})
            for dt, s_, a in hits:
                if dt.month != month.month or dt.year != month.year:
                    continue
                for sg in segs:
                    if sg["start"] <= dt.day < sg["start"] + sg["span"]:
                        sg["ans"], sg["at"] = a, dt
            row["segs"] = segs
        else:                                           # month
            seg = {"start": 1, "span": last, "ans": None, "at": None, "future": False}
            for dt, s_, a in hits:
                if dt.month == month.month:
                    seg["ans"], seg["at"] = a, dt
            row["segs"] = [seg]
        rows.append(row)
    # แถวผู้ตรวจรายกะ: กะที่เครื่องหยุด → "หยุด" + ผู้กดหยุด (ในกะที่กด)
    from . import sign_blocks as SB
    shift_down: dict[str, list] = {"day": [None] * last, "night": [None] * last}
    for d in range(1, last + 1):
        base = datetime(month.year, month.month, d)
        for m in form_mins or []:
            x = slot_down(base + timedelta(minutes=m))
            if x:
                k = SB.shift_of(m, cal)
                cur = shift_down[k][d - 1] or {"by": ""}
                if x.get("by") and x["s"].date() == base.date() and SB.shift_of(x["s"].hour * 60 + x["s"].minute, cal) == k:
                    cur["by"] = x["by"]
                shift_down[k][d - 1] = cur
    return {"rows": rows, "days": days, "last": last, "form_kind": form_kind,
            "form_times": ", ".join(_hm(m) for m in form_mins), "downtime": dts, "shift_down": shift_down}


def downtime_periods(db, equipment_id, first: date, end: date) -> list[dict]:
    """v0.54 ช่วงเครื่องหยุด/PM ที่ทับเดือนนี้ พร้อมผู้กดหยุด / ผู้กดเดินเครื่อง"""
    if not equipment_id:
        return []
    from .downtime import CATEGORIES
    a = S.ts(datetime.combine(first, datetime.min.time()))
    b = S.ts(datetime.combine(end, datetime.max.time()))
    now = S.now_dt()
    out = []
    for r in db.execute("""SELECT d.*, u1.name AS by_name, u2.name AS end_name FROM cs_downtime d
                           LEFT JOIN users u1 ON u1.id=d.started_by LEFT JOIN users u2 ON u2.id=d.ended_by
                           WHERE d.equipment_id=? AND d.start_at<=? AND (d.end_at IS NULL OR d.end_at>=?)
                           ORDER BY d.start_at""", (equipment_id, b, a)):
        st = S.parse_ts(r["start_at"])
        en = S.parse_ts(r["end_at"]) if r["end_at"] else None
        out.append({"s": st, "e": en or now, "open": en is None, "by": _short(r["by_name"] or ""), "by_full": r["by_name"] or "",
                    "end_by": r["end_name"] or "", "reason": r["reason"] or "", "cat": CATEGORIES.get(r["category"], r["category"] or ""),
                    "skipped": r["skipped_rounds"] or 0, "note": r["end_note"] or ""})
    return out


def downtime_issue(x: dict, cal: dict) -> dict:
    """แถวในรายการผิดปกติ: หยุดตั้งแต่ … (กะ) ถึง … (กะ) โดยใคร"""
    from . import sign_blocks as SB
    sh = lambda t: "กะเช้า" if SB.shift_of(t.hour * 60 + t.minute, cal) == "day" else "กะดึก"
    txt = f"ตั้งแต่ {x['s']:%d/%m %H:%M} ({sh(x['s'])}) · กดหยุดโดย {x['by_full'] or '-'}"
    txt += " · ยังหยุดอยู่" if x["open"] else f" ถึง {x['e']:%d/%m %H:%M} ({sh(x['e'])}) · กดเดินเครื่องโดย {x['end_by'] or '-'}"
    if x["skipped"]:
        txt += f" · งดรอบตรวจ {x['skipped']} รอบ"
    if x["note"]:
        txt += f" · {x['note']}"
    hrs = round((x["e"] - x["s"]).total_seconds() / 3600, 1)
    return {"at": S.ts(x["s"]), "item": f"⛔ เครื่องหยุด / {x['cat']}", "value": f"{hrs:g} ชม.", "unit": "", "judgement": "down",
            "remark": (x["reason"] + " · " if x["reason"] else "") + txt, "inspector": x["by_full"], "capa": None}


def _freq_th(it: dict, kind: str, mins: list[int]) -> str:
    if kind == "slots":
        return f"{len(mins)} ครั้ง/วัน" if len(mins) > 1 else ("วันละ 1 ครั้ง" + (f" ({_hm(mins[0])})" if it.get("check_freq") == "times" else ""))
    from .itemfreq import interval, interval_label
    if interval(it.get("check_freq") or ""):
        return FREQS_LABEL(it.get("check_freq")) or interval_label(it.get("check_freq"))
    return {"week": "สัปดาห์ละ 1 ครั้ง", "month": "เดือนละ 1 ครั้ง", "half": "เดือนละ 2 ครั้ง (1–15 / 16–สิ้นเดือน)",
            "free": "ตามที่ตรวจ"}.get(kind, "")


def FREQS_LABEL(code) -> str:                            # noqa: N802
    from .itemfreq import FREQS
    return FREQS.get(code or "", "")


def tm_text(row: dict) -> str:
    """คำในช่อง 'ช่วง' ของแถวช่องรวม"""
    from .itemfreq import UNIT_TH, interval
    iv = interval(row["it"].get("check_freq") or "")
    if iv and iv[1] > 1:
        return f"{iv[1]} {UNIT_TH[iv[0]]}"
    if row["kind"] == "half":
        return "ครึ่งเดือน"
    return "สัปดาห์" if row["kind"] in ("week", "period") else "เดือน"


def seg_text(seg: dict, it: dict) -> str:
    return cell_text(seg.get("ans"), it)


def shift_people(db, form_id: int, month: date, last: int) -> dict[str, list[list[tuple]]]:
    """v0.42 ผู้ตรวจรายวันแยกกะ: {"day": [[(uid, ชื่อย่อ)] ต่อวัน], "night": [...]}
    กะ = เวลาเริ่มของรอบตรวจที่ผลตรวจผูกอยู่ (ไม่ผูกรอบ = เวลาที่ส่ง) · กะดึกที่ตรวจหลังเที่ยงคืน นับเป็นวันของรอบ"""
    from . import sign_blocks as SB
    from .itemfreq import get_calendar, parse_times
    cal = get_calendar(db)
    ds = (parse_times(cal.get("day_start")) or [480])[0]
    start = datetime(month.year, month.month, 1)
    end = datetime(month.year, month.month, last) + timedelta(days=1, hours=12)
    out: dict[str, list[list[tuple]]] = {"day": [[] for _ in range(last)], "night": [[] for _ in range(last)]}
    for r in db.execute("""SELECT s.inspector_id, u.name, s.finished_at, rd.due_at FROM cs_submissions s
                           LEFT JOIN users u ON u.id=s.inspector_id LEFT JOIN cs_rounds rd ON rd.id=s.round_id
                           WHERE s.form_id=? AND s.status<>'superseded'
                             AND ((s.finished_at>=? AND s.finished_at<?) OR (rd.due_at>=? AND rd.due_at<?))
                           ORDER BY s.finished_at, s.id""", (form_id, S.ts(start), S.ts(end), S.ts(start), S.ts(end))):
        if not r["name"]:
            continue
        t = S.parse_ts(r["due_at"]) or S.parse_ts(r["finished_at"])
        if not t:
            continue
        m = t.hour * 60 + t.minute
        k = SB.shift_of(m, cal)
        d = t.date()
        if not r["due_at"] and k == "night" and m < ds:
            d -= timedelta(days=1)
        if d.year != month.year or d.month != month.month:
            continue
        p = (r["inspector_id"], _short(r["name"]))
        if p not in out[k][d.day - 1]:
            out[k][d.day - 1].append(p)
    return out


def build_month_sheet(db, form_id: int, month: date, secret: str, printed_by: str = "") -> dict:
    form = S.get_form(db, form_id)
    if not form:
        raise S.ValidationError("ไม่พบแบบฟอร์ม")
    start = datetime(month.year, month.month, 1)
    last = calendar.monthrange(month.year, month.month)[1]
    end = datetime(month.year, month.month, last, 23, 59, 59)
    subs = [dict(r) for r in db.execute("""
        SELECT s.*, u.name AS inspector_name, a.name AS approver_name, v.version_no, rd.due_at AS round_due
        FROM cs_submissions s LEFT JOIN users u ON u.id=s.inspector_id LEFT JOIN users a ON a.id=s.approved_by
        LEFT JOIN cs_form_versions v ON v.id=s.form_version_id LEFT JOIN cs_rounds rd ON rd.id=s.round_id
        WHERE s.form_id=? AND s.status<>'superseded'
          AND (s.finished_at BETWEEN ? AND ? OR rd.due_at BETWEEN ? AND ?)
        ORDER BY s.finished_at, s.id""", (form_id, S.ts(start), S.ts(end), S.ts(start), S.ts(end)))]
    for s_ in subs:                                         # v0.54 บันทึกย้อนหลัง (ส่งหลังรอบ > 12 ชม.) → ลงช่องของวันรอบนั้น
        due = S.parse_ts(s_.get("round_due")) if s_.get("round_due") else None
        fin = S.parse_ts(s_["finished_at"])
        s_["backfill"] = bool(due and fin and fin - due > timedelta(hours=12))
        s_["place_at"] = S.ts(due) if s_["backfill"] else s_["finished_at"]
    subs = [s_ for s_ in subs if S.ts(start) <= (s_["place_at"] or "") <= S.ts(end)]
    if any(s_.get("source") == "auto" for s_ in subs):     # v0.84.1 ค่าจาก SCADA ช่วงเครื่องหยุด/สำรอง → ไม่แสดง (ยึดสถานะเครื่อง)
        from .srcmap import down_checker
        down = down_checker(db, form_id, start.date() - timedelta(days=1), end.date())
        subs = [s_ for s_ in subs if not (s_.get("source") == "auto" and str(s_.get("client_uuid") or "").startswith("src")
                                          and down(S.parse_ts(s_["finished_at"])))]
    answers: dict[int, dict[str, dict]] = {}
    if subs:
        ids = [s["id"] for s in subs]
        for r in db.execute(f"SELECT * FROM cs_answers WHERE submission_id IN ({','.join('?' * len(ids))})", ids):
            answers.setdefault(r["submission_id"], {})[r["item_key"]] = dict(r)
    items = _items_for(db, [s["form_version_id"] for s in subs], form["current_version_id"])
    grid = build_grid(db, form, month, items, subs, answers)
    rows = grid["rows"]
    cols = grid["days"]
    pages = [cols]
    rounds = db.execute("""SELECT COUNT(*) total, SUM(status='done_on_time') on_time, SUM(status='done_late') late,
                                  SUM(status='missed') missed, SUM(status IN ('overdue','pending','in_progress')) open
                           FROM cs_rounds WHERE form_id=? AND due_at BETWEEN ? AND ?""",
                        (form_id, S.ts(start), S.ts(end))).fetchone()
    ng_list = []
    for s in subs:
        for key, a in answers.get(s["id"], {}).items():
            if a["judgement"] in ("ng", "warn"):
                it = next((i for i in items if i["item_key"] == key), {"name": key, "unit": ""})
                cap = db.execute("SELECT code, status FROM cs_actions WHERE submission_id=? ORDER BY id LIMIT 1", (s["id"],)).fetchone()
                ng_list.append({"at": s["finished_at"], "item": it["name"], "value": a["value_text"] or "",
                                "unit": it.get("unit") or "", "judgement": a["judgement"], "remark": a["remark"] or "",
                                "inspector": s["inspector_name"] or "", "capa": dict(cap) if cap else None})
    from .itemfreq import get_calendar as _gc
    _cal = _gc(db)
    ng_list = [downtime_issue(x, _cal) for x in grid.get("downtime") or []] + ng_list    # v0.54 ช่วงเครื่องหยุด / PM แสดงก่อน
    inspectors = sorted({s["inspector_name"] for s in subs if s["inspector_name"]})
    approvers = sorted({s["approver_name"] for s in subs if s["approver_name"]})
    approved = sum(1 for s in subs if s["approval_status"] == "approved")
    versions = sorted({s["version_no"] for s in subs if s["version_no"]})
    if not versions and form["current_version_id"]:
        r = db.execute("SELECT version_no FROM cs_form_versions WHERE id=?", (form["current_version_id"],)).fetchone()
        versions = [r[0]] if r else []
    freq = [S.describe_schedule(dict(r)) for r in db.execute("SELECT * FROM cs_schedules WHERE form_id=? AND active=1", (form_id,))]
    from . import sign_blocks as SB
    from . import signoffs as SO
    signs = SB.build(db, form, month, last)
    for sg in signs["insp"]["segs"]:                        # v0.37 ช่องผู้ตรวจแบบรวมช่วง: ทุกคนที่ตรวจในช่วงนั้น
        ppl = list(dict.fromkeys(p for c in cols[sg["start"] - 1:sg["start"] - 1 + sg["span"]] for p in c["insp"]))
        sg["people"] = ppl
        sg["names"] = "/".join(nm for _u, nm in ppl)
        sg["future"] = date(month.year, month.month, sg["start"]) > S.now_dt().date()
    if signs["insp"].get("shifts"):                         # v0.42 แถวผู้ตรวจกะกลางวัน / กะกลางคืน
        sp = shift_people(db, form_id, month, last)
        for sh_ in signs["insp"]["shifts"]:
            sh_["cells"] = sp[sh_["key"]]
            sh_["down"] = grid["shift_down"].get(sh_["key"]) or []            # v0.54
    from . import shiftsign as SSG                         # v0.54 ลงนามรับทราบ / ย้อนหลังในช่องผู้ตรวจ
    acks = SSG.acks_for(db, form_id, month)
    if acks:
        SSG.merge_into({"signs": signs, "days": cols}, acks)
    from . import sheet_layout as SL
    lay = SL.get(db)                                       # v0.26 ข้อความ/การแสดงผลที่ผู้ดูแลระบบตั้งเอง
    if signs["rows"]:
        signs["rows"][0]["label"] = lay["row_sup"]
    for b in signs["boxes"]:
        if b.get("key") == "util":
            b["title"] = lay["util_title"]
            for cell, key in zip(b["cells"], ("util_mgr", "util_sv")):
                cell["role"] = lay[key]
    sig_ids = {s["inspector_id"] for s in subs} | {s["approved_by"] for s in subs if s["approval_status"] == "approved"}
    sig_ids |= {uid for sh_ in signs["insp"].get("shifts") or [] for c in sh_.get("cells") or [] for uid, _n in c}
    sig_ids |= {uid for ppl in acks.values() for uid, _n in ppl}
    sigs = SO.sig_bundle(db, sig_ids | set(signs["user_ids"]))
    so_digest = sorted((r["slot"], r["user_id"], r["signed_at"]) for r in SO.records(db, form_id, month).values())
    digest = json.dumps([form_id, month.isoformat(), [(s["id"], s["finished_at"], s["approval_status"], s["approved_at"],
                        sorted((k, a["value_text"], a["judgement"]) for k, a in answers.get(s["id"], {}).items())) for s in subs]]
                        + ([so_digest] if so_digest else [])
                        + ([sorted((f"{d}:{k}", [u for u, _n in v]) for (d, k), v in acks.items())] if acks else []),            # การยืนยันหน่วยงาน (เอกสารเดิมที่ไม่มี = รหัสเดิม)
                        ensure_ascii=False, sort_keys=True)
    return {
        "kind": "month", "form": form, "stamp": SB.stamp_of(db, form), "L": lay, "month": month, "month_th": th_month(month), "last_day": last,
        "rows": rows, "pages": pages, "days": cols, "subs": subs, "items": items, "grid": grid,
        "summary": {"inspections": len(subs), "rounds": rounds["total"] or 0, "on_time": rounds["on_time"] or 0,
                    "late": rounds["late"] or 0, "missed": rounds["missed"] or 0, "open": rounds["open"] or 0,
                    "ng": sum(s["ng_count"] for s in subs), "warn": sum(s["warn_count"] for s in subs),
                    "approved": approved, "pending": sum(1 for s in subs if s["approval_status"] == "pending"),
                    "days_checked": len({c["day"] for c in cols if c["subs"]})},
        "ng_list": ng_list, "inspectors": inspectors, "approvers": approvers,
        "signs": signs, "sigs": sigs,
        "versions": versions, "schedules": freq,
        "iso": iso_info(db, form_id, max((s["form_version_id"] for s in subs), default=None) or form["current_version_id"]),
        "doc_no": f"{form['code'] or 'CS'}-{month.strftime('%Y%m')}",
        "verify": _sign(secret, digest), "printed_at": datetime.now(), "printed_by": printed_by,
    }


def build_record(db, sub_id: int, secret: str, printed_by: str = "") -> dict:
    s = db.execute("""SELECT s.*, u.name AS inspector_name, a.name AS approver_name, v.version_no, f.code AS form_code,
                             f.name AS form_name, f.id AS fid, e.code AS eq_code, e.name AS eq_name, fa.name AS factory_name,
                             ar.name AS area_name, r.due_at AS round_due, r.deadline_at AS round_deadline, r.status AS round_status
                      FROM cs_submissions s LEFT JOIN users u ON u.id=s.inspector_id LEFT JOIN users a ON a.id=s.approved_by
                      JOIN cs_forms f ON f.id=s.form_id LEFT JOIN cs_form_versions v ON v.id=s.form_version_id
                      LEFT JOIN equipment e ON e.id=COALESCE(s.equipment_id, f.equipment_id)
                      LEFT JOIN factories fa ON fa.id=f.factory_id LEFT JOIN areas ar ON ar.id=f.area_id
                      LEFT JOIN cs_rounds r ON r.id=s.round_id
                      WHERE s.id=?""", (sub_id,)).fetchone()
    if not s:
        raise S.ValidationError("ไม่พบผลตรวจ")
    s = dict(s)
    items = [dict(r) for r in db.execute("SELECT * FROM cs_form_items WHERE version_id=? ORDER BY order_no, id",
                                         (s["form_version_id"],))]
    ans = {r["item_key"]: dict(r) for r in db.execute("SELECT * FROM cs_answers WHERE submission_id=?", (sub_id,))}
    photos = {}
    for p in db.execute("""SELECT p.file_path, a.item_key FROM cs_photos p LEFT JOIN cs_answers a ON a.id=p.answer_id
                           WHERE p.submission_id=? ORDER BY p.id""", (sub_id,)):
        photos.setdefault(p["item_key"], []).append(p["file_path"])
    rows = []
    for i, it in enumerate(items, 1):
        a = ans.get(it["item_key"]) or {}
        rows.append({"no": i, "it": it, "spec": spec_text(it), "value": a.get("value_text") or "",
                     "judgement": a.get("judgement") or "", "remark": a.get("remark") or "",
                     "photos": photos.get(it["item_key"], [])})
    events = [dict(r) for r in db.execute("""SELECT x.id, x.finished_at, x.approval_status, x.approved_at, x.approval_note,
                                                   u.name AS approver_name FROM cs_submissions x LEFT JOIN users u ON u.id=x.approved_by
                                            WHERE x.id=? OR x.resubmit_of=? OR x.id=? ORDER BY x.id""",
                                         (sub_id, sub_id, s["resubmit_of"] or 0))]
    actions = [dict(r) for r in db.execute("SELECT code, title, status, due_date FROM cs_actions WHERE submission_id=?", (sub_id,))]
    digest = json.dumps([sub_id, s["finished_at"], s["approval_status"], s["approved_at"],
                         sorted((k, a["value_text"], a["judgement"], a["remark"]) for k, a in ans.items())],
                        ensure_ascii=False, sort_keys=True)
    ok = sum(1 for r in rows if r["judgement"] == "ok")
    from .points import loads as load_scans
    from . import signoffs as SO                           # v0.30 ลายเซ็นผู้ตรวจ / ผู้อนุมัติ (จาก "ลายเซ็นของฉัน")
    sigs = SO.sig_bundle(db, [s.get("inspector_id"), s.get("approved_by") if s.get("approval_status") == "approved" else None])
    return {"kind": "record", "s": s, "rows": rows, "events": events, "actions": actions, "sigs": sigs,
            "iso": iso_info(db, s["fid"], s["form_version_id"]), "scans": load_scans(s.get("point_scans")),
            "stamp": __import__("ecs.sign_blocks", fromlist=["stamp_of"]).stamp_of(db, S.get_form(db, s["fid"]) or {"id": s["fid"]}),
            "L": __import__("ecs.sheet_layout", fromlist=["get"]).get(db),
            "counts": {"ok": ok, "warn": s["warn_count"], "ng": s["ng_count"], "total": len(rows)},
            "doc_no": f"{s['form_code'] or 'CS'}-R{sub_id:06d}", "verify": _sign(secret, digest),
            "printed_at": datetime.now(), "printed_by": printed_by}


def to_excel(sheets: list[dict], logo_path: str | None = None, stamp_path: str | None = None,
             stamp_paths: dict | None = None) -> bytes:
    """หลายแบบฟอร์ม → 1 ไฟล์ Excel (1 แบบฟอร์ม = 1 ชีท) — รูปแบบเดียวกับใบบันทึก PDF
    หัวเอกสาร (โลโก้ · ชื่อเอกสาร · เลขที่/Rev.) · ตารางหัวข้อ × วันที่ แบ่งบรรทัดตามเวลารอบ ·
    ช่วงสัปดาห์/เดือนเป็นช่องรวม · วันไม่มีรอบ/เครื่องหยุดแรเงา · ผู้ตรวจ/ผู้อนุมัติรายวัน · สรุป · NG · ช่องลงนาม · กล่องหน่วยงานมุมขวาบน · รหัสตรวจสอบ"""
    import io
    import os

    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter as L
    wb = Workbook()
    wb.remove(wb.active)
    NAVY = "142A75"
    thin, med, dot = Side(style="thin", color="64748B"), Side(style="medium", color=NAVY), Side(style="dotted", color="94A3B8")
    box = Border(left=thin, right=thin, top=thin, bottom=thin)
    fill = lambda c: PatternFill("solid", fgColor=c)            # noqa: E731
    F_HEAD, F_SEC, F_NG, F_WARN, F_DOWN, F_SEG, F_WE, F_TM = (fill("E0E7FF"), fill("F1F5F9"), fill("FECACA"), fill("FDE68A"),
                                                             fill("E5E7EB"), fill("EEF2FF"), fill("FAFBFF"), fill("F8FAFC"))
    F_OFF = PatternFill("lightUp", fgColor="CBD5E1", bgColor="F1F5F9")
    C = Alignment(horizontal="center", vertical="center", wrap_text=True)
    LW = Alignment(horizontal="left", vertical="center", wrap_text=True)
    font = lambda **k: Font(name="Tahoma", size=k.pop("size", 9), **k)   # noqa: E731
    used = set()

    def put(ws, r, c, v="", *, f=None, fl=None, al=C, bd=box, r2=None, c2=None):
        if r2 or c2:
            ws.merge_cells(start_row=r, start_column=c, end_row=r2 or r, end_column=c2 or c)
            for rr in range(r, (r2 or r) + 1):
                for cc in range(c, (c2 or c) + 1):
                    cell = ws.cell(rr, cc)
                    if bd:
                        cell.border = bd
                    if fl:
                        cell.fill = fl
        cell = ws.cell(r, c, v)
        cell.font = f or font()
        cell.alignment = al
        if bd:
            cell.border = bd
        if fl:
            cell.fill = fl
        return cell

    for sh in sheets:
        fm = sh["form"]
        title = "".join(ch for ch in (fm["code"] or fm["name"]) if ch not in '[]:*?/\\')[:28] or "Sheet"
        while title in used:
            title = title[:26] + "_" + str(len(used))
        used.add(title)
        ws = wb.create_sheet(title)
        ws.sheet_view.showGridLines = False
        days, ND = sh["days"], len(sh["days"])
        D0 = 5                                            # คอลัมน์วันที่ 1
        R = D0 + ND - 1                                   # คอลัมน์สุดท้าย
        widths = {1: 4.5, 2: 34, 3: 14, 4: 7}
        for c, w in widths.items():
            ws.column_dimensions[L(c)].width = w
        for j in range(ND):
            ws.column_dimensions[L(D0 + j)].width = 4.4
        # ── หัวเอกสาร (แถว 1–5) ──
        iso = sh.get("iso") or {}
        meta = []
        if iso.get("doc_no"):
            meta += [("เลขที่เอกสาร", f"{iso['doc_no']} {iso.get('rev') or ''}".strip()), ("วันที่มีผล", iso.get("effective") or "-")]
        meta += [("เลขที่บันทึก" if iso.get("doc_no") else "เลขที่เอกสาร", sh["doc_no"]),
                 ("รหัสแบบฟอร์ม", (fm["code"] or "-") + (" · v" + ", v".join(str(v) for v in sh["versions"]) if sh["versions"] else "")),
                 ("ประจำเดือน", sh["month_th"])]
        # กล่องลงนามหน่วยงาน (ENVIRONMENT หรือ SAFETY) มุมขวาบน — v0.23
        boxes = (sh.get("signs") or {}).get("boxes") or []
        W = 4                                               # ความกว้างต่อช่องลงนาม (คอลัมน์วันที่)
        bw = sum(len(b["cols"]) * W + (1 if b["flow"] else 0) for b in boxes)
        ME = R - bw                                         # คอลัมน์สุดท้ายของชื่อเอกสาร (เลขที่เอกสารย้ายไปมุมซ้ายล่าง v0.24)
        hr = 5
        put(ws, 1, 1, "", r2=hr, c2=2)                   # ตราประทับ PROTECTED / UTILITY Div. (รูป)
        LY = sh.get("L") or __import__("ecs.sheet_layout", fromlist=["DEFAULTS"]).DEFAULTS
        put(ws, 1, 3, LY["title_th"], f=font(size=15, bold=True, color=NAVY), r2=3, c2=ME)
        put(ws, 4, 3, fm["name"], f=font(size=11, bold=True), r2=hr, c2=ME)
        for r in range(1, hr + 1):
            ws.row_dimensions[r].height = 15
        sigs = sh.get("sigs") or {}

        def add_png(png, col, row, w_px, h_px, ncols=1, nrows=1):
            """วางรูป (bytes) ให้พอดีและอยู่กลางช่อง (col,row) ขนาดช่องรวม w_px × h_px"""
            if not png:
                return
            try:
                from openpyxl.drawing.image import Image as XLImage
                from openpyxl.drawing.spreadsheet_drawing import AnchorMarker, OneCellAnchor
                from openpyxl.drawing.xdr import XDRPositiveSize2D
                from openpyxl.utils.units import pixels_to_EMU
                img = XLImage(io.BytesIO(png))
                k = min((w_px - 4) / img.width, (h_px - 4) / img.height)
                w, h = max(1, int(img.width * k)), max(1, int(img.height * k))
                img.width, img.height = w, h
                img.anchor = OneCellAnchor(_from=AnchorMarker(col=col - 1, colOff=pixels_to_EMU((w_px - w) // 2),
                                                              row=row - 1, rowOff=pixels_to_EMU((h_px - h) // 2)),
                                           ext=XDRPositiveSize2D(pixels_to_EMU(w), pixels_to_EMU(h)))
                ws.add_image(img)
            except Exception:                              # noqa: BLE001
                pass

        def colpx(c1, c2=None):
            return sum(int((ws.column_dimensions[L(c)].width or 8.43) * 7 + 5) for c in range(c1, (c2 or c1) + 1))

        def rowpx(r1, r2=None):
            return sum(int((ws.row_dimensions[rr].height or 15) * 96 / 72) for rr in range(r1, (r2 or r1) + 1))

        def compose(pngs, vertical):
            """หลายลายเซ็นในช่องเดียว → รูปเดียว (เรียงข้างกัน)"""
            if len(pngs) == 1:
                return pngs[0]
            from PIL import Image
            ims = [Image.open(io.BytesIO(x)).convert("RGBA") for x in pngs]
            if vertical:                                   # รูปหมุนแล้ว (สูง) → เรียงซ้าย-ขวา
                H = max(i.height for i in ims)
                out = Image.new("RGBA", (sum(i.width for i in ims) + 6 * (len(ims) - 1), H), (255, 255, 255, 0))
                x = 0
                for i in ims:
                    out.paste(i, (x, (H - i.height) // 2), i)
                    x += i.width + 6
            else:
                W = max(i.width for i in ims)
                out = Image.new("RGBA", (W, sum(i.height for i in ims)), (255, 255, 255, 0))
                y = 0
                for i in ims:
                    out.paste(i, ((W - i.width) // 2, y), i)
                    y += i.height
            buf = io.BytesIO()
            out.save(buf, "PNG")
            return buf.getvalue()
        box_pending = []                                     # วางรูปหลังตั้งความสูงแถวครบ

        def box_sign(so, c1, c2):
            txt = (_short(so.get("user_name") or "") + " · " + th_dt(so["signed_at"], False)) if so and not sigs.get(so["user_id"]) else \
                  (th_dt(so["signed_at"], False) if so else "")
            put(ws, 3, c1, txt, f=font(size=7, color="142A75", bold=bool(so)), al=Alignment(horizontal="center", vertical="bottom"),
                r2=hr - 1, c2=c2)
            if so and sigs.get(so["user_id"]):
                box_pending.append((sigs[so["user_id"]]["png"], c1, c2, 3))

        c = ME + 1
        for b in boxes:
            n = len(b["cols"])
            F_BH = fill("EEF2FF")
            if b["flow"]:
                span = n * W + n - 1
                put(ws, 1, c, b["note"], f=font(size=8, bold=True, color=NAVY), fl=F_BH, c2=c + span - 1)
                cc = c
                for i, (role, _act) in enumerate(b["cols"]):
                    if i:
                        put(ws, 2, cc, "▶", f=font(size=10, color=NAVY), r2=hr, bd=Border(left=thin, right=thin))
                        cc += 1
                    so = b["cells"][i].get("so") if b.get("cells") else None
                    put(ws, 2, cc, role, f=font(size=8, bold=True, color=NAVY), fl=F_BH, c2=cc + W - 1)
                    box_sign(so, cc, cc + W - 1)
                    put(ws, hr, cc, "วันที่ " + (th_dt(so["signed_at"], False) if so else "...../...../....."),
                        f=font(size=7, color="334155"), c2=cc + W - 1)
                    cc += W
                c += span
            elif b.get("role_bottom"):                     # กล่อง Utility: หัว · ช่องเซ็น · ตำแหน่งด้านล่าง
                put(ws, 1, c, b["title"], f=Font(name="Tahoma", size=10, italic=True), c2=c + n * W - 1)
                for i, (role, _act) in enumerate(b["cols"]):
                    cc = c + i * W
                    so = b["cells"][i].get("so")
                    txt = (_short(so.get("user_name") or "") + " · " + th_dt(so["signed_at"], False)) if so and not sigs.get(so["user_id"]) else \
                          (th_dt(so["signed_at"], False) if so else "")
                    put(ws, 2, cc, txt, f=font(size=7, color="142A75", bold=bool(so)), al=Alignment(horizontal="center", vertical="bottom"),
                        r2=hr - 1, c2=cc + W - 1)
                    if so and sigs.get(so["user_id"]):
                        box_pending.append((sigs[so["user_id"]]["png"], cc, cc + W - 1, 2))
                    put(ws, hr, cc, role, f=Font(name="Tahoma", size=9, italic=True), c2=cc + W - 1)
                c += n * W
            else:
                put(ws, 1, c, b["title"], f=font(size=9, bold=True, color=NAVY), fl=F_BH, c2=c + n * W - 1)
                for i, (role, act) in enumerate(b["cols"]):
                    cc = c + i * W
                    put(ws, 2, cc, role, f=font(size=8, bold=True), c2=cc + W - 1)
                    box_sign(b["cells"][i].get("so") if b.get("cells") else None, cc, cc + W - 1)
                    put(ws, hr, cc, act, f=font(size=7, color="334155"), c2=cc + W - 1)
                c += n * W
        def add_img(path, anchor, height_px):
            if not path or not os.path.exists(path):
                return
            try:
                from openpyxl.drawing.image import Image as XLImage
                img = XLImage(path)
                ratio = img.width / img.height if img.height else 4
                img.height, img.width = height_px, int(height_px * ratio)
                ws.add_image(img, anchor)
            except Exception:                              # noqa: BLE001 — ไม่มี Pillow ก็ยังได้ไฟล์
                pass
        add_img((stamp_paths or {}).get(sh.get("stamp") or "utility") or stamp_path, "A1", min(96, hr * 20 - 4))
        for png, c1, c2, r1 in box_pending:                  # ลายเซ็นในกล่อง (เหนือวันที่ / ตำแหน่ง)
            add_png(png, c1, r1, colpx(c1, c2), rowpx(r1, hr - 1) - 10)
        # ── ข้อมูลเครื่อง ──
        r = hr + 2
        loc = (fm.get("factory_name") or "-") + (" › " + fm["area_name"] if fm.get("area_name") else "")
        eq = (fm.get("eq_code") or "— ไม่ผูกเครื่อง —") + (" · " + fm["eq_name"] if fm.get("eq_name") else "")
        split = D0 + 11
        put(ws, r, 1, f"เครื่องจักร: {eq}", al=LW, c2=3, fl=F_SEG)
        put(ws, r, 4, f"โรงงาน / พื้นที่: {loc}", al=LW, c2=split, fl=F_SEG)
        put(ws, r, split + 1, "ความถี่: " + (" · ".join(sh["schedules"]) or "-"), al=LW, c2=R, fl=F_SEG)
        ws.row_dimensions[r].height = 26
        # ── หัวตาราง 2 แถว ──
        r += 2
        head_row = r
        for c, t in ((1, "ที่"), (2, "หัวข้อตรวจ"), (3, "เกณฑ์"), (4, "เวลา /\nช่วง")):
            put(ws, r, c, t, f=font(size=9, bold=True), fl=F_HEAD, r2=r + 1)
        for j, dd in enumerate(days):
            put(ws, r, D0 + j, dd["day"], f=font(size=8, bold=True), fl=fill("DBE3FB") if dd["weekend"] else F_HEAD)
            put(ws, r + 1, D0 + j, dd["wd"], f=font(size=6), fl=fill("DBE3FB") if dd["weekend"] else F_SEG)
        ws.row_dimensions[r + 1].height = 11
        r += 2
        # ── หัวข้อ ──
        n, sec = 0, None
        for row in sh["rows"]:
            it = row["it"]
            if it.get("section") and it["section"] != sec:
                sec = it["section"]
                put(ws, r, 1, sec, f=font(bold=True, color="1E3A8A"), fl=F_SEC, al=LW, c2=R)
                r += 1
            n += 1
            label = it["name"] + (f"\n⏱ {row['freq']}" if it.get("check_freq") or (row.get("lines") and len(row["lines"]) > 1)
                                  or row["kind"] in ("week", "month", "period", "half") else "")
            if row["kind"] in ("slots", "free"):
                nl = len(row["lines"])
                put(ws, r, 1, n, r2=r + nl - 1)
                put(ws, r, 2, label, al=LW, r2=r + nl - 1)
                put(ws, r, 3, row["spec"], f=font(size=8), r2=r + nl - 1)
                for li, ln in enumerate(row["lines"]):
                    rr = r + li
                    put(ws, rr, 4, ln["label"] or "วัน", f=font(size=7, color="334155"), fl=F_TM)
                    for j, dd in enumerate(days):
                        a = ln["cells"][j]
                        dn = dd["state"] == "down" or bool((ln.get("down") or [False] * len(days))[j])     # v0.54 รายรอบ
                        fl = (F_NG if a and a["judgement"] == "ng" else F_WARN if a and a["judgement"] == "warn" else
                              None if a else F_DOWN if dn else F_OFF if dd["state"] == "off" else
                              F_WE if dd["weekend"] and dd["state"] != "future" else None)
                        v = cell_text(a, it) if a else ("หยุด" if dn and (li == 0 or ln.get("down")) else "")
                        put(ws, rr, D0 + j, v, f=font(size=8, bold=bool(a and a["judgement"] in ("ng", "warn"))), fl=fl)
                    ws.row_dimensions[rr].height = 14 if nl > 1 else 18
                if nl == 1 and len(label) > 40:
                    ws.row_dimensions[r].height = 26
                r += nl
            else:
                put(ws, r, 1, n)
                put(ws, r, 2, label, al=LW)
                put(ws, r, 3, row["spec"], f=font(size=8))
                put(ws, r, 4, tm_text(row), f=font(size=7, color="334155"), fl=F_TM)
                for sg in row["segs"]:
                    a = sg["ans"]
                    c1 = D0 + sg["start"] - 1
                    txt = f"{cell_text(a, it)} ({sg['at'].day}/{sg['at'].month})" if a else ("" if sg["future"] else "–")
                    fl = F_NG if a and a["judgement"] == "ng" else F_WARN if a and a["judgement"] == "warn" else (None if sg["future"] else F_SEG)
                    put(ws, r, c1, txt, f=font(size=8, bold=bool(a)), fl=fl, c2=c1 + sg["span"] - 1,
                        bd=Border(left=Side(style="medium", color="475569"), right=Side(style="medium", color="475569"), top=thin, bottom=thin))
                ws.row_dimensions[r].height = 26 if len(label) > 40 else 20
                r += 1
        # ── ผู้ตรวจ / ผู้อนุมัติรายวัน ──
        INS = (sh.get("signs") or {}).get("insp") or {}
        if INS.get("segs"):                                  # v0.37 ช่องผู้ตรวจรวมตามช่วง (สัปดาห์ / 2 สัปดาห์ / ครึ่งเดือน / เดือน)
            put(ws, r, 1, LY["row_insp"], f=font(bold=True, size=9), fl=F_SEG, al=LW, c2=3)
            put(ws, r, 4, INS.get("freq_th") or "", f=font(size=7))
            ws.row_dimensions[r].height = 30
            for sg in INS["segs"]:
                c1, c2 = D0 + sg["start"] - 1, D0 + sg["start"] + sg["span"] - 2
                ppl = sg.get("people") or []
                if ppl and all(uid in sigs for uid, _n in ppl):
                    put(ws, r, c1, sg["label"] if sg["span"] > 2 else "", f=font(size=6, color="94A3B8"),
                        al=Alignment(horizontal="left", vertical="top"), c2=c2 if sg["span"] > 1 else None)
                    add_png(compose([sigs[uid]["png"] for uid, _n in ppl], True), c1, r,
                            colpx(c1, c2) if sg["span"] <= 2 else min(colpx(c1, c2) - 20, 70 * len(ppl) + 40), rowpx(r))
                else:
                    txt = sg.get("names") or ""
                    put(ws, r, c1, (sg["label"] + "  " if sg["label"] and not txt else "") + txt,
                        f=font(size=7 if txt else 6, bold=bool(txt), color="142A75" if txt else "94A3B8"),
                        al=Alignment(horizontal="center" if txt else "left", vertical="center" if txt else "top", wrap_text=True),
                        c2=c2 if sg["span"] > 1 else None)
            r += 1
        for shf in INS.get("shifts") or []:                  # v0.42 ผู้ตรวจกะกลางวัน / กะกลางคืน
            put(ws, r, 1, f"{LY['row_insp']} {shf['label']}", f=font(bold=True, size=9), fl=F_SEG, al=LW, c2=3)
            put(ws, r, 4, shf["times"], f=font(size=7))
            ws.row_dimensions[r].height = 46
            for j, people in enumerate(shf.get("cells") or []):
                dn = (shf.get("down") or [None] * (j + 1))[j] if j < len(shf.get("down") or []) else None
                if not people and dn:                          # v0.54 กะที่เครื่องหยุด
                    put(ws, r, D0 + j, "หยุด" + (f"\n⛔{dn['by']}" if dn.get("by") else ""), f=font(size=6, color="475569"), fl=F_DOWN,
                        al=Alignment(horizontal="center", vertical="center", text_rotation=90, wrap_text=True))
                    continue
                if people and all(uid in sigs for uid, _n in people):
                    put(ws, r, D0 + j, "")
                    add_png(compose([sigs[uid]["vpng"] for uid, _n in people], True), D0 + j, r, colpx(D0 + j), rowpx(r))
                else:
                    put(ws, r, D0 + j, "/".join(n for _u, n in people), f=font(size=7),
                        al=Alignment(horizontal="center", vertical="center", text_rotation=90, wrap_text=False))
            r += 1
        for lbl, key, pk in (() if INS.get("segs") or INS.get("shifts") else ((LY["row_insp"], "inspectors", "insp"),)):   # หัวหน้างาน = แถว Sr.Tech ด้านล่าง
            put(ws, r, 1, lbl, f=font(bold=True), fl=F_SEG, al=LW, c2=4)
            ws.row_dimensions[r].height = 52
            for j, dd in enumerate(days):
                people = dd.get(pk) or []
                if people and all(uid in sigs for uid, _n in people):      # ทุกคนมีลายเซ็น → ใช้รูป
                    put(ws, r, D0 + j, "")
                    add_png(compose([sigs[uid]["vpng"] for uid, _n in people], True), D0 + j, r, colpx(D0 + j), rowpx(r))
                else:
                    put(ws, r, D0 + j, dd.get(key) or "", f=font(size=7),
                        al=Alignment(horizontal="center", vertical="center", text_rotation=90, wrap_text=False))
            r += 1
        # ── แถวลงนามเพิ่ม (รายสัปดาห์ / รายเดือน) ──
        for sr in (sh.get("signs") or {}).get("rows") or []:
            put(ws, r, 1, sr["label"], f=font(bold=True, size=9), fl=F_SEG, al=LW, c2=3)
            put(ws, r, 4, sr["freq_th"], f=font(size=7))
            ws.row_dimensions[r].height = 22
            for sg in sr["segs"]:
                so = sg.get("so")
                c1, c2 = D0 + sg["start"] - 1, D0 + sg["start"] + sg["span"] - 2
                if so:                                     # ยืนยันในระบบแล้ว: ลายเซ็น (หรือชื่อ) + วันที่
                    has = so["user_id"] in sigs
                    txt = ("" if has else _short(so.get("user_name") or "") + " ") + th_dt(so["signed_at"], False)
                    put(ws, r, c1, txt if sg["span"] > 2 or not has else "",
                        f=font(size=6.5, color="142A75", bold=not has), al=Alignment(horizontal="right", vertical="bottom"),
                        c2=c2 if sg["span"] > 1 else None)
                    if has:
                        add_png(sigs[so["user_id"]]["png"], c1, r, colpx(c1, c2) if sg["span"] <= 2 else min(colpx(c1, c2) - 30, 110), rowpx(r))
                else:
                    put(ws, r, c1, sg.get("label") or "",
                        f=font(size=6, color="94A3B8"), al=Alignment(horizontal="left", vertical="top"),
                        c2=c2 if sg["span"] > 1 else None)
            r += 1
        last_table_row = r - 1
        # ── สัญลักษณ์ ──
        if LY["show_legend"]:
            put(ws, r, 1, LY["legend"] or ("สัญลักษณ์: ✓ ปกติ · ✗ ไม่ผ่าน · ตัวเลข = ค่าที่วัด · แดง = NG · เหลือง = ช่วงเตือน · แรเงาลาย = ไม่มีรอบตรวจ · "
                          "เทา = เครื่องหยุด/ซ่อม · ช่องรวมฟ้า = ช่วงสัปดาห์/เดือน (– = ไม่ได้ตรวจ) · เวลา = รอบตรวจของบรรทัดนั้น"),
                f=font(size=7.5, color="334155"), al=LW, bd=None, c2=R)
        r += 2
        # ── สรุป + NG ── (ซ่อนได้ในหน้าตั้งค่ารูปแบบใบบันทึก)
        if LY["show_summary"]:
            sm = sh["summary"]
            half = D0 + 3
            put(ws, r, 1, "สรุปผลประจำเดือน", f=font(bold=True, color="FFFFFF"), fl=fill(NAVY), al=LW, c2=3)
            put(ws, r, 4, "รายการผิดปกติและการแก้ไข", f=font(bold=True, color="FFFFFF"), fl=fill(NAVY), al=LW, c2=R)
            stats = [(f"{sm['inspections']} ครั้ง ({sm['days_checked']} วัน)", "ครั้งที่ตรวจ"),
                     (f"{sm['on_time']}/{sm['rounds']}", "รอบตรวจตรงเวลา"),
                     (f"{sm['missed']} · ล่าช้า {sm['late']}", "ขาดตรวจ"),
                     (f"{sm['ng']} · เตือน {sm['warn']}", "หัวข้อ NG"),
                     (f"{sm['approved']}/{sm['inspections']}" + (f" (รอ {sm['pending']})" if sm["pending"] else ""), "อนุมัติในระบบ")]
            ng = sh["ng_list"]
            heads = [("วันที่", 4, half - 1), ("หัวข้อ", half, half + 9), ("ค่า", half + 10, half + 13),
                     ("หมายเหตุ", half + 14, R - 5), ("งานแก้ไข", R - 4, R)]
            for k, c1, c2 in heads:
                put(ws, r + 1, c1, k, f=font(size=8, bold=True), fl=F_SEC, c2=c2)
            rows_needed = max(len(stats), len(ng) or 1)
            for i in range(rows_needed):
                rr = r + 2 + i
                if i < len(stats):
                    put(ws, rr, 1, stats[i][1], f=font(size=8, color="475569"), al=LW, c2=2)
                    put(ws, rr, 3, stats[i][0], f=font(size=9, bold=True,
                        color="B91C1C" if (i in (2, 3) and stats[i][0].split(" ")[0] not in ("0",)) else "111827"))
                if ng and i < len(ng):
                    x = ng[i]
                    vals = [th_dt(x["at"]), x["item"], f"{x['value']} {x['unit']}".strip(), x["remark"],
                            f"{x['capa']['code']} ({x['capa']['status']})" if x["capa"] else "-"]
                    for (k, c1, c2), v in zip(heads, vals):
                        put(ws, rr, c1, v, f=font(size=8, bold=(k == "ค่า"), color=("B91C1C" if k == "ค่า" and x["judgement"] == "ng" else "111827")),
                            al=LW if k in ("หัวข้อ", "หมายเหตุ") else C, c2=c2)
                elif i == 0:
                    put(ws, rr, 4, "ไม่พบรายการผิดปกติในเดือนนี้", f=font(size=9, color="15803D"), al=LW, c2=R)
            r += 2 + rows_needed + 1
        # ── ช่องลงนาม ──
        acc, half_w, sp = 0.0, (sum(widths.values()) + 4.4 * ND) / 2, D0
        for cc in range(1, R + 1):
            acc += widths.get(cc, 4.4)
            if acc >= half_w:
                sp = max(3, cc)
                break
        halves = [(1, sp), (sp + 1, R)]
        from .signoffs import POSITIONS
        ms = (sh.get("signs") or {}).get("month") or {}
        util = bool((sh.get("signs") or {}).get("util"))                  # กล่อง Utility มุมขวาบนแทนช่องท้ายเอกสาร
        sbd = Border(left=med, right=med, top=med, bottom=med)
        if not util:
            ws.row_dimensions[r + 1].height = 34
        for (c1, c2), (role, so) in zip(halves, () if util else ((LY["sign_insp"], ms.get("insp")), (LY["sign_sup"], ms.get("sup")))):
            who = ((so.get("user_name") or "") + (f" ({POSITIONS.get(so.get('user_pos'), so.get('user_pos'))})" if so.get("user_pos") else "")
                   + " · วันที่ " + th_dt(so["signed_at"], False)) if so else "(................................) วันที่ ....../....../......"
            put(ws, r, c1, role, f=font(bold=True, color=NAVY), c2=c2, bd=sbd)
            put(ws, r + 1, c1, "", c2=c2, bd=Border(left=med, right=med, bottom=dot))
            put(ws, r + 2, c1, who, f=font(size=8, color="334155"), c2=c2, bd=Border(left=med, right=med, bottom=med))
            if so and sigs.get(so["user_id"]):
                add_png(sigs[so["user_id"]]["png"], c1, r + 1, colpx(c1, c2), rowpx(r + 1))
        if not util:
            ws.row_dimensions[r + 1].height = 30
            r += 4
        # ── เลขที่เอกสาร มุมซ้ายล่าง (v0.24) · ข้อความออกจากระบบ + รหัสตรวจสอบ ด้านขวา ──
        meta += [("หน้า", "1 / 1")]
        mb = Border(left=thin, right=thin, top=thin, bottom=thin)
        pairs = [meta[i:i + 2] for i in range(0, len(meta), 2)]
        # คู่ที่ 1: A–B (ชื่อ) C–D (ค่า) · คู่ที่ 2: 3 คอลัมน์วันที่ (ชื่อ) + 6 คอลัมน์ (ค่า)
        slots = [(1, 2, 3, 4), (D0, D0 + 2, D0 + 3, D0 + 8)]
        for i, pr in enumerate(pairs):
            for (k, v), (k1, k2, v1, v2) in zip(pr + [("", "")] * (2 - len(pr)), slots):
                bold = k.startswith("เลขที่")
                put(ws, r + i, k1, k, f=font(size=7.5, color="475569"), fl=F_SEG, al=LW, bd=mb, c2=k2)
                put(ws, r + i, v1, v, f=font(size=8.5, bold=bold), al=LW, bd=mb, c2=v2)
            ws.row_dimensions[r + i].height = 15
        put(ws, r, D0 + 10, f"ออกจากระบบ E-Checksheet เมื่อ {th_dt(sh['printed_at'])}" + (f" โดย {sh['printed_by']}" if sh.get("printed_by") else "")
            + "\n" + LY["footer_note"], f=font(size=7.5, color="475569"), al=LW, bd=None, r2=r + 1, c2=R - 9)
        put(ws, r, R - 8, f"รหัสตรวจสอบ {sh['verify']}", f=Font(name="Consolas", size=10, bold=True, color=NAVY),
            al=Alignment(horizontal="right", vertical="center"), bd=None, c2=R)
        r += len(pairs) - 1
        # โลโก้ AISIN มุมขวาล่าง
        r += 1
        ws.row_dimensions[r].height = 24
        if LY["show_logo"]:
            add_img(logo_path, f"{L(max(D0, R - 4))}{r}", 30)
        r += 1
        put(ws, r, max(D0, R - 8), LY["brand_tag"] if LY["show_logo"] else "", f=font(size=6.5, bold=True, color=NAVY),
            al=Alignment(horizontal="right", vertical="center"), bd=None, c2=R)
        # ── ตั้งค่าหน้ากระดาษให้เหมือน PDF: A4 แนวนอน พอดีความกว้าง หัวตารางซ้ำทุกหน้า ──
        ws.freeze_panes = f"{L(D0)}{head_row + 2}"
        ws.print_title_rows = f"{head_row}:{head_row + 1}"
        ws.print_area = f"A1:{L(R)}{r}"
        ws.page_setup.orientation = "landscape"
        ws.page_setup.paperSize = ws.PAPERSIZE_A4
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 1 if r <= 90 else 0          # เหมือน PDF: พอดี 1 หน้า (ถ้าหัวข้อยาวมากจึงขึ้นหน้าใหม่)
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.print_options.horizontalCentered = True
        ws.page_margins.left = ws.page_margins.right = 0.3
        ws.page_margins.top = ws.page_margins.bottom = 0.35
        ws.oddFooter.center.text = "หน้า &P / &N"
        ws.oddFooter.right.text = sh["doc_no"]
        _ = last_table_row
    if not wb.worksheets:
        wb.create_sheet("ว่าง")
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
