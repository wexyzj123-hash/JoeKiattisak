"""ecs/analytics.py — Phase 3: ข้อมูลสำหรับ Dashboard และกราฟ

cs_daily_stats = ตารางสรุปรายวันต่อแบบฟอร์ม (อัปเดตโดยงานเบื้องหลัง) ทำให้ Dashboard เร็วแม้ข้อมูลหลายล้านแถว
"""
from __future__ import annotations

import json
from datetime import date, datetime, time, timedelta
from typing import Any

from . import anomaly as A
from . import services as S
from .services import ts

GOOD_RATE, WARN_RATE = 95.0, 80.0          # เกณฑ์สีของอัตราตรวจตรงเวลา (ปรับได้ที่นี่)
STATS_REV = "41"                           # v0.41 นับเฉพาะแบบฟอร์มที่มีรอบตรวจเปิดใช้งาน


def rate_status(rate: float | None) -> str:
    if rate is None:
        return "none"
    return "good" if rate >= GOOD_RATE else ("warning" if rate >= WARN_RATE else "critical")


# ───────────────────────── aggregation ─────────────────────────

def refresh_daily_stats(db, day_from: date, day_to: date) -> int:
    """คำนวณ cs_daily_stats ใหม่สำหรับช่วงวันที่ (ทำซ้ำได้) — นับรอบตามวันที่เริ่มตรวจ"""
    start, end = ts(datetime.combine(day_from, time(0, 0))), ts(datetime.combine(day_to + timedelta(days=1), time(0, 0)))
    db.execute("DELETE FROM cs_daily_stats WHERE stat_date >= ? AND stat_date <= ?",
               (day_from.isoformat(), day_to.isoformat()))
    db.execute(f"""
        INSERT INTO cs_daily_stats(stat_date, form_id, due, done_on_time, done_late, missed, ng)
        SELECT substr(r.due_at, 1, 10), r.form_id, SUM(r.status<>'skipped'),
               SUM(r.status='done_on_time'), SUM(r.status='done_late'), SUM(r.status='missed'),
               COALESCE(SUM(sb.ng_count), 0)
        FROM cs_rounds r LEFT JOIN cs_submissions sb ON sb.id=r.submission_id
        WHERE r.due_at >= ? AND r.due_at < ? AND {S.scheduled_sql()}
        GROUP BY substr(r.due_at, 1, 10), r.form_id""", (start, end))
    return db.execute("SELECT changes()").fetchone()[0]


def refresh_form_stats(db, form_ids) -> int:
    """v0.41 คำนวณสถิติรายวันของแบบฟอร์มใหม่ทั้งหมด (ทุกวันที่) — หลังแก้/ปิดรอบตรวจ หรือคำนวณรอบใหม่
    แบบฟอร์มที่ไม่มีรอบตรวจเปิดใช้งานแล้ว → ไม่มีแถวในสถิติ"""
    ids = sorted({int(x) for x in form_ids if x})
    n = 0
    for i in range(0, len(ids), 400):
        part = ids[i:i + 400]
        ph = ",".join("?" * len(part))
        db.execute(f"DELETE FROM cs_daily_stats WHERE form_id IN ({ph})", part)
        db.execute(f"""
            INSERT INTO cs_daily_stats(stat_date, form_id, due, done_on_time, done_late, missed, ng)
            SELECT substr(r.due_at, 1, 10), r.form_id, SUM(r.status<>'skipped'),
                   SUM(r.status='done_on_time'), SUM(r.status='done_late'), SUM(r.status='missed'),
                   COALESCE(SUM(sb.ng_count), 0)
            FROM cs_rounds r LEFT JOIN cs_submissions sb ON sb.id=r.submission_id
            WHERE r.form_id IN ({ph}) AND {S.scheduled_sql()}
            GROUP BY substr(r.due_at, 1, 10), r.form_id""", part)
        n += db.execute("SELECT changes()").fetchone()[0]
    return n


def ensure_stats(db, day_from: date, day_to: date) -> None:
    """เติมวันที่ยังไม่มีในตารางสรุป + คำนวณ 2 วันล่าสุดใหม่เสมอ (สถานะยังเปลี่ยนได้)"""
    today = date.today()
    rev = db.execute("SELECT value FROM cs_meta WHERE key='stats_rev'").fetchone()
    if not rev or rev[0] != STATS_REV:              # v0.41 เกณฑ์นับเปลี่ยน → คำนวณตารางสรุปเก่าใหม่ทั้งหมด
        db.execute("DELETE FROM cs_daily_stats")
        db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('stats_rev', ?)", (STATS_REV,))
    recent_from = max(day_from, today - timedelta(days=1))
    if recent_from <= day_to:
        refresh_daily_stats(db, recent_from, day_to)
    have = {r[0] for r in db.execute("SELECT DISTINCT stat_date FROM cs_daily_stats WHERE stat_date >= ? AND stat_date < ?",
                                     (day_from.isoformat(), recent_from.isoformat()))}
    missing = [day_from + timedelta(days=i) for i in range((recent_from - day_from).days)
               if (day_from + timedelta(days=i)).isoformat() not in have]
    if missing:
        refresh_daily_stats(db, missing[0], missing[-1])


# ───────────────────────── dashboard ─────────────────────────

def _fac(factory_id, alias="f") -> tuple[str, list]:
    return (f" AND {alias}.factory_id=?", [factory_id]) if factory_id else ("", [])


def overview(db, day_from: date, day_to: date, factory_id: int | None = None) -> dict:
    ensure_stats(db, day_from, day_to)
    fc, fp = _fac(factory_id)
    rng = [day_from.isoformat(), day_to.isoformat()]
    tot = db.execute(f"""SELECT COALESCE(SUM(d.due),0) due, COALESCE(SUM(d.done_on_time),0) on_time,
                                COALESCE(SUM(d.done_late),0) late, COALESCE(SUM(d.missed),0) missed, COALESCE(SUM(d.ng),0) ng
                         FROM cs_daily_stats d JOIN cs_forms f ON f.id=d.form_id
                         WHERE d.stat_date BETWEEN ? AND ? {fc}""", rng + fp).fetchone()
    closed = tot["on_time"] + tot["late"] + tot["missed"]
    today = date.today()
    now_s = ts()
    open_now = db.execute(f"""SELECT SUM(r.status IN ('pending','in_progress')) pending, SUM(r.status='overdue') overdue,
                                     SUM(r.status='returned') returned
                              FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id
                              WHERE r.due_at <= ? AND r.close_at > ? AND {S.scheduled_sql()} {fc}""", [now_s, now_s] + fp).fetchone()
    pend = db.execute(f"""SELECT COUNT(*) FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
                          WHERE s.approval_status='pending' AND s.status='submitted' {fc}""", fp).fetchone()[0]
    rate = round(100.0 * tot["on_time"] / closed, 1) if closed else None
    # รายโรงงาน
    per_factory = []
    for r in db.execute(f"""SELECT fa.id, fa.name, COALESCE(SUM(d.due),0) due, COALESCE(SUM(d.done_on_time),0) on_time,
                                   COALESCE(SUM(d.done_late),0) late, COALESCE(SUM(d.missed),0) missed, COALESCE(SUM(d.ng),0) ng
                            FROM factories fa LEFT JOIN cs_forms f ON f.factory_id=fa.id
                            LEFT JOIN cs_daily_stats d ON d.form_id=f.id AND d.stat_date BETWEEN ? AND ?
                            WHERE fa.active=1 {'AND fa.id=?' if factory_id else ''}
                            GROUP BY fa.id ORDER BY fa.sort_no""", rng + fp):
        c = r["on_time"] + r["late"] + r["missed"]
        fr = round(100.0 * r["on_time"] / c, 1) if c else None
        per_factory.append({**dict(r), "rate": fr, "status": rate_status(fr),
                            "alerts": A.open_alert_counts(db, r["id"])})
    return {
        "from": day_from.isoformat(), "to": day_to.isoformat(), "today": today.isoformat(),
        "due": tot["due"], "on_time": tot["on_time"], "late": tot["late"], "missed": tot["missed"], "ng": tot["ng"],
        "rate": rate, "rate_status": rate_status(rate),
        "pending_now": open_now["pending"] or 0, "overdue_now": open_now["overdue"] or 0,
        "returned_now": open_now["returned"] or 0, "pending_approval": pend,
        "alerts": A.open_alert_counts(db, factory_id), "factories": per_factory,
    }


def compliance_trend(db, day_from: date, day_to: date, factory_id: int | None = None) -> dict:
    """อัตราตรวจตรงเวลารายวัน แยกโรงงาน (เส้นละโรงงาน ไม่เกิน 3 เส้น + รวม)"""
    ensure_stats(db, day_from, day_to)
    days = [(day_from + timedelta(days=i)).isoformat() for i in range((day_to - day_from).days + 1)]
    fc, fp = (" AND fa.id=?", [factory_id]) if factory_id else ("", [])
    rows = db.execute(f"""SELECT d.stat_date, fa.id AS fid, fa.name AS fname,
                                 SUM(d.done_on_time) ot, SUM(d.done_on_time + d.done_late + d.missed) closed
                          FROM cs_daily_stats d JOIN cs_forms f ON f.id=d.form_id JOIN factories fa ON fa.id=f.factory_id
                          WHERE d.stat_date BETWEEN ? AND ? {fc}
                          GROUP BY d.stat_date, fa.id""", [days[0], days[-1]] + fp).fetchall()
    series: dict[int, dict] = {}
    for f in db.execute(f"SELECT id, name FROM factories fa WHERE active=1 {fc} ORDER BY sort_no", fp):
        series[f["id"]] = {"id": f["id"], "name": f["name"], "values": {d: None for d in days}}
    for r in rows:
        if r["fid"] in series and r["closed"]:
            series[r["fid"]]["values"][r["stat_date"]] = round(100.0 * r["ot"] / r["closed"], 1)
    return {"days": days, "series": [{"id": s["id"], "name": s["name"], "data": [s["values"][d] for d in days]}
                                     for s in series.values()], "good": GOOD_RATE, "warn": WARN_RATE}


def heatmap(db, day_from: date, day_to: date, factory_id: int | None = None) -> dict:
    """อัตราตรวจตรงเวลา: แถว = พื้นที่ (โรงงาน › พื้นที่), คอลัมน์ = วัน"""
    ensure_stats(db, day_from, day_to)
    days = [(day_from + timedelta(days=i)).isoformat() for i in range((day_to - day_from).days + 1)]
    fc, fp = _fac(factory_id)
    rows = db.execute(f"""
        SELECT d.stat_date, COALESCE(fa.name, '-') AS fname, COALESCE(ar.name, 'ไม่ระบุพื้นที่') AS aname,
               COALESCE(fa.sort_no, 99) so, SUM(d.done_on_time) ot, SUM(d.done_late) late, SUM(d.missed) missed,
               SUM(d.due) due
        FROM cs_daily_stats d JOIN cs_forms f ON f.id=d.form_id
        LEFT JOIN factories fa ON fa.id=f.factory_id LEFT JOIN areas ar ON ar.id=f.area_id
        WHERE d.stat_date BETWEEN ? AND ? {fc}
        GROUP BY d.stat_date, fname, aname ORDER BY so, fname, aname""", [days[0], days[-1]] + fp).fetchall()
    rows_idx: dict[str, int] = {}
    labels: list[str] = []
    cells = []
    for r in rows:
        label = f"{r['fname']} › {r['aname']}"
        if label not in rows_idx:
            rows_idx[label] = len(labels)
            labels.append(label)
        closed = r["ot"] + r["late"] + r["missed"]
        rate = round(100.0 * r["ot"] / closed, 1) if closed else None
        cells.append({"x": days.index(r["stat_date"]), "y": rows_idx[label], "rate": rate, "status": rate_status(rate),
                      "on_time": r["ot"], "late": r["late"], "missed": r["missed"], "due": r["due"]})
    return {"days": days, "rows": labels, "cells": cells, "good": GOOD_RATE, "warn": WARN_RATE}


def ng_pareto(db, day_from: date, day_to: date, factory_id: int | None = None, limit: int = 10) -> dict:
    """หัวข้อที่พบ NG บ่อยที่สุด (Pareto) + % สะสม"""
    fc, fp = _fac(factory_id)
    start, end = f"{day_from.isoformat()} 00:00:00", f"{day_to.isoformat()} 23:59:59"
    rows = db.execute(f"""
        SELECT a.item_key, s.form_id, MAX(i.name) AS item_name, MAX(f.name) AS form_name, MAX(e.code) AS eq_code,
               COUNT(*) AS ng
        FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id JOIN cs_form_items i ON i.id=a.item_id
        JOIN cs_forms f ON f.id=s.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
        WHERE a.judgement='ng' AND s.status<>'superseded' AND s.finished_at BETWEEN ? AND ? {fc}
        GROUP BY s.form_id, a.item_key ORDER BY ng DESC""", [start, end] + fp).fetchall()
    total = sum(r["ng"] for r in rows)
    out, cum = [], 0
    for r in rows[:limit]:
        cum += r["ng"]
        out.append({"form_id": r["form_id"], "item_key": r["item_key"], "ng": r["ng"],
                    "label": f"{r['item_name']} · {r['eq_code'] or r['form_name']}",
                    "cum_pct": round(100.0 * cum / total, 1) if total else 0})
    other = total - cum
    return {"items": out, "total": total, "other": other}


# ───────────────────────── trend ─────────────────────────

def numeric_items(db, form_id: int) -> list[dict]:
    form = S.get_form(db, form_id)
    if not form or not form["current_version_id"]:
        return []
    return [i for i in S.get_items(db, form["current_version_id"]) if i["item_type"] in ("number", "counter", "calc")]


def item_series(db, form_id: int, item_key: str, day_from: date, day_to: date) -> dict:
    """ค่าของหัวข้อตัวเลข + เส้นเกณฑ์ + ขอบควบคุม + จุดที่ผิดกฎ SPC"""
    form = S.get_form(db, form_id)
    item = next((i for i in numeric_items(db, form_id) if i["item_key"] == item_key), None)
    if not form or not item:
        raise S.ValidationError("ไม่พบหัวข้อตัวเลขนี้ในแบบฟอร์ม")
    rules = A.get_rules(db)
    start = f"{day_from.isoformat()} 00:00:00"
    end = f"{day_to.isoformat()} 23:59:59"
    # ประวัติก่อนช่วงที่ดู ใช้เป็นฐานคำนวณของจุดแรกๆ
    pre = A.item_history(db, form_id, item_key, until=start, limit=int(rules["spc_sigma"]["window"]) + 10)
    pts = A.item_history(db, form_id, item_key, since=start, until=end, limit=5000)
    k = float(rules["spc_sigma"]["k"])
    window, min_pts = int(rules["spc_sigma"]["window"]), int(rules["spc_sigma"]["min_points"])
    # ขอบควบคุม (UCL/LCL) ของกราฟ: ใช้ N จุดก่อนช่วงที่ดูเป็นฐาน ถ้ามีไม่พอใช้ N จุดแรกของช่วง
    pre_vals = [p["v"] for p in pre][-window:]
    base_vals = pre_vals if len(pre_vals) >= min_pts else [p["v"] for p in pts][:window]
    limits = A.control_limits(base_vals, k)
    if limits:
        limits["basis"] = "ก่อนช่วงที่ดู" if base_vals is pre_vals else "จุดแรกของช่วงที่ดู"
    history = list(pre)
    points = []
    for p in pts:
        flags = [t for t, _ in A.check_numeric(item, history, p, rules)]
        points.append({"t": ts(p["t"]), "v": p["v"], "judgement": p["judgement"], "sub_id": p["sub_id"],
                       "inspector": p["inspector"], "remark": p["remark"], "flags": flags})
        history.append(p)
    vals = [p["v"] for p in points]
    stats = None
    if vals:
        stats = {"n": len(vals), "min": min(vals), "max": max(vals), "mean": round(sum(vals) / len(vals), 4),
                 "last": vals[-1], "ng": sum(1 for p in points if p["judgement"] == "ng"),
                 "warn": sum(1 for p in points if p["judgement"] == "warn"),
                 "flagged": sum(1 for p in points if p["flags"])}
        if len(vals) >= 2 and item.get("min_value") is not None and item.get("max_value") is not None and limits and limits["sd"] > 0:
            # Cpk: ความสามารถของกระบวนการเทียบเกณฑ์ (≥1.33 ดี)
            m, sd = limits["mean"], limits["sd"]
            stats["cpk"] = round(min(item["max_value"] - m, m - item["min_value"]) / (3 * sd), 2)
    return {
        "form": {"id": form["id"], "name": form["name"], "eq_code": form["eq_code"]},
        "item": {k2: item[k2] for k2 in ("item_key", "name", "item_type", "unit", "min_value", "max_value",
                                         "warn_low", "warn_high")},
        "points": points, "limits": limits, "k": k, "stats": stats,
        "rules": {k2: v["enabled"] for k2, v in rules.items()},
    }


def equipment_summary(db, equipment_id: int, days: int = 30) -> list[dict]:
    """หัวข้อตัวเลขของทุกแบบฟอร์มของเครื่อง + ค่าล่าสุด + ค่า 30 วันสำหรับ sparkline"""
    since = f"{(date.today() - timedelta(days=days)).isoformat()} 00:00:00"
    out = []
    for f in db.execute("SELECT id, name FROM cs_forms WHERE equipment_id=? AND active=1", (equipment_id,)):
        for it in numeric_items(db, f["id"]):
            hist = A.item_history(db, f["id"], it["item_key"], since=since, limit=200)
            if not hist:
                continue
            last = hist[-1]
            out.append({"form_id": f["id"], "form_name": f["name"], "item_key": it["item_key"], "name": it["name"],
                        "unit": it["unit"], "min_value": it["min_value"], "max_value": it["max_value"],
                        "last": last["v"], "last_at": ts(last["t"]), "judgement": last["judgement"],
                        "values": [h["v"] for h in hist]})
    return out


def parse_range(args: Any, default_days: int = 30) -> tuple[date, date, int]:
    """อ่านช่วงวันที่จาก query string: days=7/30/90 หรือ from/to"""
    today = date.today()
    try:
        days = int(args.get("days") or default_days)
    except ValueError:
        days = default_days
    days = max(1, min(days, 366))
    try:
        d_to = date.fromisoformat(args.get("to")) if args.get("to") else today
        d_from = date.fromisoformat(args.get("from")) if args.get("from") else d_to - timedelta(days=days - 1)
    except ValueError:
        d_to, d_from = today, today - timedelta(days=days - 1)
    if d_from > d_to:
        d_from, d_to = d_to, d_from
    if (d_to - d_from).days > 366:
        d_from = d_to - timedelta(days=366)
    return d_from, d_to, (d_to - d_from).days + 1


# ───────────────────────── operational dashboard (วันนี้) ─────────────────────────

AREA_STATUS_TH = {"good": "ปกติ", "warning": "ต้องติดตาม", "critical": "เร่งแก้ไข", "none": "ไม่มีรอบตรวจ"}


def _day_bounds(day: date) -> tuple[str, str]:
    return f"{day.isoformat()} 00:00:00", f"{day.isoformat()} 23:59:59"


def _pct_change(now_v, prev_v) -> float | None:
    if now_v is None or prev_v in (None, 0):
        return None
    return round(100.0 * (now_v - prev_v) / prev_v, 1)


def results_of_day(db, day: date, factory_id: int | None = None) -> dict:
    """ผลตรวจที่ส่งในวันนั้น: จำนวนครั้ง, หัวข้อ OK/เตือน/NG, เวลาตรวจเฉลี่ย, จำนวนรายชั่วโมง"""
    fc, fp = _fac(factory_id)
    start, end = _day_bounds(day)
    sub = db.execute(f"""SELECT COUNT(*) n, AVG(CASE WHEN s.duration_sec > 0 THEN s.duration_sec END) avg_sec,
                                COUNT(DISTINCT s.inspector_id) inspectors
                         FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
                         WHERE s.status<>'superseded' AND s.source<>'auto' AND s.finished_at BETWEEN ? AND ? {fc}""",
                     [start, end] + fp).fetchone()
    ans = db.execute(f"""SELECT SUM(a.judgement='ok') ok, SUM(a.judgement='warn') warn, SUM(a.judgement='ng') ng
                         FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id JOIN cs_forms f ON f.id=s.form_id
                         WHERE s.status<>'superseded' AND s.source<>'auto' AND s.finished_at BETWEEN ? AND ? {fc}""",
                     [start, end] + fp).fetchone()
    hourly = [0] * 24
    for r in db.execute(f"""SELECT CAST(substr(s.finished_at, 12, 2) AS INTEGER) h, COUNT(*) n
                            FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
                            WHERE s.status<>'superseded' AND s.source<>'auto' AND s.finished_at BETWEEN ? AND ? {fc} GROUP BY h""",
                        [start, end] + fp):
        if r["h"] is not None and 0 <= r["h"] < 24:
            hourly[r["h"]] = r["n"]
    ok, warn, ng = ans["ok"] or 0, ans["warn"] or 0, ans["ng"] or 0
    judged = ok + warn + ng
    return {"submissions": sub["n"], "avg_sec": round(sub["avg_sec"]) if sub["avg_sec"] else None,
            "inspectors": sub["inspectors"], "item_count": judged, "ok": ok, "warn": warn, "ng": ng,
            "pass_rate": round(100.0 * (ok + warn) / judged, 1) if judged else None, "hourly": hourly}


def equipment_counts(db, factory_id: int | None = None) -> dict:
    cond, params = ("WHERE factory_id=?", [factory_id]) if factory_id else ("", [])
    r = db.execute(f"SELECT SUM(active=1) active, SUM(active=0) inactive FROM equipment {cond}", params).fetchone()
    return {"active": r["active"] or 0, "inactive": r["inactive"] or 0}


def today_summary(db, day: date, factory_id: int | None = None, period_days: int = 30) -> dict:
    """ตัวเลขหลักแถวบนของ Dashboard + เทียบเมื่อวาน/ช่วงก่อนหน้า"""
    rounds = S.rounds_overview(db, day, factory_id)
    c = rounds["counts"]
    res = results_of_day(db, day, factory_id)
    res_prev = results_of_day(db, day - timedelta(days=1), factory_id)
    p_from = day - timedelta(days=period_days - 1)
    ov = overview(db, p_from, day, factory_id)
    prev = overview(db, p_from - timedelta(days=period_days), p_from - timedelta(days=1), factory_id)
    alerts = A.open_alert_counts(db, factory_id)
    return {
        "date": day.isoformat(),
        "equipment": equipment_counts(db, factory_id),
        "rounds_total": rounds["total"], "rounds_done": rounds["done"],
        "rounds_pct": round(100.0 * rounds["done"] / rounds["total"]) if rounds["total"] else None,
        "rounds_pending": c["pending"] + c["in_progress"], "rounds_overdue": c["overdue"], "rounds_missed": c["missed"],
        "rounds_returned": c["returned"], "rounds_late": c["done_late"], "rounds_skipped": c.get("skipped", 0),
        "results": res, "results_prev": res_prev,
        "submissions_change": _pct_change(res["submissions"], res_prev["submissions"]),
        "avg_sec_change": _pct_change(res["avg_sec"], res_prev["avg_sec"]),
        "alerts": alerts, "to_fix": alerts["critical"] + alerts["warning"],
        "period_days": period_days, "period_rate": ov["rate"], "period_rate_status": ov["rate_status"],
        "period_rate_prev": prev["rate"],
        "period_rate_delta": round(ov["rate"] - prev["rate"], 1) if ov["rate"] is not None and prev["rate"] is not None else None,
        "pending_approval": ov["pending_approval"],
    }


def area_status(db, day: date, factory_id: int | None = None) -> list[dict]:
    """สถานะรายพื้นที่ของวันนั้น (ใช้กับตารางและหมุดบนผังโรงงาน)"""
    start, end = _day_bounds(day)
    fc, fp = (" AND fa.id=?", [factory_id]) if factory_id else ("", [])
    areas = db.execute(f"""SELECT ar.id, ar.name, ar.map_x, ar.map_y, ar.layout_image, fa.id AS factory_id, fa.name AS factory_name,
                                  fa.code AS factory_code,
                                  (SELECT COUNT(*) FROM equipment e WHERE e.area_id=ar.id AND e.active=1) AS eq_count,
                                  (SELECT COUNT(*) FROM equipment e WHERE e.area_id=ar.id AND e.active=1
                                     AND e.run_status='down') AS down_count
                           FROM areas ar JOIN factories fa ON fa.id=ar.factory_id
                           WHERE ar.active=1 AND fa.active=1 {fc}
                           ORDER BY fa.sort_no, ar.name""", fp).fetchall()
    # พื้นที่ของแบบฟอร์ม = พื้นที่ของเครื่องจักร (ถ้าผูกเครื่อง) ไม่งั้นใช้พื้นที่ที่ระบุในแบบฟอร์ม
    area_of_form = "COALESCE((SELECT e.area_id FROM equipment e WHERE e.id=f.equipment_id), f.area_id)"
    rounds = {r["aid"]: r for r in db.execute(f"""
        SELECT {area_of_form} AS aid, SUM(r.status<>'skipped') total, SUM(r.status IN ('done_on_time','done_late')) done,
               SUM(r.status='missed') missed, SUM(r.status='overdue') overdue,
               SUM(r.status IN ('pending','in_progress')) pending
        FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id
        WHERE r.due_at BETWEEN ? AND ? AND {S.scheduled_sql()} GROUP BY aid""", (start, end))}
    ngs = {r["aid"]: r for r in db.execute(f"""
        SELECT {area_of_form} AS aid, SUM(s.ng_count) ng, SUM(s.warn_count) warn
        FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
        WHERE s.status<>'superseded' AND s.finished_at BETWEEN ? AND ? GROUP BY aid""", (start, end))}
    alerts = {r["aid"]: r for r in db.execute(f"""
        SELECT {area_of_form} AS aid, SUM(a.severity='critical') critical, SUM(a.severity='warning') warning,
               SUM(a.severity='info') info
        FROM cs_alerts a JOIN cs_forms f ON f.id=a.form_id
        WHERE a.alert_type<>'approval' AND a.status IN ({','.join('?' * len(A.OPEN_STATUSES))}) GROUP BY aid""", A.OPEN_STATUSES)}
    out = []
    for a in areas:
        r, n, al = rounds.get(a["id"]), ngs.get(a["id"]), alerts.get(a["id"])
        total = (r["total"] or 0) if r else 0
        done = (r["done"] or 0) if r else 0
        missed = (r["missed"] or 0) if r else 0
        overdue = (r["overdue"] or 0) if r else 0
        ng = (n["ng"] or 0) if n else 0
        crit = (al["critical"] or 0) if al else 0
        warn_al = (al["warning"] or 0) if al else 0
        if crit or missed:
            status = "critical"
        elif overdue or ng or warn_al:
            status = "warning"
        elif total or a["eq_count"]:
            status = "good"
        else:
            status = "none"
        reasons = []
        if crit:
            reasons.append(f"แจ้งเตือนวิกฤต {crit}")
        if missed:
            reasons.append(f"ขาดตรวจ {missed}")
        if overdue:
            reasons.append(f"เลยกำหนด {overdue}")
        if ng:
            reasons.append(f"NG {ng}")
        if warn_al:
            reasons.append(f"แจ้งเตือน {warn_al}")
        if a["down_count"]:
            reasons.append(f"เครื่องหยุด {a['down_count']}")
        out.append({**dict(a), "rounds": total, "done": done, "missed": missed, "overdue": overdue,
                    "pending": ((r["pending"] or 0) if r else 0), "ng": ng,
                    "done_pct": round(100.0 * done / total) if total else None,
                    "alerts_open": crit + warn_al + ((al["info"] or 0) if al else 0),
                    "status": status, "status_th": AREA_STATUS_TH[status], "reason": " · ".join(reasons)})
    return out


def get_dash_items(db) -> list[dict]:
    row = db.execute("SELECT value FROM cs_meta WHERE key='dash_items'").fetchone()
    try:
        return [x for x in json.loads(row[0]) if isinstance(x, dict)] if row and row[0] else []
    except ValueError:
        return []


def save_dash_items(db, items: list[dict], actor_id) -> list[dict]:
    clean = []
    for x in items[:8]:
        try:
            fid, key = int(x["form_id"]), str(x["item_key"])
        except (KeyError, TypeError, ValueError):
            continue
        if any(i["item_key"] == key for i in numeric_items(db, fid)) and {"form_id": fid, "item_key": key} not in clean:
            clean.append({"form_id": fid, "item_key": key})
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('dash_items', ?)", (json.dumps(clean),))
    S.audit(db, actor_id, "update", "dash_items", None, after=clean)
    return clean


def candidate_items(db, factory_id: int | None = None) -> list[dict]:
    """หัวข้อตัวเลขของแบบฟอร์มที่ใช้งาน (สำหรับเลือกแสดงบน Dashboard)"""
    fc, fp = _fac(factory_id)
    rows = db.execute(f"""
        SELECT f.id AS form_id, f.name AS form_name, e.code AS eq_code, fa.name AS factory_name, fa.id AS factory_id,
               i.item_key, i.name, i.unit, i.min_value, i.max_value, i.warn_low, i.warn_high, i.item_type
        FROM cs_forms f JOIN cs_form_items i ON i.version_id=f.current_version_id
        LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN factories fa ON fa.id=f.factory_id
        WHERE f.active=1 AND f.is_template=0 AND i.item_type='number' {fc}
        ORDER BY COALESCE(fa.sort_no, 99), e.code, f.name, i.order_no""", fp).fetchall()
    return [dict(r) for r in rows]


def key_items(db, day: date, factory_id: int | None = None, limit: int = 5, days: int = 7) -> list[dict]:
    """หัวข้อสำคัญที่แสดงบน Dashboard: ที่ผู้ดูแลเลือกไว้ หรือเลือกอัตโนมัติ (มีแจ้งเตือนค้าง/ตรวจบ่อย/มีเกณฑ์)"""
    cands = candidate_items(db, factory_id)
    by_key = {(c["form_id"], c["item_key"]): c for c in cands}
    chosen = [by_key[(x["form_id"], x["item_key"])] for x in get_dash_items(db) if (x["form_id"], x["item_key"]) in by_key]
    since = f"{(day - timedelta(days=days - 1)).isoformat()} 00:00:00"
    end = f"{day.isoformat()} 23:59:59"
    if not chosen:
        alerts = {(r[0], r[1]): r[2] for r in db.execute(
            f"""SELECT form_id, item_key, COUNT(*) FROM cs_alerts WHERE status IN ({','.join('?' * len(A.OPEN_STATUSES))})
                AND item_key IS NOT NULL GROUP BY form_id, item_key""", A.OPEN_STATUSES)}
        counts = {(r[0], r[1]): r[2] for r in db.execute(
            """SELECT s.form_id, a.item_key, COUNT(*) FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
               WHERE s.status<>'superseded' AND a.value_num IS NOT NULL AND s.finished_at BETWEEN ? AND ?
               GROUP BY s.form_id, a.item_key""", (since, end))}
        scored = []
        for c in cands:
            k = (c["form_id"], c["item_key"])
            if not counts.get(k):
                continue
            has_limit = c["min_value"] is not None or c["max_value"] is not None
            scored.append((alerts.get(k, 0) * 100 + (20 if has_limit else 0) + min(counts[k], 50), c))
        scored.sort(key=lambda x: -x[0])
        # ไม่เอาหัวข้อชื่อซ้ำกันเกิน 2 เพื่อให้เห็นหลากหลาย
        seen: dict[str, int] = {}
        for _s, c in scored:
            if seen.get(c["name"], 0) >= 2:
                continue
            seen[c["name"]] = seen.get(c["name"], 0) + 1
            chosen.append(c)
            if len(chosen) >= limit:
                break
    out = []
    day_list = [(day - timedelta(days=days - 1 - i)).isoformat() for i in range(days)]
    for c in chosen[:limit]:
        rows = db.execute("""SELECT substr(s.finished_at, 1, 10) d, AVG(a.value_num) avg, MIN(a.value_num) mn, MAX(a.value_num) mx
                             FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
                             WHERE s.form_id=? AND a.item_key=? AND s.status<>'superseded' AND a.value_num IS NOT NULL
                               AND s.finished_at BETWEEN ? AND ? GROUP BY d""", (c["form_id"], c["item_key"], since, end)).fetchall()
        by_d = {r["d"]: r for r in rows}
        last = db.execute("""SELECT a.value_num, a.value_text, a.judgement, s.finished_at, s.id AS sub_id
                             FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
                             WHERE s.form_id=? AND a.item_key=? AND s.status<>'superseded' AND a.value_num IS NOT NULL
                             ORDER BY s.finished_at DESC, s.id DESC LIMIT 1""", (c["form_id"], c["item_key"])).fetchone()
        mn, mx = c["min_value"], c["max_value"]
        spec = ("≤ " + f"{mx:g}" if mn is None else ("≥ " + f"{mn:g}" if mx is None else f"{mn:g} – {mx:g}")) \
            if (mn is not None or mx is not None) else "ไม่กำหนด"
        out.append({
            "form_id": c["form_id"], "item_key": c["item_key"], "name": c["name"], "unit": c["unit"] or "",
            "eq_code": c["eq_code"] or c["form_name"], "factory_name": c["factory_name"],
            "min_value": mn, "max_value": mx, "warn_low": c["warn_low"], "warn_high": c["warn_high"], "spec": spec,
            "days": day_list,
            "avg": [round(by_d[d]["avg"], 3) if d in by_d else None for d in day_list],
            "min": [by_d[d]["mn"] if d in by_d else None for d in day_list],
            "max": [by_d[d]["mx"] if d in by_d else None for d in day_list],
            "last": last["value_num"] if last else None, "last_at": last["finished_at"] if last else None,
            "last_judgement": last["judgement"] if last else None, "last_sub": last["sub_id"] if last else None,
        })
    return out


def seven_day(db, day: date, factory_id: int | None = None, days: int = 7) -> dict:
    """จำนวนรอบที่กำหนด เทียบรอบที่ตรวจแล้ว รายวัน"""
    d_from = day - timedelta(days=days - 1)
    ensure_stats(db, d_from, day)
    fc, fp = _fac(factory_id)
    rows = {r["stat_date"]: r for r in db.execute(f"""
        SELECT d.stat_date, SUM(d.due) due, SUM(d.done_on_time) on_time, SUM(d.done_late) late, SUM(d.missed) missed,
               SUM(d.ng) ng
        FROM cs_daily_stats d JOIN cs_forms f ON f.id=d.form_id
        WHERE d.stat_date BETWEEN ? AND ? {fc} GROUP BY d.stat_date""", [d_from.isoformat(), day.isoformat()] + fp)}
    ds = [(d_from + timedelta(days=i)).isoformat() for i in range(days)]
    g = lambda d, k: (rows[d][k] or 0) if d in rows else 0   # noqa: E731
    return {"days": ds, "due": [g(d, "due") for d in ds], "done": [g(d, "on_time") + g(d, "late") for d in ds],
            "on_time": [g(d, "on_time") for d in ds], "missed": [g(d, "missed") for d in ds],
            "ng": [g(d, "ng") for d in ds]}


def factory_layouts(db, factory_id: int | None = None) -> list[dict]:
    cond, params = ("AND id=?", [factory_id]) if factory_id else ("", [])
    return [dict(r) for r in db.execute(
        f"SELECT id, code, name, layout_image FROM factories WHERE active=1 {cond} ORDER BY sort_no, name", params)]


# ───────────────────────── ผังย่อยรายพื้นที่: สถานะรายเครื่อง ─────────────────────────

EQ_STATUS_TH = {"good": "ตรวจครบ", "pending": "รอตรวจ", "warning": "ต้องติดตาม", "critical": "เร่งแก้ไข",
                "none": "ไม่มีรอบตรวจ", "down": "เครื่องหยุด/ซ่อม"}


def equipment_status(db, day: date, area_id: int) -> list[dict]:
    """สถานะของทุกเครื่องในพื้นที่ในวันนั้น — ใช้ตรวจว่าตรวจครบจริงหรือไม่ (ผังย่อย + ตาราง)

    good = รอบของวันตรวจครบ · pending = ยังมีรอบที่ยังไม่ถึงกำหนด · warning = เลยกำหนด/NG/แจ้งเตือน
    critical = ขาดตรวจ/แจ้งเตือนวิกฤต · down = เครื่องแจ้งหยุด · none = ไม่มีรอบตรวจวันนั้น
    """
    start, end = _day_bounds(day)
    eqs = db.execute("""SELECT e.id, e.code, e.name, e.eq_type, e.map_x, e.map_y, e.run_status, e.down_reason, e.down_since,
                               e.location
                        FROM equipment e WHERE e.area_id=? AND e.active=1 ORDER BY e.code""", (area_id,)).fetchall()
    if not eqs:
        return []
    ids = [e["id"] for e in eqs]
    ph = ",".join("?" * len(ids))
    rounds = {r["eid"]: r for r in db.execute(f"""
        SELECT f.equipment_id AS eid, SUM(r.status<>'skipped') total, SUM(r.status IN ('done_on_time','done_late')) done,
               SUM(r.status='done_late') late, SUM(r.status='missed') missed, SUM(r.status='overdue') overdue,
               SUM(r.status IN ('pending','in_progress')) pending, SUM(r.status='returned') returned,
               SUM(r.status='skipped') skipped,
               MIN(CASE WHEN r.status IN ('pending','in_progress','overdue') THEN r.deadline_at END) AS next_deadline
        FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id
        WHERE f.equipment_id IN ({ph}) AND r.due_at BETWEEN ? AND ? AND {S.scheduled_sql()}
        GROUP BY f.equipment_id""", ids + [start, end])}
    subs = {r["eid"]: r for r in db.execute(f"""
        SELECT s.equipment_id AS eid, COUNT(*) n, SUM(s.ng_count) ng, SUM(s.warn_count) warn, MAX(s.finished_at) last_at
        FROM cs_submissions s WHERE s.equipment_id IN ({ph}) AND s.status<>'superseded' AND s.finished_at BETWEEN ? AND ?
        GROUP BY s.equipment_id""", ids + [start, end])}
    last_by = {r["eid"]: r for r in db.execute(f"""
        SELECT s.equipment_id AS eid, s.finished_at, u.name AS inspector FROM cs_submissions s
        LEFT JOIN users u ON u.id=s.inspector_id
        WHERE s.id IN (SELECT MAX(id) FROM cs_submissions WHERE equipment_id IN ({ph}) AND status<>'superseded'
                       GROUP BY equipment_id)""", ids)}
    alerts = {r["eid"]: r for r in db.execute(f"""
        SELECT f.equipment_id AS eid, SUM(a.severity='critical') critical, COUNT(*) n
        FROM cs_alerts a JOIN cs_forms f ON f.id=a.form_id
        WHERE f.equipment_id IN ({ph}) AND a.alert_type<>'approval' AND a.status IN ({','.join('?' * len(A.OPEN_STATUSES))})
        GROUP BY f.equipment_id""", ids + list(A.OPEN_STATUSES))}
    forms = {}
    for r in db.execute(f"SELECT id, code, name, equipment_id FROM cs_forms WHERE equipment_id IN ({ph}) AND active=1 "
                        "AND current_version_id IS NOT NULL ORDER BY code", ids):
        forms.setdefault(r["equipment_id"], []).append(dict(r))
    out = []
    for e in eqs:
        r, s, al, lb = rounds.get(e["id"]), subs.get(e["id"]), alerts.get(e["id"]), last_by.get(e["id"])
        g = (lambda k: (r[k] or 0) if r else 0)
        total, done, missed, overdue, pending = g("total"), g("done"), g("missed"), g("overdue"), g("pending")
        ng = (s["ng"] or 0) if s else 0
        crit = (al["critical"] or 0) if al else 0
        n_alert = (al["n"] or 0) if al else 0
        if e["run_status"] == "down":
            status = "down"
        elif crit or missed:
            status = "critical"
        elif overdue or ng or n_alert or g("returned"):
            status = "warning"
        elif pending:
            status = "pending"
        elif total:
            status = "good"
        else:
            status = "none"
        reasons = []
        if e["run_status"] == "down":
            reasons.append(e["down_reason"] or "เครื่องหยุด")
        for n, label in ((missed, "ขาดตรวจ"), (overdue, "เลยกำหนด"), (g("returned"), "ถูกตีกลับ"), (ng, "NG"),
                         (crit, "แจ้งเตือนวิกฤต"), (n_alert - crit, "แจ้งเตือน")):
            if n:
                reasons.append(f"{label} {n}")
        out.append({**dict(e), "rounds": total, "done": done, "missed": missed, "overdue": overdue, "pending": pending,
                    "late": g("late"), "skipped": g("skipped"), "ng": ng, "alerts": n_alert,
                    "subs_today": (s["n"] or 0) if s else 0, "last_today": s["last_at"] if s else None,
                    "last_at": lb["finished_at"] if lb else None, "last_by": lb["inspector"] if lb else None,
                    "next_deadline": r["next_deadline"] if r else None, "forms": forms.get(e["id"], []),
                    "status": status, "status_th": EQ_STATUS_TH[status], "reason": " · ".join(reasons)})
    return out


# ───────────────────────── v0.33 แดชบอร์ดรายเครื่อง (หน้าแนวโน้ม) ─────────────────────────

def machine_overview(db, form_id: int, day_from: date, day_to: date) -> dict | None:
    """ภาพรวมของแบบฟอร์ม/เครื่องในช่วงวันที่: ทุกหัวข้อ (สถิติ + ค่าล่าสุด + จุดสำหรับกราฟเล็ก) · ผู้ตรวจ · รายวัน · NG สูงสุด"""
    form = S.get_form(db, form_id)
    if not form or not form["current_version_id"]:
        return None
    start, end = f"{day_from.isoformat()} 00:00:00", f"{day_to.isoformat()} 23:59:59"
    items = S.get_items(db, form["current_version_id"])
    subs = [dict(r) for r in db.execute("""
        SELECT s.id, s.finished_at, s.inspector_id, u.name AS inspector, s.ng_count, s.warn_count, s.duration_sec,
               s.approval_status, s.round_id, r.status AS round_status
        FROM cs_submissions s LEFT JOIN users u ON u.id=s.inspector_id LEFT JOIN cs_rounds r ON r.id=s.round_id
        WHERE s.form_id=? AND s.status<>'superseded' AND s.finished_at BETWEEN ? AND ?
        ORDER BY s.finished_at""", (form_id, start, end))]
    sub_ids = {s["id"] for s in subs}
    by_item: dict[str, list] = {}
    if subs:
        for r in db.execute("""SELECT a.item_key, a.value_num, a.value_text, a.judgement, s.finished_at, s.id AS sub_id
                               FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
                               WHERE s.form_id=? AND s.status<>'superseded' AND s.finished_at BETWEEN ? AND ?
                               ORDER BY s.finished_at""", (form_id, start, end)):
            if r["sub_id"] in sub_ids:
                by_item.setdefault(r["item_key"], []).append(dict(r))
    open_alerts = {r[0]: r[1] for r in db.execute(
        f"""SELECT item_key, COUNT(*) FROM cs_alerts WHERE form_id=? AND item_key IS NOT NULL AND item_key<>''
            AND status IN ({','.join('?' * len(A.OPEN_STATUSES))}) GROUP BY item_key""", (form_id, *A.OPEN_STATUSES))}
    out_items = []
    for it in items:
        rows = [r for r in by_item.get(it["item_key"], []) if r["judgement"] != "na"
                and (r["value_num"] is not None or (r["value_text"] or "").strip())]
        numeric = it["item_type"] in ("number", "counter", "calc")
        ng = sum(1 for r in rows if r["judgement"] == "ng")
        warn = sum(1 for r in rows if r["judgement"] == "warn")
        last = rows[-1] if rows else None
        d = {"item_key": it["item_key"], "name": it["name"], "type": it["item_type"], "section": it.get("section") or "",
             "unit": it.get("unit") or "", "min_value": it.get("min_value"), "max_value": it.get("max_value"),
             "warn_low": it.get("warn_low"), "warn_high": it.get("warn_high"), "critical": bool(it.get("critical")),
             "n": len(rows), "ng": ng, "warn": warn, "ok": len(rows) - ng - warn, "alerts": open_alerts.get(it["item_key"], 0),
             "last": (last["value_text"] if last else None), "last_num": (last["value_num"] if last else None),
             "last_j": (last["judgement"] if last else None), "last_at": (last["finished_at"] if last else None),
             "last_sub": (last["sub_id"] if last else None), "numeric": numeric}
        if numeric:
            vals = [r["value_num"] for r in rows if r["value_num"] is not None]
            pts = [[r["finished_at"], r["value_num"], r["judgement"] or "", r["sub_id"]] for r in rows if r["value_num"] is not None]
            d["pts"] = pts[-120:]
            if vals:
                mean = sum(vals) / len(vals)
                sd = (sum((v - mean) ** 2 for v in vals) / (len(vals) - 1)) ** 0.5 if len(vals) > 1 else 0.0
                d.update({"mean": round(mean, 4), "min": min(vals), "max": max(vals), "sd": round(sd, 4)})
                lo, hi = it.get("min_value"), it.get("max_value")
                if len(vals) >= 5 and sd > 0 and (lo is not None or hi is not None):
                    cands = ([(hi - mean) / (3 * sd)] if hi is not None else []) + ([(mean - lo) / (3 * sd)] if lo is not None else [])
                    d["cpk"] = round(min(cands), 2)
        else:
            d["hist"] = [[r["finished_at"], (r["value_text"] or "")[:40], r["judgement"] or "", r["sub_id"]] for r in rows[-40:]]
        # สถานะของหัวข้อ: ng > warn/สัญญาณ > ok > none
        if not rows:
            d["status"] = "none"
        elif last and last["judgement"] == "ng" or d["alerts"] and ng:
            d["status"] = "ng"
        elif ng or warn or d["alerts"] or (d.get("cpk") is not None and d["cpk"] < 1):
            d["status"] = "warn"
        else:
            d["status"] = "ok"
        out_items.append(d)
    rank = {"ng": 0, "warn": 1, "ok": 2, "none": 3}
    # ผู้ตรวจ
    insp: dict = {}
    for s in subs:
        k = s["inspector_id"] or 0
        x = insp.setdefault(k, {"id": k, "name": s["inspector"] or "-", "n": 0, "ng_subs": 0, "ng_items": 0,
                                "dur": [], "on_time": 0, "late": 0, "last": None})
        x["n"] += 1
        x["ng_subs"] += 1 if s["ng_count"] else 0
        x["ng_items"] += s["ng_count"] or 0
        if s["duration_sec"]:
            x["dur"].append(s["duration_sec"])
        if s["round_status"] == "done_on_time":
            x["on_time"] += 1
        elif s["round_status"] == "done_late":
            x["late"] += 1
        x["last"] = s["finished_at"]
    inspectors = []
    for x in insp.values():
        dur = x.pop("dur")
        x["avg_min"] = round(sum(dur) / len(dur) / 60, 1) if dur else None
        inspectors.append(x)
    inspectors.sort(key=lambda x: -x["n"])
    # รายวัน
    nd = (day_to - day_from).days + 1
    days = [(day_from + timedelta(days=i)).isoformat() for i in range(nd)]
    per = {d: [0, 0] for d in days}
    for s in subs:
        dk = s["finished_at"][:10]
        if dk in per:
            per[dk][0] += 1
            per[dk][1] += 1 if s["ng_count"] else 0
    rounds = db.execute("""SELECT COUNT(*) n, SUM(status='done_on_time') on_time, SUM(status='done_late') late,
                                  SUM(status='missed') missed, SUM(status IN ('pending','due','overdue')) open_
                           FROM cs_rounds WHERE form_id=? AND due_at BETWEEN ? AND ?""", (form_id, start, end)).fetchone()
    n_r = rounds["n"] or 0
    closed = (rounds["on_time"] or 0) + (rounds["late"] or 0) + (rounds["missed"] or 0)
    total_answers = sum(i["n"] for i in out_items)
    total_ng = sum(i["ng"] for i in out_items)
    types = {}
    for i in out_items:
        t = "numeric" if i["numeric"] else ("okng" if i["type"] == "ok_ng" else ("choice" if i["type"] == "choice" else "other"))
        types[t] = types.get(t, 0) + 1
    pareto = sorted(([i["name"], i["ng"], i["item_key"]] for i in out_items if i["ng"]), key=lambda x: -x[1])[:10]
    return {
        "form": {"id": form["id"], "name": form["name"], "code": form["code"], "eq_code": form["eq_code"],
                 "eq_name": form.get("eq_name"), "factory_name": form.get("factory_name"), "area_name": form.get("area_name")},
        "items": sorted(out_items, key=lambda i: (rank[i["status"]], items.index(next(x for x in items if x["item_key"] == i["item_key"])))),
        "order": [i["item_key"] for i in items],
        "kpi": {"subs": len(subs), "n_items": len(items), "types": types, "answers": total_answers, "ng": total_ng,
                "warn": sum(i["warn"] for i in out_items),
                "pass_rate": round(100 * (total_answers - total_ng) / total_answers, 1) if total_answers else None,
                "abnormal": sum(1 for i in out_items if i["status"] in ("ng", "warn")),
                "alerts": sum(open_alerts.values()), "inspectors": len(inspectors),
                "rounds": n_r, "on_time": rounds["on_time"] or 0, "late": rounds["late"] or 0, "missed": rounds["missed"] or 0,
                "on_time_rate": round(100 * (rounds["on_time"] or 0) / closed, 1) if closed else None,
                "last_at": subs[-1]["finished_at"] if subs else None},
        "inspectors": inspectors,
        "daily": {"days": days, "subs": [per[d][0] for d in days], "ng": [per[d][1] for d in days]},
        "pareto": pareto,
    }


# ───────────────────────── v0.43 ค่าที่ตรวจย้อนหลัง รายเครื่องจักร (ทุกค่า) ─────────────────────────
MV_TYPES = ("number", "counter", "calc", "ok_ng", "choice")
MV_MAX_POINTS = 400


def machine_list(db, factory_id: int | None = None, days: int = 30) -> list[dict]:
    """เครื่องจักร/แบบฟอร์มที่มีผลตรวจในช่วงนี้ (เรียง: มีแจ้งเตือนค้าง → ตรวจล่าสุด)"""
    fc, fp = _fac(factory_id)
    since = ts(datetime.now() - timedelta(days=days))
    rows = db.execute(f"""
        SELECT f.id AS form_id, f.name AS form_name, e.code AS eq_code, fa.name AS factory_name,
               MAX(s.finished_at) AS last_at, COUNT(*) AS n,
               (SELECT COUNT(*) FROM cs_alerts al WHERE al.form_id=f.id AND al.status IN ('open','acknowledged','in_progress')) AS alerts
        FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN factories fa ON fa.id=f.factory_id
        WHERE s.status<>'superseded' AND s.finished_at>=? AND f.active=1 AND COALESCE(f.is_template,0)=0 {fc}
        GROUP BY f.id ORDER BY alerts>0 DESC, last_at DESC""", [since] + fp).fetchall()
    return [dict(r) for r in rows]


def _spec(mn, mx) -> str:
    if mn is None and mx is None:
        return ""
    if mn is None:
        return f"≤ {mx:g}"
    if mx is None:
        return f"≥ {mn:g}"
    return f"{mn:g} – {mx:g}"


def machine_values(db, form_id: int, days: int = 7, day: date | None = None) -> dict | None:
    """ทุกค่าที่ตรวจของเครื่องจักร (ทุกหัวข้อ ทุกครั้ง) ในช่วง N วัน — ใช้วาดกราฟเล็กรายหัวข้อ"""
    f = db.execute("""SELECT f.id, f.name, f.current_version_id, e.code AS eq_code, e.name AS eq_name, fa.name AS factory_name
                      FROM cs_forms f LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN factories fa ON fa.id=f.factory_id
                      WHERE f.id=?""", (form_id,)).fetchone()
    if not f:
        return None
    day = day or date.today()
    start = datetime.combine(day - timedelta(days=days - 1), time(0, 0))
    end = datetime.combine(day + timedelta(days=1), time(0, 0))
    items = [dict(r) for r in db.execute(f"""SELECT item_key, name, unit, item_type, min_value, max_value, warn_low, warn_high
                                            FROM cs_form_items WHERE version_id=? AND item_type IN ({','.join('?' * len(MV_TYPES))})
                                            ORDER BY order_no""", (f["current_version_id"], *MV_TYPES))] if f["current_version_id"] else []
    pts: dict[str, list] = {}
    for r in db.execute("""SELECT a.item_key, a.value_num, a.value_text, a.judgement, s.finished_at, s.id AS sid
                           FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
                           WHERE s.form_id=? AND s.status<>'superseded' AND s.finished_at>=? AND s.finished_at<?
                             AND a.judgement<>'na' ORDER BY s.finished_at, s.id""", (form_id, ts(start), ts(end))):
        if r["value_num"] is None and not (r["value_text"] or "").strip():
            continue
        pts.setdefault(r["item_key"], []).append(
            [r["finished_at"][:16], r["value_num"], (r["value_text"] or "")[:40], r["judgement"] or "ok", r["sid"]])
    out = []
    for it in items:
        p = pts.get(it["item_key"], [])[-MV_MAX_POINTS:]
        numeric = it["item_type"] in ("number", "counter", "calc")
        vals = [x[1] for x in p if x[1] is not None]
        out.append({
            "key": it["item_key"], "name": it["name"], "unit": it["unit"] or "", "type": "num" if numeric else "cat",
            "min": it["min_value"], "max": it["max_value"], "wl": it["warn_low"], "wh": it["warn_high"],
            "spec": _spec(it["min_value"], it["max_value"]) if numeric else ("OK / NG" if it["item_type"] == "ok_ng" else "ตัวเลือก"),
            "pts": p, "n": len(p), "ng": sum(1 for x in p if x[3] == "ng"), "warn": sum(1 for x in p if x[3] == "warn"),
            "lo": min(vals) if vals else None, "hi": max(vals) if vals else None,
            "avg": round(sum(vals) / len(vals), 2) if vals else None,
        })
    return {"form_id": f["id"], "name": f["name"], "eq_code": f["eq_code"] or "", "eq_name": f["eq_name"] or "",
            "factory_name": f["factory_name"] or "", "days": days, "from": start.date().isoformat(), "to": day.isoformat(),
            "items": out}
