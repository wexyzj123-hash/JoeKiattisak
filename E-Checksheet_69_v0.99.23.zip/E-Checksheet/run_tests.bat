@echo off
chcp 65001 >nul
rem ===== รันชุดทดสอบทั้งหมดของ E-Checksheet =====
rem ใช้: run_tests.bat            (ทุกไฟล์ รันขนาน)
rem      run_tests.bat -k v41     (เฉพาะที่ชื่อตรง) · run_tests.bat tests\test_v99_ui.py
rem ผลลัพธ์: ผ่านทั้งหมด = จบด้วยรหัส 0 · มีข้อล้ม = รหัส 1 (ใช้ต่อกับขั้นตอนอัปเดตเวอร์ชันได้)
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo สร้างสภาพแวดล้อมทดสอบ .venv ...
  python -m venv .venv || goto :fail
)
call .venv\Scripts\activate.bat
python -m pip install -q -r requirements.txt -r requirements-dev.txt || goto :fail
python -m pytest tests -q -p no:cacheprovider -n auto %*
if errorlevel 1 goto :fail
echo.
echo ✔ ผ่านทุกการทดสอบ
exit /b 0
:fail
echo.
echo ✘ มีการทดสอบที่ไม่ผ่าน หรือติดตั้งไม่สำเร็จ — ดูข้อความด้านบน
exit /b 1
