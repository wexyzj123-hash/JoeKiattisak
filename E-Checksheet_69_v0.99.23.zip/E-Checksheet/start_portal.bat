@echo off
REM Start UT-CMMS + E-Checksheet in the BACKGROUND (no console window stays open).
REM Log: data\portal.log   Stop: stop_portal.bat   Status: status_portal.bat
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul || set "PY=py"
%PY% tools\portal_ctl.py start
echo.
echo This window closes in 15 seconds (the system keeps running).
timeout /t 15
