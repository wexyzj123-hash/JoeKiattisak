#!/usr/bin/env bash
# รันชุดทดสอบทั้งหมด (Linux/Mac/CI):  ./run_tests.sh [อาร์กิวเมนต์ pytest]
set -euo pipefail
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -q -r requirements.txt -r requirements-dev.txt
exec python -m pytest tests -q -p no:cacheprovider -n auto "$@"
