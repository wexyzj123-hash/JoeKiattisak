@echo off
REM Prepare UT-CMMS + E-Checksheet merged system: backup, fix, .env, check, import.
REM Safe to run while the old UT-CMMS is still running. Nothing is deleted.
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul || set "PY=py"
%PY% tools\go_live.py %*
echo.
pause
