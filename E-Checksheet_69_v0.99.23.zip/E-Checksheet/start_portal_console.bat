@echo off
REM Start in a visible console window (for troubleshooting). Close the window to stop.
title UT-CMMS + E-Checksheet
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul || set "PY=py"
%PY% portal.py --check
if errorlevel 1 (
  pause
  exit /b 1
)
%PY% portal.py %*
pause
