@echo off
REM Start the merged server automatically when Windows starts (Task Scheduler, no extra software).
REM Right-click > Run as administrator.
chcp 65001 >nul
net session >nul 2>&1
if errorlevel 1 (
  echo Please right-click this file and choose "Run as administrator".
  pause
  exit /b 1
)
set "PYEXE="
for /f "delims=" %%i in ('where pythonw 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
if not defined PYEXE for /f "delims=" %%i in ('where python 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
if not defined PYEXE (
  echo Python not found in PATH.
  pause
  exit /b 1
)
schtasks /Create /TN "UT-Portal" /SC ONSTART /DELAY 0001:00 /RU SYSTEM /RL HIGHEST /F /TR "\"%PYEXE%\" \"%~dp0portal.py\" --log"
if errorlevel 1 (
  pause
  exit /b 1
)
echo.
echo Task "UT-Portal" created. It starts at every boot.
echo Start now:  schtasks /Run /TN UT-Portal      Stop:  schtasks /End /TN UT-Portal
echo Remove:     schtasks /Delete /TN UT-Portal /F
echo If the old UT-CMMS also starts automatically (Startup folder or another task), disable it - both use port 5000.
pause
