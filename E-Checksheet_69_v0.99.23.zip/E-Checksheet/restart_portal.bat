@echo off
REM Restart the background server (after updating files).
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul || set "PY=py"
%PY% tools\portal_ctl.py restart
timeout /t 15
