#!/usr/bin/env python3
"""portal.py — รวม UT-CMMS (เดิม) + E-Checksheet (ใหม่) ให้ทำงานเป็นระบบเดียว บนพอร์ตเดียว

    http://server:5000/          → UT-CMMS (ไฟล์โปรแกรมเดิม ไม่ได้แก้ไขแม้แต่บรรทัดเดียว)
    http://server:5000/echeck/   → E-Checksheet
    http://server:5000/energy/   → Energy Data (มิเตอร์ไฟฟ้า / ลม / น้ำ) — อยู่ในระบบ E-Checksheet ใช้ login ร่วม

- เข้าสู่ระบบครั้งเดียวใช้ได้ทั้งสองระบบ (ใช้ชื่อผู้ใช้/รหัสผ่านของ UT-CMMS) ออกฝั่งไหนก็ออกทั้งคู่
- หน้า UT-CMMS มีปุ่มลัด "E-Checksheet" มุมขวาล่าง พร้อมตัวเลขแจ้งเตือนค้าง / รอบตรวจที่ต้องทำ
- QR เดิมที่ติดเครื่อง (/checksheet/<id>) พาไปฟอร์มใหม่ของเครื่องเดียวกัน (เมื่อนำเข้าเครื่องจักรแล้ว)
- ฐานข้อมูลยังแยกไฟล์กัน: utility_cmms.db (เดิม) และ data/echecksheet.db (ใหม่) → ถอยกลับได้ทันที

ใช้งาน (ตั้ง CMMS_DIR ในไฟล์ .env ให้ชี้โฟลเดอร์ UT-CMMS ก่อน):
    python portal.py --check                 ตรวจความพร้อม ไม่เปิดเซิร์ฟเวอร์
    python portal.py --import-legacy         นำเข้าเครื่องจักร/แบบฟอร์ม/ผู้ใช้จาก UT-CMMS (รันซ้ำได้ ข้ามของที่มีแล้ว)
    python portal.py                         เปิดระบบรวม (Waitress, พอร์ต PORTAL_PORT ค่าเริ่มต้น 5000)
    python portal.py --https                 เปิดผ่าน HTTPS (พอร์ต PORTAL_HTTPS_PORT, ใช้ cert.pem/key.pem)
"""
from __future__ import annotations

import os
import re
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

for _stream in (sys.stdout, sys.stderr):      # Windows service / cmd ที่ไม่รองรับภาษาไทย → ไม่ล้ม
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

from ecs.settings import abs_path, env, env_bool, env_int  # noqa: E402

LEGACY_QR = re.compile(r"^/checksheet/(\d+)/?$")
# หน้าเช็คชีตเดิมอื่น ๆ ของ UT-CMMS (มือถือ) → ใช้ระบบใหม่แทน
LEGACY_PAGES = re.compile(r"^/checksheet(/login|/template/\d+)?/?$")


class PortalError(Exception):
    pass


def portal_config() -> dict:
    prefix = "/" + env("PORTAL_PREFIX", "/echeck").strip("/")
    return {
        "CMMS_DIR": os.path.normpath(abs_path(env("CMMS_DIR", ""))) if env("CMMS_DIR", "") else "",
        "PREFIX": prefix,
        "HOST": env("PORTAL_HOST", env("HOST", "0.0.0.0")),
        "PORT": env_int("PORTAL_PORT", 5000),
        "HTTPS_PORT": env_int("PORTAL_HTTPS_PORT", 5443),
        "CMMS_BACKGROUND": env_bool("PORTAL_CMMS_BACKGROUND", True),
        "LAUNCHER": env_bool("PORTAL_LAUNCHER", True),
        "LEGACY_QR": env_bool("PORTAL_LEGACY_QR", True),
        "CMMS_SECRET_KEY": env("CMMS_SECRET_KEY", ""),
        "GUARD": env_bool("PORTAL_GUARD", True),
    }


def load_cmms(cmms_dir: str, background: bool = True):
    """โหลดแอป UT-CMMS จากโฟลเดอร์เดิมตามที่เป็นอยู่ (import app.py) — ไม่แก้ไขไฟล์ใด ๆ"""
    if not cmms_dir or not os.path.isfile(os.path.join(cmms_dir, "app.py")):
        raise PortalError(f"ไม่พบ UT-CMMS (app.py) ที่ CMMS_DIR = {cmms_dir or '(ยังไม่ได้ตั้ง)'}")
    if cmms_dir not in sys.path:
        sys.path.insert(1, cmms_dir)
    if not background:
        # เครื่องทดสอบ: ปิด Telegram poller / ตัวแจ้งเตือนการประชุมของ UT-CMMS
        # (ถ้าเปิดพร้อมเครื่องจริง bot เดียวกันจะแย่งข้อความกัน และส่งแจ้งเตือนซ้ำ)
        import routes.meetings as _meet
        import routes.telegram_polling as _tg
        _meet.start_meeting_scheduler = lambda app: None
        _tg.start_telegram_poller = lambda app: None
    import app as cmms_module     # app.py ของ UT-CMMS สร้างแอปไว้ในตัวแปร app
    return cmms_module.app


def build(pcfg: dict | None = None, ecs_overrides: dict | None = None):
    """คืน (wsgi_app, cmms_app, ecs_app)"""
    pcfg = pcfg or portal_config()
    cmms = load_cmms(pcfg["CMMS_DIR"], pcfg["CMMS_BACKGROUND"])
    if pcfg.get("CMMS_SECRET_KEY"):
        # UT-CMMS เดิมฝังรหัสลับของ session ไว้ในโค้ด — ตั้งใหม่ที่นี่ให้ปลอดภัยขึ้น (ผู้ใช้ต้อง login ใหม่ 1 ครั้ง)
        cmms.secret_key = pcfg["CMMS_SECRET_KEY"]
    prefix = pcfg["PREFIX"]
    if pcfg.get("GUARD", True):
        from ecs.cmms_guard import install
        install(cmms)          # กัน XSS / ไฟล์แนบต้อง login / open redirect (ดู ecs/cmms_guard.py)

    from ecs import create_app
    cfg = {"CMMS_LINK": True, "CMMS_DATABASE": cmms.config["DATABASE"], "CMMS_SECRET_KEY": cmms.secret_key,
           "CMMS_HOME": "/", "CMMS_COOKIE_NAME": cmms.config.get("SESSION_COOKIE_NAME") or "session",
           "APPLICATION_ROOT": prefix, "SESSION_COOKIE_PATH": prefix}
    cfg.update(ecs_overrides or {})
    ecs_app = create_app(cfg)

    @cmms.before_request
    def _energy_path():
        # v0.62 Energy Data: http://server:5000/energy → หน้าในระบบเดียวกัน (ใช้ login ร่วม)
        from flask import redirect, request
        if request.path == "/energy" or request.path.startswith("/energy/"):
            q = request.query_string.decode()
            return redirect(f"{prefix}{request.path if request.path != '/energy' else '/energy/'}" + (f"?{q}" if q else ""))
        return None

    if pcfg["LEGACY_QR"]:
        @cmms.before_request
        def _legacy_qr():
            from flask import redirect, request
            m = LEGACY_QR.match(request.path)
            if m:
                return redirect(f"{prefix}/legacy/checksheet/{m.group(1)}")
            if LEGACY_PAGES.match(request.path):
                return redirect(f"{prefix}/m/")
            return None

    if pcfg["LAUNCHER"]:
        tag = (f'<script src="{prefix}/static/portal/launcher.js?v={_mtime(ecs_app, "portal/launcher.js")}" '
               f'data-base="{prefix}" defer></script>')

        @cmms.after_request
        def _inject_launcher(resp):
            from flask import request
            if (request.path == "/" and resp.status_code == 200 and resp.mimetype == "text/html"
                    and not resp.direct_passthrough):
                html = resp.get_data(as_text=True)
                i = html.lower().rfind("</body>")
                if i != -1 and "portal/launcher.js" not in html:
                    resp.set_data(html[:i] + tag + html[i:])
            return resp

    # v0.16 ใบแจ้งซ่อมจาก NG: รูปแนบเก็บในโฟลเดอร์ของ UT-CMMS + ให้ UT-CMMS แจ้งเตือนใบใหม่ (Telegram/อีเมล) ตามปกติ
    ecs_app.config["CMMS_UPLOAD_FOLDER"] = cmms.config.get("UPLOAD_FOLDER")
    if pcfg.get("CMMS_BACKGROUND", True):
        ecs_app.config["CMMS_WO_CREATED"] = lambda wid: _notify_new_wo(cmms, wid)

    from werkzeug.middleware.dispatcher import DispatcherMiddleware
    return DispatcherMiddleware(cmms, {prefix: ecs_app}), cmms, ecs_app


def _notify_new_wo(cmms, wid: int) -> None:
    """ส่งแจ้งเตือนใบแจ้งซ่อมใหม่ด้วยโค้ดของ UT-CMMS เอง (ทำใน thread แยก ไม่ให้ช่างรอ)"""
    import threading

    def run():
        with cmms.app_context():
            try:
                from notifications_telegram import notify_wo_created_telegram
                notify_wo_created_telegram(wid)
            except Exception as exc:              # noqa: BLE001
                print(f"[E-Checksheet→WO] telegram skipped: {exc}", flush=True)
            try:
                from helpers import get_db as cmms_db
                from notifications_email import get_email_config, notify_new_workorder_email
                if get_email_config(cmms)["enabled"]:
                    db = cmms_db()
                    row = db.execute("SELECT * FROM work_orders WHERE id=?", (wid,)).fetchone()
                    if row:
                        notify_new_workorder_email(dict(row), app=cmms, db=db)
            except Exception as exc:              # noqa: BLE001
                print(f"[E-Checksheet→WO] email skipped: {exc}", flush=True)
    threading.Thread(target=run, daemon=True, name="ecs-wo-notify").start()


def _mtime(app, filename: str) -> int:
    try:
        return int(os.path.getmtime(os.path.join(app.static_folder, filename)))
    except OSError:
        return 0


def check(pcfg: dict) -> int:
    import sqlite3
    ok = True
    print("ตรวจความพร้อมระบบรวม UT-CMMS + E-Checksheet")
    print(f"  CMMS_DIR       : {pcfg['CMMS_DIR'] or '(ยังไม่ได้ตั้ง)'}")
    try:
        _, cmms, ecs_app = build(dict(pcfg, CMMS_BACKGROUND=False), {"ENABLE_JOBS": False})
    except PortalError as exc:
        print("  ✗", exc)
        return 1
    cdb, edb = cmms.config["DATABASE"], ecs_app.config["DATABASE"]
    print(f"  ฐานข้อมูลเดิม  : {cdb}")
    print(f"  ฐานข้อมูลใหม่  : {edb}")
    if os.path.normcase(cdb) == os.path.normcase(edb):
        print("  ✗ ฐานข้อมูลทั้งสองต้องเป็นคนละไฟล์")
        ok = False
    con = sqlite3.connect(f"file:{cdb}?mode=ro", uri=True)
    n_cmms = con.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0]
    n_eq = con.execute("SELECT COUNT(*) FROM equipment").fetchone()[0]
    con.close()
    e = sqlite3.connect(edb)
    n_linked = e.execute("SELECT COUNT(*) FROM users WHERE legacy_id IS NOT NULL").fetchone()[0]
    n_eq_linked = e.execute("SELECT COUNT(*) FROM equipment WHERE legacy_id IS NOT NULL").fetchone()[0]
    e.close()
    print(f"  ผู้ใช้ UT-CMMS : {n_cmms} คน (ผูกกับ E-Checksheet แล้ว {n_linked} — ที่เหลือผูกอัตโนมัติเมื่อเข้าใช้ครั้งแรก)")
    print(f"  เครื่องจักร    : UT-CMMS {n_eq} · นำเข้า E-Checksheet แล้ว {n_eq_linked}"
          + ("" if n_eq_linked else "  ← รัน --import-legacy เพื่อให้ QR เดิมพาไปฟอร์มใหม่"))
    from ecs.cmms_guard import scan_db
    html_rows = scan_db(cdb)
    if html_rows:
        n = sum(x[2] for x in html_rows)
        where = ", ".join(f"{t}.{c} ({k})" for t, c, k in html_rows)
        print(f"  ! พบข้อความที่มีแท็ก HTML ในฐานข้อมูลเดิม {n} แถว: {where}")
        print("    (หน้าเว็บเดิมแสดงไม่ครบหรืออาจรันสคริปต์ได้) — แก้ด้วย: python portal.py --fix-html")
    if cmms.secret_key == "utility-cmms-secret-key-2026" and not pcfg.get("CMMS_SECRET_KEY"):
        print("  ! UT-CMMS ยังใช้รหัสลับ session ที่ฝังในโค้ด — แนะนำตั้ง CMMS_SECRET_KEY ในไฟล์ .env")
    print(f"  เปิดใช้งานที่   : http://<server>:{pcfg['PORT']}/  และ  {pcfg['PREFIX']}/")
    print("  ผลตรวจ         :", "พร้อมใช้งาน" if ok else "ต้องแก้ไขก่อน")
    return 0 if ok else 1


def import_legacy(pcfg: dict, users: bool, history: bool, dry_run: bool) -> int:
    from ecs.settings import load_config
    from tools.import_legacy import run
    if not pcfg["CMMS_DIR"]:
        print("ยังไม่ได้ตั้ง CMMS_DIR ในไฟล์ .env")
        return 1
    source = os.path.join(pcfg["CMMS_DIR"], "utility_cmms.db")
    target = load_config()["DATABASE"]
    os.makedirs(os.path.dirname(target), exist_ok=True)
    rep, db = run(source, target, users, history)
    (db.rollback if dry_run else db.commit)()
    db.close()
    print(("[ทดลอง ไม่บันทึก] " if dry_run else "") +
          f"เครื่องจักร {rep['equipment']} (ข้าม {rep['equipment_skipped']}) · แบบฟอร์ม {rep['forms']} "
          f"(ข้าม {rep['forms_skipped']}) · ผู้ใช้ {rep['users']} (ข้าม {rep['users_skipped']}) · ผลตรวจเก่า {rep['submissions']}")
    return 0


def fix_html(pcfg: dict) -> int:
    """ทำข้อความเดิมในฐานข้อมูล UT-CMMS ที่มีแท็ก HTML ให้แสดงผลเป็นตัวอักษร (แบ็กอัปไฟล์ก่อนแก้)"""
    import time
    from ecs.cmms_guard import scan_db
    db = os.path.join(pcfg["CMMS_DIR"], "utility_cmms.db")
    if not os.path.exists(db):
        print(f"ไม่พบ {db}")
        return 1
    found = scan_db(db)
    if not found:
        print("ไม่พบข้อความที่ต้องแก้")
        return 0
    bak = f"{db}.before-fix-html-{time.strftime('%Y%m%d-%H%M%S')}"
    import sqlite3
    src, dst = sqlite3.connect(db), sqlite3.connect(bak)
    src.backup(dst)
    src.close()
    dst.close()
    scan_db(db, fix=True)
    print(f"แก้แล้ว {sum(x[2] for x in found)} แถว ({', '.join(f'{t}.{c}' for t, c, _ in found)}) · แบ็กอัป: {bak}")
    return 0


def _log_to_file() -> None:
    """โหมดเบื้องหลัง (pythonw ไม่มีหน้าต่าง) → เขียนข้อความทั้งหมดลง data/portal.log (เก็บย้อนหลัง 1 ไฟล์ ไฟล์ละ ≤ 10 MB)"""
    import logging
    log_dir = os.path.join(ROOT, "data")
    os.makedirs(log_dir, exist_ok=True)
    path = os.path.join(log_dir, "portal.log")
    try:
        if os.path.exists(path) and os.path.getsize(path) > 10 * 1024 * 1024:
            os.replace(path, path + ".1")
    except OSError:
        pass
    fh = open(path, "a", encoding="utf-8", errors="replace", buffering=1)
    sys.stdout = sys.stderr = fh
    logging.basicConfig(level=logging.INFO, stream=fh, force=True,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    print(f"\n===== เริ่มระบบ {__import__('time').strftime('%Y-%m-%d %H:%M:%S')} (PID {os.getpid()}) =====")


def main() -> int:
    pcfg = portal_config()
    args = sys.argv[1:]
    if "--log" in args or sys.stdout is None:
        _log_to_file()
    if "--check" in args:
        return check(pcfg)
    if "--fix-html" in args:
        return fix_html(pcfg)
    if "--import-legacy" in args:
        return import_legacy(pcfg, users="--no-users" not in args, history="--history" in args,
                             dry_run="--dry-run" in args)
    try:
        wsgi, cmms, ecs_app = build(pcfg)
    except PortalError as exc:
        print(exc)
        return 1
    use_https = "--https" in args
    port = pcfg["HTTPS_PORT"] if use_https else pcfg["PORT"]
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        busy = s.connect_ex(("127.0.0.1", port)) == 0
    if busy:
        print(f"พอร์ต {port} ถูกใช้อยู่ — น่าจะเป็น UT-CMMS เดิมที่ยังรันอยู่ (อาจรันเบื้องหลังไม่มีหน้าต่าง)")
        print("หยุดได้ด้วย: คลิกขวา stop_old_cmms.bat > Run as administrator แล้วเปิด start_portal.bat ใหม่")
        return 1
    proto = "https" if use_https else "http"
    print("=" * 64)
    print("  UT-CMMS + E-Checksheet (ระบบรวม)")
    print(f"  UT-CMMS      : {proto}://localhost:{port}/")
    print(f"  E-Checksheet : {proto}://localhost:{port}{pcfg['PREFIX']}/")
    print(f"  ฐานข้อมูล    : {cmms.config['DATABASE']}")
    print(f"                 {ecs_app.config['DATABASE']}")
    if not pcfg["CMMS_BACKGROUND"]:
        print("  [โหมดทดสอบ] ปิด Telegram poller / ตัวแจ้งเตือนการประชุมของ UT-CMMS")
    print("=" * 64)
    if use_https:
        from werkzeug.serving import run_simple
        cert = key = None
        for base in (pcfg["CMMS_DIR"], ROOT):
            c, k = os.path.join(base, "cert.pem"), os.path.join(base, "key.pem")
            if os.path.exists(c) and os.path.exists(k):
                cert, key = c, k
                break
        if not cert:
            print("ไม่พบ cert.pem / key.pem (ในโฟลเดอร์ UT-CMMS หรือ E-Checksheet)")
            return 1
        run_simple(pcfg["HOST"], port, wsgi, ssl_context=(cert, key), threaded=True)
        return 0
    try:
        from waitress import serve
    except ImportError:
        print("ยังไม่ได้ติดตั้ง waitress:  pip install -r requirements.txt")
        return 1
    serve(wsgi, host=pcfg["HOST"], port=port, threads=24, connection_limit=400, channel_timeout=120,
          max_request_body_size=200 * 1024 * 1024)
    return 0


if __name__ == "__main__":
    sys.exit(main())
