"""ecs/settings.py — ค่าตั้งระบบ อ่านจากไฟล์ .env และ Environment Variables

ลำดับความสำคัญ: Environment Variable > ไฟล์ .env > ค่าเริ่มต้นในไฟล์นี้
ไม่ต้องติดตั้งไลบรารีเพิ่ม (.env รูปแบบ KEY=VALUE ต่อบรรทัด, # คือคอมเมนต์)
"""
from __future__ import annotations

import os
import secrets

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_dotenv(path: str) -> dict[str, str]:
    values: dict[str, str] = {}
    if not os.path.exists(path):
        return values
    with open(path, encoding="utf-8-sig") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            val = val.strip()
            if len(val) >= 2 and val[0] == val[-1] and val[0] in ("'", '"'):
                val = val[1:-1]
            values[key.strip()] = val
    return values


DOTENV = _load_dotenv(os.path.join(ROOT_DIR, ".env"))


def env(key: str, default: str = "") -> str:
    val = os.environ.get(key)
    if val is not None and val.strip() != "":
        return val.strip()
    return DOTENV.get(key, default)


def env_bool(key: str, default: bool = False) -> bool:
    return env(key, "1" if default else "0").lower() in ("1", "true", "yes", "on")


def env_int(key: str, default: int) -> int:
    try:
        return int(env(key, str(default)))
    except ValueError:
        return default


def abs_path(path: str) -> str:
    return path if os.path.isabs(path) else os.path.join(ROOT_DIR, path)


def secret_key() -> str:
    """SECRET_KEY จาก .env ถ้าไม่มีจะสร้างและเก็บไว้ในไฟล์ data/.secret_key"""
    key = env("SECRET_KEY")
    if key:
        return key
    path = abs_path(os.path.join("data", ".secret_key"))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            saved = fh.read().strip()
        if saved:
            return saved
    key = secrets.token_hex(32)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(key)
    return key


def load_config() -> dict:
    return {
        "APP_NAME": env("APP_NAME", "E-Checksheet"),
        "HOST": env("HOST", "0.0.0.0"),
        "PORT": env_int("PORT", 5100),
        "HTTPS_PORT": env_int("HTTPS_PORT", 5543),
        "DATABASE": abs_path(env("DATABASE", os.path.join("data", "echecksheet.db"))),
        "UPLOAD_FOLDER": abs_path(env("UPLOAD_FOLDER", os.path.join("data", "uploads"))),
        "BASE_URL": env("BASE_URL", "").rstrip("/"),          # ใช้กับลิงก์ในข้อความแจ้งเตือน (Telegram/LINE/อีเมล)
        "QR_BASE_URL": env("QR_BASE_URL", "").rstrip("/"),    # ว่าง = QR ใช้ที่อยู่ที่กำลังเปิดอยู่ (ไม่ล็อค IP)
        "SESSION_TIMEOUT_MIN": env_int("SESSION_TIMEOUT_MIN", 720),
        "ENABLE_JOBS": env_bool("ENABLE_JOBS", True),
        "JOB_INTERVAL_SEC": env_int("JOB_INTERVAL_SEC", 300),
        "NOTIFY_INTERVAL_SEC": env_int("NOTIFY_INTERVAL_SEC", 30),
        "MAX_PHOTO_MB": env_int("MAX_PHOTO_MB", 40),        # ขนาดไฟล์ต้นฉบับต่อรูป (ระบบย่อเหลือ ~200–500 KB ก่อนเก็บ)
        "SECURE_COOKIES": env_bool("SECURE_COOKIES", False),
        # ── รวมกับ UT-CMMS (portal.py ตั้งค่าให้เอง; ตั้งเองได้เมื่อรันแยกแต่อยู่โดเมน/พอร์ตเดียวกัน) ──
        "CMMS_LINK": env_bool("CMMS_LINK", False),
        "CMMS_DATABASE": env("CMMS_DATABASE", ""),
        "CMMS_SECRET_KEY": env("CMMS_SECRET_KEY", ""),
        "CMMS_HOME": env("CMMS_HOME", "/"),
        "CMMS_COOKIE_NAME": env("CMMS_COOKIE_NAME", "session"),
    }
