"""ecs/cmms_guard.py — ชั้นป้องกันที่ portal.py ครอบให้ UT-CMMS (ไม่ต้องแก้ไฟล์ของ UT-CMMS)

ปัญหาที่พบในระบบเดิม และสิ่งที่ไฟล์นี้ทำ:
1. Stored XSS: หน้าเว็บ UT-CMMS แสดงข้อความที่ผู้ใช้พิมพ์ (หัวข้อแจ้งซ่อม ชื่ออะไหล่ ข้อความแชท ฯลฯ)
   ด้วย innerHTML โดยไม่ escape — ผู้ใช้ทั่วไปพิมพ์ <img onerror=...> ในใบแจ้งซ่อม แล้วสคริปต์ทำงาน
   ในเบราว์เซอร์ของหัวหน้า/แอดมินที่เปิดแดชบอร์ด (ทดสอบยืนยันแล้ว)
   → ทำข้อความที่ส่งเข้ามาทุกช่องทาง (JSON / ฟอร์ม) ให้ไม่เป็นแท็ก HTML ก่อนถึงโค้ดเดิม:
     "<" ที่ตามด้วยตัวอักษร / ! ? → "＜" (อักษรเต็มความกว้าง อ่านออกเหมือนเดิม)
     เครื่องหมายคำพูดที่ใช้หลุดออกจาก attribute (เช่น " onfocus=...) → ″ / ′
     ข้อความปกติ เช่น "แรงดัน < 5 bar", ท่อ 1/2" ไม่ถูกเปลี่ยน
2. /uploads/<ไฟล์> เปิดได้โดยไม่ต้อง login → ต้อง login ก่อน
3. /checksheet/login?next=<เว็บภายนอก> พาไปเว็บอื่นได้ (open redirect) → รับเฉพาะ path ภายใน
"""
from __future__ import annotations

import re

from werkzeug.datastructures import ImmutableMultiDict

TAG = re.compile(r"<(?=[A-Za-z/!?])")
ATTR_BREAK = re.compile(r"""["'`][^"'`<>]*?\b(on[a-z]{3,}|style|src|href|formaction)\s*=|javascript\s*:""", re.I)
TAG_IN_DB = re.compile(r"<[A-Za-z/!?]")


def clean_text(s: str) -> str:
    if not s or ("<" not in s and '"' not in s and "'" not in s and "`" not in s and ":" not in s):
        return s
    out = TAG.sub("＜", s)
    if ATTR_BREAK.search(out):
        out = out.replace('"', "″").replace("'", "′").replace("`", "′")
        out = re.sub(r"javascript\s*:", "javascript：", out, flags=re.I)
    return out


def clean_value(v):
    if isinstance(v, str):
        return clean_text(v)
    if isinstance(v, list):
        return [clean_value(x) for x in v]
    if isinstance(v, dict):
        return {k: clean_value(x) for k, x in v.items()}
    return v


# ช่องที่ไม่ใช่ข้อความแสดงผล (รหัสผ่านต้องไม่ถูกแก้ ไม่งั้น login ไม่ได้)
SKIP_KEYS = {"password", "current_password", "new_password", "confirm_password", "req_password"}


def _clean_payload(v):
    if isinstance(v, dict):
        return {k: (x if k in SKIP_KEYS else _clean_payload(x)) for k, x in v.items()}
    if isinstance(v, list):
        return [_clean_payload(x) for x in v]
    return clean_value(v)


def _safe_next(url: str) -> str:
    if not url or not url.startswith("/") or url.startswith("//") or "\\" in url:
        return "/"
    return url


def install(cmms) -> None:
    """ผูก before_request กับแอป UT-CMMS"""
    from flask import jsonify, redirect, request, session

    @cmms.before_request
    def _guard():
        path = request.path
        if path.startswith("/uploads/") and "user_id" not in session:
            return jsonify({"error": "Unauthorized"}), 401
        if path == "/checksheet/login" and request.args.get("next") is not None:
            nxt = request.args.get("next")
            if _safe_next(nxt) != nxt:
                args = request.args.to_dict(flat=True)
                args["next"] = "/"
                from urllib.parse import urlencode
                return redirect(f"{path}?{urlencode(args)}")
        if request.method not in ("POST", "PUT", "PATCH"):
            return None
        if request.is_json:
            data = request.get_json(silent=True)
            if data is not None:
                cleaned = _clean_payload(data)
                if cleaned != data:
                    request._cached_json = (cleaned, cleaned)       # โค้ดเดิมเรียก request.json ได้ค่าที่ปลอดภัยแล้ว
        elif request.mimetype in ("multipart/form-data", "application/x-www-form-urlencoded"):
            form = request.form
            items = [(k, v if k in SKIP_KEYS else clean_text(v)) for k, v in form.items(multi=True)]
            if items != list(form.items(multi=True)):
                request.__dict__["form"] = ImmutableMultiDict(items)
        return None


def scan_db(path: str, fix: bool = False) -> list[tuple[str, str, int]]:
    """หาข้อความในฐานข้อมูล UT-CMMS ที่มีแท็ก HTML (อาจเป็น XSS ที่บันทึกไว้ก่อนหน้า) — fix=True แก้ให้ปลอดภัย"""
    import sqlite3
    con = sqlite3.connect(path) if fix else sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    found = []
    try:
        tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        for t in tables:
            cols = [r[1] for r in con.execute(f'PRAGMA table_info("{t}")') if (r[2] or "").upper() in ("TEXT", "")]
            for c in cols:
                if c in SKIP_KEYS or c in ("password", "req_password"):
                    continue
                rows = con.execute(f'SELECT rowid, "{c}" FROM "{t}" WHERE "{c}" LIKE ?', ("%<%",)).fetchall()
                bad = [(rid, v) for rid, v in rows if isinstance(v, str) and TAG_IN_DB.search(v)]
                if bad:
                    found.append((t, c, len(bad)))
                    if fix:
                        for rid, v in bad:
                            con.execute(f'UPDATE "{t}" SET "{c}"=? WHERE rowid=?', (clean_text(v), rid))
        if fix:
            con.commit()
    finally:
        con.close()
    return found
