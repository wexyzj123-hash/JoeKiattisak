"""ecs/jobs.py — งานเบื้องหลัง: สร้างรอบตรวจล่วงหน้า + อัปเดตสถานะเลยกำหนด/ขาดตรวจ

ใช้ thread เดียวแบบเดียวกับ meeting scheduler ของระบบเดิม (ไม่ต้องติดตั้งไลบรารีเพิ่ม)
ถ้ารันหลาย process (เช่นหลาย worker) งานนี้ยังปลอดภัย เพราะ generate_rounds ใช้ INSERT OR IGNORE
"""
from __future__ import annotations

import logging
import sqlite3
import threading
import time

from .services import generate_rounds, refresh_round_statuses

log = logging.getLogger(__name__)
_started = False
_lock = threading.Lock()


def run_once(db_path: str) -> dict:
    con = sqlite3.connect(db_path, timeout=15)
    con.row_factory = sqlite3.Row
    try:
        con.execute("PRAGMA busy_timeout=15000")
        created = generate_rounds(con)
        changed = refresh_round_statuses(con)       # v0.99.9 รวมตรวจรอบเครื่องหยุดกับช่วงหยุดย้อนหลังทั้งหมด
        from datetime import date, timedelta
        from .analytics import refresh_daily_stats
        from .anomaly import check_missed
        missed_alerts = check_missed(con)
        refresh_daily_stats(con, date.today() - timedelta(days=1), date.today())
        con.commit()
        return {"created": created, **changed, "missed_alerts": missed_alerts}
    finally:
        con.close()


def _loop(app) -> None:
    interval = max(60, int(app.config.get("JOB_INTERVAL_SEC", 300)))
    db_path = app.config["DATABASE"]
    from . import backup as BK
    from .health import beat
    while True:
        beat("jobs")
        try:
            if BK.due(app):
                r = BK.backup_now(app)
                log.info("backup: %s", r)
        except Exception:
            log.exception("backup failed")
        try:
            res = run_once(db_path)
            if res["created"] or res["missed"] or res["overdue"]:
                log.info("rounds: %s", res)
        except Exception:  # งานเบื้องหลังต้องไม่ล้มทั้งระบบ
            log.exception("job failed")
        try:
            sync_cmms(app)
        except Exception:
            log.exception("cmms wo sync failed")
        time.sleep(interval)


def sync_cmms(app) -> dict | None:
    """สถานะใบแจ้งซ่อม UT-CMMS → E-Checksheet (ปิดงานแล้วแจ้งเตือน/CAPA อัปเดตตาม)"""
    from . import cmms_wo
    if not cmms_wo.available(app.config):
        return None
    con = sqlite3.connect(app.config["DATABASE"], timeout=15)
    con.row_factory = sqlite3.Row
    try:
        con.execute("PRAGMA busy_timeout=15000")
        res = cmms_wo.sync_status(con, app.config)
        if res["changed"]:
            log.info("cmms wo: %s", res)
        from . import cmms_tpm
        try:
            n = cmms_tpm.refresh_states(con, app.config)
            if n:
                log.info("cmms tpm: %s updated", n)
        except Exception:                                  # noqa: BLE001
            con.rollback()
            log.exception("cmms tpm refresh failed")
        from . import cmms_status
        cmms_status.safe(cmms_status.expire, con, app.config)
        return res
    finally:
        con.close()


def start_jobs(app) -> None:
    global _started
    import os
    if app.debug and os.environ.get("WERKZEUG_RUN_MAIN") != "true":
        return
    with _lock:
        if _started:
            return
        _started = True
    threading.Thread(target=_loop, args=(app,), daemon=True, name="ecs-jobs").start()
    log.info("job thread started")
