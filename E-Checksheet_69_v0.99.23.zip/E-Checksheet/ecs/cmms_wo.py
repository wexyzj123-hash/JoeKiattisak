"""ecs/cmms_wo.py — ผลตรวจ NG → เปิดใบแจ้งซ่อม (Work Order) ใน UT-CMMS อัตโนมัติ → ปิดงานแล้วสถานะย้อนกลับมา E-Checksheet

ใช้ประโยชน์จากที่รวมระบบแล้ว (portal.py):
  1) ส่งผลตรวจที่มี NG → สร้างใบแจ้งซ่อมใน UT-CMMS (1 ผลตรวจ = 1 ใบ รวมทุกหัวข้อ NG) พร้อมรูป NG และลิงก์กลับ
     - ถ้าเครื่องเดียวกัน หัวข้อเดียวกัน ยังมีใบที่ค้างอยู่ → ไม่เปิดใบซ้ำ แต่เพิ่มบันทึก "พบ NG ซ้ำ" ในใบเดิม
  2) งานเบื้องหลังอ่านสถานะใบแจ้งซ่อม (ทุกรอบ jobs) → ปิดงาน (completed) แล้ว:
     - แจ้งเตือนของหัวข้อนั้นเป็น "แก้ไขแล้ว" พร้อมสาเหตุ/การแก้ไขจาก UT-CMMS
     - งานแก้ไข (CAPA) ที่ผูกกับหัวข้อนั้นเป็น "รอตรวจรับ"
     - แจ้งผู้ตรวจ/หัวหน้างานในระบบ
ตั้งค่าที่ จัดการ › ใบแจ้งซ่อม UT-CMMS (ปิดไว้ก่อน จนกว่าผู้ดูแลจะเปิดใช้)

เขียนเฉพาะตาราง work_orders / wo_attachments / activity_log ของ UT-CMMS ด้วยรูปแบบเดียวกับที่ UT-CMMS สร้างเอง
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import sqlite3
import uuid
from datetime import datetime, timedelta

from . import services as S
from .services import ValidationError, ts

log = logging.getLogger(__name__)

DEFAULTS = {
    "enabled": False,
    "mode": "ng",                # ng = ทุก NG · critical = เฉพาะหัวข้อวิกฤต · manual = กดเปิดเอง
    "department": "UT",
    "repair_type": "เช็คชีท NG",
    "repair_category": "",
    "work_window": "ทุกเวลา",
    "attach_photos": True,
    "due_days": 3,
    "due_days_critical": 1,
    "fallback_requester": "",    # username ใน UT-CMMS ที่ใช้เป็นผู้แจ้ง ถ้าผู้ตรวจยังไม่ผูกบัญชี
}
MODE_TH = {"ng": "ทุกผลตรวจที่มี NG", "critical": "เฉพาะหัวข้อวิกฤต (Critical)", "manual": "ไม่อัตโนมัติ — กดเปิดเองที่หน้าผลตรวจ"}
STATUS_TH = {"pending": "รออนุมัติ", "approved": "อนุมัติแล้ว", "in_progress": "กำลังซ่อม",
             "completed": "ซ่อมเสร็จ", "cancelled": "ยกเลิก"}
STATUS_CLASS = {"pending": "b-warn", "approved": "b-info", "in_progress": "b-info", "completed": "b-ok", "cancelled": "b-none"}
OPEN = ("pending", "approved", "in_progress")

DDL = """
CREATE TABLE IF NOT EXISTS cs_cmms_wo (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    wo_id         INTEGER NOT NULL,          -- work_orders.id ใน UT-CMMS
    wo_number     TEXT NOT NULL,
    submission_id INTEGER,
    form_id       INTEGER,
    equipment_id  INTEGER,
    item_keys     TEXT DEFAULT '',           -- JSON list
    status        TEXT NOT NULL DEFAULT 'pending',
    assignee      TEXT DEFAULT '',
    root_cause    TEXT DEFAULT '',
    action_taken  TEXT DEFAULT '',
    repeat_of     INTEGER,                   -- ผลตรวจนี้ผูกกับใบเดิม (NG ซ้ำ)
    created_by    INTEGER,
    created_at    TEXT NOT NULL,
    synced_at     TEXT,
    closed_at     TEXT,
    applied_at    TEXT                       -- เวลาที่นำผลปิดงานไปอัปเดตแจ้งเตือน/CAPA แล้ว
);
CREATE INDEX IF NOT EXISTS idx_cmmswo_sub ON cs_cmms_wo(submission_id);
CREATE INDEX IF NOT EXISTS idx_cmmswo_open ON cs_cmms_wo(status, wo_id);
"""


def ensure(db) -> None:
    db.executescript(DDL)


# ───────────────────────── ตั้งค่า ─────────────────────────

def get_settings(db) -> dict:
    cfg = dict(DEFAULTS)
    row = db.execute("SELECT value FROM cs_meta WHERE key='cmms_wo'").fetchone()
    if row and row[0]:
        try:
            cfg.update({k: v for k, v in json.loads(row[0]).items() if k in DEFAULTS})
        except ValueError:
            pass
    return cfg


def save_settings(db, data: dict, actor_id) -> dict:
    cfg = get_settings(db)
    cfg["enabled"] = data.get("enabled") in (1, True, "1", "on", "true")
    mode = str(data.get("mode") or "ng")
    cfg["mode"] = mode if mode in MODE_TH else "ng"
    for k in ("department", "repair_type", "repair_category", "work_window", "fallback_requester"):
        if k in data:
            cfg[k] = " ".join(str(data.get(k) or "").split())[:60]
    cfg["attach_photos"] = data.get("attach_photos") in (1, True, "1", "on", "true")
    for k in ("due_days", "due_days_critical"):
        try:
            cfg[k] = max(0, min(60, int(data.get(k) or DEFAULTS[k])))
        except (TypeError, ValueError):
            cfg[k] = DEFAULTS[k]
    if not cfg["department"]:
        raise ValidationError("กรุณาระบุแผนกที่แจ้ง (UT-CMMS บังคับกรอก)")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('cmms_wo', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(cfg, ensure_ascii=False),))
    S.audit(db, actor_id, "update", "cs_meta", None, after={"cmms_wo": cfg})
    return cfg


# ───────────────────────── การเชื่อมต่อ UT-CMMS ─────────────────────────

def _cmms_path(app_config) -> str | None:
    p = app_config.get("CMMS_DATABASE")
    return p if p and os.path.exists(p) else None


def available(app_config) -> bool:
    return bool(_cmms_path(app_config))


def _connect(app_config) -> sqlite3.Connection:
    path = _cmms_path(app_config)
    if not path:
        raise ValidationError("ยังไม่ได้เชื่อม UT-CMMS (เปิดผ่าน portal.py เท่านั้น)")
    con = sqlite3.connect(path, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=20000")
    return con


def status_info(db, app_config) -> dict:
    """สำหรับหน้าตั้งค่า: เชื่อมได้ไหม · จำนวนใบที่เปิดจากระบบนี้"""
    out = {"available": available(app_config), "error": "", "open": 0, "total": 0}
    r = db.execute("SELECT COUNT(*) n, SUM(status IN ('pending','approved','in_progress')) o FROM cs_cmms_wo").fetchone()
    out["total"], out["open"] = r["n"] or 0, r["o"] or 0
    if out["available"]:
        try:
            con = _connect(app_config)
            con.execute("SELECT id FROM work_orders LIMIT 1").fetchall()
            con.close()
        except (sqlite3.Error, ValidationError) as exc:
            out["available"], out["error"] = False, str(exc)
    return out


def _gen_wo_number(con) -> str:
    prefix = f"WO-{datetime.now():%Y}-"
    last = con.execute("SELECT wo_number FROM work_orders WHERE wo_number LIKE ? ORDER BY wo_number DESC LIMIT 1",
                       (prefix + "%",)).fetchone()
    try:
        n = int(last[0].split("-")[-1]) + 1 if last else 1
    except ValueError:
        n = 1
    return f"{prefix}{n:04d}"


def _requester(db, con, user_id, cfg) -> int:
    """ผู้แจ้งใน UT-CMMS: บัญชีที่ผูกกับผู้ตรวจ → ผู้ใช้ที่ตั้งไว้ → ผู้ดูแลระบบคนแรก"""
    u = db.execute("SELECT legacy_id FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None
    if u and u["legacy_id"] and con.execute("SELECT 1 FROM users WHERE id=?", (u["legacy_id"],)).fetchone():
        return int(u["legacy_id"])
    if cfg.get("fallback_requester"):
        r = con.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE", (cfg["fallback_requester"],)).fetchone()
        if r:
            return int(r["id"])
    r = con.execute("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1").fetchone() or \
        con.execute("SELECT id FROM users ORDER BY id LIMIT 1").fetchone()
    if not r:
        raise ValidationError("UT-CMMS ยังไม่มีผู้ใช้")
    return int(r["id"])


# ───────────────────────── NG → ใบแจ้งซ่อม ─────────────────────────

def _ng_items(db, sub_id: int, only_critical: bool) -> tuple[dict | None, list[dict]]:
    s = db.execute("""SELECT s.*, f.name AS form_name, f.code AS form_code, f.equipment_id AS f_eq, u.name AS inspector_name
                      FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id LEFT JOIN users u ON u.id=s.inspector_id
                      WHERE s.id=?""", (sub_id,)).fetchone()
    if not s:
        return None, []
    s = dict(s)
    rows = [dict(r) for r in db.execute("""
        SELECT a.id AS answer_id, a.item_key, a.value_text, a.remark, i.name, i.unit, i.min_value, i.max_value, i.critical
        FROM cs_answers a JOIN cs_form_items i ON i.id=a.item_id
        WHERE a.submission_id=? AND a.judgement='ng' ORDER BY i.order_no, i.id""", (sub_id,))]
    if only_critical:
        rows = [r for r in rows if r["critical"]]
    return s, rows


def create_for_submission(db, app_config, sub_id: int, actor_id=None, *, manual: bool = False,
                          base_url: str = "") -> dict | None:
    """สร้าง/ผูกใบแจ้งซ่อมจากผลตรวจ NG — คืน {wo_number, wo_id, repeat} หรือ None ถ้าไม่ต้องทำ"""
    ensure(db)
    cfg = get_settings(db)
    if not manual and (not cfg["enabled"] or cfg["mode"] == "manual"):
        return None
    if db.execute("SELECT 1 FROM cs_cmms_wo WHERE submission_id=?", (sub_id,)).fetchone():
        return None                                                    # เปิดไปแล้ว
    s, ng = _ng_items(db, sub_id, only_critical=(cfg["mode"] == "critical" and not manual))
    if not s or not ng:
        if manual:
            raise ValidationError("ผลตรวจนี้ไม่มีหัวข้อ NG")
        return None
    eq_id = s["equipment_id"] or s["f_eq"]
    eq = db.execute("SELECT e.*, a.name AS area_name, fa.name AS factory_name FROM equipment e "
                    "LEFT JOIN areas a ON a.id=e.area_id LEFT JOIN factories fa ON fa.id=e.factory_id WHERE e.id=?",
                    (eq_id,)).fetchone() if eq_id else None
    if not eq or not eq["legacy_id"]:
        msg = "แบบฟอร์มนี้ไม่ได้ผูกเครื่องจักรที่มีใน UT-CMMS — เปิดใบแจ้งซ่อมไม่ได้"
        if manual:
            raise ValidationError(msg)
        log.info("cmms wo skipped sub=%s: %s", sub_id, msg)
        return None
    keys = [r["item_key"] for r in ng]
    now = S.now_dt()
    con = _connect(app_config)
    try:
        cmms_eq = con.execute("SELECT * FROM equipment WHERE id=?", (eq["legacy_id"],)).fetchone()
        if not cmms_eq:
            raise ValidationError(f"ไม่พบเครื่อง {eq['code']} ใน UT-CMMS")
        # NG ซ้ำ: เครื่องเดียวกันมีใบจากหัวข้อเดียวกันที่ยังไม่ปิด → เพิ่มบันทึกในใบเดิม
        for lk in db.execute("SELECT * FROM cs_cmms_wo WHERE equipment_id=? AND status IN ('pending','approved','in_progress') "
                             "ORDER BY id DESC", (eq_id,)).fetchall():
            if set(json.loads(lk["item_keys"] or "[]")) & set(keys):
                wo = con.execute("SELECT id, status, notes FROM work_orders WHERE id=?", (lk["wo_id"],)).fetchone()
                if wo and wo["status"] in OPEN:
                    note = (f"[{now:%d/%m/%Y %H:%M}] E-Checksheet พบ NG ซ้ำ: "
                            + "; ".join(f"{r['name']} = {r['value_text']}{(' ' + r['unit']) if r['unit'] else ''}" for r in ng))
                    con.execute("UPDATE work_orders SET notes=TRIM(COALESCE(notes,'') || char(10) || ?), updated_at=? WHERE id=?",
                                (note[:900], now.strftime("%Y-%m-%d %H:%M:%S"), wo["id"]))
                    con.commit()
                    db.execute("""INSERT INTO cs_cmms_wo(wo_id, wo_number, submission_id, form_id, equipment_id, item_keys, status,
                                  repeat_of, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                               (lk["wo_id"], lk["wo_number"], sub_id, s["form_id"], eq_id, json.dumps(keys), wo["status"],
                                lk["id"], actor_id, ts(now)))
                    _link_alerts(db, sub_id, keys, lk["wo_id"])
                    return {"wo_id": lk["wo_id"], "wo_number": lk["wo_number"], "repeat": True}
        crit = any(r["critical"] for r in ng)
        lines = []
        for r in ng:
            spec = ""
            if r["min_value"] is not None or r["max_value"] is not None:
                lo = "" if r["min_value"] is None else format(r["min_value"], "g")
                hi = "" if r["max_value"] is None else format(r["max_value"], "g")
                spec = f" (เกณฑ์ {lo}–{hi})"
            lines.append(f"- {r['name']}: {r['value_text'] or 'NG'}{(' ' + r['unit']) if r['unit'] else ''}{spec}"
                         + (f" · {r['remark']}" if r["remark"] else ""))
        link = f"{base_url.rstrip('/')}/submissions/{sub_id}" if base_url else f"ผลตรวจ #{sub_id}"
        title = f"[E-Checksheet NG] {eq['code']} {ng[0]['name']}" + (f" +{len(ng) - 1}" if len(ng) > 1 else "")
        desc = (f"พบ NG จากการตรวจเช็ค {s['form_name']} ({s['form_code'] or ''}) {len(ng)} หัวข้อ\n" + "\n".join(lines)
                + f"\nผู้ตรวจ: {s['inspector_name'] or '-'} · เวลา {s['finished_at']}\nดูผลตรวจ: {link}")
        due = (now.date() + timedelta(days=int(cfg["due_days_critical"] if crit else cfg["due_days"]))).isoformat()
        requester = _requester(db, con, s["inspector_id"], cfg)
        stamp = now.strftime("%Y-%m-%d %H:%M:%S")
        wo_number, wid = None, None
        for _ in range(8):                                    # เลขชนกับการเปิดใบพร้อมกันใน UT-CMMS → ขอเลขใหม่
            wo_number = _gen_wo_number(con)
            try:
                cur = con.execute("""INSERT INTO work_orders
                    (wo_number, equipment_id, title, description, priority, status, requested_by, due_date, created_at, updated_at,
                     department, repair_type, repair_category, line_no, mc_no, data_entry_by, reporter_name, factory, work_window)
                    VALUES (?,?,?,?,?, 'pending', ?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (wo_number, cmms_eq["id"], title[:200], desc[:4000], "critical" if crit else "high", requester, due,
                     stamp, stamp, cfg["department"], cfg["repair_type"], cfg["repair_category"],
                     (eq["area_name"] or cmms_eq["location"] or "")[:60], eq["code"], "E-Checksheet",
                     s["inspector_name"] or "", cmms_eq["factory"] or (eq["factory_name"] or ""), cfg["work_window"]))
                wid = cur.lastrowid
                break
            except sqlite3.IntegrityError as exc:
                if "wo_number" not in str(exc):
                    raise
        if not wid:
            raise ValidationError("ออกเลขที่ใบแจ้งซ่อมไม่ได้ ลองใหม่อีกครั้ง")
        try:
            con.execute("INSERT INTO activity_log(user_id, action, target_type, target_id, details) VALUES (?,?,?,?,?)",
                        (requester, "create_wo", "work_orders", wid, f"E-Checksheet NG ผลตรวจ #{sub_id} → {wo_number}"))
        except sqlite3.Error:
            pass
        photos = _attach_photos(db, con, app_config, wid, sub_id, [r["answer_id"] for r in ng], requester) \
            if cfg["attach_photos"] else 0
        con.commit()
    finally:
        con.close()
    db.execute("""INSERT INTO cs_cmms_wo(wo_id, wo_number, submission_id, form_id, equipment_id, item_keys, status, created_by, created_at)
                  VALUES (?,?,?,?,?,?, 'pending', ?, ?)""",
               (wid, wo_number, sub_id, s["form_id"], eq_id, json.dumps(keys), actor_id, ts(now)))
    _link_alerts(db, sub_id, keys, wid)
    S.audit(db, actor_id, "create_wo", "cs_submissions", sub_id, after={"wo": wo_number, "items": keys, "photos": photos})
    hook = app_config.get("CMMS_WO_CREATED")          # portal.py: ให้ UT-CMMS ส่ง Telegram/อีเมลของใบใหม่ตามปกติ
    if callable(hook):
        try:
            hook(wid)
        except Exception:                             # noqa: BLE001 — แจ้งเตือนล้มเหลวไม่กระทบใบแจ้งซ่อม
            log.exception("cmms notify hook failed")
    return {"wo_id": wid, "wo_number": wo_number, "repeat": False, "photos": photos}


def create_generic(db, app_config, eq_id: int, title: str, desc: str, actor_id=None, priority: str = "high",
                   ref: str = "") -> dict:
    """v0.64 เปิดใบแจ้งซ่อม UT-CMMS จากงานอื่น (เช่น มิเตอร์เสียตอนจดมิเตอร์) — เครื่องต้องผูกกับ UT-CMMS"""
    ensure(db)
    cfg = get_settings(db)
    eq = db.execute("SELECT e.*, a.name AS area_name, fa.name AS factory_name FROM equipment e "
                    "LEFT JOIN areas a ON a.id=e.area_id LEFT JOIN factories fa ON fa.id=e.factory_id WHERE e.id=?",
                    (eq_id,)).fetchone()
    if not eq or not eq["legacy_id"]:
        raise ValidationError("เครื่อง/ตู้ที่ผูกไม่ได้เชื่อมกับ UT-CMMS — เปิดใบแจ้งซ่อมไม่ได้")
    now = S.now_dt()
    stamp = now.strftime("%Y-%m-%d %H:%M:%S")
    con = _connect(app_config)
    try:
        cmms_eq = con.execute("SELECT * FROM equipment WHERE id=?", (eq["legacy_id"],)).fetchone()
        if not cmms_eq:
            raise ValidationError(f"ไม่พบเครื่อง {eq['code']} ใน UT-CMMS")
        requester = _requester(db, con, actor_id, cfg)
        due = (now.date() + timedelta(days=int(cfg["due_days"]))).isoformat()
        u = db.execute("SELECT name FROM users WHERE id=?", (actor_id,)).fetchone() if actor_id else None
        wid = wo_number = None
        for _ in range(8):
            wo_number = _gen_wo_number(con)
            try:
                wid = con.execute("""INSERT INTO work_orders
                    (wo_number, equipment_id, title, description, priority, status, requested_by, due_date, created_at, updated_at,
                     department, repair_type, repair_category, line_no, mc_no, data_entry_by, reporter_name, factory, work_window)
                    VALUES (?,?,?,?,?, 'pending', ?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (wo_number, cmms_eq["id"], title[:200], desc[:4000], priority if priority in ("critical", "high", "medium", "low")
                     else "high", requester, due, stamp, stamp, cfg["department"], cfg["repair_type"], cfg["repair_category"],
                     (eq["area_name"] or cmms_eq["location"] or "")[:60], eq["code"], "Energy Data", (u["name"] if u else "") or "",
                     cmms_eq["factory"] or (eq["factory_name"] or ""), cfg["work_window"])).lastrowid
                break
            except sqlite3.IntegrityError as exc:
                if "wo_number" not in str(exc):
                    raise
        if not wid:
            raise ValidationError("ออกเลขที่ใบแจ้งซ่อมไม่ได้ ลองใหม่อีกครั้ง")
        try:
            con.execute("INSERT INTO activity_log(user_id, action, target_type, target_id, details) VALUES (?,?,?,?,?)",
                        (requester, "create_wo", "work_orders", wid, f"Energy Data {ref} → {wo_number}"))
        except sqlite3.Error:
            pass
        con.commit()
    finally:
        con.close()
    S.audit(db, actor_id, "create_wo", "equipment", eq_id, after={"wo": wo_number, "ref": ref})
    hook = app_config.get("CMMS_WO_CREATED")
    if callable(hook):
        try:
            hook(wid)
        except Exception:                             # noqa: BLE001
            log.exception("cmms notify hook failed")
    return {"wo_id": wid, "wo_number": wo_number}


def _link_alerts(db, sub_id: int, keys: list[str], wid: int) -> None:
    if keys:
        db.execute(f"UPDATE cs_alerts SET wo_id=? WHERE submission_id=? AND item_key IN ({','.join('?' * len(keys))})",
                   (wid, sub_id, *keys))


def _attach_photos(db, con, app_config, wid: int, sub_id: int, answer_ids: list[int], requester: int) -> int:
    dest = app_config.get("CMMS_UPLOAD_FOLDER")
    src_root = app_config.get("UPLOAD_FOLDER")
    if not dest or not src_root or not answer_ids:
        return 0
    rows = db.execute(f"SELECT file_path FROM cs_photos WHERE answer_id IN ({','.join('?' * len(answer_ids))}) LIMIT 5",
                      answer_ids).fetchall()
    n = 0
    for r in rows:
        src = os.path.join(src_root, r["file_path"])
        if not os.path.exists(src):
            continue
        ext = os.path.splitext(src)[1].lower().lstrip(".") or "jpg"
        name = f"wo{wid}_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:8]}.{ext}"
        try:
            os.makedirs(dest, exist_ok=True)
            shutil.copyfile(src, os.path.join(dest, name))
            con.execute("""INSERT INTO wo_attachments (wo_id, filename, original_name, file_type, file_size, uploaded_by)
                           VALUES (?,?,?,?,?,?)""", (wid, name, f"echeck_{sub_id}_{n + 1}.{ext}", ext,
                                                    os.path.getsize(src), requester))
            n += 1
        except (OSError, sqlite3.Error):
            log.exception("copy photo to UT-CMMS failed")
    return n


def after_submit(db, app_config, sub_id: int, actor_id, base_url: str = "") -> dict | None:
    """เรียกหลังบันทึกผลตรวจ — ล้มเหลวต้องไม่กระทบการส่งผลตรวจ"""
    if not available(app_config):
        return None
    try:
        res = create_for_submission(db, app_config, sub_id, actor_id, base_url=base_url)
        db.commit()
        return res
    except Exception:                                   # noqa: BLE001
        db.rollback()
        log.exception("auto WO failed for submission %s", sub_id)
        return None


# ───────────────────────── สถานะย้อนกลับ ─────────────────────────

def sync_status(db, app_config, now: datetime | None = None) -> dict:
    """อ่านสถานะใบแจ้งซ่อมที่ยังเปิดอยู่ → อัปเดต E-Checksheet (เรียกจาก jobs)"""
    ensure(db)
    stat = {"checked": 0, "changed": 0, "closed": 0}
    links = [dict(r) for r in db.execute("SELECT * FROM cs_cmms_wo WHERE status IN ('pending','approved','in_progress') "
                                         "OR (status IN ('completed','cancelled') AND applied_at IS NULL)")]
    if not links or not available(app_config):
        return stat
    now = now or S.now_dt()
    con = _connect(app_config)
    try:
        ids = sorted({lk["wo_id"] for lk in links})
        wos = {r["id"]: dict(r) for r in con.execute(
            f"""SELECT w.id, w.status, w.root_cause, w.action_taken, w.completed_at, w.repaired_by, u.name AS assignee
                FROM work_orders w LEFT JOIN users u ON u.id=w.assignee_id WHERE w.id IN ({','.join('?' * len(ids))})""", ids)}
    finally:
        con.close()
    for lk in links:
        stat["checked"] += 1
        wo = wos.get(lk["wo_id"])
        if not wo:
            wo = {"status": "cancelled", "root_cause": "", "action_taken": "ใบแจ้งซ่อมถูกลบใน UT-CMMS", "assignee": "",
                  "completed_at": None, "repaired_by": ""}
        changed = wo["status"] != lk["status"] or (wo.get("assignee") or "") != (lk["assignee"] or "")
        closed = wo["status"] in ("completed", "cancelled")
        if changed:
            stat["changed"] += 1
            db.execute("""UPDATE cs_cmms_wo SET status=?, assignee=?, root_cause=?, action_taken=?, synced_at=?,
                          closed_at=COALESCE(closed_at, ?) WHERE id=?""",
                       (wo["status"], wo.get("assignee") or wo.get("repaired_by") or "", wo.get("root_cause") or "",
                        wo.get("action_taken") or "", ts(now), ts(now) if closed else None, lk["id"]))
        if closed and not lk["applied_at"]:
            _apply_closed(db, lk, wo, now)
            db.execute("UPDATE cs_cmms_wo SET applied_at=? WHERE id=?", (ts(now), lk["id"]))
            stat["closed"] += 1
    db.commit()
    return stat


def _apply_closed(db, lk: dict, wo: dict, now: datetime) -> None:
    """ใบแจ้งซ่อมปิดแล้ว → แจ้งเตือนของหัวข้อนั้นแก้ไขแล้ว · CAPA รอตรวจรับ · แจ้งผู้ที่เกี่ยวข้อง"""
    keys = json.loads(lk["item_keys"] or "[]")
    done = wo["status"] == "completed"
    detail = (f"ใบแจ้งซ่อม {lk['wo_number']} {'ซ่อมเสร็จ' if done else 'ถูกยกเลิก'} ใน UT-CMMS"
              + (f" · สาเหตุ: {wo['root_cause']}" if wo.get("root_cause") else "")
              + (f" · การแก้ไข: {wo['action_taken']}" if wo.get("action_taken") else ""))
    stamp = ts(now)
    if lk["submission_id"] and keys:
        ph = ",".join("?" * len(keys))
        for a in db.execute(f"SELECT id, status FROM cs_alerts WHERE submission_id=? AND item_key IN ({ph})",
                            (lk["submission_id"], *keys)).fetchall():
            db.execute("INSERT INTO cs_alert_events(alert_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
                       (a["id"], "cmms", None, detail[:1000], stamp))
            if done and a["status"] in ("open", "acknowledged", "in_progress"):
                db.execute("""UPDATE cs_alerts SET status='resolved', resolved_at=?, updated_at=?,
                              root_cause=CASE WHEN COALESCE(root_cause,'')='' THEN ? ELSE root_cause END,
                              action_taken=CASE WHEN COALESCE(action_taken,'')='' THEN ? ELSE action_taken END WHERE id=?""",
                           (stamp, stamp, (wo.get("root_cause") or "")[:1000],
                            (wo.get("action_taken") or f"ซ่อมตามใบแจ้งซ่อม {lk['wo_number']}")[:1000], a["id"]))
        for c in db.execute(f"SELECT id, status FROM cs_actions WHERE submission_id=? AND (item_key IN ({ph}) OR item_key='')",
                            (lk["submission_id"], *keys)).fetchall():
            db.execute("INSERT INTO cs_action_events(action_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
                       (c["id"], "comment", None, detail[:1000], stamp))
            if done and c["status"] in ("open", "in_progress"):
                db.execute("""UPDATE cs_actions SET status='done', done_at=?, updated_at=?,
                              action_taken=CASE WHEN COALESCE(action_taken,'')='' THEN ? ELSE action_taken END WHERE id=?""",
                           (stamp, stamp, (wo.get("action_taken") or f"ซ่อมตามใบแจ้งซ่อม {lk['wo_number']}")[:1000], c["id"]))
    try:
        from . import notify as N
        s = db.execute("SELECT s.inspector_id, f.factory_id, f.name FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id "
                       "WHERE s.id=?", (lk["submission_id"],)).fetchone() if lk["submission_id"] else None
        users = []
        if s:
            q = "SELECT * FROM users WHERE active=1 AND (id=? OR (role='supervisor' AND (factory_id IS NULL OR factory_id=?)))"
            users = [dict(u) for u in db.execute(q, (s["inspector_id"] or 0, s["factory_id"] or 0))]
        if users and not lk.get("repeat_of"):
            N._deliver(db, N.get_settings(db), "", {"users": users, "groups": []}, kind="cmms",
                       subject=f"{'✅' if done else '⛔'} {lk['wo_number']} {'ซ่อมเสร็จแล้ว' if done else 'ถูกยกเลิก'}",
                       body=detail, path=f"/submissions/{lk['submission_id']}", severity="info",
                       ref_key=f"cmms_wo_closed:{lk['id']}", now=now)
    except Exception:                                   # noqa: BLE001
        log.exception("notify closed WO failed")


def links_for_submission(db, sub_id: int) -> list[dict]:
    ensure(db)
    out = []
    for r in db.execute("SELECT * FROM cs_cmms_wo WHERE submission_id=? ORDER BY id", (sub_id,)):
        d = dict(r)
        d["items"] = json.loads(d["item_keys"] or "[]")
        d["status_th"] = STATUS_TH.get(d["status"], d["status"])
        d["status_class"] = STATUS_CLASS.get(d["status"], "b-none")
        out.append(d)
    return out


def recent_links(db, limit: int = 30) -> list[dict]:
    ensure(db)
    rows = db.execute("""SELECT w.*, e.code AS eq_code, f.name AS form_name FROM cs_cmms_wo w
                         LEFT JOIN equipment e ON e.id=w.equipment_id LEFT JOIN cs_forms f ON f.id=w.form_id
                         ORDER BY w.id DESC LIMIT ?""", (limit,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["status_th"] = STATUS_TH.get(d["status"], d["status"])
        d["status_class"] = STATUS_CLASS.get(d["status"], "b-none")
        out.append(d)
    return out
