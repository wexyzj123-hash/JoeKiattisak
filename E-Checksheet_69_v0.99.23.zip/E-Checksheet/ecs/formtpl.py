"""ecs/formtpl.py — แบบฟอร์มแม่แบบ: 1 แม่แบบ ใช้กับหลายเครื่อง แก้ครั้งเดียวมีผลทุกเครื่อง

- แม่แบบ (cs_forms.is_template=1) ไม่มีเครื่อง ไม่มีรอบตรวจ มีแค่หัวข้อ
- แบบฟอร์มลูก (cs_forms.template_id) = แบบฟอร์มปกติของแต่ละเครื่อง (รอบตรวจ ผลตรวจ แยกตามเครื่อง)
  หัวข้อมาจากแม่แบบเสมอ — Publish แม่แบบ → ทุกเครื่องได้เวอร์ชันใหม่อัตโนมัติ
- เกณฑ์เฉพาะเครื่อง (Min/Max/เตือน) ตั้งแยกได้ต่อเครื่อง (cs_template_overrides) ไม่หายเมื่อแม่แบบเปลี่ยน
- ผูกแบบฟอร์มเดิมเข้าแม่แบบ: หัวข้อชื่อเดียวกันใช้รหัสหัวข้อเดิมของเครื่อง → กราฟแนวโน้ม/มิเตอร์สะสมต่อเนื่อง
- v0.99.5 ปรับหัวข้อเฉพาะเครื่อง (แม่แบบไม่เปลี่ยน): ไม่ใช้บางหัวข้อของแม่แบบ (cs_template_overrides.excluded)
  และเพิ่มหัวข้อของเครื่องเอง (cs_template_local_items) — คงอยู่ทุกครั้งที่แม่แบบออกเวอร์ชันใหม่
"""
from __future__ import annotations

import re

from . import services as S
from .services import ValidationError, audit, ts


def _norm(name: str) -> str:
    return re.sub(r"[\s:：._\-]+", "", str(name or "")).lower()


def get_template(db, form: dict) -> dict | None:
    return S.get_form(db, form["template_id"]) if form and form.get("template_id") else None


def children(db, tpl_id: int) -> list[dict]:
    rows = db.execute("""
        SELECT f.id, f.code, f.name, f.active, f.equipment_id, e.code AS eq_code, e.name AS eq_name, e.eq_type,
               ar.name AS area_name, fa.name AS factory_name, v.version_no, v.template_version_id,
               tv.version_no AS tpl_version_no,
               (SELECT COUNT(*) FROM cs_template_overrides o WHERE o.form_id=f.id AND o.has_limits=1) AS override_count,
               (SELECT COUNT(*) FROM cs_template_overrides o WHERE o.form_id=f.id AND o.excluded=1) AS excluded_count,
               (SELECT COUNT(*) FROM cs_template_local_items li WHERE li.form_id=f.id) AS local_count,
               (SELECT COUNT(*) FROM cs_schedules s WHERE s.form_id=f.id AND s.active=1) AS schedule_count,
               (SELECT MAX(finished_at) FROM cs_submissions sb WHERE sb.form_id=f.id) AS last_submitted
        FROM cs_forms f
        LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN areas ar ON ar.id=f.area_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN cs_form_versions v ON v.id=f.current_version_id
        LEFT JOIN cs_form_versions tv ON tv.id=v.template_version_id
        WHERE f.template_id=? ORDER BY fa.sort_no, e.code, f.code""", (tpl_id,)).fetchall()
    return [dict(r) for r in rows]


def overrides(db, form_id: int) -> dict[str, dict]:
    return {r["template_key"]: dict(r) for r in db.execute(
        "SELECT * FROM cs_template_overrides WHERE form_id=?", (form_id,))}


def local_items(db, form_id: int) -> list[dict]:
    import json
    out = []
    for r in db.execute("SELECT * FROM cs_template_local_items WHERE form_id=? ORDER BY sort_no, created_at", (form_id,)):
        d = json.loads(r["data_json"])
        d.update(item_key=r["item_key"], sort_no=r["sort_no"])
        out.append(d)
    return out


def _require_template(db, tpl_id: int) -> dict:
    tpl = S.get_form(db, tpl_id)
    if not tpl or not tpl.get("is_template"):
        raise ValidationError("ไม่พบแม่แบบ")
    return tpl


def sync_child(db, child_id: int, actor_id: int | None, note: str = "") -> dict | None:
    """สร้างเวอร์ชันใหม่ของแบบฟอร์มลูกจากแม่แบบ (ใช้เกณฑ์เฉพาะเครื่องทับ) แล้ว Publish"""
    child = S.get_form(db, child_id)
    tpl = get_template(db, child)
    if not tpl or not tpl["current_version_id"]:
        return None
    tv = S.get_version(db, tpl["current_version_id"])
    items = S.get_items(db, tv["id"])
    ov = overrides(db, child_id)
    draft = S.get_draft(db, child_id)
    if draft:                                     # แบบฟอร์มลูกไม่มีฉบับร่างของตัวเอง
        db.execute("DELETE FROM cs_form_items WHERE version_id=?", (draft["id"],))
        db.execute("DELETE FROM cs_form_versions WHERE id=?", (draft["id"],))
    last_no = db.execute("SELECT COALESCE(MAX(version_no),0) FROM cs_form_versions WHERE form_id=?",
                         (child_id,)).fetchone()[0]
    vid = db.execute("""INSERT INTO cs_form_versions(form_id, version_no, status, created_by, created_at,
                            sections_json, template_version_id) VALUES (?,?,'draft',?,?,?,?)""",
                     (child_id, last_no + 1, actor_id, ts(), tv.get("sections_json") or "", tv["id"])).lastrowid
    cols = ("section", "order_no", "name", "item_type", "unit", "min_value", "max_value", "warn_low", "warn_high",
            "counter_max_step", "options_json", "required", "critical", "photo_on_ng", "guide", "check_freq",
            "check_times", "photo_required", "formula")
    from .formula import rename_refs
    kmap = {k: o["local_key"] for k, o in ov.items() if o.get("local_key")}
    rows = []
    for it in items:
        o = ov.get(it["item_key"]) or {}
        if o.get("excluded"):                           # v0.99.5 ไม่ใช้หัวข้อนี้กับเครื่องนี้ (แม่แบบยังมีอยู่)
            continue
        row = {c: it.get(c) for c in cols}
        if row.get("formula") and kmap:                 # v0.95 สูตรอ้างรหัสหัวข้อของเครื่องนี้
            row["formula"] = rename_refs(row["formula"], kmap)
        row["formula"] = row.get("formula") or ""
        if o.get("has_limits") and it["item_type"] in ("number", "counter", "calc"):
            row.update({k: o.get(k) for k in ("min_value", "max_value", "warn_low", "warn_high")})
        rows.append((o.get("local_key") or it["item_key"], row))
    for li in local_items(db, child_id):               # v0.99.5 หัวข้อเฉพาะเครื่อง → ต่อท้ายหมวดเดียวกัน (หมวดใหม่ไว้ท้ายสุด)
        row = {c: li.get(c) for c in cols}
        row["formula"] = ""
        pos = max((i for i, (_, r) in enumerate(rows) if (r.get("section") or "") == (li.get("section") or "")), default=len(rows) - 1)
        rows.insert(pos + 1, (li["item_key"], row))
    for n, (key, row) in enumerate(rows, 1):
        row["order_no"] = n
        db.execute(f"""INSERT INTO cs_form_items(version_id, item_key, {', '.join(cols)})
                       VALUES (?,?,{','.join('?' * len(cols))})""", (vid, key, *[row[c] for c in cols]))
    msg = f"ตามแม่แบบ {tpl['code']} v{tv['version_no']}" + (f": {note}" if note else "")
    return S.publish_version(db, vid, actor_id, msg, tv.get("effective_date"), tv.get("approved_by_name") or "")


def sync_all(db, tpl_id: int, actor_id: int | None, note: str = "") -> int:
    n = 0
    for c in children(db, tpl_id):
        if sync_child(db, c["id"], actor_id, note):
            n += 1
    return n


def make_template(db, source_id: int, actor_id: int | None, name: str = "") -> int:
    """สร้างแม่แบบจากแบบฟอร์มที่มีอยู่ (คัดลอกหัวข้อ) แล้วผูกแบบฟอร์มต้นฉบับเป็นลูก"""
    src = S.get_form(db, source_id)
    if not src or not src["current_version_id"]:
        raise ValidationError("แบบฟอร์มต้นฉบับต้อง Publish แล้ว")
    if src.get("is_template") or src.get("template_id"):
        raise ValidationError("แบบฟอร์มนี้เป็นแม่แบบ/ใช้แม่แบบอยู่แล้ว")
    tpl_name = (name or "").strip() or re.sub(r"\s*[-–—]?\s*" + re.escape(src.get("eq_code") or "\u0000") + r"\s*$", "",
                                               src["name"]).strip() or src["name"]
    tpl_id = S.create_form(db, {"name": tpl_name, "description": src.get("description") or "",
                                "category": src.get("category")}, actor_id)
    db.execute("UPDATE cs_forms SET is_template=1, doc_no=? WHERE id=?", (src.get("doc_no") or "", tpl_id))
    draft = S.get_draft(db, tpl_id)
    S._copy_items(db, src["current_version_id"], draft["id"])
    S.publish_version(db, draft["id"], actor_id, f"สร้างจากแบบฟอร์ม {src['code']}")
    link_forms(db, tpl_id, [source_id], actor_id, sync=False)   # หัวข้อเหมือนกันอยู่แล้ว ยังไม่ต้องออกเวอร์ชันใหม่
    audit(db, actor_id, "make_template", "cs_forms", tpl_id, after={"source": source_id})
    return tpl_id


def new_template(db, data: dict, actor_id: int | None) -> int:
    tpl_id = S.create_form(db, {"name": data.get("name"), "description": data.get("description") or "",
                                "category": data.get("category")}, actor_id)
    db.execute("UPDATE cs_forms SET is_template=1 WHERE id=?", (tpl_id,))
    return tpl_id


def link_forms(db, tpl_id: int, form_ids: list[int], actor_id: int | None, sync: bool = True) -> int:
    """ผูกแบบฟอร์มเดิมเข้าแม่แบบ — หัวข้อชื่อเดียวกันใช้รหัสหัวข้อเดิม (ประวัติ/กราฟต่อเนื่อง)"""
    tpl = _require_template(db, tpl_id)
    t_items = S.get_items(db, tpl["current_version_id"]) if tpl["current_version_id"] else []
    n = 0
    for fid in form_ids:
        f = S.get_form(db, fid)
        if not f or f.get("is_template") or f["id"] == tpl_id:
            continue
        own = {_norm(i["name"]): i for i in (S.get_items(db, f["current_version_id"]) if f["current_version_id"] else [])}
        db.execute("DELETE FROM cs_template_overrides WHERE form_id=?", (fid,))
        for it in t_items:
            mine = own.get(_norm(it["name"]))
            if not mine:
                continue
            limits = mine["item_type"] in ("number", "counter", "calc") and it["item_type"] in ("number", "counter", "calc") and any(
                mine.get(k) != it.get(k) for k in ("min_value", "max_value", "warn_low", "warn_high"))
            db.execute("""INSERT INTO cs_template_overrides(form_id, template_key, local_key, has_limits,
                              min_value, max_value, warn_low, warn_high) VALUES (?,?,?,?,?,?,?,?)""",
                       (fid, it["item_key"], mine["item_key"] if mine["item_key"] != it["item_key"] else "",
                        1 if limits else 0, mine.get("min_value"), mine.get("max_value"),
                        mine.get("warn_low"), mine.get("warn_high")))
        db.execute("UPDATE cs_forms SET template_id=?, updated_at=? WHERE id=?", (tpl_id, ts(), fid))
        if sync:
            sync_child(db, fid, actor_id, "ผูกเข้าแม่แบบ")
        push_schedules(db, tpl_id, actor_id, child_ids=[fid])
        n += 1
    return n


def apply_to_equipment(db, tpl_id: int, equipment_ids: list[int], actor_id: int | None,
                       schedule: dict | None = None) -> dict:
    """สร้างแบบฟอร์มลูกให้เครื่องที่เลือก (ข้ามเครื่องที่มีแบบฟอร์มจากแม่แบบนี้อยู่แล้ว)"""
    tpl = _require_template(db, tpl_id)
    if not tpl["current_version_id"]:
        raise ValidationError("แม่แบบยังไม่ Publish — เพิ่มหัวข้อแล้ว Publish ก่อน")
    if not equipment_ids:
        raise ValidationError("เลือกเครื่องจักรอย่างน้อย 1 เครื่อง")
    have = {r[0] for r in db.execute("SELECT equipment_id FROM cs_forms WHERE template_id=?", (tpl_id,))}
    created, skipped = [], []
    for eid in dict.fromkeys(equipment_ids):
        eq = db.execute("SELECT id, code, name FROM equipment WHERE id=?", (eid,)).fetchone()
        if not eq:
            continue
        if eq["id"] in have:
            skipped.append(eq["code"])
            continue
        fid = S.create_form(db, {"name": f"{tpl['name']} {eq['code']}", "description": tpl.get("description") or "",
                                 "equipment_id": eq["id"], "category": tpl.get("category")}, actor_id)
        db.execute("DELETE FROM cs_form_versions WHERE form_id=? AND status='draft'", (fid,))
        db.execute("UPDATE cs_forms SET template_id=?, doc_no=? WHERE id=?", (tpl_id, tpl.get("doc_no") or "", fid))
        sync_child(db, fid, actor_id)
        push_schedules(db, tpl_id, actor_id, child_ids=[fid])       # รอบตรวจที่ตั้งไว้ในแม่แบบ
        if schedule and schedule.get("times"):
            S.create_schedule(db, fid, schedule, actor_id)
        created.append(eq["code"])
    audit(db, actor_id, "apply_template", "cs_forms", tpl_id, after={"created": created, "skipped": skipped})
    return {"created": created, "skipped": skipped}


def detach(db, child_id: int, actor_id: int | None) -> None:
    db.execute("UPDATE cs_forms SET template_id=NULL, updated_at=? WHERE id=?", (ts(), child_id))
    db.execute("DELETE FROM cs_template_overrides WHERE form_id=?", (child_id,))
    db.execute("DELETE FROM cs_template_local_items WHERE form_id=?", (child_id,))   # หัวข้อเฉพาะเครื่องอยู่ในเวอร์ชันปัจจุบันแล้ว
    db.execute("UPDATE cs_schedules SET tpl_schedule_id=NULL WHERE form_id=?", (child_id,))   # รอบที่สืบทอดกลายเป็นของเครื่องเอง
    audit(db, actor_id, "detach_template", "cs_forms", child_id)


def save_overrides(db, child_id: int, data: dict, actor_id: int | None) -> int:
    """data = {template_key: {min_value, max_value, warn_low, warn_high, use: bool}} → บันทึกแล้วออกเวอร์ชันใหม่"""
    child = S.get_form(db, child_id)
    tpl = get_template(db, child)
    if not tpl:
        raise ValidationError("แบบฟอร์มนี้ไม่ได้ใช้แม่แบบ")
    t_items = {i["item_key"]: i for i in S.get_items(db, tpl["current_version_id"])}
    cur = overrides(db, child_id)
    errors, n = [], 0
    for key, d in data.items():
        it = t_items.get(key)
        if not it or it["item_type"] not in ("number", "counter", "calc"):
            continue
        use = bool(d.get("use"))
        vals = {k: S._num(d.get(k)) for k in ("min_value", "max_value", "warn_low", "warn_high")}
        if use:
            test = dict(it, **vals)
            try:
                S.normalize_item(test)
            except ValidationError as exc:
                errors += [f"{it['name']}: {e.split(': ', 1)[-1]}" for e in exc.errors]
                continue
            n += 1
        local = (cur.get(key) or {}).get("local_key") or ""
        db.execute("""INSERT INTO cs_template_overrides(form_id, template_key, local_key, has_limits, min_value,
                          max_value, warn_low, warn_high) VALUES (?,?,?,?,?,?,?,?)
                      ON CONFLICT(form_id, template_key) DO UPDATE SET has_limits=excluded.has_limits,
                          min_value=excluded.min_value, max_value=excluded.max_value,
                          warn_low=excluded.warn_low, warn_high=excluded.warn_high""",
                   (child_id, key, local, 1 if use else 0, vals["min_value"], vals["max_value"],
                    vals["warn_low"], vals["warn_high"]))
    if errors:
        raise ValidationError(errors)
    sync_child(db, child_id, actor_id, "ปรับเกณฑ์เฉพาะเครื่อง")
    return n


# ───────────────────────── v0.99.5 ปรับหัวข้อเฉพาะเครื่อง (แม่แบบไม่เปลี่ยน) ─────────────────────────

LOCAL_TYPES = ("ok_ng", "number", "counter", "choice", "text")


def _child_and_tpl(db, child_id: int) -> tuple[dict, dict]:
    child = S.get_form(db, child_id)
    tpl = get_template(db, child)
    if not tpl or not tpl["current_version_id"]:
        raise ValidationError("แบบฟอร์มนี้ไม่ได้ใช้แม่แบบ")
    return child, tpl


def set_excluded(db, child_id: int, excluded_keys, actor_id: int | None) -> dict:
    """กำหนดหัวข้อของแม่แบบที่ไม่ใช้กับเครื่องนี้ (ชุดเต็ม) → ออกเวอร์ชันใหม่ให้เครื่องนี้เท่านั้น"""
    from .formula import refs
    _, tpl = _child_and_tpl(db, child_id)
    t_items = S.get_items(db, tpl["current_version_id"])
    t_keys = {i["item_key"] for i in t_items}
    want = {k for k in excluded_keys if k in t_keys}
    cur = overrides(db, child_id)
    before = {k for k, o in cur.items() if o.get("excluded")}
    if want == before:
        return {"excluded": len(want), "changed": False}
    if len(want) >= len(t_items) and not local_items(db, child_id):
        raise ValidationError("ต้องเหลือหัวข้อตรวจอย่างน้อย 1 หัวข้อ")
    names = {i["item_key"]: i["name"] for i in t_items}
    errors = []
    for it in t_items:                                  # สูตรของหัวข้อที่ยังใช้ ต้องไม่อ้างหัวข้อที่เอาออก
        if it["item_key"] in want or not it.get("formula"):
            continue
        try:
            gone = [r for r in refs(it["formula"]) if r in want]
        except Exception:                               # noqa: BLE001 — สูตรเสียไม่ใช่เรื่องของขั้นตอนนี้
            gone = []
        if gone:
            errors.append(f"'{it['name']}' คำนวณจาก {', '.join(repr(names[g]) for g in gone)} — "
                          f"ต้องไม่ใช้ '{it['name']}' ด้วย หรือคงหัวข้อนั้นไว้")
    if errors:
        raise ValidationError(errors)
    for k in t_keys:
        ex = 1 if k in want else 0
        if k in cur:
            if (cur[k].get("excluded") or 0) != ex:
                db.execute("UPDATE cs_template_overrides SET excluded=? WHERE form_id=? AND template_key=?", (ex, child_id, k))
        elif ex:
            db.execute("INSERT INTO cs_template_overrides(form_id, template_key, excluded) VALUES (?,?,1)", (child_id, k))
    audit(db, actor_id, "local_exclude", "cs_forms", child_id,
          before={"excluded": sorted(names.get(k, k) for k in before)}, after={"excluded": sorted(names[k] for k in want)})
    sync_child(db, child_id, actor_id, f"เฉพาะเครื่องนี้: ไม่ใช้ {len(want)} หัวข้อของแม่แบบ" if want else "เฉพาะเครื่องนี้: ใช้หัวข้อของแม่แบบครบ")
    return {"excluded": len(want), "changed": True}


def save_local_item(db, child_id: int, raw: dict, actor_id: int | None, item_key: str = "") -> str:
    """เพิ่ม/แก้หัวข้อเฉพาะเครื่อง (รหัสหัวข้อคงเดิมเมื่อแก้ → ประวัติ/กราฟต่อเนื่อง)"""
    import json
    _, tpl = _child_and_tpl(db, child_id)
    if str(raw.get("item_type") or "") not in LOCAL_TYPES:
        raise ValidationError("ประเภทหัวข้อเฉพาะเครื่องต้องเป็น OK/NG · ตัวเลข · มิเตอร์สะสม · ตัวเลือก · ข้อความ")
    have = {li["item_key"]: li for li in local_items(db, child_id)}
    if item_key and item_key not in have:
        raise ValidationError("ไม่พบหัวข้อเฉพาะเครื่องนี้")
    raw = dict(raw, item_key=item_key or S.new_item_key())
    it = S.normalize_item(raw)
    t_names = {_norm(i["name"]) for i in S.get_items(db, tpl["current_version_id"])}
    others = {_norm(li["name"]) for k, li in have.items() if k != it["item_key"]}
    if _norm(it["name"]) in t_names | others:
        raise ValidationError(f"มีหัวข้อชื่อ '{it['name']}' อยู่แล้ว")
    data = {k: it[k] for k in ("section", "name", "item_type", "unit", "min_value", "max_value", "warn_low", "warn_high",
                               "counter_max_step", "options_json", "required", "critical", "photo_on_ng", "photo_required",
                               "guide", "check_freq", "check_times")}
    js = json.dumps(data, ensure_ascii=False)
    if item_key:
        db.execute("UPDATE cs_template_local_items SET data_json=?, updated_at=? WHERE form_id=? AND item_key=?",
                   (js, ts(), child_id, item_key))
    else:
        nxt = db.execute("SELECT COALESCE(MAX(sort_no),0)+1 FROM cs_template_local_items WHERE form_id=?", (child_id,)).fetchone()[0]
        db.execute("""INSERT INTO cs_template_local_items(form_id, item_key, sort_no, data_json, created_by, created_at, updated_at)
                      VALUES (?,?,?,?,?,?,?)""", (child_id, it["item_key"], nxt, js, actor_id, ts(), ts()))
    audit(db, actor_id, "local_item_edit" if item_key else "local_item_add", "cs_forms", child_id,
          before=have.get(item_key), after=dict(data, item_key=it["item_key"]))
    sync_child(db, child_id, actor_id, ("แก้" if item_key else "เพิ่ม") + f"หัวข้อเฉพาะเครื่อง: {it['name']}")
    return it["item_key"]


def delete_local_item(db, child_id: int, item_key: str, actor_id: int | None) -> None:
    _, tpl = _child_and_tpl(db, child_id)
    have = {li["item_key"]: li for li in local_items(db, child_id)}
    if item_key not in have:
        raise ValidationError("ไม่พบหัวข้อเฉพาะเครื่องนี้")
    used = sum(1 for i in S.get_items(db, tpl["current_version_id"])
               if not (overrides(db, child_id).get(i["item_key"]) or {}).get("excluded"))
    if used + len(have) - 1 < 1:
        raise ValidationError("ต้องเหลือหัวข้อตรวจอย่างน้อย 1 หัวข้อ")
    db.execute("DELETE FROM cs_template_local_items WHERE form_id=? AND item_key=?", (child_id, item_key))
    audit(db, actor_id, "local_item_delete", "cs_forms", child_id, before=have[item_key])
    sync_child(db, child_id, actor_id, f"ลบหัวข้อเฉพาะเครื่อง: {have[item_key]['name']}")


# ───────────────────────── รอบตรวจของแม่แบบ → ทุกเครื่องที่ใช้แม่แบบ ─────────────────────────

_SCHED_KEYS = ("freq_type", "times", "weekdays", "month_day", "window_min", "skip_holidays",
               "assignee_role", "assignee_user_id", "active", "anchor_date")


def _sched_data(row) -> dict:
    return {k: row[k] for k in _SCHED_KEYS}


def push_schedules(db, tpl_id: int, actor_id: int | None, replace_own: bool = False,
                   child_ids: list[int] | None = None) -> dict:
    """ทำให้รอบตรวจของเครื่องลูกตรงกับรอบตรวจของแม่แบบ
    - รอบที่สืบทอด (tpl_schedule_id) สร้าง/แก้/ปิด ตามแม่แบบ
    - replace_own=True: ปิดรอบตรวจที่ตั้งเองของแต่ละเครื่องด้วย (ให้ทุกเครื่องใช้รอบของแม่แบบเท่านั้น)"""
    _require_template(db, tpl_id)
    tpl_sched = {r["id"]: dict(r) for r in db.execute("SELECT * FROM cs_schedules WHERE form_id=?", (tpl_id,))}
    active_ids = {i for i, r in tpl_sched.items() if r["active"]}
    kids = child_ids if child_ids is not None else [c["id"] for c in children(db, tpl_id)]
    stat = {"created": 0, "updated": 0, "closed": 0, "forms": len(kids)}
    for cid in kids:
        own = [dict(r) for r in db.execute("SELECT * FROM cs_schedules WHERE form_id=? AND active=1", (cid,))]
        inherited = {r["tpl_schedule_id"]: r for r in own if r.get("tpl_schedule_id")}
        for sid in active_ids:
            want = _sched_data(tpl_sched[sid])
            have = inherited.get(sid)
            if not have:                                # เครื่องตั้งรอบเดียวกันไว้เองแล้ว → ใช้รอบนั้นแทน (ไม่สร้างรอบซ้ำ)
                same = next((r for r in own if not r.get("tpl_schedule_id") and all(
                    str(r[k] or "") == str(want[k] or "") for k in ("freq_type", "times", "weekdays", "month_day"))), None)
                if same:
                    db.execute("UPDATE cs_schedules SET tpl_schedule_id=? WHERE id=?", (sid, same["id"]))
                    same["tpl_schedule_id"] = sid
                    have = same
            if not have:
                new_id = S.create_schedule(db, cid, want, actor_id)
                db.execute("UPDATE cs_schedules SET tpl_schedule_id=? WHERE id=?", (sid, new_id))
                stat["created"] += 1
            elif any(str(have[k] or "") != str(want[k] or "") for k in _SCHED_KEYS):
                S.update_schedule(db, have["id"], want, actor_id)
                stat["updated"] += 1
        for r in own:
            gone = r.get("tpl_schedule_id") and r["tpl_schedule_id"] not in active_ids
            if gone or (replace_own and not r.get("tpl_schedule_id")):
                S.delete_schedule(db, r["id"], actor_id)
                stat["closed"] += 1
    return stat
