"""ecs/energy_manage.py — v0.90 บริหารพลังงานจากค่าจดมิเตอร์ดิบ (ตัวคำนวณเดียวกับทุกหน้า)

build() → ข้อมูลชุดเดียวที่หน้า “บริหาร” และแผง “หน่วยงาน & ไลน์” บน Dashboard ใช้ร่วมกัน
  matrix      โรงงาน × ประเภท: ยอดเดือนนี้ · เทียบช่วงเดียวกันเดือนก่อน · ค่าใช้จ่าย · เฉลี่ย/วัน · ความครบของการจด
  tree        ต่อประเภท: โรงงาน → หน่วยงาน (Section) → ไลน์ — ยอด · สัดส่วน · เทียบเดือนก่อน · แนวโน้มรายวัน
              + แถว “ไม่ได้วัด/สูญเสีย” = มิเตอร์หลักรวม − ผลรวมหน่วยงาน
  balance     มิเตอร์หลัก vs ผลรวมมิเตอร์ย่อยที่ครอบ (EN.balance)
  complete    ความครบของการจด: ค่าที่ควรมี/มีจริง · มิเตอร์ที่ขาด · ค่าเพี้ยน/ลดลง/ค่าค้าง
ทุกยอดใช้ EN.series (การใช้รายวัน) + EN.counted (ไม่นับซ้ำหลัก+ย่อย) — ตัวเลขจึงตรงกับ Dashboard/ตาราง/รายงาน/ต้นทุน
"""
from __future__ import annotations

from datetime import date, timedelta

from . import energy as EN
from . import masterdata as M
from . import services as S

NO_SEC, NO_LINE = "ไม่ระบุหน่วยงาน", "ไม่ระบุไลน์"


def _price_fn(db, cfg: dict, month: date):
    rates: dict = {}

    def price(m: dict) -> float:
        if m.get("price") is not None:
            return float(m["price"])
        kp = EN.KINDS.get(m["kind"], {}).get("price")
        if kp is not None:
            return float(kp)
        if m["kind"] == "elec":
            if m["factory_id"] not in rates:
                rates[m["factory_id"]] = EN._rate(db, m["factory_id"], month, cfg)
            return rates[m["factory_id"]]
        return 0.0
    return price


def _sum(ms: list[dict], val: dict) -> float:
    return round(sum(EN.sign(m) * (val.get(m["id"]) or 0) for m in EN.counted(ms)), 2)


def _vec(ms: list[dict], daily: dict, n: int) -> list[float]:
    cm = EN.counted(ms)
    return [round(sum(EN.sign(m) * (daily[m["id"]][i] or 0) for m in cm), 2) for i in range(n)]


def _chg(a: float, b: float) -> float | None:
    return round(100 * (a - b) / b, 1) if b else None


def build(db, month: date, fid: int | None = None, today: date | None = None, kinds: list[str] | None = None,
          project_id=None, grp=None, line=None) -> dict:
    EN.ensure(db)
    cfg = EN.settings(db)
    today = today or S.now_dt().date()
    d_from, d_to = EN.month_bounds(month)
    d_end = min(d_to, today)
    days = EN._days(d_from, d_end) if d_end >= d_from else []
    p_from = (d_from - timedelta(days=1)).replace(day=1)
    p_to = min(EN.month_bounds(p_from)[1], p_from + timedelta(days=max(0, (d_end - d_from).days)))
    ms_all = EN.meters(db, fid, None, True, project_id, grp, line)
    if kinds:
        ms_all = [m for m in ms_all if m["kind"] in kinds]
    ser = EN.series(db, ms_all, d_from, d_end) if ms_all and days else {}
    ser_p = EN.series(db, ms_all, p_from, p_to) if ms_all and days else {}
    use = {m["id"]: sum((x.get("u") or 0) for x in (ser.get(m["id"]) or {}).values()) for m in ms_all}
    pre = {m["id"]: sum((x.get("u") or 0) for x in (ser_p.get(m["id"]) or {}).values()) for m in ms_all}
    daily = {m["id"]: [((ser.get(m["id"]) or {}).get(d) or {}).get("u") for d in days] for m in ms_all}
    price = _price_fn(db, cfg, d_from)
    money = {m["id"]: use[m["id"]] * price(m) for m in ms_all}
    # วันอ้างอิง = วันล่าสุดที่มีการใช้ (นับตามวันที่ใช้จริง วันนี้จะมีค่าเมื่อมีค่าอ่านพรุ่งนี้)
    ref_i = None
    for i in range(len(days) - 1, -1, -1):
        if any(daily[m["id"]][i] is not None for m in ms_all):
            ref_i = i
            break
    if ref_i is not None:                                # v0.92 เทียบช่วงเดียวกันเท่าจำนวนวันที่มีข้อมูลจริง
        p_to = min(p_to, p_from + timedelta(days=ref_i))
        lim = p_to.isoformat()
        pre = {m["id"]: sum((x.get("u") or 0) for d, x in (ser_p.get(m["id"]) or {}).items() if d <= lim) for m in ms_all}
    facs = [f for f in M.list_factories(db) if not fid or f["id"] == fid]
    comp = completeness(db, ms_all, d_from, d_end, today, ser)
    kinds_out, matrix = [], []
    for k in EN.KIND_ORDER:
        km = [m for m in ms_all if m["kind"] == k]
        if not km:
            continue
        meta = EN.KINDS[k]
        unit = km[0]["unit"] or meta["unit"]
        fac_rows = []
        for f in facs:
            fm = [m for m in km if m["factory_id"] == f["id"]]
            if not fm:
                continue
            tot, prv = _sum(fm, use), _sum(fm, pre)
            fmains = EN.factory_mains(fm)
            secs: dict[str, list] = {}
            for m in fm:
                if m["id"] not in fmains:
                    secs.setdefault((m["grp"] or "").strip() or NO_SEC, []).append(m)
            sec_rows = []
            for g, lst in secs.items():
                if not EN.counted(lst):                    # ทั้ง Section เป็น “ไม่นับรวม” (เช่น น้ำเสีย) → ไม่ใช่การใช้
                    continue
                lines: dict[str, list] = {}
                cvs = EN.covers(lst)
                tops = {x for c in cvs.values() for x in c}       # มิเตอร์หลักของ Section → ไม่ใช่ไลน์ (ไลน์ = สิ่งที่อยู่ใต้หลัก)
                for m in lst:
                    if m["id"] in tops:
                        continue
                    lines.setdefault((m.get("line") or "").strip() or NO_LINE, []).append(m)
                u = _sum(lst, use)
                lrows = []
                if len(lines) > 1 or NO_LINE not in lines:
                    for ln, ll in lines.items():
                        if not EN.counted(ll):
                            continue
                        lu = _sum(ll, use)
                        lrows.append({"name": ln, "u": lu, "prev": _sum(ll, pre), "chg": _chg(lu, _sum(ll, pre)),
                                      "share": round(100 * lu / u, 1) if u else None, "n": len(ll),
                                      "ref": _vec(ll, daily, len(days))[ref_i] if ref_i is not None else None,
                                      "ids": [m["id"] for m in ll]})
                    lrows.sort(key=lambda x: (x["name"] == NO_LINE, -x["u"]))
                pv = _sum(lst, pre)
                vec = _vec(lst, daily, len(days))
                sec_rows.append({"name": g, "u": u, "prev": pv, "chg": _chg(u, pv), "share": round(100 * u / tot, 1) if tot else None,
                                 "n": len(lst), "lines": lrows, "spark": vec[-14:], "ref": vec[ref_i] if ref_i is not None else None,
                                 "cost": round(sum(EN.sign(m) * money[m["id"]] for m in EN.counted(lst)), 0),
                                 "missing": sum(1 for m in lst if comp["by_meter"].get(m["id"], {}).get("miss"))})
            sec_rows.sort(key=lambda x: (x["name"] == NO_SEC, -x["u"]))
            sec_sum = round(sum(s["u"] for s in sec_rows), 2)
            for s in sec_rows:                             # สัดส่วนเทียบผลรวมหน่วยงาน (ส่วนต่างกับมิเตอร์หลักแสดงแยกเป็นแถว “ไม่ได้วัด”)
                s["share"] = round(100 * s["u"] / sec_sum, 1) if sec_sum > 0 else None
            loss = round(tot - sec_sum, 2) if fmains else None
            fvec = _vec(fm, daily, len(days))
            cost = round(sum(EN.sign(m) * money[m["id"]] for m in EN.counted(fm)), 0)
            c = comp["by_fk"].get((f["id"], k), {"expect": 0, "have": 0})
            row = {"fid": f["id"], "factory": f["name"], "u": tot, "prev": prv, "chg": _chg(tot, prv), "cost": cost,
                   "avg": round(tot / len([x for x in fvec if x]), 2) if any(fvec) else None, "daily": fvec,
                   "ref": fvec[ref_i] if ref_i is not None else None, "sections": sec_rows, "loss": loss,
                   "loss_pct": round(100 * loss / tot, 1) if loss is not None and tot else None,
                   "n": len(fm), "complete": round(100 * c["have"] / c["expect"], 1) if c["expect"] else None,
                   "balance": EN.balance(fm, use)}
            fac_rows.append(row)
            matrix.append({"kind": k, **{x: row[x] for x in ("fid", "factory", "u", "prev", "chg", "cost", "avg", "complete", "n", "ref")}})
        if fac_rows:
            kinds_out.append({"kind": k, **meta, "unit": unit, "factories": fac_rows, "u": round(sum(r["u"] for r in fac_rows), 2),
                              "prev": round(sum(r["prev"] for r in fac_rows), 2), "cost": round(sum(r["cost"] for r in fac_rows), 0)})
            kinds_out[-1]["chg"] = _chg(kinds_out[-1]["u"], kinds_out[-1]["prev"])
    return {"month": d_from, "d_from": d_from, "d_end": d_end, "days": days, "ref_day": days[ref_i] if ref_i is not None else None,
            "p_from": p_from, "p_to": p_to, "kinds": kinds_out, "matrix": matrix, "facs": facs, "complete": comp,
            "cost": round(sum(k["cost"] for k in kinds_out), 0)}


def completeness(db, ms: list[dict], d_from: date, d_end: date, today: date, ser: dict) -> dict:
    """ความครบของการจด: ทุกมิเตอร์ (ยกเว้นอ่านจาก SCADA ที่ยังไม่ถึงเวลา) ต้องมีค่าอ่านทุกวันจนถึงเมื่อวาน
    · แจ้ง “อ่านไม่ได้” พร้อมเหตุผลนับว่าจดแล้ว · ค่าค้าง = การใช้เป็น 0 ติดกัน ≥ stuck_days วันในมิเตอร์ที่ปกติมีการใช้"""
    cfg = EN.settings(db)
    last = min(d_end, today - timedelta(days=1))
    days = EN._days(d_from, last) if last >= d_from else []
    stuck_n = int(cfg.get("stuck_days") or 3)
    by_meter: dict[int, dict] = {}
    by_fk: dict[tuple, dict] = {}
    if not ms or not days:
        return {"by_meter": {}, "by_fk": {}, "rows": [], "days": 0}
    ids = [m["id"] for m in ms]
    have: dict[int, set] = {i: set() for i in ids}
    for i in range(0, len(ids), 500):
        ch = ids[i:i + 500]
        q = ",".join("?" * len(ch))
        for r in db.execute(f"SELECT meter_id, day FROM en_readings WHERE day BETWEEN ? AND ? AND meter_id IN ({q})",
                            [days[0], days[-1], *ch]):
            have[r[0]].add(r[1])
        for r in db.execute(f"SELECT meter_id, day FROM en_skips WHERE day BETWEEN ? AND ? AND meter_id IN ({q})",
                            [days[0], days[-1], *ch]):
            have[r[0]].add(r[1])
    first = {r[0]: r[1] for r in db.execute(f"SELECT meter_id, MIN(day) FROM en_readings WHERE meter_id IN ({','.join(str(i) for i in ids)}) GROUP BY meter_id")}
    rows = []
    for m in ms:
        start = max(days[0], first.get(m["id"]) or days[0])
        want = [d for d in days if d >= start] if first.get(m["id"]) else days
        miss = [d for d in want if d not in have[m["id"]]]
        s = ser.get(m["id"]) or {}
        bad = [d for d, x in s.items() if x.get("flag") in ("bad", "reset")]
        us = [((s.get(d) or {}).get("u")) for d in days]
        run = best = 0
        for u in us:
            run = run + 1 if u == 0 else 0
            best = max(best, run)
        pos = [u for u in us if u]
        stuck = best >= stuck_n and len(pos) >= 3
        info = {"miss": len(miss), "want": len(want), "bad": len(bad), "stuck": best if stuck else 0,
                "last_miss": miss[-1] if miss else None, "bad_days": bad[-3:]}
        by_meter[m["id"]] = info
        fk = by_fk.setdefault((m["factory_id"], m["kind"]), {"expect": 0, "have": 0, "meters": 0, "miss_m": 0, "bad": 0, "stuck": 0})
        fk["expect"] += len(want)
        fk["have"] += len(want) - len(miss)
        fk["meters"] += 1
        fk["miss_m"] += 1 if miss else 0
        fk["bad"] += len(bad)
        fk["stuck"] += 1 if stuck else 0
        if miss or bad or stuck:
            rows.append({"m": m, "label": EN.label(m), **info})
    rows.sort(key=lambda r: (-r["miss"], -r["bad"], -r["stuck"]))
    return {"by_meter": by_meter, "by_fk": by_fk, "rows": rows, "days": len(days), "last": last}


def to_xlsx(d: dict) -> bytes:
    import io

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    hdr = PatternFill("solid", fgColor="1D4ED8")

    def head(ws, cols):
        ws.append(cols)
        for c in ws[ws.max_row]:
            c.font, c.fill = Font(bold=True, color="FFFFFF"), hdr

    ws = wb.active
    ws.title = "สรุปโรงงาน"
    ws.append([f"บริหารพลังงาน · {d['d_from']:%m/%Y} (ถึง {d['d_end']:%d/%m/%Y}) · เทียบ {d['p_from']:%d/%m}–{d['p_to']:%d/%m/%Y}"])
    ws["A1"].font = Font(bold=True, size=13)
    head(ws, ["ประเภท", "โรงงาน", "หน่วย", "ใช้เดือนนี้", "ช่วงเดียวกันเดือนก่อน", "เปลี่ยน %", "เฉลี่ย/วัน", "ค่าใช้จ่าย (บาท)",
              "ความครบการจด %", "มิเตอร์"])
    for k in d["kinds"]:
        for r in k["factories"]:
            ws.append([k["th"], r["factory"], k["unit"], r["u"], r["prev"], r["chg"], r["avg"], r["cost"], r["complete"], r["n"]])
    ws2 = wb.create_sheet("หน่วยงาน-ไลน์")
    head(ws2, ["ประเภท", "โรงงาน", "หน่วยงาน (Section)", "ไลน์", "หน่วย", "ใช้เดือนนี้", "สัดส่วน %", "เดือนก่อน", "เปลี่ยน %", "ค่าใช้จ่าย", "มิเตอร์"])
    for k in d["kinds"]:
        for r in k["factories"]:
            for s in r["sections"]:
                ws2.append([k["th"], r["factory"], s["name"], "", k["unit"], s["u"], s["share"], s["prev"], s["chg"], s["cost"], s["n"]])
                for ln in s["lines"]:
                    ws2.append([k["th"], r["factory"], s["name"], ln["name"], k["unit"], ln["u"], ln["share"], ln["prev"], ln["chg"], None, ln["n"]])
            if r["loss"] is not None:
                ws2.append([k["th"], r["factory"], "ไม่ได้วัด/สูญเสีย (หลักรวม − หน่วยงาน)", "", k["unit"], r["loss"], r["loss_pct"]])
    ws3 = wb.create_sheet("สมดุลมิเตอร์")
    head(ws3, ["ประเภท", "โรงงาน", "มิเตอร์หลัก", "Section", "หลัก", "ย่อยรวม", "ส่วนต่าง", "ส่วนต่าง %", "จำนวนย่อย"])
    for k in d["kinds"]:
        for r in k["factories"]:
            for b in r["balance"]:
                ws3.append([k["th"], r["factory"], ", ".join(EN.label(p) for p in b["parents"]), b["grp"], b["pu"], b["ku"], b["diff"], b["pct"],
                            len(b["kids"])])
    ws4 = wb.create_sheet("ความครบการจด")
    head(ws4, ["โรงงาน", "ประเภท", "มิเตอร์", "Section", "วันที่ควรมี", "ขาด", "ขาดล่าสุด", "ค่าเพี้ยน/ลดลง", "ค่าค้าง (วัน)"])
    for r in d["complete"]["rows"]:
        m = r["m"]
        ws4.append([m["factory_name"], EN.KINDS.get(m["kind"], {}).get("th", m["kind"]), r["label"], m["grp"], r["want"], r["miss"],
                    r["last_miss"], r["bad"], r["stuck"] or None])
    for w in (ws, ws2, ws3, ws4):
        for col in w.columns:
            w.column_dimensions[col[0].column_letter].width = 16
        w.column_dimensions["C"].width = 30
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()
