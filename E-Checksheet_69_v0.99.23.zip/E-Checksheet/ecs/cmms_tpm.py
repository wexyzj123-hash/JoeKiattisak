"""ecs/cmms_tpm.py — เชื่อมแผน TPM ของ UT-CMMS กับ E-Checksheet (สแกนตรวจแล้วแผน TPM อัปเดตเอง)

การเชื่อม: แบบฟอร์ม (ของเครื่องเดียวกัน) ↔ แผน TPM 1 แผนขึ้นไป — ตั้งที่หน้าแบบฟอร์ม › "แผน TPM"
  (เลือกได้ว่าต้องตรวจหัวข้อไหนบ้างจึงนับว่าทำแผนนั้นแล้ว · ไม่เลือก = ทั้งแบบฟอร์ม)

ส่งผลตรวจ → แผน TPM ที่ถึงช่วงทำ (เกินกำหนด / ใกล้ถึงกำหนด) ถูกบันทึกทำงานให้อัตโนมัติ ด้วยขั้นตอนเดียวกับปุ่ม "บันทึกทำงาน" ของ UT-CMMS:
  tpm_plans.status = awaiting_approval (รอยืนยัน) · last_done = วันที่ตรวจ
  tpm_logs  = ผู้ทำ (ผู้ตรวจ) · เวลาที่ใช้ · ผล ok / issue_found (มี NG) · ค่าที่ตรวจ · ลิงก์ใบบันทึก E-Checksheet
  tpm_attachments = รูปจากการตรวจ
หัวหน้าอนุมัติผลตรวจใน E-Checksheet → ยืนยันแผน TPM ให้ด้วย (คำนวณกำหนดครั้งถัดไปแบบเดียวกับ UT-CMMS)
ตีกลับ → แผน TPM กลับเป็น "ตามแผน" · ลบผลตรวจ → ยกเลิกบันทึกที่ยังไม่ยืนยัน
ยืนยัน/ไม่อนุมัติใน UT-CMMS เองก็ได้ — สถานะแสดงกลับในหน้าผลตรวจ
"""
from __future__ import annotations

import calendar
import json
import logging
import os
import shutil
import sqlite3
import uuid
from datetime import date, datetime, timedelta

from . import services as S
from .services import ValidationError, ts

log = logging.getLogger(__name__)

DEFAULTS = {"enabled": False, "lead_days": 5, "approve_with_submission": True, "attach_photos": True}
# ตรงกับ FREQ_CONFIG ของ UT-CMMS (config.py)
FREQ = {"1/W": (7, 0, "1 ครั้ง/สัปดาห์"), "2/M": (15, 0, "2 ครั้ง/เดือน"), "1/M": (0, 1, "1 ครั้ง/เดือน"),
        "6/Y": (0, 2, "6 ครั้ง/ปี"), "4/Y": (0, 3, "4 ครั้ง/ปี"), "3/Y": (0, 4, "3 ครั้ง/ปี"),
        "2/Y": (0, 6, "2 ครั้ง/ปี"), "1/Y": (0, 12, "1 ครั้ง/ปี")}
LEGACY = {"daily": "1/W", "weekly": "1/W", "biweekly": "2/M", "monthly": "1/M", "quarterly": "4/Y",
          "half_yearly": "2/Y", "yearly": "1/Y"}
STATUS_TH = {"scheduled": "ตามแผน", "pending": "ตามแผน", "awaiting_approval": "รอยืนยัน", "completed": "เสร็จ",
             "skipped": "ข้าม"}
STATE_TH = {"submitted": "บันทึกทำงานแล้ว · รอยืนยัน", "approved": "ยืนยันแล้ว", "rejected": "ไม่อนุมัติ",
            "cancelled": "ยกเลิก"}

DDL = """
CREATE TABLE IF NOT EXISTS cs_tpm_links (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id    INTEGER NOT NULL,
    plan_id    INTEGER NOT NULL,            -- tpm_plans.id ใน UT-CMMS
    item_keys  TEXT DEFAULT '',             -- JSON list · ว่าง = ทั้งแบบฟอร์ม
    created_by INTEGER,
    created_at TEXT NOT NULL,
    UNIQUE (form_id, plan_id)
);
CREATE TABLE IF NOT EXISTS cs_tpm_sync (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_id       INTEGER NOT NULL,
    form_id       INTEGER,
    submission_id INTEGER,
    tpm_log_id    INTEGER,
    prev_last_done TEXT,                  -- last_done เดิมของแผน (คืนค่าเมื่อยกเลิก)
    task          TEXT DEFAULT '',
    due_date      TEXT,
    result        TEXT DEFAULT 'ok',
    state         TEXT NOT NULL DEFAULT 'submitted',   -- submitted | approved | rejected | cancelled
    next_due      TEXT,
    note          TEXT DEFAULT '',
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tpmsync_sub ON cs_tpm_sync(submission_id);
"""


def ensure(db) -> None:
    db.executescript(DDL)


# ───────────────────────── ตั้งค่า / การเชื่อมต่อ ─────────────────────────

def get_settings(db) -> dict:
    cfg = dict(DEFAULTS)
    row = db.execute("SELECT value FROM cs_meta WHERE key='cmms_tpm'").fetchone()
    if row and row[0]:
        try:
            cfg.update({k: v for k, v in json.loads(row[0]).items() if k in DEFAULTS})
        except ValueError:
            pass
    return cfg


def save_settings(db, data: dict, actor_id) -> dict:
    on = lambda k: data.get(k) in (1, True, "1", "on", "true")      # noqa: E731
    cfg = {"enabled": on("enabled"), "approve_with_submission": on("approve_with_submission"),
           "attach_photos": on("attach_photos")}
    try:
        cfg["lead_days"] = max(0, min(30, int(data.get("lead_days") or 5)))
    except (TypeError, ValueError):
        cfg["lead_days"] = 5
    db.execute("INSERT INTO cs_meta(key, value) VALUES('cmms_tpm', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(cfg),))
    S.audit(db, actor_id, "update", "cs_meta", None, after={"cmms_tpm": cfg})
    return cfg


def available(app_config) -> bool:
    p = app_config.get("CMMS_DATABASE")
    return bool(p and os.path.exists(p))


def _connect(app_config, readonly: bool = False) -> sqlite3.Connection:
    path = app_config.get("CMMS_DATABASE")
    if not path or not os.path.exists(path):
        raise ValidationError("ยังไม่ได้เชื่อม UT-CMMS (เปิดผ่าน portal.py เท่านั้น)")
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=20) if readonly else sqlite3.connect(path, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=20000")
    return con


def freq_display(plan: dict) -> str:
    fd = (plan.get("frequency_display") or "").strip()
    return fd if fd in FREQ else LEGACY.get(plan.get("frequency") or "monthly", "1/M")


def _add_months(d: date, n: int) -> date:
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def calc_next_due(base: date, fd: str) -> date:
    """เหมือน config.calc_next_due ของ UT-CMMS"""
    days, months, _ = FREQ.get(fd, (0, 1, ""))
    return _add_months(base, months) if months else base + timedelta(days=days)


def lead_days(plan: dict, cfg: dict) -> int:
    """ช่วงก่อนกำหนดที่ยอมให้นับว่าทำแผนแล้ว — ไม่เกิน 1/4 ของรอบ (แผนรายสัปดาห์ = 1 วัน)"""
    days, months, _ = FREQ.get(freq_display(plan), (0, 1, ""))
    interval = days or months * 30
    return max(0, min(int(cfg.get("lead_days", 5)), max(1, interval // 4)))


def plan_state(plan: dict, today: date | None = None) -> str:
    """สถานะแบบเดียวกับปฏิทิน TPM: overdue | soon | scheduled | awaiting"""
    today = today or date.today()
    if plan.get("status") == "awaiting_approval":
        return "awaiting"
    try:
        due = date.fromisoformat(str(plan.get("next_due"))[:10])
    except ValueError:
        return "scheduled"
    if due < today:
        return "overdue"
    return "soon" if (due - today).days <= 5 else "scheduled"


STATE_BADGE = {"overdue": ("เกินกำหนด", "b-ng"), "soon": ("ใกล้แผน", "b-warn"), "scheduled": ("ตามแผน", "b-info"),
               "awaiting": ("รอยืนยัน", "b-primary")}


def _plans(con, where: str, params) -> list[dict]:
    rows = con.execute(f"""SELECT t.*, u.name AS assignee_name FROM tpm_plans t LEFT JOIN users u ON u.id=t.assignee_id
                           WHERE {where} ORDER BY t.next_due, t.id""", params).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["fd"] = freq_display(d)
        d["freq_label"] = FREQ.get(d["fd"], (0, 0, d["fd"]))[2]
        d["state"] = plan_state(d)
        d["badge"] = STATE_BADGE[d["state"]]
        out.append(d)
    return out


def plans_for_equipment(app_config, cmms_eq_id: int) -> list[dict]:
    con = _connect(app_config, readonly=True)
    try:
        return _plans(con, "t.equipment_id=?", (cmms_eq_id,))
    finally:
        con.close()


def plans_by_ids(app_config, ids: list[int]) -> dict[int, dict]:
    if not ids:
        return {}
    con = _connect(app_config, readonly=True)
    try:
        return {p["id"]: p for p in _plans(con, f"t.id IN ({','.join('?' * len(ids))})", list(ids))}
    finally:
        con.close()


# ───────────────────────── ตั้งค่าการเชื่อมต่อรายแบบฟอร์ม ─────────────────────────

def form_links(db, form_id: int) -> list[dict]:
    ensure(db)
    out = []
    for r in db.execute("SELECT * FROM cs_tpm_links WHERE form_id=? ORDER BY id", (form_id,)):
        d = dict(r)
        d["items"] = json.loads(d["item_keys"] or "[]")
        out.append(d)
    return out


def save_links(db, app_config, form_id: int, plan_items: dict[int, list[str]], actor_id) -> int:
    """plan_items = {plan_id: [item_key, ...]} (รายการว่าง = ทั้งแบบฟอร์ม) — แทนที่การเชื่อมทั้งหมดของแบบฟอร์ม"""
    ensure(db)
    form = S.get_form(db, form_id)
    if not form:
        raise ValidationError("ไม่พบแบบฟอร์ม")
    if plan_items:
        eq = db.execute("SELECT legacy_id FROM equipment WHERE id=?", (form["equipment_id"],)).fetchone() \
            if form["equipment_id"] else None
        if not eq or not eq["legacy_id"]:
            raise ValidationError("แบบฟอร์มต้องผูกเครื่องจักรที่มีใน UT-CMMS ก่อน")
        plans = plans_by_ids(app_config, list(plan_items))
        bad = [pid for pid in plan_items if pid not in plans or plans[pid]["equipment_id"] != eq["legacy_id"]]
        if bad:
            raise ValidationError("แผน TPM ที่เลือกไม่ใช่ของเครื่องนี้")
    valid_keys = {i["item_key"] for i in S.get_items(db, form["current_version_id"])} if form["current_version_id"] else set()
    db.execute("DELETE FROM cs_tpm_links WHERE form_id=?", (form_id,))
    for pid, keys in plan_items.items():
        keys = [k for k in keys if k in valid_keys]
        db.execute("INSERT INTO cs_tpm_links(form_id, plan_id, item_keys, created_by, created_at) VALUES (?,?,?,?,?)",
                   (form_id, pid, json.dumps(keys) if keys else "", actor_id, ts()))
    S.audit(db, actor_id, "tpm_links", "cs_forms", form_id, after={str(k): v for k, v in plan_items.items()})
    return len(plan_items)


_GENERIC = {"tank", "pump", "check", "checking", "air", "the", "and", "for", "with", "clean",
            "cleaning", "system", "unit", "main", "line", "condition", "equipment", "machine", "part", "parts", "change",
            "replace", "inspection", "monthly", "weekly", "daily", "yearly", "year", "month", "valve", "motor", "no"}


def _tokens(text: str) -> set[str]:
    import re
    return {t for t in re.findall(r"[a-z]+|[\u0e00-\u0e7f]+", (text or "").lower())
            if (len(t) >= 3 if t.isascii() else len(t) >= 4) and t not in _GENERIC}


def suggest(items: list[dict], plan: dict) -> list[str]:
    """หัวข้อที่ชื่อตรงกับงาน TPM (แบบระมัดระวัง: คำสำคัญของงาน ≥ 60% ต้องอยู่ในหัวข้อเดียวกัน · เทียบ 4 ตัวอักษรแรก
    เช่น Temperature ↔ Temp) — ใช้ติ๊กให้ก่อน / เชื่อมอัตโนมัติ"""
    words = _tokens(plan.get("task") or "")
    if not words:
        return []
    out = []
    for i in items:
        hay = _tokens(i["name"] + " " + (i.get("section") or ""))
        pre = {h[:4] for h in hay}
        hit = sum(1 for w in words if w in hay or w[:4] in pre)
        if len(words) == 1:                     # งานคำเดียว: ต้องตรงทั้งคำในชื่อหัวข้อ และยาวพอ (กัน "Water" ตรงทุกข้อ)
            (w,) = words
            ok = len(w) >= 6 and w in _tokens(i["name"])
        else:
            ok = hit >= 2 and hit / len(words) >= 0.6
        if ok:
            out.append(i["item_key"])
    return out


# ───────────────────────── ส่งผลตรวจ → บันทึกทำงาน TPM ─────────────────────────

def _cmms_user(db, con, user_id) -> int:
    u = db.execute("SELECT legacy_id FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None
    if u and u["legacy_id"] and con.execute("SELECT 1 FROM users WHERE id=?", (u["legacy_id"],)).fetchone():
        return int(u["legacy_id"])
    r = con.execute("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1").fetchone() or \
        con.execute("SELECT id FROM users ORDER BY id LIMIT 1").fetchone()
    if not r:
        raise ValidationError("UT-CMMS ยังไม่มีผู้ใช้")
    return int(r["id"])


def after_submit(db, app_config, sub_id: int, actor_id, base_url: str = "") -> list[dict]:
    """เรียกหลังบันทึกผลตรวจ — ล้มเหลวต้องไม่กระทบการส่งผลตรวจ"""
    if not available(app_config):
        return []
    try:
        res = record_submission(db, app_config, sub_id, base_url=base_url)
        db.commit()
        return res
    except Exception:                                   # noqa: BLE001
        db.rollback()
        log.exception("TPM sync failed for submission %s", sub_id)
        return []


def record_submission(db, app_config, sub_id: int, *, base_url: str = "", now: datetime | None = None) -> list[dict]:
    ensure(db)
    cfg = get_settings(db)
    if not cfg["enabled"]:
        return []
    s = db.execute("""SELECT s.*, u.name AS inspector_name, f.name AS form_name, f.code AS form_code
                      FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id LEFT JOIN users u ON u.id=s.inspector_id
                      WHERE s.id=?""", (sub_id,)).fetchone()
    if not s or s["status"] != "submitted":
        return []
    links = form_links(db, s["form_id"])
    if not links:
        return []
    answers = {r["item_key"]: dict(r) for r in db.execute(
        """SELECT a.id, a.item_key, a.value_text, a.judgement, a.remark, i.name, i.unit FROM cs_answers a
           JOIN cs_form_items i ON i.id=a.item_id WHERE a.submission_id=? ORDER BY i.order_no""", (sub_id,))}
    now = now or S.now_dt()
    done_day = (S.parse_ts(s["finished_at"]) or now).date()
    con = _connect(app_config)
    out = []
    from .cmms_status import get_settings as status_cfg
    # เวลาที่ใช้ตรวจนับครั้งเดียว: รายงานสถานะช่างของ UT-CMMS รวม "สถานะ + งานซ่อม + TPM" — ถ้าเชื่อมสถานะช่างอยู่
    # เวลาไปอยู่ในสถานะ "ตรวจเช็ค" แล้ว (TPM = 0) · ไม่เชื่อม = ลงเวลาที่แผนแรกแผนเดียว
    hours_left = 0.0 if status_cfg(db)["enabled"] else round((s["duration_sec"] or 0) / 3600, 2)
    try:
        plans = {p["id"]: p for p in _plans(con, f"t.id IN ({','.join('?' * len(links))})", [lk["plan_id"] for lk in links])}
        for lk in links:
            p = plans.get(lk["plan_id"])
            if not p or p["status"] not in ("scheduled", "pending"):
                continue                                          # รอยืนยันอยู่แล้ว / เสร็จ / ข้าม
            try:
                due = date.fromisoformat(str(p["next_due"])[:10])
            except ValueError:
                continue
            if done_day < due - timedelta(days=lead_days(p, cfg)):
                continue                                          # ยังไม่ถึงช่วงทำแผน
            keys = lk["items"] or [k for k, a in answers.items()]
            got = [answers[k] for k in keys if k in answers and answers[k]["judgement"] != "na"]
            if not got or (lk["items"] and len(got) < len([k for k in lk["items"]])):
                continue                                          # หัวข้อที่กำหนดยังตรวจไม่ครบ
            ng = [a for a in got if a["judgement"] == "ng"]
            lines = [f"{a['name']}: {a['value_text']}{(' ' + a['unit']) if a['unit'] else ''}"
                     + (" (NG)" if a["judgement"] == "ng" else "") + (f" · {a['remark']}" if a["remark"] else "")
                     for a in got[:25]]
            link = f"{base_url.rstrip('/')}/submissions/{sub_id}/record" if base_url else f"ผลตรวจ #{sub_id}"
            notes = (f"บันทึกจาก E-Checksheet: {s['form_name']} ({s['form_code'] or ''})\n" + "\n".join(lines)
                     + (f"\n… และอีก {len(got) - 25} หัวข้อ" if len(got) > 25 else "") + f"\nใบบันทึก: {link}")
            who = _cmms_user(db, con, s["inspector_id"])
            prev_last = p["last_done"]
            hours, hours_left = hours_left, 0.0
            con.execute("UPDATE tpm_plans SET last_done=?, status='awaiting_approval', updated_at=CURRENT_TIMESTAMP WHERE id=?",
                        (done_day.isoformat(), p["id"]))
            cur = con.execute("""INSERT INTO tpm_logs (tpm_plan_id, done_by, done_date, actual_date, time_spent, result, notes,
                                 action_taken, performed_by, scheduled_due_date) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                              (p["id"], who, now.date().isoformat(), done_day.isoformat(), hours,
                               "issue_found" if ng else "ok", notes[:3000],
                               f"ตรวจตามเช็คชีท {s['form_code'] or ''}".strip() + (f" · พบ NG {len(ng)} หัวข้อ" if ng else ""),
                               s["inspector_name"] or "", p["next_due"]))
            log_id = cur.lastrowid
            try:
                con.execute("INSERT INTO activity_log(user_id, action, target_type, target_id, details) VALUES (?,?,?,?,?)",
                            (who, "submit_tpm", "tpm_plans", p["id"], f"E-Checksheet ผลตรวจ #{sub_id} รอหัวหน้ายืนยัน"))
            except sqlite3.Error:
                pass
            photos = _attach(db, con, app_config, p["id"], log_id, sub_id, [a["id"] for a in got], who) \
                if cfg["attach_photos"] else 0
            db.execute("""INSERT INTO cs_tpm_sync(plan_id, form_id, submission_id, tpm_log_id, prev_last_done, task, due_date,
                          result, state, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?, 'submitted', ?, ?)""",
                       (p["id"], s["form_id"], sub_id, log_id, prev_last, p["task"], p["next_due"],
                        "issue_found" if ng else "ok", ts(now), ts(now)))
            out.append({"plan_id": p["id"], "task": p["task"], "due": p["next_due"], "photos": photos, "ng": len(ng)})
        con.commit()
    finally:
        con.close()
    if out:
        S.audit(db, s["inspector_id"], "tpm_submit", "cs_submissions", sub_id, after=out)
    return out


def _attach(db, con, app_config, plan_id: int, log_id: int, sub_id: int, answer_ids: list[int], who: int) -> int:
    dest, src_root = app_config.get("CMMS_UPLOAD_FOLDER"), app_config.get("UPLOAD_FOLDER")
    if not dest or not src_root or not answer_ids:
        return 0
    rows = db.execute(f"SELECT file_path FROM cs_photos WHERE answer_id IN ({','.join('?' * len(answer_ids))}) LIMIT 10",
                      answer_ids).fetchall()
    n = 0
    for r in rows:
        src = os.path.join(src_root, r["file_path"])
        if not os.path.exists(src):
            continue
        ext = os.path.splitext(src)[1].lower().lstrip(".") or "jpg"
        name = f"tpm{plan_id}_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:8]}.{ext}"
        try:
            os.makedirs(dest, exist_ok=True)
            shutil.copyfile(src, os.path.join(dest, name))
            con.execute("""INSERT INTO tpm_attachments (tpm_id, tpm_log_id, filename, original_name, file_type, file_size, uploaded_by)
                           VALUES (?,?,?,?,?,?,?)""", (plan_id, log_id, name, f"echeck_{sub_id}_{n + 1}.{ext}", ext,
                                                      os.path.getsize(src), who))
            n += 1
        except (OSError, sqlite3.Error):
            log.exception("copy photo to TPM failed")
    return n


# ───────────────────────── อนุมัติ / ตีกลับ / ลบ ─────────────────────────

def _pending(db, sub_ids: list[int]) -> list[dict]:
    ensure(db)
    if not sub_ids:
        return []
    return [dict(r) for r in db.execute(
        f"SELECT * FROM cs_tpm_sync WHERE state='submitted' AND submission_id IN ({','.join('?' * len(sub_ids))})", sub_ids)]


def on_approve(db, app_config, sub_ids: list[int], approver_id) -> int:
    """อนุมัติผลตรวจ → ยืนยันแผน TPM (เหมือนหัวหน้ากด 'ยืนยัน' ใน UT-CMMS) — คืนจำนวนแผนที่ยืนยัน"""
    if not available(app_config) or not get_settings(db)["approve_with_submission"]:
        return 0
    if not sub_ids:
        return 0
    ok = {r[0] for r in db.execute(f"SELECT id FROM cs_submissions WHERE approval_status='approved' AND id IN "
                                   f"({','.join('?' * len(sub_ids))})", list(sub_ids))}
    rows = [r for r in _pending(db, sorted(ok))]
    if not rows:
        return 0
    n = 0
    con = _connect(app_config)
    try:
        who = _cmms_user(db, con, approver_id)
        for r in rows:
            p = con.execute("SELECT * FROM tpm_plans WHERE id=?", (r["plan_id"],)).fetchone()
            lg = con.execute("SELECT * FROM tpm_logs WHERE id=?", (r["tpm_log_id"],)).fetchone()
            if not p or not lg:
                _set_state(db, r["id"], "cancelled", note="แผน/บันทึกถูกลบใน UT-CMMS")
                continue
            if lg["approved_at"] or p["status"] != "awaiting_approval":
                _set_state(db, r["id"], "approved" if lg["approved_at"] else "rejected")      # ทำใน UT-CMMS ไปแล้ว
                continue
            last_done = date.fromisoformat(str(p["last_done"] or date.today().isoformat())[:10])
            orig = str(p["next_due"] or date.today().isoformat())[:10]
            actual = str(lg["actual_date"] or lg["done_date"])[:10]
            late = 1 if actual > orig else 0
            nxt = calc_next_due(last_done, freq_display(dict(p))).isoformat()
            con.execute("UPDATE tpm_plans SET next_due=?, status='scheduled', updated_at=CURRENT_TIMESTAMP WHERE id=?",
                        (nxt, p["id"]))
            con.execute("""UPDATE tpm_logs SET approved_by=?, approved_at=?, was_overdue=?,
                           scheduled_due_date=COALESCE(scheduled_due_date, ?) WHERE id=?""",
                        (who, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), late, orig, lg["id"]))
            try:
                con.execute("INSERT INTO activity_log(user_id, action, target_type, target_id, details) VALUES (?,?,?,?,?)",
                            (who, "approve_tpm", "tpm_plans", p["id"],
                             f"{'เสร็จช้ากว่าแผน' if late else 'เสร็จตามแผน'} next: {nxt} (อนุมัติผ่าน E-Checksheet)"))
            except sqlite3.Error:
                pass
            _set_state(db, r["id"], "approved", next_due=nxt)
            n += 1
        con.commit()
    finally:
        con.close()
    return n


def on_reject(db, app_config, sub_ids: list[int], reason: str, state: str = "rejected", actor_id=None) -> int:
    """ตีกลับ / ลบผลตรวจ → แผน TPM กลับเป็นตามแผน (เฉพาะที่ยังไม่ยืนยัน)"""
    if not available(app_config):
        return 0
    rows = _pending(db, sub_ids)
    if not rows:
        return 0
    n = 0
    con = _connect(app_config)
    try:
        for r in rows:
            p = con.execute("SELECT status FROM tpm_plans WHERE id=?", (r["plan_id"],)).fetchone()
            lg = con.execute("SELECT id, approved_at FROM tpm_logs WHERE id=?", (r["tpm_log_id"],)).fetchone()
            if lg and lg["approved_at"]:
                _set_state(db, r["id"], "approved")
                continue
            if state == "cancelled":
                # ผลตรวจถูกลบ → ลบบันทึกทำงานออกจาก UT-CMMS (ไม่ให้ปฏิทินขึ้นว่าทำแล้ว) และคืน last_done เดิม
                if p and p["status"] == "awaiting_approval":
                    con.execute("UPDATE tpm_plans SET status='scheduled', last_done=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                                (r.get("prev_last_done"), r["plan_id"]))
                if lg:
                    _drop_attachments(con, app_config, lg["id"])
                    con.execute("DELETE FROM tpm_logs WHERE id=?", (lg["id"],))
                try:
                    con.execute("INSERT INTO activity_log(user_id, action, target_type, target_id, details) VALUES (?,?,?,?,?)",
                                (_cmms_user(db, con, None), "reject_tpm", "tpm_plans", r["plan_id"],
                                 f"ยกเลิก — ผลตรวจ E-Checksheet #{r['submission_id']} ถูกลบ: {reason[:150]}"))
                except sqlite3.Error:
                    pass
            else:
                # ตีกลับ = เหมือนกด "ไม่อนุมัติ" ใน UT-CMMS (เก็บบันทึกไว้ + หมายเหตุ)
                if p and p["status"] == "awaiting_approval":
                    con.execute("UPDATE tpm_plans SET status='scheduled', updated_at=CURRENT_TIMESTAMP WHERE id=?", (r["plan_id"],))
                if lg:
                    con.execute("UPDATE tpm_logs SET notes = COALESCE(notes,'') || ? WHERE id=?",
                                (f" [ไม่อนุมัติ: {reason[:200]} (E-Checksheet)]", lg["id"]))
                try:
                    con.execute("INSERT INTO activity_log(user_id, action, target_type, target_id, details) VALUES (?,?,?,?,?)",
                                (_cmms_user(db, con, actor_id), "reject_tpm", "tpm_plans", r["plan_id"], reason[:200]))
                except sqlite3.Error:
                    pass
            _set_state(db, r["id"], state, note=reason[:300])
            n += 1
        con.commit()
    finally:
        con.close()
    return n


def safe(fn, db, *args, **kw) -> int:
    """เรียก on_approve / on_reject จากหน้าเว็บ — ข้อผิดพลาดฝั่ง UT-CMMS ต้องไม่ทำให้การอนุมัติ/ตีกลับล้ม"""
    try:
        n = fn(db, *args, **kw)
        db.commit()
        return n
    except Exception:                                   # noqa: BLE001
        db.rollback()
        log.exception("TPM %s failed", fn.__name__)
        return 0


def _drop_attachments(con, app_config, log_id: int) -> None:
    folder = app_config.get("CMMS_UPLOAD_FOLDER")
    for a in con.execute("SELECT id, filename FROM tpm_attachments WHERE tpm_log_id=?", (log_id,)).fetchall():
        if folder and a["filename"]:
            try:
                os.remove(os.path.join(folder, os.path.basename(a["filename"])))
            except OSError:
                pass
    con.execute("DELETE FROM tpm_attachments WHERE tpm_log_id=?", (log_id,))


def _set_state(db, sync_id: int, state: str, note: str = "", next_due: str | None = None) -> None:
    db.execute("UPDATE cs_tpm_sync SET state=?, note=CASE WHEN ?<>'' THEN ? ELSE note END, next_due=COALESCE(?, next_due), "
               "updated_at=? WHERE id=?", (state, note, note, next_due, ts(), sync_id))


def refresh_states(db, app_config) -> int:
    """อ่านผลยืนยัน/ไม่อนุมัติที่ทำใน UT-CMMS → อัปเดตสถานะใน E-Checksheet (jobs)"""
    ensure(db)
    rows = [dict(r) for r in db.execute("SELECT * FROM cs_tpm_sync WHERE state='submitted'")]
    if not rows or not available(app_config):
        return 0
    con = _connect(app_config, readonly=True)
    n = 0
    try:
        for r in rows:
            lg = con.execute("SELECT approved_at, notes FROM tpm_logs WHERE id=?", (r["tpm_log_id"],)).fetchone()
            p = con.execute("SELECT status, next_due FROM tpm_plans WHERE id=?", (r["plan_id"],)).fetchone()
            if not lg or not p:
                _set_state(db, r["id"], "cancelled", note="ถูกลบใน UT-CMMS")
            elif lg["approved_at"]:
                _set_state(db, r["id"], "approved", next_due=p["next_due"])
            elif p["status"] != "awaiting_approval":
                _set_state(db, r["id"], "rejected", note="ไม่อนุมัติใน UT-CMMS")
            else:
                continue
            n += 1
    finally:
        con.close()
    db.commit()
    return n


# ───────────────────────── แสดงผล ─────────────────────────

def sync_for_submission(db, sub_id: int) -> list[dict]:
    ensure(db)
    out = []
    for r in db.execute("SELECT * FROM cs_tpm_sync WHERE submission_id=? ORDER BY id", (sub_id,)):
        d = dict(r)
        d["state_th"] = STATE_TH.get(d["state"], d["state"])
        d["cls"] = {"submitted": "b-primary", "approved": "b-ok", "rejected": "b-ng", "cancelled": "b-none"}[d["state"]]
        out.append(d)
    return out


def due_for_forms(db, app_config, form_ids: list[int] | None = None) -> list[dict]:
    """แผน TPM ที่เชื่อมกับแบบฟอร์มและอยู่ในช่วงทำ "ตอนนี้" (ส่งผลตรวจแล้วจะถูกบันทึก) — ใช้ในหน้างานของฉัน/หน้ากรอก"""
    ensure(db)
    cfg = get_settings(db)
    if not cfg["enabled"] or not available(app_config):
        return []
    q = "SELECT l.*, f.name AS form_name, f.factory_id, e.code AS eq_code FROM cs_tpm_links l JOIN cs_forms f ON f.id=l.form_id " \
        "LEFT JOIN equipment e ON e.id=f.equipment_id WHERE f.active=1"
    links = [dict(r) for r in db.execute(q)]
    if form_ids is not None:
        links = [lk for lk in links if lk["form_id"] in set(form_ids)]
    if not links:
        return []
    plans = plans_by_ids(app_config, sorted({lk["plan_id"] for lk in links}))
    today = date.today()
    out = []
    for lk in links:
        p = plans.get(lk["plan_id"])
        if not p or p["status"] not in ("scheduled", "pending"):
            continue
        try:
            due = date.fromisoformat(str(p["next_due"])[:10])
        except ValueError:
            continue
        if today >= due - timedelta(days=lead_days(p, cfg)):
            items = json.loads(lk["item_keys"] or "[]")
            out.append({"form_id": lk["form_id"], "form_name": lk["form_name"], "eq_code": lk["eq_code"],
                        "factory_id": lk["factory_id"], "plan_id": p["id"], "task": p["task"], "next_due": p["next_due"],
                        "state": p["state"], "state_th": p["badge"][0], "freq": p["freq_label"], "items": items,
                        "assignee": p.get("assignee_name") or ""})
    out.sort(key=lambda x: x["next_due"])
    return out


# ───────────────────────── หน้าผู้ดูแลระบบ ─────────────────────────

def overview(db, app_config) -> dict:
    """ภาพรวม: แบบฟอร์มที่มีเครื่องใน UT-CMMS · จำนวนแผน · เชื่อมแล้วกี่แผน · แผนที่แนะนำ (ชื่อตรงกับหัวข้อ)"""
    ensure(db)
    forms = [dict(r) for r in db.execute(
        """SELECT f.id, f.name, f.code, f.current_version_id, f.factory_id, e.code AS eq_code, e.legacy_id
           FROM cs_forms f JOIN equipment e ON e.id=f.equipment_id
           WHERE f.active=1 AND COALESCE(f.is_template,0)=0 AND e.legacy_id IS NOT NULL AND f.current_version_id IS NOT NULL
           ORDER BY e.code, f.name""")]
    links: dict[int, set] = {}
    for r in db.execute("SELECT form_id, plan_id FROM cs_tpm_links"):
        links.setdefault(r["form_id"], set()).add(r["plan_id"])
    by_eq: dict[int, list] = {}
    if forms and available(app_config):
        con = _connect(app_config, readonly=True)
        try:
            ids = sorted({f["legacy_id"] for f in forms})
            for p in _plans(con, f"t.equipment_id IN ({','.join('?' * len(ids))})", ids):
                by_eq.setdefault(p["equipment_id"], []).append(p)
        finally:
            con.close()
    out = []
    for f in forms:
        plans = by_eq.get(f["legacy_id"], [])
        if not plans:
            continue
        items = S.get_items(db, f["current_version_id"])
        linked = links.get(f["id"], set())
        f["n_plans"], f["n_linked"] = len(plans), len(linked & {p["id"] for p in plans})
        f["suggest"] = [p["task"] for p in plans if p["id"] not in linked and suggest(items, p)]
        out.append(f)
    return {"forms": out, "n_links": sum(f["n_linked"] for f in out),
            "n_suggest": sum(len(f["suggest"]) for f in out)}


def auto_link(db, app_config, actor_id, form_ids: list[int] | None = None) -> dict:
    """เชื่อมอัตโนมัติ: แผนที่ชื่องานตรงกับหัวข้อในแบบฟอร์ม → นับว่าทำแล้วเมื่อตรวจหัวข้อที่ตรงกันครบ (ไม่แตะการเชื่อมเดิม)"""
    ov = overview(db, app_config)
    n_forms = n_links = 0
    for f in ov["forms"]:
        if form_ids is not None and f["id"] not in form_ids or not f["suggest"]:
            continue
        items = S.get_items(db, f["current_version_id"])
        current = {lk["plan_id"]: lk["items"] for lk in form_links(db, f["id"])}
        added = 0
        for p in plans_for_equipment(app_config, f["legacy_id"]):
            if p["id"] in current:
                continue
            keys = suggest(items, p)
            if keys:
                current[p["id"]] = keys
                added += 1
        if added:
            save_links(db, app_config, f["id"], current, actor_id)
            n_forms += 1
            n_links += added
    return {"forms": n_forms, "links": n_links}


def recent_syncs(db, limit: int = 30) -> list[dict]:
    ensure(db)
    rows = db.execute("""SELECT y.*, f.name AS form_name, e.code AS eq_code FROM cs_tpm_sync y
                         LEFT JOIN cs_forms f ON f.id=y.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
                         ORDER BY y.id DESC LIMIT ?""", (limit,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["state_th"] = STATE_TH.get(d["state"], d["state"])
        d["cls"] = {"submitted": "b-primary", "approved": "b-ok", "rejected": "b-ng", "cancelled": "b-none"}.get(d["state"], "b-none")
        out.append(d)
    return out
