"""ecs/capa.py — Phase 4: งานแก้ไข / ป้องกัน (CAPA)

สถานะ: เปิด → กำลังดำเนินการ → เสร็จ รอตรวจรับ → ปิดงาน   (ยกเลิกได้ / ตรวจรับไม่ผ่านกลับไปดำเนินการ)
สร้างจากแจ้งเตือนหรือผลตรวจ NG ได้ในคลิกเดียว (ดึงเครื่อง/แบบฟอร์ม/รูปก่อนแก้ไขให้อัตโนมัติ)
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any

from . import services as S
from .services import ValidationError, ts

STATUS_TH = {"open": "เปิด", "in_progress": "กำลังดำเนินการ", "done": "รอตรวจรับ", "closed": "ปิดงาน", "cancelled": "ยกเลิก"}
STATUS_CLASS = {"open": "b-info", "in_progress": "b-warn", "done": "b-primary", "closed": "b-ok", "cancelled": "b-none"}
SOURCE_TH = {"alert": "จากแจ้งเตือน", "ng": "จากผลตรวจ NG", "manual": "สร้างเอง", "report": "แจ้งจากหน้างาน"}
PRIORITY_TH = {"low": "ต่ำ", "normal": "ปกติ", "high": "สูง", "urgent": "ด่วนมาก"}
TYPE_TH = {"corrective": "แก้ไข (Corrective)", "preventive": "ป้องกัน (Preventive)"}
EVENT_TH = {"created": "สร้างงาน", "update": "แก้ไขข้อมูล", "assign": "มอบหมาย", "start": "เริ่มดำเนินการ",
            "done": "ส่งตรวจรับ", "verify": "ตรวจรับ / ปิดงาน", "reject": "ตรวจรับไม่ผ่าน", "cancel": "ยกเลิก",
            "reopen": "เปิดใหม่", "comment": "ความเห็น", "photo": "แนบรูป"}
OPEN = ("open", "in_progress", "done")
DUE_DAYS = {"critical": 1, "warning": 3, "info": 7}
FLOW = {  # action: (จากสถานะ, ไปสถานะ)
    "start": (("open",), "in_progress"),
    "done": (("open", "in_progress"), "done"),
    "verify": (("done",), "closed"),
    "reject": (("done",), "in_progress"),
    "cancel": (("open", "in_progress", "done"), "cancelled"),
    "reopen": (("closed", "cancelled"), "in_progress"),
}
MAX_PHOTOS = 10


def _event(db, action_id: int, event: str, actor_id, detail: str = "", now: datetime | None = None) -> None:
    db.execute("INSERT INTO cs_action_events(action_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
               (action_id, event, actor_id, detail[:1000], ts(now or S.now_dt())))


def _next_code(db, now: datetime) -> str:
    prefix = f"CAPA-{now:%Y}-"
    row = db.execute("SELECT code FROM cs_actions WHERE code LIKE ? ORDER BY code DESC LIMIT 1", (prefix + "%",)).fetchone()
    n = int(row[0].rsplit("-", 1)[1]) + 1 if row else 1
    return f"{prefix}{n:04d}"


def _clean(data: dict, db, partial: bool = False) -> dict:
    out: dict[str, Any] = {}
    errors = []
    if not partial or "title" in data:
        title = str(data.get("title") or "").strip()
        if not title:
            errors.append("กรุณาระบุหัวข้องาน")
        out["title"] = title[:200]
    if "description" in data:
        out["description"] = str(data.get("description") or "").strip()[:2000]
    if "action_type" in data or not partial:
        at = data.get("action_type") or "corrective"
        out["action_type"] = at if at in TYPE_TH else "corrective"
    if "priority" in data or not partial:
        pr = data.get("priority") or "normal"
        out["priority"] = pr if pr in PRIORITY_TH else "normal"
    if "owner_id" in data:
        try:
            oid = int(data.get("owner_id") or 0) or None
        except (TypeError, ValueError):
            oid = None
        if oid and not db.execute("SELECT 1 FROM users WHERE id=? AND active=1", (oid,)).fetchone():
            errors.append("ไม่พบผู้รับผิดชอบ")
        out["owner_id"] = oid
    if "due_date" in data:
        dd = str(data.get("due_date") or "").strip()
        if dd:
            try:
                date.fromisoformat(dd)
            except ValueError:
                errors.append("วันที่กำหนดเสร็จไม่ถูกต้อง")
        out["due_date"] = dd or None
    if errors:
        raise ValidationError(errors)
    return out


def create_action(db, data: dict, actor_id, now: datetime | None = None) -> int:
    now = now or S.now_dt()
    fields = _clean(data, db)
    fields.setdefault("owner_id", None)
    fields.setdefault("due_date", None)
    link = {k: data.get(k) for k in ("source", "alert_id", "submission_id", "item_key", "form_id", "equipment_id", "factory_id")}
    if link.get("form_id") and not link.get("factory_id"):
        row = db.execute("SELECT factory_id, equipment_id FROM cs_forms WHERE id=?", (link["form_id"],)).fetchone()
        if row:
            link["factory_id"] = row["factory_id"]
            link["equipment_id"] = link.get("equipment_id") or row["equipment_id"]
    if link.get("equipment_id") and not link.get("factory_id"):
        row = db.execute("SELECT factory_id FROM equipment WHERE id=?", (link["equipment_id"],)).fetchone()
        link["factory_id"] = row["factory_id"] if row else None
    now_s = ts(now)
    aid = db.execute("""INSERT INTO cs_actions(code, source, alert_id, submission_id, item_key, form_id, equipment_id, factory_id,
                        title, description, action_type, priority, owner_id, due_date, status, created_by, created_at, updated_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'open', ?,?,?)""",
                     (_next_code(db, now), link.get("source") or "manual", link.get("alert_id"), link.get("submission_id"),
                      link.get("item_key") or "", link.get("form_id"), link.get("equipment_id"), link.get("factory_id"),
                      fields["title"], fields.get("description", ""), fields["action_type"], fields["priority"],
                      fields["owner_id"], fields["due_date"], actor_id, now_s, now_s)).lastrowid
    _event(db, aid, "created", actor_id, fields.get("description", "")[:300], now)
    S.audit(db, actor_id, "create", "cs_actions", aid, after=fields)
    if fields["owner_id"]:
        _notify_owner(db, aid, "มอบหมายงานแก้ไขให้คุณ", now)
    return aid


def create_from_alert(db, alert_id: int, actor_id, now: datetime | None = None) -> int:
    now = now or S.now_dt()
    a = db.execute("""SELECT a.*, f.factory_id FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id WHERE a.id=?""",
                   (alert_id,)).fetchone()
    if not a:
        raise ValidationError("ไม่พบรายการแจ้งเตือน")
    exist = db.execute(f"SELECT id FROM cs_actions WHERE alert_id=? AND status IN ({','.join('?' * len(OPEN))})",
                       (alert_id, *OPEN)).fetchone()
    if exist:
        return exist["id"]
    due = (now.date() + timedelta(days=DUE_DAYS.get(a["severity"], 3))).isoformat()
    aid = create_action(db, {
        "title": f"แก้ไข: {a['title']}"[:200], "description": a["detail"] or "", "priority":
            {"critical": "urgent", "warning": "high"}.get(a["severity"], "normal"),
        "owner_id": a["assigned_to"] or actor_id, "due_date": due, "source": "alert", "alert_id": alert_id,
        "submission_id": a["submission_id"], "item_key": a["item_key"] or "", "form_id": a["form_id"],
        "equipment_id": a["equipment_id"], "factory_id": a["factory_id"]}, actor_id, now)
    code = db.execute("SELECT code FROM cs_actions WHERE id=?", (aid,)).fetchone()[0]
    now_s = ts(now)
    db.execute("INSERT INTO cs_alert_events(alert_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
               (alert_id, "capa", actor_id, code, now_s))
    if a["status"] in ("open", "acknowledged"):
        db.execute("""UPDATE cs_alerts SET status='in_progress', ack_by=COALESCE(ack_by, ?), ack_at=COALESCE(ack_at, ?),
                      assigned_to=COALESCE(assigned_to, ?), updated_at=MAX(updated_at, ?) WHERE id=?""",
                   (actor_id, now_s, a["assigned_to"] or actor_id, now_s, alert_id))
    if a["submission_id"] and a["item_key"]:
        _copy_ng_photos(db, aid, a["submission_id"], a["item_key"], actor_id, now)
    return aid


def create_from_ng(db, submission_id: int, item_key: str, actor_id, now: datetime | None = None) -> int:
    now = now or S.now_dt()
    row = db.execute("""SELECT a.value_text, a.remark, a.judgement, i.name, i.unit, s.form_id, s.equipment_id, f.factory_id,
                               f.name AS form_name, e.code AS eq_code
                        FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id JOIN cs_form_items i ON i.id=a.item_id
                        JOIN cs_forms f ON f.id=s.form_id LEFT JOIN equipment e ON e.id=s.equipment_id
                        WHERE a.submission_id=? AND a.item_key=?""", (submission_id, item_key)).fetchone()
    if not row:
        raise ValidationError("ไม่พบหัวข้อในผลตรวจ")
    exist = db.execute(f"""SELECT id FROM cs_actions WHERE submission_id=? AND item_key=? AND status IN ({','.join('?' * len(OPEN))})""",
                       (submission_id, item_key, *OPEN)).fetchone()
    if exist:
        return exist["id"]
    alert = db.execute("""SELECT id FROM cs_alerts WHERE form_id=? AND item_key=? AND status IN ('open','acknowledged','in_progress')
                          ORDER BY id DESC LIMIT 1""", (row["form_id"], item_key)).fetchone()
    if alert:
        return create_from_alert(db, alert["id"], actor_id, now)
    who = row["eq_code"] or row["form_name"]
    desc = f"{row['name']} = {row['value_text']}{(' ' + row['unit']) if row['unit'] else ''}" + (f" — {row['remark']}" if row["remark"] else "")
    aid = create_action(db, {"title": f"แก้ไข NG: {row['name']} — {who}"[:200], "description": desc, "priority": "high",
                             "owner_id": actor_id, "due_date": (now.date() + timedelta(days=3)).isoformat(), "source": "ng",
                             "submission_id": submission_id, "item_key": item_key, "form_id": row["form_id"],
                             "equipment_id": row["equipment_id"], "factory_id": row["factory_id"]}, actor_id, now)
    _copy_ng_photos(db, aid, submission_id, item_key, actor_id, now)
    return aid


def _copy_ng_photos(db, action_id: int, submission_id: int, item_key: str, actor_id, now) -> None:
    rows = db.execute("""SELECT p.file_path, p.size_kb FROM cs_photos p JOIN cs_answers a ON a.id=p.answer_id
                         WHERE a.submission_id=? AND a.item_key=? LIMIT ?""", (submission_id, item_key, MAX_PHOTOS)).fetchall()
    for r in rows:
        db.execute("""INSERT INTO cs_action_photos(action_id, kind, file_path, size_kb, created_by, created_at)
                      VALUES (?, 'before', ?, ?, ?, ?)""", (action_id, r["file_path"], r["size_kb"], actor_id, ts(now)))


def update_action(db, action_id: int, data: dict, actor_id, now: datetime | None = None) -> None:
    cur = get_action(db, action_id)
    if not cur:
        raise ValidationError("ไม่พบงาน")
    if cur["status"] in ("closed", "cancelled"):
        raise ValidationError("งานนี้ปิดแล้ว แก้ไขไม่ได้")
    fields = _clean(data, db, partial=True)
    if not fields:
        return
    now = now or S.now_dt()
    fields["updated_at"] = ts(now)
    db.execute(f"UPDATE cs_actions SET {', '.join(f'{k}=?' for k in fields)} WHERE id=?", (*fields.values(), action_id))
    changed = [k for k in fields if k != "updated_at" and str(cur.get(k) or "") != str(fields[k] or "")]
    if "owner_id" in changed and fields["owner_id"]:
        _event(db, action_id, "assign", actor_id, f"ผู้รับผิดชอบ: {_user_name(db, fields['owner_id'])}", now)
        _notify_owner(db, action_id, "มอบหมายงานแก้ไขให้คุณ", now)
    other = [k for k in changed if k != "owner_id"]
    if other:
        _event(db, action_id, "update", actor_id, ", ".join(other), now)
    S.audit(db, actor_id, "update", "cs_actions", action_id, before={k: cur.get(k) for k in changed},
            after={k: fields[k] for k in changed})


def _user_name(db, uid) -> str:
    r = db.execute("SELECT name FROM users WHERE id=?", (uid,)).fetchone()
    return r["name"] if r else "-"


def transition(db, action_id: int, action: str, actor_id, *, note: str = "", root_cause: str = "",
               action_taken: str = "", now: datetime | None = None) -> dict:
    cur = get_action(db, action_id)
    if not cur:
        raise ValidationError("ไม่พบงาน")
    if action not in FLOW:
        raise ValidationError("คำสั่งไม่ถูกต้อง")
    allowed, new = FLOW[action]
    if cur["status"] not in allowed:
        raise ValidationError(f"ทำไม่ได้ในสถานะ “{STATUS_TH.get(cur['status'])}”")
    now = now or S.now_dt()
    now_s = ts(now)
    note = (note or "").strip()[:1000]
    sets: dict[str, Any] = {"status": new, "updated_at": now_s}
    if action == "done":
        root_cause = (root_cause or cur["root_cause"] or "").strip()
        action_taken = (action_taken or "").strip() or cur["action_taken"]
        if not root_cause or not action_taken:
            raise ValidationError("กรุณาระบุสาเหตุและการแก้ไขที่ทำ")
        sets.update(root_cause=root_cause[:1000], action_taken=action_taken[:2000], done_at=now_s)
        note = note or action_taken
    if action in ("reject", "cancel", "reopen") and not note:
        raise ValidationError("กรุณาระบุเหตุผล")
    if action == "verify":
        sets.update(verified_by=actor_id, verify_note=note, closed_at=now_s)
    if action == "reopen":
        sets.update(closed_at=None, verified_by=None)
    db.execute(f"UPDATE cs_actions SET {', '.join(f'{k}=?' for k in sets)} WHERE id=?", (*sets.values(), action_id))
    _event(db, action_id, action, actor_id, note, now)
    S.audit(db, actor_id, action, "cs_actions", action_id, before={"status": cur["status"]}, after={"status": new})
    if action == "verify" and cur["alert_id"]:
        # ปิดงานแก้ไข → แจ้งเตือนต้นทางถือว่าแก้ไขแล้ว (ถ้ายังไม่ได้บันทึก)
        a = db.execute("SELECT status FROM cs_alerts WHERE id=?", (cur["alert_id"],)).fetchone()
        if a and a["status"] in ("open", "acknowledged", "in_progress"):
            db.execute("""UPDATE cs_alerts SET status='resolved', root_cause=?, action_taken=?, resolved_by=?, resolved_at=?,
                          ack_at=COALESCE(ack_at, ?), ack_by=COALESCE(ack_by, ?), updated_at=? WHERE id=?""",
                       (sets.get("root_cause") or cur["root_cause"], cur["action_taken"], actor_id, now_s, now_s, actor_id,
                        now_s, cur["alert_id"]))
            db.execute("INSERT INTO cs_alert_events(alert_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
                       (cur["alert_id"], "resolve", actor_id, f"ปิดจากงาน {cur['code']}", now_s))
    if action == "done":
        _notify_managers(db, action_id, "งานแก้ไขเสร็จ รอตรวจรับ", now)
    if action == "reject" and cur["owner_id"]:
        _notify_owner(db, action_id, f"ตรวจรับไม่ผ่าน: {note}", now)
    return get_action(db, action_id)


def add_comment(db, action_id: int, actor_id, text: str, now: datetime | None = None) -> None:
    text = (text or "").strip()
    if not text:
        raise ValidationError("กรุณาพิมพ์ความเห็น")
    if not db.execute("SELECT 1 FROM cs_actions WHERE id=?", (action_id,)).fetchone():
        raise ValidationError("ไม่พบงาน")
    _event(db, action_id, "comment", actor_id, text[:1000], now)
    db.execute("UPDATE cs_actions SET updated_at=? WHERE id=?", (ts(now or S.now_dt()), action_id))


def add_photo(db, action_id: int, kind: str, file_storage, upload_dir: str, max_bytes: int, actor_id,
              now: datetime | None = None) -> int:
    from .submissions import _store_photo
    if kind not in ("before", "after"):
        raise ValidationError("ชนิดรูปไม่ถูกต้อง")
    cur = db.execute("SELECT status FROM cs_actions WHERE id=?", (action_id,)).fetchone()
    if not cur:
        raise ValidationError("ไม่พบงาน")
    if cur["status"] in ("closed", "cancelled"):
        raise ValidationError("งานนี้ปิดแล้ว")
    n = db.execute("SELECT COUNT(*) FROM cs_action_photos WHERE action_id=? AND kind=?", (action_id, kind)).fetchone()[0]
    if n >= MAX_PHOTOS:
        raise ValidationError(f"แนบรูปได้ไม่เกิน {MAX_PHOTOS} รูปต่อประเภท")
    info = _store_photo(file_storage, upload_dir, max_bytes)
    pid = db.execute("""INSERT INTO cs_action_photos(action_id, kind, file_path, size_kb, created_by, created_at)
                        VALUES (?,?,?,?,?,?)""", (action_id, kind, info["rel"], info["size_kb"], actor_id,
                                                  ts(now or S.now_dt()))).lastrowid
    _event(db, action_id, "photo", actor_id, "รูปก่อนแก้ไข" if kind == "before" else "รูปหลังแก้ไข", now)
    return pid


def delete_actions(db, ids: list[int], actor_id, reason: str, upload_dir: str | None = None) -> int:
    """v0.33 ลบงานแก้ไข (หัวหน้างาน/ผู้ดูแลระบบ) — ต้องระบุเหตุผล · เก็บข้อมูลเดิมทั้งหมดไว้ใน Audit Trail"""
    import os
    reason = str(reason or "").strip()[:300]
    if not reason:
        raise ValidationError("กรุณาระบุเหตุผลที่ลบ")
    n = 0
    for aid in dict.fromkeys(int(x) for x in ids):
        row = db.execute("SELECT * FROM cs_actions WHERE id=?", (aid,)).fetchone()
        if not row:
            continue
        photos = [dict(r) for r in db.execute("SELECT * FROM cs_action_photos WHERE action_id=?", (aid,))]
        events = [dict(r) for r in db.execute("SELECT * FROM cs_action_events WHERE action_id=?", (aid,))]
        S.audit(db, actor_id, "delete", "cs_actions", aid, before={**dict(row), "photos": photos, "events": events},
                after={"reason": reason})
        db.execute("DELETE FROM cs_action_photos WHERE action_id=?", (aid,))
        db.execute("DELETE FROM cs_action_events WHERE action_id=?", (aid,))
        db.execute("DELETE FROM cs_actions WHERE id=?", (aid,))
        db.execute("DELETE FROM cs_notifications WHERE url LIKE ?", (f"%/actions/{aid}",))
        if upload_dir:
            for ph in photos:                                   # รูปที่แนบเฉพาะงานนี้ (ไม่ใช่รูปของผลตรวจ)
                used = db.execute("SELECT 1 FROM cs_photos WHERE file_path=? UNION SELECT 1 FROM cs_action_photos WHERE file_path=?",
                                  (ph["file_path"], ph["file_path"])).fetchone()
                path = os.path.join(upload_dir, ph["file_path"])
                if not used and os.path.isfile(path):
                    try:
                        os.remove(path)
                    except OSError:
                        pass
        n += 1
    return n


# ───────────────────────── query ─────────────────────────

_SELECT = """SELECT c.*, u.name AS owner_name, cb.name AS created_name, vb.name AS verified_name, fa.name AS factory_name,
                    e.code AS eq_code, f.name AS form_name, al.status AS alert_status, al.title AS alert_title
             FROM cs_actions c LEFT JOIN users u ON u.id=c.owner_id LEFT JOIN users cb ON cb.id=c.created_by
             LEFT JOIN users vb ON vb.id=c.verified_by LEFT JOIN factories fa ON fa.id=c.factory_id
             LEFT JOIN equipment e ON e.id=c.equipment_id LEFT JOIN cs_forms f ON f.id=c.form_id
             LEFT JOIN cs_alerts al ON al.id=c.alert_id"""


def _decorate(d: dict, today: date) -> dict:
    d["overdue"] = bool(d["due_date"] and d["status"] in ("open", "in_progress") and d["due_date"] < today.isoformat())
    d["days_left"] = (date.fromisoformat(d["due_date"]) - today).days if d["due_date"] else None
    return d


def get_action(db, action_id: int) -> dict | None:
    row = db.execute(_SELECT + " WHERE c.id=?", (action_id,)).fetchone()
    if not row:
        return None
    d = _decorate(dict(row), date.today())
    d["photos"] = [dict(r) for r in db.execute("SELECT * FROM cs_action_photos WHERE action_id=? ORDER BY id", (action_id,))]
    d["events"] = [dict(r) for r in db.execute(
        """SELECT ev.*, u.name AS actor_name FROM cs_action_events ev LEFT JOIN users u ON u.id=ev.actor_id
           WHERE ev.action_id=? ORDER BY ev.created_at DESC, ev.id DESC""", (action_id,))]
    return d


def list_actions(db, *, status: str = "open", owner_id=None, factory_id=None, overdue: bool = False, q: str = "",
                 limit: int = 300) -> list[dict]:
    where, params = ["1=1"], []
    if status == "open":
        where.append("c.status IN ('open','in_progress','done')")
    elif status in STATUS_TH:
        where.append("c.status=?")
        params.append(status)
    if owner_id:
        where.append("c.owner_id=?")
        params.append(owner_id)
    if factory_id:
        where.append("c.factory_id=?")
        params.append(factory_id)
    if overdue:
        where.append("c.status IN ('open','in_progress') AND c.due_date < ?")
        params.append(date.today().isoformat())
    if q:
        where.append("(c.title LIKE ? OR c.code LIKE ? OR e.code LIKE ?)")
        params += [f"%{q}%"] * 3
    rows = db.execute(_SELECT + f""" WHERE {' AND '.join(where)}
        ORDER BY CASE c.status WHEN 'done' THEN 0 WHEN 'in_progress' THEN 1 WHEN 'open' THEN 2 ELSE 3 END,
                 CASE WHEN c.due_date IS NULL THEN 1 ELSE 0 END, c.due_date, c.id DESC LIMIT ?""", params + [limit]).fetchall()
    today = date.today()
    return [_decorate(dict(r), today) for r in rows]


def action_counts(db, owner_id=None, factory_id=None) -> dict:
    cond, params = "", []
    if owner_id:
        cond += " AND owner_id=?"
        params.append(owner_id)
    if factory_id:
        cond += " AND factory_id=?"
        params.append(factory_id)
    today = date.today().isoformat()
    month = today[:7]
    r = db.execute(f"""SELECT SUM(status IN ('open','in_progress')) active, SUM(status='done') waiting,
                              SUM(status IN ('open','in_progress') AND due_date < ?) overdue,
                              SUM(status IN ('open','in_progress') AND due_date BETWEEN ? AND ?) due_week,
                              SUM(status='closed' AND substr(closed_at,1,7)=?) closed_month
                       FROM cs_actions WHERE 1=1 {cond}""",
                   [today, today, (date.today() + timedelta(days=7)).isoformat(), month] + params).fetchone()
    return {k: r[k] or 0 for k in ("active", "waiting", "overdue", "due_week", "closed_month")}


# ───────────────────────── notifications ─────────────────────────

def _notify_owner(db, action_id: int, headline: str, now: datetime | None = None) -> None:
    from . import notify as N
    c = get_action(db, action_id)
    if not c or not c["owner_id"]:
        return
    u = db.execute("SELECT * FROM users WHERE id=? AND active=1", (c["owner_id"],)).fetchone()
    if not u:
        return
    cfg = N.get_settings(db)
    body = f"{c['title']}\nกำหนดเสร็จ: {c['due_date'] or '-'} · ความสำคัญ: {PRIORITY_TH[c['priority']]}"
    N._deliver(db, cfg, _base_url(db), {"users": [dict(u)], "groups": []}, kind="capa", subject=f"🛠 {headline} ({c['code']})",
               body=body, path=f"/actions/{action_id}", severity="warning" if c["priority"] in ("high", "urgent") else "info",
               ref_key=f"capa:{action_id}:{headline}:{ts(now or S.now_dt())}", now=now)


def _notify_managers(db, action_id: int, headline: str, now: datetime | None = None) -> None:
    from . import notify as N
    c = get_action(db, action_id)
    q, params = "SELECT * FROM users WHERE active=1 AND role='supervisor'", []
    if c["factory_id"]:
        q += " AND (factory_id IS NULL OR factory_id=?)"
        params.append(c["factory_id"])
    users = [dict(u) for u in db.execute(q, params)]
    if c["created_by"]:
        cb = db.execute("SELECT * FROM users WHERE id=? AND active=1", (c["created_by"],)).fetchone()
        if cb and cb["id"] not in {u["id"] for u in users}:
            users.append(dict(cb))
    cfg = N.get_settings(db)
    N._deliver(db, cfg, _base_url(db), {"users": users, "groups": []}, kind="capa", subject=f"✅ {headline} ({c['code']})",
               body=f"{c['title']}\nผู้รับผิดชอบ: {c['owner_name'] or '-'}\nการแก้ไข: {c['action_taken']}",
               path=f"/actions/{action_id}", severity="info", ref_key=f"capa_done:{action_id}:{c['done_at']}", now=now)


def _base_url(db) -> str:
    try:
        from flask import current_app
        return current_app.config.get("BASE_URL", "")
    except RuntimeError:
        return ""


def capa_reminders(db, now: datetime | None = None, base_url: str = "") -> dict:
    """เตือนเจ้าของงานเมื่อครบกำหนดพรุ่งนี้/วันนี้ และเมื่อเลยกำหนด (วันละครั้ง) + แจ้งหัวหน้าเมื่อเลยกำหนด"""
    from . import notify as N
    now = now or S.now_dt()
    cfg = N.get_settings(db)
    if not cfg.get("capa_remind"):
        return {"capa_due": 0, "capa_overdue": 0}
    today = now.date()
    out = {"capa_due": 0, "capa_overdue": 0}
    rows = db.execute(_SELECT + """ WHERE c.status IN ('open','in_progress') AND c.due_date IS NOT NULL AND c.due_date <= ?
                                    AND (c.reminded_at IS NULL OR substr(c.reminded_at,1,10) < ?)""",
                      ((today + timedelta(days=1)).isoformat(), today.isoformat())).fetchall()
    for r in rows:
        c = dict(r)
        overdue = c["due_date"] < today.isoformat()
        days = (today - date.fromisoformat(c["due_date"])).days
        subject = (f"⏰ งานแก้ไขเลยกำหนด {days} วัน ({c['code']})" if overdue
                   else f"📅 งานแก้ไขครบกำหนด{'วันนี้' if c['due_date'] == today.isoformat() else 'พรุ่งนี้'} ({c['code']})")
        body = f"{c['title']}\nผู้รับผิดชอบ: {c['owner_name'] or 'ยังไม่ได้มอบหมาย'} · กำหนดเสร็จ {c['due_date']}"
        users: dict[int, dict] = {}
        if c["owner_id"]:
            u = db.execute("SELECT * FROM users WHERE id=? AND active=1", (c["owner_id"],)).fetchone()
            if u:
                users[u["id"]] = dict(u)
        if overdue or not c["owner_id"]:
            q, params = "SELECT * FROM users WHERE active=1 AND role='supervisor'", []
            if c["factory_id"]:
                q += " AND (factory_id IS NULL OR factory_id=?)"
                params.append(c["factory_id"])
            for u in db.execute(q, params):
                users[u["id"]] = dict(u)
        N._deliver(db, cfg, base_url, {"users": list(users.values()), "groups": []}, kind="capa", subject=subject, body=body,
                   path=f"/actions/{c['id']}", severity="warning" if overdue else "info",
                   ref_key=f"capa_rem:{c['id']}:{today.isoformat()}", now=now)
        db.execute("UPDATE cs_actions SET reminded_at=? WHERE id=?", (ts(now), c["id"]))
        out["capa_overdue" if overdue else "capa_due"] += 1
    return out



# ───────────────────────── แจ้งปัญหาจากหน้างาน (นอกเช็คชีท) ─────────────────────────

MAX_REPORT_PHOTOS = 5


def report_problem(db, equipment_id: int, text: str, actor_id, *, urgent: bool = False, photos=None,
                   upload_dir: str = "", max_bytes: int = 10 * 1024 * 1024, now: datetime | None = None) -> dict:
    """ช่างสแกน QR เครื่อง → พิมพ์ปัญหา 1 บรรทัด + ถ่ายรูป → เปิดงานแก้ไข (CAPA) ให้ทันที และแจ้งหัวหน้างานของโรงงาน"""
    now = now or S.now_dt()
    text = " ".join(str(text or "").split())
    if len(text) < 3:
        raise ValidationError("พิมพ์ปัญหาที่พบอย่างน้อย 3 ตัวอักษร")
    eq = db.execute("SELECT id, code, name, factory_id FROM equipment WHERE id=?", (equipment_id,)).fetchone()
    if not eq:
        raise ValidationError("ไม่พบเครื่องจักร")
    photos = [p for p in (photos or []) if p and getattr(p, "filename", "")][:MAX_REPORT_PHOTOS]
    reporter = _user_name(db, actor_id)
    form = db.execute("SELECT id FROM cs_forms WHERE equipment_id=? AND active=1 ORDER BY id LIMIT 1", (equipment_id,)).fetchone()
    due = (now.date() + timedelta(days=1 if urgent else 3)).isoformat()
    aid = create_action(db, {
        "title": f"[{eq['code']}] {text}"[:200],
        "description": f"แจ้งจากหน้างานโดย {reporter or '-'} (สแกน QR เครื่อง {eq['code']} {eq['name']})\n{text}",
        "priority": "urgent" if urgent else "high", "due_date": due, "source": "report",
        "equipment_id": eq["id"], "factory_id": eq["factory_id"], "form_id": form["id"] if form else None,
    }, actor_id, now)
    for p in photos:
        add_photo(db, aid, "before", p, upload_dir, max_bytes, actor_id, now)
    c = get_action(db, aid)
    try:
        _notify_managers_new(db, aid, now)
    except Exception:                                   # noqa: BLE001 — แจ้งเตือนล้มเหลวไม่ทำให้การแจ้งปัญหาหาย
        pass
    return {"id": aid, "code": c["code"], "due_date": due, "photos": len(photos)}


def _notify_managers_new(db, action_id: int, now: datetime | None = None) -> None:
    from . import notify as N
    c = get_action(db, action_id)
    q, params = "SELECT * FROM users WHERE active=1 AND role IN ('supervisor','admin')", []
    if c["factory_id"]:
        q += " AND (factory_id IS NULL OR factory_id=?)"
        params.append(c["factory_id"])
    users = [dict(u) for u in db.execute(q, params) if u["role"] == "supervisor" or u["factory_id"]]
    if not users:
        users = [dict(u) for u in db.execute("SELECT * FROM users WHERE active=1 AND role='admin'")]
    cfg = N.get_settings(db)
    N._deliver(db, cfg, _base_url(db), {"users": users, "groups": []}, kind="capa",
               subject=f"{'🚨' if c['priority'] == 'urgent' else '⚠'} แจ้งปัญหาจากหน้างาน ({c['code']})",
               body=f"{c['title']}\nผู้แจ้ง: {c['created_name'] or '-'} · กำหนดเสร็จ: {c['due_date'] or '-'}",
               path=f"/actions/{action_id}", severity="warning" if c["priority"] == "urgent" else "info",
               ref_key=f"capa_report:{action_id}", now=now)
