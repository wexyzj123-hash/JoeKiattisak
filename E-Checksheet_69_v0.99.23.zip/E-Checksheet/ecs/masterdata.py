"""ecs/masterdata.py — ข้อมูลหลัก: ผู้ใช้, โรงงาน, พื้นที่, เครื่องจักร (รวมนำเข้า CSV)"""
from __future__ import annotations

import csv
import io
import re
import secrets

from .schema import ROLES
from .security import hash_password, password_problem
from .services import ValidationError, audit, row_dict, ts

_CODE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-/]{0,39}$")                 # รหัสโรงงาน
_EQ_CODE_RE = re.compile(r"^[^\s\\?#%<>\"'][^\\?#%<>\"'\t\r\n]{0,39}$")     # รหัสเครื่อง: มีเว้นวรรค/ภาษาไทยได้
_USER_RE = re.compile(r"^[A-Za-z0-9._\-]{3,40}$")


def new_qr_token() -> str:
    return secrets.token_urlsafe(9)   # 12 ตัวอักษร เดาไม่ได้ ใช้ใน URL ของ QR


# ───────────────────────── factories & areas ─────────────────────────

def list_factories(db, include_inactive: bool = False) -> list[dict]:
    where = "" if include_inactive else "WHERE active=1"
    return [dict(r) for r in db.execute(f"SELECT * FROM factories {where} ORDER BY sort_no, name")]


def save_factory(db, data: dict, actor_id, factory_id: int | None = None) -> int:
    code = str(data.get("code") or "").strip().upper()
    name = str(data.get("name") or "").strip()
    if not _CODE_RE.match(code):
        raise ValidationError("รหัสโรงงานใช้ได้เฉพาะ A-Z 0-9 . _ - (ไม่เกิน 40 ตัว)")
    if not name:
        raise ValidationError("กรุณาระบุชื่อโรงงาน")
    dup = db.execute("SELECT id FROM factories WHERE code=? AND id<>?", (code, factory_id or 0)).fetchone()
    if dup:
        raise ValidationError(f"รหัสโรงงาน {code} ถูกใช้แล้ว")
    try:
        sort_no = int(data.get("sort_no") or 0)
    except ValueError:
        sort_no = 0
    active = 0 if data.get("active") in (0, "0", False) else 1
    if factory_id:
        db.execute("UPDATE factories SET code=?, name=?, sort_no=?, active=? WHERE id=?",
                   (code, name[:100], sort_no, active, factory_id))
    else:
        factory_id = db.execute("INSERT INTO factories(code, name, sort_no, active) VALUES (?,?,?,?)",
                                (code, name[:100], sort_no, active)).lastrowid
    audit(db, actor_id, "save", "factories", factory_id, after={"code": code, "name": name, "active": active})
    return factory_id


def list_areas(db, factory_id: int | None = None, include_inactive: bool = False) -> list[dict]:
    where, params = ["1=1"], []
    if factory_id:
        where.append("a.factory_id=?")
        params.append(factory_id)
    if not include_inactive:
        where.append("a.active=1")
    return [dict(r) for r in db.execute(f"""
        SELECT a.*, f.name AS factory_name,
               (SELECT COUNT(*) FROM equipment e WHERE e.area_id=a.id AND e.active=1) AS equipment_count
        FROM areas a JOIN factories f ON f.id=a.factory_id
        WHERE {' AND '.join(where)} ORDER BY f.sort_no, a.name""", params)]


def get_or_create_area(db, factory_id: int, name: str) -> int | None:
    name = (name or "").strip()
    if not name:
        return None
    row = db.execute("SELECT id FROM areas WHERE factory_id=? AND name=?", (factory_id, name)).fetchone()
    if row:
        return row["id"]
    return db.execute("INSERT INTO areas(factory_id, name) VALUES (?,?)", (factory_id, name[:100])).lastrowid


def save_area(db, data: dict, actor_id, area_id: int | None = None) -> int:
    name = str(data.get("name") or "").strip()
    try:
        factory_id = int(data.get("factory_id") or 0)
    except ValueError:
        factory_id = 0
    if not db.execute("SELECT 1 FROM factories WHERE id=?", (factory_id,)).fetchone():
        raise ValidationError("กรุณาเลือกโรงงาน")
    if not name:
        raise ValidationError("กรุณาระบุชื่อพื้นที่")
    dup = db.execute("SELECT id FROM areas WHERE factory_id=? AND name=? AND id<>?",
                     (factory_id, name, area_id or 0)).fetchone()
    if dup:
        raise ValidationError(f"มีพื้นที่ชื่อ {name} ในโรงงานนี้แล้ว")
    active = 0 if data.get("active") in (0, "0", False) else 1
    if area_id:
        db.execute("UPDATE areas SET factory_id=?, name=?, active=? WHERE id=?", (factory_id, name[:100], active, area_id))
        # ย้ายพื้นที่ไปโรงงานอื่น → เครื่องจักร/แบบฟอร์มในพื้นที่ย้ายโรงงานตาม
        db.execute("UPDATE equipment SET factory_id=? WHERE area_id=? AND IFNULL(factory_id, -1)<>?", (factory_id, area_id, factory_id))
        db.execute("UPDATE cs_forms SET factory_id=? WHERE area_id=? AND IFNULL(factory_id, -1)<>?", (factory_id, area_id, factory_id))
    else:
        area_id = db.execute("INSERT INTO areas(factory_id, name, active) VALUES (?,?,?)",
                             (factory_id, name[:100], active)).lastrowid
    audit(db, actor_id, "save", "areas", area_id, after={"factory_id": factory_id, "name": name})
    return area_id


# ───────────────────────── equipment ─────────────────────────

def list_equipment(db, factory_id: int | None = None, area_id: int | None = None, q: str = "",
                   include_inactive: bool = False) -> list[dict]:
    where, params = ["1=1"], []
    if factory_id:
        where.append("e.factory_id=?")
        params.append(factory_id)
    if area_id:
        where.append("e.area_id=?")
        params.append(area_id)
    if q:
        where.append("(e.code LIKE ? OR e.name LIKE ? OR e.eq_type LIKE ?)")
        params += [f"%{q}%"] * 3
    if not include_inactive:
        where.append("e.active=1")
    return [dict(r) for r in db.execute(f"""
        SELECT e.*, f.name AS factory_name, a.name AS area_name,
               (SELECT COUNT(*) FROM cs_forms cf WHERE cf.equipment_id=e.id AND cf.active=1) AS form_count
        FROM equipment e LEFT JOIN factories f ON f.id=e.factory_id LEFT JOIN areas a ON a.id=e.area_id
        WHERE {' AND '.join(where)} ORDER BY f.sort_no, e.code""", params)]


def get_equipment(db, equipment_id: int) -> dict | None:
    return row_dict(db.execute("""
        SELECT e.*, f.name AS factory_name, a.name AS area_name FROM equipment e
        LEFT JOIN factories f ON f.id=e.factory_id LEFT JOIN areas a ON a.id=e.area_id WHERE e.id=?""",
                               (equipment_id,)).fetchone())


def get_equipment_by_token(db, token: str) -> dict | None:
    return row_dict(db.execute("SELECT * FROM equipment WHERE qr_token=? AND active=1", (token,)).fetchone())


def save_equipment(db, data: dict, actor_id, equipment_id: int | None = None) -> int:
    errors = []
    code = str(data.get("code") or "").strip()
    name = str(data.get("name") or "").strip()
    code = re.sub(r"\s+", " ", code)
    if not _EQ_CODE_RE.match(code):
        errors.append("รหัสเครื่องยาวได้ไม่เกิน 40 ตัว และห้ามมีเครื่องหมาย \\ ? # % < > \" '")
    if not name:
        errors.append("กรุณาระบุชื่อเครื่องจักร")
    try:
        factory_id = int(data.get("factory_id") or 0) or None
        area_id = int(data.get("area_id") or 0) or None
    except ValueError:
        factory_id = area_id = None
        errors.append("โรงงาน/พื้นที่ไม่ถูกต้อง")
    if factory_id and not db.execute("SELECT 1 FROM factories WHERE id=?", (factory_id,)).fetchone():
        errors.append("ไม่พบโรงงานที่เลือก")
    if area_id:
        ar = db.execute("SELECT factory_id FROM areas WHERE id=?", (area_id,)).fetchone()
        if not ar:
            errors.append("ไม่พบพื้นที่ที่เลือก")
        elif factory_id and ar["factory_id"] != factory_id:
            errors.append("พื้นที่ไม่อยู่ในโรงงานที่เลือก")
        elif not factory_id:
            factory_id = ar["factory_id"]
    if code and db.execute("SELECT 1 FROM equipment WHERE code=? AND id<>?", (code, equipment_id or 0)).fetchone():
        errors.append(f"รหัสเครื่อง {code} ถูกใช้แล้ว")
    if errors:
        raise ValidationError(errors)
    active = 0 if data.get("active") in (0, "0", False) else 1
    fields = (code, name[:200], str(data.get("eq_type") or "").strip()[:60], factory_id, area_id,
              str(data.get("location") or "").strip()[:200], active, str(data.get("note") or "")[:1000])
    now = ts()
    if equipment_id:
        before = get_equipment(db, equipment_id)
        db.execute("""UPDATE equipment SET code=?, name=?, eq_type=?, factory_id=?, area_id=?, location=?,
                      active=?, note=?, updated_at=? WHERE id=?""", fields + (now, equipment_id))
        audit(db, actor_id, "update", "equipment", equipment_id,
              before={k: before[k] for k in ("code", "name", "factory_id", "area_id", "active")},
              after={"code": code, "name": name, "factory_id": factory_id, "area_id": area_id, "active": active})
        from .services import sync_forms_to_equipment
        sync_forms_to_equipment(db, equipment_id)     # แบบฟอร์มของเครื่องย้ายโรงงาน/พื้นที่ตามเครื่อง
    else:
        equipment_id = db.execute("""INSERT INTO equipment(code, name, eq_type, factory_id, area_id, location,
                                     active, note, qr_token, legacy_id, created_at, updated_at)
                                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                                  fields + (new_qr_token(), data.get("legacy_id"), now, now)).lastrowid
        audit(db, actor_id, "create", "equipment", equipment_id, after={"code": code, "name": name})
    return equipment_id


def regenerate_qr(db, equipment_id: int, actor_id) -> str:
    token = new_qr_token()
    db.execute("UPDATE equipment SET qr_token=?, updated_at=? WHERE id=?", (token, ts(), equipment_id))
    audit(db, actor_id, "regenerate_qr", "equipment", equipment_id)
    return token


EQUIPMENT_CSV_HEADERS = ["code", "name", "eq_type", "factory", "area", "location"]


def import_equipment_csv(db, text: str, actor_id) -> dict:
    """นำเข้า/อัปเดตเครื่องจักรจาก CSV (คอลัมน์: code,name,eq_type,factory,area,location)
    factory ใส่ได้ทั้งรหัส (F1) หรือชื่อ (Factory 1) · area ที่ยังไม่มีจะถูกสร้างให้"""
    reader = csv.DictReader(io.StringIO(text.lstrip("﻿")))
    if not reader.fieldnames or not {"code", "name"} <= {h.strip().lower() for h in reader.fieldnames}:
        raise ValidationError("ไฟล์ CSV ต้องมีหัวคอลัมน์อย่างน้อย code,name")
    factories = {}
    for f in db.execute("SELECT id, code, name FROM factories"):
        factories[f["code"].lower()] = f["id"]
        factories[f["name"].lower()] = f["id"]
    result = {"created": 0, "updated": 0, "errors": []}
    for line_no, raw in enumerate(reader, start=2):
        row = {(k or "").strip().lower(): (v or "").strip() for k, v in raw.items()}
        if not any(row.values()):
            continue
        fac_key = row.get("factory", "").lower()
        factory_id = factories.get(fac_key) if fac_key else None
        if fac_key and not factory_id:
            result["errors"].append(f"บรรทัด {line_no}: ไม่พบโรงงาน '{row.get('factory')}'")
            continue
        area_id = get_or_create_area(db, factory_id, row.get("area", "")) if factory_id else None
        existing = db.execute("SELECT id FROM equipment WHERE code=?", (row.get("code", ""),)).fetchone()
        data = {"code": row.get("code"), "name": row.get("name"), "eq_type": row.get("eq_type", ""),
                "factory_id": factory_id, "area_id": area_id, "location": row.get("location", "")}
        try:
            save_equipment(db, data, actor_id, existing["id"] if existing else None)
            result["updated" if existing else "created"] += 1
        except ValidationError as exc:
            result["errors"].extend(f"บรรทัด {line_no}: {e}" for e in exc.errors)
    return result


# ───────────────────────── users ─────────────────────────

def _set_position(db, user_id: int, pos) -> None:
    """v0.25 ตำแหน่งงาน (ใช้กำหนดสิทธิ์ลงนามในใบบันทึก)"""
    from .signoffs import POSITIONS
    pos = str(pos or "").strip()
    db.execute("UPDATE users SET position=? WHERE id=?", (pos if pos in POSITIONS else "", user_id))


def set_restrict_view(db, user_id: int, on, actor_id) -> bool:
    """v0.29 จำกัดการดู: เห็นเฉพาะเช็คชีท ENVIRONMENT / SAFETY ที่มีสิทธิ์ลงนาม-อนุมัติ (ไม่มีผลกับผู้ดูแลระบบ)"""
    on = 1 if on else 0
    r = db.execute("SELECT role, COALESCE(restrict_view,0) FROM users WHERE id=?", (user_id,)).fetchone()
    if not r or r[1] == on:
        return False
    db.execute("UPDATE users SET restrict_view=? WHERE id=?", (on, user_id))
    audit(db, actor_id, "restrict_view", "users", user_id, before=r[1], after=on)
    return True


def list_users(db, include_inactive: bool = True) -> list[dict]:
    where = "WHERE u.username<>'_auto'" if include_inactive else "WHERE u.active=1 AND u.username<>'_auto'"
    return [dict(r) for r in db.execute(f"""
        SELECT u.id, u.username, u.name, u.role, u.factory_id, u.email, u.phone, u.telegram_chat_id,
               u.active, u.last_login_at, u.must_change_pw, u.legacy_id, COALESCE(u.position, '') AS position, COALESCE(u.can_approve, 0) AS can_approve, COALESCE(u.restrict_view, 0) AS restrict_view, f.name AS factory_name
        FROM users u LEFT JOIN factories f ON f.id=u.factory_id {where}
        ORDER BY u.active DESC, CASE u.role WHEN 'admin' THEN 0 WHEN 'supervisor' THEN 1
                 WHEN 'technician' THEN 2 ELSE 3 END, u.name""")]


def count_users(db) -> int:
    return db.execute("SELECT COUNT(*) FROM users").fetchone()[0]


def get_user(db, user_id: int) -> dict | None:
    return row_dict(db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone())


def save_user(db, data: dict, actor_id, user_id: int | None = None) -> int:
    errors = []
    username = str(data.get("username") or "").strip()
    name = str(data.get("name") or "").strip()
    role = str(data.get("role") or "technician")
    password = str(data.get("password") or "")
    if not _USER_RE.match(username):
        errors.append("ชื่อผู้ใช้ 3–40 ตัว ใช้ได้เฉพาะ A-Z a-z 0-9 . _ -")
    if not name:
        errors.append("กรุณาระบุชื่อ-นามสกุล")
    if role not in ROLES:
        errors.append("บทบาทไม่ถูกต้อง")
    if db.execute("SELECT 1 FROM users WHERE username=? AND id<>?", (username, user_id or 0)).fetchone():
        errors.append(f"ชื่อผู้ใช้ {username} ถูกใช้แล้ว")
    if not user_id or password:
        problem = password_problem(password)
        if problem:
            errors.append(problem)
    try:
        factory_id = int(data.get("factory_id") or 0) or None
    except ValueError:
        factory_id = None
    if factory_id and not db.execute("SELECT 1 FROM factories WHERE id=?", (factory_id,)).fetchone():
        errors.append("ไม่พบโรงงานที่เลือก")
    active = 0 if data.get("active") in (0, "0", False) else 1
    if user_id and (not active or role != "admin"):
        # ห้ามปิด/ลดสิทธิ์ผู้ดูแลระบบคนสุดท้าย
        others = db.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1 AND id<>?",
                            (user_id,)).fetchone()[0]
        me = db.execute("SELECT role, active FROM users WHERE id=?", (user_id,)).fetchone()
        if me and me["role"] == "admin" and me["active"] and others == 0:
            errors.append("ต้องมีผู้ดูแลระบบที่ใช้งานอยู่อย่างน้อย 1 คน")
    if errors:
        raise ValidationError(errors)
    now = ts()
    vals = (username, name[:100], role, factory_id, str(data.get("email") or "")[:120],
            str(data.get("phone") or "")[:40], str(data.get("telegram_chat_id") or "")[:40], active)
    if user_id:
        db.execute("""UPDATE users SET username=?, name=?, role=?, factory_id=?, email=?, phone=?,
                      telegram_chat_id=?, active=?, updated_at=? WHERE id=?""", vals + (now, user_id))
        if "line_user_id" in data or "notify_channels" in data:
            set_contacts(db, user_id, data, actor_id, audit_it=False)
        if "can_delete_results" in data:
            db.execute("UPDATE users SET can_delete_results=? WHERE id=?", (1 if data["can_delete_results"] else 0, user_id))
        if "position" in data:
            _set_position(db, user_id, data.get("position"))
        if "can_approve" in data:
            db.execute("UPDATE users SET can_approve=? WHERE id=?", (1 if data["can_approve"] else 0, user_id))
        if "restrict_view" in data:
            set_restrict_view(db, user_id, data["restrict_view"], actor_id)
        if password:
            db.execute("UPDATE users SET password=?, must_change_pw=? WHERE id=?",
                       (hash_password(password), 1 if actor_id != user_id else 0, user_id))
        audit(db, actor_id, "update", "users", user_id,
              after={"username": username, "role": role, "factory_id": factory_id, "active": active,
                     "password_changed": bool(password), "can_delete_results": data.get("can_delete_results")})
    else:
        user_id = db.execute("""INSERT INTO users(username, name, role, factory_id, email, phone, telegram_chat_id,
                                active, password, must_change_pw, legacy_id, created_at, updated_at)
                                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                             vals + (hash_password(password), 1 if data.get("must_change_pw", 1) else 0,
                                     data.get("legacy_id"), now, now)).lastrowid
        if data.get("can_delete_results"):
            db.execute("UPDATE users SET can_delete_results=1 WHERE id=?", (user_id,))
        if data.get("position"):
            _set_position(db, user_id, data.get("position"))
        if data.get("can_approve"):
            db.execute("UPDATE users SET can_approve=1 WHERE id=?", (user_id,))
        if data.get("restrict_view"):
            set_restrict_view(db, user_id, 1, actor_id)
        audit(db, actor_id, "create", "users", user_id, after={"username": username, "role": role})
        if "line_user_id" in data or "notify_channels" in data:
            set_contacts(db, user_id, data, actor_id, audit_it=False)
    return user_id


NOTIFY_CHANNELS = ("telegram", "line", "email")
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def set_contacts(db, user_id: int, data: dict, actor_id, audit_it: bool = True) -> None:
    """ช่องทางรับแจ้งเตือนส่วนตัว: Telegram chat id, LINE user id, อีเมล + เลือกช่องทางที่ต้องการรับ"""
    errors = []
    email = str(data.get("email") or "").strip()[:120]
    tg = str(data.get("telegram_chat_id") or "").strip()[:40]
    line = str(data.get("line_user_id") or "").strip()[:60]
    if email and not _EMAIL_RE.match(email):
        errors.append("รูปแบบอีเมลไม่ถูกต้อง")
    if tg and not re.match(r"^-?\d{3,20}$", tg):
        errors.append("Telegram chat id ต้องเป็นตัวเลข (กลุ่มขึ้นต้นด้วย -)")
    if line and not re.match(r"^[UCR][0-9a-f]{32}$", line):
        errors.append("LINE user id ต้องขึ้นต้นด้วย U และตามด้วยตัวอักษร 32 ตัว")
    raw = data.get("notify_channels")
    if isinstance(raw, str):
        raw = [x for x in raw.split(",") if x]
    chans = ["app"] + [c for c in (raw or []) if c in NOTIFY_CHANNELS]
    if errors:
        raise ValidationError(errors)
    db.execute("UPDATE users SET email=?, telegram_chat_id=?, line_user_id=?, notify_channels=?, updated_at=? WHERE id=?",
               (email, tg, line, ",".join(chans), ts(), user_id))
    if audit_it:
        audit(db, actor_id, "update", "user_contacts", user_id, after={"channels": chans})


def change_own_password(db, user_id: int, current: str, new: str, confirm: str) -> None:
    from .security import verify_password
    user = get_user(db, user_id)
    if not user or not verify_password(user["password"], current):
        raise ValidationError("รหัสผ่านปัจจุบันไม่ถูกต้อง")
    if new != confirm:
        raise ValidationError("ยืนยันรหัสผ่านใหม่ไม่ตรงกัน")
    if new == current:
        raise ValidationError("รหัสผ่านใหม่ต้องไม่เหมือนรหัสผ่านเดิม")
    problem = password_problem(new)
    if problem:
        raise ValidationError(problem)
    db.execute("UPDATE users SET password=?, must_change_pw=0, updated_at=? WHERE id=?",
               (hash_password(new), ts(), user_id))
    audit(db, user_id, "change_password", "users", user_id)


# ───────────────────────── ผังโรงงาน + หมุดพื้นที่ ─────────────────────────

MAX_LAYOUT_BYTES = 60 * 1024 * 1024            # ต้นฉบับ (ระบบย่อก่อนเก็บ)


def set_factory_layout(db, factory_id: int, data: bytes | None, upload_dir: str, actor_id) -> str:
    """บันทึกรูปผังโรงงาน (JPG/PNG/WEBP) หรือ data=None เพื่อลบ → คืน path ใน uploads"""
    import os
    import uuid
    f = db.execute("SELECT id, code, layout_image FROM factories WHERE id=?", (factory_id,)).fetchone()
    if not f:
        raise ValidationError("ไม่พบโรงงาน")
    rel = ""
    if data is not None:
        if not data:
            raise ValidationError("กรุณาเลือกไฟล์รูป")
        if len(data) > MAX_LAYOUT_BYTES:
            raise ValidationError(f"ไฟล์ผังใหญ่เกิน {MAX_LAYOUT_BYTES // (1024 * 1024)} MB")
        from .imaging import ImageError, process
        try:
            data, ext = process(data, max_side=2400, quality=88, keep_png=True)   # ผังต้องคมชัด → ย่อไม่เกิน 2400px
        except ImageError as exc:
            raise ValidationError(str(exc)) from None
        rel = f"layouts/{f['code']}_{uuid.uuid4().hex[:10]}.{ext}"
        full = os.path.join(upload_dir, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "wb") as fh:
            fh.write(data)
    db.execute("UPDATE factories SET layout_image=? WHERE id=?", (rel, factory_id))
    audit(db, actor_id, "update", "factory_layout", factory_id, before={"layout_image": f["layout_image"]},
          after={"layout_image": rel})
    return rel


def set_area_pin(db, area_id: int, x, y, actor_id) -> None:
    """ตำแหน่งหมุดพื้นที่บนผัง (0–100 % ของความกว้าง/สูง) หรือ None เพื่อเอาออก"""
    a = db.execute("SELECT id, map_x, map_y FROM areas WHERE id=?", (area_id,)).fetchone()
    if not a:
        raise ValidationError("ไม่พบพื้นที่")
    if x is None or y is None:
        nx = ny = None
    else:
        try:
            nx, ny = round(float(x), 2), round(float(y), 2)
        except (TypeError, ValueError):
            raise ValidationError("ตำแหน่งไม่ถูกต้อง") from None
        if not (0 <= nx <= 100 and 0 <= ny <= 100):
            raise ValidationError("ตำแหน่งต้องอยู่ในผัง")
    db.execute("UPDATE areas SET map_x=?, map_y=? WHERE id=?", (nx, ny, area_id))
    audit(db, actor_id, "update", "area_pin", area_id, before={"x": a["map_x"], "y": a["map_y"]}, after={"x": nx, "y": ny})



def set_area_layout(db, area_id: int, data: bytes | None, upload_dir: str, actor_id) -> str:
    """รูปผังย่อยของพื้นที่ (ห้อง / อาคาร / ไลน์) หรือ data=None เพื่อลบ"""
    import os
    import uuid
    a = db.execute("SELECT id, layout_image FROM areas WHERE id=?", (area_id,)).fetchone()
    if not a:
        raise ValidationError("ไม่พบพื้นที่")
    rel = ""
    if data is not None:
        if not data:
            raise ValidationError("กรุณาเลือกไฟล์รูป")
        if len(data) > MAX_LAYOUT_BYTES:
            raise ValidationError(f"ไฟล์ผังใหญ่เกิน {MAX_LAYOUT_BYTES // (1024 * 1024)} MB")
        from .imaging import ImageError, process
        try:
            data, ext = process(data, max_side=2400, quality=88, keep_png=True)
        except ImageError as exc:
            raise ValidationError(str(exc)) from None
        rel = f"layouts/area{area_id}_{uuid.uuid4().hex[:10]}.{ext}"
        full = os.path.join(upload_dir, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "wb") as fh:
            fh.write(data)
    db.execute("UPDATE areas SET layout_image=? WHERE id=?", (rel, area_id))
    audit(db, actor_id, "update", "area_layout", area_id, before={"layout_image": a["layout_image"]}, after={"layout_image": rel})
    return rel


MAX_ICON_BYTES = 10 * 1024 * 1024               # v0.99.3 รูปไอคอนพื้นที่ (ต้นฉบับ · ระบบย่อเหลือด้านยาว 320 px)


def set_area_icon(db, area_id: int, data: bytes | None, upload_dir: str, actor_id) -> str:
    """v0.99.3 รูปไอคอนของพื้นที่ (แสดงบนการ์ดสถานะรายพื้นที่) หรือ data=None เพื่อลบ — รับเฉพาะไฟล์รูป (JPG/PNG/WEBP/HEIC) ไม่รับ SVG"""
    import os
    import uuid
    a = db.execute("SELECT id, icon_image FROM areas WHERE id=?", (area_id,)).fetchone()
    if not a:
        raise ValidationError("ไม่พบพื้นที่")
    rel = ""
    if data is not None:
        if not data:
            raise ValidationError("กรุณาเลือกไฟล์รูป")
        if len(data) > MAX_ICON_BYTES:
            raise ValidationError(f"ไฟล์รูปใหญ่เกิน {MAX_ICON_BYTES // (1024 * 1024)} MB")
        from .imaging import ImageError, process
        try:
            data, ext = process(data, max_side=320, quality=88, keep_png=True)
        except ImageError as exc:
            raise ValidationError(str(exc)) from None
        rel = f"icons/area{area_id}_{uuid.uuid4().hex[:10]}.{ext}"
        full = os.path.join(upload_dir, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "wb") as fh:
            fh.write(data)
    old = a["icon_image"] or ""
    db.execute("UPDATE areas SET icon_image=? WHERE id=?", (rel, area_id))
    audit(db, actor_id, "update", "area_icon", area_id, before={"icon_image": old}, after={"icon_image": rel})
    if old.startswith("icons/") and "/" not in old[6:] and ".." not in old:      # ลบไฟล์เก่า (เฉพาะในโฟลเดอร์ icons)
        try:
            os.remove(os.path.join(upload_dir, old))
        except OSError:
            pass
    return rel


def set_equipment_pin(db, equipment_id: int, x, y, actor_id) -> None:
    """ตำแหน่งเครื่องบนผังย่อยของพื้นที่ (0–100 %) หรือ None เพื่อเอาออก"""
    e = db.execute("SELECT id, map_x, map_y FROM equipment WHERE id=?", (equipment_id,)).fetchone()
    if not e:
        raise ValidationError("ไม่พบเครื่องจักร")
    if x is None or y is None:
        nx = ny = None
    else:
        try:
            nx, ny = round(float(x), 2), round(float(y), 2)
        except (TypeError, ValueError):
            raise ValidationError("ตำแหน่งไม่ถูกต้อง") from None
        if not (0 <= nx <= 100 and 0 <= ny <= 100):
            raise ValidationError("ตำแหน่งต้องอยู่ในผัง")
    db.execute("UPDATE equipment SET map_x=?, map_y=? WHERE id=?", (nx, ny, equipment_id))
    audit(db, actor_id, "update", "equipment_pin", equipment_id, before={"x": e["map_x"], "y": e["map_y"]},
          after={"x": nx, "y": ny})
