"""ecs/energy_registry.py — v0.65 ทะเบียนมิเตอร์ ส่งออก Excel → แก้ใน Excel → นำเข้ากลับ (ดูก่อนแล้วยืนยัน)

คอลัมน์: ID | โรงงาน | หมวดหมู่ | No./รหัส | ชื่อ | Section | ตำแหน่ง/จ่ายให้ | หน่วย | CT | ราคา/หน่วย |
         บทบาท (หลัก/ย่อย/หักออก/ไม่นับรวม) | ใช้งาน (1/0) | จำนวนหลัก | Tag SCADA | หมายเหตุ | ลบ (ใส่ 1)
- มี ID = แก้มิเตอร์เดิม · ID ว่าง = เพิ่มมิเตอร์ใหม่ · ลบ = 1 → ลบ (ถ้ายังไม่มีค่าอ่าน) หรือปิดใช้งาน (มีค่าอ่านแล้ว)
- ช่างแก้ได้เฉพาะมิเตอร์ของโรงงานตัวเอง
"""
from __future__ import annotations

import io

from . import energy as EN
from . import services as S
from . import energy_struct as ST

COLS = [("id", "ID"), ("factory", "โรงงาน"), ("kind", "หมวดหมู่"), ("code", "No./รหัส"), ("name", "ชื่อ"), ("grp", "Section"), ("line", "Line"), ("project", "Project"),
        ("location", "ตำแหน่ง/จ่ายให้"), ("unit", "หน่วย"), ("multiplier", "CT/ตัวคูณ"), ("price", "ราคา/หน่วย"),
        ("role", "บทบาท"), ("active", "ใช้งาน"), ("digits", "จำนวนหลัก"), ("scada_tag", "Tag SCADA"), ("note", "หมายเหตุ"),
        ("delete", "ลบ")]
ROLE = {1: "หลัก", 0: "ย่อย", -1: "หักออก", 2: "ไม่นับรวม"}
ROLE_IN = {"หลัก": 1, "main": 1, "1": 1, "ย่อย": 0, "sub": 0, "0": 0, "": 0, "หักออก": -1, "minus": -1, "-1": -1, "solar": -1, "ไม่นับรวม": 2, "ไม่นับ": 2, "2": 2, "info": 2}


def export_xlsx(db, factory_id=None, kind=None) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    EN.ensure(db)
    ms = EN.meters(db, factory_id, kind, active_only=False)
    wb = Workbook()
    ws = wb.active
    ws.title = "ทะเบียนมิเตอร์"
    ws.append([h for _, h in COLS])
    for c in ws[1]:
        c.font, c.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="1D4ED8")
    for m in ms:
        ws.append([m["id"], m["factory_name"] or "", EN.KINDS.get(m["kind"], {}).get("th", m["kind"]), m["code"], m["name"], m["grp"], m.get("line") or "", m.get("project_name") or "",
                   m.get("location") or "", m["unit"], m["multiplier"], m["price"], ROLE.get(m["is_main"], "ย่อย"),
                   1 if m["active"] else 0, m.get("digits"), m.get("scada_tag") or "", m["note"], None])
    widths = [7, 14, 14, 12, 30, 18, 14, 12, 24, 8, 9, 10, 9, 8, 10, 16, 24, 6]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w
    ws.freeze_panes = "B2"
    n = max(2, ws.max_row + 200)
    from openpyxl.utils import get_column_letter as gl
    ix = {k: gl(i) for i, (k, _) in enumerate(COLS, 1)}
    from . import energy_struct as ST
    pj = ",".join(p["name"] for p in ST.projects(db))
    extra = (("project", pj),) if pj and len(pj) < 250 else ()
    for col, opts in ((ix["kind"], ",".join(v["th"] for v in EN.KINDS.values())), (ix["role"], "หลัก,ย่อย,หักออก"),
                      (ix["active"], "1,0"), (ix["delete"], "1"), *((ix[k], o) for k, o in extra)):
        if len(opts) < 250:
            dv = DataValidation(type="list", formula1=f'"{opts}"', allow_blank=True)
            ws.add_data_validation(dv)
            dv.add(f"{col}2:{col}{n}")
    from . import masterdata as M
    if len(",".join(f["name"] for f in M.list_factories(db))) < 250:
        dv = DataValidation(type="list", formula1='"' + ",".join(f["name"] for f in M.list_factories(db)) + '"', allow_blank=True)
        ws.add_data_validation(dv)
        dv.add(f"B2:B{n}")
    help_ws = wb.create_sheet("วิธีใช้")
    for line in ("แก้ไขในชีต “ทะเบียนมิเตอร์” แล้วนำเข้ากลับที่ Energy Data › นำเข้า › ทะเบียนมิเตอร์",
                 "ID มีค่า = แก้มิเตอร์เดิม (ห้ามแก้ ID) · ID ว่าง = เพิ่มมิเตอร์ใหม่",
                 "Section / Line พิมพ์ชื่อใหม่ได้ (เข้าแคตตาล็อกอัตโนมัติ) · Project ต้องเป็นชื่อที่มีในระบบ (Kubota / AR5 ...)",
                 "หมวดหมู่: ใช้ชื่อตามหน้า หมวดหมู่ (เพิ่มหมวดใหม่ที่หน้านั้นก่อน)",
                 "บทบาท: หลัก = ใช้คิดยอดรวมโรงงาน · ย่อย · หักออก (เช่น Solar)",
                 "ใช้งาน: 1 = ใช้ · 0 = ปิด · ลบ: ใส่ 1 = ลบ (ถ้ามีค่าอ่านแล้วจะปิดใช้งานแทน)",
                 "ระบบแสดงรายการเปลี่ยนแปลงให้ตรวจก่อนบันทึกเสมอ"):
        help_ws.append([line])
    help_ws.column_dimensions["A"].width = 100
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def _s(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def parse(raw: bytes, filename: str = "x.xlsx") -> list[dict]:
    sheets = EN._open_book(raw, filename)
    if not sheets:
        raise S.ValidationError("อ่านไฟล์ไม่ได้")
    name, rows = next(((n, r) for n, r in sheets if n == "ทะเบียนมิเตอร์"), sheets[0])
    if not rows:
        raise S.ValidationError("ไฟล์ว่าง")
    head = [_s(x) for x in rows[0]]
    idx = {}
    for key, th in COLS:
        for i, h in enumerate(head):
            if h == th or h.lower() == key:
                idx[key] = i
    if "name" not in idx and "code" not in idx:
        raise S.ValidationError("ไม่พบหัวคอลัมน์ทะเบียนมิเตอร์ — ใช้ไฟล์ที่ส่งออกจากระบบ")
    out = []
    for n, r in enumerate(rows[1:], start=2):
        d = {k: (r[i] if i < len(r) else None) for k, i in idx.items()}
        if not any(_s(v) for v in d.values()):
            continue
        d["_row"] = n
        out.append(d)
    return out


def _num(v, label, errs, allow_empty=True):
    s = _s(v).replace(",", "")
    if s == "":
        return None
    try:
        x = float(s)
    except ValueError:
        errs.append(f"{label} ต้องเป็นตัวเลข")
        return None
    if x < 0:
        errs.append(f"{label} ต้องไม่ติดลบ")
    return x


def plan(db, rows: list[dict], uid) -> dict:
    """เทียบกับข้อมูลปัจจุบัน → รายการ เพิ่ม / แก้ (พร้อมช่องที่เปลี่ยน) / ลบ / ปิด / ผิดพลาด"""
    from . import energy_field as EF
    from . import masterdata as M
    EN.ensure(db)
    sc = EF.user_scope(db, uid)
    facs = {f["name"].strip().lower(): f["id"] for f in M.list_factories(db)}
    facs.update({str(f.get("code") or "").strip().lower(): f["id"] for f in M.list_factories(db) if f.get("code")})
    kinds = {v["th"].strip().lower(): k for k, v in EN.KINDS.items()}
    kinds.update({k.lower(): k for k in EN.KINDS})
    items = []
    for r in rows:
        errs: list[str] = []
        mid = _s(r.get("id"))
        cur = EN.meter(db, int(mid)) if mid.isdigit() else None
        if mid and not cur:
            errs.append(f"ไม่พบมิเตอร์ ID {mid}")
        fid = cur["factory_id"] if cur else None
        if _s(r.get("factory")):
            fid = facs.get(_s(r.get("factory")).lower())
            if not fid:
                errs.append(f"ไม่รู้จักโรงงาน “{_s(r.get('factory'))}”")
        elif not cur:
            fid = sc["factory_id"]
            if not fid:
                errs.append("ระบุโรงงาน")
        if sc["factory_id"] and (fid != sc["factory_id"] or (cur and cur["factory_id"] != sc["factory_id"])):
            errs.append("แก้ได้เฉพาะมิเตอร์ของโรงงานตัวเอง")
        kind = cur["kind"] if cur else None
        if _s(r.get("kind")):
            kind = kinds.get(_s(r.get("kind")).lower())
            if not kind:
                errs.append(f"ไม่รู้จักหมวด “{_s(r.get('kind'))}” — เพิ่มที่หน้า หมวดหมู่ก่อน")
        elif not cur:
            errs.append("ระบุหมวดหมู่")
        want = {"kind": kind, "factory_id": fid}
        if "project" in r:
            pn = _s(r.get("project")).lower()
            pid = None
            if pn:
                pid = next((p["id"] for p in ST.projects(db) if p["name"].strip().lower() == pn), None)
                if not pid:
                    errs.append(f"ไม่รู้จัก Project “{_s(r.get('project'))}” — เพิ่มที่ หมวดหมู่ & Section ก่อน")
            want["project_id"] = pid
        for k in ("code", "name", "grp", "line", "location", "unit", "scada_tag", "note"):
            if k in r:
                want[k] = _s(r.get(k))[:200]
        if "multiplier" in r:
            want["multiplier"] = _num(r.get("multiplier"), "CT", errs) or 1.0
        if "price" in r:
            want["price"] = _num(r.get("price"), "ราคา", errs)
        if "digits" in r:
            dg = _num(r.get("digits"), "จำนวนหลัก", errs)
            want["digits"] = int(dg) if dg else None
            if dg and not 3 <= dg <= 12:
                errs.append("จำนวนหลักต้อง 3–12")
        if "role" in r:
            role = ROLE_IN.get(_s(r.get("role")).lower())
            if role is None:
                errs.append(f"บทบาทไม่ถูกต้อง “{_s(r.get('role'))}” (หลัก/ย่อย/หักออก/ไม่นับรวม)")
            want["is_main"] = role if role is not None else 0
        if "active" in r:
            want["active"] = 0 if _s(r.get("active")) in ("0", "ไม่", "no", "ปิด") else 1
        if not cur and not (want.get("code") or want.get("name")):
            errs.append("ระบุรหัสหรือชื่อมิเตอร์")
        delete = _s(r.get("delete")) in ("1", "ลบ", "x", "X", "yes")
        it = {"row": r["_row"], "id": cur["id"] if cur else None, "label": (EN.label(cur) if cur else (want.get("name") or want.get("code") or "")),
              "errors": errs, "want": want}
        if errs:
            it["act"] = "error"
        elif delete:
            if not cur:
                it["act"] = "skip"
            else:
                has = db.execute("SELECT 1 FROM en_readings WHERE meter_id=? LIMIT 1", (cur["id"],)).fetchone()
                it["act"] = "deactivate" if has else "delete"
        elif not cur:
            it["act"] = "new"
            if db.execute("SELECT 1 FROM en_meters WHERE factory_id IS ? AND kind=? AND key=?",
                          (fid, kind, f"manual:{want.get('code') or want.get('name')}")).fetchone():
                it["act"], it["errors"] = "error", ["มีมิเตอร์รหัส/ชื่อนี้ในโรงงานและหมวดเดียวกันแล้ว"]
        else:
            diff = {}
            for k, v in want.items():
                ov = cur.get(k)
                if isinstance(v, float) or isinstance(ov, float):
                    same = (v is None and ov is None) or (v is not None and ov is not None and abs(float(v) - float(ov)) < 1e-9)
                else:
                    same = (v or "") == (ov or "") if isinstance(v, str) or isinstance(ov, str) else v == ov
                if not same:
                    diff[k] = (ov, v)
            it["diff"] = diff
            it["act"] = "update" if diff else "same"
        items.append(it)
    cnt = {a: sum(1 for x in items if x["act"] == a) for a in ("new", "update", "delete", "deactivate", "same", "error", "skip")}
    return {"items": items, "count": cnt}


def apply(db, rows: list[dict], uid) -> dict:
    p = plan(db, rows, uid)
    if p["count"]["error"]:
        raise S.ValidationError(f"มีแถวที่ผิดพลาด {p['count']['error']} แถว — แก้ไฟล์แล้วนำเข้าใหม่")
    from .services import ts
    done = {"new": 0, "update": 0, "delete": 0, "deactivate": 0}
    for it in p["items"]:
        w = it["want"]
        if it["act"] == "new":
            mid = EN.save_meter(db, None, {**{k: ("" if v is None else v) for k, v in w.items() if k not in ("is_main", "active")},
                                           "is_main": str(w.get("is_main", 0)), "active": w.get("active", 1)}, uid)
            if w.get("digits"):
                db.execute("UPDATE en_meters SET digits=? WHERE id=?", (w["digits"], mid))
            if w.get("location") or w.get("scada_tag"):
                db.execute("UPDATE en_meters SET location=?, scada_tag=? WHERE id=?", (w.get("location") or "", w.get("scada_tag") or "", mid))
            done["new"] += 1
        elif it["act"] == "update":
            upd = {k: nv for k, (ov, nv) in it["diff"].items()}
            if "kind" in upd or "factory_id" in upd:
                cur = EN.meter(db, it["id"])
                if db.execute("SELECT 1 FROM en_meters WHERE factory_id IS ? AND kind=? AND key=? AND id<>?",
                              (upd.get("factory_id", cur["factory_id"]), upd.get("kind", cur["kind"]), cur["key"], it["id"])).fetchone():
                    raise S.ValidationError(f"แถว {it['row']}: หมวด/โรงงานปลายทางมีมิเตอร์ชื่อเดียวกันแล้ว")
            before = EN.meter(db, it["id"])
            if "grp" in upd or "line" in upd:
                ST.ensure_catalog(db, before["factory_id"], upd.get("grp", before["grp"]), upd.get("line", before.get("line") or ""))
            db.execute(f"UPDATE en_meters SET {', '.join(k + '=?' for k in upd)} WHERE id=?", [*upd.values(), it["id"]])
            S.audit(db, uid, "energy_meter_xlsx", "en_meters", it["id"], before={k: before.get(k) for k in upd}, after=upd)
            done["update"] += 1
        elif it["act"] == "delete":
            EN.delete_meter(db, it["id"], uid)
            done["delete"] += 1
        elif it["act"] == "deactivate":
            db.execute("UPDATE en_meters SET active=0 WHERE id=?", (it["id"],))
            S.audit(db, uid, "energy_meter_off", "en_meters", it["id"], after={"active": 0, "via": "xlsx", "at": ts()})
            done["deactivate"] += 1
    return done
