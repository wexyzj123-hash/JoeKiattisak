"""ecs/energy_dash.py — Dashboard แบบห้องควบคุม (Control Room) ของ Energy Data (v0.69)

รวมข้อมูลจาก EN.dashboard() ต่อโรงงาน → การ์ด KPI (ไฟฟ้า/น้ำ/ลมอัด/ต้นทุน+CO₂), กราฟแนวโน้มพร้อมเส้นเป้า,
สัดส่วนตามพื้นที่, เทียบโรงงาน, แจ้งเตือน, สถานะโรงงาน และตารางสรุปมิเตอร์
"วันอ้างอิง" = วันล่าสุดที่มีข้อมูลใช้งาน (ปกติคือเมื่อวาน เพราะช่างจดตอนเช้า)
"""
from __future__ import annotations

from datetime import date, timedelta

from . import energy as EN
from . import energy_ops as OPS
from . import masterdata as M

MAIN_KINDS = ("elec", "water", "air")


def _ref_index(daily_lists: list[list[float]]) -> int | None:
    n = max((len(x) for x in daily_lists), default=0)
    for i in range(n - 1, -1, -1):
        if any((x[i] if i < len(x) else 0) for x in daily_lists):
            return i
    return None


def _clean(daily: list, days: list) -> tuple[list, list]:
    """ค่ารายวันที่ผิดปกติชัดเจน (ติดลบ หรือ > 5 เท่าของค่ากลางของวันที่มีค่า) → None + รายการไว้แจ้งผู้ใช้"""
    import statistics
    pos = [x for x in daily if x and x > 0]
    med = statistics.median(pos) if len(pos) >= 5 else None
    out, bad = [], []
    for d, x in zip(days, daily):
        if x is not None and (x < 0 or (med and x > 5 * med)):
            out.append(None)
            bad.append({"day": d, "v": x})
        else:
            out.append(x)
    return out, bad


def _chg(cur: float, prev: float | None) -> float | None:
    return round(100 * (cur - prev) / prev, 1) if prev else None


def _month_demand(db, fids: list[int], month: date) -> float:
    ym = month.strftime("%Y-%m")
    if not fids:
        return 0.0
    q = ",".join("?" * len(fids))
    row = db.execute(f"SELECT SUM(demand) FROM en_bills WHERE month=? AND factory_id IN ({q})", [ym, *fids]).fetchone()
    return float(row[0] or 0)


def _status_of(active_high: int, active_any: int, has_data: bool) -> str:
    if not has_data:
        return "none"
    if active_high:
        return "crit"
    if active_any:
        return "warn"
    return "ok"


def control(db, month: date, fid: int | None, loc: str = "", today: date | None = None, project_id: int | None = None,
            line: str | None = None) -> dict:
    EN.ensure(db)
    cfg = EN.settings(db)
    today = today or EN.S.now_dt().date()
    facs = M.list_factories(db)
    per: dict[int, dict] = {}
    for f in facs:
        d = EN.dashboard(db, month, f["id"], None, today, loc or None, project_id, line)
        if d["kinds"]:
            per[f["id"]] = {"d": d, "k": {k["kind"]: k for k in d["kinds"]}}
    all_ids = [f["id"] for f in facs if f["id"] in per]
    scope = [i for i in all_ids if not fid or i == fid]
    days = next((per[i]["d"]["days"] for i in all_ids), [])
    tgt_pct = float(cfg.get("target_pct", 5) or 0)

    # กรณีเลือกพื้นที่ (Location) → ใช้เฉพาะมิเตอร์ใน Section นั้น
    def meters_of(i, kind):
        k = per[i]["k"].get(kind)
        if not k:
            return []
        return [m for m in k["meters"] if not loc or (m["grp"] or "") == ("" if loc == "-" else loc)]

    # ── KPI ต่อประเภท ──
    kp: dict[str, dict] = {}
    for kind in MAIN_KINDS:
        lists = [per[i]["k"][kind]["daily"].get(i, []) for i in scope if kind in per[i]["k"]]
        ks = [per[i]["k"][kind] for i in scope if kind in per[i]["k"]]
        if not ks:
            continue
        daily = [round(sum(x[j] if j < len(x) else 0 for x in lists), 2) for j in range(len(days))]
        daily, outl = _clean(daily, days)                  # v0.92 ตัดวันที่ค่าผิดปกติออกจากกราฟ (แจ้งไว้ใต้กราฟ)
        ri = _ref_index([daily])
        ref_u = daily[ri] if ri is not None else 0
        prev_u = daily[ri - 1] if ri is not None and ri >= 1 else None
        exp = [m for i in scope for m in meters_of(i, kind) if m["is_main"] != 2]
        cov = lambda j: (sum(1 for m in exp if j is not None and 0 <= j < len(m.get("has") or []) and m["has"][j]), len(exp))
        c_ref, c_prev = cov(ri), cov(ri - 1 if ri else None)
        partial = bool(exp) and (c_ref[0] < 0.9 * c_ref[1] or (ri and c_prev[0] < 0.9 * c_prev[1]))
        total = sum(k["total"] for k in ks)
        prev = sum(k["prev"] for k in ks)
        cost = sum(k["cost"] for k in ks)
        co2 = sum((k["co2"] or 0) for k in ks)
        rate = cost / total if total else 0
        crate = co2 / total if total else 0
        kp[kind] = {"kind": kind, **{x: ks[0][x] for x in ("th", "unit", "icon", "color")}, "daily": daily, "ref": ri,
                    "ref_day": days[ri] if ri is not None else None, "ref_u": round(ref_u, 1), "prev_u": prev_u,
                    "chg": None if partial else _chg(ref_u, prev_u), "partial": partial, "cov": c_ref, "cov_prev": c_prev,
                    "outliers": outl, "total": round(total, 1), "prev": round(prev, 1), "chg_m": _chg(total, prev),
                    "cost": round(cost), "co2": round(co2, 2), "ref_cost": round(ref_u * rate), "ref_co2": round(ref_u * crate, 2),
                    "prev_cost": round((prev_u or 0) * rate), "prev_co2": round((prev_u or 0) * crate, 2),
                    "avg_rate": round(ref_u / 24, 1), "n": sum(k["n_meters"] for k in ks),
                    "target": round((prev / max(len(days), 1)) * (1 - tgt_pct / 100), 2) if prev else None}
    e = kp.get("elec")
    if e:
        e["demand"] = round(e["avg_rate"])
        e["demand_label"] = "เฉลี่ย"
    ref_day = next((k["ref_day"] for k in kp.values() if k["ref_day"]), None)
    cost_ref = sum(k["ref_cost"] for k in kp.values())
    cost_prev = sum(k["prev_cost"] for k in kp.values())
    co2_ref = sum(k["ref_co2"] for k in kp.values())
    co2_prev = sum(k["prev_co2"] for k in kp.values())
    any_part = any(k.get("partial") for k in kp.values())
    money = {"ref": cost_ref, "chg": None if any_part else _chg(cost_ref, cost_prev), "co2": round(co2_ref, 2),
             "co2_chg": None if any_part else _chg(co2_ref, co2_prev), "partial": any_part,
             "month": sum(k["cost"] for k in kp.values()), "co2_month": round(sum(k["co2"] for k in kp.values()), 2)}

    # ── เคส/แจ้งเตือน ──
    case_rows = OPS.cases(db, "active", fid, None, 60)
    mid_grp: dict[int, str] = {}
    for i in all_ids:
        for k in per[i]["k"].values():
            for m in k["meters"]:
                mid_grp[m["id"]] = m["grp"]
    alarms = [{"day": c["day"], "factory": c["factory_name"] or "–", "where": (c["m_name"] or c["m_code"] or c["grp"] or "–"),
               "grp": c["grp"], "rule": OPS.RULES_ALL.get(c["rule"], ("", c["title"] or c["rule"]))[1], "sev": c["severity"],
               "status": c["status"], "id": c["id"]} for c in case_rows[:6]]

    # ── สถานะโรงงาน ──
    fstat = []
    for f in facs:
        if f["id"] not in per:
            continue
        i = f["id"]
        cs = OPS.cases(db, "active", i, None, 200)
        hi = sum(1 for c in cs if c["severity"] == "high")
        row = {"id": i, "name": f["name"], "status": _status_of(hi, len(cs), True), "cases": len(cs)}
        for kind in MAIN_KINDS:
            k = per[i]["k"].get(kind)
            if k:
                lst = k["daily"].get(i, [])
                ri = _ref_index([lst])
                row[kind] = round(lst[ri], 0) if ri is not None else None
                row[kind + "_unit"] = k["unit"]
            else:
                row[kind] = None
        fstat.append(row)

    # ── เทียบโรงงาน (ไฟฟ้า เดือนนี้ vs เดือนก่อน ช่วงเดียวกัน) ──
    cmp_ = [{"name": r["name"], "cur": per[r["id"]]["k"]["elec"]["total"], "prev": per[r["id"]]["k"]["elec"]["prev"]}
            for r in fstat if "elec" in per[r["id"]]["k"]]

    # ── สัดส่วนตามพื้นที่ (ไฟฟ้า) ──
    share: dict[str, float] = {}
    for i in scope:
        ms = meters_of(i, "elec")
        by_g: dict[str, list] = {}
        for m in ms:
            by_g.setdefault(m["grp"] or "ไม่ระบุพื้นที่", []).append(m)
        for g, lst in by_g.items():                        # v0.90 ยอดของแต่ละพื้นที่ = กติกาเดียวทั้งระบบ (EN.counted)
            share[g] = share.get(g, 0) + sum(EN.sign(m) * m["u"] for m in EN.counted(lst))
    items = sorted(((k, v) for k, v in share.items() if v > 0), key=lambda x: -x[1])
    donut = [{"name": k, "value": round(v)} for k, v in items[:5]]
    rest = sum(v for _, v in items[5:])
    if rest:
        donut.append({"name": "อื่น ๆ", "value": round(rest)})

    # ── ผังพื้นที่ (Section ของโรงงานที่เลือก/โรงงานแรก) ──
    map_fid = fid or (scope[0] if scope else None)
    sec_cards = []
    if map_fid in per:
        ms = meters_of(map_fid, "elec")
        by: dict[str, list] = {}
        for m in ms:
            # เลือก Section แล้ว → แตกเป็นการ์ดต่อ Line · ไม่ได้เลือก → การ์ดต่อ Section (แสดง Line ในการ์ด)
            by.setdefault((m.get("line") or "ไม่ระบุ Line") if loc else (m["grp"] or "ไม่ระบุพื้นที่"), []).append(m)
        hi_g = {c["grp"] for c in OPS.cases(db, "active", map_fid, None, 200) if c["severity"] == "high"}
        any_g = {c["grp"] for c in OPS.cases(db, "active", map_fid, None, 200)}
        hi_m = {c["meter_id"] for c in OPS.cases(db, "active", map_fid, None, 200) if c["severity"] == "high"}
        any_m = {c["meter_id"] for c in OPS.cases(db, "active", map_fid, None, 200)}
        for g, lst in by.items():
            subs = EN.counted(lst)                         # v0.90 กติกาเดียวทั้งระบบ
            sp = [sum(EN.sign(m) * m["spark"][j] for m in subs if len(m["spark"]) > j) for j in range(14)]
            if loc:
                top = [f'{m["label"]} · {round(m["u"]):,}' for m in sorted(subs, key=lambda x: -x["u"])[:3]]
                st = _status_of(any(m["id"] in hi_m for m in subs), any(m["id"] in any_m for m in subs), any(m["u"] for m in subs))
                href = None if g == "ไม่ระบุ Line" else g
            else:
                ln: dict[str, float] = {}
                for m in subs:
                    ln[m.get("line") or ""] = ln.get(m.get("line") or "", 0) + m["u"]
                top = [f'{k} · {round(v):,}' for k, v in sorted(ln.items(), key=lambda x: -x[1]) if k][:3] or \
                      [m["label"] for m in sorted(subs, key=lambda x: -x["u"])[:3]]
                st = _status_of(g in hi_g, g in any_g, any(m["u"] for m in subs))
                href = None
            sec_cards.append({"name": g, "n": len(subs), "u": round(sum(EN.sign(m) * m["u"] for m in subs)), "lines": top, "status": st,
                              "spark": sp, "line_name": href, "n_lines": len({m.get("line") for m in subs if m.get("line")})})
        sec_cards = [x for x in sec_cards if x["u"] > 0] or sec_cards
        sec_cards.sort(key=lambda x: -x["u"])
    sections = sorted({m["grp"] for i in all_ids if not fid or i == fid for k in per[i]["k"].values() for m in k["meters"] if m["grp"]})

    # ── ตารางสรุป: ต่อ (โรงงาน, Section) หรือต่อมิเตอร์เมื่อเลือก Location ──
    hi_m = {c["meter_id"] for c in case_rows if c["severity"] == "high"}
    any_m = {c["meter_id"] for c in case_rows}
    rows: dict[tuple, dict] = {}
    for i in scope:
        fname = next((f["name"] for f in facs if f["id"] == i), "")
        ri_all = _ref_index([per[i]["k"][k]["daily"].get(i, []) for k in per[i]["k"] if k in MAIN_KINDS])
        off = (len(days) - 1 - ri_all) if ri_all is not None else None
        for kind in MAIN_KINDS:
            k = per[i]["k"].get(kind)
            if not k:
                continue
            kms = meters_of(i, kind)
            keep: set = set()
            for g in {m["grp"] for m in kms}:              # v0.90 ต่อ Section นับเฉพาะมิเตอร์ที่ไม่ถูกครอบ (กติกาเดียวทั้งระบบ)
                keep |= {m["id"] for m in EN.counted([x for x in kms if x["grp"] == g])}
            for m in kms:
                if not loc and m["id"] not in keep:
                    continue
                key = (i, m["grp"], m["label"] if loc else "")
                r = rows.setdefault(key, {"factory": fname, "grp": m["grp"] or "–", "line": m["label"] if loc else "",
                                          "n": 0, "kinds": {}, "spark": [0.0] * 14, "ids": [], "flags": 0, "last": None})
                sp = m["spark"]
                refv = sp[len(sp) - 1 - off] if off is not None and 0 <= off < len(sp) else 0
                c = r["kinds"].setdefault(kind, {"ref": 0.0, "unit": k["unit"]})
                c["ref"] += refv
                r["n"] += 1
                r["ids"].append(m["id"])
                r["flags"] += len(m["flags"])
                if kind == "elec":
                    for j in range(min(14, len(sp))):
                        r["spark"][14 - len(sp) + j] += sp[j]
    table = []
    for r in rows.values():
        has = any(v["ref"] for v in r["kinds"].values())
        hi = any(x in hi_m for x in r["ids"])
        an = any(x in any_m for x in r["ids"]) or r["flags"] > 0
        table.append({**r, "status": _status_of(hi, an, has), "first": r["ids"][0] if r["ids"] else None,
                      "kinds": {k: {"ref": round(v["ref"], 1), "unit": v["unit"], "rate": round(v["ref"] / 24, 1)} for k, v in r["kinds"].items()}})
    for r in table:
        r["has"] = r["status"] != "none"
    table.sort(key=lambda r: (r["factory"], not r["has"], -(r["kinds"].get("elec", {}).get("ref") or 0)))

    # ── รวมท้ายหน้า ──
    ef = e["total"] if e else 0
    saved = (e["prev"] - e["total"]) * (e["co2"] / e["total"]) if e and e["total"] else 0
    tot = {"elec": sum(per[i]["k"]["elec"]["total"] for i in all_ids if "elec" in per[i]["k"]),
           "water": sum(per[i]["k"]["water"]["total"] for i in all_ids if "water" in per[i]["k"]),
           "air": sum(per[i]["k"]["air"]["total"] for i in all_ids if "air" in per[i]["k"]),
           "co2_saved": round(saved, 1), "co2_pct": e["chg_m"] if e else None, "target_pct": tgt_pct, "ef": ef}
    return {"month": month, "days": days, "ref_day": ref_day, "kp": kp, "money": money, "alarms": alarms, "n_alarm": len(case_rows),
            "fstat": fstat, "cmp": cmp_, "donut": donut, "sec_cards": sec_cards, "sections": sections, "map_fid": map_fid,
            "table": table, "tot": tot, "facs": [f for f in facs if f["id"] in per], "tgt_pct": tgt_pct,
            "last_update": next(iter(per.values()))["d"]["last_update"] if per else None}


def trend_months(db, fid: int | None, kind: str, end: date, n: int = 6) -> dict:
    """ยอดรายเดือนย้อนหลัง n เดือน (ใช้กราฟโหมด Month)"""
    out_m, out_v = [], []
    m = end.replace(day=1)
    months = []
    for _ in range(n):
        months.append(m)
        m = (m - timedelta(days=1)).replace(day=1)
    for m in reversed(months):
        d = EN.dashboard(db, m, fid, kind)
        k = d["kinds"][0] if d["kinds"] else None
        out_m.append(m.strftime("%m/%y"))
        out_v.append(round(k["total_full"] if k and "total_full" in k else (k["total"] if k else 0), 1))
    return {"months": out_m, "values": out_v}


# ───────────────────────── v0.92 ความสดของข้อมูล · ที่มาอัตรา · สรุปผู้บริหาร ─────────────────────────

TH_MON = ("ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.")


def freshness(db, fids: list[int], today: date | None = None) -> list[dict]:
    """ต่อโรงงาน: วันล่าสุดที่มีค่าอ่าน · จดแล้วกี่ตัวของวันนี้/เมื่อวาน (ไม่นับมิเตอร์ “ไม่นับรวม”)"""
    today = today or EN.S.now_dt().date()
    y = (today - timedelta(days=1)).isoformat()
    out = []
    for f in M.list_factories(db):
        if f["id"] not in fids:
            continue
        ids = [m["id"] for m in EN.meters(db, f["id"]) if m["is_main"] != 2]
        if not ids:
            continue
        q = ",".join(str(i) for i in ids)
        last = db.execute(f"SELECT MAX(day) FROM en_readings WHERE day<=? AND meter_id IN ({q})", (today.isoformat(),)).fetchone()[0]
        fut = db.execute(f"SELECT COUNT(*) FROM en_readings WHERE day>? AND meter_id IN ({q})", (today.isoformat(),)).fetchone()[0]
        n_t = db.execute(f"SELECT COUNT(DISTINCT meter_id) FROM en_readings WHERE day=? AND meter_id IN ({q})", (today.isoformat(),)).fetchone()[0]
        n_y = db.execute(f"SELECT COUNT(DISTINCT meter_id) FROM en_readings WHERE day=? AND meter_id IN ({q})", (y,)).fetchone()[0]
        lag = (today - date.fromisoformat(last)).days if last else None
        out.append({"fid": f["id"], "name": f["name"], "last": last, "n": len(ids), "future": fut, "today": n_t, "yday": n_y, "lag": lag,
                    "status": "ok" if lag is not None and lag <= 1 and max(n_t, n_y) >= 0.9 * len(ids) else
                              ("warn" if lag is not None and lag <= 2 else "crit")})
    return out


def rate_source(db, fids: list[int], month: date) -> dict:
    """ค่าไฟที่ใช้คิดเงินบน Dashboard มาจากไหน: บิลเดือนนั้น · บิลล่าสุดก่อนหน้า · ค่าตั้งค่า (ประมาณ)"""
    cfg = EN.settings(db)
    ym = month.strftime("%Y-%m")
    items, est = [], False
    for f in M.list_factories(db):
        if f["id"] not in fids:
            continue
        r = OPS.bill_rate(db, f["id"], ym)
        if r:
            items.append({"name": f["name"], "rate": round(r, 2), "src": f"บิล {TH_MON[month.month - 1]}"})
            continue
        row = db.execute("""SELECT month, kwh, amount, vat FROM en_bills WHERE factory_id=? AND month<? AND kwh>0 ORDER BY month DESC LIMIT 1""",
                         (f["id"], ym)).fetchone()
        if row:
            mo = int(row[0][5:7])
            items.append({"name": f["name"], "rate": round((row[2] + row[3]) / row[1], 2), "src": f"บิลล่าสุด {TH_MON[mo - 1]}"})
        else:
            est = True
            items.append({"name": f["name"], "rate": cfg["price_elec"], "src": "ค่าตั้งค่า (ประมาณ)"})
    return {"items": items, "estimate": est or any(not x["src"].startswith("บิล ") for x in items)}


def executive(db, month: date, fids: list[int], kp: dict, U: dict | None, today: date | None = None) -> dict:
    """สรุปผู้บริหาร: ยอดสะสมเดือนนี้ vs เป้า + คาดการณ์สิ้นเดือน · kWh/หน่วยผลิต · kW Peak · 5 พื้นที่ที่ใช้เพิ่มมากสุด"""
    from . import energy_summary as SMY
    today = today or EN.S.now_dt().date()
    d_from, d_to = EN.month_bounds(month)
    dim = (d_to - d_from).days + 1
    current = d_from <= today <= d_to
    goals = []
    for kind, k in kp.items():
        tgt = 0.0
        has_t = False
        for fid in fids:
            ms = EN.meters(db, fid, kind)
            if not ms:
                continue
            t = SMY.target_for(db, kind, "factory", str(fid), fid, ms, d_from)
            if t["daily"] is not None:
                tgt += t["daily"] * dim
                has_t = True
        vals = [x for x in k["daily"] if x]
        n = len(vals)
        mtd = k["total"]
        fc = round(mtd / n * dim, 1) if current and n else round(mtd, 1)
        goals.append({"kind": kind, "th": k["th"], "icon": k["icon"], "color": k["color"], "unit": k["unit"], "mtd": round(mtd, 1),
                      "forecast": fc, "target": round(tgt, 1) if has_t else None, "days": n, "dim": dim, "current": current,
                      "pct": round(100 * fc / tgt, 1) if has_t and tgt else None,
                      "mtd_pct": round(100 * mtd / tgt, 1) if has_t and tgt else None})
    # kWh/หน่วยผลิต (ระดับโรงงาน) — เดือนล่าสุดที่มียอดผลิต
    ku = []
    for fid in fids:
        cr = OPS.cost_report(db, month.year, fid)
        if not cr["factories"]:
            continue
        rows = [r for r in cr["factories"][0]["rows"] if r["month"] <= month.month and r.get("kwh_unit")]
        if rows:
            r = rows[-1]
            prev = rows[-2]["kwh_unit"] if len(rows) > 1 else None
            ku.append({"fid": fid, "name": cr["factories"][0]["factory"]["name"], "v": r["kwh_unit"], "mo": TH_MON[r["month"] - 1],
                       "unit": (r.get("prod") or {}).get("unit") or "หน่วย", "chg": _chg(r["kwh_unit"], prev)})
    # kW Peak On-Peak (เฉพาะโรงงานที่มีข้อมูล 15 นาที)
    peaks = []
    try:
        from . import energy_power as PW
        for fid in fids:
            t = PW.tou(db, fid, d_from, today)
            if t["n_int"]:
                name = next((f["name"] for f in M.list_factories(db) if f["id"] == fid), "")
                peaks.append({"fid": fid, "name": name, "kw": t["peak_on"], "at": t["peak_on_at"], "target": t["target"],
                              "over": t["over"], "near": t["near"], "cover": t["cover"]})
    except Exception:                                     # noqa: BLE001 — ส่วนเสริม ไม่ให้ Dashboard ล่ม
        peaks = []
    # 5 พื้นที่ที่ใช้เพิ่มขึ้นมากที่สุด (เทียบช่วงเดียวกันเดือนก่อน · จัดอันดับด้วยเงินที่เพิ่ม)
    ups = []
    for k in (U or {}).get("kinds", []):
        for f in k["factories"]:
            for s in f["sections"]:
                inc = s["u"] - s["prev"]
                if s["prev"] > 0 and inc > 0:
                    baht = s["cost"] * inc / s["u"] if s["u"] else 0
                    ups.append({"kind": k["kind"], "icon": k["icon"], "unit": k["unit"], "fid": f["fid"], "factory": f["factory"],
                                "name": s["name"], "inc": round(inc, 1), "pct": s["chg"], "baht": round(baht), "u": s["u"]})
    ups.sort(key=lambda x: (-(x["baht"] or 0), -(x["pct"] or 0)))
    return {"goals": goals, "ku": ku, "peaks": peaks, "ups": ups[:5]}
