/* energy.js — Energy Data: กราฟรายวัน (ECharts) + sparkline (SVG)
 * สีโรงงานเรียงคงที่ (--viz-s1..s3) · แกนเดียวต่อกราฟ · ชี้เพื่อดูค่าทุกโรงงาน + รวม */
(function () {
  'use strict';
  const cs = getComputedStyle(document.documentElement);
  const v = (n, d) => (cs.getPropertyValue(n).trim() || d);
  const T = {
    grid: v('--viz-grid', '#e5e7eb'), axis: v('--viz-axis', '#cbd5e1'), muted: v('--muted', '#64748b'), ink: v('--text', '#0f172a'),
    surface: v('--surface', '#fff'), s: [v('--viz-s1', '#2563eb'), v('--viz-s2', '#f59e0b'), v('--viz-s3', '#10b981'), '#8b5cf6', '#ef4444'],
    font: getComputedStyle(document.body).fontFamily,
  };
  const fmt = (x, d) => x == null ? '–' : Number(x).toLocaleString('th-TH', { maximumFractionDigits: d == null ? 1 : d });
  const DPR = Math.min(window.devicePixelRatio || 1, 2);
  const charts = [];

  function daily(el, days, series, names, unit, accent) {
    if (!el || !window.echarts) return;
    const keys = Object.keys(series);
    const multi = keys.length > 1;
    const c = echarts.init(el, null, { renderer: 'canvas', devicePixelRatio: DPR });
    c.setOption({
      backgroundColor: 'transparent', textStyle: { fontFamily: T.font, color: T.ink }, animationDuration: 300,
      grid: { left: 8, right: 12, top: multi ? 34 : 14, bottom: 4, containLabel: true },
      legend: multi ? { top: 0, left: 0, icon: 'roundRect', itemWidth: 12, itemHeight: 10, textStyle: { color: T.muted } } : undefined,
      tooltip: {
        trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: T.surface, borderColor: T.axis, textStyle: { color: T.ink, fontFamily: T.font },
        formatter: (ps) => {
          const tot = ps.reduce((a, p) => a + (p.value || 0), 0);
          return `<b>${ps[0].axisValue}</b><br>` + ps.map((p) => `${p.marker} ${p.seriesName}: <b>${fmt(p.value)}</b> ${unit}`).join('<br>')
            + (multi ? `<br><span style="opacity:.75">รวม</span> <b>${fmt(tot)}</b> ${unit}` : '');
        },
      },
      xAxis: { type: 'category', data: days.map((d) => d.slice(8, 10) + '/' + d.slice(5, 7)), axisLine: { lineStyle: { color: T.axis } },
        axisTick: { show: false }, axisLabel: { color: T.muted, fontSize: 11 } },
      yAxis: { type: 'value', axisLabel: { color: T.muted, fontSize: 11, formatter: (x) => fmt(x, 0) }, splitLine: { lineStyle: { color: T.grid } } },
      series: keys.map((k, i) => ({
        name: names[k] || 'ไม่ระบุโรงงาน', type: 'bar', stack: 'f', data: series[k], barMaxWidth: 22,
        itemStyle: { color: multi ? T.s[i % T.s.length] : accent, borderRadius: i === keys.length - 1 ? [4, 4, 0, 0] : 0, borderColor: T.surface, borderWidth: multi ? 1 : 0 },
        emphasis: { focus: 'series' },
      })),
    });
    charts.push(c);
  }

  function sparks() {
    document.querySelectorAll('[data-spark]').forEach((el) => {
      let a = [];
      try { a = JSON.parse(el.dataset.spark); } catch (e) { return; }
      const w = 96, h = 26, mx = Math.max(...a, 0) || 1, bw = w / a.length;
      el.innerHTML = `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true">` +
        a.map((x, i) => `<rect x="${(i * bw + 1).toFixed(1)}" y="${(h - Math.max(1.5, h * x / mx)).toFixed(1)}" width="${(bw - 2).toFixed(1)}" height="${Math.max(1.5, h * x / mx).toFixed(1)}" rx="1.5" fill="var(--kc)" opacity="${i === a.length - 1 ? 1 : .55}"></rect>`).join('') + '</svg>';
      el.title = '14 วันล่าสุด: ' + a.map((x) => fmt(x)).join(' · ');
    });
  }

  const data = document.getElementById('en-data');
  if (data) {
    const d = JSON.parse(data.textContent);
    d.kinds.forEach((k, i) => daily(document.getElementById('ch-' + k), d.days, d.series[i], d.factories, d.units[i], d.colors[i]));
  }
  const md = document.getElementById('en-meter');
  if (md) {
    const d = JSON.parse(md.textContent);
    daily(document.getElementById('ch-meter'), d.days, { m: d.u }, { m: d.label }, d.unit, d.color);
  }
  const cd = document.getElementById('en-case');
  if (cd && window.echarts) {
    const d = JSON.parse(cd.textContent);
    const el = document.getElementById('ch-case');
    const c = echarts.init(el, null, { renderer: 'canvas', devicePixelRatio: DPR });
    const hi = v('--st-miss', '#ef4444');
    c.setOption({
      backgroundColor: 'transparent', textStyle: { fontFamily: T.font, color: T.ink }, animationDuration: 300,
      grid: { left: 8, right: 12, top: 14, bottom: 4, containLabel: true },
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: T.surface, borderColor: T.axis, textStyle: { color: T.ink, fontFamily: T.font },
        formatter: (ps) => `<b>${ps[0].axisValue}</b><br>${d.label}: <b>${fmt(ps[0].value)}</b> ${d.unit}` },
      xAxis: { type: 'category', data: d.days.map((x) => x.slice(8, 10) + '/' + x.slice(5, 7)), axisLine: { lineStyle: { color: T.axis } }, axisTick: { show: false }, axisLabel: { color: T.muted, fontSize: 11 } },
      yAxis: { type: 'value', axisLabel: { color: T.muted, fontSize: 11, formatter: (x) => fmt(x, 0) }, splitLine: { lineStyle: { color: T.grid } } },
      series: [{ type: 'bar', barMaxWidth: 22, data: d.u.map((x, i) => ({ value: x, itemStyle: { color: d.days[i] === d.mark ? hi : d.color, opacity: d.days[i] === d.mark ? 1 : 0.55, borderRadius: [4, 4, 0, 0] } })) }],
    });
    charts.push(c);
  }
  const cr = document.getElementById('en-cost');
  if (cr && window.echarts) {
    const d = JSON.parse(cr.textContent);
    const el = document.getElementById('ch-cost');
    const keys = Object.keys(d.series);
    const c = echarts.init(el, null, { renderer: 'canvas', devicePixelRatio: DPR });
    c.setOption({
      backgroundColor: 'transparent', textStyle: { fontFamily: T.font, color: T.ink }, animationDuration: 300,
      grid: { left: 8, right: 16, top: 34, bottom: 4, containLabel: true },
      legend: { top: 0, left: 0, icon: 'roundRect', itemWidth: 12, itemHeight: 10, textStyle: { color: T.muted } },
      tooltip: { trigger: 'axis', backgroundColor: T.surface, borderColor: T.axis, textStyle: { color: T.ink, fontFamily: T.font },
        formatter: (ps) => `<b>${ps[0].axisValue}</b><br>` + ps.map((p) => `${p.marker} ${p.seriesName}: <b>${fmt(p.value, 3)}</b> ${d.unit}`).join('<br>') },
      xAxis: { type: 'category', data: d.months, boundaryGap: false, axisLine: { lineStyle: { color: T.axis } }, axisTick: { show: false }, axisLabel: { color: T.muted, fontSize: 11 } },
      yAxis: { type: 'value', scale: true, axisLabel: { color: T.muted, fontSize: 11, formatter: (x) => fmt(x, 2) }, splitLine: { lineStyle: { color: T.grid } } },
      series: keys.map((k, i) => ({ name: k, type: 'line', data: d.series[k], connectNulls: false, symbol: 'circle', symbolSize: 8,
        lineStyle: { width: 2, color: T.s[i % T.s.length] }, itemStyle: { color: T.s[i % T.s.length], borderColor: T.surface, borderWidth: 2 } })),
    });
    charts.push(c);
  }
  sparks();
  window.addEventListener('resize', () => charts.forEach((c) => c.resize()));
  window.ENSpark = sparks;
})();
