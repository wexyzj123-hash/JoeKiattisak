/* v0.91 หน้าไฟฟ้า: kWh รายวัน On/Off-Peak (หรือ kW สูงสุดรายวัน) + โหลดเฉลี่ยรายชั่วโมง วันทำงาน vs วันหยุด */
(function () {
  const el = document.getElementById('pw-data');
  if (!el || !window.echarts) return;
  const D = JSON.parse(el.textContent);
  const css = getComputedStyle(document.documentElement);
  const v = (n, f) => (css.getPropertyValue(n) || '').trim() || f;
  const TXT = v('--text', '#0f172a'), MUTED = v('--muted', '#64748b'), GRID = v('--border', '#e2e8f0');
  const ON = '#d03b3b', OFF = '#2563eb', TG = '#0ca30c', PK = '#f59e0b';
  const fmt = (x) => x == null ? '–' : Number(x).toLocaleString('th-TH', {maximumFractionDigits: 1});
  const base = {textStyle: {color: TXT, fontFamily: 'inherit'}, animation: false, grid: {left: 60, right: 16, top: 34, bottom: 36},
    legend: {top: 0, textStyle: {color: MUTED}}};
  const ax = (data) => ({type: 'category', data, axisLabel: {color: MUTED}, axisLine: {lineStyle: {color: GRID}}});
  const ay = (name) => ({type: 'value', name, nameTextStyle: {color: MUTED}, axisLabel: {color: MUTED}, splitLine: {lineStyle: {color: GRID, opacity: .6}}});
  const charts = [];
  const n1 = document.getElementById('pwDay');
  if (n1) {
    const c = echarts.init(n1); charts.push(c);
    const days = D.days.map((d) => d.slice(8) + '/' + d.slice(5, 7));
    if (D.tab === 'tou') {
      c.setOption(Object.assign({}, base, {tooltip: {trigger: 'axis', valueFormatter: (x) => fmt(x) + ' kWh'}, xAxis: ax(days), yAxis: ay('kWh'),
        series: [{name: 'On-Peak', type: 'bar', stack: 'k', data: D.on, itemStyle: {color: ON}, barMaxWidth: 22},
                 {name: 'Off-Peak', type: 'bar', stack: 'k', data: D.off, itemStyle: {color: OFF, borderRadius: [3, 3, 0, 0]}, barMaxWidth: 22}]}));
    } else {
      c.setOption(Object.assign({}, base, {tooltip: {trigger: 'axis', valueFormatter: (x) => fmt(x) + ' kW'}, xAxis: ax(days), yAxis: ay('kW'),
        series: [{name: 'kW สูงสุด', type: 'bar', data: D.peak.map((x) => ({value: x, itemStyle: {color: D.target && x > D.target ? ON : PK, borderRadius: [3, 3, 0, 0]}})), barMaxWidth: 22,
          markLine: D.target ? {silent: true, symbol: 'none', lineStyle: {color: TG, type: 'dashed', width: 2}, label: {color: TG, formatter: 'เป้า ' + fmt(D.target)}, data: [{yAxis: D.target}]} : undefined}]}));
    }
  }
  const n2 = document.getElementById('pwProf');
  if (n2) {
    const c = echarts.init(n2); charts.push(c);
    const hrs = Array.from({length: 24}, (_, i) => String(i).padStart(2, '0') + ':00');
    c.setOption(Object.assign({}, base, {tooltip: {trigger: 'axis', valueFormatter: (x) => fmt(x) + ' kWh/ชม.'}, xAxis: ax(hrs), yAxis: ay('kWh/ชม.'),
      series: [{name: 'วันทำงาน (จ–ศ)', type: 'line', data: D.wd, showSymbol: false, lineStyle: {width: 2, color: ON}, itemStyle: {color: ON}},
               {name: 'เสาร์–อาทิตย์/วันหยุด', type: 'line', data: D.we, showSymbol: false, lineStyle: {width: 2, color: OFF}, itemStyle: {color: OFF}}]}));
  }
  window.addEventListener('resize', () => charts.forEach((c) => c.resize()));
})();
