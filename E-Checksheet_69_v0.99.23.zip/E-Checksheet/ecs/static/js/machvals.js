/* v0.43 ค่าที่ตรวจย้อนหลัง รายเครื่องจักร — ทุกหัวข้อ ทุกครั้งที่ตรวจ เป็นกราฟเล็กเรียงกัน (small multiples)
   ตัวเลข: เส้นค่าที่ตรวจตามเวลาจริง + แถบช่วงเกณฑ์ + จุดเตือน/NG · OK/NG/ตัวเลือก: แถบช่องสีต่อครั้ง
   ชี้ที่กราฟ = ดูค่าและเวลาของครั้งนั้น · คลิก = กราฟเต็มของหัวข้อ */
(function () {
  const root = document.getElementById('mv');
  const dataEl = document.getElementById('mv-data');
  if (!root || !dataEl) return;
  const U_ = (p) => (window.U ? window.U(p) : p);
  const $ = (id) => document.getElementById(id);
  const list = $('mv-list'), sel = $('mv-sel'), sum = $('mv-sum'), link = $('mv-link');
  const NS = 'http://www.w3.org/2000/svg';
  const W = 220, H = 40, PAD = 3;
  let data = null;
  try { data = JSON.parse(dataEl.textContent); } catch (e) { data = null; }

  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
  const fmt = (v) => (v == null ? '–' : (Math.abs(v) >= 1000 ? Math.round(v).toLocaleString() : String(+(+v).toFixed(3))));
  const tparse = (s) => new Date(s.replace(' ', 'T') + ':00').getTime();
  const tlabel = (s) => s.slice(8, 10) + '/' + s.slice(5, 7) + ' ' + s.slice(11, 16);
  const jcls = (j) => (j === 'ng' ? 'ng' : j === 'warn' ? 'warn' : 'ok');

  function el(tag, attrs) {
    const n = document.createElementNS(NS, tag);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    return n;
  }

  function spark(it, t0, t1) {
    const svg = el('svg', {viewBox: `0 0 ${W} ${H}`, preserveAspectRatio: 'none', class: 'mv-svg', 'aria-hidden': 'true'});
    const pts = it.pts;
    const X = (t) => PAD + (W - 2 * PAD) * Math.min(1, Math.max(0, (t - t0) / ((t1 - t0) || 1)));
    if (it.type === 'cat' || !pts.some((p) => p[1] != null)) {
      const bw = Math.max(2, Math.min(10, (W - 2 * PAD) / Math.max(pts.length, 1) - 1));
      pts.forEach((p) => {
        svg.appendChild(el('rect', {x: X(tparse(p[0])) - bw / 2, y: 10, width: bw, height: H - 20, rx: 1.5, class: 'mv-cell ' + jcls(p[3])}));
      });
      return {svg, xs: pts.map((p) => X(tparse(p[0])))};
    }
    const vals = pts.map((p) => p[1]).filter((v) => v != null);
    let lo = Math.min(...vals), hi = Math.max(...vals);
    const span = (hi - lo) || Math.abs(hi) || 1;
    // เกณฑ์อยู่ใกล้ข้อมูล → รวมในแกน (ให้เห็นระยะห่างจากเกณฑ์) · ไกลมาก → ไม่รวม (เส้นไม่แบน)
    [it.min, it.max].forEach((l) => { if (l != null && l >= lo - span * 1.5 && l <= hi + span * 1.5) { lo = Math.min(lo, l); hi = Math.max(hi, l); } });
    const pad = ((hi - lo) || 1) * 0.12;
    lo -= pad; hi += pad;
    const Y = (v) => H - PAD - (H - 2 * PAD) * (v - lo) / ((hi - lo) || 1);
    if (it.min != null || it.max != null) {
      const top = Y(Math.min(hi, it.max != null ? it.max : hi)), bot = Y(Math.max(lo, it.min != null ? it.min : lo));
      if (bot > top) svg.appendChild(el('rect', {x: 0, y: top, width: W, height: bot - top, class: 'mv-band'}));
      [it.min, it.max].forEach((l) => { if (l != null && l >= lo && l <= hi) svg.appendChild(el('line', {x1: 0, x2: W, y1: Y(l), y2: Y(l), class: 'mv-lim'})); });
    }
    const xy = pts.filter((p) => p[1] != null).map((p) => [X(tparse(p[0])), Y(p[1]), p]);
    if (xy.length > 1) svg.appendChild(el('polyline', {points: xy.map((q) => q[0].toFixed(1) + ',' + q[1].toFixed(1)).join(' '), class: 'mv-line'}));
    xy.forEach((q, i) => {
      const j = jcls(q[2][3]);
      if (j !== 'ok' || i === xy.length - 1 || xy.length <= 12)
        svg.appendChild(el('circle', {cx: q[0], cy: q[1], r: j !== 'ok' ? 2.6 : (i === xy.length - 1 ? 2.4 : 1.6), class: 'mv-dot ' + j + (i === xy.length - 1 ? ' last' : '')}));
    });
    return {svg, xs: xy.map((q) => q[0]), pts: xy.map((q) => q[2]), ys: xy.map((q) => q[1])};
  }

  function valueHtml(it, p) {
    if (!p) return '<b class="none">–</b><small>ไม่มีข้อมูล</small>';
    const v = it.type === 'num' ? fmt(p[1]) : esc(p[2] || (p[3] === 'ng' ? 'NG' : 'OK'));
    return `<b class="${jcls(p[3])}">${v}</b><small>${tlabel(p[0])}</small>`;
  }

  function render(d) {
    data = d;
    list.innerHTML = '';
    if (!d || !d.items.length) {
      list.innerHTML = '<div class="empty"><div class="e-title">เครื่องนี้ไม่มีหัวข้อตัวเลข / OK-NG</div></div>';
      sum.textContent = '';
      return;
    }
    const t0 = tparse(d.from + ' 00:00'), t1 = tparse(d.to + ' 23:59');
    const n = Math.max(0, ...d.items.map((x) => x.n));
    const ng = d.items.reduce((a, x) => a + x.ng, 0), warn = d.items.reduce((a, x) => a + x.warn, 0);
    sum.innerHTML = `${esc(d.eq_code || d.name)}${d.factory_name ? ' · ' + esc(d.factory_name) : ''} · ${d.items.length} หัวข้อ · ตรวจ ${n} ครั้ง` +
      (ng ? ` · <span class="text-ng">NG ${ng}</span>` : '') + (warn ? ` · <span class="text-warn">เตือน ${warn}</span>` : '') +
      ` · ${d.from.slice(8, 10)}/${d.from.slice(5, 7)} – ${d.to.slice(8, 10)}/${d.to.slice(5, 7)}`;
    link.href = U_('/trends') + '?form=' + d.form_id;
    // หัวข้อที่มี NG/เตือน ขึ้นก่อน แล้วตามลำดับในแบบฟอร์ม
    const order = d.items.map((it, i) => [it.ng * 1000 + it.warn * 10 > 0 ? 0 : 1, i, it]).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    const frag = document.createDocumentFragment();
    order.forEach(([, , it]) => {
      const row = document.createElement('a');
      row.className = 'mv-row' + (it.ng ? ' has-ng' : it.warn ? ' has-warn' : '');
      row.href = U_('/trends') + '?form=' + d.form_id + '&item=' + encodeURIComponent(it.key);
      const last = it.pts[it.pts.length - 1];
      const stat = it.type === 'num' && it.lo != null ? `ต่ำ ${fmt(it.lo)} · สูง ${fmt(it.hi)} · เฉลี่ย ${fmt(it.avg)}` : `${it.n} ครั้ง` + (it.ng ? ` · NG ${it.ng}` : '');
      row.innerHTML = `<div class="mv-l"><b title="${esc(it.name)}">${esc(it.name)}</b><small>${esc(it.spec)}${it.unit ? ' ' + esc(it.unit) : ''}</small></div>` +
        `<div class="mv-c"></div><div class="mv-v">${valueHtml(it, last)}</div><div class="mv-s small muted">${stat}</div>`;
      row.setAttribute('aria-label', `${it.name}: ล่าสุด ${last ? (it.type === 'num' ? fmt(last[1]) : (last[2] || last[3])) : 'ไม่มีข้อมูล'} ${it.unit || ''} · ${stat}`);
      const box = row.querySelector('.mv-c'), vbox = row.querySelector('.mv-v');
      if (it.pts.length) {
        const sp = spark(it, t0, t1);
        box.appendChild(sp.svg);
        const cur = el('line', {y1: 0, y2: H, class: 'mv-cur', visibility: 'hidden'});
        sp.svg.appendChild(cur);
        const pts = sp.pts || it.pts;
        const move = (ev) => {
          const r = sp.svg.getBoundingClientRect();
          const x = (ev.clientX - r.left) / r.width * W;
          let bi = 0;
          sp.xs.forEach((v, i) => { if (Math.abs(v - x) < Math.abs(sp.xs[bi] - x)) bi = i; });
          if (!pts[bi]) return;
          cur.setAttribute('x1', sp.xs[bi]); cur.setAttribute('x2', sp.xs[bi]); cur.setAttribute('visibility', 'visible');
          vbox.innerHTML = valueHtml(it, pts[bi]);
          vbox.classList.add('hover');
        };
        const leave = () => { cur.setAttribute('visibility', 'hidden'); vbox.innerHTML = valueHtml(it, last); vbox.classList.remove('hover'); };
        box.addEventListener('pointermove', move);
        box.addEventListener('pointerleave', leave);
      } else {
        box.innerHTML = '<span class="small muted">ไม่มีการตรวจในช่วงนี้</span>';
      }
      frag.appendChild(row);
    });
    list.appendChild(frag);
  }

  let days = +((document.querySelector('#mv-days a.on') || {}).dataset || {}).d || 7;
  function remember() {
    try {
      const u = new URL(location.href);
      u.searchParams.set('mv', sel.value);
      if (days === 30) u.searchParams.set('mvd', '30'); else u.searchParams.delete('mvd');
      history.replaceState(null, '', u.toString());
    } catch (e) { /* */ }
  }
  async function load() {
    list.classList.add('loading');
    try {
      const u = new URL(location.href);
      const q = '?form=' + encodeURIComponent(sel.value) + '&days=' + days + (u.searchParams.get('date') ? '&date=' + encodeURIComponent(u.searchParams.get('date')) : '');
      const r = await fetch(U_('/api/machine-values') + q, {credentials: 'same-origin'});
      if (!r.ok) throw new Error(r.status);
      render(await r.json());
      remember();
    } catch (e) {
      list.innerHTML = '<div class="empty">โหลดข้อมูลไม่สำเร็จ ลองใหม่อีกครั้ง</div>';
    } finally { list.classList.remove('loading'); }
  }
  if (sel) sel.addEventListener('change', load);
  const seg = $('mv-days');
  if (seg) seg.addEventListener('click', (e) => {
    const a = e.target.closest('a[data-d]'); if (!a) return;
    e.preventDefault();
    days = +a.dataset.d;
    seg.querySelectorAll('a').forEach((x) => x.classList.toggle('on', x === a));
    load();
  });
  try { render(data); } catch (e) { if (window.ECSLog) window.ECSLog('machvals: ' + e.message); }
})();
