/* v0.99.7 การเคลื่อนไหวทั้งระบบ (ไม่พึ่งไลบรารีภายนอก ทำงานออฟไลน์)
   1) แคปซูลเลื่อนแบบยืดหยุ่นในกลุ่มเมนู/แท็บ: ขอบด้านที่ไปถึงก่อนวิ่งเร็ว (0.36 วิ) ขอบตามมาช้ากว่า (0.55 วิ) → ยืดแล้วหด
   2) เมนูซ้าย: แถบไฮไลต์ไหลตามเมาส์ แล้วกลับไปที่เมนูปัจจุบันเมื่อเอาเมาส์ออก
   3) การ์ด 3 มิติ: เอียงตามตำแหน่งเมาส์ + แสงสะท้อน (data-tilt หรือ .kx) — เฉพาะเมาส์ ไม่ทำบนจอสัมผัส
   ผู้ใช้ที่ตั้ง "ลดการเคลื่อนไหว": วางตำแหน่งทันที ไม่มีแอนิเมชัน */
(function () {
  'use strict';
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const outCubic = (t) => 1 - Math.pow(1 - t, 3);
  const inOutCubic = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

  // ── ตัวขับค่าแบบแยกเวลา: แต่ละขอบมีความเร็ว/การหน่วงของตัวเอง ──
  function Mover(apply) {
    const cur = {}; const tw = {}; let raf = 0;
    function frame(now) {
      let busy = false;
      Object.keys(tw).forEach((k) => {
        const t = tw[k], p = Math.min(1, (now - t.t0) / t.d);
        cur[k] = t.from + (t.to - t.from) * t.ease(p);
        if (p < 1) busy = true; else delete tw[k];
      });
      apply(cur);
      raf = busy ? requestAnimationFrame(frame) : 0;
    }
    return {
      cur,
      set(v) { Object.keys(tw).forEach((k) => delete tw[k]); Object.assign(cur, v); apply(cur); },
      to(k, v, d, ease) {
        if (cur[k] === undefined || reduce) { cur[k] = v; apply(cur); return; }
        tw[k] = { from: cur[k], to: v, d, ease, t0: performance.now() };
        if (!raf) raf = requestAnimationFrame(frame);
      }
    };
  }

  // ── แคปซูล/เส้นใต้ ที่เลื่อนไปหาเมนูที่เลือก ──
  function glider(box, opt) {
    if (!box || box.dataset.gl) return;
    const all = () => [...box.querySelectorAll(opt.items)].filter((x) => !x.closest('.gl-ink'));
    const items = () => all().filter((x) => x.offsetParent !== null || x === document.activeElement);
    const itemOf = (t) => all().find((x) => x.contains(t)) || null;   // (closest() ใช้กับ :scope ไม่ได้)
    if (items().length < 2 && !opt.hover) return;
    box.dataset.gl = '1';
    box.classList.add('gl-on', 'gl-' + opt.kind);
    if (getComputedStyle(box).position === 'static') box.classList.add('gl-rel');   // ไม่ทับ position เดิม (เช่นเมนูซ้ายที่เป็น fixed)
    const g = document.createElement('span'); g.className = 'gl'; g.setAttribute('aria-hidden', 'true');
    box.insertBefore(g, box.firstChild);
    const y = opt.axis === 'y';
    // ชั้นตัวอักษรสีกลับด้าน ตัดตามรูปแคปซูล (clip-path) → ตัวอักษรเปลี่ยนสีตรงขอบแคปซูลพอดีระหว่างเลื่อน
    const inkOn = opt.kind === 'pill' || opt.kind === 'soft';
    let ink = null;
    if (inkOn) { ink = document.createElement('span'); ink.className = 'gl-ink'; ink.setAttribute('aria-hidden', 'true'); ink.inert = true; box.appendChild(ink); }
    function geom(el) {   // ใช้ offset (ไม่ถูกบิดด้วย transform/แอนิเมชันตอนเปิดหน้า) · ไม่ได้อยู่ใต้กล่องโดยตรงค่อยใช้ rect
      let x = 0, t = 0, e = el;
      while (e && e !== box) { x += e.offsetLeft; t += e.offsetTop; e = e.offsetParent; }
      if (e === box) return { x, t, w: el.offsetWidth, h: el.offsetHeight };
      const r = el.getBoundingClientRect(), o = box.getBoundingClientRect();
      return { x: r.left - o.left + box.scrollLeft - box.clientLeft, t: r.top - o.top + box.scrollTop - box.clientTop, w: r.width, h: r.height };
    }
    function buildInk() {
      if (!ink) return;
      ink.textContent = '';
      items().forEach((it) => {
        const c = document.createElement('span');   // สำเนาเป็น <span> (ไม่ใช่ลิงก์/ปุ่ม ไม่มีสถานะ on) → ตัวเลือก CSS/สคริปต์อื่นไม่เจอซ้ำ
        c.className = [...it.classList].filter((k) => !/^(on|active|gl-to)$/.test(k)).concat('gl-inv').join(' ');
        it.childNodes.forEach((n) => c.appendChild(n.cloneNode(true)));
        c.querySelectorAll('*').forEach((x) => [...x.attributes].forEach((at) => {
          if (/^(id|href|name|value|for|data-.*|aria-.*|on.*)$/i.test(at.name)) x.removeAttribute(at.name);
        }));
        const q = geom(it), cs = getComputedStyle(it);
        Object.assign(c.style, { left: q.x + 'px', top: q.t + 'px', width: q.w + 'px', height: q.h + 'px' });
        ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth',
          'borderStyle', 'justifyContent', 'alignItems', 'gap', 'fontSize', 'fontWeight', 'fontFamily', 'lineHeight', 'letterSpacing', 'textAlign'].forEach((k) => { c.style[k] = cs[k]; });
        if (cs.display.indexOf('flex') < 0) c.style.justifyContent = cs.textAlign === 'center' ? 'center' : 'flex-start';
        ink.appendChild(c);
      });
    }
    const mv = Mover((c) => {
      const a = c.a, b = c.b; if (a === undefined) return;
      if (y) { g.style.top = a + 'px'; g.style.height = Math.max(0, b - a) + 'px'; g.style.left = c.x + 'px'; g.style.width = c.w + 'px'; }
      else { g.style.left = a + 'px'; g.style.width = Math.max(0, b - a) + 'px'; g.style.top = c.y + 'px'; g.style.height = c.h + 'px'; }
      if (ink) {
        const W = ink.offsetWidth, H = ink.offsetHeight, R = opt.kind === 'soft' ? '6px' : '999px';
        ink.style.clipPath = `inset(${c.y}px ${Math.max(0, W - b)}px ${Math.max(0, H - c.y - c.h)}px ${a}px round ${R})`;
      }
    });
    const pos = (el) => { const q = geom(el); return y ? { a: q.t, b: q.t + q.h, x: q.x, w: q.w } : { a: q.x, b: q.x + q.w, y: q.t, h: q.h }; };
    let target = null, held = 0;
    function go(el, animate) {
      if (!el) { g.style.opacity = '0'; if (ink) ink.style.opacity = '0'; target = null; return; }
      const n = pos(el);
      if (!animate || mv.cur.a === undefined || g.style.opacity === '0') {
        mv.set(n); g.style.opacity = '1'; if (ink) ink.style.opacity = '1'; target = el; return;
      }
      g.style.opacity = '1'; if (ink) ink.style.opacity = '1';
      const fwd = n.a > mv.cur.a;                                  // ขอบด้านที่เลื่อนไปถึงก่อนและเร็วกว่า ขอบหลังตามมา
      mv.to(fwd ? 'b' : 'a', fwd ? n.b : n.a, 360, outCubic);
      mv.to(fwd ? 'a' : 'b', fwd ? n.a : n.b, 550, inOutCubic);
      if (y) { mv.to('x', n.x, 360, outCubic); mv.to('w', n.w, 360, outCubic); } else { mv.to('y', n.y, 360, outCubic); mv.to('h', n.h, 360, outCubic); }
      target = el;
    }
    const active = () => items().find(opt.isActive) || null;
    const relayout = () => { buildInk(); go(target && target.offsetParent ? target : active(), false); };
    // เริ่มต้น: วางที่เมนูปัจจุบันทันที (หลังฟอนต์โหลด วัดใหม่อีกครั้ง)
    buildInk(); go(active(), false);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(relayout);
    // กด: เลื่อนไปทันที และคงไว้ 1.2 วิ (ลิงก์ที่เปลี่ยนหน้า/เลื่อนหน้า ผู้ใช้เห็นการตอบสนองก่อน)
    box.addEventListener('click', (e) => {
      const it = itemOf(e.target); if (!it || e.ctrlKey || e.metaKey || e.shiftKey) return;
      if (!opt.hover) held = performance.now() + 1200;
      go(it, true);
    });
    if (opt.hover) {
      box.addEventListener('pointerover', (e) => { const it = itemOf(e.target); if (it && it.offsetParent && it !== target) go(it, true); });
      box.addEventListener('pointerleave', () => go(active(), true));
      box.addEventListener('toggle', () => setTimeout(() => go(target && target.offsetParent ? target : active(), false), 0), true);
      box.addEventListener('focusin', (e) => { const it = itemOf(e.target); if (it) go(it, true); });
    }
    // สถานะเปลี่ยนจากสคริปต์อื่น (ชิปกรอง · แท็บตามการเลื่อนหน้า) → เลื่อนตาม · เนื้อหาเปลี่ยน (ตัวนับ) → สร้างชั้นตัวอักษรใหม่
    let pend = 0;
    new MutationObserver((ms) => {
      if (ms.every((m) => (ink && ink.contains(m.target)) || m.target === g)) return;
      if (pend) return;
      pend = requestAnimationFrame(() => {
        pend = 0;
        if (ms.some((m) => m.type !== 'attributes')) buildInk();
        if (opt.hover) return;
        const a = active();
        if (performance.now() < held) { if (target && ink) buildInk(); return; }
        if (a && a !== target) go(a, true); else if (ink) buildInk();
      });
    }).observe(box, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['class', 'aria-pressed', 'aria-selected', 'aria-current', 'hidden'] });
    if (window.ResizeObserver) new ResizeObserver(relayout).observe(box);
    box.addEventListener('scroll', () => { if (!y) relayout(); }, { passive: true });
  }

  const isOn = (x) => x.classList.contains('on') || x.classList.contains('active') || x.getAttribute('aria-pressed') === 'true' || x.getAttribute('aria-current') === 'page';
  function scan(root) {
    root.querySelectorAll('.ov-tabs').forEach((b) => glider(b, { items: ':scope > a', kind: b.closest('.dash-luxe') ? 'line' : 'pill', isActive: isOn }));   // v0.99.13 แดชบอร์ด: เส้นใต้
    root.querySelectorAll('.seg').forEach((b) => {
      if (b.children.length < 2 || [...b.children].some((c) => !/^(A|BUTTON)$/.test(c.tagName))) return;   // .seg ที่ไม่ใช่กลุ่มปุ่ม (เช่นแถบเวลา) ไม่ยุ่ง
      glider(b, { items: ':scope > a, :scope > button', kind: 'soft', isActive: isOn });
    });
    root.querySelectorAll('.ab-chips, .cl-tabs').forEach((b) => glider(b, { items: ':scope > button', kind: 'pill', isActive: isOn }));
    root.querySelectorAll('.tabs').forEach((b) => glider(b, { items: ':scope > a', kind: 'line', isActive: isOn }));
    const sn = root.querySelector ? root.querySelector('.sidenav') : null;
    if (sn && fine) glider(sn, { items: '.sn-link, .sn-pin, .sn-gs', kind: 'hover', axis: 'y', hover: true, isActive: (x) => x.classList.contains('active') });
  }

  // ── การ์ด 3 มิติ: เอียงตามเมาส์ + แสงสะท้อน ──
  function tilt(el) {
    if (!fine || reduce || el.dataset.tiltOn) return;
    el.dataset.tiltOn = '1'; el.classList.add('tilt3d');
    const max = +(el.dataset.tilt || 7);
    let raf = 0, px = 0.5, py = 0.5;
    const paint = () => {
      raf = 0;
      el.style.setProperty('--rx', ((0.5 - py) * max).toFixed(2) + 'deg');
      el.style.setProperty('--ry', ((px - 0.5) * max).toFixed(2) + 'deg');
      el.style.setProperty('--gx', (px * 100).toFixed(1) + '%'); el.style.setProperty('--gy', (py * 100).toFixed(1) + '%');
    };
    el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect(); px = (e.clientX - r.left) / r.width; py = (e.clientY - r.top) / r.height;
      el.classList.add('tilt-in'); if (!raf) raf = requestAnimationFrame(paint);
    });
    el.addEventListener('pointerleave', () => { el.classList.remove('tilt-in'); px = py = 0.5; if (!raf) raf = requestAnimationFrame(paint); });
  }
  function scanTilt(root) { root.querySelectorAll('[data-tilt], .kx').forEach((el) => { if (el.dataset.tilt || !el.closest('.dash-luxe')) tilt(el); }); }   // v0.99.13 แดชบอร์ดเรียบ: ไม่เอียงแถบตัวเลข

  function init() { scan(document); scanTilt(document); document.documentElement.classList.add('motion-ready'); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  window.ECSMotion = { scan, scanTilt };
})();
