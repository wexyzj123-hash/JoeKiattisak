/* v0.99.16 ช่องสั่งงาน (Ctrl+K หรือ ⌘K): ค้นเมนู · เครื่องจักร · แบบฟอร์ม · ผลตรวจ · แจ้งเตือน แล้วสั่งงานต่อได้ทันที
   ↑↓ เลือก · Enter เปิด · → / ← เลือกคำสั่งของเครื่อง · Esc ปิด · ช่องค้นหาเมนูด้านซ้ายยังใช้ได้ตามเดิม */
(function () {
  'use strict';
  const esc = (x) => String(x == null ? '' : x).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let box = null, input = null, list = null, timer = 0, seq = 0, sel = 0, opener = null;
  const menus = () => [...document.querySelectorAll('#sidenav a.sn-link, #sidenav a.sn-pin')].map((a) => ({
    title: (a.querySelector('.sn-tx') || a).textContent.trim(), u: a.getAttribute('href'),
    sub: (a.closest('.sn-grp') && a.closest('.sn-grp').querySelector('.sn-gs')) ? a.closest('.sn-grp').querySelector('.sn-gs').getAttribute('title') || 'เมนู' : 'เมนู' })).filter((m) => m.title && m.u);

  function build() {
    box = document.createElement('div');
    box.className = 'pal'; box.hidden = true;
    box.innerHTML = '<div class="pal-scrim" data-pal-close></div>' +
      '<div class="pal-box" role="dialog" aria-modal="true" aria-label="ช่องสั่งงาน">' +
      '<div class="pal-in"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>' +
      '<input type="search" placeholder="พิมพ์รหัสเครื่อง ชื่อแบบฟอร์ม เลขผลตรวจ หรือชื่อเมนู" aria-label="ค้นหาและสั่งงาน" autocomplete="off" role="combobox" aria-expanded="true" aria-controls="palList">' +
      '<kbd>Esc</kbd></div><div class="pal-list" id="palList" role="listbox"></div>' +
      '<div class="pal-foot"><span><kbd>↑</kbd><kbd>↓</kbd> เลือก</span><span><kbd>Enter</kbd> เปิด</span><span><kbd>→</kbd> คำสั่งของเครื่อง</span></div></div>';
    document.body.appendChild(box);
    input = box.querySelector('input'); list = box.querySelector('.pal-list');
    box.addEventListener('click', (e) => { if (e.target.closest('[data-pal-close]')) close(); });
    input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(search, 160); });
    input.addEventListener('keydown', key);
  }
  function items() { return [...list.querySelectorAll('[data-pal-i]')]; }
  function focusSel(scroll) {
    const xs = items(); if (!xs.length) return;
    sel = (sel + xs.length) % xs.length;
    xs.forEach((x, i) => { x.classList.toggle('sel', i === sel); x.setAttribute('aria-selected', i === sel ? 'true' : 'false'); });
    input.setAttribute('aria-activedescendant', xs[sel].id);
    if (scroll) xs[sel].scrollIntoView({ block: 'nearest' });
  }
  function key(e) {
    const xs = items();
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key === 'ArrowDown') { e.preventDefault(); sel++; focusSel(true); return; }
    if (e.key === 'ArrowUp') { e.preventDefault(); sel--; focusSel(true); return; }
    if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && xs[sel] && (xs[sel].dataset.row || xs[sel].dataset.act)) {
      const row = xs[sel].dataset.row || xs[sel].dataset.act; const grp = xs.filter((x) => (x.dataset.row || x.dataset.act) === row);
      const k = grp.indexOf(xs[sel]) + (e.key === 'ArrowRight' ? 1 : -1);
      if (k >= 0 && k < grp.length) { e.preventDefault(); sel = xs.indexOf(grp[k]); focusSel(true); }
      return;
    }
    if (e.key === 'Enter' && xs[sel]) { e.preventDefault(); go(xs[sel]); }
  }
  function go(a) { const u = a.getAttribute('href'); if (!u) return; if (window.ECSNav) window.ECSNav(); close(true); location.href = u; }
  function row(it, gi, i, kind) {
    const id = 'pal-' + gi + '-' + i;
    let h = '<div class="pal-row' + (kind === 'mach' && it.down ? ' down' : '') + '"><a href="' + esc(it.u) + '" id="' + id + '" class="pal-a" role="option" data-pal-i' +
      (it.acts ? ' data-row="' + id + '"' : '') + '><b>' + esc(it.title) + '</b><small>' + esc(it.sub || '') + '</small></a>';
    if (it.acts) h += '<span class="pal-acts">' + it.acts.slice(1).map((x, k) => '<a href="' + esc(x.u) + '" id="' + id + '-' + k + '" class="pal-act" role="option" data-pal-i data-act="' + id + '">' + esc(x.t) + '</a>').join('') + '</span>';
    return h + '</div>';
  }
  function render(groups) {
    let h = '', gi = 0;
    groups.forEach(([title, xs, kind]) => {
      if (!xs.length) return;
      h += '<div class="pal-g"><div class="pal-gt">' + esc(title) + '</div>' + xs.map((it, i) => row(it, gi, i, kind)).join('') + '</div>'; gi++;
    });
    list.innerHTML = h || '<div class="pal-empty">ไม่พบ "' + esc(input.value) + '" — ลองพิมพ์รหัสเครื่อง เช่น SCT0002 หรือเลขผลตรวจ</div>';
    list.querySelectorAll('[data-pal-i]').forEach((a) => a.addEventListener('click', (e) => { if (e.button === 0 && !e.ctrlKey && !e.metaKey) { e.preventDefault(); go(a); } }));
    sel = 0; focusSel(false);
  }
  async function search() {
    const q = input.value.trim(), my = ++seq;
    const lq = q.toLowerCase();
    const m = menus().filter((x) => !q || x.title.toLowerCase().indexOf(lq) >= 0).slice(0, q ? 6 : 8);
    if (!q) { render([['ไปที่เมนู', m, 'menu']]); return; }
    render([['เมนู', m, 'menu']]);
    try {
      const r = await fetch(window.U('/api/palette') + '?q=' + encodeURIComponent(q), { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      if (!r.ok || my !== seq) return;
      const d = await r.json(); if (my !== seq) return;
      render([['เครื่องจักร', d.machines || [], 'mach'], ['เมนู', m, 'menu'], ['แบบฟอร์ม', d.forms || [], 'form'],
              ['ผลตรวจ', d.subs || [], 'sub'], ['แจ้งเตือนที่เปิดอยู่', d.alerts || [], 'alert']]);
    } catch (err) { /* ออฟไลน์: แสดงเฉพาะเมนู */ }
  }
  function open() {
    if (!box) build();
    opener = document.activeElement;
    box.hidden = false; document.documentElement.classList.add('pal-open');
    requestAnimationFrame(() => box.classList.add('in'));
    input.value = ''; search(); input.focus();
  }
  function close(nav) {
    if (!box || box.hidden) return;
    box.classList.remove('in'); document.documentElement.classList.remove('pal-open');
    setTimeout(() => { box.hidden = true; }, nav ? 0 : 200);
    if (!nav && opener && opener.focus) opener.focus();
  }
  window.ECSPalette = { open, close };
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); e.stopImmediatePropagation(); if (box && !box.hidden) close(); else open(); }
  }, true);
  document.addEventListener('click', (e) => { const t = e.target.closest && e.target.closest('[data-palette-open]'); if (t) { e.preventDefault(); open(); } });
})();
