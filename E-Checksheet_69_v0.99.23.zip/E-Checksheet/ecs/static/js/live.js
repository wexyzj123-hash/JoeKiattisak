/* v0.41 อัปเดตหน้าจอแบบ Real-time: ถามเซิร์ฟเวอร์ทุก N วินาทีว่าข้อมูลเปลี่ยนไหม (รอบตรวจ / ตารางรอบตรวจ / แจ้งเตือน / ผลตรวจ)
   เปลี่ยน → โหลดหน้าใหม่ทันที (คงตำแหน่งเลื่อนเดิม) · ถ้ากำลังพิมพ์/เลือก/เปิดตาราง → แสดงปุ่ม "มีข้อมูลใหม่" ให้กดเอง */
(function () {
  const el = document.querySelector('[data-live]');
  if (!el || !window.fetch) return;
  const url = el.dataset.live, sec = Math.max(5, +el.dataset.liveSec || 15);
  const KEY = 'live_scroll:' + location.pathname + location.search;
  try { const y = sessionStorage.getItem(KEY); if (y) { sessionStorage.removeItem(KEY); window.scrollTo(0, +y); } } catch (e) { /* */ }
  el.classList.add('live');
  el.innerHTML = '<span class="live-dot" aria-hidden="true"></span><span class="live-t">สด</span>' +
    '<button type="button" class="live-new" hidden>มีข้อมูลใหม่ · อัปเดต</button>';
  el.setAttribute('role', 'status');
  const t = el.querySelector('.live-t'), btn = el.querySelector('.live-new');
  let stamp = null, pending = false, busyNow = false, since = '', shown = 0;
  // v0.99.16 การ์ดสด: เหตุการณ์ใหม่ (ส่งผลตรวจ · แจ้งเตือน · หยุด/เดินเครื่อง) ลอยขึ้นมุมขวาล่าง ค้างผ่านการรีเฟรชหน้า
  const TKEY = 'live_toasts';
  const esc = (x) => String(x == null ? '' : x).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function stack() {
    let s = document.getElementById('liveToasts');
    if (!s) { s = document.createElement('div'); s.id = 'liveToasts'; s.className = 'lt-stack'; s.setAttribute('aria-live', 'polite'); document.body.appendChild(s); }
    return s;
  }
  function saved() { try { return JSON.parse(sessionStorage.getItem(TKEY) || '[]').filter((x) => x.until > Date.now()); } catch (e) { return []; } }
  function save(list) { try { sessionStorage.setItem(TKEY, JSON.stringify(list.slice(-5))); } catch (e) { /* */ } }
  function toast(ev, until, again) {
    const a = document.createElement(ev.href ? 'a' : 'div');
    a.className = 'lt t-' + (ev.tone || 'none') + (again ? ' again' : '');
    if (ev.href) a.href = ev.href;
    const left = Math.max(800, until - Date.now());
    a.innerHTML = '<i class="lt-dot" aria-hidden="true"></i><span class="lt-b"><b>' + esc(ev.title) + '</b><small>' + esc(ev.sub) + ' · ' +
      esc((ev.at || '').slice(11, 16)) + '</small></span><span class="lt-life" style="animation-duration:' + left + 'ms" aria-hidden="true"></span>';
    const close = document.createElement('button'); close.type = 'button'; close.className = 'lt-x'; close.setAttribute('aria-label', 'ปิด'); close.textContent = '×';
    close.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); drop(a, ev); });
    a.appendChild(close);
    stack().appendChild(a);
    setTimeout(() => drop(a, ev), left);
  }
  function drop(a, ev) {
    if (!a.isConnected) return;
    a.classList.add('out'); setTimeout(() => a.remove(), 380);
    save(saved().filter((x) => !(x.ev.title === ev.title && x.ev.at === ev.at)));
  }
  saved().forEach((x) => toast(x.ev, x.until, true));
  function showEvents(list) {
    const keep = saved();
    list.slice(-4).forEach((ev, i) => { const until = Date.now() + 9000 + i * 400; keep.push({ ev, until }); setTimeout(() => toast(ev, until), i * 220); });
    save(keep); shown = list.length;
    document.dispatchEvent(new CustomEvent('ecs:live-events', { detail: list }));   // โหมด TV อ่านออกเสียง
  }
  function busy() {
    const a = document.activeElement;
    if (a && /^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName) && a.type !== 'checkbox') return true;
    if (document.querySelector('.data-table:not([hidden]), dialog[open], .modal.open')) return true;
    if (document.querySelector('input[type=checkbox]:checked[name="ids"]')) return true;   // กำลังเลือกหลายรายการ
    const s = window.getSelection && window.getSelection();
    return !!(s && String(s).length);
  }
  function reload() {
    try { sessionStorage.setItem(KEY, String(window.scrollY)); } catch (e) { /* */ }
    location.reload();
  }
  btn.addEventListener('click', reload);
  async function tick() {
    if (document.visibilityState !== 'visible' || busyNow) return;
    busyNow = true;
    try {
      const r = await fetch(url + (since ? (url.indexOf('?') < 0 ? '?' : '&') + 'since=' + encodeURIComponent(since) : ''),
        {credentials: 'same-origin', cache: 'no-store', headers: {'Accept': 'application/json'}});
      if (!r.ok) throw new Error(r.status);
      const j = await r.json();
      el.classList.remove('off');
      t.textContent = 'สด · ' + j.at;
      if (stamp && j.stamp !== stamp) pending = true;
      stamp = j.stamp;
      if (j.events && j.events.length) showEvents(j.events);
      if (j.now) since = j.now;
    } catch (e) {
      el.classList.add('off');
      t.textContent = 'ขาดการเชื่อมต่อ';
    } finally { busyNow = false; }
    if (pending) {
      if (busy()) btn.hidden = false;
      else if (shown) { shown = 0; setTimeout(() => { if (busy()) btn.hidden = false; else reload(); }, 2600); }   // ให้เห็นการ์ดก่อนรีเฟรช
      else reload();
    }
  }
  tick();
  setInterval(tick, sec * 1000);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') tick(); });
})();
