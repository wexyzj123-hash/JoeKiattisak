/* ต้นทุนพลังงาน (v0.67) — กราฟซ้อน, ค้นหา, แก้หน่วยรายเดือน, ลากเรียงพื้นที่, สรุปสูตรสด */
(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const css = getComputedStyle(document.documentElement);
  const v = (k, d) => (css.getPropertyValue(k) || '').trim() || d;
  const fmt = (x, d) => (x == null || isNaN(x) ? '–' : Number(x).toLocaleString('th-TH', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }));

  // กราฟแท่งซ้อน (หมวด × เดือน) หรือแท่งกลุ่ม (โรงงาน × เดือน)
  const sd = $('#cc-stack');
  if (sd && window.echarts) {
    const d = JSON.parse(sd.textContent);
    const el = $('#ch-stack');
    const keys = Object.keys(d.series);
    const pal = ['#2563eb', '#0d9488', '#d97706', '#7c3aed', '#94a3b8', '#db2777'];
    const ink = v('--text', '#0f172a'), muted = v('--muted', '#64748b'), grid = v('--border', '#e2e8f0'), surf = v('--surface', '#fff');
    const c = echarts.init(el, null, { renderer: 'canvas' });
    c.setOption({
      backgroundColor: 'transparent', animationDuration: 300, textStyle: { color: ink },
      grid: { left: 8, right: 12, top: 34, bottom: 4, containLabel: true },
      legend: { top: 0, left: 0, icon: 'roundRect', itemWidth: 12, itemHeight: 10, textStyle: { color: muted } },
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: surf, borderColor: grid, textStyle: { color: ink },
        formatter: (ps) => `<b>${ps[0].axisValue}</b><br>` + ps.filter((p) => p.value).map((p) => `${p.marker} ${p.seriesName}: <b>${fmt(p.value)}</b>`).join('<br>') +
          (d.group ? '' : `<br>รวม <b>${fmt(ps.reduce((a, p) => a + (p.value || 0), 0))}</b>`) },
      xAxis: { type: 'category', data: d.months, axisTick: { show: false }, axisLine: { lineStyle: { color: grid } }, axisLabel: { color: muted } },
      yAxis: { type: 'value', axisLabel: { color: muted, formatter: (x) => fmt(x) }, splitLine: { lineStyle: { color: grid } } },
      series: keys.map((k, i) => ({ name: k, type: 'bar', stack: d.group ? undefined : 'a', barMaxWidth: 28, data: d.series[k],
        itemStyle: { color: pal[i % pal.length], borderColor: surf, borderWidth: d.group ? 0 : 1, borderRadius: d.group ? [4, 4, 0, 0] : 0 } })),
    });
    window.addEventListener('resize', () => c.resize());
  }

  // ค้นหาในตาราง
  const bindSearch = (inp, rows) => inp && inp.addEventListener('input', () => {
    const q = inp.value.trim().toLowerCase();
    rows.forEach((tr) => { tr.hidden = q && !(tr.dataset.q || '').includes(q); });
  });
  bindSearch($('#ccQ'), $$('#ccM tbody tr'));

  // แก้หน่วยรายเดือน
  const dl = $('#dMu');
  $$('.cc-mu').forEach((b) => b.addEventListener('click', () => {
    const vals = JSON.parse(b.dataset.v), src = JSON.parse(b.dataset.s);
    $('#muId').value = b.dataset.mid;
    $('#muL').textContent = b.dataset.l;
    for (let i = 1; i <= 12; i++) {
      const x = vals[i - 1];
      const s = x == null ? '' : String(Math.round(x * 1000) / 1000);
      $('#mu' + i).value = s;
      $('#mo' + i).value = s;
      $('#mu' + i).title = src[i - 1] ? ({ daily: 'จากประจำวัน', import: 'นำเข้า', manual: 'กรอกเอง' })[src[i - 1]] : '';
    }
    dl.showModal();
  }));

  // ลากเรียงพื้นที่
  const tb = $('#ccAr tbody');
  if (tb && $('#fOrd')) {
    let drag = null;
    tb.addEventListener('dragstart', (e) => { drag = e.target.closest('tr'); e.dataTransfer.effectAllowed = 'move'; });
    tb.addEventListener('dragover', (e) => {
      e.preventDefault();
      const tr = e.target.closest('tr');
      if (!drag || !tr || tr === drag) return;
      const r = tr.getBoundingClientRect();
      tb.insertBefore(drag, e.clientY > r.top + r.height / 2 ? tr.nextSibling : tr);
    });
    tb.addEventListener('drop', (e) => {
      e.preventDefault();
      $('#ordIds').value = $$('tr', tb).map((t) => t.dataset.id).join(',');
      $('#fOrd').hidden = false;
    });
  }

  // หน้าแก้พื้นที่: ตัวหาร, ค้นหา, สรุปสด
  const drv = $('#aDrv');
  if (drv) {
    const sync = () => { $('#aItem').hidden = drv.value !== 'item'; };
    drv.addEventListener('change', sync);
    sync();
  }
  const lt = $('#lkT');
  if (lt) {
    const rows = $$('tbody tr', lt);
    const onlyOn = $('#lkOn');
    const sum = () => {
      let n = 0, k = 0;
      rows.forEach((tr) => {
        const on = $('.lk-on', tr).checked;
        tr.classList.toggle('cc-on', on);
        if (on) { n++; k += (parseFloat(tr.dataset.k) || 0) * (parseFloat($('.lk-fx', tr).value) || 0); }
      });
      $('#lkN').textContent = n;
      $('#lkK').textContent = fmt(k);
    };
    const filt = () => {
      const q = $('#lkQ').value.trim().toLowerCase();
      rows.forEach((tr) => { tr.hidden = (q && !tr.dataset.q.includes(q)) || (onlyOn.checked && !$('.lk-on', tr).checked); });
    };
    lt.addEventListener('input', sum);
    lt.addEventListener('change', sum);
    $('#lkQ').addEventListener('input', filt);
    onlyOn.addEventListener('change', filt);
    sum();
  }
})();
