/* v0.88 หน้ามิเตอร์: การใช้รายวัน (แยกวัน · Target · ค่าเพี้ยน) + รายช่วงเวลา 15 นาทีของวันที่เลือก */
(function () {
  const el = document.getElementById('en-meter2');
  if (!el || !window.echarts) return;
  const D = JSON.parse(el.textContent);
  const css = getComputedStyle(document.documentElement);
  const v = (n, f) => (css.getPropertyValue(n) || '').trim() || f;
  const bg = getComputedStyle(document.body).backgroundColor.match(/\d+/g) || [255, 255, 255];
  const dark = (0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]) < 128;
  const TXT = v('--text', dark ? '#e2e8f0' : '#0f172a'), MUTED = v('--muted', '#64748b'), GRID = v('--border', '#e2e8f0');
  const OVER = '#d03b3b', TG = '#0ca30c', CMP = dark ? '#64748b' : '#94a3b8';
  const fmt = (x) => x == null ? '–' : Number(x).toLocaleString('th-TH', {maximumFractionDigits: Math.abs(x) >= 100 ? 0 : 2});
  const FL = {split: 'เฉลี่ยจากช่วงที่ขาดค่าอ่าน', bad: 'ค่าเพี้ยน — ไม่นับ', reset: 'ค่าลดลง/รีเซ็ต — ไม่นับ', spike: 'ค่ากระโดด', fix: 'แก้หน่วยแล้ว', first: 'ค่าแรก'};
  const charts = [];
  const base = {textStyle: {color: TXT, fontFamily: 'inherit'}, animation: false, grid: {left: 56, right: 16, top: 24, bottom: 36}};

  // การใช้รายวัน
  const n1 = document.getElementById('ch-meter2');
  if (n1) {
    const c = echarts.init(n1); charts.push(c);
    const data = D.u.map((x, i) => {
      const f = D.flags[i];
      if (x == null) return {value: null};
      const over = D.target != null && x > D.target;
      return {value: x, itemStyle: {color: D.color, opacity: f === 'split' ? 0.45 : 1, borderRadius: [3, 3, 0, 0]}};
    });
    const marks = D.u.map((x, i) => (['bad', 'reset'].includes(D.flags[i]) ? {coord: [i, 0], value: '!', itemStyle: {color: OVER}} : null)).filter(Boolean)
      .concat(D.u.map((x, i) => (x != null && D.target != null && x > D.target ? {coord: [i, x], symbol: 'triangle', symbolRotate: 180, symbolSize: 9, symbolOffset: [0, -8], label: {show: false}, itemStyle: {color: OVER}} : null)).filter(Boolean));
    c.setOption(Object.assign({}, base, {
      tooltip: {trigger: 'axis', axisPointer: {type: 'shadow'}, formatter: (ps) => {
        const i = ps[0].dataIndex, d = D.days[i], f = D.flags[i];
        return `<b>${d.slice(8)}/${d.slice(5, 7)}/${d.slice(0, 4)}</b><br>ใช้ <b>${fmt(D.u[i])}</b> ${D.unit}` +
          (D.target != null ? `<br>Target ${fmt(D.target)} ${D.unit}` : '') + (FL[f] ? `<br><i>${FL[f]}</i>` : '');
      }},
      xAxis: {type: 'category', data: D.days.map((d) => d.slice(8) + '/' + d.slice(5, 7)), axisLabel: {color: MUTED}, axisLine: {lineStyle: {color: GRID}}},
      yAxis: {type: 'value', name: D.unit, nameTextStyle: {color: MUTED}, axisLabel: {color: MUTED}, splitLine: {lineStyle: {color: GRID, opacity: .6}}},
      series: [{type: 'bar', data, barMaxWidth: 22,
        markLine: D.target != null ? {silent: true, symbol: 'none', lineStyle: {color: TG, type: 'dashed', width: 2},
          label: {color: TG, position: 'insideEndTop', formatter: 'Target ' + fmt(D.target)}, data: [{yAxis: D.target}]} : undefined,
        markPoint: marks.length ? {symbol: 'pin', symbolSize: 26, label: {color: '#fff'}, data: marks} : undefined}]}));
    c.on('click', (p) => { const pf = document.getElementById('pfDay'); if (pf) { pf.value = D.days[p.dataIndex]; pf.dispatchEvent(new Event('change')); document.getElementById('prof').scrollIntoView({behavior: 'smooth'}); } });
  }

  // รายช่วงเวลา 15 นาที
  const n2 = document.getElementById('ch-prof'), day = document.getElementById('pfDay'), info = document.getElementById('pfInfo');
  if (n2 && D.has_prof) {
    const c = echarts.init(n2); charts.push(c);
    async function load() {
      info.textContent = 'กำลังโหลด…';
      try {
        const r = await fetch(D.prof_url + '?day=' + encodeURIComponent(day.value), {credentials: 'same-origin'});
        const p = await r.json();
        info.textContent = p.sum == null ? 'วันนี้ไม่มีค่ารายช่วงเวลา' :
          `รวม ${fmt(p.sum)} ${p.unit} · สูงสุด ${fmt(p.peak)} ${p.rate_unit} เวลา ${p.peak_at} · ข้อมูลทุก ${p.res} นาที · เส้นประ = วันก่อน`;
        c.setOption(Object.assign({}, base, {
          tooltip: {trigger: 'axis', valueFormatter: (x) => x == null ? 'ไม่มีค่า' : `${fmt(x)} ${p.unit} (${fmt(x * p.rate)} ${p.rate_unit})`},
          xAxis: {type: 'category', data: p.slots, axisLabel: {color: MUTED, interval: 7}, axisLine: {lineStyle: {color: GRID}}},
          yAxis: {type: 'value', name: p.unit, nameTextStyle: {color: MUTED}, axisLabel: {color: MUTED}, splitLine: {lineStyle: {color: GRID, opacity: .6}}},
          series: [{name: day.value.slice(8) + '/' + day.value.slice(5, 7), type: 'bar', data: p.v, itemStyle: {color: D.color, borderRadius: [2, 2, 0, 0]}},
                   {name: 'วันก่อน', type: 'line', data: p.prev, showSymbol: false, lineStyle: {color: CMP, type: 'dashed', width: 1.5}, itemStyle: {color: CMP}}]}), true);
      } catch (e) { info.textContent = 'โหลดไม่สำเร็จ'; }
    }
    day.addEventListener('change', load);
    document.querySelectorAll('[data-pd]').forEach((b) => b.addEventListener('click', () => {
      const d = new Date(day.value + 'T00:00:00'); d.setDate(d.getDate() + (+b.dataset.pd));
      const iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      if (day.max && iso > day.max) return; day.value = iso; load(); }));
    load();
  }
  window.addEventListener('resize', () => charts.forEach((c) => c.resize()));
})();
