/* E-Checksheet v3 — Form Builder (vanilla JS, ไม่ต้องใช้ไลบรารีภายนอก)
   - ลากเพื่อเรียงลำดับ / ปุ่มขึ้น-ลง
   - แก้ไขหัวข้อด้านขวา ช่องที่แสดงเปลี่ยนตามประเภท
   - บันทึกร่าง (Ctrl+S) และ Publish */
(function () {
  'use strict';
  const B = window.BUILDER;
  const $ = (sel, root) => (root || document).querySelector(sel);
  const state = { items: [], selected: -1, dirty: false, publishedKeys: new Set(), errorIdx: new Set(),
    sections: {}, calendar: { shift_times: '08:00,20:00', day_start: '08:00' }, schedules: [] };
  let FREQS = { '': 'ทุกรอบ (ค่าเริ่มต้น)', shift: 'กะละ 1 ครั้ง', day: 'วันละ 1 ครั้ง', times: 'ตามเวลาที่กำหนด…',
    week: 'สัปดาห์ละ 1 ครั้ง', month: 'เดือนละ 1 ครั้ง' };
  const NO_POINT = 'ทั่วไป';

  const TYPE_DEFAULTS = { ok_ng: {}, number: {}, counter: {}, choice: { options: [{ label: 'ปกติ', ng: 0 }, { label: 'ผิดปกติ', ng: 1 }] }, text: {}, calc: {} };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function fmt(n) { return n == null || n === '' ? '' : String(n); }
  function toNum(v) { if (v === '' || v == null) return null; const n = Number(String(v).replace(',', '')); return Number.isFinite(n) ? n : NaN; }

  function newItem(extra) {
    return Object.assign({
      item_key: '', section: '', name: '', item_type: 'ok_ng', unit: '',
      min_value: null, max_value: null, warn_low: null, warn_high: null, counter_max_step: null,
      options: [], required: 1, critical: 0, photo_on_ng: 1, photo_required: 0, guide: '', check_freq: '', check_times: '', formula: ''
    }, extra || {});
  }

  function setDirty(v) {
    state.dirty = v;
    const st = $('#status');
    st.textContent = v ? 'ยังไม่บันทึก' : 'บันทึกแล้ว';
    st.classList.toggle('dirty', v);
  }

  // ── client-side validation (ตรงกับฝั่งเซิร์ฟเวอร์) ──
  function validate(it, i) {
    const e = [], L = 'หัวข้อที่ ' + (i + 1);
    if (!String(it.name || '').trim()) e.push(L + ': กรุณาระบุชื่อหัวข้อ');
    if (it.item_type === 'calc') e.push(...calcErrors(it).map(x => L + ': ' + x));
    if (it.item_type === 'number' || it.item_type === 'counter' || it.item_type === 'calc') {
      const f = ['min_value', 'max_value', 'warn_low', 'warn_high', 'counter_max_step'];
      f.forEach(k => { if (Number.isNaN(toNum(it[k]))) e.push(L + ': ค่า ' + k + ' ต้องเป็นตัวเลข'); });
      const mn = toNum(it.min_value), mx = toNum(it.max_value), wl = toNum(it.warn_low), wh = toNum(it.warn_high);
      if (mn != null && mx != null && mn > mx) e.push(L + ': Min ต้องไม่มากกว่า Max');
      if (wl != null && wh != null && wl > wh) e.push(L + ': ค่าเตือนต่ำต้องไม่มากกว่าค่าเตือนสูง');
      if (wl != null && mn != null && wl < mn) e.push(L + ': ค่าเตือนต่ำต้องอยู่ในช่วง Min–Max');
      if (wh != null && mx != null && wh > mx) e.push(L + ': ค่าเตือนสูงต้องอยู่ในช่วง Min–Max');
    }
    if (it.check_freq === 'times') {
      const bad = String(it.check_times || '').split(/[,\s;/]+/).filter(Boolean).filter(t => !/^([01]?\d|2[0-3])[:.][0-5]\d$/.test(t));
      if (bad.length) e.push(L + ': เวลา "' + bad[0] + '" ไม่ถูกต้อง (ใช้รูปแบบ 08:00)');
      else if (!String(it.check_times || '').trim()) e.push(L + ': ระบุเวลาตรวจอย่างน้อย 1 เวลา เช่น 08:00, 20:00');
    }
    if (it.item_type === 'choice') {
      const labels = (it.options || []).map(o => String(o.label || '').trim()).filter(Boolean);
      if (labels.length < 2) e.push(L + ': ตัวเลือกต้องมีอย่างน้อย 2 ตัวเลือก');
      if (new Set(labels).size !== labels.length) e.push(L + ': ตัวเลือกซ้ำกัน');
    }
    return e;
  }

  function showErrors(list) {
    const box = $('#errors');
    if (!list || !list.length) { box.hidden = true; box.innerHTML = ''; return; }
    box.hidden = false;
    box.innerHTML = '<strong>บันทึกไม่ได้ กรุณาแก้ไข:</strong><ul>' + list.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>';
    state.errorIdx = new Set();
    list.forEach(msg => { const m = /หัวข้อที่ (\d+)/.exec(msg); if (m) state.errorIdx.add(Number(m[1]) - 1); });
    renderList();
    box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  // ── list ──
  function spec(it) {
    if (it.item_type === 'calc') {
      const mn = fmt(it.min_value), mx = fmt(it.max_value), u = it.unit ? ' ' + it.unit : '';
      return '= ' + formulaText(it.formula) + (mn !== '' || mx !== '' ? ' · ' + (mn !== '' && mx !== '' ? mn + ' – ' + mx : mn !== '' ? '≥ ' + mn : '≤ ' + mx) + u : '');
    }
    if (it.item_type === 'number' || it.item_type === 'counter') {
      const mn = fmt(it.min_value), mx = fmt(it.max_value), u = it.unit ? ' ' + it.unit : '';
      if (mn !== '' && mx !== '') return mn + ' – ' + mx + u;
      if (mn !== '') return '≥ ' + mn + u;
      if (mx !== '') return '≤ ' + mx + u;
      return it.item_type === 'counter' ? 'ไม่น้อยกว่าครั้งก่อน' + u : 'ยังไม่มีเกณฑ์' + u;
    }
    if (it.item_type === 'choice') return (it.options || []).map(o => o.label + (o.ng ? ' (NG)' : '')).join(' / ');
    if (it.item_type === 'ok_ng') return 'OK / NG';
    return '';
  }

  // ── v0.95 หัวข้อคำนวณ: สูตรอ้างหัวข้อตัวเลขด้วย {item_key} · แสดงเป็นชื่อหัวข้อ ──
  const NUM_T = ['number', 'counter', 'calc'];
  function keyOf(it) { if (!it.item_key) it.item_key = 'k' + Array.from(crypto.getRandomValues(new Uint8Array(6)), b => b.toString(16).padStart(2, '0')).join(''); return it.item_key; }
  function formulaText(f) {
    return String(f || '').replace(/\{([A-Za-z0-9_\-]+)\}/g, (m, k) => { const x = state.items.find(i => i.item_key === k); return x ? '[' + (x.name || 'หัวข้อ') + ']' : '[?]'; }) || '(ยังไม่ใส่สูตร)';
  }
  function calcErrors(it) {
    const f = String(it.formula || '').trim(), e = [];
    if (!f) return ['หัวข้อคำนวณต้องใส่สูตร'];
    const refs = [...f.matchAll(/\{([A-Za-z0-9_\-]+)\}/g)].map(m => m[1]);
    if (!refs.length) e.push('สูตรต้องอ้างอย่างน้อย 1 หัวข้อ');
    refs.forEach(k => { const x = state.items.find(i => i.item_key === k);
      if (!x) e.push('สูตรอ้างหัวข้อที่ถูกลบไปแล้ว'); else if (!NUM_T.includes(x.item_type)) e.push('สูตรอ้าง “' + x.name + '” ซึ่งไม่ใช่หัวข้อตัวเลข');
      else if (x === it) e.push('สูตรอ้างตัวเองไม่ได้'); });
    if (/[^\d\s.+\-*/(),{}A-Za-z_]/.test(f.replace(/\{[^}]*\}/g, ''))) e.push('มีอักขระที่ใช้ในสูตรไม่ได้');
    return [...new Set(e)];
  }
  function calcEditor(it) {
    const nums = state.items.filter(x => x !== it && NUM_T.includes(x.item_type));
    return '<div class="field b-calc"><label>🧮 สูตรคำนวณ</label>' +
      '<input type="text" data-f="formula" value="' + esc(it.formula || '') + '" placeholder="กดชื่อหัวข้อด้านล่างเพื่อใส่ในสูตร เช่น {ค่าเข้า} - {ค่าออก}" spellcheck="false" style="font-family:monospace">' +
      '<div class="b-calcprev" id="calcPrev">= ' + esc(formulaText(it.formula)) + '</div>' +
      '<div class="b-timechips">' + (nums.length ? nums.map(x => '<button type="button" class="chip" data-calcref="' + state.items.indexOf(x) + '">+ ' + esc(x.name || 'หัวข้อ') + (x.unit ? ' (' + esc(x.unit) + ')' : '') + '</button>').join('') :
        '<span class="small muted">ยังไม่มีหัวข้อตัวเลขในแบบฟอร์ม — เพิ่มหัวข้อตัวเลขก่อน</span>') + '</div>' +
      '<div class="b-timechips">' + ['+', '-', '*', '/', '(', ')', 'abs(', 'avg(', 'max(', 'min(', ','].map(o => '<button type="button" class="chip" data-calcop="' + esc(o) + '">' + esc(o) + '</button>').join('') + '</div>' +
      '<p class="small muted" style="margin:4px 0 0">ช่างไม่ต้องกรอก — ระบบคำนวณให้ทันทีเมื่อกรอกหัวข้อที่อ้างครบ แล้วตัดสิน OK/เตือน/NG ตาม Min/Max ด้านล่าง เช่น ΔP ไส้กรอง = ขาเข้า − ขาออก · ΔT Chiller = น้ำกลับ − น้ำจ่าย</p></div>';
  }

  function freqText(it) {
    if (!it.check_freq) return '';
    if (it.check_freq === 'times') {
      const t = String(it.check_times || '').split(/[,\s;/]+/).filter(Boolean);
      return t.length + ' ครั้ง/วัน ' + t.join(', ');
    }
    return FREQS[it.check_freq] || ivLabel(it.check_freq);
  }
  function ivLabel(f) { const m = /^([dwm]):(\d{1,3})$/.exec(f || ''); if (!m) return ''; const u = { d: 'วัน', w: 'สัปดาห์', m: 'เดือน' }[m[1]];
    return m[2] === '1' ? u + 'ละ 1 ครั้ง' : 'ทุก ' + m[2] + ' ' + u; }

  // จัดหัวข้อที่อยู่จุดตรวจเดียวกันให้อยู่ติดกัน (ลำดับจุด = ลำดับที่ปรากฏครั้งแรก) — ไม่เปลี่ยนลำดับภายในจุด
  function regroup() {
    const sel = state.items[state.selected];
    const order = [];
    state.items.forEach(it => { if (!order.includes(it.section || '')) order.push(it.section || ''); });
    state.items = order.flatMap(sec => state.items.filter(it => (it.section || '') === sec));
    if (sel) state.selected = state.items.indexOf(sel);
  }
  function groups() {
    const out = [];
    state.items.forEach((it, i) => {
      const sec = it.section || '';
      let g = out.find(x => x.name === sec);
      if (!g) { g = { name: sec, idx: [] }; out.push(g); }
      g.idx.push(i);
    });
    return out;
  }

  function renderList() {
    const list = $('#list');
    if (!state.items.length) {
      list.innerHTML = '<div class="card empty"><div class="e-title">ยังไม่มีหัวข้อตรวจ</div>' +
        '<div>เริ่มจาก "+ เพิ่มจุดตรวจ" (เช่น ถังพักน้ำ, ปั๊ม, ตู้คอนโทรล) แล้วเพิ่มหัวข้อในแต่ละจุด<br>หรือ "วางหลายหัวข้อ" / "นำเข้าจากไฟล์"</div></div>';
      return;
    }
    regroup();
    const gs = groups();
    const named = gs.some(g => g.name);
    let html = '';
    gs.forEach((g, gi) => {
      const meta = state.sections[g.name] || {};
      html += '<div class="b-group' + (g.name ? '' : ' b-group-none') + '" data-g="' + gi + '">' +
        '<div class="b-group-head">' +
        '<span class="b-group-no">' + (g.name || named ? gi + 1 : '•') + '</span>' +
        '<div class="b-group-title"><b>' + esc(g.name || (named ? NO_POINT + ' (ยังไม่ระบุจุดตรวจ)' : NO_POINT)) + '</b>' +
        '<span class="small muted">' + g.idx.length + ' หัวข้อ' + (meta.hint ? ' · 📍 ' + esc(meta.hint) : '') + '</span></div>' +
        '<div class="b-actions">' +
        '<button class="btn btn-sm" type="button" data-gact="add" title="เพิ่มหัวข้อในจุดนี้">+ หัวข้อ</button>' +
        '<button class="btn btn-icon" type="button" data-gact="edit" title="แก้ชื่อ / ตำแหน่ง / ความถี่ทั้งจุด" aria-label="แก้ไขจุดตรวจ">✎</button>' +
        '<button class="btn btn-icon" type="button" data-gact="up" title="ย้ายจุดขึ้น" aria-label="ย้ายจุดขึ้น"' + (gi ? '' : ' disabled') + '>↑</button>' +
        '<button class="btn btn-icon" type="button" data-gact="down" title="ย้ายจุดลง" aria-label="ย้ายจุดลง"' + (gi < gs.length - 1 ? '' : ' disabled') + '>↓</button>' +
        (g.name ? '<button class="btn btn-icon btn-danger" type="button" data-gact="ungroup" title="ยกเลิกจุดตรวจ (หัวข้อยังอยู่)" aria-label="ยกเลิกจุดตรวจ">✕</button>' : '') +
        '</div></div>';
      g.idx.forEach(i => {
        const it = state.items[i];
        const isNew = it.item_key && !state.publishedKeys.has(it.item_key) || !it.item_key;
        html += '<div class="b-item' + (i === state.selected ? ' selected' : '') + (state.errorIdx.has(i) ? ' has-error' : '') +
          '" draggable="true" data-i="' + i + '">' +
          '<div class="b-handle" title="ลากเพื่อย้าย (ย้ายข้ามจุดตรวจได้)">⋮⋮</div>' +
          '<div style="min-width:0"><div class="b-name">' + (i + 1) + '. ' + (esc(it.name) || '<span class="muted">(ยังไม่มีชื่อ)</span>') + '</div>' +
          '<div class="b-meta"><span class="badge b-info">' + esc(B.typeLabels[it.item_type] || it.item_type) + '</span>' +
          '<span>' + esc(spec(it)) + '</span>' +
          (it.check_freq ? '<span class="badge b-freq">⏱ ' + esc(freqText(it)) + '</span>' : '') +
          (it.photo_required ? '<span class="badge b-info">📷 ต้องมีรูป</span>' : '') +
          (it.critical ? '<span class="badge b-ng">วิกฤต</span>' : '') +
          (!it.required ? '<span class="badge b-none">ไม่บังคับ</span>' : '') +
          ((B.requests || []).some(r => r.item_key && r.item_key === it.item_key) ? '<span class="badge b-warn">✏️ มีคำขอแก้ไข</span>' : '') +
          (isNew && state.publishedKeys.size ? '<span class="badge b-warn">ใหม่</span>' : '') + '</div></div>' +
          '<div class="b-actions">' +
          '<button class="btn btn-icon" type="button" data-act="up" title="เลื่อนขึ้น" aria-label="เลื่อนขึ้น">↑</button>' +
          '<button class="btn btn-icon" type="button" data-act="down" title="เลื่อนลง" aria-label="เลื่อนลง">↓</button>' +
          '<button class="btn btn-icon" type="button" data-act="dup" title="ทำสำเนา" aria-label="ทำสำเนา">⧉</button>' +
          '<button class="btn btn-icon btn-danger" type="button" data-act="del" title="ลบ" aria-label="ลบ">✕</button>' +
          '</div></div>';
      });
      html += '</div>';
    });
    list.innerHTML = html;
  }

  // ── จุดตรวจ (กลุ่มหัวข้อ) ──
  let groupEditing = null;       // null = สร้างใหม่, string = ชื่อจุดเดิม
  function openGroupDialog(name) {
    groupEditing = name;
    const meta = state.sections[name || ''] || {};
    $('#gTitle').textContent = name == null ? 'เพิ่มจุดตรวจ' : 'แก้ไขจุดตรวจ';
    $('#gName').value = name || '';
    $('#gHint').value = meta.hint || '';
    $('#gFreq').value = '__keep';
    $('#gFreqRow').hidden = name == null;
    $('#gTimes').value = ''; $('#gTimesRow').hidden = true;
    $('#dlgGroup').showModal();
    $('#gName').focus();
  }
  $('#gFreq').addEventListener('change', () => { $('#gTimesRow').hidden = $('#gFreq').value !== 'times'; });
  $('#gApply').addEventListener('click', () => {
    const name = $('#gName').value.trim().slice(0, 120);
    const hint = $('#gHint').value.trim().slice(0, 300);
    if (groupEditing == null && !name) { $('#gName').focus(); return; }
    if (name && name !== (groupEditing || '') && state.items.some(it => (it.section || '') === name) && groupEditing != null &&
        !confirm('มีจุดตรวจชื่อ "' + name + '" อยู่แล้ว — รวมหัวข้อเข้าด้วยกัน?')) return;
    if (groupEditing == null) {
      state.items.push(newItem({ section: name }));
      state.selected = state.items.length - 1;
    } else {
      const old = groupEditing || '';
      const freq = $('#gFreq').value;
      state.items.forEach(it => {
        if ((it.section || '') !== old) return;
        it.section = name;
        if (freq !== '__keep') { it.check_freq = freq; it.check_times = freq === 'times' ? $('#gTimes').value.trim() : ''; }
      });
      if (old !== name) delete state.sections[old];
    }
    state.sections[name] = { hint };
    $('#dlgGroup').close();
    setDirty(true); renderList(); renderEditor();
    if (groupEditing == null) { const n = $('#editor [data-f=name]'); if (n) n.focus(); }
  });
  function groupAction(gi, act) {
    const gs = groups(), g = gs[gi]; if (!g) return;
    if (act === 'add') {
      const at = g.idx[g.idx.length - 1] + 1;
      state.items.splice(at, 0, newItem({ section: g.name }));
      state.selected = at; setDirty(true); renderList(); renderEditor();
      const n = $('#editor [data-f=name]'); if (n) n.focus();
    } else if (act === 'edit') openGroupDialog(g.name);
    else if (act === 'up' || act === 'down') {
      const other = gs[act === 'up' ? gi - 1 : gi + 1]; if (!other) return;
      const names = gs.map(x => x.name);
      const a = names.indexOf(g.name), b = names.indexOf(other.name);
      [names[a], names[b]] = [names[b], names[a]];
      const sel = state.items[state.selected];
      state.items = names.flatMap(n => state.items.filter(it => (it.section || '') === n));
      state.selected = sel ? state.items.indexOf(sel) : -1;
      setDirty(true); renderList(); renderEditor();
    } else if (act === 'ungroup') {
      if (!confirm('ยกเลิกจุดตรวจ "' + g.name + '"?\nหัวข้อ ' + g.idx.length + ' ข้อ ไม่ถูกลบ แต่จะย้ายไปอยู่กลุ่ม "' + NO_POINT + '"')) return;
      g.idx.forEach(i => { state.items[i].section = ''; });
      delete state.sections[g.name];
      setDirty(true); renderList(); renderEditor();
    }
  }
  $('#btnGroup').addEventListener('click', () => openGroupDialog(null));

  // จัดกลุ่มอัตโนมัติจากชื่อ เช่น "DISCHARGE TANK: ถังไม่รั่ว" → จุด "DISCHARGE TANK" หัวข้อ "ถังไม่รั่ว"
  const PREFIX_RE = /^\s*([^:：]{2,60}?)\s*[:：]\s*(\S.*)$/;
  function autoPlan() {
    const canon = {}, plan = [];
    state.items.forEach((it, i) => {
      const m = PREFIX_RE.exec(it.name || ''); if (!m || /^\d+([.,]\d+)?$/.test(m[1].trim())) return;
      const key = m[1].trim().replace(/\s+/g, ' ').toUpperCase();
      canon[key] = canon[key] || m[1].trim().replace(/\s+/g, ' ');
      plan.push({ i, section: canon[key], name: m[2].trim() });
    });
    return plan;
  }
  $('#btnAuto').addEventListener('click', () => {
    const plan = autoPlan();
    const box = $('#autoPreview');
    if (!plan.length) {
      box.innerHTML = '<p>ไม่พบชื่อหัวข้อที่มีรูปแบบ <span class="mono">ชื่อจุด: รายละเอียด</span><br>' +
        '<span class="muted small">ตัวอย่าง: "DISCHARGE TANK: ถังไม่มีการชำรุด" จะถูกแยกเป็นจุด "DISCHARGE TANK" และหัวข้อ "ถังไม่มีการชำรุด"</span></p>';
      $('#autoApply').hidden = true;
    } else {
      const bySec = {};
      plan.forEach(p => { (bySec[p.section] = bySec[p.section] || []).push(p); });
      box.innerHTML = '<p style="margin-top:0">พบ ' + Object.keys(bySec).length + ' จุดตรวจ จาก ' + plan.length + ' หัวข้อ (หัวข้ออื่นอยู่ที่เดิม):</p>' +
        Object.entries(bySec).map(([sec, ps]) => '<div class="auto-grp"><b>' + esc(sec) + '</b><ul>' +
          ps.map(p => '<li>' + esc(p.name) + '</li>').join('') + '</ul></div>').join('');
      $('#autoApply').hidden = false;
    }
    $('#dlgAuto').showModal();
  });
  $('#autoApply').addEventListener('click', () => {
    autoPlan().forEach(p => { const it = state.items[p.i]; it.section = p.section; it.name = p.name; });
    $('#dlgAuto').close(); setDirty(true); renderList(); renderEditor();
  });

  function move(from, to) {
    if (to < 0 || to >= state.items.length || from === to) return;
    const neighbour = state.items[to];
    if (neighbour && (neighbour.section || '') !== (state.items[from].section || '')) {
      state.items[from].section = neighbour.section || '';   // เลื่อนข้ามขอบจุด = ย้ายเข้าจุดข้างเคียง
    }
    const [it] = state.items.splice(from, 1);
    state.items.splice(to, 0, it);
    state.selected = to;
    state.errorIdx.clear();
    setDirty(true); renderList(); renderEditor();
  }

  $('#list').addEventListener('click', e => {
    const ga = e.target.closest('[data-gact]');
    if (ga) { groupAction(Number(ga.closest('.b-group').dataset.g), ga.dataset.gact); return; }
    const row = e.target.closest('.b-item'); if (!row) return;
    const i = Number(row.dataset.i);
    const act = e.target.closest('[data-act]');
    if (act) {
      e.stopPropagation();
      const a = act.dataset.act;
      if (a === 'up') move(i, i - 1);
      else if (a === 'down') move(i, i + 1);
      else if (a === 'dup') {
        const copy = JSON.parse(JSON.stringify(state.items[i])); copy.item_key = ''; copy.name += ' (สำเนา)';
        state.items.splice(i + 1, 0, copy); state.selected = i + 1; setDirty(true); renderList(); renderEditor();
      } else if (a === 'del') {
        const it = state.items[i];
        const warn = it.item_key && state.publishedKeys.has(it.item_key)
          ? '\nหัวข้อนี้มีในเวอร์ชันที่ใช้อยู่ ประวัติผลตรวจเดิมยังเก็บไว้ แต่การตรวจครั้งต่อไปจะไม่มีหัวข้อนี้' : '';
        if (!confirm('ลบหัวข้อ "' + (it.name || '(ไม่มีชื่อ)') + '"?' + warn)) return;
        state.items.splice(i, 1);
        state.selected = Math.min(i, state.items.length - 1);
        state.errorIdx.clear(); setDirty(true); renderList(); renderEditor();
      }
      return;
    }
    state.selected = i; renderList(); renderEditor();
  });

  // drag & drop
  let dragFrom = -1;
  $('#list').addEventListener('dragstart', e => {
    const row = e.target.closest('.b-item'); if (!row) return;
    dragFrom = Number(row.dataset.i); row.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(dragFrom));
  });
  $('#list').addEventListener('dragover', e => {
    const head = e.target.closest('.b-group-head');
    if (head && dragFrom >= 0) { e.preventDefault(); return; }
    const row = e.target.closest('.b-item'); if (!row || dragFrom < 0) return;
    e.preventDefault();
    document.querySelectorAll('.drop-before').forEach(x => x.classList.remove('drop-before'));
    row.classList.add('drop-before');
  });
  $('#list').addEventListener('drop', e => {
    const head = e.target.closest('.b-group-head');
    if (head && dragFrom >= 0) {
      e.preventDefault();
      const g = groups()[Number(head.closest('.b-group').dataset.g)];
      const it = state.items[dragFrom]; it.section = g.name;
      state.items.splice(dragFrom, 1);
      const last = state.items.map((x, i) => [x, i]).filter(([x]) => (x.section || '') === g.name).pop();
      const at = last ? last[1] + 1 : state.items.length;
      state.items.splice(at, 0, it); state.selected = at; dragFrom = -1;
      setDirty(true); renderList(); renderEditor(); return;
    }
    const row = e.target.closest('.b-item'); if (!row || dragFrom < 0) return;
    e.preventDefault();
    let to = Number(row.dataset.i);
    if (dragFrom < to) to -= 1;
    const target = state.items[Number(row.dataset.i)];
    const moving = state.items[dragFrom];
    if (target && moving && moving.section !== target.section) moving.section = target.section; // ย้ายเข้ากลุ่มที่วาง
    move(dragFrom, to); dragFrom = -1;
  });
  $('#list').addEventListener('dragend', () => {
    dragFrom = -1;
    document.querySelectorAll('.dragging,.drop-before').forEach(x => x.classList.remove('dragging', 'drop-before'));
  });

  // ── editor ──
  function sectionsList() { return [...new Set(state.items.map(x => x.section).filter(Boolean))]; }

  function renderEditor() {
    const ed = $('#editor');
    const it = state.items[state.selected];
    if (!it) { ed.innerHTML = '<div class="e-empty">เลือกหัวข้อทางซ้ายเพื่อแก้ไข</div>'; return; }
    const t = it.item_type, isNum = t === 'number' || t === 'counter' || t === 'calc';
    const presets = B.presets || [];
    const typeOpts = Object.keys(B.typeLabels).map(k => '<option value="' + k + '"' + (k === t ? ' selected' : '') + '>' + esc(B.typeLabels[k]) + '</option>').join('') +
      (presets.length ? '<optgroup label="ประเภทที่เพิ่มเอง">' + presets.map(p => '<option value="preset:' + p.id + '">' + esc(p.name) + ' (' + esc(B.typeLabels[p.item_type] || p.item_type) + ')</option>').join('') + '</optgroup>' : '') +
      (B.canPreset ? '<option value="__newpreset">+ บันทึกหัวข้อนี้เป็นประเภทใหม่…</option>' : '');
    const reqs = (B.requests || []).filter(r => r.item_key && r.item_key === it.item_key);
    let html = '<h2>หัวข้อที่ ' + (state.selected + 1) + '</h2>' +
      (reqs.length ? '<div class="b-chreq">✏️ คำขอแก้ไขจากหน้างาน ' + reqs.length + ' รายการ' + reqs.map(r => '<div><b>' + esc(r.kind_th) + '</b> — ' + esc(r.detail) +
        (r.proposed ? ' <span class="muted">(เสนอ: ' + esc(r.proposed) + ')</span>' : '') + ' <span class="small muted">· ' + esc(r.requester_name || '') + '</span>' +
        ' <a href="' + esc(r.url) + '" target="_blank">จัดการ ›</a></div>').join('') + '</div>' : '') +
      '<div class="field"><label>ชื่อหัวข้อ *</label><input type="text" data-f="name" maxlength="200" value="' + esc(it.name) + '"></div>' +
      '<div class="form-row"><div class="field"><label>ประเภท</label><select data-f="item_type">' + typeOpts + '</select></div>' +
      '<div class="field"><label>จุดตรวจ</label><select data-sec>' +
      '<option value=""' + (it.section ? '' : ' selected') + '>' + NO_POINT + ' (ไม่ระบุ)</option>' +
      sectionsList().map(s => '<option value="' + esc(s) + '"' + (s === it.section ? ' selected' : '') + '>' + esc(s) + '</option>').join('') +
      '<option value="__new">+ จุดตรวจใหม่…</option></select></div></div>';
    if (t === 'calc') html += calcEditor(it);
    if (isNum) {
      html += '<div class="form-row">' +
        '<div class="field"><label>หน่วย</label><input type="text" data-f="unit" maxlength="30" value="' + esc(it.unit) + '"></div>' +
        '<div class="field"><label>Min (ต่ำกว่า = NG)</label><input type="text" inputmode="decimal" data-f="min_value" value="' + fmt(it.min_value) + '"></div>' +
        '<div class="field"><label>Max (สูงกว่า = NG)</label><input type="text" inputmode="decimal" data-f="max_value" value="' + fmt(it.max_value) + '"></div></div>' +
        '<div class="form-row">' +
        '<div class="field"><label>เตือนเมื่อต่ำกว่า</label><input type="text" inputmode="decimal" data-f="warn_low" value="' + fmt(it.warn_low) + '"></div>' +
        '<div class="field"><label>เตือนเมื่อสูงกว่า</label><input type="text" inputmode="decimal" data-f="warn_high" value="' + fmt(it.warn_high) + '"></div></div>';
      if (t === 'counter') {
        html += '<div class="field"><label>เพิ่มขึ้นได้สูงสุดต่อรอบ (เกิน = เตือน)</label><input type="text" inputmode="decimal" data-f="counter_max_step" value="' + fmt(it.counter_max_step) + '" placeholder="เช่น 24 สำหรับชั่วโมงเดินเครื่อง/วัน"></div>' +
          '<p class="small muted" style="margin-top:-6px">มิเตอร์สะสม: ค่าที่น้อยกว่าครั้งก่อนจะเป็น NG อัตโนมัติ</p>';
      }
      if (t === 'number' || t === 'calc') {
        html += '<p class="small" id="noLimitNote" style="color:var(--warn)"' + (fmt(it.min_value) === '' && fmt(it.max_value) === '' ? '' : ' hidden') +
          '>ยังไม่มีเกณฑ์ Min/Max ระบบจะตัดสิน NG ไม่ได้</p>';
      }
    }
    if (t === 'choice') {
      html += '<div class="field"><label>ตัวเลือก (ติ๊ก NG สำหรับตัวเลือกที่ผิดปกติ)</label><div id="opts">' +
        (it.options || []).map((o, k) => '<div class="opt-row"><input type="text" data-opt="' + k + '" value="' + esc(o.label) + '" maxlength="80">' +
          '<label class="check" style="margin:0"><input type="checkbox" data-optng="' + k + '"' + (o.ng ? ' checked' : '') + '> NG</label>' +
          '<button class="btn btn-icon" type="button" data-optdel="' + k + '" aria-label="ลบตัวเลือก">✕</button></div>').join('') +
        '</div><button class="btn btn-sm" type="button" id="optAdd">+ ตัวเลือก</button></div>';
    }
    html += freqEditor(it);
    html += '<div class="field"><label>วิธีตรวจ / ข้อแนะนำ (แสดงให้ช่างเห็น)</label><textarea data-f="guide" maxlength="500">' + esc(it.guide) + '</textarea></div>' +
      '<div class="field">' +
      (t === 'calc' ? '' : '<label class="check"><input type="checkbox" data-b="required"' + (it.required ? ' checked' : '') + '> ต้องกรอก</label>' +
      '<label class="check"><input type="checkbox" data-b="photo_required"' + (it.photo_required ? ' checked' : '') + '> 📷 ต้องแนบรูปหลักฐานการตรวจ (ทุกครั้ง)</label>') +
      (t !== 'text' ? '<label class="check"><input type="checkbox" data-b="photo_on_ng"' + (it.photo_on_ng ? ' checked' : '') + '> NG ต้องแนบรูป</label>' +
        '<label class="check"><input type="checkbox" data-b="critical"' + (it.critical ? ' checked' : '') + '> NG = วิกฤต (แจ้งเตือนด่วน)</label>' : '') +
      '</div>';
    ed.innerHTML = html;
  }

  function roundTimes() {
    return [...new Set(state.schedules.flatMap(s => String(s.times || '').split(/[,\s]+/).filter(Boolean)))].sort();
  }
  function freqHelp(it) {
    const c = state.calendar;
    if (!it.check_freq) return 'ขึ้นให้ตรวจทุกครั้งที่เปิดแบบฟอร์ม';
    if (it.check_freq === 'shift') return 'ขึ้นครั้งแรกของแต่ละกะ (กะเริ่ม ' + esc(c.shift_times) + ') — ตรวจแล้ว รอบถัดไปในกะเดียวกันจะไม่ขึ้น';
    if (it.check_freq === 'day') return 'ขึ้นจนกว่าจะมีผู้ตรวจในวันนั้น (วันทำงานเริ่ม ' + esc(c.day_start) + ') — ตรวจแล้วรอบถัดไปในวันเดียวกันจะไม่ขึ้น';
    if (it.check_freq === 'week') return 'ขึ้นจนกว่าจะมีผู้ตรวจในสัปดาห์นั้น (เริ่มวันจันทร์ ' + esc(c.day_start) + ')';
    if (it.check_freq === 'month') return 'ขึ้นจนกว่าจะมีผู้ตรวจในเดือนนั้น (เริ่มวันที่ 1 ' + esc(c.day_start) + ')';
    const iv = /^([dwm]):(\d{1,3})$/.exec(it.check_freq);
    if (iv) return 'ขึ้นจนกว่าจะมีผู้ตรวจในช่วงนั้น แล้วขึ้นอีกครั้งเมื่อครบ' + (iv[2] === '1' ? '' : ' ' + iv[2]) + ' ' + ({ d: 'วัน', w: 'สัปดาห์', m: 'เดือน' }[iv[1]]) +
      (iv[1] === 'w' ? ' (ช่วงเริ่มวันจันทร์ ' : iv[1] === 'm' ? ' (ช่วงเริ่มวันที่ 1 ' : ' (เริ่มช่วง ') + esc(c.day_start) + ')';
    return 'ขึ้นเมื่อถึงแต่ละเวลาที่กำหนด ตรวจแล้วจะไม่ขึ้นจนถึงเวลาถัดไป';
  }
  function freqEditor(it) {
    const rt = roundTimes();
    const keys = Object.keys(FREQS); if (it.check_freq && !(it.check_freq in FREQS)) keys.push(it.check_freq);
    const opts = keys.map(k => '<option value="' + k + '"' + (k === (it.check_freq || '') ? ' selected' : '') + '>' + esc(FREQS[k] || ivLabel(k)) + '</option>').join('');
    let warn = '';
    if (it.check_freq === 'times' && rt.length) {
      const off = String(it.check_times || '').split(/[,\s;/]+/).filter(Boolean)
        .map(t => t.replace('.', ':').padStart(5, '0')).filter(t => !rt.includes(t));
      if (off.length) warn = '<p class="small" style="color:var(--warn);margin:4px 0 0">เวลา ' + esc(off.join(', ')) +
        ' ไม่ตรงกับรอบตรวจของแบบฟอร์ม — หัวข้อจะขึ้นในรอบแรกหลังเวลานั้น</p>';
    }
    return '<div class="field b-freqbox"><label>⏱ ความถี่การตรวจหัวข้อนี้</label><select data-f="check_freq">' + opts + '</select>' +
      '<div' + (it.check_freq === 'times' ? '' : ' hidden') + ' style="margin-top:6px">' +
      '<input type="text" data-f="check_times" value="' + esc(it.check_times || '') + '" placeholder="เช่น 08:00, 14:00, 20:00, 02:00" inputmode="numeric">' +
      (rt.length ? '<div class="b-timechips">' + rt.map(t => '<button type="button" class="chip" data-addtime="' + esc(t) + '">+ ' + esc(t) + '</button>').join('') + '</div>' : '') +
      '</div>' + warn +
      '<p class="small muted" style="margin:4px 0 0">' + freqHelp(it) + '</p>' +
      '<p class="small muted" style="margin:2px 0 0">' + (B.isTemplate ? 'แม่แบบ: รอบตรวจตั้งแยกที่แต่ละเครื่อง' :
        'รอบตรวจของแบบฟอร์มนี้: ' + (rt.length ? esc(rt.join(', ')) : 'ยังไม่ได้ตั้ง (ตั้งที่แท็บ "รอบตรวจ")')) +
      (B.isAdmin ? ' · <a href="' + B.calendarUrl + '" target="_blank">ตั้งเวลากะ</a>' : '') + '</p></div>';
  }

  $('#editor').addEventListener('input', e => {
    const it = state.items[state.selected]; if (!it) return;
    const f = e.target.dataset.f;
    if (f && f !== 'item_type' && f !== 'check_freq') {
      it[f] = ['min_value', 'max_value', 'warn_low', 'warn_high', 'counter_max_step'].includes(f) ? e.target.value.trim() : e.target.value;
      setDirty(true); renderList();
      if (f === 'formula') { const pv = $('#calcPrev'); if (pv) pv.textContent = '= ' + formulaText(it.formula); }
      const note = $('#noLimitNote');
      if (note) note.hidden = !(fmt(it.min_value) === '' && fmt(it.max_value) === '');
    }
    if (e.target.dataset.opt != null) { it.options[Number(e.target.dataset.opt)].label = e.target.value; setDirty(true); renderList(); }
  });
  $('#editor').addEventListener('change', e => {
    const it = state.items[state.selected]; if (!it) return;
    if (e.target.hasAttribute('data-sec')) {
      let v = e.target.value;
      if (v === '__new') {
        v = (prompt('ชื่อจุดตรวจใหม่ (เช่น ถังพักน้ำทิ้ง, ปั๊มน้ำ P-01, ตู้คอนโทรล)') || '').trim().slice(0, 120);
        if (!v) { renderEditor(); return; }
      }
      it.section = v; setDirty(true); renderList(); renderEditor(); return;
    }
    if (e.target.dataset.f === 'check_freq') {
      it.check_freq = e.target.value;
      if (it.check_freq === 'times' && !it.check_times) it.check_times = roundTimes().join(', ');
      if (it.check_freq !== 'times') it.check_times = '';
      setDirty(true); renderList(); renderEditor(); return;
    }
    if (e.target.dataset.f === 'item_type' && e.target.value === '__newpreset') {
      e.target.value = it.item_type;
      savePreset(it);
      return;
    }
    if (e.target.dataset.f === 'item_type' && e.target.value.startsWith('preset:')) {
      // ประเภทที่เพิ่มเอง: ใช้ค่าตั้งต้น (ประเภทพื้นฐาน ตัวเลือก หน่วย เกณฑ์)
      const p = (B.presets || []).find(x => 'preset:' + x.id === e.target.value);
      if (p) {
        it.item_type = p.item_type;
        if (p.item_type === 'choice') it.options = JSON.parse(JSON.stringify(p.options || []));
        if (p.unit) it.unit = p.unit;
        if (p.min_value != null) it.min_value = p.min_value;
        if (p.max_value != null) it.max_value = p.max_value;
        if (it.item_type === 'text') { it.photo_on_ng = 0; it.critical = 0; }
      }
      setDirty(true); renderList(); renderEditor(); return;
    }
    if (e.target.dataset.f === 'item_type') {
      it.item_type = e.target.value;
      if (it.item_type === 'choice' && (!it.options || it.options.length < 2)) it.options = JSON.parse(JSON.stringify(TYPE_DEFAULTS.choice.options));
      if (it.item_type === 'text') { it.photo_on_ng = 0; it.critical = 0; }
      if (it.item_type === 'calc') { it.required = 0; it.photo_required = 0; }
      setDirty(true); renderList(); renderEditor();
    }
    if (e.target.dataset.b) { it[e.target.dataset.b] = e.target.checked ? 1 : 0; setDirty(true); renderList(); }
    if (e.target.dataset.optng != null) { it.options[Number(e.target.dataset.optng)].ng = e.target.checked ? 1 : 0; setDirty(true); renderList(); }
  });
  $('#editor').addEventListener('click', e => {
    const it = state.items[state.selected]; if (!it) return;
    if (e.target.id === 'optAdd') { it.options.push({ label: '', ng: 0 }); setDirty(true); renderEditor(); }
    if (e.target.dataset.addtime) {
      const cur = String(it.check_times || '').split(/[,\s;/]+/).filter(Boolean);
      if (!cur.includes(e.target.dataset.addtime)) cur.push(e.target.dataset.addtime);
      it.check_times = cur.sort().join(', '); setDirty(true); renderList(); renderEditor(); return;
    }
    if (e.target.dataset.optdel != null) { it.options.splice(Number(e.target.dataset.optdel), 1); setDirty(true); renderList(); renderEditor(); }
  });

  // ── add / bulk ──
  $('#btnAdd').addEventListener('click', () => {
    const cur = state.items[state.selected];
    const at = state.selected >= 0 ? state.selected + 1 : state.items.length;
    state.items.splice(at, 0, newItem({ section: cur ? cur.section : '' }));
    state.selected = at; setDirty(true); renderList(); renderEditor();
    const name = $('#editor [data-f=name]'); if (name) name.focus();
  });
  $('#btnBulk').addEventListener('click', () => { $('#importInfo').hidden = true; $('#dlgBulk').showModal(); });
  // นำเข้าจากไฟล์: เซิร์ฟเวอร์อ่าน PDF/Excel → เติมข้อความในกล่อง "วางหลายหัวข้อ" ให้ตรวจแก้ก่อนเพิ่ม
  $('#btnImport').addEventListener('click', () => { $('#importFile').value = ''; $('#importFile').click(); });
  $('#importFile').addEventListener('change', async () => {
    const file = $('#importFile').files[0]; if (!file) return;
    const btn = $('#btnImport'); btn.disabled = true; const label = btn.textContent; btn.textContent = 'กำลังอ่านไฟล์…';
    try {
      const fd = new FormData(); fd.append('file', file);
      const r = await fetch(U('/api/forms/' + B.formId + '/import-items'), { method: 'POST', body: fd, credentials: 'same-origin',
        headers: { 'X-CSRF-Token': CS3.csrf(), Accept: 'application/json' } });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.error || 'อ่านไฟล์ไม่สำเร็จ');
      const box = $('#bulkText'); box.value = (box.value.trim() ? box.value.trim() + '\n' : '') + d.text;
      const info = $('#importInfo'); info.hidden = false;
      info.innerHTML = '<b>อ่านได้ ' + d.count + ' หัวข้อ</b> จาก ' + file.name.replace(/[<>&]/g, '') +
        ' — ตรวจ/แก้ชื่อ หน่วย และเกณฑ์ด้านล่าง ลบบรรทัดที่ไม่ใช่หัวข้อ แล้วกด "เพิ่มหัวข้อ"';
      $('#dlgBulk').showModal();
    } catch (e) { alert(e.message); }
    finally { btn.disabled = false; btn.textContent = label; }
  });
  $('#bulkApply').addEventListener('click', () => {
    const cur = state.items[state.selected];
    let section = cur ? cur.section : '', added = 0;
    $('#bulkText').value.split(/\r?\n/).forEach(line => {
      const raw = line.trim(); if (!raw) return;
      if (raw.startsWith('#')) { section = raw.replace(/^#+/, '').trim(); return; }
      const [name, unit, mn, mx, fq] = raw.split('|').map(x => (x || '').trim());
      const numeric = unit || mn || mx;
      state.items.push(newItem(Object.assign({ section, name, item_type: numeric ? 'number' : 'ok_ng', unit: unit || '',
        min_value: mn || null, max_value: mx || null }, parseFreqText(fq))));
      added++;
    });
    $('#dlgBulk').close(); $('#bulkText').value = '';
    if (added) { state.selected = state.items.length - 1; setDirty(true); renderList(); renderEditor(); }
  });

  // คอลัมน์ที่ 5 ของ "วางหลายหัวข้อ": ทุกรอบ / กะ / วัน / สัปดาห์ / เดือน / 08:00,20:00
  function parseFreqText(t) {
    t = String(t || '').trim().toLowerCase();
    if (!t || /ทุกรอบ|every|all/.test(t)) return {};
    if (/\d{1,2}[:.]\d{2}/.test(t)) return { check_freq: 'times', check_times: (t.match(/\d{1,2}[:.]\d{2}/g) || []).join(', ') };
    if (/กะ|shift/.test(t)) return { check_freq: 'shift' };
    if (/สัปดาห์|week/.test(t)) return { check_freq: 'week' };
    if (/เดือน|month/.test(t)) return { check_freq: 'month' };
    if (/วัน|day|daily/.test(t)) return { check_freq: 'day' };
    return {};
  }

  // ── save / publish / discard ──
  function payloadItems() {
    return state.items.map(it => ({
      item_key: it.item_key || '', section: it.section || '', name: it.name, item_type: it.item_type, unit: it.unit || '',
      min_value: it.min_value, max_value: it.max_value, warn_low: it.warn_low, warn_high: it.warn_high,
      counter_max_step: it.counter_max_step, options: it.options || [], required: it.required, critical: it.critical,
      photo_on_ng: it.photo_on_ng, guide: it.guide || '', legacy_item_id: it.legacy_item_id || null,
      check_freq: it.check_freq || '', check_times: it.check_times || '', photo_required: it.photo_required ? 1 : 0,
      formula: it.item_type === 'calc' ? (it.formula || '') : ''
    }));
  }
  function payloadSections() {
    const used = new Set(state.items.map(it => it.section || ''));
    return Object.entries(state.sections).filter(([n, m]) => used.has(n) && m && m.hint).map(([name, m]) => ({ name, hint: m.hint }));
  }

  async function save() {
    const errs = []; state.items.forEach((it, i) => errs.push(...validate(it, i)));
    if (errs.length) { showErrors(errs); return false; }
    const btn = $('#btnSave'); btn.disabled = true; $('#status').textContent = 'กำลังบันทึก…';
    try {
      const res = await CS3.api('PUT', '/api/forms/' + B.formId + '/draft', { version_id: B.versionId, items: payloadItems(), sections: payloadSections() });
      B.versionId = res.version_id;
      $('#btnDiscard').hidden = !state.publishedKeys.size;
      showErrors([]); state.errorIdx.clear();
      await load(true);
      setDirty(false);
      return true;
    } catch (e) {
      showErrors(e.data && e.data.errors ? e.data.errors : [e.message]);
      $('#status').textContent = 'บันทึกไม่สำเร็จ'; return false;
    } finally { btn.disabled = false; }
  }

  $('#btnSave').addEventListener('click', save);
  document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); } });
  window.addEventListener('beforeunload', e => { if (state.dirty) { e.preventDefault(); e.returnValue = ''; } });

  ($('#btnPublish') || document.createElement('button')).addEventListener('click', async () => {
    if (state.dirty && !(await save())) return;
    if (!B.versionId) { showErrors(['ยังไม่มีการแก้ไข — แก้หัวข้อแล้วบันทึกก่อน Publish']); return; }
    if (!state.items.length) { showErrors(['ต้องมีหัวข้อตรวจอย่างน้อย 1 หัวข้อก่อน Publish']); return; }
    const keys = new Set(state.items.map(x => x.item_key));
    const added = state.items.filter(x => !state.publishedKeys.has(x.item_key)).length;
    const removed = [...state.publishedKeys].filter(k => !keys.has(k)).length;
    $('#publishDiff').textContent = state.publishedKeys.size
      ? 'เทียบกับเวอร์ชันที่ใช้อยู่: เพิ่ม ' + added + ' หัวข้อ · ลบ ' + removed + ' หัวข้อ · รวม ' + state.items.length + ' หัวข้อ'
      : 'เวอร์ชันแรก · ' + state.items.length + ' หัวข้อ';
    $('#dlgPublish').showModal();
  });
  $('#publishConfirm').addEventListener('click', async () => {
    const btn = $('#publishConfirm'); btn.disabled = true;
    try {
      await CS3.api('POST', '/api/forms/' + B.formId + '/publish', { note: $('#publishNote').value,
        effective_date: ($('#publishEff') || {}).value || '', approved_by_name: ($('#publishApprover') || {}).value || '' });
      state.dirty = false; location.href = B.detailUrl;
    } catch (e) { $('#dlgPublish').close(); showErrors(e.data && e.data.errors ? e.data.errors : [e.message]); }
    finally { btn.disabled = false; }
  });
  $('#btnDiscard').addEventListener('click', async () => {
    if (!confirm('ทิ้งฉบับร่างนี้? การแก้ไขทั้งหมดที่ยังไม่ Publish จะหายไป')) return;
    try { await CS3.api('POST', '/api/forms/' + B.formId + '/discard'); state.dirty = false; location.href = B.detailUrl; }
    catch (e) { showErrors([e.message]); }
  });

  async function savePreset(it) {
    const name = prompt('ตั้งชื่อประเภทใหม่ (ใช้ซ้ำได้ในทุกแบบฟอร์ม)\nเช่น "สถานะระบบ" = ' + (it.item_type === 'choice' ? (it.options || []).map(o => o.label).join(' / ') : (B.typeLabels[it.item_type] || '')));
    if (!name || !name.trim()) return;
    try {
      const r = await CS3.api('POST', '/api/item-presets', { name: name.trim(), item_type: it.item_type, options: it.options || [],
        unit: it.unit || '', min_value: it.min_value, max_value: it.max_value });
      B.presets = r.presets; renderEditor();
      alert('เพิ่มประเภท "' + name.trim() + '" แล้ว — เลือกใช้ได้ในช่อง "ประเภท" ของทุกหัวข้อ');
    } catch (err) { alert(err.message); }
  }

  $('#editor').addEventListener('click', e => {                 // v0.95 ใส่หัวข้อ/เครื่องหมายลงสูตร
    const it = state.items[state.selected]; if (!it) return;
    const r = e.target.closest('[data-calcref]'), o = e.target.closest('[data-calcop]');
    if (!r && !o) return;
    e.preventDefault();
    const ins = r ? '{' + keyOf(state.items[Number(r.dataset.calcref)]) + '}' : o.dataset.calcop;
    const inp = $('#editor [data-f="formula"]');
    const cur = it.formula || '', at = inp && document.activeElement === inp ? inp.selectionStart : cur.length;
    const pad = r || /^[a-z]/.test(ins) ? '' : ' ';
    it.formula = (cur.slice(0, at) + (cur && !/\s$/.test(cur.slice(0, at)) && at ? pad : '') + ins + (pad && o ? ' ' : '') + cur.slice(at)).replace(/\s{2,}/g, ' ');
    setDirty(true); renderList(); renderEditor();
    const n = $('#editor [data-f="formula"]'); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); }
  });

  async function load(keepSelection) {
    const data = await CS3.api('GET', '/api/forms/' + B.formId + '/draft');
    B.versionId = data.version_id;
    state.publishedKeys = new Set(data.published_keys || []);
    state.items = data.items.map(it => newItem(it));
    state.sections = {};
    (data.sections || []).forEach(sc => { state.sections[sc.name || ''] = { hint: sc.hint || '' }; });
    if (data.calendar) {
      state.calendar = data.calendar;
      if (data.calendar.freqs) {                   // JSON เรียง key ตามตัวอักษร → เรียงใหม่ ถี่ → ห่าง (ต้องตรงกับ itemfreq.freq_days)
        const fx = { '': -1, times: 0.4, shift: 0.5, day: 1, week: 7, month: 30.5 };
        const days = k => k in fx ? fx[k] : (m => m ? Number(m[2]) * { d: 1, w: 7, m: 30.5 }[m[1]] + 0.01 : 999)(/^([dwm]):(\d+)$/.exec(k));
        const all = Object.assign({}, data.calendar.freqs, { '': 'ทุกรอบ (ค่าเริ่มต้น)', times: 'ตามเวลาที่กำหนด…' });
        FREQS = {}; Object.keys(all).sort((a, b) => days(a) - days(b)).forEach(k => { FREQS[k] = all[k]; });
      }
    }
    state.schedules = data.schedules || [];
    if (!keepSelection) {
      state.selected = state.items.length ? 0 : -1;
      const want = new URLSearchParams(location.search).get('item');          // มาจากคำขอแก้ไข → เลือกหัวข้อนั้น
      const wi = want ? state.items.findIndex(x => x.item_key === want) : -1;
      if (wi >= 0) state.selected = wi;
    }
    else state.selected = Math.min(state.selected, state.items.length - 1);
    renderList(); renderEditor();
  }

  load(false).catch(e => { $('#list').innerHTML = '<div class="card errors">โหลดไม่สำเร็จ: ' + esc(e.message) + '</div>'; });
})();
