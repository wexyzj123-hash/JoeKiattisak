/* machine.js — v0.33 แดชบอร์ดรายเครื่อง (หน้าแนวโน้ม): การ์ดทุกหัวข้อ + กราฟเล็ก SVG + ตัวกรอง
 * สีสถานะใช้ token เดียวกับหน้าภาพรวม (เขียว/เหลือง/แดง/เทา) และมีข้อความกำกับเสมอ */
(function () {
  'use strict';
  const el = document.getElementById('ov-data');
  if (!el) return;
  const ov = JSON.parse(el.textContent);
  const grid = document.getElementById('mc-grid'), empty = document.getElementById('mc-empty');
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
  const num = (v) => v == null ? '–' : (Math.round(v * 1000) / 1000).toLocaleString('th-TH');
  const fmtTs = (s) => s ? s.slice(8, 10) + '/' + s.slice(5, 7) + ' ' + s.slice(11, 16) : '';
  const U_ = (p) => (window.U ? window.U(p) : p);
  const ST = {ok: 'ปกติ', warn: 'เฝ้าระวัง', ng: 'ผิดปกติ', none: 'ไม่มีข้อมูล'};
  const JT = {ok: 'ปกติ', warn: 'เตือน', ng: 'NG'};
  const TYPE = {number: 'ตัวเลข', counter: 'มิเตอร์สะสม', ok_ng: 'OK/NG', choice: 'ตัวเลือก', text: 'ข้อความ', photo: 'รูปถ่าย'};
  const params = new URLSearchParams(location.search);

  function spec(it) {
    const lo = it.min_value, hi = it.max_value;
    if (lo == null && hi == null) return 'ไม่กำหนดเกณฑ์';
    return lo == null ? '≤ ' + num(hi) : (hi == null ? '≥ ' + num(lo) : num(lo) + ' – ' + num(hi));
  }

  // กราฟเส้นเล็ก: แถบเขียว = ช่วงเกณฑ์, เส้นประเหลือง = ช่วงเตือน, ▲ แดง = NG, ◆ เหลือง = เตือน
  function lineSvg(it) {
    const pts = it.pts || [];
    if (!pts.length) return '<div class="mc-nodata">ไม่มีค่าที่ตรวจในช่วงนี้</div>';
    const W = 280, H = 70, P = 6;
    const vals = pts.map((p) => p[1]);
    const lims = [it.min_value, it.max_value, it.warn_low, it.warn_high].filter((v) => v != null);
    let mn = Math.min(...vals), mx = Math.max(...vals);
    const span0 = (mx - mn) || Math.abs(mx) * 0.1 || 1;
    lims.forEach((v) => { if (v >= mn - span0 * 1.5 && v <= mx + span0 * 1.5) { mn = Math.min(mn, v); mx = Math.max(mx, v); } });
    const pad = (mx - mn) * 0.1 || 1; mn -= pad; mx += pad;
    const x = (i) => pts.length === 1 ? W / 2 : P + i * (W - 2 * P) / (pts.length - 1);
    const y = (v) => H - P - (v - mn) / (mx - mn) * (H - 2 * P);
    const clampY = (v) => Math.max(0, Math.min(H, y(v)));
    let band = '';
    if (it.min_value != null || it.max_value != null) {
      const top = it.max_value != null ? clampY(it.max_value) : 0, bot = it.min_value != null ? clampY(it.min_value) : H;
      if (bot > top) band = '<rect x="0" y="' + top.toFixed(1) + '" width="' + W + '" height="' + (bot - top).toFixed(1) + '" class="mc-band"/>';
    }
    const warn = [it.warn_low, it.warn_high].filter((v) => v != null && v > mn && v < mx)
      .map((v) => '<line x1="0" x2="' + W + '" y1="' + y(v).toFixed(1) + '" y2="' + y(v).toFixed(1) + '" class="mc-warnline"/>').join('');
    const d = pts.map((p, i) => (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(p[1]).toFixed(1)).join(' ');
    const marks = pts.map((p, i) => {
      const cx = x(i).toFixed(1), cy = y(p[1]).toFixed(1);
      if (p[2] === 'ng') return '<path d="M' + cx + ' ' + (cy - 5) + ' l4.5 8 h-9z" class="mc-ng"><title>' + esc(fmtTs(p[0]) + ' · ' + num(p[1]) + ' NG') + '</title></path>';
      if (p[2] === 'warn') return '<rect x="' + (cx - 3.2) + '" y="' + (cy - 3.2) + '" width="6.4" height="6.4" transform="rotate(45 ' + cx + ' ' + cy + ')" class="mc-warn"/>';
      return '';
    }).join('');
    const last = pts[pts.length - 1];
    return '<svg class="mc-svg" viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" role="img" aria-label="แนวโน้ม ' + esc(it.name) + '">' +
      band + warn + '<path d="' + d + '" class="mc-line" vector-effect="non-scaling-stroke"/>' + marks +
      '<circle cx="' + x(pts.length - 1).toFixed(1) + '" cy="' + y(last[1]).toFixed(1) + '" r="3.2" class="mc-last ' + (last[2] || 'ok') + '"/></svg>';
  }
  // หัวข้อ OK/NG · ตัวเลือก: แถบผลแต่ละครั้ง (ซ้าย=เก่า → ขวา=ล่าสุด)
  function stripSvg(it) {
    const h = it.hist || [];
    if (!h.length) return '<div class="mc-nodata">ไม่มีผลตรวจในช่วงนี้</div>';
    return '<div class="mc-strip" role="img" aria-label="ผลตรวจ ' + h.length + ' ครั้งล่าสุด">' + h.map((r) =>
      '<span class="' + (r[2] || 'ok') + '" title="' + esc(fmtTs(r[0]) + ' · ' + r[1] + (r[2] === 'ng' ? ' (NG)' : '')) + '"></span>').join('') + '</div>';
  }

  function card(it) {
    const unit = it.unit ? ' <small>' + esc(it.unit) + '</small>' : '';
    const last = it.numeric ? (it.last_num == null ? '–' : num(it.last_num)) : (it.last || '–');
    const jb = it.last_j && JT[it.last_j] ? '<span class="badge b-' + (it.last_j === 'ng' ? 'ng' : it.last_j === 'warn' ? 'warn' : 'ok') + '">' + JT[it.last_j] + '</span>' : '';
    const stats = it.numeric
      ? '<span>เฉลี่ย <b>' + num(it.mean) + '</b></span><span>ต่ำ–สูง <b>' + num(it.min) + '–' + num(it.max) + '</b></span>' +
        (it.cpk != null ? '<span title="Cpk ≥1.33 ดี · 1–1.33 พอใช้ · <1 ต้องปรับปรุง">Cpk <b class="' + (it.cpk >= 1.33 ? 'text-ok' : it.cpk >= 1 ? 'text-warn' : 'text-ng') + '">' + it.cpk + '</b></span>' : '')
      : '<span>ผ่าน <b>' + (it.n ? Math.round(100 * (it.n - it.ng) / it.n) + '%' : '–') + '</b></span>';
    const href = it.numeric && it.n ? '?' + new URLSearchParams({form: ov.form.id, item: it.item_key, days: params.get('days') || '30', mode: params.get('mode') || 'spec'}) + '#deep'
      : (it.last_sub ? U_('/submissions/' + it.last_sub) : '');
    const tag = href ? 'a' : 'div';
    return '<' + tag + ' class="mc-card st-' + it.status + '" id="mci-' + esc(it.item_key) + '"' + (href ? ' href="' + esc(href) + '"' : '') + '>' +
      '<div class="mc-top"><span class="mc-st">' + ST[it.status] + '</span><span class="mc-type">' + esc(TYPE[it.type] || it.type) + (it.critical ? ' · วิกฤต' : '') + '</span></div>' +
      '<div class="mc-name">' + esc(it.name) + '</div>' +
      (it.section ? '<div class="mc-sec">📍 ' + esc(it.section) + '</div>' : '') +
      '<div class="mc-val"><b>' + esc(last) + '</b>' + (it.numeric ? unit : '') + ' ' + jb +
      (it.last_at ? '<span class="mc-at">' + fmtTs(it.last_at) + '</span>' : '') + '</div>' +
      (it.numeric ? '<div class="mc-spec">เกณฑ์ ' + spec(it) + (it.unit ? ' ' + esc(it.unit) : '') + '</div>' : '') +
      '<div class="mc-chart">' + (it.numeric ? lineSvg(it) : stripSvg(it)) + '</div>' +
      '<div class="mc-stats"><span>ตรวจ <b>' + it.n + '</b></span>' + stats +
      (it.ng ? '<span class="text-ng">NG <b>' + it.ng + '</b></span>' : '') + (it.warn ? '<span class="text-warn">เตือน <b>' + it.warn + '</b></span>' : '') +
      (it.alerts ? '<span class="text-ng">⚑ แจ้งเตือนค้าง <b>' + it.alerts + '</b></span>' : '') + '</div></' + tag + '>';
  }

  let F = 'all', SORT = 'status', Q = '';
  const order = {}; ov.order.forEach((k, i) => { order[k] = i; });
  function render() {
    let list = ov.items.slice();
    if (F === 'bad') list = list.filter((i) => i.status === 'ng' || i.status === 'warn');
    if (F === 'num') list = list.filter((i) => i.numeric);
    if (F === 'cat') list = list.filter((i) => !i.numeric);
    if (Q) list = list.filter((i) => (i.name + ' ' + i.section).toLowerCase().includes(Q));
    if (SORT === 'form') list.sort((a, b) => order[a.item_key] - order[b.item_key]);
    grid.innerHTML = list.map(card).join('');
    empty.hidden = list.length > 0;
  }
  const seg = (id, attr, set) => {
    const box = document.getElementById(id);
    box.addEventListener('click', (e) => {
      const a = e.target.closest('[' + attr + ']'); if (!a) return; e.preventDefault();
      box.querySelectorAll('[' + attr + ']').forEach((x) => x.classList.toggle('on', x === a)); set(a.getAttribute(attr)); render();
    });
  };
  seg('mc-filter', 'data-f', (v) => { F = v; });
  seg('mc-sort', 'data-s', (v) => { SORT = v; });
  document.getElementById('mc-q').addEventListener('input', (e) => { Q = e.target.value.trim().toLowerCase(); render(); });
  document.addEventListener('click', (e) => {
    const k = e.target.closest('[data-mcfilter]');
    if (k) { e.preventDefault(); const a = document.querySelector('#mc-filter [data-f="' + k.dataset.mcfilter + '"]'); if (a) a.click();
      document.getElementById('mc-items').scrollIntoView({behavior: 'smooth'}); }
    const j = e.target.closest('[data-mcjump]');
    if (j) { e.preventDefault(); const all = document.querySelector('#mc-filter [data-f="all"]'); if (all && F !== 'all') all.click();
      const c = document.getElementById('mci-' + j.dataset.mcjump);
      if (c) { c.scrollIntoView({behavior: 'smooth', block: 'center'}); c.classList.add('flash-hl'); setTimeout(() => c.classList.remove('flash-hl'), 1600); } }
  });
  render();
  // v0.99.18 กดแท่ง/วันที่ในตาราง = ดูเฉพาะวันนั้น (หน้าแนวโน้ม ?day=)
  const dayHref = (iso) => { const u = new URL(location.href); ['days', 'from', 'to'].forEach((k) => u.searchParams.delete(k));
    u.searchParams.set('day', iso); u.hash = ''; return u.pathname + u.search; };
  if (window.ECSCharts) ECSCharts.daily(document.getElementById('c-mc-daily'), ov.daily, {table: document.getElementById('t-mc-daily'),
    dayHref, onDay: (iso) => { if (typeof window.ECSNav === 'function') window.ECSNav(); location.href = dayHref(iso); }});
})();
