/* v0.99.16 สรุปเปลี่ยนกะแบบสไลด์ — ขึ้นเองครั้งแรกที่เปิดระบบในกะ (3 ชม. แรกของกะ · ครั้งเดียวต่อกะต่อเครื่อง)
   ปัดซ้าย/ขวา หรือปุ่มลูกศร · Esc / "ข้าม" ปิด · กดปุ่ม [data-brief-open] เพื่อดูอีกครั้ง */
(function () {
  'use strict';
  const host = document.querySelector('[data-brief]'); if (!host || !window.fetch) return;
  const U = window.U || ((p) => p);
  const esc = (x) => String(x == null ? '' : x).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let data = null, box = null, idx = 0, opener = null;
  const seenKey = (k) => 'brief_seen:' + k;
  function seen(k) { try { return localStorage.getItem(seenKey(k)) === '1'; } catch (e) { return false; } }
  function markSeen(k) { try { localStorage.setItem(seenKey(k), '1'); } catch (e) { /* */ } }
  const chip = (t, tone) => '<span class="bf-chip' + (tone ? ' t-' + tone : '') + '">' + esc(t) + '</span>';
  function slides(d) {
    const p = d.prev_sum;
    const s1 = '<p class="bf-k">กะก่อนหน้า ' + esc(d.prev) + '</p><h2>' + (p.carry_n || p.missed ? 'มีงานค้าง ' + (p.carry_n + p.missed) + ' รายการ' : 'กะก่อนหน้าเรียบร้อย') + '</h2>' +
      '<div class="bf-stats"><div><b>' + p.done + '</b><span>ตรวจแล้ว / ' + p.total + '</span></div><div><b class="' + (p.missed ? 't-ng' : '') + '">' + p.missed + '</b><span>ขาดตรวจ</span></div>' +
      '<div><b class="' + (p.carry_n ? 't-warn' : '') + '">' + p.carry_n + '</b><span>ส่งต่อมากะนี้</span></div><div><b class="' + (p.ng_new ? 't-ng' : '') + '">' + p.ng_new + '</b><span>NG / เตือนใหม่</span></div></div>' +
      (d.carry.length ? '<p class="bf-k">ยังตรวจได้ก่อนปิดรอบ</p><div class="bf-chips">' + d.carry.map((c) => chip(c.code + ' · ' + c.due + ' (ปิด ' + c.close + ')', 'warn')).join('') + '</div>' : '') +
      (d.missed.length ? '<p class="bf-k">ขาดตรวจ</p><div class="bf-chips">' + d.missed.map((c) => chip(c.code + ' · ' + c.due, 'ng')).join('') + '</div>' : '');
    const s2 = '<p class="bf-k">เครื่องที่หยุดอยู่ตอนนี้</p><h2>' + (d.down_n ? 'หยุดอยู่ ' + d.down_n + ' เครื่อง' : 'ทุกเครื่องเดินอยู่') + '</h2>' +
      (d.down.length ? '<ul class="bf-list">' + d.down.map((x) => '<li><b>' + esc(x.code) + '</b><span>' + esc(x.reason || x.name) + '</span><small>ตั้งแต่ ' + esc(x.since) + '</small></li>').join('') + '</ul>'
        : '<p class="bf-ok">ไม่มีเครื่องแจ้งหยุด — ตรวจได้ทุกรอบ</p>') + '<p class="bf-note">เครื่องหยุดไม่นับขาดตรวจ · เดินเครื่องแล้วกลับมาตรวจตามรอบ</p>';
    const s3 = '<p class="bf-k">ค่าที่ใกล้เกณฑ์ (ยังผ่าน แต่ควรดูก่อน NG)</p><h2>' + (d.trend.length ? 'เฝ้าดู ' + d.trend.length + ' หัวข้อ' : 'ไม่มีค่าที่ใกล้เกณฑ์') + '</h2>' +
      (d.trend.length ? '<ul class="bf-list">' + d.trend.map((x) => '<li><b>' + esc(x.eq) + '</b><span>' + esc(x.item) + ' · ล่าสุด ' + esc(x.last) + ' ' + esc(x.unit) + '</span>' +
        (x.eta != null ? '<small class="t-warn">ถึงค่า' + (x.side === 'max' ? 'สูงสุด' : 'ต่ำสุด') + ' ~' + (x.eta >= 1 ? Math.round(x.eta) : '<1') + ' วัน</small>' : '') + '</li>').join('') + '</ul>'
        : '<p class="bf-ok">ทุกหัวข้ออยู่กลางเกณฑ์</p>') +
      (d.ng_open.length ? '<p class="bf-k">แจ้งเตือนที่ยังเปิด</p><div class="bf-chips">' + d.ng_open.map((a) => chip((a.code ? a.code + ' · ' : '') + a.title, a.sev === 'critical' ? 'ng' : 'warn')).join('') + '</div>' : '');
    const f = d.first;
    const s4 = '<p class="bf-k">' + esc(d.shift) + '</p><h2>' + (f.due ? 'รอบแรก ' + esc(f.due) + ' · ' + f.codes.length + ' เครื่อง' : 'ไม่มีรอบตรวจในกะนี้') + '</h2>' +
      (f.due ? '<div class="bf-stats"><div><b>' + esc(f.deadline || '–') + '</b><span>ส่งก่อน</span></div><div><b>' + f.n_shift + '</b><span>รอบทั้งกะ</span></div><div><b>' + f.n_done + '</b><span>ตรวจแล้ว</span></div></div>' +
        '<div class="bf-chips">' + f.codes.map((c) => chip(c)).join('') + '</div>' : '') +
      '<p class="bf-note">' + esc(d.factories.join(' · ')) + '</p>';
    return [['งานค้างจากกะก่อน', s1], ['เครื่องหยุด', s2], ['ค่าใกล้เกณฑ์', s3], ['กะนี้', s4]];
  }
  function show(d) {
    opener = document.activeElement;
    const ss = slides(d);
    box = document.createElement('div'); box.className = 'bf';
    box.innerHTML = '<div class="bf-scrim"></div><div class="bf-card" role="dialog" aria-modal="true" aria-label="สรุปเปลี่ยนกะ">' +
      '<div class="bf-top"><span class="bf-title">สรุปเปลี่ยนกะ</span><div class="bf-dots" role="tablist">' + ss.map((s, i) => '<button type="button" role="tab" aria-label="' + esc(s[0]) + '" data-bf-go="' + i + '"></button>').join('') + '</div>' +
      '<button type="button" class="bf-skip" data-bf-close>ข้าม</button></div>' +
      '<div class="bf-track">' + ss.map((s, i) => '<section class="bf-slide" aria-label="' + esc(s[0]) + '" data-i="' + i + '">' + s[1] + '</section>').join('') + '</div>' +
      '<div class="bf-nav"><button type="button" class="bf-btn" data-bf-prev>ก่อนหน้า</button><button type="button" class="bf-btn bf-main" data-bf-next>ถัดไป</button></div></div>';
    document.body.appendChild(box); document.documentElement.classList.add('bf-open');
    requestAnimationFrame(() => box.classList.add('in'));
    idx = 0; go(0);
    box.addEventListener('click', (e) => {
      const t = e.target;
      if (t.closest('[data-bf-close]')) return close();
      if (t.closest('[data-bf-prev]')) return go(idx - 1);
      if (t.closest('[data-bf-next]')) return idx >= ss.length - 1 ? close() : go(idx + 1);
      const g = t.closest('[data-bf-go]'); if (g) go(+g.dataset.bfGo);
    });
    box.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { e.preventDefault(); close(); }
      if (e.key === 'ArrowRight') go(idx + 1); if (e.key === 'ArrowLeft') go(idx - 1);
      if (e.key === 'Tab') { const f = [...box.querySelectorAll('button')].filter((b) => !b.disabled); const a = f[0], z = f[f.length - 1];
        if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); } }
    });
    let x0 = null;
    box.querySelector('.bf-track').addEventListener('pointerdown', (e) => { x0 = e.clientX; });
    box.querySelector('.bf-track').addEventListener('pointerup', (e) => { if (x0 != null && Math.abs(e.clientX - x0) > 50) go(idx + (e.clientX < x0 ? 1 : -1)); x0 = null; });
    markSeen(d.key);
    box.querySelector('[data-bf-next]').focus();
  }
  function go(i) {
    const n = box.querySelectorAll('.bf-slide').length;
    idx = Math.max(0, Math.min(n - 1, i));
    box.querySelector('.bf-track').style.transform = 'translateX(' + (-idx * 100) + '%)';
    box.querySelectorAll('.bf-slide').forEach((s, k) => { s.classList.toggle('on', k === idx); s.setAttribute('aria-hidden', k === idx ? 'false' : 'true'); });
    box.querySelectorAll('[data-bf-go]').forEach((b, k) => { b.classList.toggle('on', k === idx); b.setAttribute('aria-selected', k === idx ? 'true' : 'false'); });
    box.querySelector('[data-bf-prev]').disabled = idx === 0;
    box.querySelector('[data-bf-next]').textContent = idx === n - 1 ? 'เริ่มงาน' : 'ถัดไป';
  }
  function close() {
    if (!box) return;
    const b = box; box = null; b.classList.remove('in'); document.documentElement.classList.remove('bf-open');
    setTimeout(() => b.remove(), 260);
    if (opener && opener.focus) opener.focus();
  }
  async function load() {
    if (data) return data;
    const r = await fetch(U('/api/shift-brief'), { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } });
    if (!r.ok) throw new Error(r.status);
    data = await r.json(); return data;
  }
  document.addEventListener('click', async (e) => {
    const t = e.target.closest && e.target.closest('[data-brief-open]'); if (!t) return;
    e.preventDefault(); try { show(await load()); } catch (err) { /* ออฟไลน์ */ }
  });
  if (host.dataset.brief === 'auto') {
    load().then((d) => { if (d.age_min >= 0 && d.age_min < 180 && !seen(d.key)) setTimeout(() => { if (!box) show(d); }, 700); }).catch(() => {});
  }
})();
