/* v0.87 Dashboard รายช่วงเวลา (ทุก 15 นาที) — โหลดรายวัน · ซ้อนตามระดับ · Heatmap · sparkline */
(function () {
  const el = document.getElementById('lv-data');
  if (!el || !window.echarts) return;
  const D = JSON.parse(el.textContent);
  const css = getComputedStyle(document.documentElement);
  const v = (n, f) => (css.getPropertyValue(n) || '').trim() || f;
  const bg = getComputedStyle(document.body).backgroundColor.match(/\d+/g) || [255, 255, 255];
  const dark = (0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]) < 128;
  const TXT = v('--text', dark ? '#e2e8f0' : '#0f172a'), MUTED = v('--muted', '#64748b'), GRID = v('--border', dark ? '#1f2a44' : '#e2e8f0');
  // ลำดับสีคงที่ (ตรวจแยกสีสำหรับตาบอดสีแล้ว) — สีตามตัวตน ไม่ตามอันดับ
  const PAL = dark ? ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#008300', '#9085e9', '#e66767']
                   : ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#4a3aa7', '#e34948'];
  const OTHER = dark ? '#64748b' : '#94a3b8';
  const SEQ = dark ? ['#0d366b', '#184f95', '#2a78d6', '#5598e7', '#9ec5f4'] : ['#cde2fb', '#86b6ef', '#3987e5', '#1c5cab', '#0d366b'];
  const fmt = (x, d) => x == null ? '–' : Number(x).toLocaleString('th-TH', {maximumFractionDigits: d == null ? (Math.abs(x) >= 100 ? 0 : 2) : d});
  const axis = {axisLine: {lineStyle: {color: GRID}}, axisLabel: {color: MUTED}, splitLine: {lineStyle: {color: GRID, opacity: .6}}};
  const base = {textStyle: {color: TXT, fontFamily: 'inherit'}, grid: {left: 56, right: 16, top: 36, bottom: 40}, animation: false};
  const charts = [];
  const mk = (id) => { const n = document.getElementById(id); if (!n) return null; const c = echarts.init(n, null, {renderer: 'canvas'}); charts.push(c); return c; };
  const rateTip = (val) => val == null ? '' : ` · ${fmt(val * D.rate)} ${D.rate_unit}`;

  // 1) โหลดรายวัน 15 นาที (แกนเดียว: หน่วยต่อช่วง)
  const load = mk('chLoad');
  if (load) load.setOption(Object.assign({}, base, {
    legend: {top: 0, right: 0, textStyle: {color: MUTED}, data: [D.day.slice(8) + '/' + D.day.slice(5, 7), D.cmp_day.slice(8) + '/' + D.cmp_day.slice(5, 7)]},
    tooltip: {trigger: 'axis', axisPointer: {type: 'line'}, valueFormatter: (x) => x == null ? 'ไม่มีค่า' : `${fmt(x)} ${D.unit}${rateTip(x)}`},
    xAxis: Object.assign({type: 'category', data: D.slots, axisLabel: {color: MUTED, interval: 7}}, {axisLine: axis.axisLine}),
    yAxis: Object.assign({type: 'value', name: D.unit, nameTextStyle: {color: MUTED}}, axis),
    series: [
      {name: D.day.slice(8) + '/' + D.day.slice(5, 7), type: 'bar', data: D.total, barCategoryGap: '20%',
       itemStyle: {color: D.meta.color, borderRadius: [3, 3, 0, 0]}},
      {name: D.cmp_day.slice(8) + '/' + D.cmp_day.slice(5, 7), type: 'line', data: D.cmp_total, showSymbol: false, connectNulls: false,
       lineStyle: {width: 2, color: OTHER, type: 'dashed'}, itemStyle: {color: OTHER}}]}));

  // 2) ซ้อนตามระดับถัดไป
  const st = mk('chStack');
  if (st) {
    let ci = 0;
    const ser = D.stack.map((s) => ({name: s.name, type: 'bar', stack: 'all', data: s.data, barCategoryGap: '10%',
      itemStyle: {color: s.other ? OTHER : (s.color || PAL[ci++ % PAL.length]), borderColor: dark ? '#111a2e' : '#ffffff', borderWidth: 0.5},
      emphasis: {focus: 'series'}}));
    st.setOption(Object.assign({}, base, {
      grid: {left: 56, right: 16, top: 56, bottom: 40},
      legend: {type: 'scroll', top: 0, textStyle: {color: MUTED}},
      tooltip: {trigger: 'axis', axisPointer: {type: 'shadow'}, order: 'valueDesc',
        valueFormatter: (x) => x ? `${fmt(x)} ${D.unit}${rateTip(x)}` : '–'},
      xAxis: {type: 'category', data: D.slots, axisLabel: {color: MUTED, interval: 7}, axisLine: axis.axisLine},
      yAxis: Object.assign({type: 'value', name: D.unit, nameTextStyle: {color: MUTED}}, axis), series: ser}));
  }

  // 3) Heatmap วัน × เวลา ทั้งเดือน
  const hm = mk('chHeat');
  if (hm) {
    hm.setOption(Object.assign({}, base, {
      grid: {left: 44, right: 16, top: 10, bottom: 70},
      tooltip: {formatter: (p) => `วันที่ ${D.heat_days[p.value[1]]} · ${D.slots[p.value[0]]}<br><b>${fmt(p.value[2])} ${D.unit}</b>${rateTip(p.value[2])}`},
      xAxis: {type: 'category', data: D.slots, axisLabel: {color: MUTED, interval: 7}, axisLine: axis.axisLine, splitArea: {show: false}},
      yAxis: {type: 'category', data: D.heat_days, inverse: true, axisLabel: {color: MUTED}, axisLine: axis.axisLine},
      visualMap: {min: 0, max: D.heat_max || 1, calculable: false, orient: 'horizontal', left: 'center', bottom: 8, itemWidth: 12, itemHeight: 220,
        text: [fmt(D.heat_max) + ' ' + D.unit + ' (มาก)', 'น้อย 0'], inRange: {color: SEQ}, textStyle: {color: MUTED}},
      series: [{type: 'heatmap', data: D.heat, emphasis: {itemStyle: {borderColor: TXT, borderWidth: 1}}}]}));
    hm.on('click', (p) => {
      const u = new URL(location.href);
      u.searchParams.set('day', D.month.slice(0, 8) + D.heat_days[p.value[1]]);
      location.href = u.toString();
    });
  }

  // sparkline รายชั่วโมงในตาราง (SVG เล็ก)
  document.querySelectorAll('.lv-spark').forEach((n) => {
    const h = JSON.parse(n.dataset.h || '[]'), mx = Math.max(...h, 0);
    if (!mx) { n.textContent = '–'; return; }
    const w = 96, H = 22, bw = w / 24;
    n.innerHTML = `<svg width="${w}" height="${H}" viewBox="0 0 ${w} ${H}" aria-hidden="true">` +
      h.map((x, i) => `<rect x="${(i * bw + .5).toFixed(1)}" y="${(H - (x / mx) * H).toFixed(1)}" width="${(bw - 1).toFixed(1)}" height="${((x / mx) * H).toFixed(1)}" rx="1" fill="${D.meta.color}"><title>${String(i).padStart(2, '0')}:00 ${fmt(x)} ${D.unit}</title></rect>`).join('') + '</svg>';
  });

  window.addEventListener('resize', () => charts.forEach((c) => c.resize()));
  // วันนี้: รีเฟรชทุก 5 นาที (ค่าจาก SCADA เข้ามาเรื่อย ๆ)
  const today = new Date(); const iso = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
  if (D.day === iso) setTimeout(() => location.reload(), 5 * 60 * 1000);
})();
