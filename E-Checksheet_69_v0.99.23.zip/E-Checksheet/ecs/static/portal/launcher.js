/* เชื่อม E-Checksheet เข้ากับหน้า UT-CMMS (portal.py แทรกไฟล์นี้ให้ ไม่ต้องแก้ไฟล์ของ UT-CMMS)

   - เมนู "E-Checksheet" ใน sidebar ของ UT-CMMS ใช้ระบบใหม่แทนโมดูลเช็คชีตเดิมทั้งหมด
     (ข้อมูลเช็คชีตเดิมย้ายเข้าระบบใหม่ด้วย python portal.py --import-legacy --history)
     หน้าในเมนูแสดงตัวเลขแจ้งเตือนค้าง / รอบตรวจที่ต้องทำ และปุ่มไปหน้าต่าง ๆ ของ E-Checksheet (login อัตโนมัติ)
   - ตัวเลขแดงบนเมนู = แจ้งเตือนค้างใน E-Checksheet
   - หน้าอื่นที่ไม่มี sidebar ของ UT-CMMS → ปุ่มลอยมุมซ้ายล่าง (ไม่ชนปุ่มผู้ช่วย AI มุมขวาล่าง) */
(function () {
  if (window.__ecsLauncher) return;
  window.__ecsLauncher = true;
  const me = document.currentScript;
  const BASE = (me && me.dataset.base) || '/echeck';
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let data = null, timer = null;

  // ───── สไตล์ (ใช้ตัวแปรสีของธีม UT-CMMS จึงเข้ากับทุกธีม) ─────
  const css = document.createElement('style');
  css.textContent = `
  .ecs-count{margin-left:auto;min-width:20px;height:20px;padding:0 6px;border-radius:10px;background:#dc2626;color:#fff;font-size:11px;font-weight:700;display:inline-grid;place-items:center}
  .ecs-hub .ecs-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px;margin-bottom:18px}
  .ecs-hub .ecs-kpi{background:var(--bg-card);border:1px solid var(--border);border-radius:10px;padding:16px}
  .ecs-hub .ecs-kpi b{display:block;font-size:30px;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1.2}
  .ecs-hub .ecs-kpi span{font-size:12px;color:var(--text-m)}
  .ecs-hub .ecs-links{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
  .ecs-hub a.ecs-link{display:flex;gap:12px;align-items:center;padding:14px 16px;border-radius:10px;border:1px solid var(--border);background:var(--bg-card);color:var(--text);text-decoration:none;min-height:64px}
  .ecs-hub a.ecs-link:hover{border-color:var(--primary);background:var(--bg-hover)}
  .ecs-hub a.ecs-link.pri{background:linear-gradient(135deg,var(--gradient-start),var(--gradient-end));color:#fff;border-color:transparent}
  .ecs-hub a.ecs-link i{font-style:normal;font-size:22px;width:28px;text-align:center}
  .ecs-hub a.ecs-link div{display:flex;flex-direction:column}.ecs-hub a.ecs-link small{font-size:11px;opacity:.75}
  .ecs-hub .ecs-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px}
  .ecs-hub .ecs-head h3{margin:0}
  #ecs-fab{position:fixed;left:16px;bottom:16px;z-index:890;display:none;align-items:center;gap:8px;padding:10px 14px;border-radius:999px;background:#1d4ed8;color:#fff;font:600 14px/1.2 inherit;text-decoration:none;box-shadow:0 6px 20px rgba(15,23,42,.28)}
  @media(max-width:768px){#ecs-fab{bottom:calc(86px + env(safe-area-inset-bottom))}}`;
  document.head.appendChild(css);

  // ───── ข้อมูลตัวเลขจาก E-Checksheet ─────
  async function refresh() {
    try {
      const r = await fetch(BASE + '/api/portal/badge', { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } });
      data = r.ok ? await r.json() : null;
    } catch (e) { data = null; }
    decorate();
    clearTimeout(timer);
    timer = setTimeout(refresh, data && data.logged_in ? 60000 : 20000);
    return data;
  }

  // ───── ตัวเลขบนเมนู sidebar / ปุ่มลอยสำรอง ─────
  function decorate() {
    const ok = !!(data && data.logged_in);
    const btn = document.querySelector('#sidebar-nav button[data-page="checksheet"]');
    if (btn) {
      btn.title = 'E-Checksheet (ระบบตรวจเช็คออนไลน์ใหม่)';
      let c = btn.querySelector('.ecs-count');
      const n = ok ? (data.alerts || 0) : 0;
      if (n && !c) { c = document.createElement('span'); c.className = 'ecs-count'; btn.appendChild(c); }
      if (c) { c.hidden = !n; c.textContent = n > 99 ? '99+' : n; c.setAttribute('aria-label', 'แจ้งเตือนค้าง ' + n); }
    }
    let fab = document.getElementById('ecs-fab');
    const needFab = ok && !document.getElementById('sidebar-nav');
    if (needFab && !fab) {
      fab = document.createElement('a');
      fab.id = 'ecs-fab'; fab.href = BASE + '/';
      fab.textContent = 'E-Checksheet';
      document.body.appendChild(fab);
      const en = document.createElement('a');                 // v0.62 ปุ่ม Energy Data ข้างกัน
      en.id = 'ecs-fab-en'; en.href = BASE + '/energy/'; en.textContent = '⚡ Energy Data';
      en.style.cssText = 'position:fixed;left:150px;bottom:16px;z-index:890;display:inline-flex;padding:10px 14px;border-radius:999px;background:#0f766e;color:#fff;font:600 14px/1.2 inherit;text-decoration:none;box-shadow:0 6px 20px rgba(15,23,42,.28)';
      document.body.appendChild(en);
    }
    if (fab) fab.style.display = needFab ? 'inline-flex' : 'none';
    const fen = document.getElementById('ecs-fab-en'); if (fen) fen.style.display = needFab ? 'inline-flex' : 'none';
  }

  // ───── หน้าศูนย์รวม E-Checksheet ภายใน UT-CMMS ─────
  function links(role) {
    const L = (href, ic, title, sub, pri) => `<a class="ecs-link${pri ? ' pri' : ''}" href="${BASE}${href}"><i>${ic}</i><div><b>${title}</b><small>${sub}</small></div></a>`;
    const field = [L('/m/', '📋', 'งานตรวจของฉันวันนี้', 'โหมดตรวจบนมือถือ · ใช้ได้แม้สัญญาณหลุด', true),
                   L('/m/scan', '⌗', 'สแกน QR ที่เครื่อง', 'เปิดฟอร์มของเครื่องทันที')];
    const office = [L('/dashboard', '📊', 'ภาพรวมการตรวจเช็ค', '3 โรงงาน · ผังพื้นที่ · กราฟ', role !== 'technician'),
                    L('/alerts', '🔔', 'แจ้งเตือน / ความผิดปกติ', 'รับทราบ · มอบหมาย · ปิดงาน'),
                    L('/actions', '🛠️', 'งานแก้ไข (CAPA)', 'ติดตามจนปิดงาน'),
                    L('/rounds', '⏱️', 'ติดตามรอบตรวจ', 'ตรงเวลา · เลยกำหนด · ขาดตรวจ'),
                    L('/trends', '📈', 'แนวโน้ม / Control Chart', 'ค่าตรวจย้อนหลังเทียบเกณฑ์'),
                    L('/reports', '📄', 'รายงาน', 'รายวัน / สัปดาห์ / เดือน · PDF · Excel'),
                    L('/energy/', '⚡', 'Energy Data', 'มิเตอร์ไฟฟ้า · ลม · น้ำ · น้ำ RO · ชั่วโมงเครื่อง')];
    if (role === 'technician') return field.concat(office.slice(1, 3), [office[6]]);
    if (role === 'admin' || role === 'supervisor' || role === 'manager') return office.concat([L('/approvals', '✅', 'รออนุมัติ', 'ตรวจผลและอนุมัติ/ตีกลับ'), L('/forms', '🧩', 'แบบฟอร์ม / รอบตรวจ', 'สร้างและแก้ไขเช็คชีต')], field);
    return [office[0], office[1], office[5], office[6]];
  }

  async function renderHub(pc) {
    const d = await refresh();
    const role = (typeof state !== 'undefined' && state.user && state.user.role) || '';
    if (!d || !d.logged_in) {
      pc.innerHTML = `<div class="card"><h3>E-Checksheet</h3>
        <p style="color:var(--text-m);margin-bottom:14px">ยังเชื่อมบัญชีกับ E-Checksheet ไม่ได้ (บัญชีอาจถูกปิดสิทธิ์ใน E-Checksheet) — ติดต่อผู้ดูแลระบบ หรือเปิดหน้าเข้าสู่ระบบของ E-Checksheet</p>
        <div class="btn-group"><a class="btn btn-primary" href="${BASE}/login">เปิด E-Checksheet</a></div></div>`;
    } else {
      const kpi = (n, label, color) => `<div class="ecs-kpi"><b style="color:${n ? color : 'var(--success)'}">${n}</b><span>${label}</span></div>`;
      pc.innerHTML = `<div class="ecs-hub">
        <div class="ecs-head"><div><h3 style="font-size:18px">E-Checksheet · ระบบตรวจเช็คออนไลน์</h3>
          <div style="font-size:12px;color:var(--text-d)">เข้าใช้งานในชื่อ ${esc(d.name)} · ใช้บัญชีเดียวกับ UT-CMMS</div></div></div>
        <div class="ecs-kpis">${kpi(d.alerts || 0, 'แจ้งเตือนค้าง', 'var(--danger)')}${kpi(d.rounds || 0, 'รอบตรวจถึงกำหนด / เลยกำหนด', 'var(--accent)')}${kpi(d.unread || 0, 'การแจ้งเตือนที่ยังไม่อ่าน', 'var(--primary)')}</div>
        <div class="ecs-links">${links(role).join('')}</div></div>`;
    }
  }

  function hookMenu() {
    // เมนู checksheet ของ UT-CMMS เรียก renderChecksheet(pc) → ใช้หน้าของระบบใหม่แทนโมดูลเดิม
    if (typeof window.renderChecksheet !== 'function' || !window.renderChecksheet.__ecs) {
      const hub = function (pc) { return renderHub(pc); };
      hub.__ecs = true;
      window.renderChecksheet = hub;
    }
  }

  function start() {
    hookMenu();
    const app = document.getElementById('app') || document.body;
    new MutationObserver(decorate).observe(app, { childList: true });   // SPA วาด sidebar ใหม่ทุกครั้งที่เปลี่ยนหน้า
    refresh();
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') refresh(); });
  // UT-CMMS login โดยไม่รีโหลดหน้า → ตรวจใหม่หลังผู้ใช้กดอะไรสักอย่าง
  let soon = null;
  document.addEventListener('click', () => { if (!(data && data.logged_in) && !soon) soon = setTimeout(() => { soon = null; refresh(); }, 1500); }, true);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
