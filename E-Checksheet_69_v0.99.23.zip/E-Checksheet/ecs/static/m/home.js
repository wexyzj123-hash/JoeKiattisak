/* หน้า "งานของฉัน" — แสดงงานวันนี้ (ออนไลน์: จากเซิร์ฟเวอร์ / ออฟไลน์: จากข้อมูลล่าสุดในเครื่อง)
   และโหลดแบบฟอร์มของงานวันนี้เก็บไว้ล่วงหน้า เพื่อให้กรอกได้แม้ไม่มีสัญญาณ */
(function () {
  'use strict';
  const { esc, fmt, fmtDate } = ECS;
  const $ = s => document.querySelector(s);
  const GROUPS = [
    ['returned', 'ตีกลับ — ต้องแก้ไข', 'sb-ret'],
    ['queued', 'บันทึกแล้ว · ยังไม่ถึงระบบ (รอส่ง)', 'sb-queue'],
    ['overdue', 'เลยกำหนด', 'sb-late'],
    ['due', 'ถึงเวลาตรวจ', 'sb-wait'],
    ['upcoming', 'รอรอบ (ถัดไปวันนี้)', 'sb-wait'],
    ['missed', 'ขาดตรวจ', 'sb-miss'],
    ['done', 'ตรวจแล้ววันนี้', 'sb-done'],
    ['skipped', 'เครื่องหยุด — ไม่ต้องตรวจ', 'sb-down'],
    ['other', 'กะอื่นรับผิดชอบ (ตามตารางกะ)', 'sb-other'],
  ];
  // v0.60 สีสถานะ: ตรวจแล้ว=เขียว · รอรอบ/ถึงเวลา=เหลือง · เลยกำหนด=ส้ม · ขาดตรวจ=แดง · เครื่องหยุด=เทา · ตีกลับ=ม่วง
  const ST = {
    done: ['sb-done', '✓ ตรวจแล้ว'], due: ['sb-wait', '● ถึงเวลาตรวจ'], upcoming: ['sb-wait', '⏳ รอรอบ'],
    overdue: ['sb-late', '⏰ เลยกำหนด'], missed: ['sb-miss', '✕ ขาดตรวจ'], skipped: ['sb-down', '⛔ เครื่องหยุด'],
    returned: ['sb-ret', '↩ ตีกลับ'], other: ['sb-other', '👥 กะอื่น'], queued: ['sb-queue', '📤 รอส่ง'],
  };
  const stPill = k => ST[k] ? `<span class="st-pill ${ST[k][0]}">${ST[k][1]}</span>` : '';
  // หลอดสถานะงานวันนี้ (เต็มความกว้าง) + ป้ายจำนวน กดแล้วแสดงทั้งหมด
  function statusBar(g, cnt) {
    const segs = [['done', 'ตรวจแล้ว', cnt(['done'])], ['queue', 'รอส่งถึงระบบ', cnt(['queued'])], ['wait', 'รอรอบ / ถึงเวลา', cnt(['due', 'upcoming'])],
      ['late', 'เลยกำหนด', cnt(['overdue'])], ['ret', 'ตีกลับ', cnt(['returned'])], ['miss', 'ขาดตรวจ', cnt(['missed'])],
      ['down', 'เครื่องหยุด', cnt(['skipped'])]].filter(x => x[2]);
    const tot = segs.reduce((a, x) => a + x[2], 0);
    if (!tot) return '';
    const done = cnt(['done']), pct = Math.round(100 * done / tot), qd = cnt(['queued']);
    return `<div class="m-stat" data-mode="all" role="button" aria-label="สถานะงานวันนี้"><div class="m-stat-h"><b>สถานะงานวันนี้</b><span>ถึงระบบแล้ว <b>${done}</b>/${tot} · <b class="${pct >= 95 ? 'ok' : ''}">${pct}%</b>${qd ? ` · <b class="q">รอส่ง ${qd}</b>` : ''}</span></div>
      <div class="stbar m-stbar">${segs.map(([k, t, n]) => `<span class="st-${k}" style="flex:${n}" title="${t} ${n}">${100 * n / tot >= 8 ? n : ''}</span>`).join('')}</div>
      <div class="stleg">${segs.map(([k, t, n]) => `<span><i class="st-${k}"></i>${t} <b>${n}</b></span>`).join('')}</div></div>`;
  }
  // v0.50 ภาษากลาง: คำ/สี/ไอคอนเดียวกับเว็บ (ecs/terms.py)
  const TERMS = window.ECS_T || {};
  const term = (g, k) => { const v = (TERMS[g] || {})[k]; return v ? `<span class="badge ${v[1]}">${v[2]} ${esc(v[0])}</span>` : esc(k || ''); };

  try { sessionStorage.removeItem('m_offmode'); } catch (e) { /* */ }   // กลับหน้างานของฉัน = ออกจากโหมดออฟไลน์
  $('#today').textContent = new Date().toLocaleDateString('th-TH', { weekday: 'long', day: 'numeric', month: 'long' });

  function card(r, key) {
    const loc = key === 'done' ? null : LOCAL.map[r.form_id + ':' + r.id];
    if (key === 'queued') return queuedCard(r, loc);
    const open = !['done', 'missed', 'skipped'].includes(key);
    const href = open ? U(`/m/fill#f=${r.form_id}&r=${r.id}`) : (r.submission_id ? U(`/submissions/${r.submission_id}`) : '#');
    const eq = r.eq_code ? `<span class="mono">${esc(r.eq_code)}</span> · ` : '';
    let meta = `${eq}${esc(r.area_name || r.factory_name || '')}`;
    let right = '';
    if (key === 'done') right = (r.ng_count ? `<span class="badge b-ng">NG ${r.ng_count}</span>` : '<span class="badge b-ok">ปกติ</span>') + '<span class="m-arrived">✓ ถึงระบบแล้ว</span>';
    else if (key === 'returned') meta += `<div class="m-note">เหตุผล: ${esc(r.approval_note || '-')}</div>`;
    else if (key === 'skipped') { meta += `<div class="small muted">⛔ ${esc(r.down_reason || 'เครื่องหยุด')}</div>`; right = '<span class="badge b-none">⛔ เครื่องหยุด</span>'; }
    else if (key === 'other') { meta += `<div class="m-owner">👥 ${esc(r.owners || 'ช่างกะอื่น')}</div>`; right = '<span class="badge b-none">กะอื่น</span>'; }
    if (r.uncovered) meta += '<div class="m-flag">⚠ ไม่มีช่างเข้ากะช่วงนี้ — ใครว่างช่วยตรวจ</div>';
    if (r.carry) meta += '<div class="m-flag carry">↪ ค้างจากกะก่อน</div>';
    const time = key === 'done' ? `ส่ง ${fmt(r.finished_at)}` : `${fmt(r.due_at)}–${fmt(r.deadline_at)}`;
    if (['due', 'overdue', 'upcoming', 'other'].includes(key) && r.status !== 'missed') right = leftChip(r, key === 'other' ? (T(r.due_at) > Date.now() ? 'upcoming' : T(r.deadline_at) < Date.now() ? 'overdue' : 'due') : key) + right;      // v0.48 เหลือเวลา / เลยมา
    if (r.more) meta += `<div class="small muted">+${r.more} รอบซ้อนของเครื่องนี้ (ตรวจครั้งเดียวพอ)</div>`;
    if (loc && loc.state === 'draft') meta += draftChip(loc.d);                         // v0.95 กรอกค้างไว้
    if (key !== 'skipped' && key !== 'other') right = stPill(key) + right;             // v0.60 ป้ายสถานะสี
    else right = stPill(key) + right.replace(/<span class="badge b-none">[^<]*<\/span>/, '');
    const a = `<a class="m-task ${key}" href="${href}">
      <div class="m-task-main"><div class="m-task-title">${esc(r.form_name)}</div><div class="m-task-meta">${meta}</div></div>
      <div class="m-task-side"><div class="m-task-time">${time}</div>${right}</div></a>`;
    const btn = eqBtn(r.equipment_id, r.eq_code, r.eq_name, key === 'skipped' || r.run_status === 'down',
      r.down_reason, r.down_since, ['returned', 'overdue', 'due', 'upcoming', 'skipped', 'other', 'missed'].includes(key));   // v0.53 ทุกการ์ด
    return btn ? `<div class="m-twrap">${a}${btn}</div>` : a;
  }
  // v0.48 เวลาที่เหลือ / เลยมา — แยกงานด่วนได้ในพริบตา
  const T = s => s ? new Date(String(s).replace(' ', 'T')).getTime() : NaN;
  function dur(ms) {
    const m = Math.max(0, Math.round(ms / 60000));
    if (m >= 2880) return `${Math.floor(m / 1440)} วัน`;
    return m < 60 ? `${m} นาที` : `${Math.floor(m / 60)} ชม.${m % 60 ? ' ' + (m % 60) + ' น.' : ''}`;
  }
  function leftChip(r, key) {
    const now = Date.now();
    if (key === 'overdue') return `<span class="m-left late">เลยมา ${dur(now - T(r.deadline_at))}</span>`;
    if (key === 'upcoming') return `<span class="m-left soon">อีก ${dur(T(r.due_at) - now)}</span>`;
    const left = T(r.deadline_at) - now;
    return `<span class="m-left ${left < 30 * 60000 ? 'hurry' : ''}">เหลือ ${dur(left)}</span>`;
  }
  // ── v0.95 สถานะการส่งข้อมูลในเครื่อง: แบบร่าง (ยังไม่กดส่ง) · รอส่ง (กดส่งแล้ว ยังไม่ถึงระบบ) · ส่งไม่ผ่าน ──
  let LOCAL = { map: {}, drafts: [], pending: 0, rejected: 0, items: [] };
  const hasVal = a => a && (String(a.value == null ? '' : a.value).trim() !== '' || (a.photos || []).length);
  async function loadLocal() {
    try {
      const [st, keys, vals] = await Promise.all([ECS.status(), ECS.drafts.keys(), ECS.drafts.all()]);
      const map = {}, drafts = [];
      for (const it of st.items) map[it.payload.form_id + ':' + (it.payload.round_id || 0)] = { state: it.status === 'rejected' ? 'rejected' : 'queued', item: it };
      (keys || []).forEach((k, i) => {
        const d = (vals || [])[i], m = /^d:(\d+):(\d+)$/.exec(String(k));
        if (!d || !m) return;
        const n = Object.values(d.answers || {}).filter(hasVal).length;
        if (!n || map[m[1] + ':' + m[2]]) return;
        const x = { key: k, form_id: Number(m[1]), round_id: Number(m[2]) || null, n, meta: d.meta || {}, at: d.updated_at || d.scanned_at, round: d.round || null };
        drafts.push(x); map[m[1] + ':' + m[2]] = { state: 'draft', d: x };
      });
      drafts.sort((a, b) => String(b.at).localeCompare(String(a.at)));
      LOCAL = { map, drafts, pending: st.pending, rejected: st.rejected, items: st.items };
    } catch (e) { /* IndexedDB ใช้ไม่ได้ → แสดงตามข้อมูลเซิร์ฟเวอร์ */ }
  }
  function draftChip(d) {
    const m = d.meta || {}, tot = m.n_req || 0, got = tot ? Math.min(m.n_done || 0, tot) : d.n;
    return `<div class="m-draftchip">✏️ กรอกค้างไว้ ${tot ? `${got}/${tot} ข้อ` : `${got} ข้อ`} · ยังไม่ได้กดส่ง${m.ng ? ` · <b>NG ${m.ng}</b>` : ''}</div>`;
  }
  function queuedCard(r, loc) {
    const it = loc && loc.item, bad = loc && loc.state === 'rejected';
    const href = bad ? (it.edit_url ? U(it.edit_url) : U('/m/fill') + '#o=' + it.client_uuid) : '#outbox';
    return `<a class="m-task ${bad ? 'returned' : 'queued'}" href="${href}"><div class="m-task-main">
      <div class="m-task-title">${esc(r.form_name)}</div>
      <div class="m-task-meta">${r.eq_code ? `<span class="mono">${esc(r.eq_code)}</span> · ` : ''}${esc(r.area_name || r.factory_name || '')}
        <div class="small">${bad ? '<b class="text-ng">ส่งไม่ผ่าน — แตะเพื่อแก้ไขแล้วส่งใหม่</b>' : `กดส่งเมื่อ ${fmt(it && (it.payload.finished_at || it.created_at))} · เก็บไว้ในเครื่อง รอสัญญาณ`}</div></div></div>
      <div class="m-task-side"><div class="m-task-time">รอบ ${fmt(r.due_at)}</div>${bad ? '<span class="st-pill sb-miss">⚠ ส่งไม่ผ่าน</span>' : stPill('queued')}</div></a>`;
  }
  // ย้ายรอบที่กดส่งแล้วแต่ยังไม่ถึงระบบ ไปกลุ่ม “รอส่ง” — ไม่นับเป็นงานค้าง และไม่ให้เปิดกรอกซ้ำ
  function withLocal(data) {
    const g = {}, out = Object.assign({}, data, { groups: g });
    g.queued = [];
    for (const [k, list] of Object.entries(data.groups || {})) {
      g[k] = g[k] || [];
      for (const r of list) {
        const loc = LOCAL.map[r.form_id + ':' + r.id];
        if (k !== 'done' && k !== 'skipped' && loc && loc.state !== 'draft') g.queued.push(r); else g[k].push(r);
      }
    }
    return out;
  }

  // ข้อมูลในเครื่อง (ออฟไลน์): ปรับสถานะตามเวลาปัจจุบัน — รอบที่ปิดแล้วไม่ขึ้นเป็นงาน
  function retime(data) {
    const now = Date.now(), g = data.groups, out = Object.assign({}, data, { groups: {} });
    Object.keys(g).forEach(k => { out.groups[k] = []; });
    for (const [k, list] of Object.entries(g)) for (const r of list) {
      let key = k;
      if (['due', 'upcoming', 'overdue'].includes(k)) {
        if (T(r.close_at) <= now) key = 'missed';
        else if (T(r.deadline_at) <= now) key = 'overdue';
        else if (T(r.due_at) - 120 * 60000 <= now) key = 'due';
      }
      (out.groups[key] = out.groups[key] || []).push(r);
    }
    return out;
  }

  // v0.38 ปุ่มแจ้งเครื่องหยุด/PM หรือกลับมาเดิน (ทำงานผ่าน m/down.js)
  function eqBtn(id, code, name, down, reason, since, show) {
    if (!id || !show) return '';
    const j = esc(JSON.stringify({ id, code: code || '', name: name || '', reason: reason || '', since: since || '' }));
    return down ? `<button type="button" class="m-eqbtn run" data-eqrun="${j}">✅ เครื่องเดินแล้ว</button>`
      : `<button type="button" class="m-eqbtn" data-eqdown="${j}">⛔ เครื่องหยุด / PM</button>`;
  }
  function downSection(list) {
    const rows = (list || []).filter(d => !F.fac || String(d.factory_id || '') === F.fac);
    if (!rows.length) return '';
    return `<h2 class="m-h"><span class="badge b-warn">${rows.length}</span> ⛔ เครื่องหยุด / PM ตอนนี้</h2>` + rows.map(d =>
      `<div class="m-twrap"><div class="m-task m-downrow"><div class="m-task-main"><div class="m-task-title"><span class="mono">${esc(d.code)}</span> ${esc(d.name || '')}</div>
        <div class="m-task-meta">${esc(d.reason || '')}<div class="small muted">ตั้งแต่ ${fmt(d.since, true)}${d.by ? ' · ' + esc(d.by) : ''}${d.until ? ` · คาดว่าเดิน ${fmt(d.until, true)}` : ''}</div></div></div>
        <div class="m-task-side">${d.late ? '<span class="badge b-ng">เกินกำหนด</span>' : '<span class="badge b-warn">หยุด</span>'}</div></div>
        ${eqBtn(d.id, d.code, d.name, true, d.reason, d.since, true)}</div>`).join('');
  }

  // ── ตัวกรอง โรงงาน / หมวดหมู่ (จำไว้ในเครื่อง) + แท็บ งานวันนี้ / แบบฟอร์มทั้งหมด ──
  let F = { fac: '', cat: '' }, TAB = 'today', lastTasks = null, lastCache = false, formsList = null, search = '', MODE = 'now';
  // v0.49 งานถัดไป: ตีกลับ → เลยกำหนด (ค้างนานสุดก่อน) → ถึงเวลา (ใกล้หมดเวลาก่อน)
  function nextTask(g) {
    const by = k => (g[k] || []).filter(match).slice().sort((a, b) => T(a.deadline_at) - T(b.deadline_at));
    const r = by('returned')[0]; if (r) return [r, 'returned'];
    const o = by('overdue')[0]; if (o) return [o, 'overdue'];
    const d = by('due')[0]; return d ? [d, 'due'] : null;
  }
  function nextBar(g) {
    const n = nextTask(g);
    if (!n) return '';
    const [r, k] = n;
    const when = k === 'returned' ? 'ถูกตีกลับ — แก้ไขแล้วส่งใหม่' : k === 'overdue' ? `เลยกำหนดมา ${dur(Date.now() - T(r.deadline_at))}` : `เหลือ ${dur(T(r.deadline_at) - Date.now())}`;
    return `<a class="m-next ${k === 'overdue' ? 'late' : k === 'returned' ? 'ret' : ''}" href="${U(`/m/fill#f=${r.form_id}&r=${r.id}`)}">
      <div><div class="k">งานถัดไป · รอบ ${fmt(r.due_at)}</div><div class="t">${r.eq_code ? esc(r.eq_code) + ' · ' : ''}${esc(r.form_name)}</div>
      <div class="s">${esc(r.area_name || r.factory_name || '')} · ${when}</div></div><span class="go">เริ่มตรวจ ›</span></a>`;
  }
  // v0.50 กะของฉัน (ตารางกะ UT-CMMS) + โรงงานที่รับผิดชอบ
  function dutyBar(d) {
    if (!d) return '';
    const off = !d.on_now;
    const fac = d.all_factories ? 'ทุกโรงงาน' : d.factories.map(esc).join(', ');
    const now = d.on_now ? '<span class="badge b-ok">อยู่ในกะ</span>' : '<span class="badge b-none">นอกเวลากะ</span>';
    return `<div class="m-duty ${off ? 'off' : ''}"><div class="m-duty-k">กะของฉันวันนี้</div>
      <div class="m-duty-t">${d.icon} ${esc(d.label)}${d.window ? ` <small>${esc(d.window)}</small>` : ''} ${now}</div>
      <div class="m-duty-s">🏭 ${fac} · พรุ่งนี้ ${d.tomorrow_icon} ${esc(d.tomorrow)}${d.filter ? '' : ' · แสดงงานทุกกะ'}</div></div>`;
  }
  // v0.50 NG ที่ฉันแจ้ง — เห็นว่าใครรับเรื่อง ทำอะไรไปแล้ว
  function myNg(list) {
    if (!list || !list.length) return '';
    return `<h2 class="m-h"><span class="badge b-ng">${list.length}</span> 🔧 NG ที่ฉันแจ้ง <small class="muted">ติดตามจนปิดงาน</small></h2>` +
      list.map(a => {
        let who = '';
        if (a.status === 'open') who = 'ยังไม่มีผู้รับเรื่อง';
        else if (a.ack_name) who = `รับเรื่องโดย ${esc(a.ack_name)}${a.owner_name && a.owner_name !== a.ack_name ? ' · ผู้แก้ไข ' + esc(a.owner_name) : ''}`;
        const note = a.action_taken ? `แก้ไข: ${esc(a.action_taken)}` : (a.last_note ? esc(a.last_note) : '');
        return `<a class="m-task m-ng ${a.status}" href="${U('/alerts/' + a.id)}"><div class="m-task-main">
          <div class="m-task-title">${esc(a.title)}</div>
          <div class="m-task-meta">${a.eq_code ? `<span class="mono">${esc(a.eq_code)}</span> · ` : ''}${esc(a.form_name || '')}</div>
          <div class="m-ng-who">${who}${a.wo_id ? ' · 🛠 ใบแจ้งซ่อม #' + a.wo_id : ''}</div>${note ? `<div class="m-note">${note}</div>` : ''}</div>
          <div class="m-task-side"><div class="m-task-time">${fmt(a.updated_at)}</div>${term('ALERT', a.status)}</div></a>`;
      }).join('');
  }
  const match = r => (!F.fac || String(r.factory_id || '') === F.fac) && (!F.cat || r.cat === F.cat);
  const taskRows = d => d ? GROUPS.flatMap(([k]) => (d.groups[k] || [])) : [];
  function chipRow(label, key, items) {
    if (items.length < 2) return '';
    return `<div class="m-frow" role="group" aria-label="${label}"><span class="m-flabel">${label}</span>` +
      [['', 'ทั้งหมด', items.reduce((a, x) => a + x[2], 0)], ...items].map(([v, t, n]) =>
        `<button type="button" class="m-fchip${F[key] === v ? ' on' : ''}" data-f="${key}" data-v="${esc(v)}">${esc(t)} <b>${n}</b></button>`).join('') + '</div>';
  }
  function renderFilters() {
    const src = TAB === 'today' ? taskRows(lastTasks) : (formsList || []);
    const both = taskRows(lastTasks).concat(formsList || []);
    const facs = new Map();
    both.forEach(r => { if (r.factory_id) facs.set(String(r.factory_id), r.factory_name || ('โรงงาน ' + r.factory_id)); });
    if (F.fac && !facs.has(F.fac)) F.fac = '';
    const facItems = [...facs].sort((a, b) => a[1].localeCompare(b[1], 'th')).map(([id, name]) => [id, name, src.filter(r => String(r.factory_id || '') === id).length]);
    const inFac = src.filter(r => !F.fac || String(r.factory_id || '') === F.fac);
    const cats = new Map(); inFac.forEach(r => cats.set(r.cat, (cats.get(r.cat) || 0) + 1));
    const catItems = [...cats].sort((a, b) => a[0].localeCompare(b[0], 'th')).map(([c, n]) => [c, c, n]);
    const box = $('#filters');
    box.innerHTML = chipRow('โรงงาน', 'fac', facItems) + chipRow('หมวดหมู่', 'cat', catItems);
    box.hidden = !box.innerHTML;
  }
  function saveFilters() { ECS.kv.put('mfilter', { F, TAB }).catch(() => {}); }
  document.addEventListener('click', e => {
    const c = e.target.closest('.m-fchip');
    if (c) { F[c.dataset.f] = c.dataset.v; if (c.dataset.f === 'fac') F.cat = ''; saveFilters(); refresh(); return; }
    const md = e.target.closest('[data-mode]');
    if (md) { MODE = md.dataset.mode; ECS.kv.put('mmode', MODE).catch(() => {}); render(lastTasks, lastCache); window.scrollTo({ top: $('#tasks').offsetTop - 70, behavior: 'smooth' }); return; }
    const t = e.target.closest('[data-tab]');
    if (t) { TAB = t.dataset.tab; saveFilters(); refresh(); if (TAB === 'all' && !formsList) loadForms(); }
  });
  function refresh() {
    document.querySelectorAll('[data-tab]').forEach(b => { b.classList.toggle('on', b.dataset.tab === TAB); b.setAttribute('aria-selected', b.dataset.tab === TAB); });
    const today = TAB === 'today';
    $('#tasks').hidden = !today; $('#allForms').hidden = today;
    ['#routes', '#outbox', '#recent'].forEach(sel => { const el = $(sel); if (el && el.innerHTML) el.hidden = !today; });
    renderFilters();
    if (today && lastTasks) render(lastTasks, lastCache);
    if (!today) renderForms();
  }

  function render(data, fromCache) {
    if (fromCache) data = retime(data);
    lastTasks = data; lastCache = fromCache;
    renderSyncBox();
    const g = withLocal(data).groups;
    const filtered = F.fac || F.cat;
    const todo = ['returned', 'overdue', 'due'].reduce((a, k) => a + (g[k] || []).filter(match).length, 0);
    $('#todoCount').innerHTML = todo ? `<strong>${todo}</strong><span>งานค้าง${filtered ? ' (ที่กรอง)' : ''}</span>` : '<strong>✓</strong><span>ครบแล้ว</span>';
    if (TAB !== 'today') return;
    let html = '';
    if (fromCache) html += `<div class="m-stale">ไม่มีสัญญาณ — แสดงรายการ ณ ${fmt(data.now, true)} (ปรับสถานะตามเวลาแล้ว)</div>`;
    else html += `<div class="m-fresh">🔄 อัปเดต ${fmt(data.now)} · ตามรอบตรวจปัจจุบัน อัปเดตเองทุก 1 นาที</div>`;
    const tpm = (data.tpm || []).filter(match);
    if (tpm.length) {
      html += `<h2 class="m-h"><span class="badge b-warn">${tpm.length}</span> 📅 แผน TPM ถึงกำหนด <small class="muted">ส่งเช็คชีทแล้วแผนอัปเดตเอง</small></h2>` +
        tpm.map(t => `<a class="m-task tpm" href="${U(`/m/fill#f=${t.form_id}`)}"><div class="m-task-main">
          <div class="m-task-title">${esc(t.task)}</div>
          <div class="m-task-meta">${t.eq_code ? `<span class="mono">${esc(t.eq_code)}</span> · ` : ''}${esc(t.form_name)}${t.assignee ? ' · ' + esc(t.assignee) : ''}</div></div>
          <div class="m-task-side"><div class="m-task-time">${esc(fmtDate(t.next_due))}</div><span class="badge ${t.state === 'overdue' ? 'b-ng' : 'b-warn'}">${esc(t.state_th)}</span></div></a>`).join('');
    }
    // v0.49 โหมด "งานตอนนี้" (ค่าเริ่มต้น) = ตีกลับ / เลยกำหนด / ถึงเวลา · ที่เหลือพับไว้
    const NOWK = ['returned', 'overdue', 'due'];
    const SHOWNOW = ['returned', 'queued', 'overdue', 'due', 'missed'];                 // v0.95 ขาดตรวจ/รอส่ง เห็นตลอด
    const cnt = ks => ks.reduce((a, k) => a + (g[k] || []).filter(match).length, 0);
    const allKeys = GROUPS.map(x => x[0]);
    html += dutyBar(data.duty);
    (data.handover || []).forEach(h => {                     // v0.51 รับกะ
      html += `<a class="m-hand" href="${U('/m/handover/' + h.id)}"><span class="go">รับกะ ›</span><b>📋 รับกะ ${esc(h.factory_name || '')} · ${fmt(h.point_at)}</b>
        <div class="s">ค้าง ${h.carry_n} งาน · ขาดตรวจ ${h.missed} · NG เปิด ${h.ng_n} · เครื่องหยุด ${h.down_n}${h.has_note ? ' · 📝 มีหมายเหตุ' : ''}</div></a>`;
    });
    html += statusBar(g, cnt);
    html += draftsSection();
    html += nextBar(g);
    html += `<div class="m-mode" role="tablist"><button type="button" data-mode="now" class="${MODE === 'now' ? 'on' : ''}" role="tab" aria-selected="${MODE === 'now'}">⚡ งานตอนนี้ (${cnt(NOWK)})</button>
      <button type="button" data-mode="all" class="${MODE === 'all' ? 'on' : ''}" role="tab" aria-selected="${MODE === 'all'}">ทั้งหมดวันนี้ (${cnt(allKeys)})</button></div>`;
    if (MODE === 'all') html += downSection(data.down);
    let any = false, hidden = 0;
    for (const [key, label, cls] of GROUPS) {
      if (MODE === 'now' && !SHOWNOW.includes(key)) continue;
      const all = g[key] || [], rows = all.filter(match);
      hidden += all.length - rows.length;
      if (!rows.length) continue;
      any = true;
      html += `<h2 class="m-h"><span class="badge ${cls}">${rows.length}</span> ${label}</h2>` + rows.map(r => card(r, key)).join('');
    }
    if (MODE === 'now') {
      const rest = [['upcoming', 'ถัดไปวันนี้'], ['done', 'ตรวจแล้ว'], ['skipped', 'เครื่องหยุด'], ['other', 'กะอื่น']]
        .map(([k, t]) => [t, cnt([k])]).filter(x => x[1]);
      const downs = (data.down || []).filter(d => !F.fac || String(d.factory_id || '') === F.fac).length;
      if (downs) rest.push(['แจ้งหยุดอยู่', downs]);
      if (!any) { html += '<div class="m-empty"><strong>✓ ไม่มีงานที่ต้องทำตอนนี้</strong></div>'; any = true; }
      const RC = { 'ถัดไปวันนี้': 'sb-wait', 'ตรวจแล้ว': 'sb-done', 'ขาดตรวจ': 'sb-miss', 'เครื่องหยุด': 'sb-down', 'กะอื่น': 'sb-other', 'แจ้งหยุดอยู่': 'sb-down' };
      if (rest.length) html += `<button type="button" class="m-rest" data-mode="all">${rest.map(([t, n]) => `<span class="st-pill ${RC[t] || ''}">${t === 'ถัดไปวันนี้' ? 'รอรอบ' : t} ${n}</span>`).join(' ')} <span class="m-rest-go">แสดงทั้งหมด ›</span></button>`;
    }
    if (!any) html += filtered && hidden ? '<div class="m-empty"><strong>ไม่มีงานในตัวกรองนี้</strong><br>เลือก "ทั้งหมด" เพื่อดูงานอื่น</div>'
      : '<div class="m-empty"><strong>วันนี้ไม่มีงานตรวจที่มอบหมาย</strong><br>สแกน QR ที่เครื่อง หรือเปิดแท็บ "แบบฟอร์มทั้งหมด" เพื่อตรวจนอกรอบ</div>';
    if (filtered && hidden && any) html += `<button type="button" class="m-fclear" data-clear>+ อีก ${hidden} งานนอกตัวกรอง — แสดงทั้งหมด</button>`;
    html += myNg(data.my_ng);
    $('#tasks').innerHTML = html;
  }
  document.addEventListener('click', e => { if (e.target.closest('[data-clear]')) { F = { fac: '', cat: '' }; saveFilters(); refresh(); } });

  // ── v0.95 แถบสถานะการส่งข้อมูล (บนสุด): ถึงระบบครบ / รอส่ง / ส่งไม่ผ่าน / กรอกค้าง ──
  let lastOk = null, SENT = null, sentAll = false;
  function renderSyncBox() {
    const box = $('#syncBox'); if (!box) return;
    const L = LOCAL, off = lastCache || navigator.onLine === false;
    const sentN = SENT ? SENT.length : null;
    let cls = 'ok', head, sub = [];
    if (L.rejected) { cls = 'err'; head = `⚠ ส่งไม่ผ่าน ${L.rejected} รายการ — ข้อมูลยังไม่เข้าระบบ ต้องแก้ไขแล้วส่งใหม่`; }
    else if (L.pending) { cls = 'warn'; head = `📤 ยังไม่ถึงระบบ ${L.pending} รายการ — เก็บไว้ในเครื่องแล้ว ไม่หาย`; sub.push(off ? 'ไม่มีสัญญาณ: ส่งให้อัตโนมัติเมื่อสัญญาณกลับมา' : 'กำลังส่ง… หรือกด “ส่งตอนนี้”'); }
    else if (off) { cls = 'warn'; head = '📴 ไม่มีสัญญาณ — ผลตรวจที่กดส่งจะเก็บในเครื่องก่อน'; }
    else head = `✓ ผลตรวจที่กดส่งแล้ว ถึงระบบครบ${sentN != null ? ` · วันนี้ ${sentN} รายการ` : ''}`;
    if (L.drafts.length && cls === 'ok') cls = 'draft';
    if (L.drafts.length) sub.push(`✏️ กรอกค้างไว้ ${L.drafts.length} แบบฟอร์ม (ยังไม่ได้กดส่ง = ยังไม่เข้าระบบ)`);
    if (lastOk) sub.push(`เชื่อมต่อระบบล่าสุด ${fmt(lastOk, !String(lastOk).startsWith(ECS.nowTs().slice(0, 10)))}`);
    box.className = 'm-syncbox ' + cls; box.hidden = false;
    box.innerHTML = `<div class="m-sync-h">${head}</div>${sub.length ? `<div class="m-sync-s">${sub.map(esc).join('<br>')}</div>` : ''}
      ${L.pending || L.rejected ? `<div class="m-sync-b">${L.pending ? '<button type="button" class="m-btn m-btn-sm m-btn-primary" data-syncnow>ส่งตอนนี้</button>' : ''}<a class="m-btn m-btn-sm" href="#outbox" data-gooutbox>ดูรายการ</a></div>` : ''}`;
  }
  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-syncnow]');
    if (b) { b.disabled = true; b.textContent = 'กำลังส่ง…'; const r = await ECS.sync(); if (r.state === 'offline') toast('ยังไม่มีสัญญาณ — ข้อมูลยังอยู่ในเครื่อง'); return; }
    if (e.target.closest('[data-gooutbox]')) { e.preventDefault(); const o = $('#outbox'); if (o && !o.hidden) o.scrollIntoView({ behavior: 'smooth' }); return; }
    const dd = e.target.closest('[data-dropdraft]');
    if (dd) {
      e.preventDefault();
      if (!confirm('ทิ้งแบบร่างนี้? ค่าที่กรอกและรูปในเครื่องจะถูกลบ (ยังไม่เคยส่งเข้าระบบ)')) return;
      try { const d = await ECS.drafts.get(dd.dataset.dropdraft);
        for (const a of Object.values((d && d.answers) || {})) for (const pid of a.photos || []) await ECS.photos.del(pid);
        await ECS.drafts.del(dd.dataset.dropdraft); } catch (err) { /* */ }
      await loadLocal(); render(lastTasks, lastCache); return;
    }
    if (e.target.closest('[data-sentall]')) { sentAll = true; renderRecent(); }
  });
  function toast(msg) { const t = document.createElement('div'); t.className = 'm-toast err'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 3000); }
  function draftsSection() {
    const ds = LOCAL.drafts; if (!ds.length) return '';
    return `<h2 class="m-h"><span class="badge sb-queue">${ds.length}</span> ✏️ กรอกค้างไว้ — ยังไม่ได้กดส่ง</h2>` + ds.map(d => {
      const m = d.meta || {}, tot = m.n_req || 0, got = tot ? Math.min(m.n_done || 0, tot) : d.n, pct = tot ? Math.round(100 * got / tot) : 0;
      const href = U(`/m/fill#f=${d.form_id}${d.round_id ? '&r=' + d.round_id : ''}`);
      const dl = (d.round && d.round.deadline_at) || m.deadline_at;
      return `<div class="m-twrap"><a class="m-task m-draft" href="${href}"><div class="m-task-main">
          <div class="m-task-title">${m.eq_code ? `<span class="mono">${esc(m.eq_code)}</span> · ` : ''}${esc(m.form_name || ('แบบฟอร์ม ' + d.form_id))}</div>
          <div class="m-routebar"><div style="width:${pct}%"></div></div>
          <div class="m-task-meta">กรอกแล้ว ${tot ? `${got}/${tot}` : got} ข้อ${m.ng ? ` · <b class="text-ng">NG ${m.ng}</b>` : ''} · แก้ล่าสุด ${fmt(d.at, true)}${dl ? ` · ปิดรอบ ${fmt(dl)}` : (d.round_id ? '' : ' · ตรวจนอกรอบ')}</div></div>
          <div class="m-task-side"><span class="m-go">ทำต่อ ›</span></div></a>
        <button type="button" class="m-eqbtn" data-dropdraft="${esc(d.key)}">🗑 ทิ้งแบบร่าง</button></div>`;
    }).join('');
  }

  function renderForms() {
    const box = $('#allForms');
    if (!formsList) { box.innerHTML = '<div class="m-empty">กำลังโหลดแบบฟอร์ม…</div>'; return; }
    const q = search.trim().toLowerCase();
    const rows = formsList.filter(match).filter(f => !q || [f.name, f.code, f.eq_code, f.eq_name, f.area_name].some(v => (v || '').toLowerCase().includes(q)));
    const groups = new Map(); rows.forEach(f => { if (!groups.has(f.cat)) groups.set(f.cat, []); groups.get(f.cat).push(f); });
    let html = `<input type="search" class="m-input m-fsearch" id="fSearch" placeholder="ค้นหา: ชื่อแบบฟอร์ม / รหัสเครื่อง / พื้นที่" value="${esc(search)}">`;
    if (!rows.length) html += '<div class="m-empty">ไม่พบแบบฟอร์มตามเงื่อนไข</div>';
    [...groups].sort((a, b) => a[0].localeCompare(b[0], 'th')).forEach(([cat, list]) => {
      html += `<h2 class="m-h">🏷 ${esc(cat)} <span class="badge b-none">${list.length}</span></h2>` + list.map(f => {
        const down = f.run_status === 'down', btn = eqBtn(f.equipment_id, f.eq_code, f.eq_name, down, f.down_reason, f.down_since, true);
        const a = `<a class="m-task" href="${U('/m/fill')}#f=${f.id}"><div class="m-task-main"><div class="m-task-title">${esc(f.name)}</div>
          <div class="m-task-meta">${f.eq_code ? `<span class="mono">${esc(f.eq_code)}</span> · ` : ''}${esc(f.area_name || '')}${f.area_name && f.factory_name && !F.fac ? ' · ' : ''}${F.fac ? '' : esc(f.factory_name || '')}
          ${down ? `<div class="small muted">⛔ ${esc(f.down_reason || 'เครื่องหยุด')}</div>` : ''}</div></div>
          <div class="m-task-side"><div class="m-task-time">${f.items} ข้อ</div>${down ? '<span class="badge b-warn">หยุด</span>' : (f.last ? `<div class="small muted">ล่าสุด ${fmt(f.last, true)}</div>` : '')}</div></a>`;
        return btn ? `<div class="m-twrap">${a}${btn}</div>` : a;
      }).join('');
    });
    const had = document.activeElement && document.activeElement.id === 'fSearch';
    box.innerHTML = html;
    const inp = $('#fSearch');
    inp.addEventListener('input', () => { search = inp.value; const pos = inp.selectionStart; renderForms(); const n = $('#fSearch'); n.focus(); n.setSelectionRange(pos, pos); });
    if (had) inp.focus();
  }
  async function loadForms() {
    try { const d = await ECS.getJson('/api/m/forms'); formsList = d.forms; await ECS.kv.put('forms', formsList); }
    catch (e) { formsList = (await ECS.kv.get('forms')) || []; }
    refresh();
  }

  async function renderOutbox() {
    const st = await ECS.status();
    const box = $('#outbox');
    if (!st.items.length) { box.hidden = true; return; }
    box.hidden = TAB !== 'today';
    box.innerHTML = '<h2 class="m-h">📤 ยังไม่ถึงระบบ <small class="muted">กดส่งแล้ว เก็บในเครื่อง</small></h2>' + st.items.map(it => {
      const bad = it.status === 'rejected';
      return `<div class="m-task ${bad ? 'returned' : 'queued'}"><div class="m-task-main">
          <div class="m-task-title">${esc(it.form_name)}</div>
          <div class="m-task-meta">บันทึกเมื่อ ${fmt(it.payload.finished_at || it.created_at, true)} · ${(it.photoIds || []).length} รูป</div>
          ${bad ? `<div class="m-note">${it.error.map(esc).join('<br>')}</div>` : ''}</div>
        <div class="m-task-side">${bad ? `<a class="m-btn m-btn-sm" href="${it.edit_url ? U(it.edit_url) : U('/m/fill') + '#o=' + it.client_uuid}">แก้ไข</a>`
          : '<span class="badge b-warn">รอสัญญาณ</span>'}</div></div>`;
    }).join('') + (st.pending ? '<button class="m-btn m-btn-block" id="btnSync">ส่งตอนนี้</button>' : '');
    const b = $('#btnSync'); if (b) b.onclick = async () => { b.disabled = true; b.textContent = 'กำลังส่ง…'; await ECS.sync(); };
  }

  // v0.95 ถึงระบบแล้ววันนี้ — ยืนยันจากเซิร์ฟเวอร์ (ทุกเครื่องที่ฉันใช้) · ออฟไลน์ใช้รายการที่ส่งจากเครื่องนี้
  const APPR = { pending: ['b-warn', 'รออนุมัติ'], approved: ['b-ok', '✔ อนุมัติแล้ว'], rejected: ['b-ng', '↩ ตีกลับ'] };
  async function renderRecent() {
    const box = $('#recent');
    let rows, server = !!SENT;
    if (SENT) rows = SENT;
    else {
      const today = ECS.nowTs().slice(0, 10);
      rows = ((await ECS.kv.get('recent')) || []).filter(r => (r.at || '').startsWith(today)).map(r => ({ id: r.id, form_name: r.form_name, ng_count: r.ng, received_at: r.at, late_sync: r.offline }));
    }
    if (!rows.length) { box.hidden = true; box.innerHTML = ''; return; }
    box.hidden = TAB !== 'today';
    const show = sentAll ? rows : rows.slice(0, 6);
    box.innerHTML = `<h2 class="m-h"><span class="badge sb-done">${rows.length}</span> ✓ ถึงระบบแล้ววันนี้ <small class="muted">${server ? 'ยืนยันจากระบบ' : 'จากเครื่องนี้ (ไม่มีสัญญาณ)'}</small></h2>` + show.map(r => {
      const ap = APPR[r.approval_status];
      return `<a class="m-task done" href="${U('/submissions/' + r.id)}"><div class="m-task-main"><div class="m-task-title">${r.eq_code ? `<span class="mono">${esc(r.eq_code)}</span> · ` : ''}${esc(r.form_name)}</div>
       <div class="m-task-meta">ถึงระบบ ${fmt(r.received_at)}${r.finished_at && r.late_sync ? ` · กดส่ง ${fmt(r.finished_at)} (ส่งตามหลังเมื่อมีสัญญาณ)` : ''}${r.round_status === 'done_late' ? ' · <span class="text-warn">ตรวจล่าช้า</span>' : ''}
       ${r.approval_status === 'rejected' && r.approval_note ? `<div class="m-note">เหตุผล: ${esc(r.approval_note)}</div>` : ''}</div></div>
       <div class="m-task-side">${r.ng_count ? `<span class="badge b-ng">NG ${r.ng_count}</span>` : '<span class="badge b-ok">ปกติ</span>'}${ap ? `<span class="badge ${ap[0]}">${ap[1]}</span>` : ''}</div></a>`;
    }).join('') + (rows.length > show.length ? `<button type="button" class="m-fclear" data-sentall>แสดงทั้งหมด ${rows.length} รายการ</button>` : '');
  }

  async function prefetch(ids) {
    for (const id of ids || []) {
      try { await ECS.kv.put('pkg:' + id, await ECS.getJson(`/api/m/forms/${id}/package`)); } catch (e) { /* ข้าม */ }
    }
  }

  async function load() {
    try {
      const data = await ECS.getJson('/api/m/tasks');
      await ECS.kv.put('tasks', data);
      SENT = data.sent || null; lastOk = data.now; ECS.kv.put('last_ok', lastOk).catch(() => {});
      await loadLocal();
      render(data, false); renderFilters(); renderRecent();
      if (window.ECSOffline) ECSOffline.renderHomeBox(document.getElementById('offBox'));
      prefetch(data.prefetch_forms);
    } catch (e) {
      if (e.status === 401) { location.href = U('/login') + '?next=' + encodeURIComponent(U('/m/')); return; }
      const cached = await ECS.kv.get('tasks');
      SENT = null; try { lastOk = await ECS.kv.get('last_ok'); } catch (err) { /* */ }
      await loadLocal();
      if (cached) { render(cached, true); renderFilters(); renderRecent(); }
      else { renderSyncBox(); $('#tasks').innerHTML = '<div class="m-empty">ไม่มีสัญญาณ และยังไม่เคยโหลดงานในเครื่องนี้<br>ต่อสัญญาณแล้วลองใหม่</div>'; }
    }
  }

  // เส้นทางเดินตรวจ
  function renderRoutes(list) {
    const box = $('#routes');
    list = list || [];
    box.hidden = TAB !== 'today';
    box.innerHTML = '<h2 class="m-h"><i class=ei-walk aria-hidden=true></i> เส้นทางเดินตรวจ</h2>' + list.map(r => {
      const pct = r.total ? Math.round(100 * r.done / r.total) : 0;
      return `<a class="m-task m-route ${r.todo ? 'due' : 'done'}" href="${U('/m/route')}#id=${r.id}"><div class="m-task-main">
        <div class="m-task-title">${esc(r.name)}</div>
        <div class="m-routebar"><div style="width:${pct}%"></div></div>
        <div class="m-task-meta">${r.mine ? '<span class="badge b-none">ของฉัน</span> ' : ''}ตรวจแล้ว ${r.done}/${r.total} จุด${r.factory_name ? ' · ' + esc(r.factory_name) : ''}</div></div>
        <div class="m-task-side">${r.todo ? `<span class="badge b-info">เหลือ ${r.todo}</span>` : '<span class="badge b-ok">ครบ</span>'}</div></a>`;
    }).join('') + `<a class="m-route-add" href="${U('/m/route/edit')}">＋ สร้างเส้นทางของฉัน</a>`;
  }
  async function loadRoutes() {
    try { const d = await ECS.getJson('/api/m/routes'); await ECS.kv.put('routes', d.routes); renderRoutes(d.routes); }
    catch (e) { renderRoutes(await ECS.kv.get('routes')); }
  }

  document.addEventListener('ecs:eqstatus', () => { load(); formsList = null; loadForms(); });   // v0.38 แจ้งหยุด/เดินแล้ว → โหลดใหม่
  // v0.48 อัปเดตตามรอบตรวจปัจจุบันเอง: ทุก 1 นาทีขณะเปิดหน้า และทันทีเมื่อกลับมาที่แอป
  setInterval(() => { if (document.visibilityState === 'visible' && TAB === 'today') load(); }, 60000);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') load(); });
  document.addEventListener('ecs:sync', async e => { renderOutbox(); await loadLocal(); if (e.detail.sent) load(); else if (lastTasks) render(lastTasks, lastCache); else renderSyncBox(); });
  (async () => {
    try { const saved = await ECS.kv.get('mfilter'); if (saved) { F = Object.assign(F, saved.F || {}); TAB = saved.TAB === 'all' ? 'all' : 'today'; } } catch (e) { /* */ }
    try { const m = await ECS.kv.get('mmode'); if (m === 'all' || m === 'now') MODE = m; } catch (e) { /* */ }
    refresh();
    load(); loadRoutes(); renderOutbox(); renderRecent(); loadForms(); ECS.sync();
    if (window.ECSOffline) ECSOffline.renderHomeBox(document.getElementById('offBox'));   // v0.40 เตรียมออฟไลน์ทั้งกะ
  })();
})();
