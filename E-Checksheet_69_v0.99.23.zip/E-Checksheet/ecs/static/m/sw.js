/* Service worker — เก็บหน้าจอหลักของโหมดตรวจไว้ในเครื่อง เพื่อเปิดใช้ได้แม้ไม่มีสัญญาณ
   (ทำงานเฉพาะเมื่อเปิดผ่าน HTTPS ที่เครื่องเชื่อถือ หรือ localhost) */
const CACHE = 'ecs-__VERSION__';
// ตำแหน่งฐานของระบบ (เช่น /echeck เมื่อรวมอยู่ใน UT-CMMS) คำนวณจาก scope ของ service worker
const BASE = new URL(self.registration.scope).pathname.replace(/\/m\/$/, '');
const SHELL = ['/m/', '/m/fill', '/m/scan', '/m/energy'].map(p => BASE + p);

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => Promise.all(SHELL.map(u =>
    fetch(u, { credentials: 'same-origin' }).then(r => { if (r.ok && !r.redirected) return c.put(u, r); }).catch(() => {})))));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('ecs-') && k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (url.pathname.startsWith(BASE + '/api/') || url.pathname.startsWith(BASE + '/media/')) return;   // ข้อมูลสด ให้หน้าเว็บจัดการเอง

  if (req.mode === 'navigate' && SHELL.includes(url.pathname)) {
    // หน้าเว็บ: ใช้เครือข่ายก่อน ถ้าไม่มีสัญญาณใช้ของที่เก็บไว้
    e.respondWith(fetch(req).then(r => {
      if (r.ok && !r.redirected) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(url.pathname, copy)); }
      return r;
    }).catch(() => caches.match(url.pathname).then(r => r || new Response(
      '<meta charset="utf-8"><p style="font-family:sans-serif;padding:20px">ไม่มีสัญญาณ และยังไม่เคยเปิดหน้านี้ในเครื่องนี้</p>',
      { headers: { 'Content-Type': 'text/html; charset=utf-8' } }))));
    return;
  }
  if (url.pathname.startsWith(BASE + '/static/')) {
    // ไฟล์ CSS/JS: ใช้ของในเครื่องก่อน (ชื่อไฟล์มีเลขเวอร์ชันอยู่แล้ว)
    e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(r => {
      if (r.ok) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
      return r;
    })));
  }
});
