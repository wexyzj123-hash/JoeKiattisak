/* ocr.js — v0.64 อ่านตัวเลขจากรูปหน้าปัดมิเตอร์ (ทำงานในเครื่อง ไม่ส่งรูปออกนอกระบบ)
 * 2 วิธีช่วยกัน แล้วเลือกค่าที่เข้าช่วงที่ควรเป็นที่สุด:
 *   1) Tesseract (LSTM) อ่านเฉพาะ 0-9 และจุด — เหมาะกับเลขแบบลูกล้อ/ตัวพิมพ์
 *   2) ตัวถอดรหัส 7 ส่วน (seven-segment) — เหมาะกับจอ LCD/LED ของมิเตอร์ไฟฟ้า
 * ขั้นตอน: ตัดเฉพาะกรอบตัวเลข → ขาวดำ (Otsu) → ปรับให้ตัวเลขเข้ม/พื้นขาว → ขยายเส้นให้ส่วนของเลข 7 ส่วนต่อกัน
 * ผลลัพธ์เป็นค่าแนะนำ — ช่างต้องตรวจให้ตรงกับหน้าปัดก่อนบันทึกเสมอ */
(function () {
  'use strict';
  const SRC = (document.currentScript && document.currentScript.src) || '';
  const VENDOR = SRC ? SRC.replace(/\/m\/ocr\.js(\?.*)?$/, '/vendor/tesseract/') : U('/static/vendor/tesseract/');
  let libP = null, workerP = null;

  function loadLib() {
    if (window.Tesseract) return Promise.resolve(window.Tesseract);
    if (!libP) libP = new Promise((res, rej) => {
      const s = document.createElement('script'); s.src = VENDOR + 'tesseract.min.js';
      s.onload = () => res(window.Tesseract); s.onerror = () => { libP = null; rej(new Error('โหลดตัวอ่านตัวเลขไม่ได้')); };
      document.head.appendChild(s);
    });
    return libP;
  }
  // เตรียมไว้ล่วงหน้าตอนมีสัญญาณ (โหลดโมเดล ~7 MB ครั้งเดียว) — หลังจากนั้นอ่านได้แม้ออฟไลน์ตราบที่ยังเปิดหน้านี้อยู่
  function warm() {
    if (!workerP) workerP = (async () => {
      const T = await loadLib();
      const w = await T.createWorker('eng', 1, { workerPath: VENDOR + 'worker.min.js', corePath: VENDOR + 'tesseract-core-lstm.wasm.js',
        langPath: VENDOR.replace(/\/$/, ''), gzip: true, cacheMethod: 'none', logger: () => {} });
      await w.setParameters({ tessedit_char_whitelist: '0123456789.', tessedit_pageseg_mode: '7', classify_bln_numeric_mode: '1' });
      return w;
    })().catch((e) => { workerP = null; throw e; });
    return workerP;
  }

  function loadImg(blob) {
    return new Promise((res, rej) => { const u = URL.createObjectURL(blob); const i = new Image();
      i.onload = () => { res(i); setTimeout(() => URL.revokeObjectURL(u), 0); }; i.onerror = rej; i.src = u; });
  }

  // ตัดกรอบ (สัดส่วน 0–1) + ย่อ/ขยายให้ความสูงตัวเลขพอดี → คืน {canvas ขาวดำ, bin: Uint8Array (1 = หมึก), w, h}
  function prepare(img, box, targetH) {
    const W = img.naturalWidth, H = img.naturalHeight;
    const b = box && box.length === 4 ? box : [0.05, 0.3, 0.9, 0.4];
    const sx = Math.max(0, b[0] * W), sy = Math.max(0, b[1] * H), sw = Math.min(W - sx, b[2] * W), sh = Math.min(H - sy, b[3] * H);
    const k = (targetH || 140) / sh;
    const w = Math.max(20, Math.round(sw * k)), h = Math.max(20, Math.round(sh * k));
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d', { willReadFrequently: true });
    g.imageSmoothingQuality = 'high';
    g.drawImage(img, sx, sy, sw, sh, 0, 0, w, h);
    const d = g.getImageData(0, 0, w, h), px = d.data, gray = new Uint8Array(w * h), hist = new Array(256).fill(0);
    for (let i = 0; i < w * h; i++) { const v = (px[i * 4] * 299 + px[i * 4 + 1] * 587 + px[i * 4 + 2] * 114) / 1000 | 0; gray[i] = v; hist[v]++; }
    // Otsu
    let sum = 0; for (let t = 0; t < 256; t++) sum += t * hist[t];
    let sB = 0, wB = 0, best = 0, thr = 128;
    for (let t = 0; t < 256; t++) {
      wB += hist[t]; if (!wB) continue; const wF = w * h - wB; if (!wF) break;
      sB += t * hist[t]; const mB = sB / wB, mF = (sum - sB) / wF, v = wB * wF * (mB - mF) * (mB - mF);
      if (v > best) { best = v; thr = t; }
    }
    let bin = new Uint8Array(w * h), dark = 0;
    for (let i = 0; i < w * h; i++) { bin[i] = gray[i] < thr ? 1 : 0; dark += bin[i]; }
    if (dark > w * h / 2) for (let i = 0; i < w * h; i++) bin[i] ^= 1;          // เลขสว่างบนพื้นมืด (LED) → กลับสี
    // ลบจุดเล็ก ๆ ตามขอบ (ขอบกรอบจอ) — ล้างแถว/คอลัมน์ขอบที่หมึกเกือบเต็ม
    for (let y = 0; y < h; y++) { let n = 0; for (let x = 0; x < w; x++) n += bin[y * w + x]; if (n > w * 0.85) for (let x = 0; x < w; x++) bin[y * w + x] = 0; }
    for (let x = 0; x < w; x++) { let n = 0; for (let y = 0; y < h; y++) n += bin[y * w + x]; if (n > h * 0.9) for (let y = 0; y < h; y++) bin[y * w + x] = 0; }
    // ขยายเส้นแนวตั้งเล็กน้อย ให้ส่วนของเลข 7 ส่วนต่อกัน
    const r = Math.max(1, Math.round(h / 45));
    const dil = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (!bin[y * w + x]) continue;
      for (let dy = -r; dy <= r; dy++) { const yy = y + dy; if (yy < 0 || yy >= h) continue;
        for (let dx = -r; dx <= r; dx++) { const xx = x + dx; if (xx >= 0 && xx < w) dil[yy * w + xx] = 1; } }
    }
    const out = g.createImageData(w, h);
    for (let i = 0; i < w * h; i++) { const v = dil[i] ? 0 : 255; out.data[i * 4] = out.data[i * 4 + 1] = out.data[i * 4 + 2] = v; out.data[i * 4 + 3] = 255; }
    g.putImageData(out, 0, 0);
    // เติมขอบขาวรอบ ๆ ให้ Tesseract อ่านดีขึ้น
    const pad = Math.round(h * 0.25), c2 = document.createElement('canvas'); c2.width = w + pad * 2; c2.height = h + pad * 2;
    const g2 = c2.getContext('2d'); g2.fillStyle = '#fff'; g2.fillRect(0, 0, c2.width, c2.height); g2.drawImage(c, pad, pad);
    return { canvas: c2, bin, w, h };
  }

  // ── ถอดรหัสเลข 7 ส่วน ──
  const SEG7 = { '1111110': '0', '0110000': '1', '1101101': '2', '1111001': '3', '0110011': '4', '1011011': '5', '1011111': '6',
    '1110000': '7', '1110010': '7', '1111111': '8', '1111011': '9', '0111011': '9', '0011111': '6' };
  function sevenSeg(p) {
    const { bin, w, h } = p;
    const col = new Array(w).fill(0);
    for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) col[x] += bin[y * w + x];
    const gapMin = Math.max(2, Math.round(h * 0.06));
    const groups = []; let s = -1, gap = 0;
    for (let x = 0; x <= w; x++) {
      const on = x < w && col[x] > 0;
      if (on) { if (s < 0) s = x; gap = 0; }
      else if (s >= 0) { gap++; if (gap >= gapMin || x === w) { groups.push([s, x - gap]); s = -1; gap = 0; } }
    }
    if (!groups.length || groups.length > 12) return null;
    // ขอบบน-ล่างของตัวเลขทั้งแถว
    let top = h, bot = 0;
    for (const [a, b] of groups) for (let y = 0; y < h; y++) for (let x = a; x <= b; x++) if (bin[y * w + x]) { if (y < top) top = y; if (y > bot) bot = y; }
    const H = bot - top + 1;
    if (H < 10) return null;
    let txt = '';
    for (const [a, b] of groups) {
      let t = h, bb = 0, n = 0;
      for (let y = 0; y < h; y++) for (let x = a; x <= b; x++) if (bin[y * w + x]) { n++; if (y < t) t = y; if (y > bb) bb = y; }
      const gw = b - a + 1, gh = bb - t + 1;
      if (gh < H * 0.35) { if (t > top + H * 0.6 && gw < H * 0.35) { txt += '.'; } continue; }   // จุดทศนิยม / สิ่งรบกวน
      if (gw < H * 0.3) { txt += '1'; continue; }
      const fill = (x0, x1, y0, y1) => {      // สัดส่วนหมึกในช่อง (สัดส่วนของกล่องตัวเลข)
        const X0 = a + Math.round(x0 * gw), X1 = a + Math.round(x1 * gw), Y0 = top + Math.round(y0 * H), Y1 = top + Math.round(y1 * H);
        let k = 0, m = 0;
        for (let y = Y0; y <= Y1; y++) for (let x = X0; x <= X1; x++) { if (x < 0 || x >= w || y < 0 || y >= h) continue; m++; k += bin[y * w + x]; }
        return m ? k / m : 0;
      };
      const on = (v) => (v > 0.35 ? '1' : '0');
      const code = [fill(0.3, 0.7, 0.0, 0.12), fill(0.75, 1.0, 0.15, 0.4), fill(0.7, 1.0, 0.6, 0.85), fill(0.25, 0.7, 0.88, 1.0),
        fill(0.0, 0.3, 0.6, 0.85), fill(0.0, 0.3, 0.15, 0.4), fill(0.3, 0.7, 0.44, 0.56)].map(on).join('');
      const dgt = SEG7[code];
      if (!dgt) return null;
      txt += dgt;
    }
    return /\d/.test(txt) ? txt : null;
  }

  function clean(t) {
    let s = String(t || '').replace(/[^0-9.]/g, '');
    s = s.replace(/^\.+|\.+$/g, '');
    const i = s.indexOf('.'); if (i >= 0) s = s.slice(0, i + 1) + s.slice(i + 1).replace(/\./g, '');
    return s;
  }

  // เลือกค่าที่ดีที่สุด: อยู่ในช่วงที่ควรเป็น > จำนวนหลักตรง > ความมั่นใจ
  function rank(cands, ex) {
    const lo = ex && ex.lo != null ? ex.lo : null, hi = ex && ex.hi != null ? ex.hi : null, dg = ex && ex.digits;
    const scored = [];
    for (const c of cands) {
      const s = clean(c.text); if (!s || !/\d/.test(s)) continue;
      const vars = [s];
      // จอ LCD มักไม่มีจุด หรือจุดหลุด — ลองตีความทศนิยม 1–2 ตำแหน่งให้เข้าช่วง
      if (s.indexOf('.') < 0 && s.length > 2) { vars.push(s.slice(0, -1) + '.' + s.slice(-1)); vars.push(s.slice(0, -2) + '.' + s.slice(-2)); }
      vars.forEach((v, k) => {
        const x = parseFloat(v); if (!isFinite(x)) return;
        let sc = (c.conf || 50) / 100 - k * 0.15;
        if (lo != null && hi != null) sc += x >= lo && x <= hi ? 3 : (x >= lo && x <= lo + (hi - lo) * 3 ? 1 : -1);
        else if (lo != null) sc += x >= lo ? 1 : -1;
        if (dg && String(Math.trunc(x)).length === dg) sc += 1;
        scored.push({ value: v, num: x, score: sc, src: c.src });
      });
    }
    scored.sort((a, b) => b.score - a.score);
    const seen = new Set(), out = [];
    for (const s of scored) { if (seen.has(s.value)) continue; seen.add(s.value); out.push(s); }
    return out.slice(0, 4);
  }

  // หาตำแหน่งจอตัวเลขเอง (ยังไม่เคยตั้งกรอบ หรืออ่านจากกรอบเดิมไม่ได้) — ลองหลายกรอบด้วยตัวถอดเลข 7 ส่วน (เร็ว)
  function locate(img, ex) {
    let best = null;
    const xs = [[0.03, 0.94], [0.12, 0.76], [0.2, 0.6], [0.25, 0.5]];
    for (const hh of [0.1, 0.15, 0.2, 0.28]) {
      for (let y = 0.05; y + hh <= 0.96; y += hh / 3) {
        for (const [x, w] of xs) {
          const box = [x, Math.round(y * 1e4) / 1e4, w, hh];
          let ss = null;
          try { ss = sevenSeg(prepare(img, box, 80)); } catch (e) { ss = null; }
          if (!ss || ss.replace(/\D/g, '').length < 3) continue;
          const r = rank([{ text: ss, conf: 70, src: '7seg' }], ex)[0];
          if (r && (!best || r.score > best.score || (r.score === best.score && w * hh < best.box[2] * best.box[3]))) best = Object.assign({ box }, r);
        }
      }
    }
    return best;
  }

  async function read(blob, box, ex) {
    const img = await loadImg(blob);
    const cands = [];
    for (const H of [140, 90]) {
      const p = prepare(img, box, H);
      const ss = sevenSeg(p);
      if (ss) cands.push({ text: ss, conf: 70, src: '7seg' });
      try {
        const w = await warm();
        const r = await w.recognize(p.canvas);
        if (r && r.data && r.data.text) cands.push({ text: r.data.text, conf: r.data.confidence, src: 'ocr' });
      } catch (e) { if (!cands.length && H === 90) throw e; }
      const top = rank(cands, ex);
      if (top.length && top[0].score >= 3) break;
    }
    let used = box;
    let top = rank(cands, ex);
    if (!top.length || top[0].score < 3) {                 // กรอบเดิมอ่านไม่ได้ → หาจอเอง แล้วอ่านซ้ำที่กรอบใหม่
      const loc = locate(img, ex);
      if (loc && (!top.length || loc.score > top[0].score)) {
        used = loc.box;
        const p = prepare(img, used, 140), ss = sevenSeg(p);
        if (ss) cands.push({ text: ss, conf: 75, src: '7seg' });
        cands.push({ text: loc.value, conf: 70, src: '7seg' });
        top = rank(cands, ex);
      }
    }
    return { best: top, raw: cands, box: used };
  }

  window.ECSOCR = { warm, read, prepare, sevenSeg, rank, clean, loadImg, locate };
})();
