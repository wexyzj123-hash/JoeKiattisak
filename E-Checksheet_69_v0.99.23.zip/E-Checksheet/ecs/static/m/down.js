/* v0.38 ช่างแจ้ง "เครื่องหยุด / PM" และ "กลับมาเดินแล้ว" จากมือถือ
   ใช้ในหน้างานของฉัน (การ์ดเช็คชีท · แบบฟอร์มทั้งหมด · รายการเครื่องหยุด) และหน้ากรอกผลตรวจ
   แจ้งหยุด → รอบตรวจที่ยังไม่ปิดของเครื่องนั้น "งดตรวจ" (ไม่นับขาดตรวจ) · กลับมาเดิน → เปิดรอบที่ยังอยู่ในช่วงเวลาให้ตรวจต่อ */
(function () {
  'use strict';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const CATS = [
    ['pm', '🛠', 'PM / บำรุงรักษาตามแผน'],
    ['repair', '⚠', 'ซ่อม / เสีย'],
    ['stop', '⏸', 'หยุดตามแผนการผลิต'],
    ['standby', '💤', 'สำรอง / ไม่ได้เดิน'],
    ['other', '…', 'อื่น ๆ'],
  ];

  function toast(msg, ok) {
    const t = document.createElement('div'); t.className = 'm-toast ' + (ok ? 'ok' : 'err'); t.textContent = msg;
    document.body.appendChild(t); setTimeout(() => t.remove(), 3200);
  }
  async function post(url, body) {
    if (navigator.onLine === false) throw new Error('ไม่มีสัญญาณ — การแจ้งเครื่องหยุด/เดินต้องออนไลน์');
    const r = await fetch(U(url), { method: 'POST', credentials: 'same-origin', body: JSON.stringify(body || {}),
      headers: { 'Content-Type': 'application/json', Accept: 'application/json',
        'X-CSRF-Token': (window.ECS && ECS.csrf()) || (document.querySelector('meta[name=csrf-token]') || {}).content || '' } });
    let d = {}; try { d = await r.json(); } catch (e) { /* */ }
    if (r.status === 401 || r.redirected) throw new Error('หมดเวลาเข้าสู่ระบบ — เข้าสู่ระบบใหม่แล้วลองอีกครั้ง');
    if (!r.ok) throw new Error(d.error || 'บันทึกไม่สำเร็จ (' + r.status + ')');
    return d;
  }
  function open(html) {
    const wrap = document.createElement('div');
    wrap.className = 'm-modal'; wrap.setAttribute('role', 'dialog'); wrap.setAttribute('aria-modal', 'true');
    wrap.innerHTML = `<div class="m-sheet m-dsheet">${html}</div>`;
    document.body.appendChild(wrap); document.body.classList.add('m-modal-open');
    const close = () => { wrap.remove(); document.body.classList.remove('m-modal-open'); };
    wrap.addEventListener('click', e => { if (e.target === wrap || e.target.closest('[data-x]')) close(); });
    return { wrap, close };
  }

  /** eq = {id, code, name} · done(res) เรียกหลังบันทึกสำเร็จ */
  function downSheet(eq, done) {
    let cat = 'pm';
    const s = open(`<div class="m-sheet-ic" style="background:#fef3c7;color:#b45309">⛔</div>
      <h2>แจ้งเครื่องหยุด / PM</h2>
      <p class="m-sheet-sub"><b class="mono">${esc(eq.code || '')}</b> ${esc(eq.name || '')}</p>
      <div class="m-dcats" role="radiogroup" aria-label="สาเหตุ">${CATS.map(([k, ic, t]) =>
        `<button type="button" role="radio" data-cat="${k}" class="${k === cat ? 'on' : ''}" aria-checked="${k === cat}"><span>${ic}</span>${esc(t)}</button>`).join('')}</div>
      <label class="rp-lbl" for="dnReason">รายละเอียด <span class="muted small">(ไม่บังคับ)</span></label>
      <textarea class="m-input" id="dnReason" rows="2" maxlength="300" placeholder="เช่น เปลี่ยนไส้กรอง / มอเตอร์ไหม้ / รอชิ้นส่วน"></textarea>
      <label class="rp-lbl" for="dnSince" style="margin-top:8px">เครื่องหยุดตั้งแต่ <span class="muted small">(ย้อนหลังได้ 24 ชม. — เช่น หยุดตั้งแต่กะดึก)</span></label>
      <input class="m-input" type="datetime-local" id="dnSince" value="${(() => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); })()}">
      <div class="m-dsince">${[['ตอนนี้', 0], ['เริ่มกะ 08:00', 8], ['เริ่มกะ 17:00', 17], ['เริ่มกะ 20:00', 20]].map(([t, h]) => `<button type="button" data-since="${h}">${t}</button>`).join('')}</div>
      <label class="rp-lbl" for="dnUntil" style="margin-top:8px">คาดว่าจะกลับมาเดิน <span class="muted small">(ไม่บังคับ)</span></label>
      <input class="m-input" type="datetime-local" id="dnUntil">
      <div class="m-dnote">รอบตรวจของเครื่องนี้จะ <b>งดตรวจ</b> (ไม่นับขาดตรวจ) จนกว่าจะแจ้ง "กลับมาเดินแล้ว" · หัวหน้างานได้รับแจ้ง</div>
      <button type="button" class="m-btn m-btn-primary m-btn-block" id="dnOk">ยืนยันแจ้งเครื่องหยุด</button>
      <button type="button" class="m-btn m-btn-block" data-x>ยกเลิก</button>`);
    s.wrap.querySelector('.m-dsince').addEventListener('click', e => {      // v0.53 เวลาเริ่มหยุด (ล่าสุดที่ไม่อยู่ในอนาคต)
      const b = e.target.closest('[data-since]'); if (!b) return;
      const d = new Date(), h = +b.dataset.since;
      if (h) { d.setHours(h, 0, 0, 0); if (d > new Date()) d.setDate(d.getDate() - 1); }
      d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); s.wrap.querySelector('#dnSince').value = d.toISOString().slice(0, 16);
    });
    s.wrap.querySelector('.m-dcats').addEventListener('click', e => {
      const b = e.target.closest('[data-cat]'); if (!b) return; cat = b.dataset.cat;
      s.wrap.querySelectorAll('[data-cat]').forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-checked', x === b); });
    });
    s.wrap.querySelector('#dnOk').onclick = async ev => {
      const b = ev.currentTarget; b.disabled = true; b.textContent = 'กำลังบันทึก…';
      try {
        const d = await post(`/api/m/equipment/${eq.id}/down`, { category: cat, reason: s.wrap.querySelector('#dnReason').value,
          expected_end: s.wrap.querySelector('#dnUntil').value || null, since: s.wrap.querySelector('#dnSince').value || null });
        s.close(); toast(`แจ้ง ${d.code} หยุดแล้ว — งดรอบตรวจ ${d.skipped} รอบ`, true); if (done) done(d);
      } catch (e) { b.disabled = false; b.textContent = 'ยืนยันแจ้งเครื่องหยุด'; toast(e.message); }
    };
  }

  /** eq = {id, code, name, reason, since} */
  function runSheet(eq, done) {
    const s = open(`<div class="m-sheet-ic" style="background:#dcfce7;color:#15803d">✓</div>
      <h2>เครื่องกลับมาเดินแล้ว</h2>
      <p class="m-sheet-sub"><b class="mono">${esc(eq.code || '')}</b> ${esc(eq.name || '')}</p>
      ${eq.reason ? `<div class="m-dnote">หยุดเพราะ: ${esc(eq.reason)}${eq.since ? ` · ตั้งแต่ ${esc(ECS.fmt ? ECS.fmt(eq.since, true) : eq.since)}` : ''}</div>` : ''}
      <label class="rp-lbl" for="rnNote">บันทึกเพิ่มเติม <span class="muted small">(ไม่บังคับ)</span></label>
      <textarea class="m-input" id="rnNote" rows="2" maxlength="300" placeholder="เช่น PM เสร็จแล้ว / เปลี่ยนอะไหล่แล้ว"></textarea>
      <div class="m-dnote">รอบตรวจที่ยังอยู่ในช่วงเวลาจะกลับมาให้ตรวจตามปกติ</div>
      <button type="button" class="m-btn m-btn-primary m-btn-block" id="rnOk">ยืนยัน เครื่องเดินแล้ว</button>
      <button type="button" class="m-btn m-btn-block" data-x>ยกเลิก</button>`);
    s.wrap.querySelector('#rnOk').onclick = async ev => {
      const b = ev.currentTarget; b.disabled = true; b.textContent = 'กำลังบันทึก…';
      try {
        const d = await post(`/api/m/equipment/${eq.id}/running`, { note: s.wrap.querySelector('#rnNote').value });
        s.close(); toast(`${d.code} กลับมาเดินแล้ว — เปิดรอบตรวจคืน ${d.restored} รอบ`, true); if (done) done(d);
      } catch (e) { b.disabled = false; b.textContent = 'ยืนยัน เครื่องเดินแล้ว'; toast(e.message); }
    };
  }

  // ปุ่มในหน้าใดก็ได้: <button data-eqdown='{"id":1,"code":"..."}'> / <button data-eqrun='{...}'>
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-eqdown],[data-eqrun]'); if (!b) return;
    e.preventDefault(); e.stopPropagation();
    let eq = {}; try { eq = JSON.parse(b.dataset.eqdown || b.dataset.eqrun); } catch (x) { return; }
    const after = () => document.dispatchEvent(new CustomEvent('ecs:eqstatus', { detail: eq }));
    (b.dataset.eqdown ? downSheet : runSheet)(eq, after);
  });
  window.ECSDown = { downSheet, runSheet };
})();
