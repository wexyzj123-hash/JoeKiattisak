/* energy.js — v0.64 จดมิเตอร์หน้างาน (หน้าเดียว ใช้ต่อได้แม้สัญญาณหลุด)
 * #            รายการมิเตอร์ (ตาม Section) + ความคืบหน้าวันนี้ + สแกน QR
 * #m=ID[&d=วัน] การ์ดจดค่า: ค่าครั้งก่อน · ช่วงที่ควรเป็น · ตรวจตกหลัก/วนรอบ · รูปหน้าปัด · อ่านเลขจากรูป
 * #s=ID        อ่านไม่ได้ (เหตุผล + แจ้งซ่อม)     #w=ID  เปลี่ยนมิเตอร์
 * บันทึกเข้าคิวในเครื่อง (outbox เดียวกับผลตรวจ) แล้วส่งทันทีถ้ามีสัญญาณ */
(function () {
  'use strict';
  const { esc } = ECS;
  const app = document.getElementById('enApp');
  const photoIn = document.getElementById('enPhoto');
  const CFG = window.EN_CFG || {};
  const EP = '/api/m/energy/submit';
  let P = null, stale = null, kind = '', q = '', fac = '', showAuto = false, form = '';
  let st = {};                    // สถานะการ์ดปัจจุบัน: {photo, photoUrl, box, rollover, ...}
  const nf = (x, d) => (x == null || isNaN(x) ? '–' : Number(x).toLocaleString('th-TH', { maximumFractionDigits: d == null ? 2 : d }));
  const dm = (d) => (d ? d.slice(8, 10) + '/' + d.slice(5, 7) : '–');
  const hm = (t) => (t ? String(t).slice(11, 16) : '');

  function toast(msg, ok) {
    const t = document.createElement('div'); t.className = 'm-toast ' + (ok ? 'ok' : 'err'); t.textContent = msg;
    document.body.appendChild(t); setTimeout(() => t.remove(), 2600);
  }
  try { fac = localStorage.getItem('en_fac') || ''; kind = localStorage.getItem('en_kind') || ''; form = localStorage.getItem('en_form') || ''; } catch (e) { /* */ }
  // v0.66 แบบฟอร์มการจด: ลำดับ/หัวข้อ/คำแนะนำ/บังคับรูป ตามที่ออกแบบไว้
  const curForm = () => (form && P && (P.forms || []).find((f) => String(f.id) === String(form))) || null;
  const setForm = (v) => { form = v ? String(v) : ''; try { localStorage.setItem('en_form', form); } catch (e) { /* */ } };
  function itemOf(m) { const f = curForm(); return f ? f.items.find((i) => i.type === 'meter' && i.meter_id === m.id) || null : null; }
  function orderList() {                 // มิเตอร์ตามลำดับการจด (แบบฟอร์ม หรือ หมวด/Section)
    const f = curForm();
    if (f) return f.items.filter((i) => i.type === 'meter').map((i) => P.meters.find((x) => x.id === i.meter_id)).filter(Boolean);
    return P.meters.filter((x) => !x.auto && (!kind || x.kind === kind));
  }

  // ───────── ข้อมูล ─────────
  async function load(force) {
    try {
      P = await ECS.getJson('/api/m/energy/pack' + (fac ? '?factory=' + fac : ''));
      stale = null;
      await ECS.kv.put('energy_pack', P);
    } catch (e) {
      if (e.status === 401) { location.href = U('/login') + '?next=' + encodeURIComponent(location.pathname + location.hash); return; }
      const c = await ECS.kv.get('energy_pack');
      if (!c) { app.innerHTML = '<div class="m-empty"><strong>ต้องมีสัญญาณครั้งแรก</strong><br>เปิดหน้านี้ตอนมีสัญญาณหนึ่งครั้ง ระบบจะเก็บรายการมิเตอร์ไว้ในเครื่อง</div>'; return; }
      P = c; stale = c.now;
    }
    await applyQueue();
    if (P.cfg && P.cfg.ocr && navigator.onLine && window.ECSOCR) setTimeout(() => ECSOCR.warm().catch(() => {}), 1500);
    route();
  }
  // ค่าที่ยังรอส่ง → แสดงในรายการทันที
  async function applyQueue() {
    const s = await ECS.status();
    const by = {};
    for (const it of s.items) if (it.endpoint === EP) by[it.payload.meter_id + ':' + it.payload.day] = it;
    for (const m of P.meters) {
      const it = by[m.id + ':' + P.today];
      m.queued = it ? (it.status === 'rejected' ? 'rejected' : 'pending') : null;
      if (it && it.status !== 'rejected') {
        if (it.payload.type === 'skip') m.skip = { reason: it.payload.reason, note: it.payload.note };
        else m.today = { v: it.payload.type === 'swap' ? Number(it.payload.swap.new_value || it.payload.swap.new_start || 0) : Number(it.payload.value), at: it.payload.read_at, local: true };
      }
    }
  }
  const meter = (id) => P.meters.find((m) => String(m.id) === String(id));
  const K = (m) => P.kinds[m.kind] || { th: m.kind, unit: m.unit, icon: '•', color: '#64748b' };

  // ค่าที่ควรเป็นของวัน d (วันนี้ใช้จากเซิร์ฟเวอร์ · ย้อนหลังคำนวณจากประวัติในเครื่อง)
  function expectFor(m, d) {
    if (d === P.today) return Object.assign({}, m.ex);
    const pts = m.hist.map((h) => ({ day: h.day, v: h.v }));
    if (m.today && m.today.v != null) pts.push({ day: P.today, v: m.today.v });
    pts.sort((a, b) => (a.day < b.day ? -1 : 1));
    const prev = pts.filter((x) => x.day < d).pop(), next = pts.find((x) => x.day > d);
    const ex = { prev: prev ? prev.v : null, prev_day: prev ? prev.day : null, next: next ? next.v : null, next_day: next ? next.day : null,
      digits: m.ex.digits, mult: m.mult, typ: m.ex.typ, lo: prev ? prev.v : null, hi: null };
    if (prev && m.ex.hi != null && m.ex.prev != null && m.ex.days) {
      const per = (m.ex.hi - m.ex.prev) / m.ex.days, days = Math.max(1, Math.round((new Date(d) - new Date(prev.day)) / 864e5));
      ex.hi = prev.v + per * days;
    }
    return ex;
  }
  const digitsOf = (v) => String(Math.trunc(Math.abs(v))).length;
  function check(ex, v) {
    const out = { level: 'ok', msgs: [], u: null, rollover: null };
    const mult = ex.mult || 1;
    if (ex.prev == null) { out.msgs.push('ค่าแรกของมิเตอร์นี้'); return out; }
    if (v < ex.prev) {
      out.level = 'bad'; out.msgs.push(`น้อยกว่าครั้งก่อน (${nf(ex.prev)})`);
      if (ex.digits) { const mod = Math.pow(10, ex.digits), ru = mod - ex.prev + v;
        if (ru > 0 && (ex.hi == null || ex.prev + ru <= ex.hi || ru < mod * 0.02)) out.rollover = Math.round(ru * mult * 1e4) / 1e4; }
    } else {
      out.u = Math.round((v - ex.prev) * mult * 1e4) / 1e4;
      if (ex.next != null && v > ex.next) { out.level = 'bad'; out.msgs.push(`มากกว่าค่าวันถัดไป (${nf(ex.next)} · ${dm(ex.next_day)})`); }
      if (ex.hi != null && v > ex.hi) { if (out.level === 'ok') out.level = 'warn'; out.msgs.push(ex.typ != null ? `สูงกว่าปกติ (ปกติ ~${nf(ex.typ)}/วัน)` : 'สูงกว่าปกติ'); }
    }
    if (ex.digits && digitsOf(v) !== ex.digits && !(v < ex.prev && out.rollover != null)) {
      if (out.level === 'ok') out.level = 'warn';
      out.msgs.push(`จำนวนหลักไม่ตรง (เดิม ${ex.digits} หลัก · ใส่ ${digitsOf(v)} หลัก)`);
    }
    return out;
  }

  // ───────── หน้าแรก: รายการ ─────────
  function statusOf(m) {
    if (m.queued === 'rejected') return { cls: 'bad', txt: '⚠ ส่งไม่ผ่าน' };
    if (m.skip) return { cls: 'skip', txt: '⛔ ' + (P.reasons[m.skip.reason] || 'อ่านไม่ได้') };
    if (m.today && m.today.v != null) return { cls: m.queued ? 'queued' : 'done', txt: (m.queued ? '⏳ ' : '✓ ') + nf(m.today.v) + (m.today.at ? ' · ' + hm(m.today.at) : '') };
    if (m.auto) return { cls: 'auto', txt: '🔌 อัตโนมัติ' };
    return { cls: 'todo', txt: 'รอจด' };
  }
  function listView() {
    const all = P.meters, f = curForm();
    if (form && !f) setForm('');
    const kinds = P.kind_order.filter((k) => all.some((m) => m.kind === k));
    const match = (m) => !q || (m.label + ' ' + m.grp + ' ' + m.loc + ' ' + m.code).toLowerCase().includes(q);
    const ms = f ? orderList().filter(match) : all.filter((m) => (!kind || m.kind === kind) && match(m));
    const manual = f ? ms : ms.filter((m) => !m.auto), auto = f ? [] : ms.filter((m) => m.auto);
    const isDone = (m) => m.skip || (m.today && m.today.v != null);
    const done = manual.filter(isDone).length;
    const pct = manual.length ? Math.round(100 * done / manual.length) : 100;
    let h = '';
    if (stale) h += `<div class="m-stale"><i class=ei-phoneoff aria-hidden=true></i> ออฟไลน์ — ใช้รายการที่เก็บไว้เมื่อ ${ECS.fmt(stale, true)} · ค่าที่จดจะส่งเมื่อมีสัญญาณ</div>`;
    if (P.factories.length > 1) h += `<select class="m-input en-fac" id="enFac"><option value="">ทุกโรงงาน</option>${P.factories.map((x) => `<option value="${x.id}" ${String(x.id) === String(fac) ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>`;
    if ((P.forms || []).length) h += `<select class="m-input en-fac" id="enForm" aria-label="แบบฟอร์มการจด"><option value="">📋 ทุกมิเตอร์ (ตามหมวด/Section)</option>${P.forms.map((x) => `<option value="${x.id}" ${f && f.id === x.id ? 'selected' : ''}>📋 ${esc(x.name)} (${x.items.filter((i) => i.type === 'meter').length})</option>`).join('')}</select>`;
    h += `<div class="en-prog"><div><b>${done}</b>/${manual.length} มิเตอร์ <span class="muted">· วันนี้ ${ECS.fmtDate(P.today)}</span></div>
      <div class="m-routebar"><div style="width:${pct}%"></div></div>${f && f.note ? `<div class="small muted">${esc(f.note)}</div>` : ''}</div>
      <button type="button" class="m-btn m-btn-primary m-btn-block m-btn-lg" id="enQR">📷 สแกน QR ที่มิเตอร์</button>
      ${f ? '' : `<div class="en-kinds"><button type="button" data-k="" class="${!kind ? 'on' : ''}">ทั้งหมด</button>${kinds.map((k) => `<button type="button" data-k="${k}" class="${kind === k ? 'on' : ''}" style="--kc:${P.kinds[k].color}"><i></i>${P.kinds[k].icon} ${esc(P.kinds[k].th)}</button>`).join('')}</div>`}
      <input type="search" class="m-input" id="enQ" placeholder="ค้นหา: No. / ชื่อ / Section / ตำแหน่ง" value="${esc(q)}">`;
    let g = null;
    const row = (m, no) => { const s = statusOf(m), k = K(m);
      return `<a class="en-row ${s.cls}" href="#m=${m.id}" style="--kc:${k.color}"><div class="en-row-main"><div class="en-row-t">${no ? `<span class="en-no">${no}</span>` : ''}${k.icon} ${esc(m.label)}</div>
        <div class="en-row-s">${esc([m.loc, m.factory && !fac ? m.factory : ''].filter(Boolean).join(' · '))}</div></div><div class="en-st">${esc(s.txt)}</div></a>`; };
    const todo = manual.filter((m) => !isDone(m));
    if (todo.length && todo.length < manual.length) h += `<a class="m-btn m-btn-block" href="#m=${todo[0].id}">▶ จดต่อตัวถัดไป (${esc(todo[0].label)})</a>`;
    else if (todo.length && f) h += `<a class="m-btn m-btn-block" href="#m=${todo[0].id}">▶ เริ่มจดตามลำดับ (${esc(todo[0].label)})</a>`;
    if (f) {
      let n = 0;
      const show = new Set(manual.map((m) => m.id));
      for (const it of f.items) {
        if (it.type === 'header') { if (!q) h += `<h2 class="m-h">${esc(it.title)}</h2>`; continue; }
        const m = P.meters.find((x) => x.id === it.meter_id); if (!m) continue; n++;
        if (show.has(m.id)) h += row(m, n);
      }
    } else for (const m of manual) { if (m.grp !== g) { g = m.grp; h += `<h2 class="m-h">${esc(g || 'ทั่วไป')}</h2>`; } h += row(m); }
    if (!manual.length && !auto.length) h += '<div class="m-empty">ไม่พบมิเตอร์</div>';
    if (auto.length) h += `<details class="en-auto" ${showAuto ? 'open' : ''}><summary>🔌 อ่านอัตโนมัติจาก SCADA (${auto.length}) — จดเองเมื่อ SCADA ขาด</summary>${auto.map((m) => row(m)).join('')}</details>`;
    app.innerHTML = h;
    const sf = app.querySelector('#enFac'); if (sf) sf.onchange = () => { fac = sf.value; try { localStorage.setItem('en_fac', fac); } catch (e) { /* */ } load(); };
    const sfm = app.querySelector('#enForm'); if (sfm) sfm.onchange = () => { setForm(sfm.value); listView(); };
    app.querySelectorAll('.en-kinds button').forEach((b) => b.onclick = () => { kind = b.dataset.k; try { localStorage.setItem('en_kind', kind); } catch (e) { /* */ } listView(); });
    const qi = app.querySelector('#enQ'); qi.oninput = () => { q = qi.value.trim().toLowerCase(); const pos = qi.selectionStart; listView(); const nn = app.querySelector('#enQ'); nn.focus(); nn.setSelectionRange(pos, pos); };
    const det = app.querySelector('.en-auto'); if (det) det.ontoggle = () => { showAuto = det.open; };
    app.querySelector('#enQR').onclick = scanQR;
  }
  async function scanQR() {
    const v = await ECS.photoQR(); if (!v) return;
    const mt = String(v).match(/\/q\/([A-Za-z0-9_-]+)\/?$/);
    const m = mt && P.meters.find((x) => x.tok === mt[1]);
    if (m) { location.hash = 'm=' + m.id; return; }
    toast(mt ? 'มิเตอร์นี้ไม่อยู่ในรายการของคุณ (ต่างโรงงาน/ปิดใช้งาน)' : 'QR นี้ไม่ใช่ป้ายมิเตอร์ของ Energy Data');
  }

  // ───────── การ์ดจดค่า ─────────
  function resetState(m) {
    if (st.photoUrl) URL.revokeObjectURL(st.photoUrl);
    st = { id: m.id, photo: null, photoUrl: null, box: m.box || null, rollover: false, cands: [] };
  }
  function photoBlock(required, noOcr) {
    const ocr = P.cfg.ocr && !noOcr;
    return `<div class="en-photo">${st.photoUrl ? `<div class="en-crop" id="enCrop"><img src="${st.photoUrl}" alt="รูปหน้าปัด" id="enImg"><div class="en-box" id="enBox"><i class="tl"></i><i class="br"></i></div></div>
        <div class="en-pbtns">${ocr ? '<button type="button" class="m-btn m-btn-sm m-btn-primary" id="enOcr">🔎 อ่านเลขจากรูป</button>' : ''}
        <button type="button" class="m-btn m-btn-sm" id="enRetake">📷 ถ่ายใหม่</button></div>
        ${ocr ? '<div class="small muted">ลากกรอบสีฟ้าให้ครอบเฉพาะตัวเลข — ระบบจำกรอบของมิเตอร์นี้ไว้ใช้ครั้งหน้า</div>' : ''}<div id="enCands"></div>`
      : `<button type="button" class="m-btn m-btn-block ${required ? 'm-btn-warn' : ''}" id="enShot">📷 ถ่ายรูปหน้าปัด${required ? ' (จำเป็น)' : ''}${ocr ? ' · อ่านเลขอัตโนมัติ' : ''}</button>`}</div>`;
  }
  function hookPhoto(after) {
    const shot = () => { photoIn.value = ''; photoIn.onchange = async () => {
      const f = photoIn.files && photoIn.files[0]; if (!f) return;
      const b = await ECS.resizeImage(f, 1600, 0.85);
      if (st.photoUrl) URL.revokeObjectURL(st.photoUrl);
      st.photo = b; st.photoUrl = URL.createObjectURL(b); after(true);
    }; photoIn.click(); };
    const a = app.querySelector('#enShot'); if (a) a.onclick = shot;
    const r = app.querySelector('#enRetake'); if (r) r.onclick = shot;
    const crop = app.querySelector('#enCrop'); if (crop) cropper(crop);
  }
  // กรอบตัดตัวเลข: ลากเพื่อย้าย · ลากมุมเพื่อย่อ/ขยาย (สัดส่วน 0–1 ของรูป)
  function cropper(wrap) {
    const box = wrap.querySelector('#enBox');
    if (!st.box) st.box = [0.1, 0.35, 0.8, 0.3];
    const draw = () => { const [x, y, w, h] = st.box; Object.assign(box.style, { left: x * 100 + '%', top: y * 100 + '%', width: w * 100 + '%', height: h * 100 + '%' }); };
    draw();
    let mode = null, sx = 0, sy = 0, b0 = null;
    const pt = (e) => { const r = wrap.getBoundingClientRect(); return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]; };
    box.addEventListener('pointerdown', (e) => { e.preventDefault(); box.setPointerCapture(e.pointerId);
      mode = e.target.classList.contains('tl') ? 'tl' : e.target.classList.contains('br') ? 'br' : 'mv'; [sx, sy] = pt(e); b0 = st.box.slice(); });
    box.addEventListener('pointermove', (e) => { if (!mode) return; const [x, y] = pt(e), dx = x - sx, dy = y - sy; let [bx, by, bw, bh] = b0;
      if (mode === 'mv') { bx = Math.min(1 - bw, Math.max(0, bx + dx)); by = Math.min(1 - bh, Math.max(0, by + dy)); }
      if (mode === 'tl') { const nx = Math.min(bx + bw - 0.05, Math.max(0, bx + dx)), ny = Math.min(by + bh - 0.04, Math.max(0, by + dy)); bw += bx - nx; bh += by - ny; bx = nx; by = ny; }
      if (mode === 'br') { bw = Math.min(1 - bx, Math.max(0.05, bw + dx)); bh = Math.min(1 - by, Math.max(0.04, bh + dy)); }
      st.box = [bx, by, bw, bh].map((v) => Math.round(v * 1e4) / 1e4); draw(); });
    box.addEventListener('pointerup', () => { mode = null; });
  }
  async function runOcr(m, ex, inp, onPick) {
    const out = app.querySelector('#enCands'); if (!out || !st.photo) return;
    out.innerHTML = '<div class="small muted">⏳ กำลังอ่านตัวเลข… (ครั้งแรกอาจใช้เวลาหลายวินาที)</div>';
    try {
      const r = await ECSOCR.read(st.photo, st.box, ex);
      st.cands = r.best;
      if (r.box && r.box !== st.box) {                       // พบจอตัวเลขเอง → ย้ายกรอบให้เห็น
        st.box = r.box;
        const bx = app.querySelector('#enBox');
        if (bx) Object.assign(bx.style, { left: st.box[0] * 100 + '%', top: st.box[1] * 100 + '%', width: st.box[2] * 100 + '%', height: st.box[3] * 100 + '%' });
      }
      if (!r.best.length) { out.innerHTML = '<div class="m-err">อ่านตัวเลขไม่ออก — ปรับกรอบให้ครอบเฉพาะตัวเลข/ถ่ายให้ชัดขึ้น หรือพิมพ์เอง</div>'; return; }
      const top = r.best[0];
      if (!inp.value.trim()) { inp.value = top.value; onPick(); }
      out.innerHTML = `<div class="en-cands"><span class="small">อ่านได้:</span>${r.best.map((c, i) => `<button type="button" class="en-cand ${i === 0 ? 'on' : ''}" data-v="${esc(c.value)}">${esc(c.value)}</button>`).join('')}</div>
        <div class="small en-ocrnote">⚠ ตรวจให้ตรงกับหน้าปัดก่อนบันทึก</div>`;
      out.querySelectorAll('.en-cand').forEach((b) => b.onclick = () => { inp.value = b.dataset.v; out.querySelectorAll('.en-cand').forEach((x) => x.classList.toggle('on', x === b)); onPick(); });
      inp.classList.add('en-ocr');
    } catch (e) { out.innerHTML = `<div class="m-err">${esc(e.message || 'อ่านเลขไม่สำเร็จ')} — ต้องเปิดหน้านี้ตอนมีสัญญาณครั้งแรกเพื่อโหลดตัวอ่าน</div>`; }
  }

  function cardView(m, d) {
    const k = K(m), ex = expectFor(m, d), isToday = d === P.today;
    const cur = isToday ? (m.today && m.today.v != null ? m.today.v : null) : ((m.hist.find((h) => h.day === d) || {}).v ?? null);
    const editing = cur != null;
    const fit = itemOf(m);
    const rule = fit && fit.photo ? 2 : P.cfg.photo_rule;
    const lim = P.cfg.tech_back_days, back = Math.round((new Date(P.today) - new Date(d)) / 864e5);
    const locked = editing && !P.lead && lim && back > lim;
    const hist = [];
    if (m.today && m.today.v != null) hist.push({ day: P.today, v: m.today.v, src: m.today.src });
    m.hist.forEach((h) => hist.push(h));
    const skipToday = isToday && m.skip;
    let h = `<a class="en-back" href="#">‹ รายการมิเตอร์</a>
      <div class="en-card" style="--kc:${k.color}"><div class="en-card-k">${k.icon} ${esc(k.th)} · ${esc(m.factory)}${m.grp ? ' · ' + esc(m.grp) : ''}${m.auto ? ' · 🔌 SCADA' : ''}</div>
      <div class="en-card-t">${esc(m.label)}</div>${m.loc ? `<div class="en-card-s">📍 ${esc(m.loc)}</div>` : ''}
      ${fit && fit.hint ? `<div class="en-hint">💡 ${esc(fit.hint)}</div>` : ''}${fit && fit.photo ? '<div class="en-card-s">📷 แบบฟอร์มนี้กำหนดให้ถ่ายรูปหน้าปัดทุกครั้ง</div>' : ''}
      ${m.mult !== 1 ? `<div class="en-card-s">ตัวคูณ CT ×${nf(m.mult, 6)} — กรอกเลขบนหน้าปัดตามจริง ระบบคูณให้เอง</div>` : ''}
      ${!isToday ? `<div class="m-stale">✏️ ${editing ? 'แก้ค่า' : 'ลงค่าย้อนหลัง'}วันที่ ${ECS.fmtDate(d)}</div>` : ''}
      ${skipToday ? `<div class="m-stale">⛔ แจ้งอ่านไม่ได้แล้ว: ${esc(P.reasons[m.skip.reason] || '')}${m.skip.note ? ' · ' + esc(m.skip.note) : ''} — กรอกค่าด้านล่างถ้าอ่านได้แล้ว</div>` : ''}
      <div class="en-ref"><div><small>ครั้งก่อน${ex.prev_day ? ' · ' + dm(ex.prev_day) : ''}</small><b>${nf(ex.prev)}</b></div>
        <div><small>ควรอยู่ระหว่าง</small><b>${ex.hi != null ? nf(ex.lo, 0) + ' – ' + nf(ex.hi, 0) : (ex.prev != null ? '≥ ' + nf(ex.prev) : '–')}</b></div>
        <div><small>ปกติ/วัน</small><b>${ex.typ != null ? nf(ex.typ) + ' ' + esc(m.unit) : '–'}</b></div></div>
      ${locked ? `<div class="m-err">แก้ค่าย้อนหลังได้ไม่เกิน ${lim} วัน — แจ้งหัวหน้างานให้แก้</div>` : ''}
      <label class="en-lbl" for="enV">เลขหน้าปัด${editing ? ' (แก้จาก ' + nf(cur) + ')' : ''}</label>
      <input id="enV" class="en-big" inputmode="decimal" autocomplete="off" placeholder="${ex.prev != null ? nf(ex.prev).replace(/,/g, '') : '0'}" value="${editing ? cur : ''}" ${locked ? 'disabled' : ''}>
      <div id="enLive" class="en-live"></div>
      <div id="enRoll"></div>
      ${photoBlock(false)}
      <label class="en-lbl" for="enNote" id="enNoteL">หมายเหตุ</label>
      <input id="enNote" class="m-input" maxlength="300" placeholder="${editing ? 'เหตุผลที่แก้ (จำเป็น)' : 'ไม่บังคับ — จำเป็นเมื่อค่าผิดปกติ'}">
      <label class="en-confirm" id="enConfL" hidden><input type="checkbox" id="enConf"> ตรวจเลขบนหน้าปัดแล้ว ค่านี้ถูกต้อง</label>
      <div id="enErr"></div>
      <button type="button" class="m-btn m-btn-primary m-btn-block m-btn-lg" id="enSave" ${locked ? 'disabled' : ''}>💾 บันทึก${isToday ? ' → ตัวถัดไป' : ''}</button>
      ${isToday && !editing ? `<div class="en-sec"><a class="m-btn" href="#s=${m.id}">⛔ อ่านไม่ได้</a><a class="m-btn" href="#w=${m.id}">🔁 เปลี่ยนมิเตอร์</a></div>` : (isToday ? `<div class="en-sec"><a class="m-btn" href="#w=${m.id}">🔁 เปลี่ยนมิเตอร์</a></div>` : '')}
      </div>
      <h2 class="m-h">ประวัติ 7 วัน <small class="muted">— แตะเพื่อแก้</small></h2>
      <div class="en-hist">${hist.length ? hist.map((x, i) => { const pv = hist[i + 1]; const u = pv ? (x.v - pv.v) * m.mult : null;
        return `<a href="#m=${m.id}&d=${x.day}" class="${x.day === d ? 'on' : ''}"><span>${dm(x.day)}</span><b>${nf(x.v)}</b><small>${u != null ? (u < 0 ? '⚠ ' : '') + nf(u) + ' ' + esc(m.unit) : ''}</small>${x.src === 'scada' ? '<i>🔌</i>' : ''}</a>`; }).join('') : '<div class="muted small">ยังไม่มีค่า</div>'}
        ${Object.keys(m.skips || {}).map((dd) => `<div class="en-hskip">${dm(dd)} ⛔ ${esc(P.reasons[m.skips[dd]] || '')}</div>`).join('')}</div>
      <div class="m-links"><a href="${U(CFG.desk.replace(/0$/, m.id))}">ดูกราฟ/ตั้งค่ามิเตอร์ ›</a></div>`;
    app.innerHTML = h;
    const inp = app.querySelector('#enV'), live = app.querySelector('#enLive'), roll = app.querySelector('#enRoll');
    const note = app.querySelector('#enNote'), confL = app.querySelector('#enConfL'), noteL = app.querySelector('#enNoteL');
    let last = null;
    const update = () => {
      const raw = inp.value.replace(/,/g, '').trim();
      inp.classList.remove('warn', 'bad', 'ok');
      roll.innerHTML = ''; confL.hidden = true; last = null;
      if (!raw) { live.innerHTML = ''; return; }
      const v = Number(raw);
      if (!isFinite(v) || v < 0) { inp.classList.add('bad'); live.innerHTML = '<span class="bad">ไม่ใช่ตัวเลข</span>'; return; }
      const c = check(ex, v); last = c;
      if (st.rollover && c.rollover == null) st.rollover = false;
      inp.classList.add(st.rollover ? 'ok' : c.level);
      const uu = st.rollover ? c.rollover : c.u;
      live.innerHTML = `${uu != null ? `<div class="en-use">ใช้ <b>${nf(uu)}</b> ${esc(m.unit)}${st.rollover ? ' (มิเตอร์วนรอบ)' : ''}</div>` : ''}` +
        (st.rollover ? '' : c.msgs.map((x) => `<div class="${c.level === 'ok' ? 'muted' : c.level}">${c.level === 'ok' ? 'ℹ' : '⚠'} ${esc(x)}</div>`).join(''));
      if (c.rollover != null) roll.innerHTML = `<button type="button" class="m-btn m-btn-sm ${st.rollover ? 'm-btn-primary' : ''}" id="enRo">🔄 ${st.rollover ? 'ใช้แบบมิเตอร์วนรอบแล้ว' : 'มิเตอร์วนรอบ? (ใช้ ' + nf(c.rollover) + ' ' + esc(m.unit) + ')'}</button>`;
      const b = roll.querySelector('#enRo'); if (b) b.onclick = () => { st.rollover = !st.rollover; update(); };
      const abn = c.level !== 'ok' && !st.rollover;
      confL.hidden = !abn;
      noteL.textContent = abn || editing ? 'หมายเหตุ (จำเป็น)' : 'หมายเหตุ';
      const needPhoto = rule >= 2 || (rule >= 1 && (abn || st.rollover));
      const shotBtn = app.querySelector('#enShot'); if (shotBtn) { shotBtn.classList.toggle('m-btn-warn', needPhoto); shotBtn.firstChild && (shotBtn.textContent = '📷 ถ่ายรูปหน้าปัด' + (needPhoto ? ' (จำเป็น)' : '') + (P.cfg.ocr ? ' · อ่านเลขอัตโนมัติ' : '')); }
    };
    inp.oninput = update; update();
    inp.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); app.querySelector('#enSave').click(); } };
    const rerender = (fresh) => {          // หลังถ่ายรูป: วาดส่วนรูปใหม่ (คงค่าที่พิมพ์ไว้)
      const keep = { v: inp.value, n: note.value, c: app.querySelector('#enConf').checked };
      app.querySelector('.en-photo').outerHTML = photoBlock(false);
      hookPhoto(rerender);
      const o = app.querySelector('#enOcr'); if (o) o.onclick = () => runOcr(m, ex, inp, update);
      inp.value = keep.v; note.value = keep.n; app.querySelector('#enConf').checked = keep.c; update();
      if (fresh && P.cfg.ocr && window.ECSOCR) runOcr(m, ex, inp, update);
    };
    hookPhoto(rerender);
    if (!editing && !locked && !('ontouchstart' in window)) inp.focus();
    app.querySelector('#enSave').onclick = async () => {
      const err = app.querySelector('#enErr'); err.innerHTML = '';
      const raw = inp.value.replace(/,/g, '').trim();
      if (!raw) { err.innerHTML = '<div class="m-err">กรอกเลขหน้าปัด หรือกด “อ่านไม่ได้”</div>'; return; }
      update();
      if (!last) { err.innerHTML = '<div class="m-err">เลขไม่ถูกต้อง</div>'; return; }
      const abn = last.level !== 'ok' && !st.rollover;
      if (abn && !app.querySelector('#enConf').checked) { err.innerHTML = '<div class="m-err">ค่าผิดปกติ — ตรวจเลขบนหน้าปัดอีกครั้ง แล้วติ๊ก “ค่านี้ถูกต้อง”</div>'; return; }
      if ((abn || editing) && note.value.trim().length < 2) { err.innerHTML = `<div class="m-err">${editing ? 'แก้ค่าต้องระบุเหตุผล' : 'ค่าผิดปกติต้องใส่หมายเหตุ'}</div>`; note.focus(); return; }
      if (!st.photo && (rule >= 2 || (rule >= 1 && (abn || st.rollover)))) { err.innerHTML = '<div class="m-err">ต้องถ่ายรูปหน้าปัด</div>'; return; }
      await submit(m, { type: 'read', day: d, value: raw, note: note.value.trim(), confirm: abn, rollover: !!st.rollover }, d === P.today);
    };
  }

  // ───────── อ่านไม่ได้ ─────────
  function skipView(m) {
    let reason = '';
    app.innerHTML = `<a class="en-back" href="#m=${m.id}">‹ กลับไปจดค่า</a><div class="en-card" style="--kc:${K(m).color}">
      <div class="en-card-t">⛔ อ่านไม่ได้ — ${esc(m.label)}</div><div class="en-card-s">เลือกเหตุผล (ระบบจะไม่นับว่า “ไม่ได้จด”)</div>
      <div class="en-reasons">${(P.reason_order || Object.keys(P.reasons)).map((k) => [k, P.reasons[k]]).map(([k, v]) => `<button type="button" class="m-btn m-btn-block" data-r="${k}">${esc(v)}</button>`).join('')}</div>
      <div id="enWo"></div>${photoBlock(false, true)}
      <label class="en-lbl" for="enNote">รายละเอียด</label><input id="enNote" class="m-input" maxlength="300" placeholder="เช่น จอดับ ไม่มีไฟเลี้ยง">
      <div id="enErr"></div><button type="button" class="m-btn m-btn-primary m-btn-block m-btn-lg" id="enSave">บันทึก</button></div>`;
    app.querySelectorAll('[data-r]').forEach((b) => b.onclick = () => {
      reason = b.dataset.r; app.querySelectorAll('[data-r]').forEach((x) => x.classList.toggle('m-btn-primary', x === b));
      app.querySelector('#enWo').innerHTML = reason === 'broken' ? (m.has_eq ? '<label class="en-confirm"><input type="checkbox" id="enWoC" checked> เปิดใบแจ้งซ่อม UT-CMMS ทันที</label>'
        : '<div class="small muted">ระบบเปิดเคสติดตามให้หัวหน้างาน · ผูกเครื่อง/ตู้ในหน้ามิเตอร์ เพื่อเปิดใบแจ้งซ่อม UT-CMMS อัตโนมัติ</div>') : '';
    });
    const re = (fresh) => { const n = app.querySelector('#enNote').value; app.querySelector('.en-photo').outerHTML = photoBlock(false, true); hookPhoto(re); app.querySelector('#enNote').value = n; const o = app.querySelector('#enOcr'); if (o) o.remove(); };
    hookPhoto(re);
    app.querySelector('#enSave').onclick = async () => {
      const err = app.querySelector('#enErr'), note = app.querySelector('#enNote').value.trim();
      if (!reason) { err.innerHTML = '<div class="m-err">เลือกเหตุผล</div>'; return; }
      if (reason === 'other' && !note) { err.innerHTML = '<div class="m-err">ระบุรายละเอียด</div>'; return; }
      const wo = app.querySelector('#enWoC');
      await submit(m, { type: 'skip', day: P.today, reason, note, wo: !!(wo && wo.checked) }, true);
    };
  }

  // ───────── เปลี่ยนมิเตอร์ ─────────
  function swapView(m) {
    const ex = m.ex;
    app.innerHTML = `<a class="en-back" href="#m=${m.id}">‹ กลับไปจดค่า</a><div class="en-card" style="--kc:${K(m).color}">
      <div class="en-card-t">🔁 เปลี่ยนมิเตอร์ — ${esc(m.label)}</div>
      <div class="en-card-s">ค่าครั้งก่อน ${nf(ex.prev)} (${dm(ex.prev_day)}) · CT ×${nf(m.mult, 6)}</div>
      <label class="en-lbl">เลขสุดท้ายของมิเตอร์เก่า (ตอนถอด)</label><input id="wOld" class="en-big" inputmode="decimal" placeholder="${ex.prev != null ? ex.prev : ''}">
      <label class="en-lbl">เลขเริ่มของมิเตอร์ใหม่</label><input id="wStart" class="m-input" inputmode="decimal" value="0">
      <label class="en-lbl">เลขปัจจุบันของมิเตอร์ใหม่ <small class="muted">(ว่าง = เท่ากับเลขเริ่ม)</small></label><input id="wNow" class="m-input" inputmode="decimal">
      <label class="en-lbl">CT ratio ของมิเตอร์ใหม่</label><input id="wCt" class="m-input" inputmode="decimal" value="${m.mult}">
      <div id="wCalc" class="en-live"></div>
      ${photoBlock(P.cfg.photo_rule >= 1)}
      <label class="en-lbl" for="enNote">รายละเอียด (จำเป็น)</label><input id="enNote" class="m-input" maxlength="300" placeholder="เช่น เปลี่ยนเพราะจอเสีย / S/N ใหม่">
      <div id="enErr"></div><button type="button" class="m-btn m-btn-primary m-btn-block m-btn-lg" id="enSave">บันทึกการเปลี่ยนมิเตอร์</button></div>`;
    const g = (id) => app.querySelector(id).value.replace(/,/g, '').trim();
    const calc = () => { const o = Number(g('#wOld')), s = Number(g('#wStart') || 0), n = g('#wNow') === '' ? s : Number(g('#wNow')), c = Number(g('#wCt') || m.mult);
      const out = app.querySelector('#wCalc');
      if (g('#wOld') === '' && ex.prev != null) { out.innerHTML = ''; return; }
      const u = (ex.prev != null ? (o - ex.prev) * m.mult : 0) + (n - s) * c;
      out.innerHTML = isFinite(u) ? `<div class="en-use">หน่วยของวันนี้ <b>${nf(u)}</b> ${esc(m.unit)}</div>` + (ex.prev != null && o < ex.prev ? '<div class="bad">⚠ เลขสุดท้ายน้อยกว่าค่าครั้งก่อน</div>' : '') : ''; };
    ['#wOld', '#wStart', '#wNow', '#wCt'].forEach((s) => app.querySelector(s).oninput = calc);
    const re = () => { const keep = ['#wOld', '#wStart', '#wNow', '#wCt', '#enNote'].map((s) => app.querySelector(s).value);
      app.querySelector('.en-photo').outerHTML = photoBlock(P.cfg.photo_rule >= 1); hookPhoto(re);
      ['#wOld', '#wStart', '#wNow', '#wCt', '#enNote'].forEach((s, i) => { app.querySelector(s).value = keep[i]; }); const o = app.querySelector('#enOcr'); if (o) o.remove(); calc(); };
    hookPhoto(re);
    app.querySelector('#enSave').onclick = async () => {
      const err = app.querySelector('#enErr'), note = app.querySelector('#enNote').value.trim();
      if (ex.prev != null && g('#wOld') === '') { err.innerHTML = '<div class="m-err">กรอกเลขสุดท้ายของมิเตอร์เก่า</div>'; return; }
      if (!note) { err.innerHTML = '<div class="m-err">ระบุรายละเอียด</div>'; return; }
      if (P.cfg.photo_rule >= 1 && !st.photo) { err.innerHTML = '<div class="m-err">ถ่ายรูปหน้าปัดมิเตอร์ใหม่</div>'; return; }
      await submit(m, { type: 'swap', day: P.today, note, swap: { old_final: g('#wOld'), new_start: g('#wStart') || '0', new_value: g('#wNow'), new_mult: g('#wCt') } }, true);
    };
  }

  // ───────── ส่ง ─────────
  async function submit(m, data, goNext) {
    const btn = app.querySelector('#enSave'); if (btn) { btn.disabled = true; btn.textContent = 'กำลังบันทึก…'; }
    const item = { client_uuid: ECS.uuid(), endpoint: EP, created_at: ECS.nowTs(), status: 'pending', photoIds: [],
      form_name: '⚡ ' + m.label + (data.day !== P.today ? ' (' + dm(data.day) + ')' : ''), edit_url: '/m/energy#m=' + m.id + '&d=' + data.day,
      payload: Object.assign({ client_uuid: null, meter_id: m.id, from: 'm', read_at: ECS.nowTs(), finished_at: ECS.nowTs(), box: st.photo ? st.box : null,
        form_id: curForm() ? curForm().id : null }, data) };
    item.payload.client_uuid = item.client_uuid;
    if (data.day !== P.today) item.payload.read_at = null;
    if (st.photo) { const pid = 'p' + ECS.uuid().replace(/-/g, '').slice(0, 16); await ECS.photos.put(pid, { blob: st.photo }); item.photoIds = [pid]; item.payload.photo = pid; }
    await ECS.outbox.put(item.client_uuid, item);
    let res = { state: 'offline' };
    if (navigator.onLine) { res = await ECS.sendOne(item); if (res.state === 'retry') { await ECS.ping(); res = await ECS.sendOne(item); } }
    if (res.state === 'rejected') {
      await ECS.outbox.del(item.client_uuid); for (const pid of item.photoIds) await ECS.photos.del(pid);
      const err = app.querySelector('#enErr'); if (err) err.innerHTML = `<div class="m-err">${(res.errors || ['บันทึกไม่สำเร็จ']).map(esc).join('<br>')}</div>`;
      if (btn) { btn.disabled = false; btn.textContent = '💾 บันทึก'; }
      return;
    }
    const sent = res.state === 'sent', r = (res.result || {});
    if (data.day === P.today) {
      if (data.type === 'skip') { m.skip = { reason: data.reason, note: data.note, wo: r.wo_number }; m.today = null; }
      else { m.skip = null; m.today = { v: r.value != null ? r.value : Number(data.type === 'swap' ? (data.swap.new_value || data.swap.new_start) : data.value), at: ECS.nowTs(), photo: r.photo }; }
      m.queued = sent ? null : 'pending';
    } else {
      const hh = m.hist.find((x) => x.day === data.day); if (hh) hh.v = Number(data.value); else m.hist.push({ day: data.day, v: Number(data.value) });
      m.hist.sort((a, b) => (a.day < b.day ? 1 : -1));
    }
    if (data.type === 'swap' && data.swap.new_mult) { m.mult = Number(data.swap.new_mult) || m.mult; m.ex.prev = Number(data.swap.new_value || data.swap.new_start); m.ex.hi = null; }
    if (st.photo && st.box) m.box = st.box;
    try { await ECS.kv.put('energy_pack', P); } catch (e) { /* */ }
    toast(sent ? (r.wo_number ? `✓ บันทึกแล้ว · เปิดใบแจ้งซ่อม ${r.wo_number}` : r.wo_error ? '✓ บันทึกแล้ว · ' + r.wo_error : '✓ บันทึกแล้ว') : '📴 บันทึกในเครื่องแล้ว — ส่งเมื่อมีสัญญาณ', true);
    ECS.status().then(ECS.renderNetBar);
    if (goNext) {
      const list = orderList();
      const i = list.findIndex((x) => x.id === m.id);
      const nxt = list.slice(i + 1).concat(list.slice(0, i)).find((x) => !(x.skip || (x.today && x.today.v != null)));
      location.hash = nxt ? 'm=' + nxt.id : '';
    } else location.hash = 'm=' + m.id;
  }

  // ───────── เส้นทาง ─────────
  function route() {
    if (!P) return;
    const hs = new URLSearchParams(location.hash.slice(1));
    if (hs.get('f')) { setForm(hs.get('f')); history.replaceState(null, '', location.pathname); }
    const id = hs.get('m') || hs.get('s') || hs.get('w');
    const m = id && meter(id);
    window.scrollTo(0, 0);
    if (id && !m) { toast('ไม่พบมิเตอร์นี้ในรายการของคุณ'); listView(); return; }
    if (!m) { listView(); return; }
    if (!st.id || st.id !== m.id || hs.get('m')) resetState(m);
    if (hs.get('s')) return skipView(m);
    if (hs.get('w')) return swapView(m);
    const d = hs.get('d') && /^\d{4}-\d{2}-\d{2}$/.test(hs.get('d')) && hs.get('d') <= P.today ? hs.get('d') : P.today;
    cardView(m, d);
  }
  window.addEventListener('hashchange', route);
  document.addEventListener('ecs:sent', (e) => { const it = e.detail.item; if (it.endpoint !== EP || !P) return;
    const m = meter(it.payload.meter_id); if (m && m.queued) { m.queued = null; if (!location.hash) listView(); } });
  ECS.status().then(ECS.renderNetBar);
  load();
})();
