/* v0.99.10 ปุ่มส่งผลตรวจแบบเครื่องบินกระดาษ — กดแล้ว: แถบ (wake) เลื่อนทับปุ่ม · เครื่องบินบินออก ·
   ตัวอักษรสถานะ "ลงจอด" ทีละตัว ตามผลจริงจากเซิร์ฟเวอร์ (ส่งถึงระบบ / เก็บในเครื่องรอส่ง / ส่งไม่ผ่าน)
   ไม่ใช่แค่ภาพเคลื่อนไหว: สถานะสุดท้ายแสดงหลังได้คำตอบจากเซิร์ฟเวอร์เท่านั้น */
(function () {
  'use strict';
  const PLANE = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4z"/></svg>';
  const reduce = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // แยกตัวอักษรแบบ grapheme (สระ/วรรณยุกต์ไทยติดกับพยัญชนะ ไม่หลุดเป็นตัวลอย)
  function graphemes(text) {
    if (window.Intl && Intl.Segmenter) return Array.from(new Intl.Segmenter('th', { granularity: 'grapheme' }).segment(text), x => x.segment);
    return text.match(/.[ัิ-ฺ็-๎]*/gu) || [];
  }

  function html(label, attrs) {
    return `<button type="button" class="sx" data-state="idle" ${attrs || ''}><span class="sx-wake" aria-hidden="true"></span>
      <span class="sx-go"><span class="sx-plane"><span class="sx-dash"></span>${PLANE}</span><span class="sx-word">${esc(label)}</span></span>
      <span class="sx-done" aria-live="polite"></span></button>`;
  }

  // กดส่ง → แถบเลื่อน + เครื่องบินบินออก (ระหว่างรอเซิร์ฟเวอร์: แถบวิ่ง "กำลังส่ง…")
  async function launch(btn) {
    btn.disabled = true;
    btn.style.setProperty('--fly', Math.round(btn.clientWidth * 0.62) + 'px');
    btn.dataset.state = 'go';
    btn.querySelector('.sx-done').innerHTML = '<span class="sx-wait">กำลังส่ง…</span>';
    await wait(reduce() ? 60 : 760);
    btn.classList.add('sx-waiting');
  }

  // ผลจริง: sent | queued | error → ตัวอักษรลงจอดทีละตัว
  async function land(btn, state, text) {
    btn.classList.remove('sx-waiting');
    const icon = state === 'sent' ? '✓ ' : state === 'queued' ? '⇅ ' : '! ';
    const chs = graphemes(icon + text);
    btn.querySelector('.sx-done').innerHTML = chs.map((c, i) =>
      `<span class="sx-ch" style="animation-delay:${i * 34}ms">${c === ' ' ? '&nbsp;' : esc(c)}</span>`).join('');
    btn.dataset.state = state;
    btn.setAttribute('aria-label', text);
    await wait(reduce() ? 300 : 200 + chs.length * 34 + 900);
  }

  function reset(btn, label) {
    btn.disabled = false; btn.dataset.state = 'idle'; btn.classList.remove('sx-waiting');
    btn.querySelector('.sx-done').innerHTML = '';
    if (label) btn.querySelector('.sx-word').textContent = label;
  }

  window.SendFx = { html, launch, land, reset, PLANE, graphemes };
})();
