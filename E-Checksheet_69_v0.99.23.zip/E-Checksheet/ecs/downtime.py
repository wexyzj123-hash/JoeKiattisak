"""ecs/downtime.py — สถานะเครื่องหยุด/ซ่อม

- แจ้งเครื่องหยุด → รอบตรวจที่ยังไม่ปิดของแบบฟอร์มเครื่องนั้นเป็น "skipped" (ไม่ต้องตรวจ ไม่นับขาดตรวจ)
  และรอบที่ระบบสร้างใหม่ระหว่างหยุดก็เป็น skipped ทันที
- เครื่องกลับมาใช้งาน → รอบที่ยังไม่ปิด (ยังอยู่ในช่วงเวลาตรวจหรืออนาคต) กลับเป็น pending ให้ตรวจต่อได้
- เก็บประวัติทุกครั้ง (cs_downtime) ใช้ดูเวลาหยุดรวม/สาเหตุ
- ช่างยังส่งผลตรวจได้ตามปกติ (บันทึกเป็นการตรวจนอกรอบ)
"""
from __future__ import annotations

from datetime import datetime, timedelta

from . import services as S
from .services import ValidationError, audit, parse_ts, ts

CATEGORIES = {
    "repair": "ซ่อม / เสีย",
    "pm": "PM / บำรุงรักษาตามแผน",
    "standby": "สำรอง / ไม่ได้เดิน",
    "stop": "หยุดตามแผนการผลิต",
    "other": "อื่น ๆ",
}
OPEN = ("pending", "in_progress", "overdue")


def _form_ids(db, equipment_id: int) -> list[int]:
    return [r[0] for r in db.execute("SELECT id FROM cs_forms WHERE equipment_id=?", (equipment_id,))]


def _scada_sync(db, equipment_id: int, since: datetime | None, until: datetime | None, actor_id) -> None:
    """v0.84 ค่าจาก SCADA ยึดสถานะเครื่องจักร: ช่วงหยุด → เอาค่าออก · ช่วงที่กลับมาเดิน → ลงค่าจากค่าดิบที่เก็บไว้"""
    import logging
    try:
        from .srcmap import on_downtime_change
        on_downtime_change(db, equipment_id, since or S.now_dt(), until, actor_id)
    except Exception:                                       # noqa: BLE001 — ไม่ให้การแจ้งหยุด/เดินเครื่องล้มเพราะ SCADA
        logging.getLogger(__name__).exception("scada sync on downtime change failed")


def set_down(db, equipment_id: int, actor_id: int | None, reason: str = "", category: str = "repair",
             expected_end: str | None = None, start_at: datetime | None = None) -> dict:
    eq = db.execute("SELECT id, code, run_status FROM equipment WHERE id=?", (equipment_id,)).fetchone()
    if not eq:
        raise ValidationError("ไม่พบเครื่องจักร")
    if eq["run_status"] == "down":
        raise ValidationError(f"{eq['code']} แจ้งหยุดอยู่แล้ว")
    category = category if category in CATEGORIES else "other"
    reason = str(reason or "").strip()[:300]
    if not reason:
        raise ValidationError("กรุณาระบุสาเหตุที่เครื่องหยุด")
    exp = None
    if expected_end:
        dt = parse_ts(str(expected_end).replace("T", " "))
        if not dt:
            raise ValidationError("วันเวลาที่คาดว่าจะกลับมาใช้งานไม่ถูกต้อง")
        exp = ts(dt)
    start = start_at or S.now_dt()
    stamp = ts(start)
    fids = _form_ids(db, equipment_id)
    skipped = 0
    if fids:
        ph = ",".join("?" * len(fids))
        # v0.53 หยุดย้อนหลัง: รอบที่เริ่มหลังเวลาหยุด (รวมที่กลายเป็นขาดตรวจไปแล้ว) = งดตรวจ + ปิดแจ้งเตือนขาดตรวจ
        hit = [r[0] for r in db.execute(f"""SELECT id FROM cs_rounds WHERE form_id IN ({ph}) AND submission_id IS NULL
                     AND status IN ('pending','in_progress','overdue','missed') AND close_at > ?""", [*fids, stamp])]
        if hit:
            db.execute(f"UPDATE cs_rounds SET status='skipped', updated_at=? WHERE id IN ({','.join('?' * len(hit))})", [ts(), *hit])
            from .statfix import _close_missed_alerts
            _close_missed_alerts(db, hit, actor_id, ts(), f"เครื่องหยุดตั้งแต่ {start:%d/%m %H:%M} — งดตรวจ")
        skipped = len(hit)
    db.execute("""UPDATE equipment SET run_status='down', down_reason=?, down_since=?, down_until=?, down_by=?, updated_at=?
                  WHERE id=?""", (f"{CATEGORIES[category]}: {reason}", stamp, exp, actor_id, ts(), equipment_id))
    did = db.execute("""INSERT INTO cs_downtime(equipment_id, start_at, reason, category, expected_end, started_by, skipped_rounds)
                        VALUES (?,?,?,?,?,?,?)""", (equipment_id, stamp, reason, category, exp, actor_id, skipped)).lastrowid
    audit(db, actor_id, "down", "equipment", equipment_id, after={"reason": reason, "category": category, "expected": exp,
                                                                   "skipped_rounds": skipped})
    _scada_sync(db, equipment_id, start, None, actor_id)
    return {"id": did, "skipped": skipped, "code": eq["code"]}


def set_running(db, equipment_id: int, actor_id: int | None, note: str = "", now: datetime | None = None) -> dict:
    eq = db.execute("SELECT id, code, run_status FROM equipment WHERE id=?", (equipment_id,)).fetchone()
    if not eq:
        raise ValidationError("ไม่พบเครื่องจักร")
    if eq["run_status"] != "down":
        raise ValidationError(f"{eq['code']} ใช้งานอยู่แล้ว")
    now = now or S.now_dt()
    _ds = db.execute("SELECT down_since FROM equipment WHERE id=?", (equipment_id,)).fetchone()
    since0 = parse_ts(_ds[0]) if _ds and _ds[0] else now
    stamp = ts(now)
    fids = _form_ids(db, equipment_id)
    restored = 0
    if fids:
        ph = ",".join("?" * len(fids))
        restored = db.execute(f"""UPDATE cs_rounds SET status='pending', updated_at=?
                                 WHERE form_id IN ({ph}) AND status='skipped' AND submission_id IS NULL AND close_at > ?""",
                              [stamp, *fids, stamp]).rowcount
    db.execute("""UPDATE equipment SET run_status='running', down_reason='', down_since=NULL, down_until=NULL, down_by=NULL,
                  updated_at=? WHERE id=?""", (ts(), equipment_id))
    db.execute("""UPDATE cs_downtime SET end_at=?, ended_by=?, end_note=? WHERE equipment_id=? AND end_at IS NULL""",
               (stamp, actor_id, str(note or "").strip()[:300], equipment_id))
    if fids:
        S.refresh_round_statuses(db, now)              # รอบที่เลยกำหนดแล้ว → overdue (หลังปิดช่วงหยุด: ไม่ให้นับเป็นเครื่องหยุดซ้ำ)
    audit(db, actor_id, "running", "equipment", equipment_id, after={"note": note, "restored_rounds": restored})
    _scada_sync(db, equipment_id, min(since0, now), None, actor_id)
    return {"restored": restored, "code": eq["code"]}


def is_down(db, form_id: int) -> dict | None:
    r = db.execute("""SELECT e.code, e.run_status, e.down_reason, e.down_since, e.down_until, u.name AS down_by_name
                      FROM cs_forms f JOIN equipment e ON e.id=f.equipment_id LEFT JOIN users u ON u.id=e.down_by
                      WHERE f.id=?""", (form_id,)).fetchone()
    return dict(r) if r and r["run_status"] == "down" else None


def down_list(db, factory_id: int | None = None) -> list[dict]:
    where, params = ["e.run_status='down'"], []
    if factory_id:
        where.append("e.factory_id=?")
        params.append(factory_id)
    now = S.now_dt()
    out = []
    for r in db.execute(f"""SELECT e.*, fa.name AS factory_name, ar.name AS area_name, u.name AS down_by_name
                            FROM equipment e LEFT JOIN factories fa ON fa.id=e.factory_id LEFT JOIN areas ar ON ar.id=e.area_id
                            LEFT JOIN users u ON u.id=e.down_by WHERE {' AND '.join(where)}
                            ORDER BY e.down_since""", params):
        d = dict(r)
        since = parse_ts(d["down_since"])
        d["hours"] = round((now - since).total_seconds() / 3600, 1) if since else None
        until = parse_ts(d["down_until"])
        d["late"] = bool(until and until < now)
        out.append(d)
    return out


def history(db, equipment_id: int | None = None, limit: int = 100) -> list[dict]:
    where, params = "", []
    if equipment_id:
        where = "WHERE d.equipment_id=?"
        params.append(equipment_id)
    now = S.now_dt()
    out = []
    for r in db.execute(f"""SELECT d.*, e.code, e.name, s.name AS started_by_name, x.name AS ended_by_name
                            FROM cs_downtime d JOIN equipment e ON e.id=d.equipment_id
                            LEFT JOIN users s ON s.id=d.started_by LEFT JOIN users x ON x.id=d.ended_by
                            {where} ORDER BY d.start_at DESC LIMIT ?""", params + [limit]):
        d = dict(r)
        a, b = parse_ts(d["start_at"]), parse_ts(d["end_at"]) or now
        d["hours"] = round((b - a).total_seconds() / 3600, 1) if a else None
        d["category_th"] = CATEGORIES.get(d["category"], d["category"])
        out.append(d)
    return out


def fix_stale_skipped(db, now: datetime | None = None, days: int | None = None) -> int:
    """v0.55 รอบที่ถูกงด (skipped) แต่ไม่อยู่ในช่วงเครื่องหยุดจริง → คืนสถานะตามเวลา (รอตรวจ / เลยกำหนด / ขาดตรวจ)
    v0.99.9 ใช้ S.reconcile_down_rounds — ตรวจย้อนหลังทั้งหมดทั้ง 2 ทาง (`days` เก็บไว้ให้เรียกแบบเดิมได้)"""
    return S.reconcile_down_rounds(db, now)["down_restored"]


def shift_start_of(at: datetime, cal: dict) -> datetime:
    """เวลาเริ่มกะของเวลา at (ตามเวลากะในปฏิทิน · ไม่ได้ตั้ง → 08:00 / 20:00)"""
    from .sign_blocks import _shift_starts
    starts = _shift_starts(cal) or [8 * 60, 20 * 60]
    m = at.hour * 60 + at.minute
    base = at.replace(hour=0, minute=0, second=0, microsecond=0)
    past = [x for x in starts if x <= m]
    if past:
        return base + timedelta(minutes=max(past))
    return base - timedelta(days=1) + timedelta(minutes=max(starts))


def auto_run_on_check(db, form_id: int, user_id: int, checked_at: datetime, now: datetime | None = None) -> dict | None:
    """v0.56 เครื่องที่แจ้งหยุดอยู่ แล้วมีช่างส่งผลตรวจ → ปลดสถานะหยุดเป็น "เดินเครื่อง" อัตโนมัติ โดยช่างผู้ตรวจ
    เวลาเดินเครื่อง = เวลาเริ่มกะของช่างผู้ตรวจ (อ้างอิงตามกะ) แต่ไม่ก่อนเวลาที่กดหยุด
    และไม่ก่อนเวลาปิดรอบที่งดตรวจไปแล้วในกะนั้น (รอบที่ปิดไปก่อนช่างมาตรวจยังเป็น "งดตรวจ" ไม่กลายเป็นขาดตรวจ)
    ผลตรวจที่ทำก่อนเวลากดหยุด (เช่น ส่งออฟไลน์ภายหลัง) ไม่ปลดสถานะ"""
    f = db.execute("""SELECT e.id, e.code, e.run_status FROM cs_forms f JOIN equipment e ON e.id=f.equipment_id
                      WHERE f.id=?""", (form_id,)).fetchone()
    if not f or f["run_status"] != "down":
        return None
    d = db.execute("SELECT id, start_at FROM cs_downtime WHERE equipment_id=? AND end_at IS NULL ORDER BY start_at DESC LIMIT 1",
                   (f["id"],)).fetchone()
    start = parse_ts(d["start_at"]) if d else parse_ts(db.execute("SELECT down_since FROM equipment WHERE id=?", (f["id"],)).fetchone()[0])
    if start and checked_at <= start:
        return None
    from .itemfreq import get_calendar
    from .sign_blocks import shift_of
    cal = get_calendar(db)
    at = release_time(db, f["id"], start, checked_at, cal)
    u = db.execute("SELECT name FROM users WHERE id=?", (user_id,)).fetchone()
    sh = "กะกลางวัน" if shift_of(checked_at.hour * 60 + checked_at.minute, cal) == "day" else "กะกลางคืน"
    note = f"ปลดอัตโนมัติ: {u['name'] if u else 'ช่าง'} ส่งผลตรวจ ({sh} เริ่มตรวจ {checked_at:%d/%m %H:%M})"
    res = set_running(db, f["id"], user_id, note, now=at)
    if now and now > at:
        S.refresh_round_statuses(db, now)
    return {"code": f["code"], "at": ts(at), "shift": sh, "restored": res["restored"]}


def release_time(db, equipment_id: int, start: datetime | None, checked_at: datetime, cal: dict) -> datetime:
    """เวลาเดินเครื่องเมื่อมีผลตรวจ: เริ่มกะของผู้ตรวจ · ไม่ก่อนเวลาหยุด · หลังรอบงดตรวจที่ปิดไปก่อนเริ่มตรวจ · ไม่เกินเวลาเริ่มตรวจ"""
    at = shift_start_of(checked_at, cal)
    if start and at < start:
        at = start
    fids = _form_ids(db, equipment_id)
    if fids:
        ph = ",".join("?" * len(fids))
        last_close = db.execute(f"""SELECT MAX(close_at) FROM cs_rounds WHERE form_id IN ({ph}) AND status='skipped'
                                    AND submission_id IS NULL AND close_at > ? AND close_at <= ?""",
                                [*fids, ts(at), ts(checked_at)]).fetchone()[0]
        if last_close:
            at = parse_ts(last_close)
    return min(at, checked_at)


# ───────────────────────── v0.57 แก้ข้อมูลเก่า: มีผลตรวจระหว่างที่ระบบยังค้างสถานะหยุด ─────────────────────────
MANUAL = "COALESCE(s.source,'v3') NOT IN ('auto','legacy')"


def _first_check(db, fids: list[int], start: str, end: str | None, reported: str | None = None):
    """ผลตรวจแรกที่ทำหลังเวลาหยุด และส่งเข้าระบบหลังเวลาที่แจ้งหยุด (แจ้งหยุดย้อนหลังทับผลตรวจที่มีอยู่แล้ว = ไม่นับ)"""
    ph = ",".join("?" * len(fids))
    q = f"""SELECT s.id, s.form_id, s.inspector_id, COALESCE(s.scanned_at, s.finished_at) AS at, u.name AS inspector_name
            FROM cs_submissions s LEFT JOIN users u ON u.id=s.inspector_id
            WHERE s.form_id IN ({ph}) AND s.status<>'superseded' AND {MANUAL}
              AND COALESCE(s.scanned_at, s.finished_at) > ? AND COALESCE(s.received_at, s.finished_at) > ?"""
    args = [*fids, start, reported or start]
    if end:
        q += " AND COALESCE(s.scanned_at, s.finished_at) < ?"
        args.append(end)
    return db.execute(q + " ORDER BY at LIMIT 1", args).fetchone()


def stale_downtimes(db, days: int = 62, now: datetime | None = None) -> list[dict]:
    """ช่วงหยุดเครื่อง (ยังหยุดอยู่ หรือย้อนหลัง `days` วัน) ที่มีช่างส่งผลตรวจระหว่างช่วง → ควรเดินเครื่องตั้งแต่ผลตรวจแรก"""
    from .itemfreq import get_calendar
    from .sign_blocks import shift_of
    now = now or S.now_dt()
    cal = get_calendar(db)
    out = []
    for d in db.execute("""SELECT d.*, e.code, e.name AS eq_name, e.run_status, x.name AS ended_by_name, st.name AS started_by_name
                           FROM cs_downtime d JOIN equipment e ON e.id=d.equipment_id
                           LEFT JOIN users x ON x.id=d.ended_by LEFT JOIN users st ON st.id=d.started_by
                           WHERE d.end_at IS NULL OR d.end_at >= ? ORDER BY d.start_at""", (ts(now - timedelta(days=days)),)):
        fids = _form_ids(db, d["equipment_id"])
        if not fids:
            continue
        rep = db.execute("""SELECT MIN(created_at) FROM cs_audit WHERE action='down' AND entity='equipment' AND entity_id=?
                                AND created_at >= ?""", (d["equipment_id"], d["start_at"])).fetchone()[0]
        sub = _first_check(db, fids, d["start_at"], d["end_at"], rep)
        if not sub:
            continue
        chk = parse_ts(sub["at"])
        new_end = release_time(db, d["equipment_id"], parse_ts(d["start_at"]), chk, cal)
        old_end = parse_ts(d["end_at"]) if d["end_at"] else None
        if old_end and new_end >= old_end:
            continue
        x = dict(d)
        x.update(sub_id=sub["id"], check_at=sub["at"], inspector_id=sub["inspector_id"], inspector_name=sub["inspector_name"],
                 new_end=ts(new_end), shift="กะกลางวัน" if shift_of(chk.hour * 60 + chk.minute, cal) == "day" else "กะกลางคืน",
                 hours_old=round(((old_end or now) - parse_ts(d["start_at"])).total_seconds() / 3600, 1),
                 hours_new=round((new_end - parse_ts(d["start_at"])).total_seconds() / 3600, 1))
        ph = ",".join("?" * len(fids))
        x["rounds"] = db.execute(f"""SELECT COUNT(*) FROM cs_rounds WHERE form_id IN ({ph}) AND status='skipped'
                                     AND submission_id IS NULL AND close_at > ? AND (? IS NULL OR close_at <= ?)""",
                                 [*fids, ts(new_end), d["end_at"], d["end_at"]]).fetchone()[0]
        x["offround"] = db.execute(f"""SELECT COUNT(*) FROM cs_submissions s WHERE s.form_id IN ({ph}) AND s.round_id IS NULL
                                       AND s.status<>'superseded' AND {MANUAL} AND COALESCE(s.scanned_at, s.finished_at) >= ?
                                       AND (? IS NULL OR COALESCE(s.scanned_at, s.finished_at) <= ?)""",
                                   [*fids, ts(new_end), d["end_at"], d["end_at"]]).fetchone()[0]
        out.append(x)
    return out


def _link_offround(db, fids: list[int], since: datetime, until: datetime | None, actor_id, now: datetime) -> int:
    """ผลตรวจนอกรอบ (ที่ส่งตอนระบบค้างสถานะหยุด) → ผูกกับรอบของช่วงเวลานั้น"""
    from .statfix import _close_missed_alerts
    from .submissions import EARLY_START_MIN
    ph = ",".join("?" * len(fids))
    q = f"""SELECT s.id, s.form_id, COALESCE(s.scanned_at, s.finished_at) AS at, s.finished_at FROM cs_submissions s
            WHERE s.form_id IN ({ph}) AND s.round_id IS NULL AND s.status<>'superseded' AND {MANUAL}
              AND COALESCE(s.scanned_at, s.finished_at) >= ?"""
    args: list = [*fids, ts(since)]
    if until:
        q += " AND COALESCE(s.scanned_at, s.finished_at) <= ?"
        args.append(ts(until))
    n = 0
    for sub in db.execute(q + " ORDER BY at", args).fetchall():
        at = parse_ts(sub["at"])
        r = db.execute("""SELECT r.* FROM cs_rounds r JOIN cs_schedules sc ON sc.id=r.schedule_id
                          WHERE r.form_id=? AND sc.active=1 AND r.submission_id IS NULL
                            AND r.status IN ('pending','in_progress','overdue','missed')
                            AND r.due_at <= ? AND r.close_at > ? ORDER BY r.due_at DESC LIMIT 1""",
                       (sub["form_id"], ts(at + timedelta(minutes=EARLY_START_MIN)), ts(at))).fetchone()
        if not r:
            continue
        st = S.round_status_for_submission(dict(r), parse_ts(sub["finished_at"]) or at)
        db.execute("UPDATE cs_rounds SET submission_id=?, status=? WHERE id=?", (sub["id"], st, r["id"]))
        db.execute("UPDATE cs_submissions SET round_id=? WHERE id=?", (r["id"], sub["id"]))
        _close_missed_alerts(db, [r["id"]], actor_id, ts(now), "แก้ข้อมูลย้อนหลัง: มีผลตรวจของรอบนี้แล้ว")
        n += 1
    return n


def fix_stale_downtimes(db, actor_id: int | None, ids: list[int] | None = None, now: datetime | None = None) -> dict:
    """แก้ข้อมูลเก่า: ช่วงหยุดที่มีผลตรวจระหว่างช่วง → เดินเครื่องตั้งแต่เริ่มกะของผู้ตรวจ (ผู้ตรวจเป็นผู้กดเดิน)
    + รอบที่งดตรวจเกินจริงคืนสถานะตามเวลา + ผลตรวจนอกรอบผูกเข้ารอบ"""
    now = now or S.now_dt()
    fixed = linked = 0
    rounds = 0
    for x in stale_downtimes(db, now=now):
        if ids is not None and x["id"] not in ids:
            continue
        new_end = parse_ts(x["new_end"])
        old_end = parse_ts(x["end_at"]) if x["end_at"] else None
        note = (f"ปลดอัตโนมัติ: {x['inspector_name'] or 'ช่าง'} ส่งผลตรวจ ({x['shift']} เริ่มตรวจ {parse_ts(x['check_at']):%d/%m %H:%M})"
                + (f" · แก้ข้อมูลย้อนหลัง (เดิมเดินเครื่อง {old_end:%d/%m %H:%M} โดย {x['ended_by_name'] or 'ระบบ'})" if old_end else " · แก้ข้อมูลย้อนหลัง"))
        db.execute("UPDATE cs_downtime SET end_at=?, ended_by=?, end_note=? WHERE id=?", (ts(new_end), x["inspector_id"], note[:300], x["id"]))
        if not old_end and x["run_status"] == "down":
            db.execute("""UPDATE equipment SET run_status='running', down_reason='', down_since=NULL, down_until=NULL, down_by=NULL,
                          updated_at=? WHERE id=?""", (ts(now), x["equipment_id"]))
        fids = _form_ids(db, x["equipment_id"])
        ph = ",".join("?" * len(fids))
        rows = db.execute(f"""SELECT id, deadline_at, close_at FROM cs_rounds WHERE form_id IN ({ph}) AND status='skipped'
                              AND submission_id IS NULL AND close_at > ? AND (? IS NULL OR close_at <= ?)""",
                          [*fids, ts(new_end), x["end_at"], x["end_at"]]).fetchall()
        for r in rows:                                       # ไม่แตะ updated_at → ไม่เกิดแจ้งเตือนย้อนหลัง
            st = "missed" if r["close_at"] <= ts(now) else ("overdue" if r["deadline_at"] <= ts(now) else "pending")
            db.execute("UPDATE cs_rounds SET status=? WHERE id=?", (st, r["id"]))
        rounds += len(rows)
        linked += _link_offround(db, fids, new_end, old_end, actor_id, now)
        _scada_sync(db, x["equipment_id"], new_end, None, actor_id)
        audit(db, actor_id, "downtime_fix", "cs_downtime", x["id"],
              before={"end_at": x["end_at"], "ended_by": x["ended_by"]},
              after={"end_at": ts(new_end), "ended_by": x["inspector_id"], "submission_id": x["sub_id"], "rounds": len(rows)})
        fixed += 1
    return {"fixed": fixed, "rounds": rounds, "linked": linked}


# ───────────────────────── v0.58 กรอกวันหยุดเครื่องย้อนหลัง ─────────────────────────
MAX_BACK_DAYS = 62


def _parse_dt(v, label: str) -> datetime | None:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v
    dt = parse_ts(str(v).replace("T", " "))
    if not dt:
        raise ValidationError(f"{label}ไม่ถูกต้อง")
    return dt.replace(second=0, microsecond=0)


def _overlap(db, equipment_id: int, start: datetime, end: datetime | None, skip_id: int | None = None):
    q = """SELECT id, start_at, end_at FROM cs_downtime WHERE equipment_id=? AND start_at < ? AND (end_at IS NULL OR end_at > ?)"""
    args: list = [equipment_id, ts(end or datetime(9999, 1, 1)), ts(start)]
    if skip_id:
        q += " AND id<>?"
        args.append(skip_id)
    return db.execute(q + " LIMIT 1", args).fetchone()


def record_down(db, equipment_id: int, actor_id: int | None, reason: str, category: str,
                start, end=None, note: str = "", now: datetime | None = None) -> dict:
    """แจ้งหยุดย้อนหลัง — มีเวลาเดินเครื่อง = บันทึกช่วงหยุดที่จบแล้ว · ไม่มี = เครื่องหยุดอยู่ตั้งแต่เวลานั้น
    v0.59 ช่วงที่บันทึกใหม่ "ทับแทน" ช่วงเดิมที่ซ้อนกัน (ช่วงเดิมถูกตัด/แยก/ลบเฉพาะส่วนที่ซ้อน)
    รอบที่ปิดรอบหลังเวลาเริ่มหยุดจนถึงเวลาเดินเครื่อง (ยังไม่มีผลตรวจ รวมที่เป็นขาดตรวจแล้ว) → งดตรวจ + ปิดแจ้งเตือน"""
    now = now or S.now_dt()
    start = _parse_dt(start, "เวลาเริ่มหยุด")
    end = _parse_dt(end, "เวลาเดินเครื่อง")
    if not start:
        raise ValidationError("กรุณาระบุเวลาเริ่มหยุด")
    if start > now:
        raise ValidationError("เวลาเริ่มหยุดต้องไม่เกินเวลาปัจจุบัน")
    if start < now - timedelta(days=MAX_BACK_DAYS):
        raise ValidationError(f"บันทึกย้อนหลังได้ไม่เกิน {MAX_BACK_DAYS} วัน")
    if end is not None:
        if end <= start:
            raise ValidationError("เวลาเดินเครื่องต้องหลังเวลาเริ่มหยุด")
        if end > now:
            raise ValidationError("เวลาเดินเครื่องต้องไม่เกินเวลาปัจจุบัน (ถ้ายังหยุดอยู่ ให้เว้นว่าง)")
    eq = db.execute("SELECT id, code, run_status FROM equipment WHERE id=?", (equipment_id,)).fetchone()
    if not eq:
        raise ValidationError("ไม่พบเครื่องจักร")
    category = category if category in CATEGORIES else "other"
    reason = str(reason or "").strip()[:300]
    if not reason:
        raise ValidationError("กรุณาระบุสาเหตุที่เครื่องหยุด")
    stamp_now = ts(now)
    # ── ช่วงเดิมที่ซ้อน → เหลือเฉพาะส่วนที่ไม่ซ้อน ──
    replaced = []
    far = datetime(9999, 12, 31)
    ne = end or far
    for o in db.execute("""SELECT * FROM cs_downtime WHERE equipment_id=? AND start_at < ? AND (end_at IS NULL OR end_at > ?)
                           ORDER BY start_at""", (equipment_id, ts(ne), ts(start))).fetchall():
        o = dict(o)
        os_, oe = parse_ts(o["start_at"]), parse_ts(o["end_at"]) if o["end_at"] else far
        head = (os_, start) if os_ < start else None
        tail = (ne, oe) if oe > ne else None
        replaced.append({"id": o["id"], "start_at": o["start_at"], "end_at": o["end_at"]})
        if not head and not tail:
            db.execute("DELETE FROM cs_downtime WHERE id=?", (o["id"],))
        else:
            first = head or tail
            db.execute("UPDATE cs_downtime SET start_at=?, end_at=? WHERE id=?",
                       (ts(first[0]), None if first[1] == far else ts(first[1]), o["id"]))
            if head and not o["end_at"]:
                db.execute("UPDATE cs_downtime SET ended_by=?, end_note=? WHERE id=?",
                           (actor_id, "ตัดช่วงโดยการบันทึกหยุดย้อนหลัง", o["id"]))
            if head and tail:
                db.execute("""INSERT INTO cs_downtime(equipment_id, start_at, end_at, reason, category, expected_end, started_by,
                              ended_by, end_note, skipped_rounds) VALUES (?,?,?,?,?,?,?,?,?,0)""",
                           (equipment_id, ts(tail[0]), None if tail[1] == far else ts(tail[1]), o["reason"], o["category"],
                            o["expected_end"], o["started_by"], o["ended_by"], o["end_note"]))
    # ── รอบตรวจในช่วงหยุด → งดตรวจ ──
    fids = _form_ids(db, equipment_id)
    hit_ids: list[int] = []
    if fids:
        ph = ",".join("?" * len(fids))
        q = f"""SELECT id FROM cs_rounds WHERE form_id IN ({ph}) AND submission_id IS NULL
                AND status IN ('pending','in_progress','overdue','missed') AND close_at > ?"""
        args: list = [*fids, ts(start)]
        if end:
            q += " AND close_at <= ?"
            args.append(ts(end))
        hit_ids = [r[0] for r in db.execute(q, args)]
        if hit_ids:
            db.execute(f"UPDATE cs_rounds SET status='skipped' WHERE id IN ({','.join('?' * len(hit_ids))})", hit_ids)
            from .statfix import _close_missed_alerts
            _close_missed_alerts(db, hit_ids, actor_id, stamp_now,
                                 f"บันทึกเครื่องหยุดย้อนหลังตั้งแต่ {start:%d/%m %H:%M}" + (f"–{end:%d/%m %H:%M}" if end else "") + " — งดตรวจ")
    u = db.execute("SELECT name FROM users WHERE id=?", (actor_id,)).fetchone() if actor_id else None
    end_note = (f"บันทึกย้อนหลังโดย {u['name'] if u else 'ระบบ'} {now:%d/%m %H:%M}"
                + (f" · ทับช่วงเดิม {len(replaced)} ช่วง" if replaced else "")
                + (f" · {note.strip()}" if note and note.strip() else ""))[:300]
    did = db.execute("""INSERT INTO cs_downtime(equipment_id, start_at, end_at, reason, category, started_by, ended_by, end_note, skipped_rounds)
                        VALUES (?,?,?,?,?,?,?,?,?)""", (equipment_id, ts(start), ts(end) if end else None, reason, category, actor_id,
                                                         actor_id if end else None, end_note if end else "", len(hit_ids))).lastrowid
    # ── สถานะเครื่องตอนนี้ ตามช่วงที่ยังเปิดอยู่ ──
    open_ = db.execute("SELECT * FROM cs_downtime WHERE equipment_id=? AND end_at IS NULL ORDER BY start_at DESC LIMIT 1",
                       (equipment_id,)).fetchone()
    if open_:
        db.execute("""UPDATE equipment SET run_status='down', down_reason=?, down_since=?, down_by=?, updated_at=? WHERE id=?""",
                   (f"{CATEGORIES.get(open_['category'], '')}: {open_['reason']}", open_["start_at"], open_["started_by"],
                    stamp_now, equipment_id))
    elif eq["run_status"] == "down":
        db.execute("""UPDATE equipment SET run_status='running', down_reason='', down_since=NULL, down_until=NULL, down_by=NULL,
                      updated_at=? WHERE id=?""", (stamp_now, equipment_id))
        S.refresh_round_statuses(db, now)
    fix_stale_skipped(db, now, days=MAX_BACK_DAYS + 2)   # รอบที่เคยงดเพราะช่วงเดิม แต่ไม่อยู่ในช่วงหยุดแล้ว → คืนสถานะ
    s0 = min([start] + [parse_ts(r["start_at"]) for r in replaced])
    _scada_sync(db, equipment_id, s0, None, actor_id)
    audit(db, actor_id, "down_backfill", "cs_downtime", did,
          before={"replaced": replaced} if replaced else None,
          after={"equipment_id": equipment_id, "start": ts(start), "end": ts(end) if end else None,
                 "reason": reason, "category": category, "skipped_rounds": len(hit_ids)})
    return {"id": did, "skipped": len(hit_ids), "code": eq["code"], "closed": bool(end), "replaced": len(replaced)}


def set_running_at(db, equipment_id: int, actor_id: int | None, at=None, note: str = "", now: datetime | None = None) -> dict:
    """เครื่องกลับมาใช้งาน — ระบุเวลาเดินเครื่องย้อนหลังได้ (ไม่ก่อนเวลาที่หยุด) · รอบที่ปิดไปแล้วหลังเวลาเดินเครื่องเป็นขาดตรวจ
    โดยไม่ส่งแจ้งเตือนย้อนหลัง"""
    now = now or S.now_dt()
    at = _parse_dt(at, "เวลาเดินเครื่อง")
    if at is None:
        return set_running(db, equipment_id, actor_id, note)
    if at > now:
        raise ValidationError("เวลาเดินเครื่องต้องไม่เกินเวลาปัจจุบัน")
    eq = db.execute("SELECT down_since FROM equipment WHERE id=?", (equipment_id,)).fetchone()
    since = parse_ts(eq["down_since"]) if eq and eq["down_since"] else None
    if since and at <= since:
        raise ValidationError(f"เวลาเดินเครื่องต้องหลังเวลาที่หยุด ({since:%d/%m/%Y %H:%M})")
    if at >= now - timedelta(minutes=1):
        return set_running(db, equipment_id, actor_id, note)
    res = set_running(db, equipment_id, actor_id, note, now=at)
    fids = _form_ids(db, equipment_id)
    if fids:                                           # สถานะตามเวลาจริง แต่ updated_at = เวลาเดินเครื่อง → ไม่เตือนย้อนหลัง
        ph = ",".join("?" * len(fids))
        db.execute(f"""UPDATE cs_rounds SET status='missed', updated_at=? WHERE form_id IN ({ph}) AND submission_id IS NULL
                       AND status IN ('pending','in_progress','overdue') AND close_at <= ?""", [ts(at), *fids, ts(now)])
        db.execute(f"""UPDATE cs_rounds SET status='overdue', updated_at=? WHERE form_id IN ({ph}) AND submission_id IS NULL
                       AND status IN ('pending','in_progress') AND deadline_at <= ?""", [ts(at), *fids, ts(now)])
    res["at"] = ts(at)
    return res
