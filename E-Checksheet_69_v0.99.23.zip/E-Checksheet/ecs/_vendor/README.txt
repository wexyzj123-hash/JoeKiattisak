xlrd 2.0.2 (BSD) — อ่านไฟล์ .xls รุ่นเก่า (ไม่ต้อง pip install เพิ่ม)
