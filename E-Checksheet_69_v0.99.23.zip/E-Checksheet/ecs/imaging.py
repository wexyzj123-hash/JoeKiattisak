"""ecs/imaging.py — รับรูปได้ทุกรูปแบบ/ไฟล์ใหญ่ แล้วลดขนาดก่อนเก็บ

รองรับ: JPG, PNG, WEBP, GIF, BMP, TIFF และ HEIC/HEIF (รูปจาก iPhone — ต้องมี pillow-heif)
ขั้นตอน: หมุนตาม EXIF → ย่อด้านยาวสุดไม่เกิน max_side → บันทึกเป็น JPEG คุณภาพ ~82 (ไฟล์เล็กลง 5–20 เท่า)
ไม่มี Pillow ในเครื่อง → เก็บไฟล์เดิมได้เฉพาะ JPG/PNG/WEBP (แบบเดิม)
"""
from __future__ import annotations

import io

try:
    from PIL import Image, ImageOps
    Image.MAX_IMAGE_PIXELS = 150_000_000        # กันไฟล์รูปอันตราย (decompression bomb) แต่รับรูปกล้อง 100 MP ได้
    HAS_PIL = True
except ImportError:                              # pragma: no cover
    HAS_PIL = False

HAS_HEIF = False
if HAS_PIL:
    try:
        from pillow_heif import register_heif_opener
        register_heif_opener()
        HAS_HEIF = True
    except Exception:                            # pragma: no cover - ไม่ได้ติดตั้ง
        HAS_HEIF = False

PHOTO_MAX_SIDE = 1600
PHOTO_QUALITY = 82
ACCEPT = "image/*,.heic,.heif,.jpg,.jpeg,.png,.webp,.gif,.bmp,.tif,.tiff"


class ImageError(ValueError):
    pass


def sniff(head: bytes) -> str | None:
    """เดาชนิดไฟล์จากไบต์ต้นไฟล์ (ไม่เชื่อนามสกุล)"""
    if head.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[:2] == b"BM":
        return "bmp"
    if head[:4] in (b"II*\x00", b"MM\x00*"):
        return "tiff"
    if head[4:8] == b"ftyp" and head[8:12] in (b"heic", b"heix", b"hevc", b"hevx", b"mif1", b"msf1", b"heim", b"heis", b"avif"):
        return "heic"
    return None


def process(data: bytes, max_side: int = PHOTO_MAX_SIDE, quality: int = PHOTO_QUALITY,
            keep_png: bool = False) -> tuple[bytes, str]:
    """คืน (ไบต์ที่ลดขนาดแล้ว, นามสกุล) — ยก ImageError ถ้าไม่ใช่รูปที่อ่านได้"""
    kind = sniff(data[:16])
    if not kind:
        raise ImageError("ไฟล์นี้ไม่ใช่รูปภาพที่รองรับ (JPG, PNG, WEBP, HEIC, GIF, BMP, TIFF)")
    if not HAS_PIL:
        if kind in ("jpg", "png", "webp"):
            return data, kind
        raise ImageError("เซิร์ฟเวอร์ยังไม่ได้ติดตั้ง Pillow จึงรับได้เฉพาะ JPG, PNG, WEBP (pip install Pillow pillow-heif)")
    if kind == "heic" and not HAS_HEIF:
        raise ImageError("รูป HEIC (iPhone) ต้องติดตั้ง pillow-heif ที่เซิร์ฟเวอร์: pip install pillow-heif "
                         "— หรือตั้งค่ากล้อง iPhone เป็น 'รองรับมากที่สุด' (JPG)")
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
    except Image.DecompressionBombError:
        raise ImageError("รูปมีความละเอียดสูงเกินไป") from None
    except Exception:
        raise ImageError("อ่านไฟล์รูปไม่ได้ (ไฟล์อาจเสีย)") from None
    try:
        img = ImageOps.exif_transpose(img)
    except Exception:
        pass
    if getattr(img, "n_frames", 1) > 1:
        img.seek(0)
    img.thumbnail((max_side, max_side), Image.LANCZOS)
    buf = io.BytesIO()
    if keep_png and kind == "png":
        img.save(buf, "PNG", optimize=True)
        return buf.getvalue(), "png"
    if img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGBA")
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[-1])
        img = bg
    elif img.mode != "RGB":
        img = img.convert("RGB")
    img.save(buf, "JPEG", quality=quality, optimize=True, progressive=True)
    return buf.getvalue(), "jpg"                 # บันทึกใหม่เสมอ: หมุนภาพถูกทิศ + ตัดข้อมูล GPS/EXIF ออก
