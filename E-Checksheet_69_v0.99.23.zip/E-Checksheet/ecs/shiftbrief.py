"""ecs/shiftbrief.py — v0.99.16 สรุปเปลี่ยนกะแบบสไลด์ (แสดงครั้งแรกที่เปิดระบบในกะ)

4 สไลด์: กะก่อนหน้าเหลืออะไรค้าง · เครื่องที่หยุดอยู่ · ค่าที่ใกล้เกณฑ์ · รอบแรกของกะนี้
ขอบเขตโรงงาน = โรงงานที่ผู้ใช้รับผิดชอบ (ไม่ได้กำหนด = ทุกโรงงาน) · ใช้ตัวสรุปกะเดิม (handover.summarize)"""
from __future__ import annotations

from datetime import datetime, timedelta

from . import services as S
from .services import parse_ts, ts


def shift_window(cal: dict, now: datetime) -> tuple[datetime, datetime, datetime]:
    """(เริ่มกะก่อนหน้า, เริ่มกะนี้, เริ่มกะถัดไป) ตามเวลากะในปฏิทิน (ไม่ได้ตั้ง → 08:00 / 20:00)"""
    from .sign_blocks import _shift_starts
    starts = _shift_starts(cal) or [8 * 60, 20 * 60]
    base = now.replace(hour=0, minute=0, second=0, microsecond=0)
    pts = sorted(base + timedelta(days=d, minutes=m) for d in (-1, 0, 1) for m in starts)
    i = max(k for k, p in enumerate(pts) if p <= now)
    return pts[i - 1], pts[i], pts[i + 1]


def brief(db, user_id: int, now: datetime | None = None) -> dict:
    from . import handover as HO
    from . import insights as IN
    from . import roster as RO
    from .itemfreq import get_calendar
    from .sign_blocks import shift_of
    now = now or S.now_dt()
    cal = get_calendar(db)
    prev, cur, nxt = shift_window(cal, now)
    mine = RO.factories_of(db, user_id)
    facs = [dict(r) for r in db.execute("SELECT id, name FROM factories WHERE active=1 ORDER BY sort_no, id")]
    if mine:
        facs = [f for f in facs if f["id"] in mine] or facs
    agg = {"total": 0, "done": 0, "late": 0, "missed": 0, "skipped": 0, "carry_n": 0, "ng_new": 0, "carry": [], "missed_list": [], "ng_open": [], "down": []}
    for f in facs:
        sm = HO.summarize(db, f["id"], prev, cur)
        for k in ("total", "done", "late", "missed", "skipped", "carry_n", "ng_new"):
            agg[k] += sm[k]
        agg["carry"] += sm["carry"]
        agg["missed_list"] += sm["missed_list"]
        agg["ng_open"] += sm["ng_open"]
        agg["down"] += sm["down"]
    fids = [f["id"] for f in facs]
    trend = []
    for fid in (fids if mine else [None]):
        trend += IN.trending(db, now.date(), fid, limit=6)
    trend = trend[:5]
    ph = ",".join("?" * len(fids)) or "NULL"
    first = [dict(r) for r in db.execute(f"""
        SELECT r.due_at, r.deadline_at, r.status, e.code AS eq_code, f.name AS form_name
        FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id JOIN cs_schedules sc ON sc.id=r.schedule_id
        LEFT JOIN equipment e ON e.id=f.equipment_id
        WHERE f.active=1 AND sc.active=1 AND f.factory_id IN ({ph}) AND r.due_at>=? AND r.due_at<?
        ORDER BY r.due_at, e.code""", (*fids, ts(cur), ts(nxt)))]
    due0 = first[0]["due_at"] if first else None
    m0 = cur.hour * 60 + cur.minute
    name = "กะกลางวัน" if shift_of(m0, cal) == "day" else "กะกลางคืน"
    return {
        "key": ts(cur), "shift": f"{name} {cur:%H:%M}–{nxt:%H:%M}", "prev": f"{prev:%d/%m %H:%M}–{cur:%H:%M}",
        "age_min": int((now - cur).total_seconds() // 60), "factories": [f["name"] for f in facs],
        "prev_sum": {k: agg[k] for k in ("total", "done", "late", "missed", "skipped", "carry_n", "ng_new")},
        "carry": [{"code": r["eq_code"] or r["form_name"], "due": r["due_at"][11:16], "close": (r["close_at"] or "")[5:16]} for r in agg["carry"][:6]],
        "missed": [{"code": r["eq_code"] or r["form_name"], "due": r["due_at"][11:16]} for r in agg["missed_list"][:6]],
        "ng_open": [{"code": a["eq_code"] or "", "title": a["title"], "sev": a["severity"]} for a in agg["ng_open"][:4]],
        "down": [{"code": d["code"], "name": d["name"], "reason": d["down_reason"] or "",
                  "since": (d["down_since"] or "")[5:16]} for d in agg["down"][:6]],
        "down_n": len(agg["down"]),
        "trend": [{"eq": x.get("eq") or "", "item": x.get("item") or "", "last": x.get("last"), "unit": x.get("unit") or "",
                   "eta": x.get("eta"), "side": x.get("side")} for x in trend],
        "first": {"due": due0[11:16] if due0 else None, "deadline": (first[0]["deadline_at"] or "")[11:16] if first else None,
                  "codes": [r["eq_code"] or r["form_name"] for r in first if r["due_at"] == due0][:10],
                  "n_shift": len(first), "n_done": sum(1 for r in first if r["status"] in ("done_on_time", "done_late"))},
    }


def parse_key(key: str) -> datetime | None:
    return parse_ts(key)
