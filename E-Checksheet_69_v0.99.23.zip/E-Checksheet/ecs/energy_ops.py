"""ecs/energy_ops.py — Energy Data v0.63: ระบบมิเตอร์ไฟฟ้า (และลม/น้ำ) แบบครบวงจรในตัว

อ้างอิงโครงสร้างงานจริงของการจดมิเตอร์ไฟฟ้า (โรงงาน › Section › มิเตอร์ No. · CT ratio · มิเตอร์หลัก/ย่อย/หักออก)
แต่สร้างใหม่ทั้งหมดบนฐานข้อมูลของ E-Checksheet — ไม่ผูกกับระบบอื่น

  en_fix_log     ประวัติแก้ค่าอ่าน/หน่วยที่ถูกต้อง พร้อมเหตุผล (ใคร เมื่อไหร่ ก่อน/หลัง)
  en_holidays    ปฏิทินวันหยุด/หยุดซ่อมบำรุง (ว่างโรงงาน = ทุกโรงงาน) — ใช้ตรวจ “วันหยุดแต่ยังใช้สูง”
  en_bills       บิลค่าไฟรายเดือนต่อโรงงาน (kWh, ค่าพลังงาน, Ft, Demand, VAT) → ค่าไฟจริงบาท/kWh
  en_production  ยอดผลิตรายเดือน → kWh ต่อหน่วยผลิต
  en_cases       ใบติดตามความผิดปกติ: เปิด → กำลังตรวจ → แก้แล้ว (บันทึกหน่วยที่ประหยัดได้) / ไม่ใช่ปัญหา

ตรวจความผิดปกติ 7 กฎ (ตั้งเกณฑ์ได้ที่หน้า ตั้งค่า): ค่าลดลง · พุ่งผิดปกติ (z-score) · ค่าไม่ขยับ · ไม่ได้จดหลายวัน ·
วันหยุดแต่ยังใช้สูง · โหลดพื้นฐานสูงขึ้น · ผลรวมมิเตอร์ย่อยเปลี่ยนสัดส่วนจากมิเตอร์หลัก
"""
from __future__ import annotations

import calendar
import io
import statistics
from datetime import date, timedelta

from . import services as S
from .services import ts

DDL = """
CREATE TABLE IF NOT EXISTS en_fix_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    meter_id    INTEGER NOT NULL,
    day         TEXT NOT NULL,
    field       TEXT NOT NULL,              -- value | u_override
    old_value   REAL,
    new_value   REAL,
    reason      TEXT NOT NULL DEFAULT '',
    user_id     INTEGER,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_enfix_meter ON en_fix_log(meter_id, day);
CREATE TABLE IF NOT EXISTS en_holidays (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id  INTEGER,
    day         TEXT NOT NULL,
    name        TEXT NOT NULL DEFAULT '',
    kind        TEXT NOT NULL DEFAULT 'holiday',     -- holiday | shutdown
    UNIQUE (factory_id, day)
);
CREATE TABLE IF NOT EXISTS en_bills (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id  INTEGER NOT NULL,
    month       TEXT NOT NULL,                       -- YYYY-MM
    kwh         REAL NOT NULL DEFAULT 0,
    amount      REAL NOT NULL DEFAULT 0,             -- ค่าพลังงาน + Demand + Ft ก่อน VAT
    ft          REAL NOT NULL DEFAULT 0,
    demand      REAL NOT NULL DEFAULT 0,
    vat         REAL NOT NULL DEFAULT 0,
    note        TEXT NOT NULL DEFAULT '',
    user_id     INTEGER,
    updated_at  TEXT NOT NULL,
    UNIQUE (factory_id, month)
);
CREATE TABLE IF NOT EXISTS en_production (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id  INTEGER NOT NULL,
    month       TEXT NOT NULL,
    qty         REAL NOT NULL DEFAULT 0,
    unit        TEXT NOT NULL DEFAULT 'ชิ้น',
    user_id     INTEGER,
    updated_at  TEXT NOT NULL,
    UNIQUE (factory_id, month)
);
CREATE TABLE IF NOT EXISTS en_cases (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id  INTEGER,
    meter_id    INTEGER,
    kind        TEXT NOT NULL DEFAULT 'elec',
    grp         TEXT NOT NULL DEFAULT '',
    day         TEXT NOT NULL,
    rule        TEXT NOT NULL,
    severity    TEXT NOT NULL DEFAULT 'warn',        -- high | warn | info
    title       TEXT NOT NULL DEFAULT '',
    detail      TEXT NOT NULL DEFAULT '',
    impact      REAL NOT NULL DEFAULT 0,             -- หน่วยที่เกินจากปกติ
    baht        REAL NOT NULL DEFAULT 0,
    status      TEXT NOT NULL DEFAULT 'open',        -- open | checking | fixed | ignored
    cause       TEXT NOT NULL DEFAULT '',
    action      TEXT NOT NULL DEFAULT '',
    saved       REAL NOT NULL DEFAULT 0,             -- หน่วย/เดือน ที่ประหยัดได้หลังแก้
    assignee_id INTEGER,
    opened_by   INTEGER,
    opened_at   TEXT NOT NULL,
    updated_at  TEXT NOT NULL,
    closed_at   TEXT
);
CREATE INDEX IF NOT EXISTS idx_encase_status ON en_cases(status, factory_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_encase ON en_cases(IFNULL(meter_id, 0), IFNULL(factory_id, 0), day, rule);
"""

RULES = {
    "negative": ("high", "เลขมิเตอร์ลดลง"),
    "spike": ("high", "ใช้พุ่งผิดปกติ"),
    "stuck": ("warn", "เลขมิเตอร์ไม่ขยับ"),
    "missing": ("info", "ไม่ได้จดหลายวันติด"),
    "holiday_load": ("high", "วันหยุดแต่ยังใช้สูง"),
    "baseload_up": ("warn", "โหลดพื้นฐานสูงขึ้น"),
    "balance": ("warn", "สัดส่วนมิเตอร์ย่อย/มิเตอร์หลักเปลี่ยน"),
}
EXTRA_RULES = {"fault": ("warn", "มิเตอร์เสีย/อ่านไม่ได้")}      # เปิดจากหน้างาน (ไม่ใช่ผลตรวจอัตโนมัติ)
RULES_ALL = {**RULES, **EXTRA_RULES}
SEV = {"high": ("สูง", 0), "warn": ("เตือน", 1), "info": ("แจ้ง", 2)}
STATUS = {"open": "เปิด", "checking": "กำลังตรวจ", "fixed": "แก้แล้ว", "ignored": "ไม่ใช่ปัญหา"}
CAUSES = ("อุปกรณ์เปิดค้าง", "ลมอัดรั่ว", "น้ำรั่ว", "เดินเครื่องเพิ่ม/เพิ่มกะ", "มิเตอร์เสีย/CT หลุด", "จดผิด/กรอกผิด",
          "เปลี่ยน/รีเซ็ตมิเตอร์", "ตั้งค่าเครื่องไม่เหมาะสม", "ไลน์หยุดตามแผน", "อื่น ๆ")

GENERIC_HINTS = {
    "negative": ["ตรวจว่ามิเตอร์ถูกเปลี่ยนหรือรีเซ็ตในวันนั้นหรือไม่",
                 "ตรวจว่ากรอกเลขสลับวันหรือตกหลักหรือไม่",
                 "ถ้าเปลี่ยนมิเตอร์จริง ให้แก้ “หน่วยที่ถูกต้อง” ของวันนั้นแทนการแก้เลขหน้าปัด"],
    "spike": ["ตรวจว่ามีเดินเครื่องเพิ่ม เพิ่มกะ หรือทดลองผลิตในวันนั้นหรือไม่",
              "ตรวจโหลด/อุปกรณ์ที่เพิ่งต่อเข้าวงจรนี้",
              "เทียบกับแผนผลิต — ผลิตเท่าเดิมแต่ใช้ขึ้น แปลว่าประสิทธิภาพตก"],
    "stuck": ["ตรวจว่ามิเตอร์เสีย จอดับ หรือ CT หลุดหรือไม่",
              "ถ้าไลน์หยุดจริง ให้ปิดเคสเป็น “ไม่ใช่ปัญหา” และบันทึกวันหยุดในปฏิทิน",
              "ถ้าเป็นมิเตอร์อ่านอัตโนมัติ ตรวจสาย Modbus/gateway"],
    "missing": ["ตรวจว่าผู้จดตกหรือเข้าถึงมิเตอร์ไม่ได้",
                "ถ้าเข้าถึงยาก พิจารณาย้ายจุดอ่านหรือติดตั้ง gateway"],
    "holiday_load": ["เดินสำรวจหน้างานในวันหยุด ดูว่าอะไรยังเดินอยู่",
                     "ตรวจอุปกรณ์ที่ไม่มีระบบปิดอัตโนมัติ",
                     "ทำ checklist ปิดเครื่องก่อนหยุดยาว และมอบผู้รับผิดชอบ"],
    "baseload_up": ["โหลดพื้นฐาน = ที่ใช้ตลอดแม้ไม่ผลิต ขึ้นแปลว่ามีของเปิดค้าง",
                    "ตรวจลมอัดรั่ว วาล์ว และ solenoid",
                    "ตรวจฮีตเตอร์ ตู้ควบคุมอุณหภูมิ และไฟส่องสว่างที่ไม่ได้ปิด"],
    "fault": ["ตรวจจอ/แบตเตอรี่/ไฟเลี้ยงของมิเตอร์ และสาย CT", "ถ้าต้องเปลี่ยนมิเตอร์ ให้ช่างบันทึก “เปลี่ยนมิเตอร์” ในหน้าจดมิเตอร์",
              "ระหว่างมิเตอร์เสีย ให้ประมาณหน่วยจากมิเตอร์หลัก/ข้างเคียง แล้วแก้ “หน่วยที่ถูกต้อง” ภายหลัง"],
    "balance": ["ตรวจว่ามีโหลดใหม่ที่ยังไม่ได้ติดมิเตอร์ย่อย",
                "ตรวจ CT ratio ของมิเตอร์ว่าตั้งถูกหรือไม่",
                "ตรวจมิเตอร์ย่อยที่ไม่ได้จด/ค่าค้างในวันนั้น"],
}
EQUIPMENT_HINTS = [
    (("compressor", "คอมเพรส", "air", "ลม"), ["ลมอัดรั่วคือสาเหตุอันดับหนึ่ง — ตรวจด้วยเครื่องอัลตราโซนิก",
                                             "ตรวจแรงดันตั้งสูงเกินจำเป็นหรือไม่ (ลด 1 bar ประหยัด ~7%)",
                                             "ตรวจ drain trap เปิดค้าง"]),
    (("lighting", "light", "lp-", "แสงสว่าง"), ["ตรวจไฟเปิดค้างนอกเวลาทำงาน", "พิจารณาแยกวงจร ติดเซนเซอร์/ตัวตั้งเวลา"]),
    (("chiller", "air con", "aircon", "แอร์", "cooling"), ["ตรวจอุณหภูมิตั้งต่ำเกินจำเป็น", "ตรวจคอยล์สกปรก/สารทำความเย็น",
                                                          "ตรวจเปิดทิ้งนอกเวลาทำงาน"]),
    (("ht", "heat", "carbur", "oven", "furnace", "ฮีต", "เตา"), ["ตรวจฉนวนและซีลประตูเตา", "ตรวจอุ่นเตารอชิ้นงานนานเกินไป",
                                                              "ตรวจ thermocouple และการตั้งค่าควบคุมอุณหภูมิ"]),
    (("pump", "waste", "ro", "boiler", "ปั๊ม", "น้ำ"), ["ตรวจปั๊มเดินตลอดโดยไม่จำเป็น", "ตรวจท่อ/วาล์วรั่ว",
                                                      "พิจารณาอินเวอร์เตอร์ควบคุมรอบ"]),
]


def ensure_ops(db) -> None:
    db.executescript(DDL)


def hints_for(rule: str, name: str = "") -> list[str]:
    out = list(GENERIC_HINTS.get(rule, []))
    n = (name or "").lower()
    for keys, extra in EQUIPMENT_HINTS:
        if any(k in n for k in keys):
            return extra + out
    return out


def _f(v, name: str, allow_empty=True, minimum: float | None = 0.0):
    s = str(v if v is not None else "").replace(",", "").strip()
    if s == "":
        if allow_empty:
            return None
        raise S.ValidationError(f"กรุณากรอก{name}")
    try:
        x = float(s)
    except ValueError:
        raise S.ValidationError(f"{name} ต้องเป็นตัวเลข") from None
    if minimum is not None and x < minimum:
        raise S.ValidationError(f"{name} ต้องไม่ติดลบ")
    return x


def _ym(v) -> str:
    s = str(v or "").strip()[:7]
    try:
        y, m = (int(x) for x in s.split("-"))
        return date(y, m, 1).strftime("%Y-%m")
    except (ValueError, TypeError):
        raise S.ValidationError("เดือนไม่ถูกต้อง (YYYY-MM)") from None


# ───────────────────────── แก้ค่าอ่าน + ประวัติ ─────────────────────────

def correct(db, mid: int, day: str, value, u_fix, reason: str, actor) -> dict:
    """แก้เลขหน้าปัด และ/หรือ “หน่วยที่ถูกต้อง” ของวัน (เช่น วันเปลี่ยนมิเตอร์) — ต้องมีเหตุผลเสมอ"""
    from . import energy as EN
    m = EN.meter(db, mid)
    if not m:
        raise S.ValidationError("ไม่พบมิเตอร์")
    try:
        d = date.fromisoformat(day)
    except ValueError:
        raise S.ValidationError("วันที่ไม่ถูกต้อง") from None
    if d > S.now_dt().date():
        raise S.ValidationError("แก้ค่าวันล่วงหน้าไม่ได้")
    reason = (reason or "").strip()[:300]
    if len(reason) < 3:
        raise S.ValidationError("กรุณาระบุเหตุผลการแก้ไข")
    old = db.execute("SELECT value, u_override FROM en_readings WHERE meter_id=? AND day=?", (mid, day)).fetchone()
    new_v = _f(value, "เลขหน้าปัด")
    clear_u = str(u_fix or "").strip() in ("", "-")
    new_u = None if clear_u else _f(u_fix, "หน่วยที่ถูกต้อง")
    if new_v is None:
        if not old:
            raise S.ValidationError("วันนี้ยังไม่มีค่าอ่าน — กรอกเลขหน้าปัดด้วย")
        new_v = old[0]
    stamp = ts(S.now_dt())
    changes = []
    if not old or abs(old[0] - new_v) > 1e-9:
        changes.append(("value", old[0] if old else None, new_v))
    if (old[1] if old else None) != new_u and not (old and old[1] is not None and new_u is not None and abs(old[1] - new_u) < 1e-9):
        changes.append(("u_override", old[1] if old else None, new_u))
    if not changes:
        return {"changed": 0}
    db.execute("""INSERT INTO en_readings(meter_id, day, value, u_override, src, user_id, updated_at) VALUES (?,?,?,?,?,?,?)
                  ON CONFLICT(meter_id, day) DO UPDATE SET value=excluded.value, u_override=excluded.u_override,
                  src=excluded.src, user_id=excluded.user_id, updated_at=excluded.updated_at""",
               (mid, day, new_v, new_u, "fix", actor, stamp))
    for field, a, b in changes:
        db.execute("""INSERT INTO en_fix_log(meter_id, day, field, old_value, new_value, reason, user_id, created_at)
                      VALUES (?,?,?,?,?,?,?,?)""", (mid, day, field, a, b, reason, actor, stamp))
    S.audit(db, actor, "energy_fix", "en_readings", mid, before={"day": day, "value": old[0] if old else None,
            "u_override": old[1] if old else None}, after={"day": day, "value": new_v, "u_override": new_u, "reason": reason})
    return {"changed": len(changes)}


def fix_log(db, mid: int, limit: int = 50) -> list[dict]:
    ensure_ops(db)
    return [dict(r) for r in db.execute("""SELECT l.*, u.name AS user_name FROM en_fix_log l LEFT JOIN users u ON u.id=l.user_id
                                           WHERE l.meter_id=? ORDER BY l.id DESC LIMIT ?""", (mid, limit))]


# ───────────────────────── ปฏิทินวันหยุด ─────────────────────────

def holidays(db, year: int | None = None) -> list[dict]:
    ensure_ops(db)
    w, a = "", []
    if year:
        w, a = "WHERE h.day LIKE ?", [f"{year}-%"]
    return [dict(r) for r in db.execute(f"""SELECT h.*, f.name AS factory_name FROM en_holidays h
                                            LEFT JOIN factories f ON f.id=h.factory_id {w} ORDER BY h.day, h.factory_id""", a)]


def add_holiday(db, factory_id, day: str, name: str, kind: str, actor) -> None:
    ensure_ops(db)
    try:
        d0 = date.fromisoformat(str(day or "")[:10])
    except ValueError:
        raise S.ValidationError("วันที่ไม่ถูกต้อง") from None
    fid = int(factory_id) if str(factory_id or "").isdigit() and int(factory_id) else None
    kind = kind if kind in ("holiday", "shutdown") else "holiday"
    name = (name or "").strip()[:120] or ("หยุดซ่อมบำรุง" if kind == "shutdown" else "วันหยุด")
    db.execute("""INSERT INTO en_holidays(factory_id, day, name, kind) VALUES (?,?,?,?)
                  ON CONFLICT(factory_id, day) DO UPDATE SET name=excluded.name, kind=excluded.kind""",
               (fid, d0.isoformat(), name, kind))
    S.audit(db, actor, "energy_holiday", "en_holidays", None, after={"factory_id": fid, "day": d0.isoformat(), "name": name, "kind": kind})


def del_holiday(db, hid: int, actor) -> None:
    r = db.execute("SELECT * FROM en_holidays WHERE id=?", (hid,)).fetchone()
    if r:
        db.execute("DELETE FROM en_holidays WHERE id=?", (hid,))
        S.audit(db, actor, "energy_holiday_del", "en_holidays", hid, before=dict(r))


def off_days(db, factory_id, d_from: date, d_to: date, cfg: dict) -> set[str]:
    ensure_ops(db)
    out = {r[0] for r in db.execute("""SELECT day FROM en_holidays WHERE (factory_id IS NULL OR factory_id IS ?)
                                       AND day>=? AND day<=?""", (factory_id, d_from.isoformat(), d_to.isoformat()))}
    if cfg.get("sunday_off", 1):
        d = d_from
        while d <= d_to:
            if d.weekday() == 6:
                out.add(d.isoformat())
            d += timedelta(days=1)
    return out


# ───────────────────────── บิลค่าไฟ + ยอดผลิต ─────────────────────────

def save_bill(db, data: dict, actor) -> None:
    ensure_ops(db)
    fid = int(data.get("factory_id") or 0)
    if not fid:
        raise S.ValidationError("เลือกโรงงาน")
    ym = _ym(data.get("month"))
    v = {k: _f(data.get(k), n, allow_empty=k != "kwh") or 0.0 for k, n in
         (("kwh", "หน่วยตามบิล (kWh)"), ("amount", "ค่าไฟก่อน VAT"), ("ft", "ค่า Ft"), ("demand", "ค่า Demand"), ("vat", "VAT"))}
    if v["kwh"] <= 0:
        raise S.ValidationError("หน่วยตามบิลต้องมากกว่า 0")
    if not v["vat"] and v["amount"]:
        v["vat"] = round(v["amount"] * 0.07, 2)
    note = str(data.get("note") or "").strip()[:200]
    db.execute("""INSERT INTO en_bills(factory_id, month, kwh, amount, ft, demand, vat, note, user_id, updated_at)
                  VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(factory_id, month) DO UPDATE SET kwh=excluded.kwh,
                  amount=excluded.amount, ft=excluded.ft, demand=excluded.demand, vat=excluded.vat, note=excluded.note,
                  user_id=excluded.user_id, updated_at=excluded.updated_at""",
               (fid, ym, v["kwh"], v["amount"], v["ft"], v["demand"], v["vat"], note, actor, ts(S.now_dt())))
    S.audit(db, actor, "energy_bill", "en_bills", None, after=dict(v, factory_id=fid, month=ym))


def del_bill(db, bid: int, actor) -> None:
    r = db.execute("SELECT * FROM en_bills WHERE id=?", (bid,)).fetchone()
    if r:
        db.execute("DELETE FROM en_bills WHERE id=?", (bid,))
        S.audit(db, actor, "energy_bill_del", "en_bills", bid, before=dict(r))


def save_production(db, data: dict, actor) -> None:
    ensure_ops(db)
    fid = int(data.get("factory_id") or 0)
    if not fid:
        raise S.ValidationError("เลือกโรงงาน")
    ym = _ym(data.get("month"))
    qty = _f(data.get("qty"), "ยอดผลิต", allow_empty=False)
    unit = str(data.get("unit") or "ชิ้น").strip()[:20] or "ชิ้น"
    db.execute("""INSERT INTO en_production(factory_id, month, qty, unit, user_id, updated_at) VALUES (?,?,?,?,?,?)
                  ON CONFLICT(factory_id, month) DO UPDATE SET qty=excluded.qty, unit=excluded.unit,
                  user_id=excluded.user_id, updated_at=excluded.updated_at""", (fid, ym, qty, unit, actor, ts(S.now_dt())))
    S.audit(db, actor, "energy_production", "en_production", None, after={"factory_id": fid, "month": ym, "qty": qty, "unit": unit})


def bill_rate(db, factory_id, ym: str) -> float | None:
    ensure_ops(db)
    r = db.execute("SELECT kwh, amount, vat FROM en_bills WHERE factory_id IS ? AND month=?", (factory_id, ym)).fetchone()
    return (r[1] + r[2]) / r[0] if r and r[0] else None


def _month_total(db, factory_id, kind: str, y: int, mo: int) -> tuple[float, int]:
    """ยอดใช้ของโรงงานในเดือน (มิเตอร์หลัก ถ้ามี) และจำนวนวันที่มีข้อมูล"""
    from . import energy as EN
    ms = EN.meters(db, factory_id, kind)
    if not ms:
        return 0.0, 0
    d_from = date(y, mo, 1)
    d_to = min(date(y, mo, calendar.monthrange(y, mo)[1]), S.now_dt().date())
    if d_to < d_from:
        return 0.0, 0
    tm = EN.totals_set(ms)
    ser = EN.series(db, tm, d_from, d_to)
    days = set()
    tot = 0.0
    for m in tm:
        for d, x in ser[m["id"]].items():
            if x.get("u") is not None:
                tot += EN.sign(m) * x["u"]
                days.add(d)
    return round(tot, 2), len(days)


def cost_report(db, year: int, factory_id: int | None = None) -> dict:
    """บิลค่าไฟ + ยอดมิเตอร์ + ยอดผลิต → บาท/kWh จริง, ส่วนต่างบิล-มิเตอร์, kWh/หน่วยผลิต"""
    ensure_ops(db)
    from . import masterdata as M
    facs = [f for f in M.list_factories(db) if not factory_id or f["id"] == factory_id]
    bills = {(r["factory_id"], r["month"]): dict(r) for r in db.execute("SELECT * FROM en_bills WHERE month LIKE ?", (f"{year}-%",))}
    prod = {(r["factory_id"], r["month"]): dict(r) for r in db.execute("SELECT * FROM en_production WHERE month LIKE ?", (f"{year}-%",))}
    today = S.now_dt().date()
    out = []
    for f in facs:
        rows = []
        for mo in range(1, 13):
            if date(year, mo, 1) > today:
                break
            ym = f"{year}-{mo:02d}"
            meter_kwh, ndays = _month_total(db, f["id"], "elec", year, mo)
            b = bills.get((f["id"], ym))
            p = prod.get((f["id"], ym))
            total_baht = (b["amount"] + b["vat"]) if b else None
            kwh_ref = b["kwh"] if b else meter_kwh
            rows.append({"ym": ym, "month": mo, "meter_kwh": meter_kwh, "ndays": ndays, "bill": b,
                         "rate": round(total_baht / b["kwh"], 4) if b and b["kwh"] else None, "baht": total_baht,
                         "diff_pct": round(100 * (meter_kwh - b["kwh"]) / b["kwh"], 1) if b and b["kwh"] and meter_kwh else None,
                         "prod": p, "kwh_unit": round(kwh_ref / p["qty"], 3) if p and p["qty"] and kwh_ref else None,
                         "baht_unit": round(total_baht / p["qty"], 3) if p and p["qty"] and total_baht else None})
        sb = [r for r in rows if r["bill"]]
        out.append({"factory": f, "rows": rows,
                    "sum_kwh": round(sum(r["bill"]["kwh"] for r in sb), 1), "sum_baht": round(sum(r["baht"] for r in sb), 2),
                    "sum_meter": round(sum(r["meter_kwh"] for r in rows), 1),
                    "avg_rate": round(sum(r["baht"] for r in sb) / sum(r["bill"]["kwh"] for r in sb), 4) if sb else None})
    chart = {}
    for F in out:
        r12 = [None] * 12
        for r in F["rows"]:
            r12[r["month"] - 1] = r["rate"]
        if any(x is not None for x in r12):
            chart[F["factory"]["name"]] = r12
    return {"year": year, "factories": out, "chart": chart}


# ───────────────────────── รายงานตาม Section ─────────────────────────

def section_report(db, factory_id: int, kind: str, year: int, project_id=None, grp=None, line=None, by: str = "section") -> dict:
    """การใช้รายเดือนแยกตาม Section (กลุ่มของมิเตอร์ย่อย) + ยอดมิเตอร์หลัก + ส่วนที่ไม่มีมิเตอร์ย่อย"""
    from . import energy as EN
    from . import energy_struct as ST
    ms_all = EN.meters(db, factory_id, kind)
    filtered = bool(project_id or grp or line)
    ms = ST.apply_filter(ms_all, project_id, grp, line)
    today = S.now_dt().date()
    months = [mo for mo in range(1, 13) if date(year, mo, 1) <= today]
    d_from = date(year, 1, 1)
    d_to = min(date(year, 12, 31), today)
    ser = EN.series(db, ms, d_from, d_to) if ms and d_to >= d_from else {}
    tot_ids = {m["id"] for m in EN.totals_set(ms)}
    has_main = any(m["is_main"] == 1 for m in ms) and not filtered

    def per_month(group):
        vals = []
        for mo in months:
            p = f"{year}-{mo:02d}"
            vals.append(round(sum(EN.sign(m) * (x.get("u") or 0) for m in group for d, x in ser[m["id"]].items() if d.startswith(p)), 2))
        return vals

    sections: dict[str, list] = {}
    fm = EN.factory_mains(ms) if has_main else set()
    for m in ms:
        if m["id"] in fm:                                  # มิเตอร์หลักรวมของโรงงาน = แถว “รวม” ไม่ใช่ Section
            continue
        key = m["grp"] or "ไม่ระบุ Section"
        if by == "line":
            key += " › " + (m.get("line") or "(ไม่ระบุ Line)")
        sections.setdefault(key, []).append(m)
    rows = []
    for g, group in sections.items():
        vals = per_month(EN.counted(group))               # v0.90 ยอด Section = กติกาเดียวทั้งระบบ (ไม่นับซ้ำหลัก+ย่อย)
        mrows = [{"id": m["id"], "label": EN.label(m), "vals": per_month([m]), "role": m["is_main"]} for m in group]
        for r in mrows:
            r["sum"] = round(sum(r["vals"]), 2)
        mrows.sort(key=lambda r: -r["sum"])
        rows.append({"grp": g, "vals": vals, "sum": round(sum(vals), 2), "meters": mrows})
    rows.sort(key=lambda r: -r["sum"])
    if filtered:
        total = per_month([m for g in sections.values() for m in g])
    else:
        total = per_month([m for m in ms if m["id"] in tot_ids])
    sub_total = [round(sum(r["vals"][i] for r in rows), 2) for i in range(len(months))]
    unmetered = [round(t - s, 2) for t, s in zip(total, sub_total)] if has_main else None
    grand = round(sum(total), 2)
    for r in rows:
        r["share"] = round(100 * r["sum"] / grand, 1) if grand else None
    return {"months": months, "rows": rows, "total": total, "grand": grand, "sub_total": sub_total,
            "unmetered": unmetered, "has_main": has_main, "unit": (ms[0]["unit"] if ms else EN.KINDS[kind]["unit"]),
            "n_meters": len(ms), "filtered": filtered, "by": by, "facets": ST.facets(ms_all)}


def section_xlsx(db, factory_id: int, kind: str, year: int, project_id=None, grp=None, line=None, by: str = "section") -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    from . import energy as EN
    rep = section_report(db, factory_id, kind, year, project_id, grp, line, by)
    fac = db.execute("SELECT name FROM factories WHERE id=?", (factory_id,)).fetchone()
    wb = Workbook()
    ws = wb.active
    ws.title = "ตาม Section"
    ws.append([f"Energy Data · {EN.KINDS[kind]['th']} ({rep['unit']}) · {fac[0] if fac else ''} · ปี {year} · แยกตาม Section"])
    ws["A1"].font = Font(bold=True, size=13)
    head = ["Section / มิเตอร์"] + [f"{m:02d}/{year}" for m in rep["months"]] + ["รวม", "สัดส่วน %"]
    ws.append(head)
    for c in ws[2]:
        c.font, c.fill = Font(bold=True), PatternFill("solid", fgColor="DBEAFE")
    for r in rep["rows"]:
        ws.append([r["grp"]] + r["vals"] + [r["sum"], r["share"]])
        for c in ws[ws.max_row]:
            c.font = Font(bold=True)
        for m in r["meters"]:
            ws.append(["   " + m["label"]] + m["vals"] + [m["sum"], None])
    if rep["unmetered"] is not None:
        ws.append(["ไม่มีมิเตอร์ย่อย (หลัก − ย่อย)"] + rep["unmetered"] + [round(sum(rep["unmetered"]), 2), None])
    ws.append(["ยอดรวมโรงงาน"] + rep["total"] + [rep["grand"], 100 if rep["grand"] else None])
    for c in ws[ws.max_row]:
        c.font = Font(bold=True)
    ws.column_dimensions["A"].width = 42
    for i in range(2, len(head) + 1):
        ws.column_dimensions[ws.cell(row=2, column=i).column_letter].width = 12
    ws.freeze_panes = "B3"
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


# ───────────────────────── ตรวจความผิดปกติ ─────────────────────────

def _price(db, m: dict, day: str, cfg: dict, cache: dict) -> float:
    if m["price"] is not None:
        return m["price"]
    from .energy import KINDS
    kp = (KINDS.get(m["kind"]) or {}).get("price")
    if kp is not None:
        return kp
    if m["kind"] != "elec":
        return 0.0
    key = (m["factory_id"], day[:7])
    if key not in cache:
        cache[key] = bill_rate(db, m["factory_id"], day[:7]) or cfg["price_elec"]
    return cache[key]


def scan(db, factory_id: int | None = None, kind: str | None = None, days: int = 30, today: date | None = None) -> dict:
    """ตรวจ 7 กฎในช่วง N วันล่าสุด → รายการสิ่งที่พบ (ยังไม่บันทึก) พร้อมสถานะเคสที่เปิดไว้แล้ว"""
    from . import energy as EN
    ensure_ops(db)
    cfg = EN.settings(db)
    today = today or S.now_dt().date()
    d_to = today
    d_from = today - timedelta(days=max(1, days) - 1)
    base_from = d_from - timedelta(days=42)
    ms = EN.meters(db, factory_id, kind)
    ser = EN.series(db, ms, base_from, d_to)
    min_u = cfg["min_u"]
    offs: dict = {}
    pc: dict = {}
    found = []

    def add(m, rule, day, detail, impact=0.0, fid=None, grp=None, name=None):
        sev, title = RULES[rule]
        nm = name or (EN.label(m) if m else "")
        found.append({"rule": rule, "severity": sev, "title": f"{title} — {nm}", "rule_th": title, "detail": detail,
                      "meter_id": m["id"] if m else None, "factory_id": fid if fid is not None else (m["factory_id"] if m else None),
                      "factory": (m or {}).get("factory_name") or "", "kind": (m or {}).get("kind") or kind or "elec",
                      "grp": grp if grp is not None else (m or {}).get("grp", ""), "day": day, "label": nm,
                      "unit": (m or {}).get("unit") or "", "impact": round(max(0.0, impact), 2),
                      "baht": round(max(0.0, impact) * (_price(db, m, day, cfg, pc) if m else 0), 0),
                      "hints": hints_for(rule, f"{nm} {(m or {}).get('grp', '')}")})

    f0 = d_from.isoformat()
    for m in ms:
        s = ser[m["id"]]
        if m["factory_id"] not in offs:
            offs[m["factory_id"]] = off_days(db, m["factory_id"], base_from, d_to, cfg)
        off = offs[m["factory_id"]]
        items = sorted(s.items())
        work_hist = [(d, x["u"]) for d, x in items if x.get("u") is not None and d not in off and x.get("gap", 1) <= 1]
        # 1) ค่าลดลง
        for d, x in items:
            if d >= f0 and x["flag"] == "reset":
                add(m, "negative", d, f"เลขหน้าปัด {x['v']:,.2f} น้อยกว่าครั้งก่อน — ไม่นำมารวมยอด")
        # 2) พุ่งผิดปกติ (z-score เทียบวันทำงาน 28 วันก่อนหน้า)
        for i, (d, x) in enumerate(items):
            if d < f0 or x.get("u") is None or d in off or x.get("gap", 1) > 1:
                continue
            ref = [u for dd, u in work_hist if dd < d][-28:]
            if len(ref) < 7:
                continue
            mu = statistics.mean(ref)
            sd = statistics.pstdev(ref)
            if mu < min_u or x["u"] < min_u:
                continue
            z = (x["u"] - mu) / sd if sd > 1e-9 else (99.0 if x["u"] > mu * 1.5 else 0.0)
            if z >= cfg["z_warn"]:
                add(m, "spike", d, f"ใช้ {x['u']:,.1f} {m['unit']} · ปกติ ~{mu:,.1f} (z = {min(z, 99):.1f})", x["u"] - mu)
                if z < cfg["z_high"]:
                    found[-1]["severity"] = "warn"
        # 3) ค่าไม่ขยับ
        run = []
        typical = statistics.median([u for _, u in work_hist[-28:]]) if len(work_hist) >= 5 else 0
        for d, x in items:
            if x.get("u") == 0 and d not in off:
                run.append(d)
                continue
            if len(run) >= cfg["stuck_days"] and run[-1] >= f0 and typical >= min_u:
                add(m, "stuck", run[-1], f"เลขหน้าปัดไม่เปลี่ยน {len(run)} วันทำงาน ({run[0][8:]}/{run[0][5:7]}–{run[-1][8:]}/{run[-1][5:7]}) · ปกติ ~{typical:,.1f}/วัน")
            run = []
        if len(run) >= cfg["stuck_days"] and run[-1] >= f0 and typical >= min_u:
            add(m, "stuck", run[-1], f"เลขหน้าปัดไม่เปลี่ยน {len(run)} วันทำงานจนถึงล่าสุด · ปกติ ~{typical:,.1f}/วัน")
        # 4) ไม่ได้จดหลายวัน
        last = db.execute("SELECT MAX(day) FROM en_readings WHERE meter_id=?", (m["id"],)).fetchone()[0]
        if last:
            gap = (today - date.fromisoformat(last)).days
            if gap >= cfg["missing_days"] and (today - timedelta(days=60)).isoformat() <= last:
                add(m, "missing", today.isoformat(), f"ค่าล่าสุด {last[8:]}/{last[5:7]}/{last[:4]} — ขาด {gap} วัน")
        # 5) วันหยุดแต่ยังใช้สูง
        if m["kind"] in ("elec", "air", "water", "ro"):
            wk = [u for _, u in work_hist[-28:]]
            if len(wk) >= 7:
                med = statistics.median(wk)
                for d, x in items:
                    if d >= f0 and d in off and x.get("u") is not None and x.get("gap", 1) <= 1 and med >= min_u \
                            and x["u"] > cfg["holiday_ratio"] * med:
                        add(m, "holiday_load", d, f"วันหยุดใช้ {x['u']:,.1f} = {100 * x['u'] / med:.0f}% ของวันทำงาน (~{med:,.1f}) · เกณฑ์ {100 * cfg['holiday_ratio']:.0f}%",
                            x["u"] - cfg["holiday_ratio"] * med)
        # 6) โหลดพื้นฐานสูงขึ้น (ค่าต่ำสุดช่วง 20% ล่างของ 14 วันล่าสุด เทียบ 28 วันก่อนหน้า)
        vals = [(d, x["u"]) for d, x in items if x.get("u") is not None and x.get("gap", 1) <= 1]
        recent = [u for d, u in vals if d >= (today - timedelta(days=13)).isoformat()]
        before = [u for d, u in vals if (today - timedelta(days=41)).isoformat() <= d < (today - timedelta(days=13)).isoformat()]
        if len(recent) >= 7 and len(before) >= 10:
            def base(xs):
                xs = sorted(xs)
                return statistics.mean(xs[:max(1, len(xs) // 5)])
            b0, b1 = base(before), base(recent)
            if b0 >= min_u and b1 > cfg["baseload_rise"] * b0:
                add(m, "baseload_up", today.isoformat(), f"โหลดพื้นฐาน 14 วันล่าสุด ~{b1:,.1f}/วัน จากเดิม ~{b0:,.1f}/วัน (+{100 * (b1 / b0 - 1):.0f}%)",
                    (b1 - b0) * 30)
    # 7) สัดส่วนมิเตอร์ย่อย/หลัก (ไฟฟ้า, ต่อโรงงาน)
    by_f: dict = {}
    for m in ms:
        if m["kind"] == "elec":
            by_f.setdefault(m["factory_id"], []).append(m)
    pairs = []
    for fid, group in by_f.items():                       # v0.90 ทุกชุด มิเตอร์หลัก → มิเตอร์ที่มันครอบ (โครงสร้างเดียวกับหน้าบริหาร)
        for b in EN.balance(group, {}):
            pairs.append((fid, b["parents"], b["kids"]))
    for fid, mains, subs in pairs:
        if not mains or len(subs) < 2:
            continue
        cov = {}
        for d in sorted({d for m in mains for d in ser[m["id"]]}):
            mv = sum((ser[m["id"]].get(d) or {}).get("u") or 0 for m in mains)
            if mv < min_u * 10 or any(((ser[m["id"]].get(d) or {}).get("u") is None) for m in mains):
                continue
            sv = sum(EN.sign(m) * ((ser[m["id"]].get(d) or {}).get("u") or 0) for m in subs)
            cov[d] = (sv / mv, mv, sv)
        if len(cov) < 10:
            continue
        med = statistics.median(c[0] for c in cov.values())
        worst = sorted(((d, c) for d, c in cov.items() if d >= f0 and abs(c[0] - med) > cfg["balance_tol"]),
                       key=lambda t: -abs(t[1][0] - med))[:5]
        for d, (r, mv, sv) in worst:
            add(mains[0], "balance", d, f"มิเตอร์ย่อยรวม {sv:,.0f} = {100 * r:.0f}% ของมิเตอร์หลัก {mv:,.0f} kWh · ปกติ ~{100 * med:.0f}%",
                abs(r - med) * mv, fid=fid, grp=mains[0].get("grp") or "ทั้งโรงงาน",
                name=f"{EN.label(mains[0])} (หลัก vs ย่อย)")
    # ผูกเคสที่เปิดไว้แล้ว
    for x in found:
        r = db.execute("""SELECT id, status FROM en_cases WHERE IFNULL(meter_id,0)=? AND IFNULL(factory_id,0)=? AND day=? AND rule=?""",
                       (x["meter_id"] or 0, x["factory_id"] or 0, x["day"], x["rule"])).fetchone()
        x["case_id"], x["case_status"] = (r[0], r[1]) if r else (None, None)
    found.sort(key=lambda x: (SEV[x["severity"]][1], -x["baht"], -x["impact"], x["day"]))
    counts = {k: sum(1 for x in found if x["rule"] == k) for k in RULES}
    return {"items": found, "counts": counts, "d_from": d_from, "d_to": d_to, "days": days,
            "sev": {k: sum(1 for x in found if x["severity"] == k) for k in SEV},
            "baht": round(sum(x["baht"] for x in found if not x["case_id"]), 0)}


# ───────────────────────── เคสติดตาม ─────────────────────────

def open_case(db, data: dict, actor) -> int:
    ensure_ops(db)
    rule = data.get("rule")
    if rule not in RULES_ALL:
        raise S.ValidationError("กฎไม่ถูกต้อง")
    try:
        day = date.fromisoformat(str(data.get("day") or "")[:10]).isoformat()
    except ValueError:
        raise S.ValidationError("วันที่ไม่ถูกต้อง") from None
    mid = int(data.get("meter_id") or 0) or None
    fid = int(data.get("factory_id") or 0) or None
    r = db.execute("SELECT id FROM en_cases WHERE IFNULL(meter_id,0)=? AND IFNULL(factory_id,0)=? AND day=? AND rule=?",
                   (mid or 0, fid or 0, day, rule)).fetchone()
    if r:
        return r[0]
    sev = data.get("severity") if data.get("severity") in SEV else RULES_ALL[rule][0]
    stamp = ts(S.now_dt())
    cid = db.execute("""INSERT INTO en_cases(factory_id, meter_id, kind, grp, day, rule, severity, title, detail, impact, baht,
                        status, opened_by, opened_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,'open',?,?,?)""",
                     (fid, mid, data.get("kind") or "elec", str(data.get("grp") or "")[:80], day, rule, sev,
                      str(data.get("title") or RULES_ALL[rule][1])[:200], str(data.get("detail") or "")[:1000],
                      _f(data.get("impact"), "ผลกระทบ") or 0, _f(data.get("baht"), "บาท") or 0, actor, stamp, stamp)).lastrowid
    S.audit(db, actor, "energy_case_open", "en_cases", cid, after={"rule": rule, "day": day, "meter_id": mid})
    return cid


def case(db, cid: int) -> dict | None:
    ensure_ops(db)
    r = db.execute("""SELECT c.*, f.name AS factory_name, m.code AS m_code, m.name AS m_name, m.unit AS unit,
                      u.name AS assignee_name, o.name AS opened_name FROM en_cases c
                      LEFT JOIN factories f ON f.id=c.factory_id LEFT JOIN en_meters m ON m.id=c.meter_id
                      LEFT JOIN users u ON u.id=c.assignee_id LEFT JOIN users o ON o.id=c.opened_by WHERE c.id=?""", (cid,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["hints"] = hints_for(d["rule"], f"{d.get('m_name') or ''} {d.get('grp') or ''}")
    return d


def update_case(db, cid: int, data: dict, actor) -> None:
    c = case(db, cid)
    if not c:
        raise S.ValidationError("ไม่พบเคส")
    status = data.get("status") or c["status"]
    if status not in STATUS:
        raise S.ValidationError("สถานะไม่ถูกต้อง")
    cause = str(data.get("cause") if data.get("cause") is not None else c["cause"]).strip()[:120]
    action = str(data.get("action") if data.get("action") is not None else c["action"]).strip()[:1000]
    saved = _f(data.get("saved"), "หน่วยที่ประหยัดได้")
    saved = c["saved"] if saved is None else saved
    aid = data.get("assignee_id")
    aid = (int(aid) if str(aid).isdigit() and int(aid) else None) if aid is not None else c["assignee_id"]
    if status in ("fixed", "ignored") and not cause:
        raise S.ValidationError("ปิดเคสต้องระบุสาเหตุ")
    if status == "fixed" and not action:
        raise S.ValidationError("ปิดเคส “แก้แล้ว” ต้องระบุวิธีแก้")
    closed = c["closed_at"]
    if status in ("fixed", "ignored") and c["status"] not in ("fixed", "ignored"):
        closed = ts(S.now_dt())
    elif status in ("open", "checking"):
        closed = None
    db.execute("""UPDATE en_cases SET status=?, cause=?, action=?, saved=?, assignee_id=?, closed_at=?, updated_at=? WHERE id=?""",
               (status, cause, action, saved if status == "fixed" else 0, aid, closed, ts(S.now_dt()), cid))
    S.audit(db, actor, "energy_case", "en_cases", cid, before={k: c[k] for k in ("status", "cause", "action", "saved", "assignee_id")},
            after={"status": status, "cause": cause, "action": action, "saved": saved, "assignee_id": aid})


def cases(db, status: str | None = None, factory_id: int | None = None, kind: str | None = None, limit: int = 300) -> list[dict]:
    ensure_ops(db)
    w, a = ["1=1"], []
    if status == "active":
        w.append("c.status IN ('open','checking')")
    elif status in STATUS:
        w.append("c.status=?")
        a.append(status)
    if factory_id:
        w.append("c.factory_id=?")
        a.append(factory_id)
    if kind:
        w.append("c.kind=?")
        a.append(kind)
    return [dict(r) for r in db.execute(f"""SELECT c.*, f.name AS factory_name, m.code AS m_code, m.name AS m_name, m.unit AS unit,
                                            u.name AS assignee_name FROM en_cases c LEFT JOIN factories f ON f.id=c.factory_id
                                            LEFT JOIN en_meters m ON m.id=c.meter_id LEFT JOIN users u ON u.id=c.assignee_id
                                            WHERE {' AND '.join(w)}
                                            ORDER BY CASE c.status WHEN 'open' THEN 0 WHEN 'checking' THEN 1 ELSE 2 END,
                                            CASE c.severity WHEN 'high' THEN 0 WHEN 'warn' THEN 1 ELSE 2 END, c.day DESC, c.id DESC
                                            LIMIT ?""", [*a, limit])]


def case_summary(db, factory_id: int | None = None) -> dict:
    ensure_ops(db)
    w, a = "", []
    if factory_id:
        w, a = "WHERE factory_id=?", [factory_id]
    st = {k: 0 for k in STATUS}
    for r in db.execute(f"SELECT status, COUNT(*) FROM en_cases {w} GROUP BY status", a):
        st[r[0]] = r[1]
    saved = db.execute(f"""SELECT kind, SUM(saved), COUNT(*) FROM en_cases {w + (' AND ' if w else 'WHERE ')} status='fixed'
                           GROUP BY kind""", a).fetchall()
    high = db.execute(f"""SELECT COUNT(*) FROM en_cases {w + (' AND ' if w else 'WHERE ')} status IN ('open','checking')
                          AND severity='high'""", a).fetchone()[0]
    return {"status": st, "active": st["open"] + st["checking"], "high": high,
            "saved": {r[0]: {"units": round(r[1] or 0, 1), "n": r[2]} for r in saved}}


def assignees(db) -> list[dict]:
    return [dict(r) for r in db.execute("""SELECT id, name, role FROM users WHERE active=1 AND role IN ('admin','supervisor','technician')
                                           ORDER BY name""")]
