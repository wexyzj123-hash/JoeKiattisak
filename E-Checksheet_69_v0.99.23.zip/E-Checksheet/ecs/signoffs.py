"""ecs/signoffs.py — v0.24 ลายเซ็นประจำตัว + การยืนยันของหน่วยงาน (ENVIRONMENT / SAFETY) ในระบบแทนการเซ็นบนกระดาษ

  ลายเซ็นประจำตัว  : ผู้ใช้วาดบนจอหรืออัปโหลดรูป → เก็บเป็น PNG พื้นใส (cs_user_signatures)
                     ใบบันทึกรายเดือนใช้รูปนี้ในแถว ผู้ตรวจ / หัวหน้างาน / ช่องลงนามหน่วยงาน (ไม่มีรูป = แสดงชื่อ)
  การยืนยันหน่วยงาน: 1 ช่องลงนาม = 1 slot ต่อแบบฟอร์ม/เดือน (cs_signoffs)
      row:<key>:<วันเริ่ม>  แถวลงนามรายสัปดาห์/รายเดือน (key = env_week, env_month, safety_month หรือ c0.. = แถวกำหนดเอง)
      box:<env|safety>:<i>  ช่องในกล่องมุมขวาบน (env: 0 MANAGER, 1 SSV/SV · safety: 0 DM, 1 SAFETY)
  ผู้มีสิทธิ์ลงนาม: กลุ่ม env_mgr / env_sv / safety_dm / safety_sf (ตั้งที่หน้า "ลงนามหน่วยงาน" โดยผู้ดูแลระบบ · cs_meta sign_roles)
  ลำดับในกล่อง: ENVIRONMENT = SSV/SV ตรวจก่อน แล้ว MANAGER อนุมัติ · SAFETY = DM ก่อน ▶ SAFETY
"""
from __future__ import annotations

import base64
import io
import json
from datetime import date

from . import services as S
from . import sign_blocks as SB

DDL = """
CREATE TABLE IF NOT EXISTS cs_user_signatures (
    user_id    INTEGER PRIMARY KEY,
    png        BLOB NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cs_signoffs (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id   INTEGER NOT NULL,
    month     TEXT NOT NULL,              -- YYYY-MM
    slot      TEXT NOT NULL,
    user_id   INTEGER NOT NULL,
    signed_at TEXT NOT NULL,
    UNIQUE(form_id, month, slot)
);
CREATE INDEX IF NOT EXISTS ix_cs_signoffs_month ON cs_signoffs(month, form_id);
"""

# v0.25 ตำแหน่งงาน (ผู้ดูแลระบบกำหนดรายคน) ไล่จากต่ำไปสูง — ใช้กำหนดสิทธิ์ลงนามแต่ละช่อง
POSITIONS = {"tech": "Tech", "srtech": "Sr.Tech", "fm": "FM", "sv": "SV", "ssv": "SSV", "dm": "DM"}
# กลุ่มหน่วยงาน (แยกจากสายงาน) — ตั้งที่หน้า "ลงนามหน่วยงาน"
GROUPS = {"env_sv": "ENVIRONMENT — SSV/SV (Checked by)", "env_mgr": "ENVIRONMENT — MANAGER (Approved by)",
          "safety_sf": "SAFETY — เจ้าหน้าที่ SAFETY"}
DEPT_GROUPS = {"env": ["env_mgr", "env_sv"], "safety": ["safety_sf"]}
# ช่องลงนามมาตรฐานของทุกใบบันทึกรายเดือน
# หัวหน้างานรายสัปดาห์: เติมอัตโนมัติเมื่อผลตรวจในสัปดาห์นั้นได้รับอนุมัติครบ (ผู้อนุมัติคนล่าสุดของสัปดาห์)
STD_WEEK = {"key": "sup", "label": "หัวหน้างาน (Sr.Tech)", "positions": []}
STD_MONTH = [("mon:insp", "ผู้ตรวจ (Sr.Tech/FM)", ["srtech", "fm"], None),
             ("mon:sup", "หัวหน้างาน (SV/SSV)", ["sv", "ssv"], "mon:insp")]
# กล่อง Utility มุมขวาบน (เลือกรายแบบฟอร์ม) — แทนช่องลงนามท้ายเอกสาร: SV/SSV ก่อน แล้ว Manager (ตำแหน่ง DM)
UTIL_SLOTS = [("box:util:1", "Utility — SV/SSV", ["sv", "ssv"], None, "SV/SSV"),
              ("box:util:0", "Utility — Manager", ["dm"], "box:util:1", "Manager")]
SIG_MAX = (600, 200)
INK = (20, 35, 120)                       # สีหมึกน้ำเงินเข้ม (เหมือนปากกาลูกลื่น)


def ensure(db) -> None:
    db.executescript(DDL)
    have = {r[1] for r in db.execute("PRAGMA table_info(cs_signoffs)")}
    if "auto" not in have:                                   # v0.26 เติมอัตโนมัติจากการอนุมัติ
        db.execute("ALTER TABLE cs_signoffs ADD COLUMN auto INTEGER NOT NULL DEFAULT 0")
    if not db.execute("SELECT 1 FROM cs_meta WHERE key='v26_week_auto'").fetchone():
        # แถวหัวหน้างานรายสัปดาห์เปลี่ยนเป็นเติมจากการอนุมัติ → คำนวณใหม่ 4 เดือนล่าสุด
        db.execute("DELETE FROM cs_signoffs WHERE slot LIKE 'row:sup:%'")
        for r in db.execute("""SELECT DISTINCT form_id, substr(finished_at, 1, 10) d FROM cs_submissions
                               WHERE finished_at >= date('now', '-125 days')""").fetchall():
            try:
                sync_week(db, r[0], date.fromisoformat(r[1]))
            except Exception:                                # noqa: BLE001
                pass
        db.execute("INSERT INTO cs_meta(key, value) VALUES('v26_week_auto', '1')")


class SignError(ValueError):
    pass


# ───────────────────────── ลายเซ็นประจำตัว ─────────────────────────

def process_signature(raw: bytes) -> bytes:
    """รูปใดก็ได้ (วาดจากจอ = PNG พื้นใส / สแกนกระดาษ = พื้นขาว) → PNG พื้นใส หมึกน้ำเงิน ตัดขอบ ย่อไม่เกิน 600×200"""
    from PIL import Image, ImageOps
    try:
        im = Image.open(io.BytesIO(raw))
        im = ImageOps.exif_transpose(im)
        im.load()
    except Exception as e:                                   # noqa: BLE001
        raise SignError("ไฟล์รูปลายเซ็นไม่ถูกต้อง") from e
    if max(im.size) > 4000:
        im.thumbnail((4000, 4000))
    rgba = im.convert("RGBA")
    bg = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
    flat = Image.alpha_composite(bg, rgba).convert("L")     # พื้นใส → ขาว
    # ความเข้มของหมึก: ขาว (≥225) = ใส · เข้ม = ทึบ
    alpha = flat.point(lambda v: 0 if v >= 225 else min(255, int((225 - v) * 255 / 150)))
    box = alpha.point(lambda v: 255 if v > 40 else 0).getbbox()
    if not box:
        raise SignError("ไม่พบเส้นลายเซ็นในรูป")
    pad = 6
    box = (max(0, box[0] - pad), max(0, box[1] - pad), min(alpha.width, box[2] + pad), min(alpha.height, box[3] + pad))
    alpha = alpha.crop(box)
    out = Image.new("RGBA", alpha.size, INK + (0,))
    out.putalpha(alpha)
    out.thumbnail(SIG_MAX, Image.LANCZOS)
    buf = io.BytesIO()
    out.save(buf, "PNG", optimize=True)
    return buf.getvalue()


def save_signature(db, user_id: int, raw: bytes, actor_id=None) -> None:
    if not raw or len(raw) > 8 * 1024 * 1024:
        raise SignError("ไฟล์รูปลายเซ็นว่างหรือใหญ่เกินไป (ไม่เกิน 8 MB)")
    png = process_signature(raw)
    db.execute("""INSERT INTO cs_user_signatures(user_id, png, updated_at) VALUES (?,?,?)
                  ON CONFLICT(user_id) DO UPDATE SET png=excluded.png, updated_at=excluded.updated_at""", (user_id, png, S.ts()))
    S.audit(db, actor_id or user_id, "signature_set", "users", user_id)


def delete_signature(db, user_id: int, actor_id=None) -> None:
    db.execute("DELETE FROM cs_user_signatures WHERE user_id=?", (user_id,))
    S.audit(db, actor_id or user_id, "signature_delete", "users", user_id)


def signature_png(db, user_id) -> bytes | None:
    r = db.execute("SELECT png FROM cs_user_signatures WHERE user_id=?", (user_id,)).fetchone() if user_id else None
    return bytes(r[0]) if r else None


def data_uri(png: bytes | None) -> str:
    return "data:image/png;base64," + base64.b64encode(png).decode() if png else ""


def rotated(png: bytes) -> bytes:
    """หมุน 90° (อ่านจากล่างขึ้นบน) สำหรับช่องแคบแนวตั้งของแถวผู้ตรวจ/หัวหน้างาน"""
    from PIL import Image
    im = Image.open(io.BytesIO(png)).rotate(90, expand=True)
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return buf.getvalue()


def sig_bundle(db, user_ids) -> dict:
    """{uid: {h, v, png, vpng}} สำหรับเอกสาร (h = แนวนอน, v = หมุนแนวตั้ง) — เฉพาะคนที่มีลายเซ็น"""
    out = {}
    for uid in {u for u in user_ids if u}:
        png = signature_png(db, uid)
        if png:
            try:
                v = rotated(png)
            except Exception:                                # noqa: BLE001
                v = png
            out[uid] = {"h": data_uri(png), "v": data_uri(v), "png": png, "vpng": v}
    return out


# ───────────────────────── ผู้มีสิทธิ์ลงนาม ─────────────────────────

def get_roles(db) -> dict:
    r = db.execute("SELECT value FROM cs_meta WHERE key='sign_roles'").fetchone()
    try:
        d = json.loads(r[0]) if r and r[0] else {}
    except ValueError:
        d = {}
    return {g: [int(x) for x in d.get(g) or [] if str(x).isdigit()] for g in GROUPS}


def save_roles(db, data: dict, actor_id) -> dict:
    cfg = {g: sorted({int(x) for x in data.get(g) or [] if str(x).isdigit()}) for g in GROUPS}
    db.execute("INSERT INTO cs_meta(key, value) VALUES('sign_roles', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(cfg),))
    S.audit(db, actor_id, "update", "cs_meta", None, after={"sign_roles": cfg})
    _CACHE.clear()
    return cfg


def save_positions(db, data: dict, actor_id) -> int:
    """{user_id: position} จากหน้าผู้มีสิทธิ์ลงนาม"""
    n = 0
    for uid, pos in data.items():
        pos = pos if pos in POSITIONS else ""
        r = db.execute("SELECT COALESCE(position,'') FROM users WHERE id=?", (uid,)).fetchone()
        if r and r[0] != pos:
            db.execute("UPDATE users SET position=? WHERE id=?", (pos, uid))
            S.audit(db, actor_id, "position", "users", uid, before=r[0], after=pos)
            n += 1
    _CACHE.clear()
    return n


def user_groups(db, user_id) -> set[str]:
    return {g for g, ids in get_roles(db).items() if user_id in ids}


def user_position(db, user_id) -> str:
    r = db.execute("SELECT COALESCE(position,'') FROM users WHERE id=?", (user_id,)).fetchone()
    return r[0] if r else ""


# ───────────────────────── ช่องลงนามของแบบฟอร์ม/เดือน ─────────────────────────

def month_key(month: date) -> str:
    return month.strftime("%Y-%m")


def _last_day(month: date) -> int:
    import calendar
    return calendar.monthrange(month.year, month.month)[1]


def records(db, form_id: int, month: date) -> dict:
    return {r["slot"]: dict(r) for r in db.execute(
        """SELECT so.*, u.name AS user_name, COALESCE(u.position,'') AS user_pos FROM cs_signoffs so
           LEFT JOIN users u ON u.id=so.user_id WHERE so.form_id=? AND so.month=?""", (form_id, month_key(month)))}


def records_all(db, month: date) -> dict:
    out: dict = {}
    for r in db.execute("""SELECT so.*, u.name AS user_name, COALESCE(u.position,'') AS user_pos FROM cs_signoffs so
                           LEFT JOIN users u ON u.id=so.user_id WHERE so.month=?""", (month_key(month),)):
        out.setdefault(r["form_id"], {})[r["slot"]] = dict(r)
    return out


def sub_days(db, month: date, form_id: int | None = None) -> dict:
    """{form_id: {วันที่มีผลตรวจ}} ของเดือน"""
    last = _last_day(month)
    a, b = f"{month_key(month)}-01 00:00:00", f"{month_key(month)}-{last:02d} 23:59:59"
    out: dict = {}
    for r in db.execute("""SELECT form_id, CAST(substr(finished_at, 9, 2) AS INTEGER) d FROM cs_submissions
                           WHERE status<>'superseded' AND finished_at BETWEEN ? AND ? AND (? IS NULL OR form_id=?)
                           GROUP BY form_id, d""", (a, b, form_id, form_id)):
        out.setdefault(r["form_id"], set()).add(r["d"])
    return out


def pending_all(db, month: date, form_id: int | None = None) -> dict:
    """{form_id: จำนวนผลตรวจในเดือนที่ยังไม่อนุมัติ (รออนุมัติ / ตีกลับรอแก้)}"""
    last = _last_day(month)
    a, b = f"{month_key(month)}-01 00:00:00", f"{month_key(month)}-{last:02d} 23:59:59"
    return {r[0]: r[1] for r in db.execute(
        """SELECT form_id, COUNT(*) FROM cs_submissions WHERE status IN ('submitted','returned')
           AND approval_status<>'approved' AND finished_at BETWEEN ? AND ? AND (? IS NULL OR form_id=?)
           GROUP BY form_id""", (a, b, form_id, form_id))}


def week_of(month: date, day: int) -> dict:
    return next(sg for sg in SB.week_segments(month, _last_day(month)) if sg["start"] <= day < sg["start"] + sg["span"])


def seg_of(db, form, month: date, day: int) -> dict:
    """v0.37 ช่องหัวหน้างาน (Sr.Tech) ที่วันนั้นอยู่ — ความยาวตามที่ตั้งในแบบฟอร์ม (ค่าเริ่มต้น = ตามรอบตรวจ ≥ 1 สัปดาห์)"""
    f = form if isinstance(form, dict) else S.get_form(db, form)
    if not f:
        return week_of(month, day)
    return next(sg for sg in SB.sup_segments(db, f, month, _last_day(month)) if sg["start"] <= day < sg["start"] + sg["span"])


def resync_form(db, form_id: int) -> None:
    """คำนวณช่องหัวหน้างานที่เติมอัตโนมัติใหม่ทุกเดือนที่มีผลตรวจ (หลังเปลี่ยนความยาวช่อง / รอบตรวจ)"""
    months = [r[0] for r in db.execute("""SELECT DISTINCT substr(finished_at, 1, 7) FROM cs_submissions
                                          WHERE form_id=? AND finished_at IS NOT NULL""", (form_id,))]
    months = sorted(set(months) | {r[0] for r in db.execute(
        "SELECT DISTINCT month FROM cs_signoffs WHERE form_id=? AND slot LIKE 'row:sup:%'", (form_id,))})
    form = S.get_form(db, form_id)
    if not form:
        return
    for mk in months:
        try:
            y, m = (int(x) for x in mk.split("-"))
        except ValueError:
            continue
        month = date(y, m, 1)
        db.execute("DELETE FROM cs_signoffs WHERE form_id=? AND month=? AND slot LIKE 'row:sup:%' AND COALESCE(auto,0)=1",
                   (form_id, mk))
        for sg in SB.sup_segments(db, form, month, _last_day(month)):
            sync_week(db, form_id, date(y, m, sg["start"]), form=form)
    _CACHE.clear()


def sync_week(db, form_id: int, day: date, form: dict | None = None) -> None:
    """แถวหัวหน้างาน (Sr.Tech) = อนุมัติผลตรวจในช่วงของช่องนั้นครบทุกฉบับ → ลงนามอัตโนมัติด้วยผู้อนุมัติคนล่าสุด · ไม่ครบ → ว่าง
    v0.37 ช่วง = ความยาวช่องที่ตั้งในแบบฟอร์ม (สัปดาห์ / 2 สัปดาห์ / ครึ่งเดือน / เดือน / วัน)"""
    month = day.replace(day=1)
    sg = seg_of(db, form or form_id, month, day.day)
    a = f"{month_key(month)}-{sg['start']:02d} 00:00:00"
    b = f"{month_key(month)}-{sg['start'] + sg['span'] - 1:02d} 23:59:59"
    rows = db.execute("""SELECT approval_status, approved_by, approved_at FROM cs_submissions
                         WHERE form_id=? AND status IN ('submitted','returned') AND finished_at BETWEEN ? AND ?""",
                      (form_id, a, b)).fetchall()
    slot = f"row:sup:{sg['start']}"
    cur = db.execute("SELECT user_id, signed_at FROM cs_signoffs WHERE form_id=? AND month=? AND slot=?",
                     (form_id, month_key(month), slot)).fetchone()
    done = rows and all(r["approval_status"] == "approved" for r in rows)
    who = [r for r in rows if r["approved_by"]]              # ข้อมูลเก่าที่อนุมัติโดยไม่มีชื่อผู้อนุมัติ → ข้าม
    if not done or not who:
        if cur:
            db.execute("DELETE FROM cs_signoffs WHERE form_id=? AND month=? AND slot=?", (form_id, month_key(month), slot))
            _CACHE.clear()
        return
    last = max(who, key=lambda r: r["approved_at"] or "")
    if cur and cur["user_id"] == last["approved_by"] and cur["signed_at"] == last["approved_at"]:
        return
    db.execute("""INSERT INTO cs_signoffs(form_id, month, slot, user_id, signed_at, auto) VALUES (?,?,?,?,?,1)
                  ON CONFLICT(form_id, month, slot) DO UPDATE SET user_id=excluded.user_id, signed_at=excluded.signed_at, auto=1""",
               (form_id, month_key(month), slot, last["approved_by"], last["approved_at"] or S.ts()))
    _CACHE.clear()


def sync_sub(db, sub_id: int | None = None, form_id: int | None = None, finished_at: str | None = None) -> None:
    """เรียกหลังส่ง/อนุมัติ/ตีกลับ/ลบผลตรวจ — ไม่ทำให้งานหลักล้มถ้าผิดพลาด"""
    try:
        if sub_id and not (form_id and finished_at):
            r = db.execute("SELECT form_id, finished_at FROM cs_submissions WHERE id=?", (sub_id,)).fetchone()
            if not r:
                return
            form_id, finished_at = r[0], r[1]
        d = S.parse_ts(finished_at)
        if form_id and d:
            sync_week(db, form_id, d.date())
    except Exception:                                        # noqa: BLE001
        import logging
        logging.getLogger(__name__).exception("sync_week failed")


def slots(db, form: dict, month: date, cfg: dict | None = None, recs: dict | None = None, days: set | None = None,
          pend: int | None = None) -> list[dict]:
    """ทุกช่องที่ต้องลงนามของแบบฟอร์มในเดือนนั้น:
    {slot, kind, label, part, groups, positions, opens, after, rec, na}  na = ไม่มีผลตรวจในช่วงนั้น (ไม่ต้องลงนาม)"""
    cfg = cfg if cfg is not None else SB.effective(db, form)
    last = _last_day(month)
    dept = SB.dept(cfg)
    recs = recs if recs is not None else records(db, form["id"], month)
    days = days if days is not None else sub_days(db, month, form["id"]).get(form["id"], set())
    pend = pend if pend is not None else pending_all(db, month, form["id"]).get(form["id"], 0)
    segs_w = SB.week_segments(month, last)
    last_week = date(month.year, month.month, segs_w[-1]["start"])
    segs_sup = SB.sup_segments(db, form, month, last) if form.get("id") else segs_w
    out = []

    def add(slot, kind, label, part, groups, positions, opens, after=None, need=None, role="", gate=False, auto=False):
        out.append({"slot": slot, "kind": kind, "label": label, "part": part, "groups": groups, "positions": positions,
                    "opens": opens, "after": after, "rec": recs.get(slot), "role": role or label, "auto": auto,
                    "pending": pend if gate else 0, "na": not (days & need) if need is not None else not days,
                    "days": sorted(days & need) if need is not None else sorted(days)})     # v0.27 วันที่มีผลตรวจของช่องนี้

    # หัวหน้างาน (Sr.Tech) — ทุกใบบันทึก · ความยาวช่องตามที่ตั้ง (ค่าเริ่มต้นรายสัปดาห์ / ตามรอบตรวจ)
    for sg in segs_sup:
        add(f"row:sup:{sg['start']}", "row", STD_WEEK["label"], f"{sg['start']}–{sg['start'] + sg['span'] - 1}", [],
            STD_WEEK["positions"], date(month.year, month.month, sg["start"]), need=set(range(sg["start"], sg["start"] + sg["span"])),
            auto=True)
    rows = [(k, SB.PRESET_ROWS[k][0], SB.PRESET_ROWS[k][1], DEPT_GROUPS[SB.ROW_DEPT[k]], ["dm"] if SB.ROW_DEPT[k] == "safety" else [])
            for k in cfg["rows"]]
    rows += [(f"c{i}", c["label"], c["freq"], DEPT_GROUPS.get(dept, []), ["srtech", "fm", "sv", "ssv", "dm"])
             for i, c in enumerate(cfg["custom_rows"])]
    for key, label, freq, groups, positions in rows:
        segs = segs_w if freq == "week" else [{"start": 1, "span": last, "label": ""}]
        for sg in segs:
            part = f"{sg['start']}–{sg['start'] + sg['span'] - 1}" if freq == "week" else "ทั้งเดือน"
            add(f"row:{key}:{sg['start']}", "row", label, part, groups, positions, date(month.year, month.month, sg["start"]),
                need=set(range(sg["start"], sg["start"] + sg["span"])))
    if dept:
        b = SB.PRESET_BOXES[dept]
        order = b["order"]
        for n, i in enumerate(order):
            role, act = b["cols"][i]
            grp = b["groups"][i]
            add(f"box:{dept}:{i}", "box", (b["title"] or "SAFETY") + " — " + role + (f" ({act})" if act else ""), "ประจำเดือน",
                [grp] if grp in GROUPS else [], ["dm"] if grp == "dm" else [], last_week,
                after=f"box:{dept}:{order[n - 1]}" if n else None, role=role)
    # ช่องลงนามรายเดือนของสายงาน: กล่อง Utility มุมขวาบน (ถ้าเลือก) หรือช่องท้ายเอกสาร — ต้องอนุมัติผลตรวจครบทั้งเดือนก่อน
    if cfg.get("util"):
        for slot, label, positions, after, role in UTIL_SLOTS:
            add(slot, "month", label, "ประจำเดือน", [], positions, last_week, after=after, role=role, gate=True)
    else:
        for slot, label, positions, after in STD_MONTH:
            add(slot, "month", label, "ประจำเดือน", [], positions, last_week, after=after, role=label, gate=True)
    return out


def check(db, sl: dict, user: dict, all_slots: list[dict], today: date | None = None, groups: set | None = None,
          form: dict | None = None) -> str:
    """'' = ลงนามได้ · อื่น ๆ = เหตุผลที่ยังลงนามไม่ได้"""
    today = today or S.now_dt().date()
    if sl["rec"]:
        return "ลงนามแล้ว"
    if sl["na"]:
        return "ไม่มีผลตรวจในช่วงนี้"
    if sl.get("auto"):
        return "เติมอัตโนมัติเมื่ออนุมัติผลตรวจครบทั้งช่วง"
    groups = user_groups(db, user["id"]) if groups is None else groups
    pos = user.get("position") if "position" in user else user_position(db, user["id"])
    if not (groups & set(sl["groups"]) or (pos and pos in sl["positions"])):
        need = [POSITIONS[p] for p in sl["positions"]] + [GROUPS[g].split(" — ")[-1] for g in sl["groups"]]
        return "สำหรับ " + "/".join(need) if need else "ไม่มีสิทธิ์ลงนามช่องนี้"
    if form and user.get("factory_id") and form.get("factory_id") and user["factory_id"] != form["factory_id"] and not groups:
        return "แบบฟอร์มของโรงงานอื่น"
    if today < sl["opens"]:
        return f"ลงนามได้ตั้งแต่ {sl['opens']:%d/%m/%Y}"
    if sl.get("pending"):
        return f"รออนุมัติผลตรวจอีก {sl['pending']} รายการ"
    if sl["after"]:
        prev = next((x for x in all_slots if x["slot"] == sl["after"]), None)
        if prev and not prev["rec"]:
            return "รอ " + prev["role"] + " ลงนามก่อน"
    return ""


def _user(db, user: dict) -> dict:
    u = dict(user)
    if "position" not in u or "factory_id" not in u:
        r = db.execute("SELECT COALESCE(position,'') p, factory_id FROM users WHERE id=?", (u["id"],)).fetchone()
        u["position"], u["factory_id"] = (r[0], r[1]) if r else ("", None)
    return u


def sign(db, form: dict, month: date, slot: str, user: dict) -> dict:
    user = _user(db, user)
    all_slots = slots(db, form, month)
    sl = next((x for x in all_slots if x["slot"] == slot), None)
    if not sl:
        raise SignError("ไม่พบช่องลงนามนี้ในแบบฟอร์ม")
    why = check(db, sl, user, all_slots, form=form)
    if why:
        raise SignError(why)
    db.execute("INSERT INTO cs_signoffs(form_id, month, slot, user_id, signed_at) VALUES (?,?,?,?,?)",
               (form["id"], month_key(month), slot, user["id"], S.ts()))
    S.audit(db, user["id"], "signoff", "cs_forms", form["id"], after={"month": month_key(month), "slot": slot, "label": sl["label"]})
    _CACHE.clear()
    return sl


def unsign(db, form: dict, month: date, slot: str, user: dict) -> None:
    all_slots = slots(db, form, month)
    sl = next((x for x in all_slots if x["slot"] == slot), None)
    if not sl or not sl["rec"]:
        raise SignError("ช่องนี้ยังไม่ได้ลงนาม")
    if sl["rec"]["user_id"] != user["id"] and user.get("role") != "admin":
        raise SignError("ยกเลิกได้เฉพาะผู้ลงนามเอง หรือผู้ดูแลระบบ")
    nxt = next((x for x in all_slots if x["after"] == slot and x["rec"]), None)
    if nxt:
        raise SignError("ต้องยกเลิกการลงนามของ " + nxt["role"] + " ก่อน")
    db.execute("DELETE FROM cs_signoffs WHERE form_id=? AND month=? AND slot=?", (form["id"], month_key(month), slot))
    S.audit(db, user["id"], "signoff_cancel", "cs_forms", form["id"], before={"month": month_key(month), "slot": slot,
                                                                              "by": sl["rec"]["user_id"]})
    _CACHE.clear()


def active_forms(db, factory_id: int | None = None) -> list[dict]:
    """แบบฟอร์มที่ใช้งานอยู่ + ค่าช่องลงนาม (ของตัวเอง หรือของแม่แบบ) — อ่านครั้งเดียวทั้งชุด"""
    cfgs = {r["id"]: r["sign_config"] for r in db.execute("SELECT id, sign_config FROM cs_forms")}
    from .view_scope import current as _vs_current           # v0.29 บัญชีที่ถูกจำกัดการดู
    vis = _vs_current()
    out = []
    for r in db.execute("""SELECT f.*, e.code AS eq_code, fa.name AS factory_name FROM cs_forms f
                           LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN factories fa ON fa.id=f.factory_id
                           WHERE f.is_template=0 AND f.active=1 AND f.current_version_id IS NOT NULL
                           AND (? IS NULL OR f.factory_id=?) ORDER BY f.code, f.name""", (factory_id, factory_id)):
        form = dict(r)
        if vis is not None and form["id"] not in vis:
            continue
        cfg = SB.parse(cfgs.get(form["id"]))
        if SB.is_empty(cfg) and form.get("template_id"):
            cfg = SB.parse(cfgs.get(form["template_id"]))
        form["cfg"] = cfg
        out.append(form)
    return out


signable_forms = active_forms                                # ชื่อเดิม (v0.24)


def form_slots(db, month: date, factory_id: int | None = None) -> list[tuple[dict, list[dict]]]:
    recs, days, pend = records_all(db, month), sub_days(db, month), pending_all(db, month)
    return [(f, slots(db, f, month, f["cfg"], recs.get(f["id"], {}), days.get(f["id"], set()), pend.get(f["id"], 0)))
            for f in active_forms(db, factory_id)]


_CACHE: dict = {}


def pending_count(db, user: dict, months: list[date]) -> int:
    """จำนวนช่องที่ผู้ใช้ลงนามได้ตอนนี้ (ตามตำแหน่ง/กลุ่มหน่วยงาน) — ตัวเลขที่เมนู · แคช 60 วินาที"""
    if not user:
        return 0
    user = _user(db, user)
    groups = user_groups(db, user["id"])
    if not groups and user["position"] in ("", "tech"):
        return 0
    import time
    dbfile = db.execute("PRAGMA database_list").fetchone()[2]
    key = (dbfile, user["id"], tuple(months))
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    n = 0
    for m in months:
        for form, al in form_slots(db, m, None if groups else user.get("factory_id")):
            n += sum(1 for sl in al if not check(db, sl, user, al, groups=groups, form=form))
    _CACHE[key] = (time.time(), n)
    return n


def is_signer(db, user: dict) -> bool:
    u = _user(db, user)
    return bool(user_groups(db, u["id"])) or u["position"] not in ("", "tech")


def days_text(month: date, days) -> str:
    """[3, 4, 5, 10] → '3–5, 10 ก.ย.' (วันที่ของเอกสารที่ตรวจ)"""
    days = sorted(set(days or []))
    if not days:
        return ""
    TH = ("ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.")
    parts, a, b = [], days[0], days[0]
    for d in days[1:] + [None]:
        if d is not None and d == b + 1:
            b = d
            continue
        parts.append(f"{a}–{b}" if b > a + 1 else (f"{a}, {b}" if b == a + 1 else str(a)))
        if d is not None:
            a = b = d
    return ", ".join(parts) + f" {TH[month.month - 1]}"
