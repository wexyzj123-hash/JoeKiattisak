"""ecs/cmms_status.py — เชื่อม "สถานะช่าง" ของ UT-CMMS กับการตรวจใน E-Checksheet

เปิดหน้ากรอกเช็คชีท (สแกน QR) → สถานะช่างใน UT-CMMS เป็น "🔍 ตรวจเช็ค · <แบบฟอร์ม> (<เครื่อง>)"
  (ตาราง tech_custom_status + เปิดบันทึกเวลา tech_status_log ชนิด inspection — ชนิดเดียวกับที่ UT-CMMS ใช้)
ส่งผลตรวจ → ปิดบันทึกเวลา (เริ่ม → เวลาส่งจริง) และปิดสถานะ (หรือกลับไปสถานะเดิม ตามที่ตั้งค่า)
ออกจากหน้ากรอกโดยไม่ส่ง → หยุดนับ · กลับมากรอกต่อภายใน 15 นาที = นับต่อรายการเดิม
เปิดค้างไว้เกินเวลาที่ตั้ง (ค่าเริ่มต้น 60 นาที) → ปิดให้อัตโนมัติ (นับไม่เกินเวลานั้น)
ส่งแบบออฟไลน์ (ไม่ได้เปิดสถานะไว้) → ลงบันทึกเวลาย้อนหลังจากเวลาเริ่ม-ส่งในผลตรวจ
สถานะเดิมที่ตั้งเองใน UT-CMMS ถูกปิดด้วยกฎเดียวกับ UT-CMMS (นับในกรอบกะ หักเบรก)
"""
from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, time as dtime, timedelta

from . import services as S
from .services import ts

log = logging.getLogger(__name__)

DEFAULTS = {"enabled": False, "after_done": "clear", "stale_minutes": 60}
AFTER_TH = {"clear": "ปิดสถานะ (ว่าง)", "restore": "กลับไปสถานะเดิมก่อนตรวจ"}
RESUME_MIN = 15          # ออกจากหน้ากรอกแล้วกลับมาภายในนี้ = นับต่อ
TYPE = "inspection"

DDL = """
CREATE TABLE IF NOT EXISTS cs_status_sync (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL,
    cmms_user_id  INTEGER NOT NULL,
    form_id       INTEGER,
    client_uuid   TEXT DEFAULT '',
    submission_id INTEGER,
    log_id        INTEGER,               -- tech_status_log.id ใน UT-CMMS
    status_text   TEXT DEFAULT '',
    prev_text     TEXT,                  -- สถานะเดิมก่อนตรวจ (ใช้เมื่อตั้งค่า "กลับไปสถานะเดิม")
    prev_type     TEXT,
    started_at    TEXT NOT NULL,
    stopped_at    TEXT,
    ended_at      TEXT,
    minutes       REAL,
    state         TEXT NOT NULL DEFAULT 'open'   -- open | paused | done | stale | offline
);
CREATE INDEX IF NOT EXISTS idx_statussync_user ON cs_status_sync(user_id, state);
"""


def ensure(db) -> None:
    db.executescript(DDL)


def get_settings(db) -> dict:
    cfg = dict(DEFAULTS)
    row = db.execute("SELECT value FROM cs_meta WHERE key='cmms_status'").fetchone()
    if row and row[0]:
        try:
            cfg.update({k: v for k, v in json.loads(row[0]).items() if k in DEFAULTS})
        except ValueError:
            pass
    return cfg


def save_settings(db, data: dict, actor_id) -> dict:
    cfg = {"enabled": data.get("enabled") in (1, True, "1", "on", "true"),
           "after_done": data.get("after_done") if data.get("after_done") in AFTER_TH else "clear"}
    try:
        cfg["stale_minutes"] = max(10, min(240, int(data.get("stale_minutes") or 60)))
    except (TypeError, ValueError):
        cfg["stale_minutes"] = 60
    db.execute("INSERT INTO cs_meta(key, value) VALUES('cmms_status', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(cfg),))
    S.audit(db, actor_id, "update", "cs_meta", None, after={"cmms_status": cfg})
    return cfg


def _connect(app_config):
    from .cmms_tpm import _connect as c
    return c(app_config)


def available(app_config) -> bool:
    from .cmms_tpm import available as a
    return a(app_config)


def _has_tables(con) -> bool:
    return len(con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name IN "
                           "('tech_status_log','tech_custom_status')").fetchall()) == 2


def _fmt(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _parse(s) -> datetime | None:
    try:
        return datetime.strptime(str(s)[:19], "%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError):
        return None


# ───────── กฎนับเวลาแบบเดียวกับ UT-CMMS (routes/dashboard.py _shift_window_for / _close_open_log) ─────────

def _shift_window(status_type: str, now: datetime):
    today = now.date()
    c = datetime.combine
    if status_type == "night_shift":
        if now.hour < 12:
            start, end = c(today - timedelta(days=1), dtime(20, 0)), c(today, dtime(5, 0))
        else:
            start, end = c(today, dtime(20, 0)), c(today + timedelta(days=1), dtime(5, 0))
        return start, end, c(end.date(), dtime(0, 0)), c(end.date(), dtime(1, 0)), 480
    if status_type == "ot":
        if now.hour < 12:
            start, end = c(today, dtime(5, 20)), c(today, dtime(8, 0))
        else:
            start, end = c(today, dtime(17, 20)), c(today, dtime(20, 0))
        return start, end, start, start, 160
    return c(today, dtime(8, 0)), c(today, dtime(17, 0)), c(today, dtime(12, 0)), c(today, dtime(13, 0)), 480


def _close_foreign_log(con, cmms_uid: int, now: datetime) -> None:
    """ปิดบันทึกเวลาของสถานะที่ตั้งไว้เองใน UT-CMMS (กฎเดียวกับ UT-CMMS)"""
    row = con.execute("SELECT id, start_at, status_type FROM tech_status_log WHERE user_id=? AND end_at IS NULL "
                      "ORDER BY id DESC LIMIT 1", (cmms_uid,)).fetchone()
    if not row:
        return
    start = _parse(row["start_at"]) or now
    s0, s1, b0, b1, cap = _shift_window(row["status_type"] or "", now)
    cs, ce = max(start, s0), min(now, s1)
    raw = max(0.0, (ce - cs).total_seconds() / 60)
    overlap = max(0.0, (min(ce, b1) - max(cs, b0)).total_seconds() / 60)
    net = round(max(0.0, min(cap, raw - overlap)), 1)
    con.execute("UPDATE tech_status_log SET end_at=?, duration_minutes=? WHERE id=?", (_fmt(now), net, row["id"]))


def _end_own_log(con, log_id, start: datetime, end: datetime, cap_min: float) -> float:
    """ปิดบันทึกเวลาของการตรวจ — นับเวลาจริง (เริ่ม → ส่ง) ไม่เกิน cap"""
    end = max(end, start)
    minutes = round(min(cap_min, (end - start).total_seconds() / 60), 1)
    con.execute("UPDATE tech_status_log SET end_at=?, duration_minutes=? WHERE id=? AND end_at IS NULL",
                (_fmt(end), minutes, log_id))
    return minutes


def _set_custom(con, cmms_uid: int, text: str, stype: str, now: datetime) -> None:
    con.execute("""INSERT INTO tech_custom_status (user_id, status_text, status_type, set_by, set_at) VALUES (?,?,?,?,?)
                   ON CONFLICT(user_id) DO UPDATE SET status_text=excluded.status_text, status_type=excluded.status_type,
                   set_by=excluded.set_by, set_at=excluded.set_at""", (cmms_uid, text, stype, cmms_uid, _fmt(now)))


def _clear_if_ours(con, cmms_uid: int, text: str) -> bool:
    cur = con.execute("DELETE FROM tech_custom_status WHERE user_id=? AND status_type=? AND status_text=?",
                      (cmms_uid, TYPE, text))
    return cur.rowcount > 0


def _after(con, cfg, sess: dict, now: datetime) -> None:
    """หลังตรวจเสร็จ/หยุด: ปิดสถานะของเรา แล้ว (ถ้าตั้งไว้) กลับไปสถานะเดิม"""
    if _clear_if_ours(con, sess["cmms_user_id"], sess["status_text"]) and cfg["after_done"] == "restore" \
            and sess.get("prev_text"):
        _set_custom(con, sess["cmms_user_id"], sess["prev_text"], sess["prev_type"] or "custom", now)
        con.execute("INSERT INTO tech_status_log (user_id, status_type, status_text, start_at, set_by) VALUES (?,?,?,?,?)",
                    (sess["cmms_user_id"], sess["prev_type"] or "custom", sess["prev_text"], _fmt(now), sess["cmms_user_id"]))


def _cmms_uid(db, con, user_id) -> int | None:
    u = db.execute("SELECT legacy_id FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None
    if not u or not u["legacy_id"]:
        return None
    r = con.execute("SELECT id FROM users WHERE id=?", (u["legacy_id"],)).fetchone()
    return int(r["id"]) if r else None


def _status_text(db, form_id: int) -> str:
    f = db.execute("""SELECT f.name, e.code FROM cs_forms f LEFT JOIN equipment e ON e.id=f.equipment_id
                      WHERE f.id=?""", (form_id,)).fetchone()
    if not f:
        return "เช็คชีท"
    name = f["name"]
    if f["code"] and f["code"] not in name:
        name += f" ({f['code']})"
    return name[:200]          # การ์ดสถานะช่างของ UT-CMMS แสดง "🔍 ตรวจเช็ค" นำหน้าให้เอง


# ───────────────────────── เริ่ม / หยุด / เสร็จ ─────────────────────────

def start(db, app_config, user_id: int, form_id: int, client_uuid: str = "", now: datetime | None = None) -> dict:
    """เปิดหน้ากรอก → ตั้งสถานะ "ตรวจเช็ค" ใน UT-CMMS · คืน {"status": text} หรือ {} ถ้าไม่ได้ทำ"""
    ensure(db)
    cfg = get_settings(db)
    if not cfg["enabled"] or not available(app_config):
        return {}
    now = now or S.now_dt()
    con = _connect(app_config)
    try:
        if not _has_tables(con):
            return {}
        cuid = _cmms_uid(db, con, user_id)
        if not cuid:
            return {}
        text = _status_text(db, form_id)
        live = [dict(r) for r in db.execute(
            "SELECT * FROM cs_status_sync WHERE user_id=? AND state IN ('open','paused') ORDER BY id DESC", (user_id,))]
        same = next((s for s in live if s["form_id"] == form_id and (s["state"] == "open" or (
            s["stopped_at"] and now - _parse(s["stopped_at"]) <= timedelta(minutes=RESUME_MIN)))), None)
        cur = con.execute("SELECT status_text, status_type FROM tech_custom_status WHERE user_id=?", (cuid,)).fetchone()
        if same:
            lg = con.execute("SELECT id, end_at FROM tech_status_log WHERE id=?", (same["log_id"],)).fetchone()
            if lg:
                if same["state"] == "paused":                     # กลับมากรอกต่อ → นับต่อรายการเดิม
                    if cur and cur["status_type"] != TYPE:
                        _close_foreign_log(con, cuid, now)       # สถานะเดิมที่คืนให้ตอนออกจากหน้ากรอก
                    con.execute("UPDATE tech_status_log SET end_at=NULL, duration_minutes=NULL WHERE id=?", (lg["id"],))
                    db.execute("UPDATE cs_status_sync SET state='open', stopped_at=NULL WHERE id=?", (same["id"],))
                _set_custom(con, cuid, same["status_text"], TYPE, now)
                con.commit()
                db.commit()
                return {"status": same["status_text"]}
        # ปิดรอบก่อนหน้าของเรา (เช่น เดินตรวจต่อเครื่องถัดไป) — สถานะเดิมก่อนตรวจส่งต่อให้รอบใหม่
        prev_text = prev_type = None
        for s in live:
            if s["state"] == "open":
                _end_own_log(con, s["log_id"], _parse(s["started_at"]), now, cfg["stale_minutes"])
            db.execute("UPDATE cs_status_sync SET state='stale', ended_at=? WHERE id=?", (ts(now), s["id"]))
            prev_text, prev_type = prev_text or s["prev_text"], prev_type or s["prev_type"]
        ours = {x["status_text"] for x in live}
        if cur and not (cur["status_type"] == TYPE and cur["status_text"] in ours):
            prev_text, prev_type = cur["status_text"], cur["status_type"]
        _close_foreign_log(con, cuid, now)          # บันทึกเวลาที่ยังเปิดอยู่ (สถานะที่ตั้งเองใน UT-CMMS)
        _set_custom(con, cuid, text, TYPE, now)
        log_id = con.execute("INSERT INTO tech_status_log (user_id, status_type, status_text, start_at, set_by) "
                             "VALUES (?,?,?,?,?)", (cuid, TYPE, text, _fmt(now), cuid)).lastrowid
        con.commit()
        db.execute("""INSERT INTO cs_status_sync(user_id, cmms_user_id, form_id, client_uuid, log_id, status_text,
                      prev_text, prev_type, started_at, state) VALUES (?,?,?,?,?,?,?,?,?, 'open')""",
                   (user_id, cuid, form_id, client_uuid or "", log_id, text, prev_text, prev_type, ts(now)))
        db.commit()
        return {"status": text}
    finally:
        con.close()


def stop(db, app_config, user_id: int, form_id: int | None = None, now: datetime | None = None) -> int:
    """ออกจากหน้ากรอกโดยไม่ส่ง → หยุดนับเวลา (กลับมาภายใน 15 นาที = นับต่อ)"""
    ensure(db)
    rows = [dict(r) for r in db.execute("SELECT * FROM cs_status_sync WHERE user_id=? AND state='open'" +
                                        (" AND form_id=?" if form_id else ""),
                                        (user_id, form_id) if form_id else (user_id,))]
    if not rows or not available(app_config):
        return 0
    cfg, now = get_settings(db), now or S.now_dt()
    con = _connect(app_config)
    try:
        for s in rows:
            _end_own_log(con, s["log_id"], _parse(s["started_at"]), now, cfg["stale_minutes"])
            _after(con, cfg, s, now)
            db.execute("UPDATE cs_status_sync SET state='paused', stopped_at=? WHERE id=?", (ts(now), s["id"]))
        con.commit()
        db.commit()
    finally:
        con.close()
    return len(rows)


def finish(db, app_config, sub_id: int, now: datetime | None = None) -> dict:
    """ส่งผลตรวจแล้ว → ปิดเวลา (เริ่ม → เวลาส่งจริง) และปิดสถานะ — คืน {"minutes": n} หรือ {}"""
    ensure(db)
    cfg = get_settings(db)
    if not cfg["enabled"] or not available(app_config):
        return {}
    s = db.execute("SELECT id, form_id, inspector_id, client_uuid, scanned_at, finished_at FROM cs_submissions WHERE id=?",
                   (sub_id,)).fetchone()
    if not s or db.execute("SELECT 1 FROM cs_status_sync WHERE submission_id=?", (sub_id,)).fetchone():
        return {}
    now = now or S.now_dt()
    end = min(S.parse_ts(s["finished_at"]) or now, now)
    sess = db.execute("""SELECT * FROM cs_status_sync WHERE user_id=? AND form_id=? AND state IN ('open','paused')
                         ORDER BY id DESC LIMIT 1""", (s["inspector_id"], s["form_id"])).fetchone()
    con = _connect(app_config)
    try:
        if not _has_tables(con):
            return {}
        if sess:
            sess = dict(sess)
            start_dt = _parse(sess["started_at"])
            if sess["state"] == "paused":
                lg = con.execute("SELECT duration_minutes FROM tech_status_log WHERE id=?", (sess["log_id"],)).fetchone()
                minutes = lg["duration_minutes"] if lg else 0
                if lg:     # ส่งหลังออกจากหน้ากรอก (ส่งจากคิว) → ใช้เวลาเริ่ม→ส่งจริง
                    con.execute("UPDATE tech_status_log SET end_at=NULL WHERE id=?", (sess["log_id"],))
                    minutes = _end_own_log(con, sess["log_id"], start_dt, end, cfg["stale_minutes"])
            else:
                minutes = _end_own_log(con, sess["log_id"], start_dt, end, cfg["stale_minutes"])
                _after(con, cfg, sess, now)
            db.execute("""UPDATE cs_status_sync SET state='done', submission_id=?, ended_at=?, minutes=? WHERE id=?""",
                       (sub_id, ts(end), minutes, sess["id"]))
        elif stale := db.execute("""SELECT * FROM cs_status_sync WHERE user_id=? AND form_id=? AND state='stale'
                                    AND submission_id IS NULL AND started_at >= ? ORDER BY id DESC LIMIT 1""",
                                 (s["inspector_id"], s["form_id"],
                                  ts((S.parse_ts(s["scanned_at"]) or end) - timedelta(minutes=5)))).fetchone():
            # ถูกปิดอัตโนมัติไปแล้ว (กรอกนาน) → ขยายเวลาให้ถึงเวลาส่งจริง (ไม่เกิน 4 ชม.)
            start_dt = _parse(stale["started_at"])
            con.execute("UPDATE tech_status_log SET end_at=NULL, status_text=? WHERE id=?", (stale["status_text"], stale["log_id"]))
            minutes = _end_own_log(con, stale["log_id"], start_dt, end, 240)
            db.execute("UPDATE cs_status_sync SET state='done', submission_id=?, ended_at=?, minutes=? WHERE id=?",
                       (sub_id, ts(end), minutes, stale["id"]))
        else:
            # ไม่ได้เปิดสถานะไว้ (กรอกตอนออฟไลน์) → ลงเวลาย้อนหลังจากเวลาเริ่ม-ส่งในผลตรวจ
            cuid = _cmms_uid(db, con, s["inspector_id"])
            start_dt = S.parse_ts(s["scanned_at"])
            if not cuid or not start_dt or end <= start_dt:
                return {}
            text = _status_text(db, s["form_id"])
            minutes = round(min(cfg["stale_minutes"], (end - start_dt).total_seconds() / 60), 1)
            log_id = con.execute("""INSERT INTO tech_status_log (user_id, status_type, status_text, start_at, end_at,
                                    duration_minutes, set_by) VALUES (?,?,?,?,?,?,?)""",
                                 (cuid, TYPE, text + " · ออฟไลน์", _fmt(start_dt), _fmt(end), minutes, cuid)).lastrowid
            db.execute("""INSERT INTO cs_status_sync(user_id, cmms_user_id, form_id, client_uuid, submission_id, log_id,
                          status_text, started_at, ended_at, minutes, state) VALUES (?,?,?,?,?,?,?,?,?,?, 'offline')""",
                       (s["inspector_id"], cuid, s["form_id"], s["client_uuid"], sub_id, log_id, text, ts(start_dt),
                        ts(end), minutes))
        con.commit()
        db.commit()
        return {"minutes": minutes}
    finally:
        con.close()


def after_submit(db, app_config, sub_id: int) -> dict:
    """เรียกหลังบันทึกผลตรวจ — ล้มเหลวต้องไม่กระทบการส่งผลตรวจ"""
    try:
        return finish(db, app_config, sub_id)
    except Exception:                                   # noqa: BLE001
        db.rollback()
        log.exception("tech status finish failed for submission %s", sub_id)
        return {}


def expire(db, app_config, now: datetime | None = None) -> int:
    """jobs: เปิดหน้ากรอกค้างไว้เกินเวลา → ปิดสถานะ (นับไม่เกินเวลาที่ตั้ง) · paused เกิน 15 นาที → จบรายการ"""
    ensure(db)
    rows = [dict(r) for r in db.execute("SELECT * FROM cs_status_sync WHERE state IN ('open','paused')")]
    if not rows or not available(app_config):
        return 0
    cfg, now = get_settings(db), now or S.now_dt()
    limit = timedelta(minutes=cfg["stale_minutes"])
    n = 0
    con = _connect(app_config)
    try:
        for s in rows:
            start_dt = _parse(s["started_at"])
            if s["state"] == "open" and now - start_dt >= limit:
                _end_own_log(con, s["log_id"], start_dt, start_dt + limit, cfg["stale_minutes"])
                con.execute("UPDATE tech_status_log SET status_text=? WHERE id=?",
                            ((s["status_text"] + " · ไม่ได้ส่งผล (ปิดอัตโนมัติ)")[:250], s["log_id"]))
                _after(con, cfg, s, now)
                db.execute("UPDATE cs_status_sync SET state='stale', ended_at=? WHERE id=?", (ts(start_dt + limit), s["id"]))
                n += 1
            elif s["state"] == "paused" and s["stopped_at"] and now - _parse(s["stopped_at"]) > timedelta(minutes=RESUME_MIN):
                db.execute("UPDATE cs_status_sync SET state='stale', ended_at=stopped_at WHERE id=?", (s["id"],))
                n += 1
        con.commit()
        db.commit()
    finally:
        con.close()
    return n


def safe(fn, db, *args, **kw):
    try:
        return fn(db, *args, **kw)
    except Exception:                                   # noqa: BLE001
        db.rollback()
        log.exception("tech status %s failed", fn.__name__)
        return {} if fn is start else 0


def recent(db, limit: int = 30) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.execute(
        """SELECT y.*, u.name AS user_name FROM cs_status_sync y LEFT JOIN users u ON u.id=y.user_id
           ORDER BY y.id DESC LIMIT ?""", (limit,))]


STATE_TH = {"open": ("กำลังตรวจ", "b-primary"), "paused": ("ออกจากหน้ากรอก", "b-warn"), "done": ("ส่งผลแล้ว", "b-ok"),
            "stale": ("ปิดอัตโนมัติ", "b-none"), "offline": ("ส่งออฟไลน์ (ลงเวลาย้อนหลัง)", "b-info")}


def unlinked_inspectors(db) -> list[dict]:
    """ผู้ตรวจที่ยังไม่ผูกบัญชี UT-CMMS (สถานะช่างจะไม่ขึ้น)"""
    return [dict(r) for r in db.execute(
        "SELECT id, username, name FROM users WHERE active=1 AND role IN ('technician','supervisor') "
        "AND legacy_id IS NULL ORDER BY name")]
