"""ecs/perms.py — v0.52 สิทธิ์การใช้งาน: ตารางสิทธิ์ตามบทบาท · สิทธิ์แก้ไขแบบฟอร์มที่ผู้ดูแลระบบอนุญาต · ดูหน้าจอแทนผู้ใช้

สิทธิ์แก้ไขแบบฟอร์ม (cs_form_editors) — ผู้ดูแลระบบให้เจ้าหน้าที่ (เช่น สิ่งแวดล้อม / เซฟตี้) แก้ไขได้:
  ขอบเขต: แบบฟอร์มที่เลือก หรือ "ทุกแบบฟอร์มของหน่วยงาน" (ENVIRONMENT / SAFETY ตามช่องลงนามของแบบฟอร์ม)
  ระดับ: แก้หัวข้อ (ฉบับร่าง) · เผยแพร่เองได้ (Publish) · ตั้งรอบตรวจได้
  แก้แล้วแต่เผยแพร่เองไม่ได้ → แจ้งผู้ดูแลระบบ/หัวหน้างานให้ตรวจและ Publish
ผู้ดูแลระบบ / หัวหน้างาน (ที่ไม่ถูกจำกัดการดู) แก้ได้ทุกแบบฟอร์มเหมือนเดิม
"""
from __future__ import annotations

from functools import wraps

from flask import abort, flash, jsonify, redirect, render_template, request, session, url_for

from . import services as S
from .services import ts

DDL = """
CREATE TABLE IF NOT EXISTS cs_form_editors (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    form_id     INTEGER REFERENCES cs_forms(id),     -- ว่าง = ทั้งหน่วยงาน (dept)
    dept        TEXT NOT NULL DEFAULT '',            -- env | safety (เมื่อ form_id ว่าง)
    can_publish INTEGER NOT NULL DEFAULT 0,
    can_schedule INTEGER NOT NULL DEFAULT 0,
    granted_by  INTEGER REFERENCES users(id),
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_csfe_user ON cs_form_editors(user_id);
"""
DEPT_TH = {"env": "ENVIRONMENT (สิ่งแวดล้อม)", "safety": "SAFETY (เซฟตี้)"}
MANAGE = ("admin", "supervisor")
NONE = {"edit": False, "publish": False, "schedule": False, "via": ""}
FULL = {"edit": True, "publish": True, "schedule": True, "via": "role"}


def ensure(db) -> None:
    db.executescript(DDL)


def _user(db, uid):
    return db.execute("SELECT id, role, COALESCE(restrict_view,0) AS rv, active FROM users WHERE id=?", (uid,)).fetchone() if uid else None


def form_access(db, uid, form_id) -> dict:
    """สิทธิ์ของผู้ใช้ต่อแบบฟอร์มนี้ → {edit, publish, schedule, via}"""
    u = _user(db, uid)
    if not u or not u["active"]:
        return dict(NONE)
    if u["role"] == "admin" or (u["role"] in MANAGE and not u["rv"]):
        return dict(FULL)
    ensure(db)
    grants = db.execute("SELECT * FROM cs_form_editors WHERE user_id=?", (uid,)).fetchall()
    if not grants or not form_id:
        return dict(NONE)
    dept = None
    out = dict(NONE)
    for g in grants:
        hit = g["form_id"] == form_id
        if not hit and not g["form_id"] and g["dept"]:
            if dept is None:
                from .view_scope import forms_by_dept
                dept = forms_by_dept(db).get(form_id, "")
            hit = dept == g["dept"]
        if hit:
            out["edit"] = True
            out["publish"] = out["publish"] or bool(g["can_publish"])
            out["schedule"] = out["schedule"] or bool(g["can_schedule"])
            out["via"] = "grant"
    return out


def editable_form_ids(db, uid) -> set[int] | None:
    """None = แก้ได้ทุกแบบฟอร์ม · set = แบบฟอร์มที่ได้รับอนุญาต"""
    u = _user(db, uid)
    if not u:
        return set()
    if u["role"] == "admin" or (u["role"] in MANAGE and not u["rv"]):
        return None
    ensure(db)
    out: set[int] = set()
    depts = set()
    for g in db.execute("SELECT form_id, dept FROM cs_form_editors WHERE user_id=?", (uid,)):
        if g["form_id"]:
            out.add(g["form_id"])
        elif g["dept"]:
            depts.add(g["dept"])
    if depts:
        from .view_scope import forms_by_dept
        out |= {fid for fid, d in forms_by_dept(db).items() if d in depts}
    return out


def list_grants(db) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.execute("""
        SELECT g.*, u.name AS user_name, u.role AS user_role, f.name AS form_name, f.code AS form_code, gb.name AS granted_by_name
        FROM cs_form_editors g JOIN users u ON u.id=g.user_id LEFT JOIN cs_forms f ON f.id=g.form_id
        LEFT JOIN users gb ON gb.id=g.granted_by ORDER BY u.name, g.dept, f.name""")]


def add_grant(db, data: dict, actor_id) -> int:
    ensure(db)
    try:
        uid = int(data.get("user_id") or 0)
    except ValueError:
        uid = 0
    u = _user(db, uid)
    if not u or not u["active"]:
        raise S.ValidationError("กรุณาเลือกผู้ใช้")
    if u["role"] == "admin":
        raise S.ValidationError("ผู้ดูแลระบบแก้ไขได้ทุกแบบฟอร์มอยู่แล้ว")
    scope = str(data.get("scope") or "")
    form_id, dept = None, ""
    if scope in DEPT_TH:
        dept = scope
    else:
        try:
            form_id = int(data.get("form_id") or 0)
        except ValueError:
            form_id = 0
        if not form_id or not db.execute("SELECT 1 FROM cs_forms WHERE id=?", (form_id,)).fetchone():
            raise S.ValidationError("กรุณาเลือกแบบฟอร์ม หรือเลือกทั้งหน่วยงาน")
    flag = lambda k: 1 if data.get(k) in (1, True, "1", "on", "true") else 0
    dup = db.execute("SELECT id FROM cs_form_editors WHERE user_id=? AND COALESCE(form_id,0)=? AND dept=?",
                     (uid, form_id or 0, dept)).fetchone()
    if dup:
        db.execute("UPDATE cs_form_editors SET can_publish=?, can_schedule=?, granted_by=? WHERE id=?",
                   (flag("can_publish"), flag("can_schedule"), actor_id, dup[0]))
        gid = dup[0]
    else:
        gid = db.execute("""INSERT INTO cs_form_editors(user_id, form_id, dept, can_publish, can_schedule, granted_by, created_at)
                            VALUES (?,?,?,?,?,?,?)""", (uid, form_id, dept, flag("can_publish"), flag("can_schedule"),
                                                        actor_id, ts(S.now_dt()))).lastrowid
    S.audit(db, actor_id, "grant", "cs_form_editors", gid,
            after={"user_id": uid, "form_id": form_id, "dept": dept, "publish": flag("can_publish"), "schedule": flag("can_schedule")})
    return gid


def remove_grant(db, gid: int, actor_id) -> None:
    ensure(db)
    row = db.execute("SELECT * FROM cs_form_editors WHERE id=?", (gid,)).fetchone()
    if row:
        db.execute("DELETE FROM cs_form_editors WHERE id=?", (gid,))
        S.audit(db, actor_id, "revoke", "cs_form_editors", gid, before=dict(row))


def notify_draft(db, form_id: int, actor_id) -> None:
    """ผู้ได้รับสิทธิ์แก้ (แต่เผยแพร่เองไม่ได้) บันทึกฉบับร่าง → แจ้งผู้ดูแลระบบ/หัวหน้างานให้ตรวจและ Publish (วันละครั้งต่อแบบฟอร์ม)"""
    from .notify import notify_user_app
    f = S.get_form(db, form_id)
    who = db.execute("SELECT name FROM users WHERE id=?", (actor_id,)).fetchone()
    day = S.now_dt().strftime("%Y%m%d")
    for u in db.execute("SELECT id FROM users WHERE active=1 AND role IN ('admin','supervisor') AND COALESCE(restrict_view,0)=0"):
        notify_user_app(db, u[0], "form_draft", f"✏️ ฉบับร่างรอเผยแพร่: {f['name'] if f else form_id}",
                        f"แก้ไขโดย {who[0] if who else '-'} — ตรวจแล้วกด Publish", url=f"/forms/{form_id}/builder",
                        ref_key=f"form_draft:{form_id}:{day}")


def require_form(level: str = "edit", by_schedule: bool = False):
    """แทน require_role(MANAGE) ในหน้าที่แก้แบบฟอร์ม: ผ่านเมื่อมีสิทธิ์ระดับนี้กับแบบฟอร์มนั้น"""
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            from .db import get_db
            from .security import wants_json
            if "user_id" not in session:
                if wants_json():
                    return jsonify({"error": "กรุณาเข้าสู่ระบบใหม่", "code": "login_required"}), 401
                return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
            db = get_db()
            fid = kwargs.get("form_id")
            if by_schedule:
                r = db.execute("SELECT form_id FROM cs_schedules WHERE id=?", (kwargs.get("schedule_id"),)).fetchone()
                if not r:
                    abort(404)
                fid = r[0]
            if not form_access(db, session["user_id"], fid).get(level):
                msg = {"publish": "คุณแก้ไขได้ แต่การเผยแพร่ (Publish) ต้องให้ผู้ดูแลระบบ/หัวหน้างาน",
                       "schedule": "ไม่มีสิทธิ์ตั้งรอบตรวจของแบบฟอร์มนี้"}.get(level, "ไม่มีสิทธิ์แก้ไขแบบฟอร์มนี้ — ติดต่อผู้ดูแลระบบ")
                if wants_json():
                    return jsonify({"error": msg}), 403
                return render_template("error.html", code=403, message=msg), 403
            return fn(*args, **kwargs)
        return wrapper
    return deco


# ───────────────────────── ตารางสิทธิ์ตามบทบาท ─────────────────────────
# (ความสามารถ, admin, supervisor, technician, viewer, หมายเหตุ)
MATRIX = [
    ("กรอกเช็คชีท / สแกน QR (มือถือ)", "✓", "✓", "✓", "–", ""),
    ("แจ้งเครื่องหยุด / แจ้งปัญหา / ขอแก้แบบฟอร์ม", "✓", "✓", "✓", "–", ""),
    ("ดูผลตรวจ / รายงาน / ใบบันทึก", "✓", "✓", "✓", "✓", "บัญชีที่ \"จำกัดการดู\" เห็นเฉพาะแบบฟอร์มหน่วยงานของตน"),
    ("อนุมัติ / ตีกลับผลตรวจ", "✓", "✓", "สิทธิ์อนุมัติ", "สิทธิ์อนุมัติ", "ติ๊ก \"สิทธิ์อนุมัติแบบกลุ่ม\" ในหน้าผู้ใช้ หรือตำแหน่งผู้ลงนาม"),
    ("รับทราบ / แก้ไข NG (แจ้งเตือน)", "✓", "✓", "เมื่อถูกมอบหมาย", "–", "ปิดงานได้เฉพาะหัวหน้างาน/ผู้ดูแล"),
    ("ต้องจัดการวันนี้ · ตารางกะ · มอบหมายโรงงาน", "✓", "✓", "–", "–", ""),
    ("สร้าง / แก้ไข / Publish แบบฟอร์ม · ตั้งรอบตรวจ", "✓", "✓", "ได้รับอนุญาต", "ได้รับอนุญาต", "ผู้ดูแลอนุญาตรายแบบฟอร์มหรือทั้งหน่วยงาน (ด้านล่าง)"),
    ("เครื่องจักร / ป้าย QR / เส้นทางเดินตรวจ", "✓", "✓", "–", "–", ""),
    ("ลบผลตรวจ", "✓", "สิทธิ์ลบ", "สิทธิ์ลบ", "–", "ติ๊ก \"ลบผลตรวจได้\" ในหน้าผู้ใช้"),
    ("ผู้ใช้ · ช่องทางแจ้งเตือน · SCADA · เชื่อม UT-CMMS · แบ็กอัป", "✓", "–", "–", "–", ""),
    ("ดูหน้าจอแทนผู้ใช้ (ตรวจปัญหา)", "✓", "–", "–", "–", "ดูได้อย่างเดียว แก้ไข/ส่งข้อมูลไม่ได้ · บันทึก Audit"),
]


def user_overview(db) -> list[dict]:
    from .view_scope import user_depts
    from . import roster as RO
    grants: dict[int, list] = {}
    for g in list_grants(db):
        grants.setdefault(g["user_id"], []).append(g)
    fac = RO.factory_names(db)
    out = []
    for u in db.execute("""SELECT id, username, name, role, factory_id, legacy_id, COALESCE(restrict_view,0) AS rv,
                                  COALESCE(can_approve,0) AS ca, COALESCE(can_delete_results,0) AS cd, COALESCE(position,'') AS pos
                           FROM users WHERE active=1 ORDER BY CASE role WHEN 'admin' THEN 0 WHEN 'supervisor' THEN 1
                           WHEN 'technician' THEN 2 ELSE 3 END, name"""):
        d = dict(u)
        fids = RO.factories_of(db, d["id"])
        d["fac_text"] = ", ".join(fac.get(f, "?") for f in fids) if fids else "ทุกโรงงาน"
        d["depts"] = sorted(user_depts(db, d["id"])) if d["rv"] else []
        d["grants"] = grants.get(d["id"], [])
        out.append(d)
    return out


# ───────────────────────── ดูหน้าจอแทนผู้ใช้ (อ่านอย่างเดียว) ─────────────────────────
VIEW_AS_OK = {"team.view_as_stop", "auth.logout", "static", "mobile.service_worker", "mobile.manifest"}


def start_view_as(db, target_id: int) -> None:
    if session.get("role") != "admin" or session.get("view_as"):
        raise S.ValidationError("เฉพาะผู้ดูแลระบบ")
    t = db.execute("SELECT id, name, role, factory_id, active FROM users WHERE id=?", (target_id,)).fetchone()
    if not t or not t["active"]:
        raise S.ValidationError("ไม่พบผู้ใช้")
    if t["role"] == "admin":
        raise S.ValidationError("ดูแทนผู้ดูแลระบบด้วยกันไม่ได้")
    orig = {k: session.get(k) for k in ("user_id", "role", "name", "factory_id")}
    S.audit(db, orig["user_id"], "view_as", "users", t["id"], after={"target": t["name"]})
    session["view_as"] = {"orig": orig, "target_name": t["name"]}
    session.update(user_id=t["id"], role=t["role"], name=t["name"], factory_id=t["factory_id"])
    session.pop("_view_scope", None)


def stop_view_as(db) -> bool:
    va = session.pop("view_as", None)
    if not va:
        return False
    session.update(**va["orig"])
    S.audit(db, va["orig"]["user_id"], "view_as_stop", "users", None, after={"target": va.get("target_name")})
    return True


def guard_view_as():
    """เรียกใน before_request: ระหว่างดูแทนผู้ใช้ ห้ามบันทึก/ส่ง/แก้ไขใด ๆ"""
    if not session.get("view_as") or request.method in ("GET", "HEAD", "OPTIONS"):
        return None
    if request.endpoint in VIEW_AS_OK:
        return None
    msg = "กำลังดูหน้าจอแทนผู้ใช้ (อ่านอย่างเดียว) — กด “กลับเป็นผู้ดูแลระบบ” ก่อนแก้ไขข้อมูล"
    if request.path.startswith("/api/") or request.is_json:
        return jsonify({"error": msg, "code": "view_as"}), 403
    flash(msg, "error")
    return redirect(request.referrer or url_for("index"))
