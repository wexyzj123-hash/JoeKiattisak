"""ecs/binding.py — v0.47 ศูนย์ผูกข้อมูล SCADA / SQL: ขั้นตอน 1→5 ในหน้าเดียว พร้อมสถานะของแต่ละขั้น

1 เชื่อมต่อแหล่งข้อมูล   2 ตรวจเวลา (UTC / นาฬิกาไม่ตรง)   3 Tag ที่พบ / ค่าค้าง
4 จับคู่หัวข้อในแบบฟอร์ม   5 วิธีลงค่า + ตรวจผลการลงค่าเมื่อวาน (ช่องที่ขาด พร้อมสาเหตุ)
สถานะ: ok (เรียบร้อย) · warn (ควรตรวจ) · todo (ยังไม่ได้ทำ)
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

from . import connectors as CN
from . import services as S
from .services import parse_ts, ts

STALE_MIN = 180
MAX_FORMS_CHECK = 60


def _worst(states: list[str]) -> str:
    return "todo" if "todo" in states else ("warn" if "warn" in states else "ok")


def time_check(db, src: dict) -> dict:
    """เทียบเวลาค่าล่าสุดของ Tag กับเวลาที่ดึงข้อมูล → เดาว่าเวลาเพี้ยน (เช่น UTC) และเสนอค่าเลื่อนเวลา"""
    newest = db.execute("SELECT MAX(last_seen) FROM cs_source_tags WHERE source_id=?", (src["id"],)).fetchone()[0]
    run = parse_ts(src.get("last_run_at")) if src.get("last_run_at") else None
    nt = parse_ts(newest) if newest else None
    if not nt or not run:
        return {"state": "todo", "lag_min": None, "suggest": None, "msg": "ยังไม่มีข้อมูลให้ตรวจเวลา — กดดึงข้อมูลก่อน"}
    lag = round((run - nt).total_seconds() / 60)
    shift = int(src.get("ts_shift_min") or 0)
    if -15 <= lag <= 60:
        return {"state": "ok", "lag_min": lag, "suggest": None,
                "msg": f"เวลาตรง (ค่าล่าสุดห่างจากเวลาดึง {lag} นาที){' · เลื่อนเวลา ' + format(shift, '+d') + ' นาที' if shift else ''}"}
    h = abs(lag) / 60
    last = db.execute("SELECT rows_read, status FROM cs_source_runs WHERE source_id=? ORDER BY id DESC LIMIT 1", (src["id"],)).fetchone()
    if lag > 0 and last and last["status"] == "ok" and not last["rows_read"]:
        return {"state": "warn", "lag_min": lag, "suggest": None,
                "msg": f"รอบล่าสุดไม่มีค่าใหม่ (ค่าล่าสุดเมื่อ {h:.1f} ชม. ก่อน) — SCADA อาจหยุดส่งค่า / Query ไม่ได้ดึงช่วงล่าสุด"}
    hours = round(lag / 60)
    sug = None
    if hours and abs(lag - hours * 60) <= 20:          # ห่างเป็นจำนวนชั่วโมงพอดี → โซนเวลาไม่ตรง
        sug = shift + hours * 60
        why = "น่าจะเป็นเวลา UTC" if hours in (7, -7) else "โซนเวลา/นาฬิกาของข้อมูลต่างจากเวลาไทย"
    elif lag < 0:
        why = "เวลาของข้อมูลอยู่ในอนาคต — นาฬิกาเครื่อง SCADA อาจเดินเร็ว"
    else:
        why = "SCADA ส่งค่าช้า หรือเวลาของข้อมูลเพี้ยน"
    return {"state": "warn", "lag_min": lag, "suggest": sug if sug is not None and -1440 <= sug <= 1440 else None,
            "msg": f"ค่าล่าสุด{'ช้ากว่า' if lag > 0 else 'เร็วกว่า'}เวลาดึงข้อมูล {h:.1f} ชม. — {why}"}


def fill_check(db, day: date) -> dict:
    """ผลการลงค่าของวันที่เลือก: ช่องเวลาที่ควรลง · ลงแล้ว · ขาด (พร้อมสาเหตุ)"""
    from . import srcmap as SM
    total = filled = 0
    missing: list[dict] = []
    forms = 0
    for src in CN.list_sources(db):
        if not src["active"]:
            continue
        for cfg in SM.form_cfgs(db, src["id"]):
            if cfg["effective"] == "bucket" or forms >= MAX_FORMS_CHECK:
                continue
            forms += 1
            for t, keys in SM.plan(db, src["id"], cfg["form_id"], cfg, day, day):
                if t > S.now_dt():
                    continue
                total += 1
                if db.execute("SELECT 1 FROM cs_submissions WHERE client_uuid=?", (SM._uuid(src["id"], cfg["form_id"], t),)).fetchone() \
                        or (SM.is_mixed(db, src, cfg["form_id"]) and keys is not None and keys <= SM._human_keys(db, cfg["form_id"], t)):
                    filled += 1
                    continue
                vals = SM.slot_values(db, src["id"], cfg["form_id"], cfg, t, keys)
                if vals:
                    why = "มีค่าแล้ว รอการดึงข้อมูลรอบถัดไป"
                elif not db.execute("SELECT 1 FROM cs_source_values WHERE source_id=? AND ts LIKE ?",
                                    (src["id"], f"{day.isoformat()}%")).fetchone():
                    why = "ไม่มีค่าจากแหล่งข้อมูลทั้งวัน (SCADA หยุด / ดึงข้อมูลไม่สำเร็จ / เก็บค่าดิบเกินกำหนด)"
                else:
                    why = f"ไม่มีค่าในช่วง ±{cfg['window_min']} นาทีรอบเวลานี้ — ขยายช่วง หรือตรวจ Tag"
                missing.append({"source_id": src["id"], "source": src["name"], "form_id": cfg["form_id"],
                                "form": cfg["eq_code"] or cfg["form_name"], "time": t.strftime("%H:%M"), "why": why})
    return {"day": day.isoformat(), "total": total, "filled": filled, "missing": missing[:100], "missing_n": len(missing),
            "pct": round(100 * filled / total) if total else None}


def status(db, day: date | None = None) -> dict:
    from . import formmap as FM
    from . import srcmap as SM
    now = S.now_dt()
    day = day or (now - timedelta(days=1)).date()
    srcs = CN.list_sources(db)
    # ── 1 เชื่อมต่อ ──
    s1 = []
    for s in srcs:
        st = "ok" if s["active"] and s["last_status"] == "ok" else ("todo" if not s["last_run_at"] else "warn")
        if not s["active"]:
            st = "warn"
        s1.append({**s, "state": st})
    st1 = "todo" if not srcs else ("ok" if any(x["state"] == "ok" for x in s1) and all(x["state"] != "todo" for x in s1) else "warn")
    # ── 2 เวลา ──
    s2 = []
    for s in srcs:
        full = CN.get_source(db, s["id"])
        s2.append({"id": s["id"], "name": s["name"], "shift": int(full.get("ts_shift_min") or 0), **time_check(db, full)})
    st2 = _worst([x["state"] for x in s2]) if s2 else "todo"
    # ── 3 Tag ──
    tags = db.execute("""SELECT COUNT(*) n, SUM(form_id IS NOT NULL AND item_key<>'') mapped,
                                SUM(last_seen IS NOT NULL) seen FROM cs_source_tags""").fetchone()
    stale = [dict(r) for r in db.execute("""SELECT t.tag, t.last_seen, s.name AS source, f.name AS form_name, e.code AS eq_code
                                            FROM cs_source_tags t JOIN cs_sources s ON s.id=t.source_id
                                            LEFT JOIN cs_forms f ON f.id=t.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
                                            WHERE t.form_id IS NOT NULL AND t.item_key<>'' AND s.active=1
                                              AND (t.last_seen IS NULL OR t.last_seen < ?) ORDER BY t.last_seen LIMIT 50""",
                                         (ts(now - timedelta(minutes=STALE_MIN)),))]
    s3 = {"total": tags["n"] or 0, "mapped": tags["mapped"] or 0, "seen": tags["seen"] or 0, "stale": stale}
    st3 = "todo" if not s3["total"] else ("warn" if stale else "ok")
    # ── 4 จับคู่หัวข้อ ──
    cov = FM.coverage_list(db)
    mapped_forms = [c for c in cov if c["mapped"]]
    sug_forms = []
    if s3["total"] > s3["mapped"]:                      # มี Tag ว่าง → หาแบบฟอร์มที่ระบบมีคำแนะนำ
        for c in cov[:MAX_FORMS_CHECK]:
            n = len(FM.suggest_for_form(db, c["id"]))
            if n:
                sug_forms.append({**c, "sug": n})
    s4 = {"forms": len(cov), "mapped_forms": len(mapped_forms), "items_mapped": sum(c["mapped"] for c in cov),
          "items_numeric": sum(c["numeric"] for c in cov), "sug_forms": sug_forms[:30], "top": mapped_forms[:30]}
    st4 = "todo" if not mapped_forms else ("warn" if sug_forms else "ok")
    # ── 5 วิธีลงค่า + ผลการลงค่า ──
    modes = {"round": 0, "times": 0, "bucket": 0}
    bucket_sched = []
    for s in srcs:
        for c in SM.form_cfgs(db, s["id"]):
            modes[c["effective"]] += 1
            if c["effective"] == "bucket" and c["schedules"]:
                bucket_sched.append({**c, "source_id": s["id"], "source": s["name"]})
    fill = fill_check(db, day)
    pend = db.execute("""SELECT COUNT(*) FROM cs_submissions WHERE source='auto' AND approval_status='pending'
                         AND status='submitted'""").fetchone()[0]
    s5 = {"modes": modes, "bucket_sched": bucket_sched, "fill": fill, "pending": pend}
    st5 = "todo" if not sum(modes.values()) else ("warn" if bucket_sched or fill["missing_n"] else "ok")
    steps = [st1, st2, st3, st4, st5]
    return {"steps": steps, "done": sum(1 for x in steps if x == "ok"), "s1": s1, "s2": s2, "s3": s3, "s4": s4, "s5": s5,
            "day": day, "now": now}


def apply_shift(db, sid: int, minutes: int, actor_id) -> None:
    src = CN.get_source(db, sid)
    if not src:
        raise S.ValidationError("ไม่พบแหล่งข้อมูล")
    minutes = max(-1440, min(1440, int(minutes)))
    db.execute("UPDATE cs_sources SET ts_shift_min=?, watermark='' WHERE id=?", (minutes, sid))
    S.audit(db, actor_id, "update", "cs_sources", sid, before={"ts_shift_min": src.get("ts_shift_min")},
            after={"ts_shift_min": minutes, "reason": "ศูนย์ผูกข้อมูล: ปรับเวลาตามที่ระบบแนะนำ"})
