"""ecs/health.py — หน้าสถานะระบบ: งานเบื้องหลังยังเดินไหม · ฐานข้อมูล/ดิสก์ · แบ็กอัปล่าสุด · ข้อความค้างส่ง · Error ล่าสุด
และตรวจคุณภาพข้อมูล (สิ่งที่ผู้ดูแลควรแก้)"""
from __future__ import annotations

import os
import platform
import shutil
import sys
from datetime import datetime, timedelta

STARTED_AT = datetime.now()
_beats: dict[str, datetime] = {}


def beat(name: str) -> None:
    _beats[name] = datetime.now()


def _dir_size(path: str) -> tuple[int, int]:
    total = n = 0
    if path and os.path.isdir(path):
        for root, _, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                    n += 1
                except OSError:
                    pass
    return total, n


def _log_errors(log_path: str, limit: int = 30) -> list[str]:
    if not log_path or not os.path.exists(log_path):
        return []
    try:
        with open(log_path, "rb") as fh:
            fh.seek(max(0, os.path.getsize(log_path) - 400_000))
            lines = fh.read().decode("utf-8", "replace").splitlines()
    except OSError:
        return []
    hits = [ln for ln in lines if " ERROR " in ln or "Traceback" in ln or " CRITICAL " in ln]
    return hits[-limit:]


def _check(ok, label, detail="", level="bad"):
    return {"ok": bool(ok), "label": label, "detail": detail, "level": "ok" if ok else level}


def collect(db, app) -> dict:
    from . import __version__
    from . import backup as BK
    cfg = app.config
    now = datetime.now()
    db_path = cfg["DATABASE"]
    db_size = os.path.getsize(db_path) if os.path.exists(db_path) else 0
    wal = db_path + "-wal"
    wal_size = os.path.getsize(wal) if os.path.exists(wal) else 0
    up_size, up_n = _dir_size(cfg["UPLOAD_FOLDER"])
    try:
        du = shutil.disk_usage(os.path.dirname(db_path) or ".")
        disk = {"total": du.total, "free": du.free, "pct_free": round(100 * du.free / du.total, 1) if du.total else None}
    except OSError:
        disk = None
    bk = BK.settings(cfg)
    last_bk = BK.last(db)
    backups = BK.list_backups(bk["dir"])
    try:
        bk_disk = shutil.disk_usage(bk["dir"]) if os.path.isdir(bk["dir"]) else None
    except OSError:
        bk_disk = None
    same_drive = os.path.splitdrive(os.path.abspath(bk["dir"]))[0].lower() == os.path.splitdrive(os.path.abspath(db_path))[0].lower() \
        and os.path.abspath(bk["dir"]).startswith(os.path.dirname(os.path.dirname(os.path.abspath(db_path))))
    counts = {t: db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in
              ("users", "equipment", "cs_forms", "cs_submissions", "cs_answers", "cs_photos", "cs_alerts", "cs_actions")}
    outbox = {r[0]: r[1] for r in db.execute("SELECT status, COUNT(*) FROM cs_msg_outbox GROUP BY status")}
    outbox_fail = [dict(r) for r in db.execute("""SELECT channel, COALESCE(NULLIF(target_label, ''), target) AS target, last_error AS error, created_at FROM cs_msg_outbox
                                                   WHERE status='failed' ORDER BY id DESC LIMIT 10""")]
    jobs_on = bool(cfg.get("ENABLE_JOBS")) and not cfg.get("TESTING")
    beats = {k: v for k, v in _beats.items()}
    job_iv = max(60, int(cfg.get("JOB_INTERVAL_SEC", 300)))

    def beat_ok(name, max_age):
        b = beats.get(name)
        return b is not None and now - b < timedelta(seconds=max_age)

    # คุณภาพข้อมูล
    dq = [
        ("แบบฟอร์มที่ Publish แล้วแต่ยังไม่ตั้งรอบตรวจ", db.execute("""SELECT COUNT(*) FROM cs_forms f WHERE f.active=1 AND f.is_template=0
              AND f.current_version_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM cs_schedules s WHERE s.form_id=f.id AND s.active=1)""").fetchone()[0],
         "forms.forms", {"status": "nosched"}),
        ("แบบฟอร์มที่ยังไม่ผูกเครื่องจักร", db.execute("""SELECT COUNT(*) FROM cs_forms WHERE active=1 AND is_template=0
              AND equipment_id IS NULL""").fetchone()[0], "forms.forms", {"bind": "no"}),
        ("หัวข้อตัวเลขที่ยังไม่มีเกณฑ์ Min/Max", db.execute("""SELECT COUNT(*) FROM cs_form_items i JOIN cs_forms f ON f.current_version_id=i.version_id
              WHERE f.active=1 AND i.item_type='number' AND i.min_value IS NULL AND i.max_value IS NULL""").fetchone()[0], "forms.forms", {}),
        ("เครื่องจักรที่ยังไม่ระบุพื้นที่", db.execute("SELECT COUNT(*) FROM equipment WHERE active=1 AND area_id IS NULL").fetchone()[0],
         "admin.equipment", {"area": ""}),
        ("เครื่องที่แจ้งหยุดเกินกำหนดคืน", db.execute("""SELECT COUNT(*) FROM equipment WHERE run_status='down' AND down_until IS NOT NULL
              AND down_until < ?""", (now.strftime("%Y-%m-%d %H:%M:%S"),)).fetchone()[0], "admin.equipment_down_list", {}),
        ("ผลตรวจรออนุมัติเกิน 3 วัน", db.execute("""SELECT COUNT(*) FROM cs_submissions WHERE status='submitted' AND approval_status='pending'
              AND finished_at < ?""", ((now - timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S"),)).fetchone()[0], "review.submissions", {}),
        ("ผู้ใช้ที่ยังไม่ระบุโรงงาน (ช่าง)", db.execute("""SELECT COUNT(*) FROM users WHERE active=1 AND role='technician'
              AND factory_id IS NULL""").fetchone()[0], "admin.users", {}),
    ]
    bk_age = None
    if last_bk and last_bk.get("at"):
        try:
            bk_age = now - datetime.strptime(last_bk["at"], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            bk_age = None
    checks = [
        _check(not jobs_on or beat_ok("jobs", job_iv * 3), "งานเบื้องหลัง (สร้างรอบตรวจ/เลยกำหนด)",
               f"ทำงานล่าสุด {beats['jobs']:%H:%M:%S}" if "jobs" in beats else ("ปิดอยู่ (ENABLE_JOBS=0)" if not jobs_on else "ยังไม่ทำงาน")),
        _check(not jobs_on or beat_ok("notify", 300), "ตัวส่งแจ้งเตือน / รายงานตามเวลา",
               f"ทำงานล่าสุด {beats['notify']:%H:%M:%S}" if "notify" in beats else ("ปิดอยู่" if not jobs_on else "ยังไม่ทำงาน")),
        _check(last_bk and last_bk.get("ok") and bk_age is not None and bk_age < timedelta(hours=26), "แบ็กอัปล่าสุดภายใน 24 ชม.",
               (f"{last_bk['at']} · {'สำเร็จ' if last_bk.get('ok') else 'ล้มเหลว: ' + str(last_bk.get('error', ''))}") if last_bk else "ยังไม่เคยแบ็กอัป"),
        _check(disk is None or (disk["pct_free"] or 0) >= 10, "พื้นที่ดิสก์เหลือ ≥ 10%",
               f"เหลือ {disk['free'] / 1e9:.1f} GB ({disk['pct_free']}%)" if disk else "-", "warn"),
        _check(not same_drive, "เก็บแบ็กอัปแยกจากโฟลเดอร์ระบบ",
               "แนะนำตั้ง BACKUP_DIR ไปดิสก์อื่น/แชร์ไดรฟ์ (ถ้าเครื่องเสียจะได้ไม่หายพร้อมกัน)" if same_drive else bk["dir"], "warn"),
        _check(not outbox.get("failed"), "ข้อความแจ้งเตือนส่งไม่ออก", f"{outbox.get('failed', 0)} ข้อความ" if outbox.get("failed") else "ไม่มี", "warn"),
    ]
    return {
        "version": __version__, "python": sys.version.split()[0], "platform": platform.platform(terse=True),
        "started_at": STARTED_AT, "uptime": now - STARTED_AT, "now": now,
        "db": {"path": db_path, "size": db_size, "wal": wal_size, "counts": counts},
        "uploads": {"path": cfg["UPLOAD_FOLDER"], "size": up_size, "files": up_n},
        "disk": disk, "backup": {**bk, "last": last_bk, "files": backups[:20], "count": len(backups),
                                 "disk_free": bk_disk.free if bk_disk else None},
        "outbox": outbox, "outbox_fail": outbox_fail, "beats": beats, "jobs_on": jobs_on,
        "checks": checks, "dq": dq,
        "log_errors": _log_errors(os.path.join(os.path.dirname(db_path), "portal.log")) or
                      _log_errors(os.path.join(os.path.dirname(db_path), "app.log")),
    }


def integrity(db) -> str:
    return db.execute("PRAGMA quick_check").fetchone()[0]
