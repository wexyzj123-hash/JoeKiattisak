"""ecs/energy_forms.py — v0.66 แบบฟอร์มการจดมิเตอร์ (ออกแบบเอง · เรียงลำดับการจดเอง)

แบบฟอร์ม 1 ชุด = รายการมิเตอร์ตามลำดับเดินจดจริง + หัวข้อคั่น (เช่น “ห้อง MDB ชั้น 2”) — ข้ามหมวดได้ (ไฟฟ้า/ลม/น้ำในรอบเดียว)
ตั้งต่อรายการได้: บังคับรูปหน้าปัด · คำแนะนำการอ่าน (เช่น “อ่านจอบนสุด หน่วย MWh”)
ใช้ได้ทั้งหน้าจดมือถือ (ไปตัวถัดไปตามลำดับในแบบฟอร์ม) และหน้าบันทึกค่า (ตารางเรียงตามแบบฟอร์ม)

  en_forms       id · name · factory_id · note · active · sort_no
  en_form_items  form_id · pos · type (meter|header) · meter_id · title · photo · hint
"""
from __future__ import annotations

import json

from . import services as S
from .services import ts

DDL = """
CREATE TABLE IF NOT EXISTS en_forms (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    factory_id  INTEGER,
    note        TEXT NOT NULL DEFAULT '',
    active      INTEGER NOT NULL DEFAULT 1,
    sort_no     INTEGER NOT NULL DEFAULT 0,
    created_by  INTEGER,
    created_at  TEXT NOT NULL,
    updated_by  INTEGER,
    updated_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS en_form_items (
    form_id     INTEGER NOT NULL,
    pos         INTEGER NOT NULL,
    type        TEXT NOT NULL DEFAULT 'meter',
    meter_id    INTEGER,
    title       TEXT NOT NULL DEFAULT '',
    photo       INTEGER NOT NULL DEFAULT 0,
    hint        TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (form_id, pos)
);
CREATE INDEX IF NOT EXISTS idx_enfi_meter ON en_form_items(meter_id);
"""


def ensure_forms(db) -> None:
    db.executescript(DDL)


def _scope(db, uid):
    from .energy_field import user_scope
    return user_scope(db, uid)


def forms(db, uid=None, factory_id=None, active_only: bool = False) -> list[dict]:
    ensure_forms(db)
    sc = _scope(db, uid) if uid else {"factory_id": None}
    w, a = ["1=1"], []
    fid = sc["factory_id"] or factory_id
    if fid:
        w.append("(f.factory_id=? OR f.factory_id IS NULL)")
        a.append(fid)
    if active_only:
        w.append("f.active=1")
    return [dict(r) for r in db.execute(f"""SELECT f.*, fa.name AS factory_name, u.name AS updated_name,
                    (SELECT COUNT(*) FROM en_form_items i WHERE i.form_id=f.id AND i.type='meter') AS n_meters,
                    (SELECT COUNT(*) FROM en_form_items i WHERE i.form_id=f.id AND i.type='header') AS n_headers
                    FROM en_forms f LEFT JOIN factories fa ON fa.id=f.factory_id LEFT JOIN users u ON u.id=f.updated_by
                    WHERE {' AND '.join(w)} ORDER BY f.active DESC, f.sort_no, f.name""", a)]


def form(db, form_id: int) -> dict | None:
    ensure_forms(db)
    r = db.execute("SELECT f.*, fa.name AS factory_name FROM en_forms f LEFT JOIN factories fa ON fa.id=f.factory_id WHERE f.id=?",
                   (form_id,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["items"] = items(db, form_id)
    return d


def items(db, form_id: int) -> list[dict]:
    from . import energy as EN
    out = []
    for r in db.execute("""SELECT i.*, m.code, m.name, m.grp, m.kind, m.unit, m.location, m.factory_id AS m_factory, m.active AS m_active
                           FROM en_form_items i LEFT JOIN en_meters m ON m.id=i.meter_id WHERE i.form_id=? ORDER BY i.pos""", (form_id,)):
        d = dict(r)
        if d["type"] == "meter":
            if d["kind"] is None:                      # มิเตอร์ถูกลบไปแล้ว
                continue
            d["label"] = EN.label({"code": d["code"], "name": d["name"], "key": ""})
        out.append(d)
    return out


def meter_ids(db, form_id: int) -> list[int]:
    return [r[0] for r in db.execute("""SELECT i.meter_id FROM en_form_items i JOIN en_meters m ON m.id=i.meter_id
                                        WHERE i.form_id=? AND i.type='meter' AND m.active=1 ORDER BY i.pos""", (form_id,))]


def can_edit(db, uid, f: dict | None) -> bool:
    sc = _scope(db, uid)
    if sc["role"] not in ("admin", "supervisor", "technician"):
        return False
    if f is None or not sc["factory_id"]:
        return True
    return f.get("factory_id") == sc["factory_id"]


def save(db, form_id: int | None, data: dict, actor) -> int:
    """บันทึกหัวแบบฟอร์ม + รายการ (items = [{type, meter_id, title, photo, hint}] ตามลำดับ)"""
    ensure_forms(db)
    sc = _scope(db, actor)
    name = str(data.get("name") or "").strip()[:120]
    if not name:
        raise S.ValidationError("ตั้งชื่อแบบฟอร์ม")
    fid = data.get("factory_id")
    fid = int(fid) if str(fid or "").isdigit() and int(fid) else None
    if sc["factory_id"]:
        fid = sc["factory_id"]
    note = str(data.get("note") or "").strip()[:300]
    active = 0 if str(data.get("active", "1")) in ("0", "false", "False") else 1
    try:
        sort_no = int(data.get("sort_no") or 0)
    except (TypeError, ValueError):
        sort_no = 0
    raw = data.get("items")
    if isinstance(raw, str):
        try:
            raw = json.loads(raw or "[]")
        except ValueError:
            raise S.ValidationError("รายการในแบบฟอร์มไม่ถูกต้อง") from None
    raw = raw or []
    clean = []
    seen = set()
    for it in raw[:2000]:
        t = it.get("type") or "meter"
        if t == "header":
            title = str(it.get("title") or "").strip()[:120]
            if title:
                clean.append({"type": "header", "meter_id": None, "title": title, "photo": 0, "hint": ""})
            continue
        try:
            mid = int(it.get("meter_id"))
        except (TypeError, ValueError):
            continue
        if mid in seen:
            continue
        m = db.execute("SELECT factory_id FROM en_meters WHERE id=?", (mid,)).fetchone()
        if not m:
            continue
        if sc["factory_id"] and m[0] and m[0] != sc["factory_id"]:
            raise S.ValidationError("เพิ่มได้เฉพาะมิเตอร์ของโรงงานตัวเอง")
        seen.add(mid)
        clean.append({"type": "meter", "meter_id": mid, "title": "", "photo": 1 if it.get("photo") in (1, "1", True) else 0,
                      "hint": str(it.get("hint") or "").strip()[:200]})
    if not any(c["type"] == "meter" for c in clean):
        raise S.ValidationError("เพิ่มมิเตอร์อย่างน้อย 1 ตัว")
    stamp = ts(S.now_dt())
    if form_id:
        old = form(db, form_id)
        if not old:
            raise S.ValidationError("ไม่พบแบบฟอร์ม")
        if not can_edit(db, actor, old):
            raise S.ValidationError("ไม่มีสิทธิ์แก้แบบฟอร์มนี้")
        db.execute("""UPDATE en_forms SET name=?, factory_id=?, note=?, active=?, sort_no=?, updated_by=?, updated_at=? WHERE id=?""",
                   (name, fid, note, active, sort_no, actor, stamp, form_id))
        db.execute("DELETE FROM en_form_items WHERE form_id=?", (form_id,))
        S.audit(db, actor, "energy_form", "en_forms", form_id,
                before={"name": old["name"], "items": [(i["type"], i["meter_id"] or i["title"]) for i in old["items"]]},
                after={"name": name, "items": [(c["type"], c["meter_id"] or c["title"]) for c in clean]})
    else:
        form_id = db.execute("""INSERT INTO en_forms(name, factory_id, note, active, sort_no, created_by, created_at, updated_by, updated_at)
                                VALUES (?,?,?,?,?,?,?,?,?)""", (name, fid, note, active, sort_no, actor, stamp, actor, stamp)).lastrowid
        S.audit(db, actor, "energy_form_new", "en_forms", form_id, after={"name": name, "n": len(clean)})
    for pos, c in enumerate(clean, 1):
        db.execute("INSERT INTO en_form_items(form_id, pos, type, meter_id, title, photo, hint) VALUES (?,?,?,?,?,?,?)",
                   (form_id, pos, c["type"], c["meter_id"], c["title"], c["photo"], c["hint"]))
    return form_id


def delete(db, form_id: int, actor) -> None:
    f = form(db, form_id)
    if not f:
        raise S.ValidationError("ไม่พบแบบฟอร์ม")
    if not can_edit(db, actor, f):
        raise S.ValidationError("ไม่มีสิทธิ์ลบแบบฟอร์มนี้")
    db.execute("DELETE FROM en_form_items WHERE form_id=?", (form_id,))
    db.execute("DELETE FROM en_forms WHERE id=?", (form_id,))
    S.audit(db, actor, "energy_form_del", "en_forms", form_id, before={"name": f["name"], "n": len(f["items"])})


def copy(db, form_id: int, actor) -> int:
    f = form(db, form_id)
    if not f:
        raise S.ValidationError("ไม่พบแบบฟอร์ม")
    return save(db, None, {"name": f"{f['name']} (สำเนา)"[:120], "factory_id": f["factory_id"], "note": f["note"], "active": 1,
                           "items": [{k: i[k] for k in ("type", "meter_id", "title", "photo", "hint")} for i in f["items"]]}, actor)


def from_sections(db, factory_id, kinds: list[str] | None = None) -> list[dict]:
    """ร่างเริ่มต้น: มิเตอร์ของโรงงาน เรียงตามหมวด › Section พร้อมหัวข้อคั่น"""
    from . import energy as EN
    out = []
    last = None
    for m in EN.meters(db, factory_id):
        if kinds and m["kind"] not in kinds:
            continue
        g = f"{EN.KINDS.get(m['kind'], {}).get('th', m['kind'])} · {m['grp'] or 'ทั่วไป'}"
        if g != last:
            out.append({"type": "header", "title": g})
            last = g
        out.append({"type": "meter", "meter_id": m["id"], "photo": 0, "hint": ""})
    return out


def for_pack(db, uid) -> list[dict]:
    """แบบฟอร์มที่ใช้งานได้ของผู้ใช้ (ส่งให้มือถือ)"""
    out = []
    for f in forms(db, uid, active_only=True):
        its = [{"type": i["type"], "meter_id": i["meter_id"], "title": i["title"], "photo": i["photo"], "hint": i["hint"]}
               for i in items(db, f["id"])]
        out.append({"id": f["id"], "name": f["name"], "factory_id": f["factory_id"], "note": f["note"], "items": its})
    return out
