"""ecs/srcwatch.py — v0.75 เฝ้าแหล่งข้อมูล SCADA (E-Check และ Energy Data)

- ดึงไม่สำเร็จติดกัน FAIL_RUNS ครั้ง  → แจ้ง "ขัดข้อง" ถึงผู้ดูแลระบบ (กระดิ่ง + อีเมล/LINE/Teams ตามที่ตั้งไว้ของแต่ละคน)
- ดึงสำเร็จแต่ไม่มีข้อมูลใหม่เกิน STALE_MIN นาที → แจ้ง "ข้อมูลหยุด" (SCADA/Historian หยุดเขียน หรือ Query ไม่ได้ช่วงล่าสุด)
- กลับมาปกติ → แจ้ง "กลับมาปกติ" และดึงช่องที่ขาดช่วงที่ขัดข้องให้เอง (ย้อนหลังไม่เกิน BACKFILL_MAX_DAYS วัน)
แจ้งครั้งเดียวต่อเหตุการณ์ (เก็บสถานะใน alert_state / alert_since ของแหล่งข้อมูล)
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta

from . import services as S
from .services import parse_ts, ts

log = logging.getLogger(__name__)

FAIL_RUNS = 3
STALE_MIN = 180
BACKFILL_MAX_DAYS = 7
KINDS = {"echeck": ("cs_sources", "cs_source_runs", "/admin/sources/{id}", "E-Check"),
         "energy": ("en_sources", "en_source_runs", "/energy/sources/{id}", "Energy Data")}
STATE_TH = {"fail": "ดึงข้อมูลไม่สำเร็จ", "stale": "ไม่มีข้อมูลใหม่"}


def _admins(db) -> list[dict]:
    return [dict(u) for u in db.execute("SELECT * FROM users WHERE active=1 AND role='admin' ORDER BY id")]


def _send(db, kind: str, src: dict, subject: str, body: str, severity: str, ref: str, now: datetime) -> int:
    from . import notify as N
    path = KINDS[kind][2].format(id=src["id"])
    try:
        cfg = N.get_settings(db)
        res = N._deliver(db, cfg, "", {"users": _admins(db), "groups": []}, kind="source_watch", subject=subject, body=body,
                         path=path, severity=severity, ref_key=ref, now=now)
        return res["app"] + res["ext"]
    except Exception:                                    # noqa: BLE001 — แจ้งเตือนต้องไม่ทำให้การดึงข้อมูลล้ม
        log.exception("source watch notify failed")
        n = 0
        for u in _admins(db):
            n += N.notify_user_app(db, u["id"], "source_watch", subject, body, path, severity, ref, now)
        return n


def state_of(db, kind: str, src: dict, now: datetime) -> tuple[str, datetime | None, str]:
    """('' | fail | stale, ตั้งแต่เมื่อไร, รายละเอียด)"""
    table, runs, _p, _l = KINDS[kind]
    last = db.execute(f"SELECT status, started_at, message FROM {runs} WHERE source_id=? ORDER BY id DESC LIMIT ?",
                      (src["id"], FAIL_RUNS)).fetchall()
    if len(last) >= FAIL_RUNS and all(r["status"] != "ok" for r in last):
        return "fail", parse_ts(last[-1]["started_at"]), last[0]["message"] or ""
    wm = parse_ts(src["watermark"]) if src.get("watermark") else None
    stale = max(STALE_MIN, 2 * int(src.get("interval_min") or 15))
    if wm and src.get("kind") != "csv" and last and last[0]["status"] == "ok" and now - wm > timedelta(minutes=stale):
        return "stale", wm, f"ข้อมูลล่าสุดเมื่อ {wm:%d/%m %H:%M} ({(now - wm).total_seconds() / 3600:.1f} ชม.ก่อน)"
    return "", None, ""


def check(db, kind: str, sid: int, now: datetime | None = None) -> str:
    """เรียกหลังดึงข้อมูลทุกครั้ง → ส่งแจ้งเตือนเมื่อสถานะเปลี่ยน · คืนสถานะปัจจุบัน"""
    table, _runs, _p, label = KINDS[kind]
    now = now or S.now_dt()
    src = dict(db.execute(f"SELECT * FROM {table} WHERE id=?", (sid,)).fetchone() or {})
    if not src or not src.get("active"):
        return ""
    st, since, detail = state_of(db, kind, src, now)
    old = src.get("alert_state") or ""
    if st == old:
        return st
    if st:                                               # เริ่มขัดข้อง (หรือเปลี่ยนชนิด)
        db.execute(f"UPDATE {table} SET alert_state=?, alert_since=? WHERE id=?",
                   (st, src.get("alert_since") if old else ts(since or now), sid))
        _send(db, kind, src, f"⚠ SCADA {label}: {src['name']} — {STATE_TH[st]}",
              f"{detail}\nตั้งแต่ {(since or now):%d/%m/%Y %H:%M}\nค่าอัตโนมัติจะไม่ลงจนกว่าจะแก้ไข — ตรวจการเชื่อมต่อ / SCADA / Historian",
              "warning", f"srcwatch:{kind}:{sid}:{st}:{ts(since or now)}", now)
        return st
    # กลับมาปกติ → ดึงช่องที่ขาดช่วงที่ขัดข้อง
    began = parse_ts(src["alert_since"]) if src.get("alert_since") else now - timedelta(days=1)
    db.execute(f"UPDATE {table} SET alert_state='', alert_since=NULL WHERE id=?", (sid,))
    made = 0
    try:
        made = backfill(db, kind, sid, began, now)
    except Exception as exc:                              # noqa: BLE001
        log.warning("backfill after recovery failed (%s %s): %s", kind, sid, exc)
    _send(db, kind, src, f"✅ SCADA {label}: {src['name']} — กลับมาปกติ",
          f"ขัดข้องตั้งแต่ {began:%d/%m/%Y %H:%M} ({(now - began).total_seconds() / 3600:.1f} ชม.)"
          + (f"\nดึงช่องที่ขาดช่วงนั้นแล้ว {made} รายการ" if made else "\nตรวจช่องที่ยังขาดได้ที่หน้า ตรวจ/แก้ค่าย้อนหลัง"),
          "info", f"srcwatch:{kind}:{sid}:ok:{ts(began)}", now)
    return ""


def backfill(db, kind: str, sid: int, began: datetime, now: datetime) -> int:
    d_from = max(began.date(), (now - timedelta(days=BACKFILL_MAX_DAYS - 1)).date())
    if kind == "echeck":
        from . import connectors as CN
        from . import srcmap as SM
        src = CN.get_source(db, sid)
        return SM.fill_range(db, src, d_from, now.date(), now=now)["created"] if src else 0
    from . import energy_src as ES
    src = ES.get_source(db, sid)
    return ES.fill_range(db, src, d_from, now.date(), now=now)["readings"] if src else 0


def safe_check(db, kind: str, sid: int, now: datetime | None = None) -> str:
    try:
        return check(db, kind, sid, now)
    except Exception:                                     # noqa: BLE001
        log.exception("source watch failed (%s %s)", kind, sid)
        return ""
