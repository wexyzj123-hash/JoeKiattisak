"""ecs/view_scope.py — v0.29 จำกัดการดูเช็คชีท (หน่วยงาน ENVIRONMENT / SAFETY)

ผู้ดูแลระบบติ๊ก "จำกัดการดู" รายคน (users.restrict_view) → ผู้ใช้คนนั้นเห็นเฉพาะแบบฟอร์ม (Check Sheet)
ที่ตนมีสิทธิ์ลงนาม/อนุมัติ ตามหน่วยงานที่ตั้งในแบบฟอร์ม (sign_config: ENVIRONMENT หรือ SAFETY)
  · กลุ่ม ENVIRONMENT (env_sv / env_mgr)  → แบบฟอร์มหน่วยงาน ENVIRONMENT
  · กลุ่ม SAFETY (safety_sf) หรือตำแหน่ง DM → แบบฟอร์มหน่วยงาน SAFETY
ผู้ดูแลระบบ (admin) ไม่ถูกจำกัดเสมอ · หน้าอื่นที่รวมข้อมูลทุกแบบฟอร์ม (แดชบอร์ด แนวโน้ม แจ้งเตือน ฯลฯ) ถูกปิดสำหรับบัญชีที่จำกัด
"""
from __future__ import annotations

from flask import abort, flash, g, has_request_context, jsonify, redirect, request, session, url_for

from . import sign_blocks as SB

# หน้าที่บัญชีที่ถูกจำกัดเปิดได้ (ที่เหลือ → กลับไปหน้าเช็คชีทของฉัน)
ALLOWED_ENDPOINTS = {
    "static", "index", "cmms.badge", "dash.client_log",
    "sign.my_signature", "sign.my_signature_png", "sign.signoffs", "sign.signoff_sign", "sign.signoff_cancel",
    "forms.forms", "forms.form_detail", "forms.form_export_xlsx", "forms.version_view",
    "rep.index", "rep.sheets", "rep.record", "rep.doc_image",
    "review.submissions", "review.submission_detail", "review.approvals_group",
    "review.submission_approve", "review.submission_return",
    "work.api_notifications", "work.api_notifications_read", "work.notifications", "work.notifications_read_all",
    "work.open_notification", "work.api_theme", "work.my_notify", "work.my_notify_test",
    "mobile.media", "mobile.service_worker", "mobile.manifest",
    # v0.52 แก้ไขแบบฟอร์มที่ผู้ดูแลระบบอนุญาต (ตรวจสิทธิ์รายแบบฟอร์มอีกชั้นใน perms.require_form)
    "forms.builder", "forms.api_draft_get", "forms.api_draft_save", "forms.api_publish", "forms.api_discard",
    "forms.api_import_items", "forms.form_import_xlsx", "forms.point_labels",
    "forms.schedule_create", "forms.schedule_update", "forms.schedule_delete",
    "team.view_as_stop", "team.status_help",
}
DEPT_TH = {"env": "ENVIRONMENT", "safety": "SAFETY"}


def form_dept(cfg: dict) -> str:
    """หน่วยงานของแบบฟอร์ม จากค่าช่องลงนาม (กล่องมุมขวาบน หรือแถวลงนามในตาราง)"""
    d = SB.dept(cfg)
    if d:
        return d
    for k in cfg.get("rows") or []:
        return SB.ROW_DEPT.get(k, "")
    return ""


def user_depts(db, user_id: int) -> set[str]:
    from . import signoffs as SO
    groups = SO.user_groups(db, user_id)
    out = {d for d, gs in SO.DEPT_GROUPS.items() if groups & set(gs)}
    if SO.user_position(db, user_id) == "dm":
        out.add("safety")
    return out


def is_restricted(db, user_id) -> bool:
    r = db.execute("SELECT role, COALESCE(restrict_view,0) FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None
    return bool(r and r[0] != "admin" and r[1])


def forms_by_dept(db) -> dict[int, str]:
    """{form_id: 'env'|'safety'|''} ทุกแบบฟอร์ม (ใช้ค่าของแม่แบบถ้าแบบฟอร์มไม่ได้ตั้งเอง)"""
    raw = {r[0]: (r[1], r[2]) for r in db.execute("SELECT id, sign_config, template_id FROM cs_forms")}
    out = {}
    for fid, (sc, tid) in raw.items():
        cfg = SB.parse(sc)
        if SB.is_empty(cfg) and tid and tid in raw:
            cfg = SB.parse(raw[tid][0])
        out[fid] = form_dept(cfg)
    return out


def allowed_form_ids(db, user_id) -> set[int] | None:
    """None = ไม่จำกัด · set = รหัสแบบฟอร์มที่เห็นได้"""
    if not is_restricted(db, user_id):
        return None
    depts = user_depts(db, user_id)
    return {fid for fid, d in forms_by_dept(db).items() if d and d in depts}


def current() -> set[int] | None:
    """ขอบเขตของผู้ใช้ที่ล็อกอินในคำขอนี้ (แคชต่อคำขอ) · นอกคำขอเว็บ (งานเบื้องหลัง) = ไม่จำกัด"""
    if not has_request_context() or "user_id" not in session:
        return None
    if "_view_scope" not in g:
        from .db import get_db
        g._view_scope = allowed_form_ids(get_db(), session["user_id"])
    return g._view_scope


def sql(alias: str = "f.id") -> tuple[str, list]:
    """เงื่อนไข SQL ต่อท้าย WHERE: (' AND f.id IN (...)', params) หรือ ('', [])"""
    ids = current()
    if ids is None:
        return "", []
    if not ids:
        return " AND 0", []
    ids = sorted(ids)
    return f" AND {alias} IN ({','.join('?' * len(ids))})", ids


def can_see_form(form_id) -> bool:
    ids = current()
    return ids is None or (form_id is not None and int(form_id) in ids)


def _form_ids_in_request(db) -> list[int]:
    va = request.view_args or {}
    out = []
    if va.get("form_id"):
        out.append(va["form_id"])
    if va.get("sub_id"):
        r = db.execute("SELECT form_id FROM cs_submissions WHERE id=?", (va["sub_id"],)).fetchone()
        out.append(r[0] if r else -1)
    for part in request.args.getlist("form"):
        out += [int(x) for x in str(part).split(",") if x.strip().isdigit()]
    return out


def guard():
    """เรียกใน before_request — ปิดหน้าที่ไม่เกี่ยว + ห้ามเปิดแบบฟอร์ม/ผลตรวจนอกสิทธิ์ (403)"""
    if request.endpoint in (None, "static") or "user_id" not in session:
        return None
    ep = request.endpoint
    if ep.startswith("auth.") or (ep.startswith("cmms.") and ep != "cmms.legacy_qr"):
        return None
    ids = current()
    if ids is None:
        return None
    if ep == "index":
        return redirect(url_for("rep.index"))
    if ep not in ALLOWED_ENDPOINTS:
        if request.path.startswith("/api/"):
            return jsonify({"error": "บัญชีนี้ถูกจำกัดให้ดูเฉพาะเช็คชีทที่มีสิทธิ์อนุมัติ", "code": "restricted"}), 403
        flash("บัญชีนี้ถูกจำกัดให้ดูเฉพาะเช็คชีทที่มีสิทธิ์อนุมัติ (ENVIRONMENT / SAFETY) — ติดต่อผู้ดูแลระบบหากต้องการสิทธิ์เพิ่ม", "error")
        return redirect(url_for("rep.index"))
    from .db import get_db
    for fid in _form_ids_in_request(get_db()):
        if fid not in ids:
            abort(403)
    return None
