"""ecs/notify.py — Phase 4: ส่งแจ้งเตือน + ส่งต่อ L1–L3 + ช่วงเงียบ + เตือนรอบตรวจ + สรุปประจำวัน

ช่องทาง
- กระดิ่งในระบบ (cs_notifications) ใช้ได้เสมอ แม้เครื่องแม่ข่ายออกอินเทอร์เน็ตไม่ได้
- Telegram Bot API, LINE Messaging API (push), Microsoft Teams (Incoming Webhook / Workflows), Email (SMTP)

ข้อความภายนอกเข้าคิว cs_msg_outbox ก่อนเสมอ แล้วงานเบื้องหลังส่งทีละรายการ ส่งไม่สำเร็จจะลองใหม่อัตโนมัติ
(1, 5, 15, 60, 180 นาที) — ไม่ถือ transaction ของฐานข้อมูลไว้ระหว่างรอเครือข่าย
"""
from __future__ import annotations

import copy
import html
import json
import logging
import os
import re
import smtplib
import ssl
import threading
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta
from email.message import EmailMessage
from typing import Any, Callable

from . import services as S
from .anomaly import OPEN_STATUSES, SEV_RANK, TYPE_TH
from .services import parse_ts, ts

log = logging.getLogger(__name__)

CHANNELS = ("telegram", "line", "teams", "email")
CHANNEL_TH = {"app": "ในระบบ", "telegram": "Telegram", "line": "LINE", "teams": "Microsoft Teams", "email": "อีเมล"}
SEV_TH = {"critical": "วิกฤต", "warning": "เตือน", "info": "ข้อมูล"}
SEV_ICON = {"critical": "🔴", "warning": "🟠", "info": "🔵"}
RETRY_MIN = (1, 5, 15, 60, 180)
MAX_ATTEMPTS = len(RETRY_MIN) + 1

DEFAULT_SETTINGS: dict[str, Any] = {
    "telegram": {"enabled": False, "bot_token": "", "default_target": ""},
    "line": {"enabled": False, "access_token": "", "default_target": ""},
    "teams": {"enabled": False, "default_target": ""},
    "email": {"enabled": False, "host": "", "port": 587, "security": "starttls", "username": "", "password": "",
              "sender": "", "default_target": ""},
    # ยังไม่แก้ไขเกินกี่ชั่วโมงหลังเกิด → เตือนระดับถัดไป (0 = ไม่เตือน)
    "sla_hours": {"critical": 8, "warning": 24, "info": 0},
    "round_due_before_min": 30,      # เตือนช่างก่อนครบกำหนดกี่นาที (0 = ไม่เตือน)
    "round_overdue": True,           # เตือนช่างเมื่อเลยกำหนด
    "capa_remind": True,             # เตือนเจ้าของงาน CAPA ก่อนครบ/เมื่อเลยกำหนด
    "daily_summary": {"enabled": False, "time": "17:00"},
    # v0.20 ถึงเวลาตรวจ → ส่งเข้ากลุ่ม (Teams / Telegram / …) แยกตามความถี่
    "round_start": {"enabled": False, "freqs": ["shift", "daily", "weekly", "monthly"], "channels": ["telegram", "teams"],
                    "use_l1_groups": True},
    # v0.38 เตือนผู้อนุมัติ (หัวหน้างาน / Sr.Tech / FM / SV …) เรื่องผลตรวจที่ยังไม่อนุมัติ — สัปดาห์ละครั้ง
    "weekly_approval": {"enabled": True, "weekday": 0, "time": "08:30"},
}
WEEKDAY_TH = ("จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์", "เสาร์", "อาทิตย์")
FREQ_LABEL = {"shift": ("🔁", "รายกะ"), "daily": ("📅", "ประจำวัน"), "weekly": ("🗓", "ประจำสัปดาห์"),
              "monthly": ("📆", "ประจำเดือน"), "semimonthly": ("🗓", "ครึ่งเดือน"), "": ("🔔", "ตามรอบ")}
SECRETS = {("telegram", "bot_token"): "TELEGRAM_BOT_TOKEN", ("line", "access_token"): "LINE_CHANNEL_ACCESS_TOKEN",
           ("email", "password"): "SMTP_PASSWORD"}


class SendError(Exception):
    pass


def _env_secret(name: str) -> str:
    from .settings import env
    return env(name, "").strip()


# ───────────────────────── settings ─────────────────────────

def get_settings(db, with_secrets: bool = True) -> dict:
    cfg = copy.deepcopy(DEFAULT_SETTINGS)
    row = db.execute("SELECT value FROM cs_meta WHERE key='notify_settings'").fetchone()
    if row and row[0]:
        try:
            saved = json.loads(row[0])
            for k, v in saved.items():
                if k in cfg and isinstance(cfg[k], dict) and isinstance(v, dict):
                    cfg[k].update({kk: vv for kk, vv in v.items() if kk in cfg[k]})
                elif k in cfg:
                    cfg[k] = v
        except ValueError:
            pass
    for (ch, key), name in SECRETS.items():   # ค่าใน .env / ตัวแปรระบบ มาก่อนค่าในฐานข้อมูล
        val = _env_secret(name)
        if val:
            cfg[ch][key] = val
            cfg[ch][f"{key}_from_env"] = True
    if not with_secrets:
        for (ch, key) in SECRETS:
            val = cfg[ch].get(key) or ""
            cfg[ch][f"{key}_set"] = bool(val)
            cfg[ch][key] = ("••••" + val[-4:]) if val else ""
    return cfg


def save_settings(db, data: dict, actor_id) -> dict:
    """data มาจากฟอร์ม — ช่องรหัสลับที่เว้นว่างแปลว่าใช้ค่าเดิม, clear_<ch>_<key>=1 แปลว่าลบ"""
    cur = get_settings(db)
    errors = []
    for ch in CHANNELS:
        d = data.get(ch) or {}
        c = cur[ch]
        c["enabled"] = bool(d.get("enabled"))
        for key in list(DEFAULT_SETTINGS[ch].keys()):
            if key == "enabled" or key not in d:
                continue
            val = d[key]
            if (ch, key) in SECRETS:
                if d.get(f"clear_{key}"):
                    c[key] = ""
                elif str(val).strip():
                    c[key] = str(val).strip()
                continue
            if key == "port":
                try:
                    c[key] = int(val)
                except (TypeError, ValueError):
                    errors.append("พอร์ต SMTP ต้องเป็นตัวเลข")
                continue
            c[key] = str(val).strip()[:500]
        if ch == "teams" and c.get("default_target") and not c["default_target"].startswith("https://"):
            errors.append("Teams Webhook URL ต้องขึ้นต้นด้วย https://")
        if ch == "email" and c.get("security") not in ("starttls", "ssl", "none"):
            c["security"] = "starttls"
    try:
        for sev in ("critical", "warning", "info"):
            v = float(data.get("sla_hours", {}).get(sev, cur["sla_hours"][sev]) or 0)
            if not 0 <= v <= 720:
                raise ValueError
            cur["sla_hours"][sev] = v
        v = int(data.get("round_due_before_min", cur["round_due_before_min"]) or 0)
        if not 0 <= v <= 720:
            raise ValueError
        cur["round_due_before_min"] = v
    except (TypeError, ValueError):
        errors.append("ค่าเวลาต้องเป็นตัวเลขในช่วงที่กำหนด (SLA 0–720 ชม., เตือนล่วงหน้า 0–720 นาที)")
    cur["round_overdue"] = bool(data.get("round_overdue"))
    cur["capa_remind"] = bool(data.get("capa_remind"))
    ds = data.get("daily_summary") or {}
    tm = str(ds.get("time") or "17:00")
    try:
        datetime.strptime(tm, "%H:%M")
    except ValueError:
        errors.append("เวลาสรุปประจำวันต้องเป็นรูปแบบ HH:MM")
        tm = "17:00"
    cur["daily_summary"] = {"enabled": bool(ds.get("enabled")), "time": tm}
    if "round_start" in data:
        rs = data.get("round_start") or {}
        cur["round_start"] = {"enabled": bool(rs.get("enabled")),
                              "freqs": [f for f in FREQ_LABEL if f and f in (rs.get("freqs") or [])],
                              "channels": [c for c in CHANNELS if c in (rs.get("channels") or [])],
                              "use_l1_groups": bool(rs.get("use_l1_groups"))}
        if cur["round_start"]["enabled"] and not cur["round_start"]["channels"]:
            errors.append("แจ้งเตือนถึงเวลาตรวจ: เลือกช่องทางอย่างน้อย 1 ช่องทาง")
    if "weekly_approval" in data:
        wa = data.get("weekly_approval") or {}
        tm = str(wa.get("time") or "08:30")
        try:
            datetime.strptime(tm, "%H:%M")
        except ValueError:
            errors.append("เวลาเตือนอนุมัติรายสัปดาห์ต้องเป็นรูปแบบ HH:MM")
            tm = "08:30"
        try:
            wd = int(wa.get("weekday", 0))
        except (TypeError, ValueError):
            wd = 0
        cur["weekly_approval"] = {"enabled": bool(wa.get("enabled")), "weekday": wd if 0 <= wd <= 6 else 0, "time": tm}
    if errors:
        raise S.ValidationError(errors)
    store = copy.deepcopy(cur)
    for (ch, key), name in SECRETS.items():
        store[ch].pop(f"{key}_from_env", None)
        if _env_secret(name):
            store[ch][key] = ""          # ค่าจาก .env ไม่เก็บลงฐานข้อมูล
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('notify_settings', ?)", (json.dumps(store),))
    S.audit(db, actor_id, "update", "notify_settings", None,
            after={ch: {"enabled": store[ch]["enabled"]} for ch in CHANNELS})
    return cur


def channel_ready(cfg: dict, ch: str) -> bool:
    c = cfg.get(ch) or {}
    if not c.get("enabled"):
        return False
    if ch == "telegram":
        return bool(c.get("bot_token"))
    if ch == "line":
        return bool(c.get("access_token"))
    if ch == "email":
        return bool(c.get("host") and c.get("sender"))
    return True


# ───────────────────────── senders ─────────────────────────

def _http_json(url: str, payload: dict, headers: dict | None = None, timeout: int = 12) -> str:
    if not re.match(r"^https?://", url or "", re.I):      # v0.99.1 รับเฉพาะ http/https (กัน file:// หรือ scheme แปลก ๆ จากค่าที่ตั้งผิด)
        raise SendError("URL ต้องขึ้นต้นด้วย http:// หรือ https://")
    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), method="POST",
                                 headers={"Content-Type": "application/json; charset=utf-8", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:   # noqa: S310 (URL มาจากผู้ดูแลระบบ)
            return resp.read(2000).decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        body = exc.read(500).decode("utf-8", "replace")
        raise SendError(f"HTTP {exc.code}: {body[:300]}") from None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise SendError(f"เชื่อมต่อไม่ได้: {getattr(exc, 'reason', exc)}") from None


def send_telegram(cfg: dict, target: str, subject: str, body: str, url: str) -> None:
    token = cfg["telegram"].get("bot_token")
    if not token:
        raise SendError("ยังไม่ได้ตั้ง Bot Token")
    text = (f"<b>{html.escape(subject)}</b>\n{html.escape(body)}" if subject else html.escape(body))
    if url:
        text += f'\n<a href="{html.escape(url, quote=True)}">เปิดในระบบ</a>'
    res = _http_json(f"https://api.telegram.org/bot{token}/sendMessage",
                     {"chat_id": target, "text": text[:4000], "parse_mode": "HTML", "disable_web_page_preview": True})
    if '"ok":true' not in res.replace(" ", ""):
        raise SendError(res[:300])


def send_line(cfg: dict, target: str, subject: str, body: str, url: str) -> None:
    token = cfg["line"].get("access_token")
    if not token:
        raise SendError("ยังไม่ได้ตั้ง Channel Access Token")
    text = "\n".join(x for x in (subject, body, url) if x)
    _http_json("https://api.line.me/v2/bot/message/push", {"to": target, "messages": [{"type": "text", "text": text[:4900]}]},
               {"Authorization": f"Bearer {token}"})


def send_teams(cfg: dict, target: str, subject: str, body: str, url: str) -> None:
    if not target.startswith("https://"):
        raise SendError("Webhook URL ไม่ถูกต้อง")
    if "webhook.office.com" in target:          # Incoming Webhook แบบเดิม (O365 Connector)
        text = f"**{subject}**\n\n{body}" + (f"\n\n[เปิดในระบบ]({url})" if url else "")
        _http_json(target, {"text": text})
        return
    card = {"$schema": "http://adaptivecards.io/schemas/adaptive-card.json", "type": "AdaptiveCard", "version": "1.4",
            "body": [{"type": "TextBlock", "text": subject, "weight": "Bolder", "size": "Medium", "wrap": True}]
            + [{"type": "TextBlock", "text": ln, "wrap": True, "spacing": "None"}          # 1 บรรทัด = 1 TextBlock (ขึ้นบรรทัดใหม่ชัวร์)
               for ln in (body or "").split("\n")[:40] if ln.strip()],
            "actions": [{"type": "Action.OpenUrl", "title": "เปิดในระบบ", "url": url}] if url else []}
    _http_json(target, {"type": "message", "attachments": [
        {"contentType": "application/vnd.microsoft.card.adaptive", "content": card}]})


def send_email(cfg: dict, target: str, subject: str, body: str, url: str,
               attachments: list[tuple[str, bytes, str]] | None = None) -> None:
    c = cfg["email"]
    if not c.get("host") or not c.get("sender"):
        raise SendError("ยังไม่ได้ตั้ง SMTP")
    msg = EmailMessage()
    msg["Subject"] = subject or "E-Checksheet"
    msg["From"] = c["sender"]
    msg["To"] = ", ".join(x.strip() for x in target.replace(";", ",").split(",") if x.strip())
    msg.set_content(body + (f"\n\nเปิดในระบบ: {url}" if url else ""))
    msg.add_alternative(
        f"<div style='font-family:Tahoma,sans-serif;font-size:14px'><h3 style='margin:0 0 8px'>{html.escape(subject)}</h3>"
        f"<p style='white-space:pre-line'>{html.escape(body)}</p>"
        + (f"<p><a href='{html.escape(url, quote=True)}'>เปิดในระบบ</a></p>" if url else "") + "</div>", subtype="html")
    for fname, data, mime in attachments or []:
        maintype, _, subtype = mime.partition("/")
        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=fname)
    port = int(c.get("port") or 587)
    try:
        if c.get("security") == "ssl":
            server = smtplib.SMTP_SSL(c["host"], port, timeout=15, context=ssl.create_default_context())
        else:
            server = smtplib.SMTP(c["host"], port, timeout=15)
            if c.get("security") == "starttls":
                server.starttls(context=ssl.create_default_context())
        with server:
            if c.get("username"):
                server.login(c["username"], c.get("password") or "")
            server.send_message(msg)
    except (smtplib.SMTPException, OSError) as exc:
        raise SendError(f"SMTP: {exc}") from None


SENDERS: dict[str, Callable[[dict, str, str, str, str], None]] = {
    "telegram": send_telegram, "line": send_line, "teams": send_teams, "email": send_email}


# ───────────────────────── queue ─────────────────────────

def enqueue(db, cfg: dict, channel: str, target: str, subject: str, body: str, url: str = "", *,
            alert_id: int | None = None, ref_key: str = "", label: str = "", now: datetime | None = None) -> int | None:
    target = (target or "").strip()
    if channel not in CHANNELS or not target or not channel_ready(cfg, channel):
        return None
    if ref_key and db.execute("""SELECT 1 FROM cs_msg_outbox WHERE channel=? AND target=? AND ref_key=?""",
                              (channel, target, ref_key)).fetchone():
        return None
    now_s = ts(now or S.now_dt())
    return db.execute("""INSERT INTO cs_msg_outbox(channel, target, target_label, subject, body, url, alert_id, ref_key,
                         status, attempts, next_try_at, created_at) VALUES (?,?,?,?,?,?,?,?, 'pending', 0, ?, ?)""",
                      (channel, target, label[:120], subject[:200], body[:4000], url[:500], alert_id, ref_key[:120],
                       now_s, now_s)).lastrowid


def notify_user_app(db, user_id: int, kind: str, title: str, body: str = "", url: str = "", severity: str = "info",
                    ref_key: str = "", now: datetime | None = None) -> bool:
    if ref_key and db.execute("SELECT 1 FROM cs_notifications WHERE user_id=? AND ref_key=?", (user_id, ref_key)).fetchone():
        return False
    db.execute("""INSERT INTO cs_notifications(user_id, kind, severity, title, body, url, ref_key, created_at)
                  VALUES (?,?,?,?,?,?,?,?)""", (user_id, kind, severity, title[:200], body[:1000], url[:300], ref_key[:120],
                                               ts(now or S.now_dt())))
    return True


def process_outbox(db_or_path, now: datetime | None = None, limit: int = 30) -> dict:
    """ส่งข้อความที่ถึงเวลา — รับ path (งานเบื้องหลัง) หรือ connection (ทดสอบ)"""
    import sqlite3
    own = isinstance(db_or_path, str)
    db = sqlite3.connect(db_or_path, timeout=15) if own else db_or_path
    if own:
        db.row_factory = sqlite3.Row
    out = {"sent": 0, "failed": 0, "retry": 0}
    try:
        now = now or S.now_dt()
        cfg = get_settings(db)
        rows = db.execute("""SELECT * FROM cs_msg_outbox WHERE status='pending' AND next_try_at<=? ORDER BY id LIMIT ?""",
                          (ts(now), limit)).fetchall()
        db.commit()
        for r in rows:
            try:
                if not channel_ready(cfg, r["channel"]):
                    raise SendError("ช่องทางนี้ถูกปิดหรือยังตั้งค่าไม่ครบ")
                SENDERS[r["channel"]](cfg, r["target"], r["subject"], r["body"], r["url"])
                db.execute("UPDATE cs_msg_outbox SET status='sent', attempts=attempts+1, sent_at=?, last_error='' WHERE id=?",
                           (ts(S.now_dt()), r["id"]))
                out["sent"] += 1
            except Exception as exc:  # noqa: BLE001 — ข้อผิดพลาดทุกแบบต้องบันทึกแล้วลองใหม่
                err = str(exc)
                for (ch, key) in SECRETS:     # ไม่เก็บ token ลง log
                    secret = cfg.get(ch, {}).get(key)
                    if secret:
                        err = err.replace(secret, "***")
                attempts = r["attempts"] + 1
                if attempts >= MAX_ATTEMPTS:
                    db.execute("UPDATE cs_msg_outbox SET status='failed', attempts=?, last_error=? WHERE id=?",
                               (attempts, err[:500], r["id"]))
                    out["failed"] += 1
                else:
                    nxt = now + timedelta(minutes=RETRY_MIN[attempts - 1])
                    db.execute("UPDATE cs_msg_outbox SET attempts=?, last_error=?, next_try_at=? WHERE id=?",
                               (attempts, err[:500], ts(nxt), r["id"]))
                    out["retry"] += 1
            db.commit()
        return out
    finally:
        if own:
            db.close()


def retry_message(db, msg_id: int) -> None:
    db.execute("UPDATE cs_msg_outbox SET status='pending', attempts=0, next_try_at=?, last_error='' WHERE id=?",
               (ts(S.now_dt()), msg_id))


def send_test(db, channel: str, target: str) -> None:
    """ส่งทันที (ไม่ผ่านคิว) เพื่อให้ผู้ดูแลเห็นผลเลย"""
    cfg = get_settings(db)
    if channel not in CHANNELS:
        raise SendError("ช่องทางไม่ถูกต้อง")
    if not cfg[channel].get("enabled"):
        raise SendError("กรุณาเปิดใช้งานช่องทางนี้และบันทึกก่อนทดสอบ")
    target = (target or cfg[channel].get("default_target") or "").strip()
    if not target:
        raise SendError("กรุณาระบุผู้รับ")
    SENDERS[channel](cfg, target, "ทดสอบการแจ้งเตือน E-Checksheet",
                     f"ข้อความทดสอบ {datetime.now():%d/%m/%Y %H:%M} — ถ้าเห็นข้อความนี้แปลว่าตั้งค่าถูกต้อง", "")


# ───────────────────────── escalation config ─────────────────────────

def get_levels(db, factory_id: int | None) -> list[dict]:
    """ระดับของโรงงานนั้น ถ้าโรงงานไม่ได้ตั้งเอง ใช้ค่ารวม (factory_id ว่าง)"""
    rows = []
    if factory_id:
        rows = db.execute("SELECT * FROM cs_esc_levels WHERE factory_id=? ORDER BY level", (factory_id,)).fetchall()
    if not rows:
        rows = db.execute("SELECT * FROM cs_esc_levels WHERE factory_id IS NULL ORDER BY level").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["recipients"] = [dict(x) for x in db.execute(
            """SELECT r.*, u.name AS user_name FROM cs_esc_recipients r LEFT JOIN users u ON u.id=r.user_id
               WHERE r.level_id=? ORDER BY r.id""", (r["id"],))]
        out.append(d)
    return out


def save_levels(db, factory_id: int | None, levels: list[dict], actor_id) -> None:
    """levels = [{level, after_min, min_severity, active, recipients:[{kind,user_id,role,channel,target,label}]}]"""
    errors = []
    prev_after = -1
    for lv in sorted(levels, key=lambda x: int(x.get("level") or 0)):
        try:
            n, after = int(lv["level"]), int(lv.get("after_min") or 0)
        except (TypeError, ValueError, KeyError):
            errors.append("ข้อมูลระดับไม่ถูกต้อง")
            continue
        if not 1 <= n <= 3 or not 0 <= after <= 10080:
            errors.append(f"L{n}: เวลาต้องอยู่ระหว่าง 0–10080 นาที")
        if lv.get("active") and after <= prev_after and n > 1:
            errors.append(f"L{n}: เวลาต้องมากกว่าระดับก่อนหน้า")
        if lv.get("active"):
            prev_after = after
        if lv.get("min_severity") not in SEV_RANK:
            lv["min_severity"] = "warning"
        for r in lv.get("recipients") or []:
            if r.get("kind") == "group":
                if r.get("channel") not in CHANNELS or not (r.get("target") or "").strip():
                    errors.append(f"L{n}: กลุ่มแชทต้องระบุช่องทางและปลายทาง")
                elif r["channel"] == "teams" and r["target"] != "default" and not r["target"].startswith("https://"):
                    errors.append(f"L{n}: Teams ต้องเป็น Webhook URL (https://…)")
            elif r.get("kind") == "user":
                if not db.execute("SELECT 1 FROM users WHERE id=?", (r.get("user_id"),)).fetchone():
                    errors.append(f"L{n}: ไม่พบผู้ใช้")
            elif r.get("kind") == "role":
                if r.get("role") not in ("admin", "supervisor", "technician", "viewer"):
                    errors.append(f"L{n}: บทบาทไม่ถูกต้อง")
            else:
                errors.append(f"L{n}: ชนิดผู้รับไม่ถูกต้อง")
    if errors:
        raise S.ValidationError(sorted(set(errors)))
    cond, params = ("factory_id=?", [factory_id]) if factory_id else ("factory_id IS NULL", [])
    old = [r[0] for r in db.execute(f"SELECT id FROM cs_esc_levels WHERE {cond}", params)]
    for lid in old:
        db.execute("DELETE FROM cs_esc_recipients WHERE level_id=?", (lid,))
    db.execute(f"DELETE FROM cs_esc_levels WHERE {cond}", params)
    for lv in levels:
        lid = db.execute("INSERT INTO cs_esc_levels(factory_id, level, after_min, min_severity, active) VALUES (?,?,?,?,?)",
                         (factory_id, int(lv["level"]), int(lv.get("after_min") or 0), lv["min_severity"],
                          1 if lv.get("active") else 0)).lastrowid
        for r in lv.get("recipients") or []:
            db.execute("""INSERT INTO cs_esc_recipients(level_id, kind, user_id, role, channel, target, label)
                          VALUES (?,?,?,?,?,?,?)""",
                       (lid, r["kind"], r.get("user_id") if r["kind"] == "user" else None,
                        r.get("role", "") if r["kind"] == "role" else "", r.get("channel", "") if r["kind"] == "group" else "",
                        (r.get("target") or "").strip()[:500] if r["kind"] == "group" else "", (r.get("label") or "")[:80]))
    S.audit(db, actor_id, "update", "escalation", factory_id, after=levels)


def reset_factory_levels(db, factory_id: int, actor_id) -> None:
    """ให้โรงงานกลับไปใช้ค่ารวม"""
    for lid in [r[0] for r in db.execute("SELECT id FROM cs_esc_levels WHERE factory_id=?", (factory_id,))]:
        db.execute("DELETE FROM cs_esc_recipients WHERE level_id=?", (lid,))
    db.execute("DELETE FROM cs_esc_levels WHERE factory_id=?", (factory_id,))
    S.audit(db, actor_id, "reset", "escalation", factory_id)


def _user_targets(u: dict, cfg: dict) -> list[tuple[str, str]]:
    allowed = set((u.get("notify_channels") or "app,telegram,line,email").split(","))
    out = []
    if "telegram" in allowed and u.get("telegram_chat_id"):
        out.append(("telegram", u["telegram_chat_id"]))
    if "line" in allowed and u.get("line_user_id"):
        out.append(("line", u["line_user_id"]))
    if "email" in allowed and u.get("email"):
        out.append(("email", u["email"]))
    return [(ch, t) for ch, t in out if channel_ready(cfg, ch)]


def level_recipients(db, level: dict, factory_id: int | None, cfg: dict) -> dict:
    """→ {"users": [user dict], "groups": [(channel, target, label)]}"""
    users: dict[int, dict] = {}
    groups = []
    for r in level["recipients"]:
        if r["kind"] == "user" and r["user_id"]:
            u = db.execute("SELECT * FROM users WHERE id=? AND active=1", (r["user_id"],)).fetchone()
            if u:
                users[u["id"]] = dict(u)
        elif r["kind"] == "role":
            from . import roster as RO
            if r["role"] in RO.TEAM_ROLES:            # v0.51 ตามโรงงานที่มอบหมาย + ช่างที่อยู่ในกะตอนนี้
                now = S.now_dt()
                ids = [p["id"] for p in RO.responsible(db, factory_id, now, now + timedelta(minutes=1), r["role"])]
                rows = db.execute(f"SELECT * FROM users WHERE active=1 AND id IN ({','.join('?' * len(ids))})", ids) if ids else []
            else:
                q = "SELECT * FROM users WHERE active=1 AND role=?"
                params: list[Any] = [r["role"]]
                if factory_id:
                    q += " AND (factory_id IS NULL OR factory_id=?)"
                    params.append(factory_id)
                rows = db.execute(q, params)
            for u in rows:
                users[u["id"]] = dict(u)
        elif r["kind"] == "group":
            target = cfg.get(r["channel"], {}).get("default_target", "") if r["target"] == "default" else r["target"]
            if target:
                groups.append((r["channel"], target, r["label"] or CHANNEL_TH.get(r["channel"], r["channel"])))
    return {"users": list(users.values()), "groups": groups}


# ───────────────────────── ช่วงเงียบ ─────────────────────────

def active_silence(db, factory_id, equipment_id, form_id, now: datetime | None = None) -> dict | None:
    now_s = ts(now or S.now_dt())
    row = db.execute("""SELECT * FROM cs_silences WHERE cancelled_at IS NULL AND starts_at<=? AND ends_at>?
                        AND (factory_id IS NULL OR factory_id=?) AND (equipment_id IS NULL OR equipment_id=?)
                        AND (form_id IS NULL OR form_id=?) ORDER BY ends_at DESC LIMIT 1""",
                     (now_s, now_s, factory_id, equipment_id, form_id)).fetchone()
    return dict(row) if row else None


def list_silences(db, include_past: bool = False) -> list[dict]:
    cond = "" if include_past else "WHERE s.cancelled_at IS NULL AND s.ends_at > ?"
    params = [] if include_past else [ts(S.now_dt())]
    return [dict(r) for r in db.execute(f"""
        SELECT s.*, fa.name AS factory_name, e.code AS eq_code, f.name AS form_name, u.name AS created_name
        FROM cs_silences s LEFT JOIN factories fa ON fa.id=s.factory_id LEFT JOIN equipment e ON e.id=s.equipment_id
        LEFT JOIN cs_forms f ON f.id=s.form_id LEFT JOIN users u ON u.id=s.created_by
        {cond} ORDER BY s.starts_at DESC LIMIT 200""", params)]


def save_silence(db, data: dict, actor_id) -> int:
    def _int(v):
        try:
            return int(v or 0) or None
        except (TypeError, ValueError):
            return None
    fid, eid, form_id = _int(data.get("factory_id")), _int(data.get("equipment_id")), _int(data.get("form_id"))
    start, end = parse_ts(str(data.get("starts_at") or "").replace("T", " ")), parse_ts(str(data.get("ends_at") or "").replace("T", " "))
    reason = str(data.get("reason") or "").strip()
    errors = []
    if not (fid or eid or form_id):
        errors.append("ต้องเลือกอย่างน้อย 1 อย่าง: โรงงาน เครื่องจักร หรือแบบฟอร์ม")
    if not start or not end:
        errors.append("กรุณาระบุเวลาเริ่มและสิ้นสุด")
    elif end <= start:
        errors.append("เวลาสิ้นสุดต้องหลังเวลาเริ่ม")
    elif end - start > timedelta(days=31):
        errors.append("ช่วงเงียบยาวได้ไม่เกิน 31 วัน")
    if not reason:
        errors.append("กรุณาระบุเหตุผล เช่น ซ่อมบำรุงประจำปี")
    if eid and not fid:
        row = db.execute("SELECT factory_id FROM equipment WHERE id=?", (eid,)).fetchone()
        fid = row["factory_id"] if row else None
    if errors:
        raise S.ValidationError(errors)
    sid = db.execute("""INSERT INTO cs_silences(factory_id, equipment_id, form_id, starts_at, ends_at, reason, created_by, created_at)
                        VALUES (?,?,?,?,?,?,?,?)""", (fid, eid, form_id, ts(start), ts(end), reason[:300], actor_id,
                                                      ts(S.now_dt()))).lastrowid
    S.audit(db, actor_id, "create", "cs_silences", sid, after={"from": ts(start), "to": ts(end), "reason": reason})
    return sid


def cancel_silence(db, sid: int, actor_id) -> None:
    db.execute("UPDATE cs_silences SET cancelled_at=? WHERE id=? AND cancelled_at IS NULL", (ts(S.now_dt()), sid))
    S.audit(db, actor_id, "cancel", "cs_silences", sid)


# ───────────────────────── escalation engine ─────────────────────────

def _link(base_url: str, path: str) -> str:
    return f"{base_url.rstrip('/')}{path}" if base_url else ""


def _minutes(a: datetime, b: datetime) -> float:
    return (a - b).total_seconds() / 60.0


def _alert_message(a: dict, level: int, reason: str) -> tuple[str, str]:
    sev = a["severity"]
    subject = f"{SEV_ICON.get(sev, '')} [{SEV_TH.get(sev, sev)}] {a['title']}"
    lines = [a["detail"] or "", f"ประเภท: {TYPE_TH.get(a['alert_type'], a['alert_type'])}"]
    if a.get("factory_name"):
        lines.append(f"โรงงาน: {a['factory_name']}")
    lines.append(f"เกิดเมื่อ: {parse_ts(a['created_at']).strftime('%d/%m/%Y %H:%M')}"
                 + (f" · เกิดซ้ำ {a['occurrences']} ครั้ง" if a["occurrences"] > 1 else ""))
    lines.append(f"ระดับแจ้งเตือน: L{level}" + (f" — {reason}" if reason else ""))
    return subject, "\n".join(x for x in lines if x)


def _deliver(db, cfg: dict, base_url: str, recips: dict, *, kind: str, subject: str, body: str, path: str,
             severity: str, ref_key: str, alert_id: int | None = None, now: datetime | None = None) -> dict:
    url = _link(base_url, path)
    n_app = n_ext = 0
    for u in recips["users"]:
        n_app += notify_user_app(db, u["id"], kind, subject, body, path, severity, ref_key, now)   # กระดิ่งในระบบเสมอ
        for ch, target in _user_targets(u, cfg):
            n_ext += bool(enqueue(db, cfg, ch, target, subject, body, url, alert_id=alert_id, ref_key=ref_key,
                                  label=u["name"], now=now))
    for ch, target, label in recips["groups"]:
        n_ext += bool(enqueue(db, cfg, ch, target, subject, body, url, alert_id=alert_id, ref_key=ref_key,
                              label=label, now=now))
    return {"app": n_app, "ext": n_ext, "names": [u["name"] for u in recips["users"]] + [g[2] for g in recips["groups"]]}


def escalate(db, now: datetime | None = None, base_url: str = "") -> dict:
    """ส่งแจ้งเตือนตามระดับ: L1 ทันทีที่เกิด แล้วส่งต่อ L2/L3 เมื่อยังไม่มีผู้รับทราบตามเวลาที่ตั้ง
    รับทราบแล้วแต่ยังไม่แก้ไขเกิน SLA → เตือนระดับถัดไป"""
    now = now or S.now_dt()
    now_s = ts(now)
    cfg = get_settings(db)
    stats = {"notified": 0, "escalated": 0, "sla": 0, "silenced": 0}
    alerts = db.execute(f"""
        SELECT a.*, f.factory_id, fa.name AS factory_name FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        WHERE a.status IN ({','.join('?' * len(OPEN_STATUSES))})""", OPEN_STATUSES).fetchall()
    for row in alerts:
        a = dict(row)
        sil = active_silence(db, a["factory_id"], a["equipment_id"], a["form_id"], now)
        if sil:
            if not db.execute("SELECT 1 FROM cs_alert_events WHERE alert_id=? AND event='silenced' AND detail LIKE ?",
                              (a["id"], f"#{sil['id']} %")).fetchone():
                db.execute("INSERT INTO cs_alert_events(alert_id, event, detail, created_at) VALUES (?,?,?,?)",
                           (a["id"], "silenced", f"#{sil['id']} {sil['reason']} (ถึง {parse_ts(sil['ends_at']):%d/%m %H:%M})", now_s))
            stats["silenced"] += 1
            continue
        levels = [lv for lv in get_levels(db, a["factory_id"]) if lv["active"]]
        created = parse_ts(a["created_at"])
        age = _minutes(now, created)
        if a["status"] == "open":
            due = [lv for lv in levels if lv["level"] > a["notified_level"] and lv["after_min"] <= age
                   and SEV_RANK[a["severity"]] >= SEV_RANK[lv["min_severity"]]
                   and (a["alert_type"] != "approval" or lv["level"] == 1)]      # รออนุมัติ: แจ้ง L1 เท่านั้น ไม่ส่งต่อ
            if not due:
                continue
            for lv in due:
                recips = level_recipients(db, lv, a["factory_id"], cfg)
                reason = "" if lv["level"] == 1 else f"ยังไม่มีผู้รับทราบภายใน {lv['after_min']} นาที"
                subject, body = _alert_message(a, lv["level"], reason)
                res = _deliver(db, cfg, base_url, recips, kind="alert" if lv["level"] == 1 else "escalate", subject=subject,
                               body=body, path=f"/alerts/{a['id']}", severity=a["severity"],
                               ref_key=f"alert:{a['id']}:L{lv['level']}:{a['severity']}", alert_id=a["id"], now=now)
                ev = "notify" if lv["level"] == 1 else "escalate"
                who = ", ".join(res["names"]) or "ยังไม่ได้กำหนดผู้รับ"
                db.execute("INSERT INTO cs_alert_events(alert_id, event, channel, detail, created_at) VALUES (?,?,?,?,?)",
                           (a["id"], ev, f"L{lv['level']}", f"L{lv['level']} → {who} (ในระบบ {res['app']}, ภายนอก {res['ext']})"[:500], now_s))
                stats["notified" if lv["level"] == 1 else "escalated"] += 1
            top = max(lv["level"] for lv in due)
            db.execute("UPDATE cs_alerts SET notified_level=?, level=?, last_notified_at=? WHERE id=?",
                       (top, max(top, 1), now_s, a["id"]))
        else:
            hours = 0.0 if a["alert_type"] == "approval" else float(cfg["sla_hours"].get(a["severity"]) or 0)
            if hours <= 0 or age < hours * 60:
                continue
            last = parse_ts(a["sla_notified_at"]) if a["sla_notified_at"] else None
            if last and _minutes(now, last) < hours * 60:
                continue
            ups = [lv for lv in levels if lv["level"] > max(a["notified_level"], 1)] or levels[-1:]
            if not ups:
                continue
            lv = ups[0]
            recips = level_recipients(db, lv, a["factory_id"], cfg)
            from . import terms as _TR
            status_th = _TR.label("ALERT", a["status"])
            subject, body = _alert_message(a, lv["level"], f"{status_th} แต่ยังไม่แก้ไขเกิน {hours:g} ชั่วโมง")
            subject = "⏰ ยังไม่แก้ไข: " + a["title"]
            res = _deliver(db, cfg, base_url, recips, kind="escalate", subject=subject, body=body,
                           path=f"/alerts/{a['id']}", severity=a["severity"],
                           ref_key=f"sla:{a['id']}:{now:%Y%m%d%H}", alert_id=a["id"], now=now)
            db.execute("INSERT INTO cs_alert_events(alert_id, event, channel, detail, created_at) VALUES (?,?,?,?,?)",
                       (a["id"], "sla", f"L{lv['level']}",
                        f"เกิน {hours:g} ชม. → L{lv['level']} {', '.join(res['names']) or 'ยังไม่ได้กำหนดผู้รับ'}"[:500], now_s))
            db.execute("UPDATE cs_alerts SET sla_notified_at=?, level=MAX(level, ?), notified_level=MAX(notified_level, ?) WHERE id=?",
                       (now_s, lv["level"], lv["level"], a["id"]))
            stats["sla"] += 1
    return stats


# ───────────────────────── เตือนรอบตรวจ ─────────────────────────

def _round_assignees(db, sched: dict, factory_id, a: datetime | None = None, b: datetime | None = None,
                     R: dict | None = None, members: list[dict] | None = None) -> list[dict]:
    """ผู้รับแจ้งเตือนของรอบ — v0.51 ตามโรงงานที่มอบหมาย + ตารางกะ (คนลาหยุด/นอกกะไม่ได้รับ)"""
    if sched.get("assignee_user_id"):
        u = db.execute("SELECT * FROM users WHERE id=? AND active=1", (sched["assignee_user_id"],)).fetchone()
        return [dict(u)] if u else []
    role = sched.get("assignee_role") or "technician"
    from . import roster as RO
    if role in RO.TEAM_ROLES:
        a = a or S.now_dt()
        ids = [p["id"] for p in RO.responsible(db, factory_id, a, b or a + timedelta(minutes=1), role, R, members)]
        if not ids:
            return []
        return [dict(u) for u in db.execute(f"SELECT * FROM users WHERE active=1 AND id IN ({','.join('?' * len(ids))})", ids)]
    q, params = "SELECT * FROM users WHERE active=1 AND role=?", [role]
    if factory_id:
        q += " AND (factory_id IS NULL OR factory_id=?)"
        params.append(factory_id)
    return [dict(u) for u in db.execute(q, params)]


def round_reminders(db, now: datetime | None = None, base_url: str = "") -> dict:
    """ใกล้ครบกำหนด (ก่อน N นาที) และเลยกำหนด → แจ้งผู้รับผิดชอบรอบนั้น (รวมเป็นข้อความเดียวต่อคน)"""
    now = now or S.now_dt()
    now_s = ts(now)
    cfg = get_settings(db)
    before = int(cfg.get("round_due_before_min") or 0)
    out = {"due": 0, "overdue": 0}
    groups: dict[tuple[str, int], list[str]] = {}
    users: dict[int, dict] = {}
    from . import roster as RO
    members = RO.team(db)
    R = RO.load(db, now.date() - timedelta(days=2), now.date() + timedelta(days=2))

    def collect(kind: str, rows, col: str):
        for r in rows:
            db.execute(f"UPDATE cs_rounds SET {col}=? WHERE id=?", (now_s, r["id"]))
            if active_silence(db, r["factory_id"], r["equipment_id"], r["form_id"], now):
                continue
            sched = db.execute("SELECT * FROM cs_schedules WHERE id=?", (r["schedule_id"],)).fetchone()
            label = f"{r['eq_code'] or r['form_name']} (ต้องเสร็จ {parse_ts(r['deadline_at']):%H:%M})"
            dl, cl = parse_ts(r["deadline_at"]), parse_ts(r["close_at"])
            b = dl if dl and dl > now else (cl or now + timedelta(hours=1))      # เวลาที่เหลือของรอบ → คนที่อยู่กะช่วงนั้น
            for u in _round_assignees(db, dict(sched) if sched else {}, r["factory_id"], now, b, R, members):
                users[u["id"]] = u
                groups.setdefault((kind, u["id"]), []).append(label)
            out[kind] += 1

    base_q = """SELECT r.*, f.name AS form_name, f.factory_id, f.equipment_id, e.code AS eq_code
                FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
                JOIN cs_schedules sx ON sx.id=r.schedule_id AND sx.active=1
                WHERE r.submission_id IS NULL AND f.active=1 AND COALESCE(e.run_status,'running')<>'down' AND {cond}"""
    if before > 0:
        collect("due", db.execute(base_q.format(cond="""r.status IN ('pending','in_progress') AND r.due_notified_at IS NULL
                AND r.due_at<=? AND r.deadline_at>? AND r.deadline_at<=?"""),
                                  (now_s, now_s, ts(now + timedelta(minutes=before)))).fetchall(), "due_notified_at")
    if cfg.get("round_overdue"):
        collect("overdue", db.execute(base_q.format(cond="""r.status='overdue' AND r.overdue_notified_at IS NULL
                AND r.close_at>?"""), (now_s,)).fetchall(), "overdue_notified_at")
    for (kind, uid), labels in groups.items():
        u = users[uid]
        title = (f"⏳ ใกล้ครบกำหนดตรวจ {len(labels)} รอบ" if kind == "due" else f"⚠️ เลยกำหนดตรวจ {len(labels)} รอบ")
        body = "\n".join("• " + x for x in labels[:15]) + (f"\nและอีก {len(labels) - 15} รอบ" if len(labels) > 15 else "")
        _deliver(db, cfg, base_url, {"users": [u], "groups": []}, kind=f"round_{kind}", subject=title, body=body,
                 path="/m/", severity="warning" if kind == "overdue" else "info",
                 ref_key=f"round_{kind}:{uid}:{now:%Y%m%d%H%M}", now=now)
    return out


def round_start_targets(db, cfg: dict, factory_id) -> list[tuple[str, str, str]]:
    """ปลายทางกลุ่มของแจ้งเตือนถึงเวลาตรวจ: กลุ่มแชทใน L1 ของโรงงาน (ถ้าตั้งไว้) ไม่งั้นกลุ่มหลักของช่องทาง"""
    rs = cfg["round_start"]
    out: list[tuple[str, str, str]] = []
    l1 = []
    if rs.get("use_l1_groups"):
        lv = next((x for x in get_levels(db, factory_id) if x["level"] == 1 and x["active"]), None)
        if lv:
            l1 = level_recipients(db, lv, factory_id, cfg)["groups"]
    for ch in rs.get("channels") or []:
        if not channel_ready(cfg, ch):
            continue
        mine = [g for g in l1 if g[0] == ch]
        if mine:
            out += mine
        elif cfg[ch].get("default_target"):
            out.append((ch, cfg[ch]["default_target"], "กลุ่มหลัก"))
    return list(dict.fromkeys(out))


def _freq_group(ft: str) -> str:
    """ความถี่ของรอบ → กลุ่มในแจ้งเตือนถึงเวลาตรวจ (v0.38: ทุก N วัน/สัปดาห์/เดือน นับเป็นประจำวัน/สัปดาห์/เดือน)"""
    ft = ft or ""
    if ft in FREQ_LABEL:
        return ft
    return {"d": "daily", "w": "weekly", "m": "monthly"}.get(ft.split(":")[0], "") if ":" in ft else ""


def round_start_reminders(db, now: datetime | None = None, base_url: str = "", catch_up_min: int = 60) -> dict:
    """ถึงเวลาเริ่มตรวจ → ส่งเข้ากลุ่ม 1 ข้อความต่อ (โรงงาน × ความถี่) เช่น 📅 ถึงเวลาตรวจประจำวัน — Factory 1 (5 รายการ)"""
    now = now or S.now_dt()
    now_s = ts(now)
    cfg = get_settings(db)
    rs = cfg["round_start"]
    if not rs.get("enabled"):
        return {"started": 0}
    rows = db.execute("""
        SELECT r.*, f.name AS form_name, f.factory_id, f.equipment_id, e.code AS eq_code, fa.name AS factory_name,
               COALESCE(sc.freq_type, '') AS freq_type, u.name AS assignee_name
        FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id JOIN cs_schedules sc ON sc.id=r.schedule_id AND sc.active=1
        LEFT JOIN users u ON u.id=sc.assignee_user_id
        WHERE r.start_notified_at IS NULL AND r.submission_id IS NULL AND r.status IN ('pending','in_progress')
          AND f.active=1 AND COALESCE(f.is_template,0)=0
          AND r.due_at<=? AND r.due_at>=? AND r.deadline_at>?
        ORDER BY f.factory_id, r.due_at""", (now_s, ts(now - timedelta(minutes=catch_up_min)), now_s)).fetchall()
    groups: dict[tuple, list[dict]] = {}
    for r in rows:
        db.execute("UPDATE cs_rounds SET start_notified_at=? WHERE id=?", (now_s, r["id"]))
        freq = _freq_group(r["freq_type"])
        if freq and freq not in rs["freqs"]:
            continue
        if active_silence(db, r["factory_id"], r["equipment_id"], r["form_id"], now):
            continue
        groups.setdefault((r["factory_id"], r["factory_name"] or "", freq), []).append(dict(r))
    sent = 0
    for (fac, fac_name, freq), items in groups.items():
        icon, label = FREQ_LABEL[freq]
        subject = f"{icon} ถึงเวลาตรวจ{label}" + (f" — {fac_name}" if fac_name else "") + f" ({len(items)} รายการ)"
        lines = []
        for it in items[:25]:
            dl = parse_ts(it["deadline_at"])
            when = dl.strftime("%H:%M") if dl.date() == now.date() else dl.strftime("%d/%m %H:%M")
            code = it["eq_code"] if it["eq_code"] and it["eq_code"] not in it["form_name"] else ""
            lines.append(f"• {code + ' · ' if code else ''}{it['form_name']} — ภายใน {when}"
                         + (f" ({it['assignee_name']})" if it["assignee_name"] else ""))
        if len(items) > 25:
            lines.append(f"… และอีก {len(items) - 25} รายการ")
        lines.append(f"ประเภท: ตรวจ{label} · เริ่ม {parse_ts(items[0]['due_at']):%d/%m/%Y %H:%M}")
        try:                                                   # v0.51 ผู้รับผิดชอบตามตารางกะ
            from . import roster as RO
            dl0 = max(parse_ts(x["deadline_at"]) for x in items)
            who = RO.responsible(db, fac, now, dl0, "technician")
            if who and len(who) <= 8:
                lines.append("👷 ผู้รับผิดชอบกะนี้: " + ", ".join(p["name"] for p in who))
        except Exception:                                      # noqa: BLE001
            pass
        for ch, target, lbl in round_start_targets(db, cfg, fac):
            sent += bool(enqueue(db, cfg, ch, target, subject, "\n".join(lines), _link(base_url, "/m/"),
                                 ref_key=f"round_start:{fac}:{freq}:{now:%Y%m%d%H%M}", label=lbl, now=now))
    return {"started": sum(len(v) for v in groups.values()), "start_msgs": sent}


# ───────────────────────── v0.38 เตือนผู้อนุมัติ รายสัปดาห์ ─────────────────────────

def approvers(db) -> list[dict]:
    """ผู้มีสิทธิ์อนุมัติ: หัวหน้างาน · ผู้ที่ได้รับสิทธิ์อนุมัติ · ตำแหน่ง Sr.Tech / FM / SV / SSV / DM (ไม่รวมผู้ดูแลระบบ)"""
    from .submissions import APPROVER_POSITIONS
    ph = ",".join("?" * len(APPROVER_POSITIONS))
    return [dict(u) for u in db.execute(
        f"""SELECT * FROM users WHERE active=1 AND role<>'admin'
            AND (role='supervisor' OR COALESCE(can_approve,0)=1 OR COALESCE(position,'') IN ({ph})) ORDER BY name""",
        APPROVER_POSITIONS)]


def weekly_approval_text(db, factory_id, before: datetime) -> tuple[int, int, int, list[str]]:
    """ผลตรวจที่ยังไม่อนุมัติ (ส่งก่อน before) → (จำนวนผลตรวจ, NG, จำนวนแบบฟอร์ม×สัปดาห์, บรรทัดรายการ)"""
    rows = db.execute("""SELECT s.form_id, s.finished_at, s.ng_count, f.name, f.code, e.code AS eq_code
                         FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
                         WHERE s.status='submitted' AND s.approval_status='pending' AND s.finished_at < ?
                           AND (? IS NULL OR f.factory_id IS NULL OR f.factory_id=?)
                         ORDER BY f.code, s.finished_at""", (ts(before), factory_id, factory_id)).fetchall()
    groups: dict = {}
    for r in rows:
        d = parse_ts(r["finished_at"])
        wk = (d - timedelta(days=d.weekday())).date()
        g = groups.setdefault((r["form_id"], wk), {"label": r["eq_code"] or r["code"] or r["name"], "wk": wk, "n": 0, "ng": 0})
        g["n"] += 1
        g["ng"] += 1 if r["ng_count"] else 0
    lines = [f"• {g['label']} สัปดาห์ {g['wk']:%d/%m} — {g['n']} ผลตรวจ" + (f" (NG {g['ng']})" if g["ng"] else "")
             for g in sorted(groups.values(), key=lambda x: (x["wk"], x["label"]))]
    return len(rows), sum(1 for r in rows if r["ng_count"]), len(groups), lines


def weekly_approval_reminders(db, now: datetime | None = None, base_url: str = "", force: bool = False) -> dict:
    """ทุกสัปดาห์ (วัน/เวลาที่ตั้ง) → เตือนผู้อนุมัติแต่ละคน ถ้ามีผลตรวจของสัปดาห์ก่อน ๆ ที่ยังไม่อนุมัติ (กระดิ่ง + ช่องทางส่วนตัว)"""
    now = now or S.now_dt()
    cfg = get_settings(db)
    wa = cfg.get("weekly_approval") or {}
    if not wa.get("enabled") and not force:
        return {"wk_appr": 0}
    hh, mm = (int(x) for x in str(wa.get("time") or "08:30").split(":"))
    if not force and (now.weekday() != int(wa.get("weekday", 0)) or (now.hour, now.minute) < (hh, mm)):
        return {"wk_appr": 0}
    week0 = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    key = f"wkappr:{week0:%Y-%m-%d}"
    if not force and db.execute("SELECT 1 FROM cs_meta WHERE key='wkappr_sent' AND value=?", (key,)).fetchone():
        return {"wk_appr": 0}
    sent = 0
    cache: dict = {}
    for u in approvers(db):
        fac = u.get("factory_id")
        if fac not in cache:
            cache[fac] = weekly_approval_text(db, fac, week0)
        n, ng, n_groups, lines = cache[fac]
        if not n:
            continue
        subject = f"🗓 รออนุมัติรายสัปดาห์: {n_groups} รายการ ({n} ผลตรวจ" + (f" · NG {ng}" if ng else "") + ")"
        body = "\n".join(lines[:15]) + (f"\nและอีก {len(lines) - 15} รายการ" if len(lines) > 15 else "") + \
            "\nเปิดเมนู รออนุมัติ › อนุมัติรายสัปดาห์ (ผลที่มี NG ต้องเปิดดูก่อน)"
        _deliver(db, cfg, base_url, {"users": [u], "groups": []}, kind="approval_week", subject=subject, body=body,
                 path="/approvals/group", severity="warning" if ng else "info", ref_key=f"{key}:{u['id']}", now=now)
        sent += 1
    if not force:
        db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('wkappr_sent', ?)", (key,))
    return {"wk_appr": sent}


# ───────────────────────── สรุปประจำวัน ─────────────────────────

def daily_summary_text(db, day: date) -> tuple[str, str]:
    from .analytics import results_of_day
    lines = []
    for f in db.execute("SELECT id, name FROM factories WHERE active=1 ORDER BY sort_no"):
        ov = S.rounds_overview(db, day, f["id"])
        if not ov["total"]:
            continue
        res = results_of_day(db, day, f["id"])
        al = db.execute(f"""SELECT COUNT(*) FROM cs_alerts a JOIN cs_forms fm ON fm.id=a.form_id WHERE fm.factory_id=?
                            AND a.status IN ({','.join('?' * len(OPEN_STATUSES))})""", (f["id"], *OPEN_STATUSES)).fetchone()[0]
        lines.append(f"{f['name']}: ตรวจแล้ว {ov['done']}/{ov['total']} รอบ · ขาดตรวจ {ov['counts']['missed']} · "
                     f"NG {res['ng']} หัวข้อ · แจ้งเตือนค้าง {al}")
    capa = db.execute("""SELECT COUNT(*) FROM cs_actions WHERE status IN ('open','in_progress') AND due_date < ?""",
                      (day.isoformat(),)).fetchone()[0]
    if capa:
        lines.append(f"งานแก้ไข (CAPA) เลยกำหนด {capa} งาน")
    return f"📋 สรุปการตรวจเช็ค {day:%d/%m/%Y}", "\n".join(lines) or "ไม่มีรอบตรวจในวันนี้"


def daily_summary(db, now: datetime | None = None, base_url: str = "", force: bool = False) -> bool:
    now = now or S.now_dt()
    cfg = get_settings(db)
    ds = cfg["daily_summary"]
    if not ds.get("enabled") and not force:
        return False
    hh, mm = (int(x) for x in ds.get("time", "17:00").split(":"))
    if not force and (now.hour, now.minute) < (hh, mm):
        return False
    key = f"summary:{now.date().isoformat()}"
    if not force and db.execute("SELECT 1 FROM cs_meta WHERE key='summary_sent' AND value=?", (key,)).fetchone():
        return False
    subject, body = daily_summary_text(db, now.date())
    for ch in CHANNELS:
        target = cfg[ch].get("default_target")
        if target:
            enqueue(db, cfg, ch, target, subject, body, _link(base_url, "/dashboard"), ref_key=key + (":f" if force else ""),
                    label="กลุ่มหลัก", now=now)
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('summary_sent', ?)", (key,))
    return True


# ───────────────────────── in-app ─────────────────────────

def unread_count(db, user_id: int) -> int:
    return db.execute("SELECT COUNT(*) FROM cs_notifications WHERE user_id=? AND read_at IS NULL", (user_id,)).fetchone()[0]


def list_notifications(db, user_id: int, limit: int = 30, unread_only: bool = False) -> list[dict]:
    cond = " AND read_at IS NULL" if unread_only else ""
    return [dict(r) for r in db.execute(
        f"SELECT * FROM cs_notifications WHERE user_id=? {cond} ORDER BY id DESC LIMIT ?", (user_id, limit))]


def mark_read(db, user_id: int, ids: list[int] | None = None) -> int:
    now_s = ts(S.now_dt())
    if ids:
        q = f"UPDATE cs_notifications SET read_at=? WHERE user_id=? AND read_at IS NULL AND id IN ({','.join('?' * len(ids))})"
        return db.execute(q, (now_s, user_id, *ids)).rowcount
    return db.execute("UPDATE cs_notifications SET read_at=? WHERE user_id=? AND read_at IS NULL", (now_s, user_id)).rowcount


# ───────────────────────── background loop ─────────────────────────

_wake = threading.Event()
_started = False
_lock = threading.Lock()


def wake() -> None:
    """ให้รอบส่งแจ้งเตือนทำงานทันที (เรียกหลังบันทึกผลตรวจที่มีแจ้งเตือนใหม่)"""
    _wake.set()


def tick(db_path: str, base_url: str = "", now: datetime | None = None) -> dict:
    import sqlite3
    con = sqlite3.connect(db_path, timeout=15)
    con.row_factory = sqlite3.Row
    try:
        con.execute("PRAGMA busy_timeout=15000")
        con.execute("PRAGMA foreign_keys=ON")
        now = now or S.now_dt()
        res = escalate(con, now, base_url)
        res.update(round_reminders(con, now, base_url))
        res.update(round_start_reminders(con, now, base_url))
        from .capa import capa_reminders
        res.update(capa_reminders(con, now, base_url))
        res.update(weekly_approval_reminders(con, now, base_url))
        daily_summary(con, now, base_url)
        con.commit()
        try:                                            # v0.51 ส่งกะ / รับกะ · สรุปผลงานรายสัปดาห์
            from .handover import generate as _ho
            res["handovers"] = _ho(con, now, base_url)
            from .scorecard import weekly_send as _sc
            res["scorecard"] = _sc(con, now, base_url)
        except Exception:                               # noqa: BLE001
            con.rollback()
            log.exception("handover/scorecard failed")
        con.commit()
    finally:
        con.close()
    res.update(process_outbox(db_path))
    return res


def _loop(app) -> None:
    interval = max(10, int(app.config.get("NOTIFY_INTERVAL_SEC", 30)))
    from .health import beat
    while True:
        beat("notify")
        try:
            tick(app.config["DATABASE"], app.config.get("BASE_URL", ""))
        except Exception:  # งานเบื้องหลังต้องไม่ล้มทั้งระบบ
            log.exception("notify tick failed")
        try:
            from .views.rep import run_due_schedules
            run_due_schedules(app)          # รายงานตามเวลา
        except Exception:
            log.exception("report schedule failed")
        try:
            from .connectors import run_due_sources
            run_due_sources(app)            # ดึงข้อมูลจากระบบภายนอก
        except Exception:
            log.exception("data source failed")
        try:
            from .energy_src import run_due_sources as run_energy_sources
            run_energy_sources(app)         # v0.72 ดึงค่า SCADA ของ Energy Data (แยกจาก E-Check)
        except Exception:
            log.exception("energy data source failed")
        _wake.wait(interval)
        _wake.clear()


def start_notifier(app) -> None:
    global _started
    if app.debug and os.environ.get("WERKZEUG_RUN_MAIN") != "true":
        return
    with _lock:
        if _started:
            return
        _started = True
    threading.Thread(target=_loop, args=(app,), daemon=True, name="ecs-notify").start()
    log.info("notify thread started")
