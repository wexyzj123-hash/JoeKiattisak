"""ecs/energy_register.py — v0.90 ทะเบียนมิเตอร์มาตรฐาน (สร้างจากไฟล์จดมิเตอร์ ไอชิน 1–3)

ไฟล์ ecs/data/meter_register.json สร้างจากไฟล์ Excel ที่ใช้จดมิเตอร์จริงของแต่ละโรงงาน:
  ไฟฟ้า   Daily_Aisin1 · Electric used ไอชิน 2 · Electric used ไอชิน 3
  น้ำใช้  บันทึกการใช้น้ำ ไอชิน 1/2/3          น้ำ RO   การใช้น้ำ RO ไอชิน 1/2/3
  ลมอัด   การใช้ลม LINE ไอชิน 2/3              ชั่วโมงเดินเครื่อง  AIR COMPRESSOR ไอชิน 3
แต่ละแถว: โรงงาน (1–3) · ประเภท · key (ตัวเดียวกับที่หน้า “นำเข้า” สร้างจากหัวตาราง → นำเข้าไฟล์เดิมแล้วลงมิเตอร์ตัวเดียวกัน)
· รหัส · ชื่อ · Section · Line · บทบาท (หลัก/ย่อย/ไม่นับรวม) · มิเตอร์แม่ · หน่วย · ราคา · ลำดับ

plan()  เทียบทะเบียนกับมิเตอร์ในระบบ → ใหม่ / ตรงแล้ว / ต่าง (ระบุช่อง) / มีในระบบแต่ไม่มีในทะเบียน
apply() mode "fill" = เพิ่มมิเตอร์ที่ขาด + เติมช่องที่ว่าง · mode "sync" = ปรับทุกช่องให้ตรงทะเบียน
"""
from __future__ import annotations

import json
import os
import re

from . import energy as EN
from . import masterdata as M
from . import services as S
from .services import ts

PATH = os.path.join(os.path.dirname(__file__), "data", "meter_register.json")
FIELDS = ("code", "name", "grp", "line", "is_main", "unit", "price", "parent")
FIELD_TH = {"code": "รหัส", "name": "ชื่อ", "grp": "Section", "line": "Line", "is_main": "บทบาท", "unit": "หน่วย",
            "price": "ราคา", "parent": "มิเตอร์แม่"}
_CACHE: list | None = None


def rows() -> list[dict]:
    global _CACHE
    if _CACHE is None:
        with open(PATH, encoding="utf-8") as fh:
            _CACHE = json.load(fh)
    return _CACHE


def norm_section(g: str) -> str:
    """ชื่อ Section จากหัวตาราง Excel → ชื่อมาตรฐาน (ตัด “การใช้น้ำ R.O ฝั่ง …” ฯลฯ)"""
    g = re.sub(r"^การใช้(?:น้ำ\s*R\.?O|น้ำ|ลม|ไฟฟ้า|ไฟ)\s*ฝั่ง\s*", "", (g or "").strip())
    g = re.sub(r"\bD10\s*C\b", "D10C", re.sub(r"\s+", " ", g), flags=re.I)
    return g.strip()[:80]


def factory_map(db) -> dict[int, int]:
    """โรงงานในทะเบียน (1–3) → id โรงงานในระบบ: ชื่อ/รหัสมีเลขตรงกัน · ไม่งั้นตามลำดับ"""
    facs = M.list_factories(db)
    out: dict[int, int] = {}
    for n in (1, 2, 3):
        hit = [f for f in facs if re.search(rf"(?<!\d){n}(?!\d)", f"{f['name']} {f['code']}")]
        if hit:
            out[n] = hit[0]["id"]
        elif n <= len(facs):
            out[n] = facs[n - 1]["id"]
    return out


def _want(r: dict) -> dict:
    return {"code": r["code"], "name": r["name"][:120], "grp": r["grp"], "line": r.get("line") or "", "is_main": r["role"],
            "unit": r["unit"], "price": r.get("price"), "parent": r.get("parent_key")}


def _find(db, fid, kind, r: dict, taken: set) -> dict | None:
    m = db.execute("SELECT * FROM en_meters WHERE factory_id IS ? AND kind=? AND key=?", (fid, kind, r["key"])).fetchone()
    if m:
        return dict(m)
    for col, val in (("code", r["code"]), ("name", r["name"])):     # มิเตอร์ที่สร้างเองไว้ก่อน (key คนละแบบ) → จับคู่ด้วยรหัส/ชื่อที่ไม่ซ้ำ
        if not val:
            continue
        hit = [dict(x) for x in db.execute(f"SELECT * FROM en_meters WHERE factory_id IS ? AND kind=? AND UPPER(TRIM({col}))=UPPER(?)",
                                           (fid, kind, val.strip())) if x["id"] not in taken]
        if len(hit) == 1:
            return hit[0]
    return None


def plan(db, factory_no: int | None = None, kind: str | None = None) -> dict:
    EN.ensure(db)
    fmap = factory_map(db)
    key_of: dict[int, str] = {}
    items, taken = [], set()
    for r in rows():
        if (factory_no and r["f"] != factory_no) or (kind and r["kind"] != kind) or r["kind"] not in EN.KINDS:
            continue
        fid = fmap.get(r["f"])
        if not fid:
            continue
        m = _find(db, fid, r["kind"], r, taken)
        want = _want(r)
        diff = []
        if m:
            taken.add(m["id"])
            key_of[m["id"]] = r["key"]
            for f in FIELDS:
                if f == "parent":
                    continue
                cur, new = m.get(f), want[f]
                if f == "price" and new is None:
                    continue
                if (cur if cur is not None else "") != (new if new is not None else ""):
                    diff.append(f)
        items.append({"r": r, "fid": fid, "m": m, "want": want, "diff": diff,
                      "status": "new" if not m else ("diff" if diff else "same")})
    # มิเตอร์แม่: เทียบ key ของแม่ปัจจุบันกับทะเบียน
    for it in items:
        if it["m"] and it["want"]["parent"] and key_of.get(it["m"].get("parent_id") or 0) != it["want"]["parent"]:
            it["diff"].append("parent")
            it["status"] = "diff"
    reg_ids = {it["m"]["id"] for it in items if it["m"]}
    extra = []
    for n, fid in fmap.items():
        if factory_no and n != factory_no:
            continue
        for m in EN.meters(db, fid, kind):
            if m["id"] not in reg_ids and m["kind"] in {r["kind"] for r in rows() if r["f"] == n}:
                extra.append(m)
    summary: dict[tuple, dict] = {}
    for it in items:
        s = summary.setdefault((it["r"]["f"], it["r"]["kind"]), {"f": it["r"]["f"], "kind": it["r"]["kind"], "src": it["r"]["src"],
                                                             "n": 0, "new": 0, "diff": 0, "same": 0, "extra": 0})
        s["n"] += 1
        s[it["status"]] += 1
    for m in extra:
        n = next((k for k, v in fmap.items() if v == m["factory_id"]), None)
        if (n, m["kind"]) in summary:
            summary[(n, m["kind"])]["extra"] += 1
    return {"items": items, "extra": extra, "summary": sorted(summary.values(), key=lambda s: (s["f"], EN.KIND_ORDER.index(s["kind"])
                                                                                           if s["kind"] in EN.KIND_ORDER else 9)),
            "fmap": fmap, "counts": {k: sum(1 for it in items if it["status"] == k) for k in ("new", "diff", "same")}}


def apply(db, mode: str, actor, factory_no: int | None = None, kind: str | None = None, deactivate_extra: bool = False) -> dict:
    """mode fill = เพิ่มที่ขาด + เติมเฉพาะช่องว่าง · sync = ปรับทุกช่องให้ตรงทะเบียน"""
    if mode not in ("fill", "sync"):
        raise S.ValidationError("รูปแบบการปรับไม่ถูกต้อง")
    p = plan(db, factory_no, kind)
    stamp = ts(S.now_dt())
    res = {"new": 0, "updated": 0, "parents": 0, "deactivated": 0}
    by_key: dict[tuple, int] = {}
    for it in p["items"]:
        r, w, fid = it["r"], it["want"], it["fid"]
        if not it["m"]:
            mid = db.execute("""INSERT INTO en_meters(factory_id, kind, key, code, name, grp, unit, price, is_main, sort_no, note, created_at)
                                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                             (fid, r["kind"], r["key"], w["code"], w["name"], w["grp"], w["unit"], w["price"], w["is_main"],
                              r["sort"], r.get("note") or "", stamp)).lastrowid
            if w["line"]:
                db.execute("UPDATE en_meters SET line=? WHERE id=?", (w["line"], mid))
            res["new"] += 1
        else:
            m, mid = it["m"], it["m"]["id"]
            upd = {}
            for f in it["diff"]:
                if f == "parent":
                    continue
                if mode == "sync" or m.get(f) in (None, "") or (f == "is_main" and m.get(f) == 0 and w["is_main"] != 0
                                                                 and mode == "fill"):
                    upd[f] = w[f]
            if mode == "sync":
                upd["sort_no"] = r["sort"]
            if upd:
                db.execute(f"UPDATE en_meters SET {', '.join(k + '=?' for k in upd)} WHERE id=?", [*upd.values(), mid])
                if set(upd) - {"sort_no"}:
                    res["updated"] += 1
        by_key[(fid, r["kind"], r["key"])] = mid
        from .energy_struct import ensure_catalog
        ensure_catalog(db, fid, w["grp"], w["line"])
    for it in p["items"]:
        w, fid, r = it["want"], it["fid"], it["r"]
        mid = by_key[(fid, r["kind"], r["key"])]
        pid = by_key.get((fid, r["kind"], w["parent"])) if w["parent"] else None
        cur = db.execute("SELECT parent_id FROM en_meters WHERE id=?", (mid,)).fetchone()[0]
        if pid and cur != pid and (mode == "sync" or not cur):
            db.execute("UPDATE en_meters SET parent_id=? WHERE id=?", (pid, mid))
            res["parents"] += 1
    if deactivate_extra and mode == "sync":
        for m in p["extra"]:
            if m["active"] and not m.get("scada_tag"):
                db.execute("UPDATE en_meters SET active=0 WHERE id=?", (m["id"],))
                res["deactivated"] += 1
    S.audit(db, actor, "energy_register", "en_meters", None, after=dict(res, mode=mode, factory=factory_no, kind=kind))
    return res


def detect(parsed: dict, db) -> dict | None:
    """ไฟล์ที่นำเข้า → โรงงาน/ประเภทที่ key ตรงกับทะเบียนมากที่สุด (ช่วยเลือกให้อัตโนมัติ)"""
    keys = {m["key"] for m in parsed.get("meters") or []}
    if not keys:
        return None
    score: dict[tuple, int] = {}
    for r in rows():
        if r["key"] in keys:
            score[(r["f"], r["kind"])] = score.get((r["f"], r["kind"]), 0) + 1
    if not score:
        return None
    (n, kind), hit = max(score.items(), key=lambda x: x[1])
    fid = factory_map(db).get(n)
    if hit < max(2, len(keys) // 3) or not fid:
        return None
    return {"factory_id": fid, "kind": kind, "hit": hit, "n": len(keys), "f": n}


def standard_for(db, factory_id, kind: str) -> dict[str, dict]:
    """key → แถวทะเบียนของโรงงาน/ประเภทนี้ (ใช้ตั้ง Section/Line/บทบาทให้มิเตอร์ใหม่ตอนนำเข้าให้ตรงมาตรฐาน)"""
    n = next((k for k, v in factory_map(db).items() if v == factory_id), None)
    if not n:
        return {}
    return {r["key"]: r for r in rows() if r["f"] == n and r["kind"] == kind}
