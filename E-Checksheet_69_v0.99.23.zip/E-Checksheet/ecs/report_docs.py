"""ecs/report_docs.py — Phase 5: รายงานรายวัน / รายเดือน (ดูบนเว็บ พิมพ์ PDF และ Excel หลายชีต)

รวมข้อมูลจากทุกโมดูล: รอบตรวจ, ผลตรวจ, NG, แจ้งเตือน, งานแก้ไข (CAPA), อัตราตรวจตรงเวลารายพื้นที่, ผู้ตรวจ
"""
from __future__ import annotations

import calendar
import html
from datetime import date, datetime, timedelta
from typing import Any

from . import analytics as AN
from . import services as S
from .reports import APPROVAL_TH, ROUND_TH, SEV_TH, STATUS_TH, _spec, workbook

CAPA_TH = {"open": "เปิด", "in_progress": "กำลังดำเนินการ", "done": "รอตรวจรับ", "closed": "ปิดงาน", "cancelled": "ยกเลิก"}
KINDS = {"daily": "รายงานการตรวจเช็คประจำวัน", "weekly": "รายงานการตรวจเช็คประจำสัปดาห์",
         "monthly": "รายงานการตรวจเช็คประจำเดือน"}
TH_MONTHS = ("มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน",
             "ตุลาคม", "พฤศจิกายน", "ธันวาคม")

# สีสำหรับเอกสารพิมพ์ (พื้นขาว) — ชุดเดียวกับ Dashboard
C_S1, C_S3, C_CRIT, C_WARN, C_GOOD, C_GRID, C_INK, C_MUTED = ("#2a78d6", "#1baf7a", "#d03b3b", "#fab219", "#0ca30c",
                                                              "#e1e0d9", "#1f2937", "#6b7280")


def thai_date(d: date) -> str:
    return f"{d.day} {TH_MONTHS[d.month - 1]} {d.year + 543}"


def period_for(kind: str, ref: date) -> tuple[date, date, str]:
    if kind == "monthly":
        first = ref.replace(day=1)
        last = ref.replace(day=calendar.monthrange(ref.year, ref.month)[1])
        return first, last, f"เดือน{TH_MONTHS[ref.month - 1]} {ref.year + 543}"
    if kind == "weekly":
        first = ref - timedelta(days=6)
        return first, ref, f"{thai_date(first)} – {thai_date(ref)}"
    return ref, ref, f"วันที่ {thai_date(ref)}"


def _fc(factory_id, alias="f"):
    return (f" AND {alias}.factory_id=?", [factory_id]) if factory_id else ("", [])


def _rng(d_from: date, d_to: date) -> list[str]:
    return [f"{d_from.isoformat()} 00:00:00", f"{d_to.isoformat()} 23:59:59"]


def build(db, kind: str, ref: date, factory_id: int | None = None, generated_by: str = "") -> dict:
    d_from, d_to, period = period_for(kind, ref)
    d_to_eff = min(d_to, date.today())
    fc, fp = _fc(factory_id)
    rng = _rng(d_from, d_to)
    fac_name = "ทุกโรงงาน"
    if factory_id:
        r = db.execute("SELECT name FROM factories WHERE id=?", (factory_id,)).fetchone()
        fac_name = r["name"] if r else "-"
    ov = AN.overview(db, d_from, max(d_from, d_to_eff), factory_id)

    sub = db.execute(f"""SELECT SUM(s.source<>'auto') n, AVG(CASE WHEN s.duration_sec > 0 AND s.source<>'auto' THEN s.duration_sec END) avg_sec,
                                SUM(s.source='auto') auto_n
                         FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
                         WHERE s.status<>'superseded' AND s.finished_at BETWEEN ? AND ? {fc}""", rng + fp).fetchone()
    ans = db.execute(f"""SELECT SUM(a.judgement='ok') ok, SUM(a.judgement='warn') warn, SUM(a.judgement='ng') ng
                         FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id JOIN cs_forms f ON f.id=s.form_id
                         WHERE s.status<>'superseded' AND s.source<>'auto' AND s.finished_at BETWEEN ? AND ? {fc}""", rng + fp).fetchone()
    judged = (ans["ok"] or 0) + (ans["warn"] or 0) + (ans["ng"] or 0)
    al = db.execute(f"""SELECT COUNT(*) n, SUM(a.severity='critical') crit, SUM(a.severity='warning') warn,
                               SUM(a.status IN ('resolved','closed')) done
                        FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id
                        WHERE a.alert_type<>'approval' AND a.created_at BETWEEN ? AND ? {fc}""", rng + fp).fetchone()
    cfc, cfp = (" AND c.factory_id=?", [factory_id]) if factory_id else ("", [])
    capa = db.execute(f"""SELECT SUM(c.created_at BETWEEN ? AND ?) opened,
                                 SUM(c.status='closed' AND c.closed_at BETWEEN ? AND ?) closed,
                                 SUM(c.status IN ('open','in_progress') AND c.due_date < ?) overdue,
                                 SUM(c.status IN ('open','in_progress','done')) active
                          FROM cs_actions c WHERE 1=1 {cfc}""",
                      rng + rng + [date.today().isoformat()] + cfp).fetchone()

    # รายพื้นที่
    area_rows = []
    for r in db.execute(f"""
        SELECT COALESCE(fa.name,'-') fac, COALESCE(ar.name,'ไม่ระบุพื้นที่') area, SUM(d.due) due, SUM(d.done_on_time) ot,
               SUM(d.done_late) late, SUM(d.missed) missed, SUM(d.ng) ng
        FROM cs_daily_stats d JOIN cs_forms f ON f.id=d.form_id LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN areas ar ON ar.id=COALESCE(f.area_id, e.area_id)
        WHERE d.stat_date BETWEEN ? AND ? {fc}
        GROUP BY fac, area ORDER BY MIN(COALESCE(fa.sort_no, 99)), fac, area""", [d_from.isoformat(), d_to.isoformat()] + fp):
        closed = (r["ot"] or 0) + (r["late"] or 0) + (r["missed"] or 0)
        rate = round(100.0 * (r["ot"] or 0) / closed, 1) if closed else None
        area_rows.append({**dict(r), "rate": rate, "status": AN.rate_status(rate)})

    # รายวัน (สำหรับรายเดือน)
    days = []
    if kind in ("monthly", "weekly"):
        trend = {r["stat_date"]: r for r in db.execute(f"""
            SELECT d.stat_date, SUM(d.due) due, SUM(d.done_on_time) ot, SUM(d.done_late) late, SUM(d.missed) missed, SUM(d.ng) ng
            FROM cs_daily_stats d JOIN cs_forms f ON f.id=d.form_id WHERE d.stat_date BETWEEN ? AND ? {fc}
            GROUP BY d.stat_date""", [d_from.isoformat(), d_to.isoformat()] + fp)}
        d = d_from
        while d <= d_to:
            r = trend.get(d.isoformat())
            due = (r["due"] or 0) if r else 0
            done = ((r["ot"] or 0) + (r["late"] or 0)) if r else 0
            closed = done + ((r["missed"] or 0) if r else 0)
            days.append({"date": d, "due": due, "done": done, "on_time": (r["ot"] or 0) if r else 0,
                         "missed": (r["missed"] or 0) if r else 0, "ng": (r["ng"] or 0) if r else 0,
                         "rate": round(100.0 * ((r["ot"] or 0) if r else 0) / closed, 1) if closed else None,
                         "future": d > date.today()})
            d += timedelta(days=1)

    # NG ทั้งหมดในช่วง (พร้อมรูปแรก และงานแก้ไขที่เกี่ยวข้อง)
    ng_rows = [dict(r) for r in db.execute(f"""
        SELECT s.id AS sub_id, s.finished_at, fa.name AS factory, e.code AS eq_code, f.name AS form_name, i.name AS item,
               a.value_text, i.unit, i.min_value, i.max_value, i.item_type, a.remark, u.name AS inspector, a.item_key, s.form_id,
               (SELECT p.file_path FROM cs_photos p WHERE p.answer_id=a.id ORDER BY p.id LIMIT 1) AS photo,
               (SELECT c.code || ' · ' || c.status FROM cs_actions c WHERE (c.submission_id=s.id AND c.item_key=a.item_key)
                   OR (c.alert_id IN (SELECT al.id FROM cs_alerts al WHERE al.form_id=s.form_id AND al.item_key=a.item_key))
                   ORDER BY c.id DESC LIMIT 1) AS capa
        FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id JOIN cs_form_items i ON i.id=a.item_id
        JOIN cs_forms f ON f.id=s.form_id LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN equipment e ON e.id=s.equipment_id LEFT JOIN users u ON u.id=s.inspector_id
        WHERE a.judgement='ng' AND s.status<>'superseded' AND s.finished_at BETWEEN ? AND ? {fc}
        ORDER BY s.finished_at LIMIT 300""", rng + fp)]
    for r in ng_rows:
        r["spec"] = _spec(r["min_value"], r["max_value"]) if r["item_type"] in ("number", "counter", "calc") else ""
        if r["capa"]:
            code, st = r["capa"].split(" · ")
            r["capa"] = f"{code} ({CAPA_TH.get(st, st)})"

    missed = [dict(r) for r in db.execute(f"""
        SELECT r.due_at, r.deadline_at, fa.name AS factory, e.code AS eq_code, f.name AS form_name
        FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN equipment e ON e.id=f.equipment_id
        WHERE r.status='missed' AND r.due_at BETWEEN ? AND ? AND {S.scheduled_sql()} {fc} ORDER BY r.due_at LIMIT 200""", rng + fp)]

    alerts = [dict(r) for r in db.execute(f"""
        SELECT a.id, a.created_at, a.severity, a.alert_type, a.title, a.status, a.occurrences, a.root_cause, a.action_taken,
               fa.name AS factory
        FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id LEFT JOIN factories fa ON fa.id=f.factory_id
        WHERE a.alert_type<>'approval' AND a.created_at BETWEEN ? AND ? {fc}
        ORDER BY CASE a.severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END, a.created_at LIMIT 300""", rng + fp)]

    capa_rows = [dict(r) for r in db.execute(f"""
        SELECT c.code, c.title, c.status, c.priority, c.due_date, c.created_at, c.closed_at, u.name AS owner, e.code AS eq_code
        FROM cs_actions c LEFT JOIN users u ON u.id=c.owner_id LEFT JOIN equipment e ON e.id=c.equipment_id
        WHERE (c.status IN ('open','in_progress','done') OR c.created_at BETWEEN ? AND ? OR c.closed_at BETWEEN ? AND ?) {cfc}
        ORDER BY CASE c.status WHEN 'open' THEN 0 WHEN 'in_progress' THEN 0 WHEN 'done' THEN 1 ELSE 2 END, c.due_date
        LIMIT 200""", rng + rng + cfp)]
    today_s = date.today().isoformat()
    for c in capa_rows:
        c["overdue"] = bool(c["due_date"] and c["status"] in ("open", "in_progress") and c["due_date"] < today_s)

    inspectors = [dict(r) for r in db.execute(f"""
        SELECT u.name, COUNT(*) subs, AVG(CASE WHEN s.duration_sec > 0 THEN s.duration_sec END) avg_sec, SUM(s.ng_count) ng,
               SUM(r.status='done_on_time') on_time, SUM(r.status='done_late') late
        FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id JOIN users u ON u.id=s.inspector_id
        LEFT JOIN cs_rounds r ON r.submission_id=s.id
        WHERE s.status<>'superseded' AND s.source<>'auto' AND s.finished_at BETWEEN ? AND ? {fc}
        GROUP BY u.id ORDER BY subs DESC""", rng + fp)]

    rounds = []
    if kind == "daily":
        rounds = S.rounds_overview(db, d_from, factory_id)["items"]

    pareto = AN.ng_pareto(db, d_from, d_to, factory_id, limit=10)
    return {
        "kind": kind, "title": KINDS[kind], "period": period, "d_from": d_from, "d_to": d_to, "factory": fac_name,
        "factory_id": factory_id, "generated_at": datetime.now(), "generated_by": generated_by,
        "kpi": {
            "due": ov["due"], "on_time": ov["on_time"], "late": ov["late"], "missed": ov["missed"], "rate": ov["rate"],
            "rate_status": ov["rate_status"], "subs": sub["n"] or 0, "auto_subs": sub["auto_n"] or 0,
            "avg_sec": round(sub["avg_sec"]) if sub["avg_sec"] else None,
            "item_count": judged, "ng": ans["ng"] or 0, "warn": ans["warn"] or 0,
            "pass_rate": round(100.0 * ((ans["ok"] or 0) + (ans["warn"] or 0)) / judged, 1) if judged else None,
            "alerts": al["n"], "alerts_crit": al["crit"] or 0, "alerts_warn": al["warn"] or 0, "alerts_done": al["done"] or 0,
            "capa_opened": capa["opened"] or 0, "capa_closed": capa["closed"] or 0, "capa_overdue": capa["overdue"] or 0,
            "capa_active": capa["active"] or 0,
        },
        "factories": ov["factories"] if not factory_id else [], "areas": area_rows, "days": days, "ng": ng_rows,
        "missed": missed, "alerts": alerts, "capa": capa_rows, "inspectors": inspectors, "rounds": rounds,
        "pareto": pareto,
    }


# ───────────────────────── SVG charts (สำหรับเอกสารพิมพ์ — ไม่ใช้ JavaScript) ─────────────────────────

def _esc(s: Any) -> str:
    return html.escape(str(s if s is not None else ""))


def svg_daily_bars(days: list[dict], width: int = 1000, height: int = 220) -> str:
    """แท่งคู่: รอบที่กำหนด / ตรวจแล้ว รายวัน + เส้น % ตรงเวลาแยกเป็นป้ายตัวเลข (แกนเดียว)"""
    if not days:
        return ""
    pad_l, pad_r, pad_t, pad_b = 34, 8, 18, 34
    w, h = width - pad_l - pad_r, height - pad_t - pad_b
    mx = max([d["due"] for d in days] + [1])
    step = w / len(days)
    bw = max(2.0, min(12.0, step * 0.34))
    out = [f'<svg viewBox="0 0 {width} {height}" width="100%" role="img" aria-label="รอบที่กำหนดเทียบรอบที่ตรวจแล้วรายวัน" '
           f'style="font-family:inherit;font-size:10px">']
    for i in range(5):
        v = mx * i / 4
        y = pad_t + h - h * i / 4
        out.append(f'<line x1="{pad_l}" x2="{width - pad_r}" y1="{y:.1f}" y2="{y:.1f}" stroke="{C_GRID}"/>'
                   f'<text x="{pad_l - 4}" y="{y + 3:.1f}" text-anchor="end" fill="{C_MUTED}">{v:.0f}</text>')
    for i, d in enumerate(days):
        x = pad_l + i * step + step / 2
        for j, (val, col) in enumerate(((d["due"], C_S1), (d["done"], C_S3))):
            bh = h * val / mx
            bx = x - bw - 1 + j * (bw + 2)
            out.append(f'<rect x="{bx:.1f}" y="{pad_t + h - bh:.1f}" width="{bw:.1f}" height="{bh:.1f}" rx="2" fill="{col}"/>')
        if d["missed"]:
            out.append(f'<text x="{x:.1f}" y="{pad_t + h - h * d["due"] / mx - 4:.1f}" text-anchor="middle" fill="{C_CRIT}" '
                       f'font-weight="700">{d["missed"]}</text>')
        if len(days) <= 31 and (i % (1 if len(days) <= 16 else 2) == 0):
            out.append(f'<text x="{x:.1f}" y="{height - pad_b + 14}" text-anchor="middle" fill="{C_MUTED}">{d["date"].day}</text>')
    out.append("</svg>")
    return "".join(out)


def svg_hbars(items: list[dict], label_key: str, value_key: str, width: int = 1000, row_h: int = 22,
              color: str = C_S1, suffix_key: str | None = None) -> str:
    if not items:
        return ""
    label_w = 330
    height = row_h * len(items) + 6
    mx = max([it[value_key] for it in items] + [1])
    out = [f'<svg viewBox="0 0 {width} {height}" width="100%" role="img" style="font-family:inherit;font-size:11px">']
    for i, it in enumerate(items):
        y = i * row_h + 3
        bw = (width - label_w - 90) * it[value_key] / mx
        label = str(it[label_key])
        label = label if len(label) <= 52 else label[:50] + "…"
        suffix = f" · {it[suffix_key]}%" if suffix_key else ""
        out.append(f'<text x="{label_w - 8}" y="{y + row_h * 0.62:.1f}" text-anchor="end" fill="{C_INK}">{_esc(label)}</text>'
                   f'<rect x="{label_w}" y="{y + 3}" width="{max(bw, 2):.1f}" height="{row_h - 8}" rx="3" fill="{color}"/>'
                   f'<text x="{label_w + bw + 6:.1f}" y="{y + row_h * 0.62:.1f}" fill="{C_INK}">{it[value_key]}{suffix}</text>')
    out.append("</svg>")
    return "".join(out)


# ───────────────────────── Excel ─────────────────────────

def to_excel(rep: dict) -> bytes:
    k = rep["kpi"]
    sub = f"{rep['factory']} · {rep['period']}"
    rate = lambda v: "" if v is None else v   # noqa: E731
    summary = [["รอบตรวจที่กำหนด", k["due"]], ["ตรวจตรงเวลา", k["on_time"]], ["ตรวจล่าช้า", k["late"]], ["ขาดตรวจ", k["missed"]],
               ["% ตรวจตรงเวลา", rate(k["rate"])], ["ผลตรวจที่ส่ง (ครั้ง)", k["subs"]], ["  - จากระบบอัตโนมัติ", k["auto_subs"]],
               ["เวลาตรวจเฉลี่ย (นาที)", round(k["avg_sec"] / 60, 1) if k["avg_sec"] else ""],
               ["หัวข้อที่ตรวจ", k["item_count"]], ["NG", k["ng"]], ["ช่วงเตือน", k["warn"]], ["% ผ่านเกณฑ์", rate(k["pass_rate"])],
               ["แจ้งเตือนเกิดใหม่", k["alerts"]], ["  - วิกฤต", k["alerts_crit"]], ["  - แก้ไขแล้ว", k["alerts_done"]],
               ["CAPA เปิดใหม่", k["capa_opened"]], ["CAPA ปิดงาน", k["capa_closed"]], ["CAPA ยังไม่ปิด", k["capa_active"]],
               ["CAPA เลยกำหนด", k["capa_overdue"]]]
    status_th = {"good": "ผ่านเป้าหมาย", "warning": "เฝ้าระวัง", "critical": "ต่ำกว่าเกณฑ์", "none": "-"}
    sheets = [
        {"title": rep["title"], "subtitle": sub, "sheet_name": "สรุป", "headers": ["รายการ", "ค่า"], "rows": summary,
         "widths": [34, 14]},
        {"title": "สรุปรายพื้นที่", "subtitle": sub, "headers": ["โรงงาน", "พื้นที่", "รอบที่กำหนด", "ตรงเวลา", "ล่าช้า", "ขาดตรวจ",
                                                               "% ตรงเวลา", "สถานะ", "NG"],
         "rows": [[a["fac"], a["area"], a["due"] or 0, a["ot"] or 0, a["late"] or 0, a["missed"] or 0, rate(a["rate"]),
                   status_th[a["status"]], a["ng"] or 0] for a in rep["areas"]],
         "widths": [14, 26, 12, 10, 10, 10, 11, 14, 8],
         "highlight": lambda r: {"ต่ำกว่าเกณฑ์": "ng", "เฝ้าระวัง": "warn"}.get(r[7])},
    ]
    if rep["days"]:
        sheets.append({"title": "รายวัน", "subtitle": sub, "headers": ["วันที่", "รอบที่กำหนด", "ตรวจแล้ว", "ตรงเวลา", "ขาดตรวจ",
                                                                     "% ตรงเวลา", "NG"],
                       "rows": [[d["date"].strftime("%d/%m/%Y"), d["due"], d["done"], d["on_time"], d["missed"], rate(d["rate"]),
                                 d["ng"]] for d in rep["days"] if not d["future"]],
                       "widths": [12, 12, 10, 10, 10, 11, 8]})
    if rep["rounds"]:
        sheets.append({"title": "รอบตรวจ", "subtitle": sub, "headers": ["เริ่มตรวจ", "ต้องเสร็จ", "โรงงาน", "เครื่อง", "แบบฟอร์ม",
                                                                       "สถานะ", "ผู้ตรวจ", "ส่งผล", "NG", "อนุมัติ"],
                       "rows": [[S.parse_ts(r["due_at"]).strftime("%H:%M"), S.parse_ts(r["deadline_at"]).strftime("%H:%M"),
                                 r["factory_name"] or "", r["eq_code"] or "", r["form_name"], ROUND_TH.get(r["status"], r["status"]),
                                 r["inspector_name"] or "", S.parse_ts(r["finished_at"]).strftime("%H:%M") if r["finished_at"] else "",
                                 r["ng_count"] or 0, APPROVAL_TH.get(r["approval_status"] or "", "")] for r in rep["rounds"]],
                       "widths": [9, 9, 12, 11, 34, 13, 18, 8, 6, 12],
                       "highlight": lambda r: "ng" if r[5] in ("ขาดตรวจ", "ตีกลับ") else ("warn" if r[5] in ("เลยกำหนด", "ตรวจล่าช้า") else None)})
    sheets += [
        {"title": "หัวข้อที่พบ NG", "subtitle": sub, "headers": ["เวลา", "โรงงาน", "เครื่อง", "หัวข้อ", "ค่า", "เกณฑ์", "หมายเหตุ",
                                                                "ผู้ตรวจ", "งานแก้ไข"],
         "rows": [[S.parse_ts(n["finished_at"]).strftime("%d/%m %H:%M"), n["factory"] or "", n["eq_code"] or n["form_name"], n["item"],
                   f"{n['value_text']} {n['unit'] or ''}".strip(), n["spec"], n["remark"] or "", n["inspector"] or "",
                   n["capa"] or ""] for n in rep["ng"]],
         "widths": [12, 12, 12, 28, 12, 12, 34, 16, 24], "highlight": lambda r: "ng"},
        {"title": "ขาดตรวจ", "subtitle": sub, "headers": ["รอบ", "โรงงาน", "เครื่อง", "แบบฟอร์ม"],
         "rows": [[S.parse_ts(m["due_at"]).strftime("%d/%m %H:%M"), m["factory"] or "", m["eq_code"] or "", m["form_name"]]
                  for m in rep["missed"]], "widths": [14, 14, 12, 40]},
        {"title": "แจ้งเตือน", "subtitle": sub, "headers": ["เวลา", "ระดับ", "รายการ", "สถานะ", "ครั้ง", "สาเหตุ", "การแก้ไข"],
         "rows": [[S.parse_ts(a["created_at"]).strftime("%d/%m %H:%M"), SEV_TH.get(a["severity"], a["severity"]), a["title"],
                   STATUS_TH.get(a["status"], a["status"]), a["occurrences"], a["root_cause"] or "", a["action_taken"] or ""]
                  for a in rep["alerts"]], "widths": [12, 9, 44, 13, 7, 28, 28],
         "highlight": lambda r: "ng" if r[1] == "วิกฤต" else None},
        {"title": "งานแก้ไข (CAPA)", "subtitle": sub, "headers": ["เลขที่", "งาน", "เครื่อง", "ผู้รับผิดชอบ", "กำหนดเสร็จ", "สถานะ"],
         "rows": [[c["code"], c["title"], c["eq_code"] or "", c["owner"] or "", c["due_date"] or "",
                   CAPA_TH.get(c["status"], c["status"]) + (" (เลยกำหนด)" if c["overdue"] else "")] for c in rep["capa"]],
         "widths": [16, 50, 12, 18, 12, 22], "highlight": lambda r: "ng" if "เลยกำหนด" in r[5] else None},
        {"title": "ผู้ตรวจ", "subtitle": sub, "headers": ["ผู้ตรวจ", "ส่งผลตรวจ", "ตรงเวลา", "ล่าช้า", "เวลาเฉลี่ย (นาที)", "พบ NG"],
         "rows": [[i["name"], i["subs"], i["on_time"] or 0, i["late"] or 0, round(i["avg_sec"] / 60, 1) if i["avg_sec"] else "",
                   i["ng"] or 0] for i in rep["inspectors"]], "widths": [24, 12, 10, 10, 16, 10]},
    ]
    return workbook(sheets)


def filename(rep: dict, ext: str) -> str:
    stamp = rep["d_from"].strftime("%Y-%m") if rep["kind"] == "monthly" else (
        f"{rep['d_from'].isoformat()}_{rep['d_to'].isoformat()}" if rep["kind"] == "weekly" else rep["d_from"].isoformat())
    return f"echecksheet_{rep['kind']}_{stamp}{('_F' + str(rep['factory_id'])) if rep['factory_id'] else ''}.{ext}"
