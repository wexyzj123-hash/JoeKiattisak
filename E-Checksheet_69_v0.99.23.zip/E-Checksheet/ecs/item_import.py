"""ecs/item_import.py — นำเข้าหัวข้อตรวจจากไฟล์ (PDF / Excel / CSV / TXT) → ข้อความรูปแบบ "วางหลายหัวข้อ"

ผลลัพธ์ 1 บรรทัด = 1 หัวข้อ:   ชื่อ | หน่วย | Min | Max      (ไม่มีหน่วย/ค่า = OK/NG)   ·   "# ชื่อกลุ่ม" = กลุ่มหัวข้อ
ผู้ใช้ตรวจ/แก้ในกล่องข้อความก่อนกด "เพิ่มหัวข้อ" เสมอ (ไฟล์แต่ละโรงงานหน้าตาไม่เหมือนกัน)
PDF ที่เป็นภาพสแกน (ไม่มีข้อความ) อ่านไม่ได้ — ต้องใช้ไฟล์ Excel หรือพิมพ์เอง
"""
from __future__ import annotations

import csv
import io
import re

MAX_ITEMS = 300
NUM = r"[-+]?\d+(?:[.,]\d+)?"
UNITS = (r"kgf/cm2|kgf/cm²|kg/cm2|kg/cm²|kgf|mpa|kpa|bar|psi|°c|℃|°f|deg\.?c|c°|%rh|%|rpm|a|amp|v|volt|kw|kva|kvar|kwh|hz|"
         r"mm|cm|m3/h|m3|m³|l/min|lpm|l|ml|ppm|mg/l|µs/cm|us/cm|ntu|hr|hrs|h|min|sec|s|db|lux|mm/s|ph")
UNIT_RE = re.compile(rf"(?<![A-Za-z])({UNITS})(?![A-Za-z])", re.I)
RANGE_RE = re.compile(rf"({NUM})\s*(?:-|–|~|to|ถึง|÷)\s*({NUM})", re.I)
MAX_RE = re.compile(rf"(?:≤|<=|<|max\.?|ไม่เกิน|สูงสุด|not\s+more\s+than|nmt)\s*({NUM})|({NUM})\s*(?:max\.?|สูงสุด)", re.I)
MIN_RE = re.compile(rf"(?:≥|>=|>|min\.?|ไม่น้อยกว่า|ต่ำสุด|at\s+least|nlt)\s*({NUM})|({NUM})\s*(?:min\.?|ต่ำสุด)", re.I)
OKNG_RE = re.compile(r"\b(ok\s*/\s*ng|o\s*/\s*x|normal\s*/\s*abnormal|good\s*/\s*no\s*good)\b|ปกติ\s*/\s*ผิดปกติ|✓|✔", re.I)
NUMBERING_RE = re.compile(r"^\s*(?:ข้อ\s*)?(?:(?:\(?\d{1,3}[.)]\d{0,2}[.)]?|\(?[a-zA-Zก-ฮ][.)]|\d{1,3})\s+|\d{1,3}(?=[ก-ฮเแโใไ]))")
HEAD_ROW_RE = re.compile(r"^(no\.?|ลำดับ|ที่)?\s*(item|check\s*item|check\s*point|หัวข้อ|รายการ(ตรวจ)?|จุดตรวจ)"
                         r"(\s+(standard|spec|criteria|เกณฑ์|มาตรฐาน|unit|หน่วย|method|วิธี(การ)?(ตรวจ)?|result|ผล|min|max))+$", re.I)
TITLE_RE = re.compile(r"check\s*-?\s*sheet|เช็ค\s*ชี[ทต]|แบบฟอร์มตรวจ|แบบบันทึก", re.I)
SKIP_RE = re.compile(r"(document\s*no|doc\.?\s*no|rev(ision)?\s*[:.]|page\s*\d|หน้า\s*\d|checked\s*by|approved\s*by|inspected\s*by|"
                     r"prepared\s*by|ลงชื่อ|ผู้ตรวจ\s*[:：]|ผู้อนุมัติ|หัวหน้างาน\s*[:：]|วันที่\s*[:：]|date\s*[:：]|month\s*[:：]|"
                     r"เดือน\s*[:：]|shift\s*[:：]|กะ\s*[:：]|signature|^(ผู้ตรวจ(สอบ)?|ผู้บันทึก|ผู้อนุมัติ|หัวหน้า(งาน)?|inspector|checker|operator|supervisor)$|remark\s*[:：]?$|หมายเหตุ\s*[:：]?$|^no\.?$|^item$|^รายการ$)", re.I)
HEADER_WORDS = {"name": ("item", "check item", "check point", "หัวข้อ", "รายการ", "รายการตรวจ", "จุดตรวจ", "description", "parameter"),
                "unit": ("unit", "หน่วย"), "min": ("min", "ต่ำสุด", "lower", "lsl"), "max": ("max", "สูงสุด", "upper", "usl"),
                "spec": ("spec", "standard", "criteria", "เกณฑ์", "มาตรฐาน", "ค่ามาตรฐาน", "range", "ค่าที่กำหนด")}


class ImportError_(ValueError):
    pass


def _num(s: str | None) -> str:
    if not s:
        return ""
    s = s.replace(",", ".")
    try:
        v = float(s)
    except ValueError:
        return ""
    return str(int(v)) if v == int(v) else str(v)


def _clean_unit(u: str) -> str:
    low = u.lower()
    return {"℃": "°C", "°c": "°C", "c°": "°C", "deg.c": "°C", "degc": "°C", "kg/cm2": "kgf/cm2", "kg/cm²": "kgf/cm2",
            "kgf/cm²": "kgf/cm2", "m³": "m3", "amp": "A", "a": "A", "v": "V", "volt": "V", "kw": "kW", "kwh": "kWh",
            "hz": "Hz", "mpa": "MPa", "kpa": "kPa", "ph": "pH", "hrs": "hr", "h": "hr"}.get(low, u)


def parse_spec(text: str) -> tuple[str, str, str, bool]:
    """คืน (unit, min, max, is_numeric) จากข้อความเกณฑ์"""
    t = text.replace("＜", "<").replace("＞", ">")
    unit = ""
    m = UNIT_RE.search(t)
    if m:
        unit = _clean_unit(m.group(1))
    mn = mx = ""
    r = RANGE_RE.search(t)
    if r:
        a, b = _num(r.group(1)), _num(r.group(2))
        if a and b:
            mn, mx = (a, b) if float(a) <= float(b) else (b, a)
    else:
        m1 = MAX_RE.search(t)
        m2 = MIN_RE.search(t)
        if m1:
            mx = _num(m1.group(1) or m1.group(2))
        if m2:
            mn = _num(m2.group(1) or m2.group(2))
    numeric = bool(mn or mx or (unit and unit not in ("%",) and not OKNG_RE.search(t)))
    return unit, mn, mx, numeric


def parse_line(raw: str) -> tuple[str, str] | None:
    """('section', ชื่อ) | ('item', บรรทัดรูปแบบ bulk) | None"""
    is_head = raw.rstrip().endswith((":", "："))
    line = re.sub(r"\s+", " ", raw.replace("\t", " ")).strip(" |:：-–_.•·*")
    if len(line) < 2 or SKIP_RE.search(line) or HEAD_ROW_RE.match(line) or TITLE_RE.search(line):
        return None
    if re.fullmatch(r"[\d\s./-]+", line):                    # เลขวันที่ 1 2 3 … 31 / เลขหน้า
        return None
    if re.search(r"(?:\b\d{1,2}\b\s+){8,}", line):            # หัวตารางวันที่ของเช็คชีตรายเดือน
        line = re.sub(r"(?:\b\d{1,2}\b\s*){8,}.*$", "", line).strip()
        if len(line) < 2 or HEAD_ROW_RE.match(line):
            return None
    line = NUMBERING_RE.sub("", line).strip()
    if is_head and len(line) <= 60 and not re.search(NUM + r"\s*(?:-|~)", line):
        return ("section", line)
    # แยกชื่อกับเกณฑ์: เกณฑ์เริ่มที่ตัวเลข/สัญลักษณ์เปรียบเทียบ/คำว่า OK/NG ตัวแรกที่อยู่หลังชื่อ
    m = re.search(rf"(?:\s|^)(?=(?:{NUM}\s*(?:-|–|~|to|ถึง)\s*{NUM})|≤|≥|<|>|max|min|ไม่เกิน|ไม่น้อยกว่า|ok\s*/|o\s*/\s*x|ปกติ\s*/|✓|✔)",
                  line, re.I)
    name, spec = (line[:m.start()].strip(), line[m.start():]) if m and m.start() > 1 else (line, "")
    if not spec:
        # ชื่อ + หน่วยท้ายบรรทัด เช่น "Running hour  hr"
        um = re.search(rf"\s({UNITS})$", line, re.I)
        if um and len(line) - len(um.group(0)) > 2:
            name, spec = line[:um.start()].strip(), um.group(1)
    name = name.strip(" |:-–")
    if len(name) < 2 or not re.search(r"[A-Za-zก-๙]", name):
        return None
    if len(name) > 150:
        name = name[:150]
    unit, mn, mx, numeric = parse_spec(spec) if spec else ("", "", "", False)
    if numeric:
        return ("item", f"{name} | {unit} | {mn} | {mx}")
    return ("item", name)


def lines_to_bulk(lines: list[str]) -> tuple[str, int]:
    out, seen, n = [], set(), 0
    for raw in lines:
        res = parse_line(raw)
        if not res:
            continue
        kind, val = res
        key = val.lower()
        if kind == "section":
            out.append(f"# {val}")
            continue
        if key in seen:
            continue
        seen.add(key)
        out.append(val)
        n += 1
        if n >= MAX_ITEMS:
            break
    # ตัดหัวข้อกลุ่มที่ไม่มีรายการตามมา
    cleaned = [ln for i, ln in enumerate(out) if not (ln.startswith("#") and (i + 1 == len(out) or out[i + 1].startswith("#")))]
    return "\n".join(cleaned), n


# ฟอนต์ไทยใน PDF (Windows/Office) มักเก็บสระ-วรรณยุกต์เป็นตัวอักษรพิเศษ (Private Use Area U+F700–F71A) → แปลงกลับเป็นอักษรไทยปกติ
_THAI_PUA = dict(zip(range(0xF700, 0xF71B), "\u0e10\u0e34\u0e35\u0e36\u0e37\u0e48\u0e49\u0e4a\u0e4b\u0e4c"
                                              "\u0e48\u0e49\u0e4a\u0e4b\u0e4c\u0e0d\u0e31\u0e4d\u0e47"
                                              "\u0e48\u0e49\u0e4a\u0e4b\u0e4c\u0e38\u0e39\u0e3a"))
_TONE_BEFORE_VOWEL = re.compile("([\u0e48-\u0e4c])([\u0e31\u0e34-\u0e3a\u0e47])")


def fix_thai(text: str) -> str:
    """แก้อักษรไทยเพี้ยนจาก PDF: แปลงอักษรพิเศษ + เรียงวรรณยุกต์ไว้หลังสระบน/ล่าง + ํา → ำ"""
    text = text.translate(_THAI_PUA)
    text = _TONE_BEFORE_VOWEL.sub(r"\2\1", text)
    return text.replace("\u0e4d\u0e32", "\u0e33")


def pdf_lines(data: bytes) -> list[str]:
    try:
        from pypdf import PdfReader
    except ImportError:
        raise ImportError_("เซิร์ฟเวอร์ยังไม่ได้ติดตั้ง pypdf: python -m pip install pypdf") from None
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            reader.decrypt("")
        lines = []
        for page in reader.pages[:40]:
            try:
                text = page.extract_text(extraction_mode="layout") or ""
            except TypeError:                                 # pypdf รุ่นเก่า
                text = page.extract_text() or ""
            for ln in fix_thai(text).splitlines():
                # ตารางใน PDF: ช่องว่างยาว = คั่นคอลัมน์
                parts = [p.strip() for p in re.split(r"\s{3,}", ln) if p.strip()]
                if parts:
                    lines.append(" ".join(parts) if len(parts) <= 1 else _join_cells(parts))
    except ImportError_:
        raise
    except Exception:
        raise ImportError_("อ่านไฟล์ PDF ไม่ได้ (ไฟล์อาจเสียหรือมีรหัสผ่าน)") from None
    if not any(re.search(r"[A-Za-zก-๙]", ln) for ln in lines):
        raise ImportError_("PDF นี้เป็นภาพสแกน (ไม่มีข้อความให้อ่าน) — ใช้ไฟล์ Excel/Word ต้นฉบับ หรือพิมพ์หัวข้อเอง")
    return lines


def _join_cells(cells: list[str]) -> str:
    """แถวตาราง → 'ชื่อ เกณฑ์' (ข้ามช่องที่เป็นลำดับเลข และช่องเช็ควันที่)"""
    cells = [c for c in cells if not re.fullmatch(r"\d{1,3}[.)]?", c)] or cells
    return " ".join(cells)


def table_lines(rows: list[list[str]]) -> list[str]:
    """ตาราง (Excel/CSV) → บรรทัด: ถ้าเจอหัวตาราง (หัวข้อ/หน่วย/Min/Max/เกณฑ์) ใช้ตามคอลัมน์"""
    rows = [[str(c).strip() if c is not None else "" for c in r] for r in rows]
    rows = [r for r in rows if any(r)]
    head_idx, cols = None, {}
    for i, r in enumerate(rows[:15]):
        found = {}
        for j, c in enumerate(r):
            low = c.lower()
            for key, words in HEADER_WORDS.items():
                if key not in found and any(low == w or low.startswith(w) for w in words):
                    found[key] = j
        if "name" in found and len(found) >= 2:
            head_idx, cols = i, found
            break
    lines = []
    if head_idx is None:
        for r in rows:
            lines.append(_join_cells([c for c in r if c]))
        return lines
    for r in rows[head_idx + 1:]:
        get = lambda k: r[cols[k]] if k in cols and cols[k] < len(r) else ""  # noqa: E731
        name = get("name")
        if not name:
            continue
        if not any(get(k) for k in ("unit", "min", "max", "spec")) and name.endswith((":", "：")):
            lines.append(name)
            continue
        if "min" in cols or "max" in cols:
            unit = get("unit")
            mn, mx = _num(get("min")), _num(get("max"))
            spec = get("spec")
            if spec and not (mn or mx):
                u2, mn, mx, _ = parse_spec(spec)
                unit = unit or u2
            if unit or mn or mx:
                lines.append(f"{name} ||| {unit} ||| {mn} ||| {mx}")
                continue
        lines.append(" ".join(x for x in (name, get("spec"), get("unit")) if x))
    return lines


def extract(filename: str, data: bytes) -> dict:
    name = (filename or "").lower()
    if not data:
        raise ImportError_("ไฟล์ว่างเปล่า")
    if data[:5] == b"%PDF-" or name.endswith(".pdf"):
        lines = pdf_lines(data)
    elif data[:2] == b"PK" or name.endswith((".xlsx", ".xlsm")):
        try:
            from openpyxl import load_workbook
            wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
            ws = wb.worksheets[0]
            lines = table_lines([list(r) for r in ws.iter_rows(max_row=600, values_only=True)])
        except Exception:
            raise ImportError_("อ่านไฟล์ Excel ไม่ได้ (รองรับ .xlsx)") from None
    else:
        if name.rsplit(".", 1)[-1] not in ("csv", "txt", "tsv", name) or b"\x00" in data[:4096]:
            raise ImportError_("รองรับไฟล์ PDF, Excel (.xlsx), CSV หรือ TXT")
        text = None
        for enc in ("utf-8-sig", "cp874", "tis-620"):
            try:
                text = data.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        if text is None:
            raise ImportError_("รองรับไฟล์ PDF, Excel (.xlsx), CSV หรือ TXT")
        if name.endswith(".csv") or text.count(",") > text.count("\n"):
            lines = table_lines(list(csv.reader(io.StringIO(text))))
        else:
            lines = text.splitlines()
    # บรรทัดที่มาจากตารางมีรูปแบบแน่นอนแล้ว (ชื่อ ||| หน่วย ||| min ||| max) → ไม่ต้องเดา
    direct, guess = [], []
    for ln in lines:
        if " ||| " in ln:
            name, unit, mn, mx = (ln.split(" ||| ") + ["", "", ""])[:4]
            direct.append(f"{name.strip()} | {unit.strip()} | {mn.strip()} | {mx.strip()}")
        else:
            guess.append(ln)
    text, n = lines_to_bulk(guess) if guess else ("", 0)
    if direct:
        text = "\n".join(direct + ([text] if text else []))
        n += len(direct)
    if not n:
        raise ImportError_("ไม่พบรายการหัวข้อตรวจในไฟล์นี้")
    return {"text": text, "count": n, "source_lines": len(lines)}
