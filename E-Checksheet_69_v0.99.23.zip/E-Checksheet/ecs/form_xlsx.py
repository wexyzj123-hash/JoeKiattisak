"""ecs/form_xlsx.py — ส่งออก / นำเข้าแบบฟอร์มเป็น Excel

ส่งออก: 1 แบบฟอร์ม = 1 ไฟล์ (ชีท "หัวข้อตรวจ" · "จุดตรวจ" · "ข้อมูลแบบฟอร์ม" · "วิธีใช้")
  - ใช้แก้หัวข้อจำนวนมากใน Excel แล้วนำเข้ากลับ หรือเก็บเป็นไฟล์สำรองแบบฟอร์ม
  - คอลัมน์ "รหัสหัวข้อ" ห้ามแก้ — ใช้จับคู่หัวข้อเดิม (ประวัติผลตรวจ/กราฟต่อเนื่อง) · แถวใหม่ปล่อยว่างได้
  - มีรายการให้เลือก (Data Validation) สำหรับประเภท / ความถี่ / ใช่-ไม่ใช่
นำเข้า:
  - เข้า "ฉบับร่าง" ของแบบฟอร์มเดิม (ต้องกด Publish เองหลังตรวจดู) — ตรวจทุกแถวก่อน มีผิดแม้แถวเดียว = ไม่บันทึกอะไรเลย
  - หรือสร้างเป็นแบบฟอร์มใหม่ (ใช้กู้คืนจากไฟล์สำรอง / คัดลอกข้ามเครื่อง)
"""
from __future__ import annotations

import io
import json
from datetime import datetime

from . import services as S
from .itemfreq import FREQS
from .services import ValidationError

TYPE_TH = {"ok_ng": "OK/NG", "number": "ตัวเลข", "counter": "มิเตอร์สะสม", "choice": "ตัวเลือก", "text": "ข้อความ"}
TYPE_IN = {v.lower(): k for k, v in TYPE_TH.items()} | {k: k for k in TYPE_TH} | {
    "ok / ng": "ok_ng", "okng": "ok_ng", "ok-ng": "ok_ng", "number": "number", "ค่าวัด": "number", "มิเตอร์": "counter",
    "counter": "counter", "choice": "choice", "text": "text"}
FREQ_TH = dict(FREQS)                               # '' → ทุกรอบ ...
FREQ_IN = {v: k for k, v in FREQ_TH.items()} | {k: k for k in FREQ_TH if k}
YES = {"y", "yes", "ใช่", "1", "true", "✓", "x", "บังคับ"}
COLS = [  # (key, หัวคอลัมน์, ความกว้าง)
    ("item_key", "รหัสหัวข้อ (ห้ามแก้)", 16),
    ("section", "จุดตรวจ / หมวด", 22),
    ("name", "ชื่อหัวข้อตรวจ *", 44),
    ("item_type", "ประเภท *", 13),
    ("unit", "หน่วย", 9),
    ("min_value", "Min", 8),
    ("max_value", "Max", 8),
    ("warn_low", "เตือนต่ำ", 9),
    ("warn_high", "เตือนสูง", 9),
    ("counter_max_step", "มิเตอร์เพิ่มสูงสุด/ครั้ง", 12),
    ("options", "ตัวเลือก (คั่นด้วย | ใส่ * ท้ายตัวที่ NG)", 30),
    ("required", "บังคับกรอก", 9),
    ("critical", "วิกฤต", 8),
    ("photo_on_ng", "NG ต้องแนบรูป", 10),
    ("photo_required", "แนบรูปทุกครั้ง", 10),
    ("check_freq", "ความถี่", 17),
    ("check_times", "เวลา (ถ้า 'ตามเวลาที่กำหนด')", 16),
    ("guide", "คำแนะนำ / วิธีตรวจ", 36),
]
MAX_ROWS = 500


def _iv_label(code) -> str:
    from .itemfreq import interval_label
    return interval_label(code or "")


def _iv_in(text: str) -> str | None:
    """'w:2' / 'ทุก 2 สัปดาห์' / 'ทุก 3 วัน' / 'ทุก 2 เดือน' → รหัสความถี่แบบช่วง (v0.32)"""
    import re as _re

    from .itemfreq import interval
    t = str(text or "").strip()
    if interval(t):
        return t
    m = _re.match(r"^ทุก\s*(\d{1,3})\s*(วัน|สัปดาห์|อาทิตย์|เดือน)$", t)
    if m:
        code = {"วัน": "d", "สัปดาห์": "w", "อาทิตย์": "w", "เดือน": "m"}[m.group(2)] + ":" + m.group(1)
        return code if interval(code) else None
    return None


def _yn(v) -> str:
    return "ใช่" if v else ""


def _g(v):
    if v is None:
        return None
    return int(v) if float(v).is_integer() else v


# ───────────────────────── ส่งออก ─────────────────────────

def export_form(db, form_id: int, use_draft: bool = False) -> tuple[bytes, str]:
    from openpyxl import Workbook
    from openpyxl.comments import Comment
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter as L
    from openpyxl.worksheet.datavalidation import DataValidation

    form = S.get_form(db, form_id)
    if not form:
        raise ValidationError("ไม่พบแบบฟอร์ม")
    draft = S.get_draft(db, form_id) if use_draft else None
    vid = draft["id"] if draft else form["current_version_id"]
    items = S.get_items(db, vid) if vid else []
    sections = S.get_sections(db, vid, items) if vid else []
    ver = db.execute("SELECT version_no, status FROM cs_form_versions WHERE id=?", (vid,)).fetchone() if vid else None

    wb = Workbook()
    ws = wb.active
    ws.title = "หัวข้อตรวจ"
    head_fill, key_fill = PatternFill("solid", fgColor="142A75"), PatternFill("solid", fgColor="E5E7EB")
    thin = Side(style="thin", color="CBD5E1")
    box = Border(left=thin, right=thin, top=thin, bottom=thin)
    for c, (_, title, width) in enumerate(COLS, 1):
        cell = ws.cell(1, c, title)
        cell.font = Font(bold=True, color="FFFFFF", name="Tahoma", size=10)
        cell.fill = head_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = box
        ws.column_dimensions[L(c)].width = width
    ws.row_dimensions[1].height = 36
    ws.cell(1, 1).comment = Comment("ใช้จับคู่หัวข้อเดิม เพื่อให้ประวัติผลตรวจ/กราฟต่อเนื่อง — ห้ามแก้ · แถวใหม่ปล่อยว่าง", "E-Checksheet")
    for r, it in enumerate(items, 2):
        opts = ""
        if it["item_type"] == "choice":
            opts = " | ".join(o["label"] + ("*" if o.get("ng") else "") for o in (it.get("options") or []))
        row = {"item_key": it["item_key"], "section": it.get("section") or "", "name": it["name"],
               "item_type": TYPE_TH.get(it["item_type"], it["item_type"]), "unit": it.get("unit") or "",
               "min_value": _g(it.get("min_value")), "max_value": _g(it.get("max_value")),
               "warn_low": _g(it.get("warn_low")), "warn_high": _g(it.get("warn_high")),
               "counter_max_step": _g(it.get("counter_max_step")), "options": opts,
               "required": _yn(it.get("required")), "critical": _yn(it.get("critical")),
               "photo_on_ng": _yn(it.get("photo_on_ng")), "photo_required": _yn(it.get("photo_required")),
               "check_freq": FREQ_TH.get(it.get("check_freq") or "", "") or _iv_label(it.get("check_freq")), "check_times": it.get("check_times") or "",
               "guide": it.get("guide") or ""}
        for c, (k, _, _) in enumerate(COLS, 1):
            cell = ws.cell(r, c, row[k])
            cell.border = box
            cell.font = Font(name="Tahoma", size=10, color="6B7280" if k == "item_key" else "111827")
            cell.alignment = Alignment(vertical="top", wrap_text=k in ("name", "guide", "options", "section"))
            if k == "item_key":
                cell.fill = key_fill
    last = max(len(items) + 1, 2) + 200                     # เผื่อแถวว่างสำหรับเพิ่มหัวข้อ
    def dv(formula: str, col: str, prompt: str):
        v = DataValidation(type="list", formula1=formula, allow_blank=True, showErrorMessage=True,
                           errorTitle="ค่าไม่ถูกต้อง", error="เลือกจากรายการ", promptTitle="เลือก", prompt=prompt)
        v.add(f"{col}2:{col}{last}")
        ws.add_data_validation(v)
    col = {k: L(i) for i, (k, _, _) in enumerate(COLS, 1)}
    dv('"' + ",".join(TYPE_TH.values()) + '"', col["item_type"], "ประเภทหัวข้อ")
    dv('"' + ",".join(FREQ_TH.values()) + '"', col["check_freq"], "ว่าง/ทุกรอบ = ขึ้นทุกรอบตรวจ")
    for k in ("required", "critical", "photo_on_ng", "photo_required"):
        dv('"ใช่,ไม่"', col[k], "ใช่ / ไม่ (ว่าง = ไม่)")
    ws.freeze_panes = "C2"
    ws.auto_filter.ref = f"A1:{L(len(COLS))}{max(len(items) + 1, 2)}"

    ws2 = wb.create_sheet("จุดตรวจ")
    for c, (t, w) in enumerate((("จุดตรวจ / หมวด", 30), ("ตำแหน่ง / คำแนะนำการหา (แสดงบนมือถือ)", 60)), 1):
        cell = ws2.cell(1, c, t)
        cell.font, cell.fill = Font(bold=True, color="FFFFFF", name="Tahoma"), head_fill
        ws2.column_dimensions[L(c)].width = w
    for r, s in enumerate(sections, 2):
        ws2.cell(r, 1, s["name"] or "")
        ws2.cell(r, 2, s.get("hint") or "")

    ws3 = wb.create_sheet("ข้อมูลแบบฟอร์ม")
    info = [("รหัสแบบฟอร์ม", form["code"]), ("ชื่อแบบฟอร์ม", form["name"]), ("เลขที่เอกสาร", form.get("doc_no") or ""),
            ("หมวดหมู่", form.get("category") or ""), ("เครื่องจักร", " ".join(x for x in (form.get("eq_code"), form.get("eq_name")) if x)),
            ("โรงงาน / พื้นที่", " › ".join(x for x in (form.get("factory_name"), form.get("area_name")) if x)),
            ("เวอร์ชันที่ส่งออก", f"v{ver['version_no']} ({'ฉบับร่าง' if ver['status'] == 'draft' else 'ใช้งาน'})" if ver else "-"),
            ("จำนวนหัวข้อ", len(items)),
            ("รอบตรวจ", " · ".join(s["description"] for s in S.list_schedules(db, form_id) if s["active"]) or "-"),
            ("ส่งออกเมื่อ", datetime.now().strftime("%d/%m/%Y %H:%M")), ("form_id", form["id"])]
    ws3.column_dimensions["A"].width, ws3.column_dimensions["B"].width = 20, 70
    for r, (k, v) in enumerate(info, 1):
        ws3.cell(r, 1, k).font = Font(bold=True, name="Tahoma")
        ws3.cell(r, 2, v)

    ws4 = wb.create_sheet("วิธีใช้")
    ws4.column_dimensions["A"].width = 110
    tips = [
        "วิธีแก้หัวข้อใน Excel แล้วนำเข้ากลับ",
        "1) แก้/เพิ่ม/ลบแถวในชีท 'หัวข้อตรวจ' ได้ตามต้องการ — ลำดับแถว = ลำดับที่แสดงบนมือถือ",
        "2) คอลัมน์ 'รหัสหัวข้อ' ห้ามแก้ (ใช้จับคู่ประวัติผลตรวจเดิม) · หัวข้อใหม่ปล่อยว่าง ระบบสร้างรหัสให้ · ลบแถว = ลบหัวข้อ",
        "3) ประเภท: " + " / ".join(TYPE_TH.values()) + " — Min/Max/เตือน/หน่วย ใช้กับตัวเลขและมิเตอร์สะสม",
        "4) ตัวเลือก: คั่นด้วย |  เช่น  สะอาด | ต้องเปลี่ยน*   (ใส่ * ท้ายตัวที่ถือเป็น NG)",
        "5) ความถี่: " + " / ".join(FREQ_TH.values()) + " — 'ตามเวลาที่กำหนด' ต้องใส่เวลา เช่น 08:00, 20:00",
        "6) ช่อง ใช่/ไม่: ใส่ 'ใช่' หรือเว้นว่าง · บังคับกรอก และ NG ต้องแนบรูป ค่าเริ่มต้นของหัวข้อใหม่ = ใช่",
        "7) ชีท 'จุดตรวจ' ใส่ตำแหน่ง/คำแนะนำของแต่ละจุด (ชื่อต้องตรงกับคอลัมน์ จุดตรวจ)",
        "8) นำเข้า: หน้าแบบฟอร์ม › หัวข้อตรวจ › 'นำเข้าจาก Excel' → ระบบตรวจทุกแถวก่อน ถ้าผิดจะแจ้งแถวที่ผิดและไม่บันทึก",
        "   ผลนำเข้าเป็น 'ฉบับร่าง' — ตรวจดูแล้วกด Publish เพื่อใช้งาน (ผลตรวจเก่าไม่เปลี่ยน)",
        "9) ใช้เป็นไฟล์สำรอง: จัดการ › แบบฟอร์ม › 'นำเข้าแบบฟอร์มใหม่จาก Excel' สร้างแบบฟอร์มใหม่จากไฟล์นี้ได้",
    ]
    for r, t in enumerate(tips, 1):
        c = ws4.cell(r, 1, t)
        c.font = Font(name="Tahoma", size=11, bold=(r == 1))
        c.alignment = Alignment(wrap_text=True)
    wb.active = 0
    buf = io.BytesIO()
    wb.save(buf)
    fname = f"{form['code'] or 'FORM'}-หัวข้อตรวจ-v{ver['version_no'] if ver else 0}.xlsx"
    return buf.getvalue(), fname


# ───────────────────────── นำเข้า ─────────────────────────

def _cell(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def parse_workbook(data: bytes) -> dict:
    """อ่านไฟล์ → {items, sections, info, errors} (ยังไม่บันทึก)"""
    from openpyxl import load_workbook
    try:
        wb = load_workbook(io.BytesIO(data), data_only=True, read_only=True)
    except Exception as exc:                         # noqa: BLE001 — ไฟล์เสีย/ไม่ใช่ xlsx
        raise ValidationError(f"เปิดไฟล์ Excel ไม่ได้ ({exc.__class__.__name__}) — ใช้ไฟล์ .xlsx ที่ส่งออกจากระบบ") from None
    ws = wb["หัวข้อตรวจ"] if "หัวข้อตรวจ" in wb.sheetnames else wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        raise ValidationError("ไฟล์ว่าง")
    head = [_cell(h) for h in rows[0]]
    idx = {}
    for key, title, _ in COLS:
        base = title.split(" (")[0].split(" *")[0].strip()
        for i, h in enumerate(head):
            if h == title or h.split(" (")[0].split(" *")[0].strip() == base:
                idx[key] = i
                break
    if "name" not in idx:
        raise ValidationError("ไม่พบคอลัมน์ 'ชื่อหัวข้อตรวจ' — ใช้ไฟล์ที่ส่งออกจากระบบเป็นต้นแบบ")
    items, errors, keys = [], [], set()
    for rn, row in enumerate(rows[1:], 2):
        get = lambda k: _cell(row[idx[k]]) if k in idx and idx[k] < len(row) else ""   # noqa: E731
        if not any(_cell(v) for v in row):
            continue
        if len(items) >= MAX_ROWS:
            errors.append(f"หัวข้อเกิน {MAX_ROWS} แถว")
            break
        name = get("name")
        if not name:
            errors.append(f"แถว {rn}: ไม่มีชื่อหัวข้อ")
            continue
        t_raw = get("item_type").lower()
        t = TYPE_IN.get(t_raw) if t_raw else "ok_ng"
        if not t:
            errors.append(f"แถว {rn} ({name[:30]}): ประเภท '{get('item_type')}' ไม่รู้จัก — ใช้ " + " / ".join(TYPE_TH.values()))
            continue
        f_raw = get("check_freq")
        freq = "" if f_raw in ("", "ทุกรอบ") else (FREQ_IN.get(f_raw) or _iv_in(f_raw))
        if freq is None:
            errors.append(f"แถว {rn} ({name[:30]}): ความถี่ '{f_raw}' ไม่รู้จัก")
            continue
        key = get("item_key")
        if key and key in keys:
            errors.append(f"แถว {rn} ({name[:30]}): รหัสหัวข้อ {key} ซ้ำกับแถวอื่น (คัดลอกแถวแล้วลืมลบรหัส?) — ลบรหัสของแถวใหม่ออก")
            continue
        if key:
            keys.add(key)
        opts = []
        if t == "choice":
            for part in get("options").replace("\n", "|").split("|"):
                p = part.strip()
                if p:
                    opts.append({"label": p.rstrip("*").strip(), "ng": 1 if p.endswith("*") else 0})

        def yn(k, default):
            v = get(k).lower()
            return default if v == "" and key == "" else (1 if v in YES else 0)
        items.append({"item_key": key, "section": get("section"), "name": name, "item_type": t, "unit": get("unit"),
                      "min_value": get("min_value"), "max_value": get("max_value"), "warn_low": get("warn_low"),
                      "warn_high": get("warn_high"), "counter_max_step": get("counter_max_step"), "options": opts,
                      "required": yn("required", 1), "critical": yn("critical", 0), "photo_on_ng": yn("photo_on_ng", 1),
                      "photo_required": yn("photo_required", 0), "check_freq": freq, "check_times": get("check_times"),
                      "guide": get("guide"), "_row": rn})
    # ตรวจรายละเอียดทุกแถว (ด้วยกติกาเดียวกับหน้า Builder) — รวม error ทุกแถวแจ้งทีเดียว
    for i, it in enumerate(items):
        try:
            S.normalize_item({k: v for k, v in it.items() if k != "_row"}, i)
        except ValidationError as exc:
            errors += [f"แถว {it['_row']}: " + e.split(": ", 1)[-1] for e in exc.errors]
    sections = []
    if "จุดตรวจ" in wb.sheetnames:
        for row in list(wb["จุดตรวจ"].iter_rows(values_only=True))[1:]:
            if row and (_cell(row[0]) or (len(row) > 1 and _cell(row[1]))):
                sections.append({"name": _cell(row[0]), "hint": _cell(row[1]) if len(row) > 1 else ""})
    info = {}
    if "ข้อมูลแบบฟอร์ม" in wb.sheetnames:
        for row in wb["ข้อมูลแบบฟอร์ม"].iter_rows(values_only=True):
            if row and row[0]:
                info[_cell(row[0])] = _cell(row[1]) if len(row) > 1 else ""
    if not items and not errors:
        errors.append("ไม่พบหัวข้อตรวจในไฟล์")
    for it in items:
        it.pop("_row", None)
    return {"items": items, "sections": sections, "info": info, "errors": errors}


def import_into_form(db, form_id: int, data: bytes, actor_id) -> dict:
    """นำเข้าเป็นฉบับร่างของแบบฟอร์มเดิม — คืนสรุปการเปลี่ยนแปลง"""
    form = S.get_form(db, form_id)
    if not form:
        raise ValidationError("ไม่พบแบบฟอร์ม")
    if form.get("template_id"):
        raise ValidationError("แบบฟอร์มนี้ใช้แม่แบบ — นำเข้าที่แม่แบบแทน")
    res = parse_workbook(data)
    if res["errors"]:
        raise ValidationError(res["errors"][:30] + ([f"… และอีก {len(res['errors']) - 30} รายการ"] if len(res["errors"]) > 30 else []))
    cur = {i["item_key"]: i for i in (S.get_items(db, form["current_version_id"]) if form["current_version_id"] else [])}
    unknown = [it["item_key"] for it in res["items"] if it["item_key"] and it["item_key"] not in cur]
    for it in res["items"]:                     # รหัสจากแบบฟอร์มอื่น (คัดลอกไฟล์มาใช้) → ถือเป็นหัวข้อใหม่
        if it["item_key"] in unknown:
            it["item_key"] = ""
    draft = S.get_or_create_draft(db, form_id, actor_id)
    n = S.save_draft_items(db, draft["id"], res["items"], actor_id)
    if res["sections"]:
        S.save_sections(db, draft["id"], res["sections"])
    kept = sum(1 for it in res["items"] if it["item_key"] in cur)
    S.audit(db, actor_id, "import_xlsx", "cs_forms", form_id, after={"items": n, "kept": kept})
    return {"items": n, "kept": kept, "new": n - kept, "removed": len(set(cur) - {it["item_key"] for it in res["items"]}),
            "draft_id": draft["id"]}


def import_new_form(db, data: bytes, actor_id, name: str = "") -> int:
    """สร้างแบบฟอร์มใหม่จากไฟล์ (กู้คืนจากไฟล์สำรอง) — ได้ฉบับร่าง รอ Publish"""
    res = parse_workbook(data)
    if res["errors"]:
        raise ValidationError(res["errors"][:30])
    title = (name or res["info"].get("ชื่อแบบฟอร์ม") or "แบบฟอร์มนำเข้า").strip()
    fid = S.create_form(db, {"name": title, "category": res["info"].get("หมวดหมู่", "")}, actor_id)
    if res["info"].get("เลขที่เอกสาร"):
        S.update_form_meta(db, fid, {"doc_no": res["info"]["เลขที่เอกสาร"]}, actor_id)
    for it in res["items"]:
        it["item_key"] = ""
    draft = S.get_draft(db, fid)
    S.save_draft_items(db, draft["id"], res["items"], actor_id)
    if res["sections"]:
        S.save_sections(db, draft["id"], res["sections"])
    S.audit(db, actor_id, "import_xlsx_new", "cs_forms", fid, after={"items": len(res["items"])})
    return fid

