"""ecs/security.py — รหัสผ่าน, CSRF, ตรวจสิทธิ์ตามบทบาท"""
from __future__ import annotations

import hashlib
import hmac
import secrets
from functools import wraps

from flask import abort, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

CSRF_KEY = "_csrf"
ROLE_TH = {"admin": "ผู้ดูแลระบบ", "supervisor": "หัวหน้างาน", "technician": "ช่างผู้ตรวจ", "viewer": "ผู้ดูข้อมูล"}
MANAGE_ROLES = ("admin", "supervisor")
# ธีมสี (ชื่อเดียวกับ UT-CMMS) — auto = ตามโหมดสว่าง/มืดของเครื่อง
THEMES = (("ocean", "Ocean", "#060b16", "#0d1526", "#3b82f6"), ("emerald", "Emerald", "#05100b", "#0a1f15", "#10b981"),
          ("amethyst", "Amethyst", "#0b0616", "#150d26", "#8b5cf6"), ("crimson", "Crimson", "#100508", "#1f0d14", "#f43f5e"),
          ("sunset", "Sunset", "#100a05", "#1f160d", "#f97316"), ("slate", "Slate", "#0f1114", "#1a1d22", "#64748b"),
          ("light", "Light", "#f1f5f9", "#ffffff", "#2563eb"), ("sakura", "Sakura", "#fdf2f8", "#ffffff", "#db2777"),
          ("auto", "AISIN", "#f2f4f9", "#0b1220", "#142a75"),
          ("control", "ห้องควบคุม", "#040a1a", "#0a1631", "#5ab8ff"))           # v0.99.16 ธีมห้องควบคุม (พื้นเข้ม เรืองแสง)
THEME_IDS = {t[0] for t in THEMES} | {"dark"}
INSPECT_ROLES = ("admin", "supervisor", "technician")
ALL_ROLES = ("admin", "supervisor", "technician", "viewer")
MIN_PASSWORD = 8


# ── password ──
def hash_password(password: str) -> str:
    return generate_password_hash(password or "", method="pbkdf2:sha256:600000", salt_length=16)


def _is_legacy_sha256(stored: str) -> bool:
    return bool(stored) and len(stored) == 64 and all(c in "0123456789abcdef" for c in stored.lower())


def verify_password(stored: str, password: str) -> bool:
    """รองรับรหัสแบบใหม่ (PBKDF2) และแบบ SHA-256 ที่นำเข้าจากระบบเดิม"""
    if not stored:
        return False
    if _is_legacy_sha256(stored):
        return hmac.compare_digest(stored.lower(), hashlib.sha256((password or "").encode()).hexdigest())
    try:
        return check_password_hash(stored, password or "")
    except ValueError:
        return False


def needs_rehash(stored: str) -> bool:
    return _is_legacy_sha256(stored)


def password_problem(password: str) -> str | None:
    if len(password or "") < MIN_PASSWORD:
        return f"รหัสผ่านต้องมีอย่างน้อย {MIN_PASSWORD} ตัวอักษร"
    if password.isdigit() or password.isalpha():
        return "รหัสผ่านต้องมีทั้งตัวอักษรและตัวเลข"
    return None


# ── CSRF ──
def csrf_token() -> str:
    tok = session.get(CSRF_KEY)
    if not tok:
        tok = secrets.token_urlsafe(32)
        session[CSRF_KEY] = tok
    return tok


def check_csrf() -> None:
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    if request.endpoint in ("static",):
        return
    sent = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token") or ""
    expected = session.get(CSRF_KEY) or ""
    if not expected or not secrets.compare_digest(sent, expected):
        abort(400, description="CSRF token ไม่ถูกต้อง กรุณารีเฟรชหน้าแล้วลองใหม่")


# ── roles ──
def wants_json() -> bool:
    return request.path.startswith("/api/") or request.is_json or \
        "application/json" in (request.headers.get("Accept") or "")


def current_user_id() -> int | None:
    return session.get("user_id")


def current_role() -> str:
    return session.get("role") or ""


def require_role(*roles):
    """ต้อง login และ (ถ้าระบุ) มีบทบาทตามที่กำหนด"""
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                if wants_json():
                    return jsonify({"error": "กรุณาเข้าสู่ระบบใหม่", "code": "login_required"}), 401
                return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
            if roles and session.get("role") not in roles:
                if wants_json():
                    return jsonify({"error": "ไม่มีสิทธิ์ใช้งานส่วนนี้"}), 403
                return render_template("error.html", code=403,
                                       message="บัญชีของคุณไม่มีสิทธิ์ใช้งานหน้านี้"), 403
            return fn(*args, **kwargs)
        return wrapper
    return deco


def safe_next(url: str | None, default: str) -> str:
    if not url or not url.startswith("/") or url.startswith("//") or "\\" in url:
        return default
    root = request.script_root or ""          # เช่น /echeck เมื่อรวมอยู่ใน UT-CMMS
    if root and url != root and not url.startswith(root + "/"):
        url = root + url
    return url
