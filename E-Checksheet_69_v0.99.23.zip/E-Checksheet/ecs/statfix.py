"""ecs/statfix.py — v0.41 ความถูกต้องของสถิติตรวจตรงเวลา

1) relink_forms: แก้/เพิ่ม/ปิดรอบตรวจ → สร้างรอบย้อนหลังตามเงื่อนไขใหม่ ผูกผลตรวจที่ส่งแล้วเข้ากับรอบที่ถูกต้อง
   คำนวณ ตรงเวลา / ล่าช้า / ขาดตรวจ ใหม่ และลบรอบเดิมที่ไม่มีในตารางใหม่ (ผลตรวจไม่ถูกลบ)
2) exclude_stats / restore_stats: ผู้ดูแลระบบลบช่วงวันที่ออกจากสถิติ (Heatmap / อัตราตรวจตรงเวลารายวัน) และยกเลิกได้
3) แบบฟอร์มที่ไม่มีรอบตรวจเปิดใช้งาน ไม่นับในสถิติ (ดู services.scheduled_sql)
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta

from . import analytics as AN
from . import services as S
from .services import ValidationError, parse_ts, ts

DEFAULT_RELINK_DAYS = 31            # แก้รอบตรวจ → คำนวณย้อนหลังกี่วัน (ตั้งได้ที่ cs_meta.relink_days)
MAX_RANGE_DAYS = 400
OPEN = ("pending", "in_progress", "overdue")


def relink_days(db) -> int:
    row = db.execute("SELECT value FROM cs_meta WHERE key='relink_days'").fetchone()
    try:
        return max(1, min(MAX_RANGE_DAYS, int(row[0]))) if row else DEFAULT_RELINK_DAYS
    except (TypeError, ValueError):
        return DEFAULT_RELINK_DAYS


def _expand(db, form_ids) -> list[int]:
    """แม่แบบไม่มีรอบตรวจของตัวเอง → ใช้แบบฟอร์มของเครื่องที่ใช้แม่แบบนั้นแทน"""
    out: list[int] = []
    for fid in {int(x) for x in form_ids if x}:
        f = db.execute("SELECT id, is_template FROM cs_forms WHERE id=?", (fid,)).fetchone()
        if not f:
            continue
        if f["is_template"]:
            out += [r[0] for r in db.execute("SELECT id FROM cs_forms WHERE template_id=?", (fid,))]
        else:
            out.append(fid)
    return sorted(set(out))


def _close_missed_alerts(db, round_ids: list[int], actor_id, now_s: str, note: str) -> int:
    """ปิดแจ้งเตือนของรอบที่ไม่ขาดตรวจแล้ว / รอบที่ถูกลบ (ขาดตรวจ · เลยกำหนด) — ไม่แตะ 'รออนุมัติ'"""
    from .anomaly import OPEN_STATUSES
    n = 0
    for rid in round_ids:
        for a in db.execute(f"""SELECT id FROM cs_alerts WHERE alert_type IN ('missed','overdue') AND round_id=?
                                AND status IN ({','.join('?' * len(OPEN_STATUSES))})""", (rid, *OPEN_STATUSES)).fetchall():
            db.execute("UPDATE cs_alerts SET status='closed', closed_by=?, closed_at=?, close_note=?, updated_at=? WHERE id=?",
                       (actor_id, now_s, note[:500], now_s, a["id"]))
            db.execute("INSERT INTO cs_alert_events(alert_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
                       (a["id"], "close", actor_id, note[:500], now_s))
            n += 1
    return n


def _drop_round(db, rid: int) -> None:
    db.execute("UPDATE cs_submissions SET round_id=NULL WHERE round_id=?", (rid,))
    db.execute("UPDATE cs_alerts SET round_id=NULL WHERE round_id=?", (rid,))
    db.execute("DELETE FROM cs_rounds WHERE id=?", (rid,))


def _relink_one(db, fid: int, day_from: date, day_to: date, now: datetime, holidays, excl, rstart: datetime,
                actor_id, st: dict) -> None:
    from .submissions import EARLY_START_MIN
    f = db.execute("""SELECT f.*, COALESCE(e.area_id, f.area_id) AS f_area FROM cs_forms f
                      LEFT JOIN equipment e ON e.id=f.equipment_id WHERE f.id=?""", (fid,)).fetchone()
    if not f:
        return
    start_s = ts(datetime.combine(day_from, time(0, 0)))
    end_s = ts(datetime.combine(day_to + timedelta(days=1), time(0, 0)))
    now_s = ts(now)
    usable = f["active"] and not f["is_template"] and f["current_version_id"]

    # ── รอบที่ควรมีตามรอบตรวจที่เปิดใช้งานอยู่ตอนนี้ ──
    want: dict[tuple, dict] = {}
    if usable:
        for srow in db.execute("SELECT * FROM cs_schedules WHERE form_id=? AND active=1", (fid,)).fetchall():
            s = dict(srow)
            for due in S.occurrences(s, day_from, day_to, holidays):
                if due < rstart or (excl and S.is_excluded(excl, f["factory_id"], f["f_area"], fid, due.date())):
                    continue
                deadline, close = S.round_window(s, due, holidays)
                want[(s["id"], ts(due))] = {"schedule_id": s["id"], "due": due, "deadline": deadline, "close": close}

    existing = [dict(r) for r in db.execute("""SELECT * FROM cs_rounds WHERE form_id=? AND due_at>=? AND due_at<?""",
                                            (fid, start_s, end_s))]
    range_ids = {r["id"] for r in existing}
    slots: list[dict] = []
    gone: list[dict] = []
    for r in existing:
        key = (r["schedule_id"], r["due_at"])
        if r["status"] == "returned":                     # ถูกตีกลับรอแก้ไข → ไม่ยุ่ง
            want.pop(key, None)
            continue
        w = want.pop(key, None)
        if w is None:
            gone.append(r)
            continue
        cl = ts(w["close"])                               # v0.99.9 ตรวจกับช่วงหยุดตามเวลาปิดรอบใหม่ทุกครั้ง
        slots.append({**w, "row": r, "skipped": not r["submission_id"] and (S.down_covers(db, fid, cl) or (
            r["status"] == "skipped" and not S.down_known(db, fid)))})
    for key, w in want.items():
        slots.append({**w, "row": None, "skipped": S.down_covers(db, fid, ts(w["close"]))})
    slots.sort(key=lambda x: x["due"])

    # ── ผลตรวจที่ต้องจัดเข้ารอบ ──
    early = timedelta(minutes=EARLY_START_MIN)
    subs = []
    for sb in db.execute("""SELECT id, round_id, finished_at FROM cs_submissions WHERE form_id=? AND status='submitted'
                            AND finished_at>=? AND finished_at<?""",
                         (fid, ts(datetime.combine(day_from, time(0, 0)) - early), end_s)).fetchall():
        if sb["round_id"] and sb["round_id"] not in range_ids:
            continue                                      # ผูกกับรอบก่อนช่วงนี้ → คงไว้
        fin = parse_ts(sb["finished_at"])
        if fin:
            subs.append({"id": sb["id"], "round_id": sb["round_id"], "fin": fin})
    subs.sort(key=lambda x: x["fin"])
    taken: dict[int, dict] = {}                           # index ของ slot → ผลตรวจ
    by_row = {sl["row"]["id"]: i for i, sl in enumerate(slots) if sl["row"]}
    rest = []
    for sb in subs:                                       # 1) ผูกรอบเดิมที่ยังอยู่ในตารางใหม่ → คงไว้ (คำนวณตรงเวลา/ล่าช้าใหม่)
        i = by_row.get(sb["round_id"])
        if i is not None and i not in taken and slots[i]["due"] - early <= sb["fin"]:
            taken[i] = sb
        else:
            rest.append(sb)
    for sb in rest:                                       # 2) ที่เหลือ → รอบที่ตรวจทันเวลาก่อน แล้วจึงรอบที่ยังเปิดอยู่
        cand = [i for i, sl in enumerate(slots) if i not in taken and not sl["skipped"]
                and sl["due"] - early <= sb["fin"] < sl["close"]]
        on_time = [i for i in cand if sb["fin"] <= slots[i]["deadline"]]
        pick = on_time[0] if on_time else (cand[0] if cand else None)
        if pick is not None:
            taken[pick] = sb

    # ── บันทึก ──
    note = "คำนวณรอบตรวจใหม่หลังแก้รอบตรวจ — รอบนี้ไม่นับเป็นขาดตรวจแล้ว"
    linked_to: dict[int, int | None] = {}
    _close_missed_alerts(db, [r["id"] for r in gone], actor_id, now_s,
                         "รอบตรวจนี้ถูกยกเลิก/เปลี่ยนเวลาในตารางรอบตรวจ — ปิดแจ้งเตือนอัตโนมัติ")
    for r in gone:
        _drop_round(db, r["id"])
        st["deleted"] += 1
    for i, sl in enumerate(slots):
        sb = taken.get(i)
        due_s, dl_s, cl_s = ts(sl["due"]), ts(sl["deadline"]), ts(sl["close"])
        if sb:
            status = "done_on_time" if sb["fin"] <= sl["deadline"] else "done_late"
        elif sl["skipped"]:
            status = "skipped"
        elif sl["close"] <= now:
            status = "missed"
        elif sl["deadline"] <= now:
            status = "overdue"
        else:
            status = "in_progress" if sl["row"] and sl["row"]["status"] == "in_progress" else "pending"
        sub_id = sb["id"] if sb else None
        st[{"done_on_time": "on_time", "done_late": "late", "missed": "missed"}.get(status, "other")] += 1
        r = sl["row"]
        if r is None:
            upd = cl_s if status == "missed" else now_s      # ขาดตรวจย้อนหลัง: ไม่ส่งแจ้งเตือนซ้ำ (ดู anomaly.check_missed)
            notified = now_s if sl["due"] <= now else None
            cur = db.execute("""INSERT OR IGNORE INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status,
                                submission_id, updated_at, due_notified_at, overdue_notified_at, start_notified_at)
                                VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                             (sl["schedule_id"], fid, due_s, dl_s, cl_s, status, sub_id, upd, notified, notified, notified))
            if not cur.rowcount:
                continue
            rid = cur.lastrowid
            st["created"] += 1
        else:
            rid = r["id"]
            if (r["deadline_at"], r["close_at"], r["status"], r["submission_id"]) != (dl_s, cl_s, status, sub_id):
                upd = (cl_s if r["status"] != "missed" else r["updated_at"]) if status == "missed" else now_s
                db.execute("""UPDATE cs_rounds SET deadline_at=?, close_at=?, status=?, submission_id=?, updated_at=?
                              WHERE id=?""", (dl_s, cl_s, status, sub_id, upd, rid))
                st["changed"] += 1
                if r["status"] == "missed" and status != "missed":
                    _close_missed_alerts(db, [rid], actor_id, now_s, note)
        if sb:
            linked_to[sb["id"]] = rid
    for sb in subs:
        new_rid = linked_to.get(sb["id"])
        if new_rid != sb["round_id"]:
            db.execute("UPDATE cs_submissions SET round_id=? WHERE id=?", (new_rid, sb["id"]))
            st["relinked"] += 1


def relink_forms(db, form_ids, *, day_from: date | None = None, day_to: date | None = None,
                 now: datetime | None = None, actor_id=None, reason: str = "") -> dict:
    """คำนวณรอบตรวจของแบบฟอร์มใหม่ในช่วงวันที่ (ค่าเริ่มต้น: ย้อนหลัง relink_days วันถึงพรุ่งนี้)"""
    now = now or S.now_dt()
    ids = _expand(db, form_ids)
    rstart = S.rounds_start_dt(db, now)
    d_to = min(day_to or (now + timedelta(days=1)).date(), (now + timedelta(days=1)).date())
    d_from = day_from or (now - timedelta(days=relink_days(db))).date()
    d_from = max(d_from, rstart.date(), d_to - timedelta(days=MAX_RANGE_DAYS))
    st = {"forms": len(ids), "from": d_from.isoformat(), "to": d_to.isoformat(), "created": 0, "deleted": 0,
          "changed": 0, "relinked": 0, "on_time": 0, "late": 0, "missed": 0, "other": 0}
    if not ids or d_from > d_to:
        return st
    holidays, excl = S._holidays(db), S.stat_exclusions(db)
    for fid in ids:
        _relink_one(db, fid, d_from, d_to, now, holidays, excl, rstart, actor_id, st)
    # v0.99.9 เปลี่ยนรอบตรวจ → ตรวจรอบเครื่องหยุด/ขาดตรวจกับช่วงหยุดเครื่องย้อนหลังทั้งหมดของแบบฟอร์มเหล่านี้
    rec = S.reconcile_down_rounds(db, now, ids, actor_id)
    st["down_skipped"], st["down_restored"] = rec["down_skipped"], rec["down_restored"]
    AN.refresh_form_stats(db, ids)
    if st["created"] or st["deleted"] or st["changed"] or st["relinked"]:
        S.audit(db, actor_id, "relink", "cs_rounds", None, after={**st, "form_ids": ids[:50], "reason": reason[:200]})
    return st


def summary_th(st: dict) -> str:
    if not (st["created"] or st["deleted"] or st["changed"] or st["relinked"]):
        return "รอบตรวจย้อนหลังตรงกับเงื่อนไขอยู่แล้ว"
    return (f"คำนวณรอบตรวจย้อนหลังใหม่ ({st['from']} ถึง {st['to']}): ผูกผลตรวจใหม่ {st['relinked']} รายการ · "
            f"ตรงเวลา {st['on_time']} · ล่าช้า {st['late']} · ขาดตรวจ {st['missed']}")


# ───────────────────────── ผู้ดูแลระบบ: ลบ / คืนสถิติ ─────────────────────────

def _scope_forms(db, factory_id=None, area_id=None, form_id=None) -> list[int]:
    q = """SELECT f.id FROM cs_forms f LEFT JOIN equipment e ON e.id=f.equipment_id WHERE COALESCE(f.is_template,0)=0"""
    p: list = []
    if factory_id:
        q += " AND f.factory_id=?"
        p.append(factory_id)
    if area_id:
        q += " AND COALESCE(e.area_id, f.area_id)=?"
        p.append(area_id)
    if form_id:
        q += " AND f.id=?"
        p.append(form_id)
    return [r[0] for r in db.execute(q, p)]


def _check_range(day_from: date, day_to: date, today: date) -> None:
    if day_from > day_to:
        raise ValidationError("วันที่เริ่มต้องไม่หลังวันที่สิ้นสุด")
    if day_to >= today:
        raise ValidationError("ลบสถิติได้ถึงเมื่อวานเท่านั้น (รอบตรวจของวันนี้ยังต้องใช้งานอยู่)")
    if (day_to - day_from).days > MAX_RANGE_DAYS:
        raise ValidationError(f"ช่วงวันที่ยาวเกิน {MAX_RANGE_DAYS} วัน")


def exclude_impact(db, day_from: date, day_to: date, factory_id=None, area_id=None, form_id=None) -> dict:
    ids = _scope_forms(db, factory_id, area_id, form_id)
    out = {"forms": 0, "rounds": 0, "on_time": 0, "late": 0, "missed": 0, "skipped": 0, "with_sub": 0}
    if not ids:
        return out
    ph = ",".join("?" * len(ids))
    r = db.execute(f"""SELECT COUNT(*) n, COUNT(DISTINCT form_id) forms, SUM(status='done_on_time') ot,
                              SUM(status='done_late') late, SUM(status='missed') missed, SUM(status='skipped') sk,
                              SUM(submission_id IS NOT NULL) ws
                       FROM cs_rounds WHERE form_id IN ({ph}) AND due_at>=? AND due_at<?""",
                   ids + [ts(datetime.combine(day_from, time(0, 0))), ts(datetime.combine(day_to + timedelta(days=1), time(0, 0)))]
                   ).fetchone()
    return {"forms": r["forms"] or 0, "rounds": r["n"] or 0, "on_time": r["ot"] or 0, "late": r["late"] or 0,
            "missed": r["missed"] or 0, "skipped": r["sk"] or 0, "with_sub": r["ws"] or 0}


def exclude_stats(db, day_from: date, day_to: date, actor_id, reason: str, *, factory_id=None, area_id=None,
                  form_id=None, now: datetime | None = None) -> dict:
    """ลบรอบตรวจในช่วงวันที่ออกจากสถิติ — ผลตรวจที่ส่งแล้วยังอยู่ครบ (กลายเป็น 'ตรวจนอกรอบ') และไม่สร้างรอบซ้ำในช่วงนี้"""
    now = now or S.now_dt()
    reason = (reason or "").strip()
    if len(reason) < 3:
        raise ValidationError("กรุณาระบุเหตุผลที่ลบสถิติ (เก็บไว้ใน Audit Trail)")
    _check_range(day_from, day_to, now.date())
    ids = _scope_forms(db, factory_id, area_id, form_id)
    if not ids:
        raise ValidationError("ไม่พบแบบฟอร์มในขอบเขตที่เลือก")
    imp = exclude_impact(db, day_from, day_to, factory_id, area_id, form_id)
    now_s = ts(now)
    ph = ",".join("?" * len(ids))
    rids = [r[0] for r in db.execute(f"""SELECT id FROM cs_rounds WHERE form_id IN ({ph}) AND due_at>=? AND due_at<?""",
                                     ids + [ts(datetime.combine(day_from, time(0, 0))),
                                            ts(datetime.combine(day_to + timedelta(days=1), time(0, 0)))])]
    _close_missed_alerts(db, rids, actor_id, now_s, f"ผู้ดูแลระบบลบสถิติช่วงนี้: {reason}")
    for rid in rids:
        _drop_round(db, rid)
    cur = db.execute("""INSERT INTO cs_stat_excl(day_from, day_to, factory_id, area_id, form_id, reason, rounds, created_by, created_at)
                        VALUES (?,?,?,?,?,?,?,?,?)""",
                     (day_from.isoformat(), day_to.isoformat(), factory_id or None, area_id or None, form_id or None,
                      reason[:300], len(rids), actor_id, now_s))
    AN.refresh_form_stats(db, ids)
    S.audit(db, actor_id, "exclude", "cs_stat_excl", cur.lastrowid,
            after={**imp, "from": day_from.isoformat(), "to": day_to.isoformat(), "factory_id": factory_id,
                   "area_id": area_id, "form_id": form_id, "reason": reason[:300]})
    return {**imp, "id": cur.lastrowid}


def restore_stats(db, excl_id: int, actor_id, now: datetime | None = None) -> dict:
    """ยกเลิกการลบสถิติ → สร้างรอบตรวจในช่วงนั้นกลับมาและผูกผลตรวจเดิมใหม่"""
    x = db.execute("SELECT * FROM cs_stat_excl WHERE id=?", (excl_id,)).fetchone()
    if not x:
        raise ValidationError("ไม่พบรายการ")
    x = dict(x)
    db.execute("DELETE FROM cs_stat_excl WHERE id=?", (excl_id,))
    ids = _scope_forms(db, x["factory_id"], x["area_id"], x["form_id"])
    st = relink_forms(db, ids, day_from=date.fromisoformat(x["day_from"]), day_to=date.fromisoformat(x["day_to"]),
                      now=now, actor_id=actor_id, reason="ยกเลิกการลบสถิติ")
    S.audit(db, actor_id, "restore", "cs_stat_excl", excl_id, before=x, after=st)
    return st


def list_exclusions(db) -> list[dict]:
    return [dict(r) for r in db.execute("""
        SELECT x.*, fa.name AS factory_name, ar.name AS area_name, f.name AS form_name, u.name AS created_name
        FROM cs_stat_excl x LEFT JOIN factories fa ON fa.id=x.factory_id LEFT JOIN areas ar ON ar.id=x.area_id
        LEFT JOIN cs_forms f ON f.id=x.form_id LEFT JOIN users u ON u.id=x.created_by
        ORDER BY x.created_at DESC LIMIT 200""")]


def unscheduled_forms(db, factory_id=None) -> list[dict]:
    """แบบฟอร์มที่ใช้งานอยู่แต่ยังไม่กำหนดรอบตรวจ (ไม่นับในสถิติ)"""
    q = f"""SELECT f.id, f.code, f.name, fa.name AS factory_name FROM cs_forms f LEFT JOIN factories fa ON fa.id=f.factory_id
            WHERE f.active=1 AND COALESCE(f.is_template,0)=0 AND NOT {S.scheduled_sql('f.id')}"""
    p: list = []
    if factory_id:
        q += " AND f.factory_id=?"
        p.append(factory_id)
    return [dict(r) for r in db.execute(q + " ORDER BY fa.sort_no, f.code", p)]
