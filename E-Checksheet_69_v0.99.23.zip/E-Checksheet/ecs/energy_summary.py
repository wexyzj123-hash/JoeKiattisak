"""ecs/energy_summary.py — v0.88 Target รายหน่วยงาน + รายงานสรุปแยก Project / Section / Line

- Target ต่อวัน: ตั้งเองราย Project / Section / Line / มิเตอร์ (ต่อโรงงาน หรือทุกโรงงาน) · ไม่ได้ตั้ง → อัตโนมัติ
  = ค่าเฉลี่ยต่อวันของเดือนก่อน × (1 − % ประหยัดเป้าหมาย)
- รายงานสรุป: ทุกหน่วยงานในระดับที่เลือก · การใช้รายวัน (แยกวัน ไม่รวมก้อน) เทียบ Target · วันใช้มาก/น้อย ·
  ช่วงเวลาที่ใช้มาก/น้อย (จากค่าทุก 15 นาที ถ้ามี) · วันในสัปดาห์ · มิเตอร์ที่ใช้มากสุด · เทียบช่วงก่อนหน้า
"""
from __future__ import annotations

import io
from datetime import date, datetime, time, timedelta

from . import energy as EN
from . import services as S
from .services import ValidationError, ts

DDL = """
CREATE TABLE IF NOT EXISTS en_targets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,
    factory_id  INTEGER NOT NULL DEFAULT 0,
    level       TEXT NOT NULL,
    key         TEXT NOT NULL,
    daily       REAL NOT NULL,
    note        TEXT NOT NULL DEFAULT '',
    updated_by  INTEGER,
    updated_at  TEXT NOT NULL,
    UNIQUE (kind, factory_id, level, key)
);
"""
LEVELS = {"project": "Project", "grp": "Section", "line": "Line", "meter": "มิเตอร์", "factory": "โรงงาน"}
MAX_DAYS = 366
WD_TH = ("จ.", "อ.", "พ.", "พฤ.", "ศ.", "ส.", "อา.")


def ensure(db) -> None:
    if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='en_targets'").fetchone():
        db.executescript(DDL)


# ───────────────────────── หน่วยงาน (กลุ่มมิเตอร์) ─────────────────────────

def unit_key(m: dict, level: str):
    if level == "factory":
        return str(m.get("factory_id") or 0)
    if level == "project":
        return str(m.get("project_id") or -1)
    if level == "grp":
        return m.get("grp") or "-"
    if level == "line":
        return f"{m.get('grp') or '-'}|{m.get('line') or '-'}"
    return str(m["id"])


def unit_name(m: dict, level: str) -> str:
    if level == "factory":
        return m.get("factory_name") or "ไม่ระบุโรงงาน"
    if level == "project":
        return m.get("project_name") or "ยังไม่กำหนด Project"
    if level == "grp":
        return m.get("grp") or "ไม่ระบุ Section"
    if level == "line":
        return f"{m.get('line') or 'ไม่ระบุ Line'} · {m.get('grp') or '–'}"
    return EN.label(m)


def counted(ms: list[dict]) -> list[dict]:
    """มิเตอร์ที่นับยอดของหน่วยงาน — v0.90 กติกาเดียวทั้งระบบ (EN.counted: ไม่นับซ้ำมิเตอร์ที่ถูกครอบในกลุ่มเดียวกัน)"""
    return EN.counted(ms)


def units(ms: list[dict], level: str) -> list[dict]:
    out: dict[str, dict] = {}
    for m in ms:
        k = unit_key(m, level)
        u = out.setdefault(k, {"key": k, "name": unit_name(m, level), "color": m.get("project_color") if level == "project" else None,
                               "meters": [], "factory_id": m.get("factory_id")})
        u["meters"].append(m)
        if u["factory_id"] != m.get("factory_id"):
            u["factory_id"] = None
    return sorted(out.values(), key=lambda u: (u["key"] in ("-1", "-", "-|-"), u["name"]))


# ───────────────────────── Target ─────────────────────────

def manual_targets(db, kind: str) -> dict[tuple, dict]:
    ensure(db)
    return {(r["factory_id"], r["level"], r["key"]): dict(r) for r in db.execute("SELECT * FROM en_targets WHERE kind=?", (kind,))}


def save_target(db, kind: str, factory_id, level: str, key: str, daily, note: str, actor) -> None:
    ensure(db)
    if level not in LEVELS or kind not in EN.KINDS:
        raise ValidationError(["ระดับ / หมวดไม่ถูกต้อง"])
    fid = int(factory_id or 0)
    key = str(key or "").strip()[:200]
    if not key:
        raise ValidationError(["ไม่ระบุหน่วยงาน"])
    v = str(daily if daily is not None else "").replace(",", "").strip()
    if v == "":
        db.execute("DELETE FROM en_targets WHERE kind=? AND factory_id=? AND level=? AND key=?", (kind, fid, level, key))
        S.audit(db, actor, "target_clear", "en_targets", None, after={"kind": kind, "factory_id": fid, "level": level, "key": key})
        return
    try:
        val = float(v)
        if val < 0:
            raise ValueError
    except ValueError:
        raise ValidationError([f"Target ต้องเป็นตัวเลข ≥ 0 ({key})"]) from None
    db.execute("""INSERT INTO en_targets(kind, factory_id, level, key, daily, note, updated_by, updated_at) VALUES (?,?,?,?,?,?,?,?)
                  ON CONFLICT(kind, factory_id, level, key) DO UPDATE SET daily=excluded.daily, note=excluded.note,
                  updated_by=excluded.updated_by, updated_at=excluded.updated_at""",
               (kind, fid, level, key, val, str(note or "")[:200], actor, ts()))
    S.audit(db, actor, "target_set", "en_targets", None, after={"kind": kind, "factory_id": fid, "level": level, "key": key, "daily": val})


def _daily_sum(ser: dict, ms: list[dict], day: str) -> float | None:
    vals = [(ser[m["id"]].get(day) or {}).get("u") for m in ms]
    vals = [EN.sign(m) * v for m, v in zip(ms, vals) if v is not None]
    return sum(vals) if vals else None


def auto_target(db, ms: list[dict], ref: date, pct: float | None = None) -> float | None:
    """ค่าเฉลี่ยต่อวันของเดือนก่อนหน้าเดือน ref × (1 − pct%) — วันที่ไม่มีค่าไม่นับ"""
    cfg = EN.settings(db)
    pct = float(cfg.get("target_pct") or 0) if pct is None else pct
    first = ref.replace(day=1)
    p_to = first - timedelta(days=1)
    p_from = p_to.replace(day=1)
    cm = counted(ms)
    if not cm:
        return None
    ser = EN.series(db, cm, p_from, p_to, split=True)
    vals = [v for v in (_daily_sum(ser, cm, (p_from + timedelta(days=i)).isoformat()) for i in range((p_to - p_from).days + 1)) if v is not None]
    if len(vals) < 3:
        return None
    return round(sum(vals) / len(vals) * (1 - pct / 100.0), 3)


def target_for(db, kind: str, level: str, key: str, factory_id, ms: list[dict], ref: date, manual: dict | None = None) -> dict:
    """{daily, src: manual|auto|None, note} — ตั้งเองของโรงงานนั้นก่อน → ตั้งเองแบบทุกโรงงาน → อัตโนมัติ"""
    manual = manual if manual is not None else manual_targets(db, kind)
    for fid in ([int(factory_id)] if factory_id else []) + [0]:
        t = manual.get((fid, level, key))
        if t:
            return {"daily": t["daily"], "src": "manual", "note": t["note"]}
    a = auto_target(db, ms, ref)
    return {"daily": a, "src": "auto" if a is not None else None, "note": ""}


def target_rows(db, kind: str, factory_id, level: str, ref: date) -> list[dict]:
    """ตารางตั้ง Target: ทุกหน่วยงานของระดับนั้น + ค่าแนะนำอัตโนมัติ + ค่าที่ตั้งไว้"""
    ms = EN.meters(db, factory_id, kind, True)
    man = manual_targets(db, kind)
    out = []
    for u in units(ms, level):
        auto = auto_target(db, u["meters"], ref)
        mine = man.get((int(factory_id or 0), level, u["key"]))
        allf = man.get((0, level, u["key"])) if factory_id else None
        out.append({**{k: u[k] for k in ("key", "name", "color")}, "n": len(u["meters"]), "auto": auto,
                    "manual": mine["daily"] if mine else None, "note": mine["note"] if mine else "",
                    "inherited": allf["daily"] if allf and not mine else None})
    return out


# ───────────────────────── รายงานสรุป ─────────────────────────

def _hourly(db, ids: list[int], d_from: date, d_to: date) -> tuple[list[float] | None, int]:
    """เฉลี่ยต่อวันของแต่ละชั่วโมง 00–23 (จากค่าทุก 15 นาที/รายชั่วโมง) · ไม่มีค่าต่อช่วง → None"""
    from . import energy_interval as EI
    EI.ensure(db)
    if not ids:
        return None, 0
    acc = [0.0] * 24
    days: set = set()
    a, b = datetime.combine(d_from, time(0, 0)), datetime.combine(d_to + timedelta(days=1), time(0, 0))
    for i in range(0, len(ids), 800):
        ch = ids[i:i + 800]
        for d_, hh, v in db.execute(f"""SELECT substr(ts, 1, 10), CAST(substr(ts, 12, 2) AS INTEGER), SUM(value) FROM en_intervals
                                        WHERE ts>=? AND ts<? AND meter_id IN ({','.join('?' * len(ch))})
                                        GROUP BY substr(ts, 1, 13)""", [ts(a), ts(b), *ch]):
            acc[hh] += v or 0.0
            days.add(d_)
    if not days:
        return None, 0
    return [round(x / len(days), 3) for x in acc], len(days)


def summary(db, kind: str, level: str, d_from: date, d_to: date, factory_id=None, project_id=None, grp=None) -> dict:
    ensure(db)
    if kind not in EN.KINDS:
        raise ValidationError(["หมวดไม่ถูกต้อง"])
    level = level if level in ("factory", "project", "grp", "line", "meter") else "project"
    if d_from > d_to:
        d_from, d_to = d_to, d_from
    if (d_to - d_from).days >= MAX_DAYS:
        raise ValidationError([f"เลือกช่วงไม่เกิน {MAX_DAYS} วัน"])
    meta = EN.KINDS[kind]
    all_ms = EN.meters(db, factory_id, kind, True, project_id, grp)
    days = [(d_from + timedelta(days=i)) for i in range((d_to - d_from).days + 1)]
    dk = [d.isoformat() for d in days]
    n_days = len(days)
    p_to = d_from - timedelta(days=1)
    p_from = p_to - timedelta(days=n_days - 1)
    cm_all = counted(all_ms)
    ser = EN.series(db, cm_all, d_from, d_to, split=True) if cm_all else {}
    ser_p = EN.series(db, cm_all, p_from, p_to, split=True) if cm_all else {}
    man = manual_targets(db, kind)
    today = S.now_dt().date()
    out_units = []
    for u in units(all_ms, level):
        cm = counted(u["meters"])
        cm = [m for m in cm if m["id"] in ser]
        tgt = target_for(db, kind, level, u["key"], u["factory_id"] or factory_id, u["meters"], d_from, man)
        daily = []
        for d, k in zip(days, dk):
            v = _daily_sum(ser, cm, k)
            split = any((ser[m["id"]].get(k) or {}).get("split") for m in cm)
            bad = any((ser[m["id"]].get(k) or {}).get("flag") in ("bad", "reset") for m in cm)
            t = tgt["daily"]
            daily.append({"day": k, "u": round(v, 3) if v is not None else None, "target": t,
                          "over": v is not None and t is not None and v > t, "split": split, "bad": bad, "future": d > today,
                          "wd": d.weekday()})
        vals = [x for x in daily if x["u"] is not None]
        total = sum(x["u"] for x in vals)
        prev_vals = [v for v in (_daily_sum(ser_p, cm, (p_from + timedelta(days=i)).isoformat()) for i in range(n_days)) if v is not None]
        prev_total = sum(prev_vals) if prev_vals else None
        t_total = tgt["daily"] * len(vals) if tgt["daily"] is not None else None
        dow = [[] for _ in range(7)]
        for x in vals:
            dow[x["wd"]].append(x["u"])
        hourly, h_days = _hourly(db, [m["id"] for m in cm], d_from, d_to)
        hr_rank = sorted(range(24), key=lambda h: hourly[h]) if hourly else []
        mt = sorted(({"name": EN.label(m), "id": m["id"], "total": round(sum((ser[m["id"]].get(k) or {}).get("u") or 0 for k in dk), 3)}
                     for m in cm), key=lambda r: -r["total"])
        for r in mt:
            r["share"] = round(100 * r["total"] / total, 1) if total else 0.0
        hi = max(vals, key=lambda x: x["u"]) if vals else None
        lo = min(vals, key=lambda x: x["u"]) if vals else None
        out_units.append({
            "key": u["key"], "name": u["name"], "color": u["color"], "n_meters": len(u["meters"]), "n_counted": len(cm),
            "daily": daily, "total": round(total, 3), "avg": round(total / len(vals), 3) if vals else None, "n_data": len(vals),
            "target": tgt, "target_total": round(t_total, 3) if t_total is not None else None,
            "pct_target": round(100 * total / t_total, 1) if t_total else None,
            "days_over": sum(1 for x in vals if x["over"]), "max_day": hi, "min_day": lo,
            "prev_total": round(prev_total, 3) if prev_total is not None else None,
            "diff_pct": round(100 * (total - prev_total) / prev_total, 1) if prev_total else None,
            "dow": [round(sum(x) / len(x), 3) if x else None for x in dow],
            "hourly": hourly, "h_days": h_days, "peak_hours": sorted(hr_rank[-3:]) if hourly else [], "low_hours": sorted(hr_rank[:3]) if hourly else [],
            "top_meters": mt[:10], "n_split": sum(1 for x in vals if x["split"]), "n_bad": sum(1 for x in daily if x["bad"])})
    out_units.sort(key=lambda u: -u["total"])
    grand = sum(u["total"] for u in out_units)
    for u in out_units:
        u["share"] = round(100 * u["total"] / grand, 1) if grand else 0.0
    tot_daily = []
    for i, k in enumerate(dk):
        vs = [u["daily"][i]["u"] for u in out_units if u["daily"][i]["u"] is not None]
        ts_ = [u["target"]["daily"] for u in out_units if u["target"]["daily"] is not None]
        tv, tt = (round(sum(vs), 3) if vs else None), (round(sum(ts_), 3) if ts_ else None)
        tot_daily.append({"day": k, "u": tv, "target": tt, "over": tv is not None and tt is not None and tv > tt,
                          "split": any(u["daily"][i]["split"] for u in out_units), "bad": False})
    return {"kind": kind, "meta": meta, "unit": meta["unit"], "level": level, "level_th": LEVELS[level], "from": d_from, "to": d_to,
            "days": dk, "n_days": n_days, "prev_from": p_from, "prev_to": p_to, "units": out_units, "grand": round(grand, 3),
            "tot_daily": tot_daily, "target_pct": EN.settings(db).get("target_pct"),
            "grand_target": round(sum(u["target_total"] or 0 for u in out_units), 3) if any(u["target_total"] for u in out_units) else None}


# ───────────────────────── Excel ─────────────────────────

def to_xlsx(rep: dict, title: str) -> bytes:
    from openpyxl import Workbook
    from openpyxl.chart import BarChart, LineChart, Reference
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    hdr = PatternFill("solid", fgColor="142A75")
    hf = Font(bold=True, color="FFFFFF")
    over = PatternFill("solid", fgColor="FDE2E1")
    est = PatternFill("solid", fgColor="EEF2FF")
    thin = Side(style="thin", color="CBD5E1")
    box = Border(left=thin, right=thin, top=thin, bottom=thin)
    unit = rep["unit"]

    def head(ws, row, cols):
        for i, c in enumerate(cols, 1):
            x = ws.cell(row=row, column=i, value=c)
            x.fill, x.font, x.border = hdr, hf, box
            x.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # สรุป
    ws = wb.active
    ws.title = "สรุป"
    ws["A1"] = title
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = f"ช่วง {rep['from']:%d/%m/%Y} – {rep['to']:%d/%m/%Y} ({rep['n_days']} วัน) · เทียบช่วงก่อน {rep['prev_from']:%d/%m/%Y} – {rep['prev_to']:%d/%m/%Y} · หน่วย {unit}"
    cols = [rep["level_th"], f"รวม ({unit})", "สัดส่วน %", f"เฉลี่ย/วัน", f"Target/วัน", "ที่มา Target", f"Target รวม", "% ของ Target",
            "วันเกิน Target", "วันใช้มากสุด", "วันใช้น้อยสุด", f"ช่วงก่อน ({unit})", "เปลี่ยนแปลง %", "ช่วงเวลาใช้มาก", "ช่วงเวลาใช้น้อย", "มิเตอร์"]
    head(ws, 4, cols)
    r = 5
    for u in rep["units"]:
        vals = [u["name"], u["total"], u["share"], u["avg"], u["target"]["daily"],
                {"manual": "ตั้งเอง", "auto": "อัตโนมัติ"}.get(u["target"]["src"], "–"), u["target_total"], u["pct_target"],
                u["days_over"], f"{u['max_day']['day'][8:]}/{u['max_day']['day'][5:7]} ({u['max_day']['u']:,.0f})" if u["max_day"] else "",
                f"{u['min_day']['day'][8:]}/{u['min_day']['day'][5:7]} ({u['min_day']['u']:,.0f})" if u["min_day"] else "",
                u["prev_total"], u["diff_pct"], ", ".join(f"{h:02d}:00" for h in u["peak_hours"]),
                ", ".join(f"{h:02d}:00" for h in u["low_hours"]), u["n_counted"]]
        for i, v in enumerate(vals, 1):
            c = ws.cell(row=r, column=i, value=v)
            c.border = box
            if isinstance(v, float):
                c.number_format = "#,##0.00"
        if u["pct_target"] and u["pct_target"] > 100:
            ws.cell(row=r, column=8).fill = over
        r += 1
    ws.cell(row=r, column=1, value="รวมทั้งหมด").font = Font(bold=True)
    ws.cell(row=r, column=2, value=rep["grand"]).font = Font(bold=True)
    ws.cell(row=r, column=2).number_format = "#,##0.00"
    for i, w in enumerate([30, 14, 9, 12, 12, 11, 14, 11, 10, 16, 16, 14, 11, 18, 18, 8], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "B5"
    # รายวัน (แยกวัน)
    wd = wb.create_sheet("รายวัน")
    head(wd, 1, ["วันที่", "วัน"] + [u["name"] for u in rep["units"]] + ["รวม", "Target รวม"])
    for i, k in enumerate(rep["days"]):
        d = date.fromisoformat(k)
        row = [d, WD_TH[d.weekday()]] + [u["daily"][i]["u"] for u in rep["units"]] + [rep["tot_daily"][i]["u"], rep["tot_daily"][i]["target"]]
        for j, v in enumerate(row, 1):
            c = wd.cell(row=i + 2, column=j, value=v)
            c.border = box
            if j == 1:
                c.number_format = "dd/mm/yyyy"
            elif isinstance(v, float):
                c.number_format = "#,##0.00"
            if 3 <= j < 3 + len(rep["units"]):
                x = rep["units"][j - 3]["daily"][i]
                if x["over"]:
                    c.fill = over
                elif x["split"]:
                    c.fill = est
    n = len(rep["days"])
    ncol = 2 + len(rep["units"]) + 2
    wd.cell(row=n + 3, column=1, value="สีชมพู = เกิน Target · สีม่วงอ่อน = เฉลี่ยจากช่วงที่ขาดค่าอ่าน (ไม่ใช่ค่าจริงรายวัน)")
    wd.column_dimensions["A"].width = 12
    for j in range(3, ncol + 1):
        wd.column_dimensions[get_column_letter(j)].width = 14
    wd.freeze_panes = "C2"
    if n:
        ch = BarChart()
        ch.title = f"การใช้รวมรายวัน ({unit}) เทียบ Target"
        ch.add_data(Reference(wd, min_col=ncol - 1, min_row=1, max_row=n + 1), titles_from_data=True)
        ch.set_categories(Reference(wd, min_col=1, min_row=2, max_row=n + 1))
        ln = LineChart()
        ln.add_data(Reference(wd, min_col=ncol, min_row=1, max_row=n + 1), titles_from_data=True)
        ch += ln
        ch.height, ch.width = 9, 26
        wd.add_chart(ch, f"{get_column_letter(ncol + 2)}2")
    # รายชั่วโมง
    wh = wb.create_sheet("รายชั่วโมง")
    head(wh, 1, ["ชั่วโมง"] + [u["name"] for u in rep["units"]])
    for h in range(24):
        wh.cell(row=h + 2, column=1, value=f"{h:02d}:00").border = box
        for j, u in enumerate(rep["units"], 2):
            c = wh.cell(row=h + 2, column=j, value=u["hourly"][h] if u["hourly"] else None)
            c.border = box
            c.number_format = "#,##0.00"
    wh.cell(row=27, column=1, value=f"ค่าเฉลี่ยต่อวันของแต่ละชั่วโมง ({unit}) — จากค่าทุก 15 นาที/รายชั่วโมงของ SCADA · ว่าง = หน่วยงานนี้ไม่มีค่าต่อช่วง")
    # มิเตอร์
    wm = wb.create_sheet("มิเตอร์")
    head(wm, 1, [rep["level_th"], "มิเตอร์", f"รวม ({unit})", "สัดส่วนในหน่วยงาน %"])
    r = 2
    for u in rep["units"]:
        for t in u["top_meters"]:
            for j, v in enumerate([u["name"], t["name"], t["total"], t["share"]], 1):
                wm.cell(row=r, column=j, value=v).border = box
            r += 1
    for col, w in (("A", 28), ("B", 34), ("C", 14), ("D", 14)):
        wm.column_dimensions[col].width = w
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()
