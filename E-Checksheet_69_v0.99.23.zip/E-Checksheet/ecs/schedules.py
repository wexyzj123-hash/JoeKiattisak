"""ecs/schedules.py — Phase 5: ตั้งเวลาส่งรายงานทางอีเมล (รายวัน / รายสัปดาห์ / รายเดือน) แนบ PDF และ/หรือ Excel"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

from . import services as S
from .services import ValidationError, parse_ts, ts

KIND_TH = {"daily": "รายวัน", "weekly": "รายสัปดาห์", "monthly": "รายเดือน"}
WEEKDAY_TH = ("จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์", "เสาร์", "อาทิตย์")
FORMATS = ("pdf", "xlsx")
_EMAIL = re.compile(r"^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$")


def _recipients(raw: str) -> list[str]:
    return [x.strip() for x in re.split(r"[,;\s]+", raw or "") if x.strip()]


def compute_next(s: dict, after: datetime) -> datetime:
    hh, mm = (int(x) for x in (s.get("send_time") or "07:30").split(":"))
    cand = after.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if s["kind"] == "daily":
        return cand if cand > after else cand + timedelta(days=1)
    if s["kind"] == "weekly":
        cand += timedelta(days=(int(s.get("weekday") or 0) - cand.weekday()) % 7)
        return cand if cand > after else cand + timedelta(days=7)
    day = min(max(int(s.get("month_day") or 1), 1), 28)
    cand = cand.replace(day=day)
    if cand <= after:
        y, m = (cand.year + 1, 1) if cand.month == 12 else (cand.year, cand.month + 1)
        cand = cand.replace(year=y, month=m)
    return cand


def report_ref(s: dict, at: datetime) -> date:
    """วันที่อ้างอิงของรายงานที่ส่ง ณ เวลา at"""
    if s["kind"] == "daily":
        return at.date() if s.get("daily_scope") == "today" else at.date() - timedelta(days=1)
    if s["kind"] == "weekly":
        return at.date() - timedelta(days=1)                       # 7 วันก่อนหน้า (ไม่รวมวันส่ง)
    first = at.date().replace(day=1)
    return (first - timedelta(days=1)).replace(day=1)             # เดือนก่อนหน้า


def save_schedule(db, data: dict, actor_id, sid: int | None = None, now: datetime | None = None) -> int:
    errors = []
    name = str(data.get("name") or "").strip()[:120]
    kind = data.get("kind") if data.get("kind") in KIND_TH else "daily"
    fmts = [f for f in (data.get("formats") or []) if f in FORMATS]
    rec = _recipients(str(data.get("recipients") or ""))
    tm = str(data.get("send_time") or "07:30")
    if not name:
        errors.append("กรุณาตั้งชื่อ")
    if not fmts:
        errors.append("เลือกรูปแบบไฟล์อย่างน้อย 1 แบบ (PDF หรือ Excel)")
    if not rec:
        errors.append("กรุณาระบุอีเมลผู้รับ")
    bad = [r for r in rec if not _EMAIL.match(r)]
    if bad:
        errors.append("อีเมลไม่ถูกต้อง: " + ", ".join(bad[:5]))
    if len(rec) > 50:
        errors.append("ผู้รับได้ไม่เกิน 50 อีเมล")
    try:
        datetime.strptime(tm, "%H:%M")
    except ValueError:
        errors.append("เวลาส่งต้องเป็นรูปแบบ HH:MM")
    try:
        weekday = int(data.get("weekday") or 0)
        month_day = int(data.get("month_day") or 1)
        if not (0 <= weekday <= 6 and 1 <= month_day <= 28):
            raise ValueError
    except (TypeError, ValueError):
        errors.append("วันที่ส่งไม่ถูกต้อง (รายเดือนเลือกได้วันที่ 1–28)")
        weekday, month_day = 0, 1
    try:
        fid = int(data.get("factory_id") or 0) or None
    except (TypeError, ValueError):
        fid = None
    if errors:
        raise ValidationError(errors)
    now = now or S.now_dt()
    row = {"name": name, "kind": kind, "daily_scope": "today" if data.get("daily_scope") == "today" else "yesterday",
           "factory_id": fid, "formats": ",".join(fmts), "recipients": ", ".join(rec), "send_time": tm, "weekday": weekday,
           "month_day": month_day, "active": 0 if str(data.get("active", "1")) in ("0", "", "False") else 1}
    row["next_run_at"] = ts(compute_next(row, now)) if row["active"] else None
    row["updated_at"] = ts(now)
    if sid:
        db.execute(f"UPDATE cs_report_schedules SET {', '.join(f'{k}=?' for k in row)} WHERE id=?", (*row.values(), sid))
        S.audit(db, actor_id, "update", "cs_report_schedules", sid, after=row)
        return sid
    row.update(created_by=actor_id, created_at=ts(now))
    sid = db.execute(f"INSERT INTO cs_report_schedules({', '.join(row)}) VALUES ({', '.join('?' * len(row))})",
                     tuple(row.values())).lastrowid
    S.audit(db, actor_id, "create", "cs_report_schedules", sid, after=row)
    return sid


def delete_schedule(db, sid: int, actor_id) -> None:
    db.execute("DELETE FROM cs_report_schedules WHERE id=?", (sid,))
    S.audit(db, actor_id, "delete", "cs_report_schedules", sid)


def get_schedule(db, sid: int) -> dict | None:
    r = db.execute("SELECT * FROM cs_report_schedules WHERE id=?", (sid,)).fetchone()
    return dict(r) if r else None


def list_schedules(db) -> list[dict]:
    return [dict(r) for r in db.execute("""SELECT s.*, fa.name AS factory_name FROM cs_report_schedules s
                                           LEFT JOIN factories fa ON fa.id=s.factory_id ORDER BY s.active DESC, s.name""")]


def list_runs(db, limit: int = 30) -> list[dict]:
    return [dict(r) for r in db.execute("SELECT * FROM cs_report_runs ORDER BY id DESC LIMIT ?", (limit,))]


def due_schedules(db, now: datetime | None = None) -> list[int]:
    now_s = ts(now or S.now_dt())
    return [r[0] for r in db.execute("""SELECT id FROM cs_report_schedules WHERE active=1 AND next_run_at IS NOT NULL
                                        AND next_run_at <= ? ORDER BY next_run_at""", (now_s,))]


def run_schedule(db, sid: int, manual: bool = False, now: datetime | None = None) -> dict:
    """สร้างไฟล์รายงานแล้วส่งอีเมล (ต้องอยู่ใน request context เพราะใช้ template) — บันทึกผลทุกครั้ง"""
    from . import notify as N
    from . import report_docs as RD
    from .views.rep import render_report
    s = get_schedule(db, sid)
    if not s:
        return {"ok": False, "message": "ไม่พบกำหนดการ"}
    now = now or S.now_dt()
    started = ts(now)
    at = parse_ts(s["next_run_at"]) if (s["next_run_at"] and not manual) else now
    ref = report_ref(s, at)
    cfg = N.get_settings(db)
    files, notes = [], []
    for fmt in s["formats"].split(","):
        try:
            body, mime, fname = render_report(s["kind"], ref, s["factory_id"], fmt, "ส่งอัตโนมัติ")
            files.append((fname, body, mime))
        except Exception as exc:  # noqa: BLE001 — ไฟล์หนึ่งพังไม่ควรทำให้อีกไฟล์ไม่ถูกส่ง
            notes.append(f"{fmt.upper()}: {exc}")
    rep = RD.build(db, s["kind"], ref, s["factory_id"])
    k = rep["kpi"]
    subject = f"{rep['title']} · {rep['period']} · {rep['factory']}"
    body = (f"{rep['title']}\n{rep['period']} · {rep['factory']}\n\n"
            f"ตรวจตรงเวลา: {'-' if k['rate'] is None else str(k['rate']) + '%'} (รอบ {k['due']} · ขาดตรวจ {k['missed']})\n"
            f"ผลตรวจที่ส่ง: {k['subs']} ครั้ง · หัวข้อ NG: {k['ng']}\n"
            f"แจ้งเตือนใหม่: {k['alerts']} (วิกฤต {k['alerts_crit']}) · CAPA ยังไม่ปิด {k['capa_active']} (เลยกำหนด {k['capa_overdue']})\n"
            + ("\nหมายเหตุ: " + "; ".join(notes) if notes else "") + "\n\nรายละเอียดอยู่ในไฟล์แนบ")
    status, message = "sent", ""
    if not files:
        status, message = "failed", "สร้างไฟล์รายงานไม่สำเร็จ: " + "; ".join(notes)
    elif not N.channel_ready(cfg, "email"):
        status, message = "failed", "ยังไม่ได้ตั้งค่าอีเมล (SMTP) หรือยังไม่เปิดใช้งาน"
    else:
        try:
            N.SENDERS["email"](cfg, s["recipients"], subject, body, N._link(_base_url(), "/reports"), attachments=files)
            message = f"ส่งถึง {s['recipients']}" + (f" (บางไฟล์ไม่สำเร็จ: {'; '.join(notes)})" if notes else "")
            status = "partial" if notes else "sent"
        except Exception as exc:  # noqa: BLE001
            status, message = "failed", f"ส่งอีเมลไม่สำเร็จ: {exc}"
    size = sum(len(f[1]) for f in files) // 1024
    db.execute("""INSERT INTO cs_report_runs(schedule_id, name, started_at, finished_at, status, message, recipients, files,
                  size_kb, manual) VALUES (?,?,?,?,?,?,?,?,?,?)""",
               (sid, s["name"], started, ts(S.now_dt()), status, message[:500], s["recipients"],
                ", ".join(f[0] for f in files), size, 1 if manual else 0))
    upd = {"last_run_at": started, "last_status": status, "last_message": message[:300]}
    if not manual and s["active"]:
        upd["next_run_at"] = ts(compute_next(s, max(now, at)))
    db.execute(f"UPDATE cs_report_schedules SET {', '.join(f'{k}=?' for k in upd)} WHERE id=?", (*upd.values(), sid))
    ok = status in ("sent", "partial")
    return {"ok": ok, "status": status, "message": ("ส่งรายงานแล้ว — " + message) if ok else message}


def _base_url() -> str:
    try:
        from flask import current_app
        return current_app.config.get("BASE_URL", "")
    except RuntimeError:
        return ""
