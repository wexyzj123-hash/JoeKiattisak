"""ecs/change_requests.py — v0.28 คำขอแก้ไขแบบฟอร์ม + ประเภทหัวข้อที่เพิ่มเอง

คำขอแก้ไข: ช่างที่ใช้เช็คชีทแจ้งได้จากหน้ากรอก (รายหัวข้อ หรือทั้งแบบฟอร์ม) เช่น ชื่อหัวข้อ/เกณฑ์/ตัวเลือกไม่ตรงหน้างาน
  เพิ่ม/ลบหัวข้อ ข้อมูลกรอกผิดหรือไม่ครบ → หัวหน้างาน/ผู้ดูแลระบบได้รับแจ้ง (กระดิ่ง) → เปิดแก้ใน Builder → ปิดคำขอ (แจ้งกลับผู้ขอ)
  สถานะ: open (ใหม่) → accepted (กำลังแก้) → done (แก้แล้ว) | rejected (ไม่แก้ + เหตุผล)
ประเภทหัวข้อที่เพิ่มเอง (presets): ชุดตั้งค่าหัวข้อที่ใช้บ่อย เช่น "สถานะระบบ" = ตัวเลือก ปกติ / ผิดปกติ(NG) / หยุดระบบชั่วคราว
  หัวหน้างาน/ผู้ดูแลระบบเพิ่มได้ (จาก Builder หรือหน้าจัดการประเภท) แล้วเลือกใช้ในช่อง "ประเภท" ของ Builder ได้ทันที
"""
from __future__ import annotations

import json

from . import services as S

DDL = """
CREATE TABLE IF NOT EXISTS cs_change_requests (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id      INTEGER NOT NULL,
    version_id   INTEGER,
    item_key     TEXT DEFAULT '',
    item_name    TEXT DEFAULT '',
    kind         TEXT NOT NULL,
    detail       TEXT NOT NULL,
    proposed     TEXT DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'open',
    requester_id INTEGER NOT NULL,
    created_at   TEXT NOT NULL,
    handler_id   INTEGER,
    handled_at   TEXT,
    reply        TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_cs_chreq_status ON cs_change_requests(status, form_id);
CREATE TABLE IF NOT EXISTS cs_item_presets (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    item_type  TEXT NOT NULL,
    options    TEXT DEFAULT '[]',
    unit       TEXT DEFAULT '',
    min_value  REAL,
    max_value  REAL,
    active     INTEGER NOT NULL DEFAULT 1,
    created_by INTEGER,
    created_at TEXT NOT NULL
);
"""

KINDS = {"name": "ชื่อหัวข้อ / คำอธิบายไม่ตรงหน้างาน", "criteria": "เกณฑ์ / ค่ามาตรฐาน / หน่วยไม่ถูกต้อง",
         "options": "ตัวเลือกไม่ครบ / ไม่เหมาะสม", "add": "ขอเพิ่มหัวข้อตรวจ", "remove": "หัวข้อนี้ไม่ใช้แล้ว / ควรลบ",
         "data": "ข้อมูลกรอกผิด / ไม่ครบ (จุดตรวจ รูป เครื่อง ฯลฯ)", "freq": "ความถี่ / เวลาตรวจไม่เหมาะสม", "other": "อื่น ๆ"}
STATUS_TH = {"open": "ใหม่", "accepted": "กำลังแก้ไข", "done": "แก้ไขแล้ว", "rejected": "ไม่แก้ไข"}
BASE_TYPES = ("ok_ng", "number", "counter", "choice", "text")


class ChangeError(ValueError):
    pass


def ensure(db) -> None:
    db.executescript(DDL)


def _managers(db, factory_id) -> list[int]:
    """ผู้รับแจ้ง: ผู้ดูแลระบบ + หัวหน้างานของโรงงานนั้น (หรือทุกโรงงาน)"""
    return [r[0] for r in db.execute(
        """SELECT id FROM users WHERE active=1 AND (role='admin' OR (role='supervisor' AND (factory_id IS NULL OR ? IS NULL OR factory_id=?)))""",
        (factory_id, factory_id))]


def create(db, form_id: int, user_id: int, kind: str, detail: str, proposed: str = "", item_key: str = "") -> int:
    from .notify import notify_user_app
    form = S.get_form(db, form_id)
    if not form:
        raise ChangeError("ไม่พบแบบฟอร์ม")
    kind = kind if kind in KINDS else "other"
    detail = str(detail or "").strip()
    if len(detail) < 3:
        raise ChangeError("กรุณาอธิบายสิ่งที่ต้องการให้แก้ (อย่างน้อย 3 ตัวอักษร)")
    item_name = ""
    if item_key:
        r = db.execute("SELECT name FROM cs_form_items WHERE version_id=? AND item_key=?",
                       (form["current_version_id"], item_key)).fetchone()
        item_name = r[0] if r else ""
    cid = db.execute("""INSERT INTO cs_change_requests(form_id, version_id, item_key, item_name, kind, detail, proposed,
                        requester_id, created_at) VALUES (?,?,?,?,?,?,?,?,?)""",
                     (form_id, form["current_version_id"], item_key or "", item_name, kind, detail[:1000],
                      str(proposed or "").strip()[:500], user_id, S.ts())).lastrowid
    who = db.execute("SELECT name FROM users WHERE id=?", (user_id,)).fetchone()
    title = f"✏️ คำขอแก้ไขแบบฟอร์ม {form['code'] or ''} {form['name']}"[:200]
    body = f"{KINDS[kind]}{' · หัวข้อ: ' + item_name if item_name else ''}\n{detail[:300]}\nโดย {who[0] if who else ''}"
    for uid in _managers(db, form.get("factory_id")):
        if uid != user_id:
            notify_user_app(db, uid, "change_request", title, body, f"/forms/change-requests/{cid}", "info", f"chreq:{cid}")
    S.audit(db, user_id, "change_request", "cs_forms", form_id, after={"id": cid, "kind": kind, "item": item_key})
    return cid


def get(db, cid: int) -> dict | None:
    r = db.execute("""SELECT c.*, f.code AS form_code, f.name AS form_name, f.factory_id, u.name AS requester_name,
                             h.name AS handler_name, fa.name AS factory_name
                      FROM cs_change_requests c JOIN cs_forms f ON f.id=c.form_id LEFT JOIN users u ON u.id=c.requester_id
                      LEFT JOIN users h ON h.id=c.handler_id LEFT JOIN factories fa ON fa.id=f.factory_id WHERE c.id=?""",
                   (cid,)).fetchone()
    return dict(r) if r else None


def listing(db, status: str = "active", form_id: int | None = None, requester_id: int | None = None,
            factory_id: int | None = None, limit: int = 300) -> list[dict]:
    cond, params = ["1=1"], []
    if status == "active":
        cond.append("c.status IN ('open','accepted')")
    elif status in STATUS_TH:
        cond.append("c.status=?")
        params.append(status)
    if form_id:
        cond.append("c.form_id=?")
        params.append(form_id)
    if requester_id:
        cond.append("c.requester_id=?")
        params.append(requester_id)
    if factory_id:
        cond.append("f.factory_id=?")
        params.append(factory_id)
    return [dict(r) for r in db.execute(f"""
        SELECT c.*, f.code AS form_code, f.name AS form_name, u.name AS requester_name, h.name AS handler_name,
               fa.name AS factory_name
        FROM cs_change_requests c JOIN cs_forms f ON f.id=c.form_id LEFT JOIN users u ON u.id=c.requester_id
        LEFT JOIN users h ON h.id=c.handler_id LEFT JOIN factories fa ON fa.id=f.factory_id
        WHERE {' AND '.join(cond)} ORDER BY CASE c.status WHEN 'open' THEN 0 WHEN 'accepted' THEN 1 ELSE 2 END, c.id DESC
        LIMIT ?""", params + [limit])]


def count_open(db, factory_id: int | None = None) -> int:
    return db.execute("""SELECT COUNT(*) FROM cs_change_requests c JOIN cs_forms f ON f.id=c.form_id
                         WHERE c.status IN ('open','accepted') AND (? IS NULL OR f.factory_id=?)""",
                      (factory_id, factory_id)).fetchone()[0]


def set_status(db, cid: int, status: str, actor_id: int, reply: str = "") -> dict:
    from .notify import notify_user_app
    c = get(db, cid)
    if not c:
        raise ChangeError("ไม่พบคำขอ")
    if status not in STATUS_TH:
        raise ChangeError("สถานะไม่ถูกต้อง")
    reply = str(reply or "").strip()
    if status == "rejected" and len(reply) < 3:
        raise ChangeError("กรุณาระบุเหตุผลที่ไม่แก้ไข เพื่อแจ้งผู้ขอ")
    db.execute("UPDATE cs_change_requests SET status=?, handler_id=?, handled_at=?, reply=? WHERE id=?",
               (status, actor_id, S.ts(), reply[:500] or c["reply"] or "", cid))
    S.audit(db, actor_id, "change_request_" + status, "cs_forms", c["form_id"], before={"status": c["status"]},
            after={"id": cid, "status": status, "reply": reply})
    if c["requester_id"] != actor_id and status != c["status"]:
        notify_user_app(db, c["requester_id"], "change_request", f"คำขอแก้ไข {c['form_code'] or ''}: {STATUS_TH[status]}",
                        (c["item_name"] + " · " if c["item_name"] else "") + (reply or KINDS.get(c["kind"], "")),
                        "/m/requests", "info", f"chreq:{cid}:{status}")
    return get(db, cid)


# ───────────────────────── ประเภทหัวข้อที่เพิ่มเอง ─────────────────────────

def _clean_options(opts) -> list[dict]:
    out = []
    for o in opts or []:
        label = str((o or {}).get("label") or "").strip()[:80]
        if label and label not in [x["label"] for x in out]:
            out.append({"label": label, "ng": 1 if (o or {}).get("ng") else 0})
    return out[:20]


def presets(db, include_inactive: bool = False) -> list[dict]:
    rows = db.execute("SELECT * FROM cs_item_presets" + ("" if include_inactive else " WHERE active=1") + " ORDER BY name").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["options"] = json.loads(d["options"] or "[]")
        except ValueError:
            d["options"] = []
        out.append(d)
    return out


def save_preset(db, data: dict, actor_id, preset_id: int | None = None) -> int:
    name = str(data.get("name") or "").strip()[:60]
    t = data.get("item_type")
    if not name:
        raise ChangeError("กรุณาตั้งชื่อประเภท")
    if t not in BASE_TYPES:
        raise ChangeError("ประเภทพื้นฐานไม่ถูกต้อง")
    opts = _clean_options(data.get("options"))
    if t == "choice" and len(opts) < 2:
        raise ChangeError("ประเภทตัวเลือกต้องมีอย่างน้อย 2 ตัวเลือก")

    def num(v):
        try:
            return float(v) if v not in (None, "") else None
        except (TypeError, ValueError):
            return None
    vals = (name, t, json.dumps(opts if t == "choice" else [], ensure_ascii=False), str(data.get("unit") or "").strip()[:20],
            num(data.get("min_value")), num(data.get("max_value")))
    dup = db.execute("SELECT id FROM cs_item_presets WHERE name=? AND active=1 AND id<>?", (name, preset_id or 0)).fetchone()
    if dup:
        raise ChangeError("มีประเภทชื่อนี้แล้ว")
    if preset_id:
        db.execute("UPDATE cs_item_presets SET name=?, item_type=?, options=?, unit=?, min_value=?, max_value=? WHERE id=?",
                   vals + (preset_id,))
    else:
        preset_id = db.execute("""INSERT INTO cs_item_presets(name, item_type, options, unit, min_value, max_value, created_by, created_at)
                                  VALUES (?,?,?,?,?,?,?,?)""", vals + (actor_id, S.ts())).lastrowid
    S.audit(db, actor_id, "item_preset", "cs_item_presets", preset_id, after={"name": name, "type": t})
    return preset_id


def delete_preset(db, preset_id: int, actor_id) -> None:
    db.execute("UPDATE cs_item_presets SET active=0 WHERE id=?", (preset_id,))
    S.audit(db, actor_id, "item_preset_delete", "cs_item_presets", preset_id)
