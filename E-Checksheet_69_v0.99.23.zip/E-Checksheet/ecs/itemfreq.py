"""ecs/itemfreq.py — ความถี่การตรวจรายหัวข้อ (หลายความถี่ในแบบฟอร์มเดียว)

ตัวอย่าง: แบบฟอร์มมีรอบตรวจ 4 ครั้ง/วัน (02:00, 08:00, 14:00, 20:00)
  - หัวข้อ "ทุกรอบ"       → ขึ้นทุกครั้ง (ค่าเริ่มต้น)
  - หัวข้อ "กะละ 1 ครั้ง"  → ขึ้นครั้งแรกของกะ ตรวจแล้วรอบถัดไปในกะเดียวกันจะไม่ขึ้น
  - หัวข้อ "วันละ 1 ครั้ง" → ขึ้นจนกว่าจะมีคนตรวจในวันนั้น (วันเริ่มตามเวลาเริ่มวันทำงาน)
  - หัวข้อ "ตามเวลา"      → กำหนดเวลาเอง เช่น 08:00, 20:00

หลักการ (ต้องตรงกับ fill.js):
  ช่วงปัจจุบัน = เวลาเริ่มช่วงล่าสุดที่ <= เวลาอ้างอิง (เวลาอ้างอิง = max(ตอนนี้, เวลาเริ่มรอบ) + ผ่อนผัน)
  หัวข้อ "ถึงเวลาตรวจ" เมื่อยังไม่มีผลตรวจตั้งแต่ (เริ่มช่วง − ผ่อนผัน)
  ผ่อนผัน = 30 นาที (หรือ 1/4 ของระยะห่างที่สั้นที่สุด) — ตรวจก่อนเวลาเล็กน้อยก็นับให้ช่วงนั้น
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta

FREQS = {
    "": "ทุกรอบ",
    "shift": "กะละ 1 ครั้ง",
    "day": "วันละ 1 ครั้ง",
    "times": "ตามเวลาที่กำหนด",
    "week": "สัปดาห์ละ 1 ครั้ง",
    "month": "เดือนละ 1 ครั้ง",
    "w:2": "เดือนละ 2 ครั้ง (ทุก 2 สัปดาห์)",
}
# v0.32 ความถี่แบบช่วง "ทุก N วัน/สัปดาห์/เดือน" — รหัส d:N · w:N · m:N (ผู้ดูแลระบบเพิ่มเองได้ เก็บใน cs_meta 'custom_freqs')
INTERVAL_RE = re.compile(r"^([dwm]):(\d{1,3})$")
UNIT_TH = {"d": "วัน", "w": "สัปดาห์", "m": "เดือน"}
UNIT_MAX = {"d": 366, "w": 52, "m": 24}
EPOCH = datetime(2024, 1, 1)                                   # วันจันทร์ — จุดตั้งต้นนับช่วง (ทุก 2 สัปดาห์ ฯลฯ)
DEFAULT_CALENDAR = {"shift_times": "08:00,20:00", "day_start": "08:00"}
GRACE_MIN = 30
TIME_RE = re.compile(r"^([01]?\d|2[0-3])[:.]([0-5]\d)$")


class FreqError(ValueError):
    pass


def parse_times(text: str | None) -> list[int]:
    """'08:00, 20:00' → [480, 1200] (นาทีนับจากเที่ยงคืน, เรียง, ไม่ซ้ำ) — ยก FreqError ถ้ารูปแบบผิด"""
    out = []
    for part in re.split(r"[,\s;/]+", str(text or "").strip()):
        if not part:
            continue
        m = TIME_RE.match(part)
        if not m:
            raise FreqError(f"เวลา '{part}' ไม่ถูกต้อง (ใช้รูปแบบ 08:00)")
        out.append(int(m.group(1)) * 60 + int(m.group(2)))
    return sorted(set(out))


def fmt_times(mins: list[int]) -> str:
    return ", ".join(f"{m // 60:02d}:{m % 60:02d}" for m in mins)


def interval(freq: str) -> tuple[str, int] | None:
    m = INTERVAL_RE.match(str(freq or ""))
    if not m:
        return None
    unit, n = m.group(1), int(m.group(2))
    return (unit, n) if 1 <= n <= UNIT_MAX[unit] else None


def interval_label(freq: str) -> str:
    iv = interval(freq)
    if not iv:
        return ""
    unit, n = iv
    return f"{UNIT_TH[unit]}ละ 1 ครั้ง" if n == 1 else f"ทุก {n} {UNIT_TH[unit]}"


def custom_freqs(db) -> list[dict]:
    """[{code, label}] ที่ผู้ดูแลระบบเพิ่มเอง"""
    row = db.execute("SELECT value FROM cs_meta WHERE key='custom_freqs'").fetchone()
    try:
        data = json.loads(row[0]) if row and row[0] else []
    except ValueError:
        data = []
    out = []
    for x in data if isinstance(data, list) else []:
        code = str((x or {}).get("code") or "")
        if interval(code) and code not in FREQS and code not in {o["code"] for o in out}:
            out.append({"code": code, "label": str(x.get("label") or "").strip()[:60] or interval_label(code)})
    return out


def save_custom_freqs(db, rows: list[dict]) -> list[dict]:
    out, seen = [], set(FREQS)
    for x in rows:
        unit = str(x.get("unit") or "")
        try:
            n = int(x.get("n") or 0)
        except (TypeError, ValueError):
            n = 0
        label_ = str(x.get("label") or "").strip()[:60]
        if not unit and not n and not label_:
            continue
        if unit not in UNIT_TH or not 1 <= n <= UNIT_MAX.get(unit, 0):
            raise FreqError(f"ความถี่ '{label_ or '-'}': ระบุทุกกี่ วัน/สัปดาห์/เดือน (วันไม่เกิน 366 · สัปดาห์ไม่เกิน 52 · เดือนไม่เกิน 24)")
        code = f"{unit}:{n}"
        if code in seen:
            raise FreqError(f"ความถี่ '{label_ or interval_label(code)}' ซ้ำกับที่มีอยู่แล้ว")
        seen.add(code)
        out.append({"code": code, "label": label_ or interval_label(code)})
    if len(out) > 20:
        raise FreqError("เพิ่มความถี่เองได้ไม่เกิน 20 แบบ")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('custom_freqs', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(out, ensure_ascii=False),))
    return out


def all_freqs(db) -> dict:
    """{code: label} ทั้งหมด (ในระบบ + ที่ผู้ดูแลระบบเพิ่ม) — เรียงตามลำดับที่แสดงในตัวเลือก"""
    out = dict(FREQS)
    for x in custom_freqs(db):
        out[x["code"]] = x["label"]
    return dict(sorted(out.items(), key=lambda kv: freq_days(kv[0])))


def freq_days(code: str) -> float:
    """ลำดับการแสดง: ทุกรอบ → ถี่ → ห่าง"""
    fixed = {"": -1, "times": 0.4, "shift": 0.5, "day": 1, "week": 7, "month": 30.5}
    if code in fixed:
        return fixed[code]
    iv = interval(code)
    return iv[1] * {"d": 1, "w": 7, "m": 30.5}[iv[0]] + 0.01 if iv else 999


def get_calendar(db) -> dict:
    cal = dict(DEFAULT_CALENDAR)
    row = db.execute("SELECT value FROM cs_meta WHERE key='work_calendar'").fetchone()
    if row and row[0]:
        try:
            saved = json.loads(row[0])
            cal.update({k: str(v) for k, v in saved.items() if k in cal})
        except ValueError:
            pass
    try:
        cal["freqs"] = all_freqs(db)                           # v0.32 ชื่อความถี่ (ส่งให้หน้ากรอก/Builder)
    except Exception:                                          # noqa: BLE001 — ตาราง cs_meta ยังไม่พร้อม
        cal["freqs"] = dict(FREQS)
    return cal


def save_calendar(db, data: dict) -> dict:
    shifts = parse_times(data.get("shift_times"))
    day = parse_times(data.get("day_start"))
    if not shifts:
        raise FreqError("กรุณาระบุเวลาเริ่มกะอย่างน้อย 1 เวลา")
    if len(shifts) > 6:
        raise FreqError("เวลาเริ่มกะได้ไม่เกิน 6 กะ")
    if len(day) != 1:
        raise FreqError("เวลาเริ่มวันทำงานต้องมี 1 เวลา")
    cal = {"shift_times": fmt_times(shifts), "day_start": fmt_times(day)}
    db.execute("INSERT INTO cs_meta(key, value) VALUES('work_calendar', ?) "
               "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(cal),))
    return cal


def normalize(freq, times) -> tuple[str, str]:
    """ค่าจาก Builder → (check_freq, check_times) พร้อมบันทึก"""
    freq = str(freq or "").strip()
    if freq not in FREQS and not interval(freq):
        raise FreqError(f"ความถี่ '{freq}' ไม่รองรับ")
    if freq != "times":
        return freq, ""
    mins = parse_times(times)
    if not mins:
        raise FreqError("ความถี่ 'ตามเวลาที่กำหนด' ต้องระบุเวลาอย่างน้อย 1 เวลา เช่น 08:00, 20:00")
    if len(mins) > 24:
        raise FreqError("กำหนดเวลาได้ไม่เกิน 24 เวลา/วัน")
    return freq, fmt_times(mins)


def _slot_minutes(freq: str, times: str, cal: dict) -> list[int]:
    if freq == "shift":
        return parse_times(cal.get("shift_times")) or [480]
    if freq == "times":
        return parse_times(times) or [480]
    return parse_times(cal.get("day_start")) or [480]


def grace(freq: str, times: str, cal: dict) -> timedelta:
    if freq in ("shift", "times"):
        mins = _slot_minutes(freq, times, cal)
        if len(mins) > 1:
            gaps = [b - a for a, b in zip(mins, mins[1:])] + [mins[0] + 1440 - mins[-1]]
            return timedelta(minutes=min(GRACE_MIN, min(gaps) / 4))
    return timedelta(minutes=GRACE_MIN)


def slot_start(freq: str, times: str, ref: datetime, cal: dict) -> datetime | None:
    """เวลาเริ่มช่วงที่ ref อยู่ (None = ทุกรอบ)"""
    if not freq:
        return None
    mins = _slot_minutes(freq, times, cal)
    base = ref.replace(hour=0, minute=0, second=0, microsecond=0)
    if freq in ("shift", "times", "day"):
        cands = [base + timedelta(days=d, minutes=m) for d in (0, -1) for m in mins]
        return max(c for c in cands if c <= ref)
    day_min = mins[0]
    iv = interval(freq)
    if iv:
        unit, n = iv
        if unit == "m":                                        # เดือน: นับจาก ม.ค. 2024 ทีละ n เดือน
            first = base.replace(day=1) + timedelta(minutes=day_min)
            if first > ref:
                first = (base.replace(day=1) - timedelta(days=1)).replace(day=1) + timedelta(minutes=day_min)
            k = (first.year - EPOCH.year) * 12 + first.month - 1
            k -= k % n
            return first.replace(year=EPOCH.year + k // 12, month=k % 12 + 1, day=1)
        step = timedelta(days=n * (7 if unit == "w" else 1))
        start0 = EPOCH + timedelta(minutes=day_min)
        k = (ref - start0) // step
        return start0 + k * step
    if freq == "week":                                          # สัปดาห์เริ่มวันจันทร์
        start = base - timedelta(days=ref.weekday()) + timedelta(minutes=day_min)
        return start if start <= ref else start - timedelta(days=7)
    if freq == "month":
        start = base.replace(day=1) + timedelta(minutes=day_min)
        if start <= ref:
            return start
        prev = (base.replace(day=1) - timedelta(days=1)).replace(day=1)
        return prev + timedelta(minutes=day_min)
    return None


def next_slot(freq: str, times: str, ref: datetime, cal: dict) -> datetime | None:
    cur = slot_start(freq, times, ref, cal)
    if cur is None:
        return None
    if freq in ("shift", "times", "day"):
        mins = _slot_minutes(freq, times, cal)
        base = cur.replace(hour=0, minute=0, second=0, microsecond=0)
        cands = sorted(base + timedelta(days=d, minutes=m) for d in (0, 1) for m in mins)
        return next(c for c in cands if c > cur)
    if freq == "week":
        return cur + timedelta(days=7)
    iv = interval(freq)
    if iv:
        unit, n = iv
        if unit != "m":
            return cur + timedelta(days=n * (7 if unit == "w" else 1))
        k = cur.month - 1 + n
        return cur.replace(year=cur.year + k // 12, month=k % 12 + 1)
    first = cur.replace(day=1)
    return (first + timedelta(days=32)).replace(day=1, hour=cur.hour, minute=cur.minute)


def reference_time(now: datetime, round_due: datetime | None) -> datetime:
    return max(now, round_due) if round_due and round_due > now else now


def is_due(freq: str, times: str, last_done: datetime | None, ref: datetime, cal: dict) -> bool:
    if not freq:
        return True
    g = grace(freq, times, cal)
    start = slot_start(freq, times, ref + g, cal)
    return last_done is None or last_done < start - g


def label(freq: str, times: str = "", cal: dict | None = None) -> str:
    """ข้อความสั้นสำหรับแสดง เช่น 'กะละ 1 ครั้ง' / '2 ครั้ง/วัน: 08:00, 20:00'"""
    if not freq:
        return ""
    if freq == "times":
        mins = parse_times(times)
        return f"{len(mins)} ครั้ง/วัน: {fmt_times(mins)}" if mins else FREQS["times"]
    if cal and cal.get("freqs") and freq in cal["freqs"]:
        return cal["freqs"][freq]
    return FREQS.get(freq, "") or interval_label(freq)
