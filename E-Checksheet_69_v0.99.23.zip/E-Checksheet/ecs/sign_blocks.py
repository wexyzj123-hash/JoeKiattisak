"""ecs/sign_blocks.py — ช่องลงนามเพิ่มเติมในใบบันทึกรายเดือน (ตั้งรายแบบฟอร์ม)

  แถวลงนามในตาราง : ช่องรวมรายสัปดาห์ (จ–อา) หรือรายเดือน เช่น "หน่วยงานสิ่งแวดล้อม (ตรวจสอบสัปดาห์ละครั้ง)"
  กล่องลงนามมุมขวาบน: ENVIRONMENT (MANAGER / SSV-SV) หรือ SAFETY (ตรวจสอบและอนุมัติเอกสารหลังใช้งาน: DM ▶ SAFETY)
  v0.23: 1 เอกสาร = 1 หน่วยงาน (ENVIRONMENT หรือ SAFETY อย่างใดอย่างหนึ่ง) · หัวหน้างานใช้แถว "หัวหน้างาน" ที่ดึงจากการอนุมัติในระบบ
เก็บใน cs_forms.sign_config (JSON) · แบบฟอร์มที่ใช้แม่แบบและยังไม่ตั้งเอง ใช้ค่าของแม่แบบ
"""
from __future__ import annotations

import json
from datetime import date

from . import services as S

PRESET_ROWS = {
    "env_week": ("หน่วยงานสิ่งแวดล้อม (ตรวจสอบสัปดาห์ละครั้ง)", "week"),
    "safety_month": ("ฝ่าย Safety (ตรวจสอบเดือนละครั้ง)", "month"),
}
ROW_DEPT = {"env_week": "env", "safety_month": "safety"}
UTIL_BOX = {"title": "Utility", "cols": [("Manager", ""), ("SV/SSV", "")], "flow": False, "note": "", "role_bottom": True,
            "order": [1, 0]}
PRESET_BOXES = {
    # groups = กลุ่มผู้มีสิทธิ์ลงนามแต่ละช่อง (ecs/signoffs) · order = ลำดับการลงนาม (index ของ cols)
    "env": {"title": "ENVIRONMENT", "cols": [("MANAGER", "APPROVED BY"), ("SSV/SV", "CHECKED BY")], "flow": False,
            "note": "", "groups": ["env_mgr", "env_sv"], "order": [1, 0]},
    "safety": {"title": "", "cols": [("DM", ""), ("SAFETY", "")], "flow": True,
               "note": "ตรวจสอบและอนุมัติเอกสารหลังใช้งาน", "groups": ["dm", "safety_sf"], "order": [0, 1]},   # DM = ตำแหน่ง DM
}
BOX_TH = {"env": "ENVIRONMENT — MANAGER (Approved) / SSV-SV (Checked)",
          "safety": "SAFETY — ตรวจสอบและอนุมัติเอกสารหลังใช้งาน: DM ▶ SAFETY"}
FREQ_TH = {"week": "1 ครั้ง/สัปดาห์", "month": "1 ครั้ง/เดือน"}
# v0.37 ความยาวช่องเซ็นของแถว "ผู้ตรวจ (Tech)" และ "หัวหน้างาน (Sr.Tech)" ในตาราง — ตั้งรายแบบฟอร์ม (แม่แบบส่งต่อให้เครื่อง)
SPAN_KEYS = ("insp_span", "sup_span")
SPANS = {"auto": "ตามรอบตรวจของแบบฟอร์ม (อัตโนมัติ)", "day": "ทุกวัน (ช่องละ 1 วัน)",
         "shift": "ทุกวัน แยกกะกลางวัน / กะกลางคืน (2 แถว · เฉพาะผู้ตรวจ)", "week": "ทุกสัปดาห์ (จ–อา)",
         "w:2": "ทุก 2 สัปดาห์", "half": "ครึ่งเดือน (1–15 / 16–สิ้นเดือน)", "month": "1 ครั้งต่อเดือน (ช่องเดียวทั้งเดือน)"}
# v0.25 ตรามุมซ้ายบนของใบบันทึก (เลือกรายแบบฟอร์ม · ค่าเริ่มต้น PROTECTED · UTILITY)
STAMPS = {"utility": ("doc-stamp.png", "PROTECTED 関係者外秘 · UTILITY Div."),
          "se": ("doc-stamp-se.png", "PROTECTED 関係者外秘 · SE Division")}
STAMP_TH = {"utility": "PROTECTED · UTILITY Div. (ค่าเริ่มต้น)", "se": "PROTECTED · SE Division"}


def stamp_own(db, form_id: int) -> str:
    r = db.execute("SELECT COALESCE(doc_stamp,'') FROM cs_forms WHERE id=?", (form_id,)).fetchone()
    return r[0] if r and r[0] in STAMPS else ""


def stamp_of(db, form: dict) -> str:
    """ตราที่ใช้จริง: ของแบบฟอร์มเอง → ของแม่แบบ → utility"""
    k = stamp_own(db, form["id"]) if form.get("id") else ""
    if not k and form.get("template_id"):
        k = stamp_own(db, form["template_id"])
    return k or "utility"


def save_stamp(db, form_ids: list[int], key: str, actor_id) -> int:
    key = key if key in STAMPS else ""
    n = 0
    for fid in form_ids:
        r = db.execute("SELECT COALESCE(doc_stamp,'') FROM cs_forms WHERE id=?", (fid,)).fetchone()
        if r and r[0] != key:
            db.execute("UPDATE cs_forms SET doc_stamp=? WHERE id=?", (key, fid))
            S.audit(db, actor_id, "doc_stamp", "cs_forms", fid, before=r[0], after=key)
            n += 1
    return n


EMPTY = {"rows": [], "custom_rows": [], "boxes": []}


def parse(raw) -> dict:
    try:
        d = json.loads(raw) if isinstance(raw, str) and raw else (raw or {})
    except ValueError:
        d = {}
    rows = list(dict.fromkeys(k for k in d.get("rows") or [] if k in PRESET_ROWS))
    custom = []
    for c in d.get("custom_rows") or []:
        lbl = str((c or {}).get("label") or "").strip()[:80]
        if lbl:
            custom.append({"label": lbl, "freq": c.get("freq") if c.get("freq") in FREQ_TH else "week"})
    boxes = [k for k in d.get("boxes") or [] if k in PRESET_BOXES][:1]      # ENVIRONMENT หรือ SAFETY อย่างเดียว
    dept = boxes[0] if boxes else next((ROW_DEPT[k] for k in rows), None)
    rows = [k for k in rows if ROW_DEPT[k] == dept]                       # ไม่ปนแถวของอีกหน่วยงาน
    out = {"rows": rows, "custom_rows": custom[:6], "boxes": boxes}
    if d.get("util"):                                                      # v0.26 กล่อง Utility มุมขวาบน
        out["util"] = True
    for k in SPAN_KEYS:                                                    # v0.37 ความยาวช่องเซ็นผู้ตรวจ / หัวหน้างาน
        if d.get(k) in SPANS and d.get(k) != "auto":
            out[k] = d[k]
    return out


def from_form(data) -> dict:
    """ฟอร์มเว็บ → config: sb_rows (หลายค่า) · sb_dept (env/safety/ว่าง) · sb_custom (textarea: 'ชื่อ | สัปดาห์/เดือน' ต่อบรรทัด)"""
    custom = []
    for line in (data.get("sb_custom") or "").splitlines():
        if not line.strip():
            continue
        label, _, fq = line.partition("|")
        fq = fq.strip().lower()
        custom.append({"label": label.strip(), "freq": "month" if fq.startswith(("เดือน", "month", "m")) else "week"})
    get = data.getlist if hasattr(data, "getlist") else (lambda k: data.get(k) or [])
    dept = (data.get("sb_dept") or "").strip()
    boxes = [dept] if dept else list(get("sb_boxes"))                     # sb_boxes = รูปแบบเดิม (รองรับย้อนหลัง)
    return parse({"rows": get("sb_rows"), "boxes": boxes, "custom_rows": custom, "util": bool(data.get("sb_util"))})


def dept(cfg: dict) -> str:
    return (cfg.get("boxes") or [""])[0]


def custom_text(cfg: dict) -> str:
    return "\n".join(f"{c['label']} | {'เดือน' if c['freq'] == 'month' else 'สัปดาห์'}" for c in cfg.get("custom_rows") or [])


def is_empty(cfg: dict) -> bool:
    return not (cfg.get("rows") or cfg.get("custom_rows") or cfg.get("boxes") or cfg.get("util"))


def own(db, form_id: int) -> dict:
    r = db.execute("SELECT sign_config FROM cs_forms WHERE id=?", (form_id,)).fetchone()
    return parse(r["sign_config"] if r else None)


def effective(db, form: dict) -> dict:
    cfg = own(db, form["id"])
    tpl = own(db, form["template_id"]) if form.get("template_id") else {}
    out = dict(tpl) if is_empty(cfg) and form.get("template_id") else dict(cfg)
    for k in SPAN_KEYS:                                     # ความยาวช่องเซ็น: ของแบบฟอร์มเอง → ของแม่แบบ → อัตโนมัติ
        v = cfg.get(k) or tpl.get(k)
        if v:
            out[k] = v
        else:
            out.pop(k, None)
    return out


# ───────────────────────── v0.37 ความยาวช่องเซ็นตามรอบตรวจ ─────────────────────────
def _code_days(code: str) -> int:
    from .itemfreq import interval
    if code in ("day", "shift"):
        return 1
    if code == "week":
        return 7
    if code == "half":
        return 15
    if code == "month":
        return 31
    iv = interval(code)
    if iv:
        return iv[1] * {"d": 1, "w": 7, "m": 31}[iv[0]]
    return 1


def auto_insp_span(db, form: dict) -> str:
    """ช่องผู้ตรวจอัตโนมัติ: หัวข้อที่ตรวจทุกวัน/หลายครั้งต่อวัน → รายวัน · ทุกหัวข้อเป็นรอบยาว → ช่วงที่สั้นที่สุด"""
    from . import sheet_report as SR
    from .itemfreq import get_calendar, interval
    sch = [dict(r) for r in db.execute("SELECT freq_type FROM cs_schedules WHERE form_id=? AND active=1", (form["id"],))]
    fts = [x["freq_type"] or "" for x in sch]
    form_kind, mins = SR._form_period(db, form["id"])
    form_code = "day"
    if form_kind == "week":
        ws = [interval(f) for f in fts if f.startswith("w:")]
        form_code = "week" if "weekly" in fts or not ws else f"w:{min(iv[1] for iv in ws)}"
        if form_code == "w:1":
            form_code = "week"
    elif form_kind in ("half", "month"):
        form_code = form_kind
    if form_code == "day" and shift_rows(db, form["id"]):      # v0.42 รอบตรวจทั้งกะกลางวันและกลางคืน → แยก 2 แถว
        return "shift"
    items = SR._items_for(db, [], form.get("current_version_id")) if form.get("current_version_id") else []
    if not items:
        return form_code
    cal = get_calendar(db)
    codes = []
    for it in items:
        kind, _m = SR._item_period(it, form_kind, mins, cal)
        if kind in ("slots", "free"):
            return "day"
        if kind == "period":
            codes.append(it.get("check_freq") or "week")
        elif kind == "week" and not (it.get("check_freq") or ""):
            codes.append(form_code if form_code != "day" else "week")
        else:
            codes.append(kind)
    return min(codes, key=_code_days) if codes else form_code


def resolve_spans(db, form: dict, cfg: dict | None = None) -> tuple[str, str]:
    """(ช่องผู้ตรวจ, ช่องหัวหน้างาน) ที่ใช้จริง — ค่าที่ตั้ง หรือคำนวณจากรอบตรวจ (หัวหน้างานอัตโนมัติ ≥ 1 สัปดาห์)"""
    cfg = cfg if cfg is not None else effective(db, form)
    ins, sup = cfg.get("insp_span") or "auto", cfg.get("sup_span") or "auto"
    auto = auto_insp_span(db, form) if "auto" in (ins, sup) else ""
    if ins == "auto":
        ins = auto
    if sup == "auto":
        sup = auto if _code_days(auto) >= 7 else "week"
    if sup == "shift":                                    # แยกกะใช้กับแถวผู้ตรวจเท่านั้น
        sup = "day"
    if ins == "shift" and form.get("id") and not shift_rows(db, form["id"]):
        ins = "day"                                       # ไม่มีรอบกลางคืน → แถวเดียว
    return ins, sup


# ───────────────────────── v0.42 แถวผู้ตรวจแยกกะกลางวัน / กะกลางคืน ─────────────────────────
SHIFT_TH = {"day": "กะกลางวัน", "night": "กะกลางคืน"}


def _shift_starts(cal: dict) -> list[int]:
    from .itemfreq import parse_times
    return sorted(parse_times(cal.get("shift_times")))


def shift_of(minute: int, cal: dict) -> str:
    """กะของเวลา (นาทีของวัน): กะที่เริ่มก่อนหรือ ≤ 30 นาทีหลังเวลานี้ · กะที่เริ่ม 05:00–16:59 = กลางวัน นอกนั้น = กลางคืน
    ไม่ได้ตั้งเวลากะ 2 กะขึ้นไป → 06:00–17:59 = กลางวัน"""
    starts = _shift_starts(cal)
    if len(starts) < 2:
        return "day" if 6 * 60 <= minute < 18 * 60 else "night"
    t = (minute + 30) % 1440
    st = max((x for x in starts if x <= t), default=starts[-1])
    return "day" if 5 * 60 <= st < 17 * 60 else "night"


def shift_rows(db, form_id) -> list[dict]:
    """[{key, label, times}] ถ้ารอบตรวจรายวัน/รายกะของแบบฟอร์มมีทั้งเวลากลางวันและกลางคืน · ไม่งั้น []"""
    from .itemfreq import fmt_times, get_calendar, parse_times
    cal = get_calendar(db)
    got: dict[str, set] = {"day": set(), "night": set()}
    for r in db.execute("""SELECT times FROM cs_schedules WHERE form_id=? AND active=1
                           AND (freq_type IN ('daily','shift') OR freq_type LIKE 'd:%')""", (form_id,)):
        for m in parse_times(r[0]):
            got[shift_of(m, cal)].add(m)
    if not (got["day"] and got["night"]):
        return []
    return [{"key": k, "label": SHIFT_TH[k], "times": fmt_times(sorted(got[k]))} for k in ("day", "night")]


def span_th(code: str) -> str:
    """คำในช่อง 'ช่วง' ของแถวลงนาม"""
    from .itemfreq import UNIT_TH, interval
    iv = interval(code)
    if iv:
        return f"1 ครั้ง/{iv[1] if iv[1] > 1 else ''} {UNIT_TH[iv[0]]}".replace("/ ", "/")
    return {"day": "รายวัน", "shift": "รายกะ", "week": "1 ครั้ง/สัปดาห์", "half": "1 ครั้ง/ครึ่งเดือน", "month": "1 ครั้ง/เดือน"}.get(code, "")


def _anchor(db, form_id, unit: str) -> date:
    """วันเริ่มนับรอบของรอบตรวจแบบ 'ทุก N วัน/สัปดาห์' ของแบบฟอร์ม (ไม่มี = 1 ม.ค. 2024 วันจันทร์ — ตรงกับรอบตรวจ)
    ทุก N สัปดาห์ → วันจันทร์ของสัปดาห์แรกที่มีรอบ (S.week_base) ให้ช่องตรงกับรอบตรวจจริง"""
    if form_id:
        for r in db.execute("""SELECT anchor_date, weekdays FROM cs_schedules WHERE form_id=? AND active=1 AND freq_type LIKE ?
                               ORDER BY id""", (form_id, unit + ":%")):
            try:
                a = date.fromisoformat((r[0] or "")[:10])
            except ValueError:
                continue
            return S.week_base(a, r[1]) if unit == "w" else a
    return date(2024, 1, 1)


def segments(db, month: date, last: int, code: str, form_id=None) -> list[dict]:
    """ช่องรวมตามความยาวที่กำหนด: [{start, span, label}] (label ว่าง = ช่องเดียว/ทั้งเดือน)
    ทุก N วัน/สัปดาห์ นับช่วงจากวันเริ่มนับรอบของรอบตรวจ (ช่องตรงกับรอบตรวจจริง) · ตัดที่ขอบเดือน"""
    from datetime import timedelta
    if code in ("day", "shift"):
        return [{"start": d, "span": 1, "label": ""} for d in range(1, last + 1)]
    if code == "week":
        return week_segments(month, last)
    if code == "half":
        return [{"start": 1, "span": 15, "label": "1–15"}, {"start": 16, "span": last - 15, "label": f"16–{last}"}]
    from .itemfreq import interval
    iv = interval(code)
    if not iv or iv[0] == "m":
        return [{"start": 1, "span": last, "label": ""}]
    unit, n = iv
    anc = _anchor(db, form_id, unit)
    mon = anc - timedelta(days=anc.weekday())
    segs: list[dict] = []
    for d in range(1, last + 1):
        dd = date(month.year, month.month, d)
        key = (dd - anc).days // n if unit == "d" else ((dd - timedelta(days=dd.weekday())) - mon).days // 7 // n
        if segs and segs[-1]["key"] == key:
            segs[-1]["span"] += 1
        else:
            segs.append({"key": key, "start": d, "span": 1})
    for sg in segs:
        sg.pop("key")
        sg["label"] = f"{sg['start']}–{sg['start'] + sg['span'] - 1}" if sg["span"] > 1 else str(sg["start"])
    return segs


def sup_segments(db, form: dict, month: date, last: int | None = None) -> list[dict]:
    import calendar
    last = last or calendar.monthrange(month.year, month.month)[1]
    return segments(db, month, last, resolve_spans(db, form)[1], form.get("id"))


def _raw(cfg: dict) -> str:
    return "" if is_empty(cfg) and not any(cfg.get(k) for k in SPAN_KEYS) else json.dumps(cfg, ensure_ascii=False)


def save(db, form_ids: list[int], cfg: dict, actor_id) -> int:
    """บันทึกแถว/กล่องลงนาม — ค่าความยาวช่องเซ็น (insp_span/sup_span) เดิมของแต่ละแบบฟอร์มคงไว้ ถ้า cfg ไม่ได้ระบุ"""
    given = {k: cfg.get(k) for k in SPAN_KEYS if k in (cfg or {})}
    cfg = parse(cfg)
    n = 0
    for fid in form_ids:
        if db.execute("SELECT 1 FROM cs_forms WHERE id=?", (fid,)).fetchone():
            c = dict(cfg)
            cur = own(db, fid)
            for k in SPAN_KEYS:
                v = given.get(k, cur.get(k, ""))
                if v in SPANS and v != "auto":
                    c[k] = v
                else:
                    c.pop(k, None)
            db.execute("UPDATE cs_forms SET sign_config=? WHERE id=?", (_raw(c), fid))
            S.audit(db, actor_id, "sign_config", "cs_forms", fid, after=c)
            n += 1
    return n


def save_spans(db, form_ids: list[int], insp: str | None, sup: str | None, actor_id) -> int:
    """ตั้งความยาวช่องเซ็น (None / 'keep' = ไม่เปลี่ยน) แล้วคำนวณช่องหัวหน้างานที่เติมอัตโนมัติใหม่"""
    n = 0
    for fid in form_ids:
        cur = own(db, fid)
        c = dict(cur)
        for k, v in (("insp_span", insp), ("sup_span", sup)):
            if v is None or v == "keep":
                continue
            if v in SPANS and v != "auto":
                c[k] = v
            else:
                c.pop(k, None)
        if c != cur:
            db.execute("UPDATE cs_forms SET sign_config=? WHERE id=?", (_raw(c), fid))
            S.audit(db, actor_id, "sign_spans", "cs_forms", fid, before={k: cur.get(k, "auto") for k in SPAN_KEYS},
                    after={k: c.get(k, "auto") for k in SPAN_KEYS})
            n += 1
        from . import signoffs as SO
        for f2 in [fid] + [r[0] for r in db.execute("SELECT id FROM cs_forms WHERE template_id=?", (fid,))]:
            SO.resync_form(db, f2)
    return n


def week_segments(month: date, last: int) -> list[dict]:
    segs, d = [], 1
    while d <= last:
        dd = date(month.year, month.month, d)
        span = min(7 - dd.weekday(), last - d + 1)
        segs.append({"start": d, "span": span, "label": f"{d}–{d + span - 1}" if span > 1 else str(d)})
        d += span
    return segs


def build(db, form: dict, month: date, last: int) -> dict:
    """ข้อมูลสำหรับเรนเดอร์: rows [{label, freq, freq_th, segs[{start, span, label, so}], std}] (แถวแรก = หัวหน้างาน Sr.Tech รายสัปดาห์) ·
    boxes [preset + key + cells[{role, act, so}]] · month {insp, sup} = ช่องลงนามท้ายเอกสาร
    so = การยืนยันในระบบ {user_id, user_name, user_pos, signed_at} หรือ None"""
    from . import signoffs as SO
    cfg = effective(db, form)
    recs = SO.records(db, form["id"], month) if form.get("id") else {}
    keys = ["sup"] + list(cfg["rows"]) + [f"c{i}" for i in range(len(cfg["custom_rows"]))]
    ins_code, sup_code = resolve_spans(db, form, cfg) if form.get("id") else ("day", "week")
    rows = [{"label": SO.STD_WEEK["label"], "freq": sup_code, "std": True}]
    rows += [{"label": PRESET_ROWS[k][0], "freq": PRESET_ROWS[k][1]} for k in cfg["rows"]] + [dict(c) for c in cfg["custom_rows"]]
    for key, r in zip(keys, rows):
        r["freq_th"] = FREQ_TH.get(r["freq"]) or span_th(r["freq"])
        if r.get("std"):
            r["segs"] = [dict(sg) for sg in segments(db, month, last, sup_code, form.get("id"))]
        else:
            r["segs"] = [dict(sg) for sg in week_segments(month, last)] if r["freq"] == "week" else [{"start": 1, "span": last, "label": ""}]
        for sg in r["segs"]:
            sg["slot"] = f"row:{key}:{sg['start']}"          # v0.85 ปุ่มลงนามในใบบันทึก
            sg["so"] = recs.get(sg["slot"])
    boxes = []
    if cfg.get("util"):                                     # กล่อง Utility (ก่อนกล่องหน่วยงาน) · แทนช่องลงนามท้ายเอกสาร
        b = dict(UTIL_BOX, key="util")
        b["cells"] = [{"role": role, "act": act, "slot": f"box:util:{i}", "so": recs.get(f"box:util:{i}")} for i, (role, act) in enumerate(b["cols"])]
        boxes.append(b)
    for k in cfg["boxes"]:
        b = dict(PRESET_BOXES[k], key=k)
        b["cells"] = [{"role": role, "act": act, "slot": f"box:{k}:{i}", "so": recs.get(f"box:{k}:{i}")} for i, (role, act) in enumerate(b["cols"])]
        boxes.append(b)
    insp = {"code": ins_code, "freq_th": span_th(ins_code),
            "segs": [dict(sg) for sg in segments(db, month, last, ins_code, form.get("id"))] if ins_code not in ("day", "shift") else [],
            "shifts": shift_rows(db, form["id"]) if ins_code == "shift" and form.get("id") else []}
    return {"rows": rows, "boxes": boxes, "user_ids": [x["user_id"] for x in recs.values()], "insp": insp,
            "month": {"insp": recs.get("mon:insp"), "sup": recs.get("mon:sup")}, "util": bool(cfg.get("util"))}
