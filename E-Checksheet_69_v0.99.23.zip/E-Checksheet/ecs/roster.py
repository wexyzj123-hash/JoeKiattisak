"""ecs/roster.py — v0.50 ตารางกะ + มอบหมายโรงงาน (เชื่อม UT-CMMS อัตโนมัติ)

ตารางกะ = ตาราง tech_shift_plan ของ UT-CMMS (ข้อมูลชุดเดียวกัน แก้ฝั่งไหนก็เห็นทั้งสองระบบ)
  ผู้ใช้ที่ผูกกับ UT-CMMS (users.legacy_id) → อ่าน/เขียนที่ UT-CMMS · ไม่ได้ผูก / ไม่ได้เปิดผ่าน portal → ตาราง cs_shift_plan ในระบบนี้
  ประเภทกะเหมือน UT-CMMS: (ว่าง)=กะเช้า · ot · night_shift · day_off · sick — วันหยุด/เสาร์ทำงาน อ่านจาก UT-CMMS
มอบหมายโรงงาน = cs_user_factories (ช่าง 1 คนรับได้หลายโรงงาน) · ไม่ได้ติ๊กเลย = ใช้โรงงานในข้อมูลผู้ใช้ (ว่าง = ทุกโรงงาน)

กรองงานของช่าง (เปิด/ปิดได้ที่หน้าตารางกะ):
  รอบที่ยังเปิดอยู่ → เห็นเมื่อ "ช่วงเวลาที่เหลือของรอบ" อยู่ในกะของตัวเอง
  อยู่ในกะของช่างคนอื่นในโรงงานเดียวกัน → ย้ายไปกลุ่ม "กะอื่นรับผิดชอบ" (พร้อมชื่อผู้รับผิดชอบ)
  ไม่มีใครเข้ากะเลย → ทุกคนในโรงงานเห็น (ป้าย "ไม่มีช่างเข้ากะ") — งานไม่ตกหล่นแม้ไม่ได้ลงตารางกะ
"""
from __future__ import annotations

import json
import time as _time
from datetime import date, datetime, time, timedelta

from . import services as S
from . import terms as TR
from .services import parse_ts, ts

DDL = """
CREATE TABLE IF NOT EXISTS cs_shift_plan (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id),
    plan_date  TEXT NOT NULL,
    shift_type TEXT NOT NULL,
    notes      TEXT DEFAULT '',
    set_by     INTEGER,
    created_at TEXT NOT NULL,
    UNIQUE (user_id, plan_date)
);
CREATE TABLE IF NOT EXISTS cs_user_factories (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id),
    factory_id INTEGER NOT NULL REFERENCES factories(id),
    UNIQUE (user_id, factory_id)
);
CREATE INDEX IF NOT EXISTS idx_csuf_user ON cs_user_factories(user_id);
"""
PLAN_TYPES = ("ot", "night_shift", "day_off", "sick")       # '' = กะเช้า (ไม่ต้องลง)
DAY = (8 * 60, 17 * 60)
OT_END = 20 * 60
NIGHT_START, NIGHT_END = 17 * 60, 8 * 60                   # 17:00 → 08:00 วันถัดไป (ตาม UT-CMMS)
TEAM_ROLES = ("technician", "supervisor")
DEFAULTS = {"filter": True}
CACHE_SEC = 20
_CACHE: dict = {}


def ensure(db) -> None:
    db.executescript(DDL)


def invalidate() -> None:
    _CACHE.clear()


def get_settings(db) -> dict:
    cfg = dict(DEFAULTS)
    row = db.execute("SELECT value FROM cs_meta WHERE key='roster'").fetchone()
    if row and row[0]:
        try:
            cfg.update({k: v for k, v in json.loads(row[0]).items() if k in DEFAULTS})
        except ValueError:
            pass
    return cfg


def save_settings(db, data: dict, actor_id) -> dict:
    cfg = {"filter": data.get("filter") in (1, True, "1", "on", "true")}
    db.execute("INSERT INTO cs_meta(key, value) VALUES('roster', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(cfg),))
    S.audit(db, actor_id, "update", "cs_meta", None, after={"roster": cfg})
    return cfg


# ───────────────────────── แหล่งข้อมูล (UT-CMMS / ในระบบ) ─────────────────────────

_BOUND: dict = {}


def bind(app_config) -> None:
    """ผูกค่าตั้งของแอป (ตำแหน่งฐานข้อมูล UT-CMMS) ไว้ให้งานเบื้องหลังที่ไม่มี app context ใช้"""
    _BOUND.clear()
    if app_config.get("CMMS_DATABASE"):
        _BOUND["CMMS_DATABASE"] = app_config.get("CMMS_DATABASE")


def _app_config() -> dict:
    try:
        from flask import current_app, has_app_context
        if has_app_context():
            return current_app.config
    except Exception:                                               # noqa: BLE001
        pass
    return dict(_BOUND)


def _cmms(cfg=None):
    """connection ไป UT-CMMS (มีตารางกะ) หรือ None"""
    cfg = cfg if cfg is not None else _app_config()
    from .cmms_tpm import available, _connect
    if not available(cfg):
        return None
    try:
        con = _connect(cfg)
        if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='tech_shift_plan'").fetchone():
            return con
        con.close()
    except Exception:                                               # noqa: BLE001
        pass
    return None


def source_name(cfg=None) -> str:
    con = _cmms(cfg)
    if con:
        con.close()
        return "cmms"
    return "local"


def load(db, d0: date, d1: date, cfg=None) -> dict:
    """{'plans': {uid: {iso: (type, notes)}}, 'holidays': {iso: name}, 'worksat': set, 'source'}"""
    cfg = cfg if cfg is not None else _app_config()
    key = (str(cfg.get("CMMS_DATABASE") or ""), d0.isoformat(), d1.isoformat())
    hit = _CACHE.get(key) if key[0] else None                   # แคชเฉพาะตอนอ่าน UT-CMMS (ข้ามไฟล์ฐานข้อมูล)
    if hit and hit[0] > _time.monotonic():
        return hit[1]
    ensure(db)
    a, b = d0.isoformat(), d1.isoformat()
    plans: dict[int, dict] = {}
    for r in db.execute("SELECT user_id, plan_date, shift_type, notes FROM cs_shift_plan WHERE plan_date BETWEEN ? AND ?", (a, b)):
        plans.setdefault(r[0], {})[r[1]] = (r[2], r[3] or "")
    holidays: dict[str, str] = {}
    worksat: set[str] = set()
    source = "local"
    con = _cmms(cfg)
    if con:
        source = "cmms"
        try:
            by_legacy: dict[int, list[int]] = {}
            for r in db.execute("SELECT id, legacy_id FROM users WHERE legacy_id IS NOT NULL"):
                by_legacy.setdefault(r[1], []).append(r[0])
            for uid in {u for us in by_legacy.values() for u in us}:
                plans.pop(uid, None)                              # ผู้ใช้ที่ผูก UT-CMMS → ใช้ตารางของ UT-CMMS เท่านั้น
            for r in con.execute("SELECT user_id, plan_date, shift_type, notes FROM tech_shift_plan WHERE plan_date BETWEEN ? AND ?", (a, b)):
                for uid in by_legacy.get(r["user_id"], []):
                    plans.setdefault(uid, {})[r["plan_date"]] = (r["shift_type"], r["notes"] or "")
            try:
                holidays = {r[0]: r[1] or "วันหยุด" for r in con.execute(
                    "SELECT holiday_date, name FROM holidays WHERE holiday_date BETWEEN ? AND ?", (a, b))}
                worksat = {r[0] for r in con.execute(
                    "SELECT work_date FROM working_saturdays WHERE work_date BETWEEN ? AND ?", (a, b))}
            except Exception:                                       # noqa: BLE001 — UT-CMMS รุ่นเก่า
                pass
        finally:
            con.close()
    else:
        for d in S._holidays(db):
            if d0 <= d <= d1:
                holidays[d.isoformat()] = "วันหยุด"
    out = {"plans": plans, "holidays": holidays, "worksat": worksat, "source": source, "d0": d0, "d1": d1}
    if key[0]:
        _CACHE[key] = (_time.monotonic() + CACHE_SEC, out)
    if len(_CACHE) > 64:
        _CACHE.clear()
    return out


def is_workday(R: dict, day: date) -> bool:
    iso = day.isoformat()
    if iso in R["holidays"]:
        return False
    wd = day.weekday()
    if wd == 6:
        return False
    if wd == 5:
        return iso in R["worksat"]
    return True


def plan_type(R: dict, uid: int, day: date) -> str:
    return (R["plans"].get(uid, {}).get(day.isoformat()) or ("", ""))[0] or ""


def shift_key(R: dict, uid: int, day: date) -> str:
    """กะของวัน (คีย์ใน terms.SHIFT): day | ot | night_shift | day_off | sick | holiday"""
    t = plan_type(R, uid, day)
    if t in PLAN_TYPES:
        return t
    return "day" if is_workday(R, day) else "holiday"


def windows(R: dict, uid: int, day: date) -> list[tuple[datetime, datetime]]:
    """ช่วงเวลาทำงานของกะที่ "เริ่ม" ในวันนี้"""
    base = datetime.combine(day, time(0, 0))
    k = shift_key(R, uid, day)
    if k == "night_shift":
        return [(base + timedelta(minutes=NIGHT_START), base + timedelta(days=1, minutes=NIGHT_END))]
    if k == "ot":
        return [(base + timedelta(minutes=DAY[0]), base + timedelta(minutes=OT_END))]
    if k == "day":
        return [(base + timedelta(minutes=DAY[0]), base + timedelta(minutes=DAY[1]))]
    return []


def covers(R: dict, uid: int, a: datetime, b: datetime) -> bool:
    if b <= a:
        b = a + timedelta(minutes=1)
    day = a.date() - timedelta(days=1)
    while day <= b.date():
        for s, e in windows(R, uid, day):
            if s < b and a < e:
                return True
        day += timedelta(days=1)
    return False


def on_duty(R: dict, uid: int, at: datetime) -> bool:
    return covers(R, uid, at, at + timedelta(minutes=1))


def window_text(R: dict, uid: int, day: date) -> str:
    w = windows(R, uid, day)
    if not w:
        return ""
    s, e = w[0]
    return f"{s:%H:%M}–{e:%H:%M}"


# ───────────────────────── มอบหมายโรงงาน ─────────────────────────

def factories_of(db, uid: int) -> list[int] | None:
    """โรงงานที่ผู้ใช้รับผิดชอบ · None = ทุกโรงงาน"""
    ensure(db)
    rows = [r[0] for r in db.execute("SELECT factory_id FROM cs_user_factories WHERE user_id=? ORDER BY factory_id", (uid,))]
    if rows:
        return rows
    u = db.execute("SELECT factory_id FROM users WHERE id=?", (uid,)).fetchone()
    return [u[0]] if u and u[0] else None


def set_factories(db, uid: int, fids: list[int], actor_id) -> None:
    ensure(db)
    valid = {r[0] for r in db.execute("SELECT id FROM factories WHERE active=1")}
    new = sorted({int(f) for f in fids if int(f) in valid})
    before = [r[0] for r in db.execute("SELECT factory_id FROM cs_user_factories WHERE user_id=? ORDER BY factory_id", (uid,))]
    if before == new:
        return
    db.execute("DELETE FROM cs_user_factories WHERE user_id=?", (uid,))
    db.executemany("INSERT INTO cs_user_factories(user_id, factory_id) VALUES (?,?)", [(uid, f) for f in new])
    S.audit(db, actor_id, "update", "cs_user_factories", uid, before={"factories": before}, after={"factories": new})


def team(db) -> list[dict]:
    """ช่าง/หัวหน้างานที่ใช้งานอยู่ + โรงงานที่รับผิดชอบ"""
    ensure(db)
    assigned: dict[int, list[int]] = {}
    for r in db.execute("SELECT user_id, factory_id FROM cs_user_factories ORDER BY factory_id"):
        assigned.setdefault(r[0], []).append(r[1])
    out = []
    for r in db.execute(f"""SELECT id, name, role, factory_id, legacy_id, COALESCE(position,'') AS position FROM users
                            WHERE active=1 AND role IN ({','.join('?' * len(TEAM_ROLES))}) ORDER BY role DESC, name""", TEAM_ROLES):
        d = dict(r)
        d["factories"] = assigned.get(d["id"]) or ([d["factory_id"]] if d["factory_id"] else None)
        d["assigned"] = bool(assigned.get(d["id"]))
        out.append(d)
    return out


def factory_names(db) -> dict[int, str]:
    return {r[0]: r[1] for r in db.execute("SELECT id, COALESCE(NULLIF(code,''), name) FROM factories WHERE active=1 ORDER BY sort_no, id")}


# ───────────────────────── ตารางกะรายเดือน ─────────────────────────

WD_TH = ("จ", "อ", "พ", "พฤ", "ศ", "ส", "อา")


def month_grid(db, month: date, cfg=None) -> dict:
    d0 = month.replace(day=1)
    d1 = (d0 + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    R = load(db, d0, d1, cfg)
    days = []
    d = d0
    while d <= d1:
        days.append({"iso": d.isoformat(), "d": d.day, "wd": WD_TH[d.weekday()], "work": is_workday(R, d),
                     "holiday": R["holidays"].get(d.isoformat(), "")})
        d += timedelta(days=1)
    fn = factory_names(db)
    people = []
    for p in team(db):
        cells = {}
        for x in days:
            t = plan_type(R, p["id"], date.fromisoformat(x["iso"]))
            if t:
                cells[x["iso"]] = t
        p["cells"] = cells
        p["fac_text"] = ", ".join(fn.get(f, "?") for f in p["factories"]) if p["factories"] else "ทุกโรงงาน"
        p["linked"] = bool(p["legacy_id"]) and R["source"] == "cmms"
        people.append(p)
    return {"month": d0, "days": days, "people": people, "source": R["source"],
            "prev": (d0 - timedelta(days=1)).replace(day=1), "next": d1 + timedelta(days=1)}


def set_plans(db, items: list[dict], actor_id, cfg=None) -> int:
    """items = [{user_id, date, shift_type ('' = ลบ = กะเช้าปกติ), notes}]"""
    ensure(db)
    cfg = cfg if cfg is not None else _app_config()
    if len(items) > 8000:
        raise S.ValidationError("แก้ได้ครั้งละไม่เกิน 8,000 ช่อง")
    users = {r[0]: r[1] for r in db.execute(
        f"SELECT id, legacy_id FROM users WHERE active=1 AND role IN ({','.join('?' * len(TEAM_ROLES))})", TEAM_ROLES)}
    actor_legacy = (db.execute("SELECT legacy_id FROM users WHERE id=?", (actor_id,)).fetchone() or [None])[0]
    clean = []
    for it in items:
        try:
            uid = int(it.get("user_id"))
            day = date.fromisoformat(str(it.get("date"))[:10])
        except (TypeError, ValueError):
            raise S.ValidationError("ข้อมูลตารางกะไม่ถูกต้อง") from None
        st = (it.get("shift_type") or "").strip()
        if uid not in users:
            raise S.ValidationError("ผู้ใช้นี้ไม่ใช่ช่าง/หัวหน้างานที่ใช้งานอยู่")
        if st and st not in PLAN_TYPES:
            raise S.ValidationError("ประเภทกะไม่ถูกต้อง")
        clean.append((uid, day.isoformat(), st, str(it.get("notes") or "")[:200]))
    con = _cmms(cfg)
    now_s = ts(S.now_dt())
    n = 0
    try:
        for uid, iso, st, notes in clean:
            leg = users[uid]
            if con is not None and leg and con.execute("SELECT 1 FROM users WHERE id=?", (leg,)).fetchone():
                if st:
                    con.execute("""INSERT INTO tech_shift_plan (user_id, plan_date, shift_type, notes, set_by) VALUES (?,?,?,?,?)
                                   ON CONFLICT(user_id, plan_date) DO UPDATE SET shift_type=excluded.shift_type,
                                   notes=excluded.notes, set_by=excluded.set_by""", (leg, iso, st, notes, actor_legacy))
                else:
                    con.execute("DELETE FROM tech_shift_plan WHERE user_id=? AND plan_date=?", (leg, iso))
            elif st:
                db.execute("""INSERT INTO cs_shift_plan (user_id, plan_date, shift_type, notes, set_by, created_at) VALUES (?,?,?,?,?,?)
                              ON CONFLICT(user_id, plan_date) DO UPDATE SET shift_type=excluded.shift_type, notes=excluded.notes,
                              set_by=excluded.set_by""", (uid, iso, st, notes, actor_id, now_s))
            else:
                db.execute("DELETE FROM cs_shift_plan WHERE user_id=? AND plan_date=?", (uid, iso))
            n += 1
        if con is not None:
            con.commit()
    finally:
        if con is not None:
            con.close()
    invalidate()
    if n:
        S.audit(db, actor_id, "update", "cs_shift_plan", None,
                after={"changes": n, "sample": [{"user_id": u, "date": d, "shift": s} for u, d, s, _n in clean[:20]]})
    return n


# ───────────────────────── กรองงานตามกะ ─────────────────────────

def split_rounds(db, user: dict, rows: list[dict], now: datetime, cfg=None) -> tuple[list[dict], list[dict]]:
    """แยกงาน (ของช่าง) เป็น (ของฉัน, กะอื่นรับผิดชอบ) — ดูหัวไฟล์"""
    if user.get("role") != "technician" or not rows or not get_settings(db)["filter"]:
        return rows, []
    dues = [parse_ts(r["due_at"]) for r in rows if r.get("due_at")]
    closes = [parse_ts(r["close_at"]) for r in rows if r.get("close_at")]
    d0 = min([now] + [d for d in dues if d]).date() - timedelta(days=1)
    d1 = max([now] + [d for d in closes if d]).date() + timedelta(days=1)
    d1 = min(d1, now.date() + timedelta(days=40))
    R = load(db, d0, d1, cfg)
    members = [p for p in team(db) if p["role"] == "technician" and p["id"] != user["id"]]
    mine, other = [], []
    for r in rows:
        st = r.get("status")
        if st not in ("pending", "in_progress", "overdue"):
            mine.append(r)
            continue
        due, dl, cl = parse_ts(r["due_at"]), parse_ts(r["deadline_at"]), parse_ts(r["close_at"])
        if not due or not dl or (cl and cl <= now) or r.get("run_status") == "down":
            mine.append(r)
            continue
        a = max(due, now)
        b = dl if now < dl else (cl or dl + timedelta(hours=1))
        if covers(R, user["id"], a, b):
            if not covers(R, user["id"], due, dl):
                r["carry"] = True                       # ค้างจากกะก่อน
            mine.append(r)
            continue
        fid = r.get("factory_id")
        owners = [p for p in members if (p["factories"] is None or fid is None or fid in p["factories"])
                  and covers(R, p["id"], a, b)]
        if owners:
            r["owners"] = ", ".join(f"{p['name']} ({TR.label('SHIFT', _owner_shift(R, p['id'], a))})" for p in owners[:3]) + \
                (f" +{len(owners) - 3}" if len(owners) > 3 else "")
            other.append(r)
        else:
            r["uncovered"] = True                       # ไม่มีช่างเข้ากะ → ทุกคนเห็น
            mine.append(r)
    return mine, other


def _owner_shift(R: dict, uid: int, at: datetime) -> str:
    for day in (at.date(), at.date() - timedelta(days=1)):
        for s, e in windows(R, uid, day):
            if s <= at < e:
                return shift_key(R, uid, day)
    return shift_key(R, uid, at.date())


def my_duty(db, uid: int, now: datetime, cfg=None) -> dict:
    """กะของฉันตอนนี้/วันนี้ + โรงงานที่รับผิดชอบ (แสดงบนหน้างานของฉัน)"""
    R = load(db, now.date() - timedelta(days=1), now.date() + timedelta(days=1), cfg)
    k = shift_key(R, uid, now.date())
    win = window_text(R, uid, now.date())
    y = now.date() - timedelta(days=1)
    if shift_key(R, uid, y) == "night_shift" and on_duty(R, uid, now) and now.hour < 12:   # กะดึกของเมื่อวานยังไม่จบ
        k, win = "night_shift", window_text(R, uid, y)
    lab = TR.SHIFT[k]
    fids = factories_of(db, uid)
    fn = factory_names(db)
    tmr = shift_key(R, uid, now.date() + timedelta(days=1))
    return {"key": k, "label": lab[0], "icon": lab[2], "cls": lab[1], "window": win, "on_now": on_duty(R, uid, now),
            "factories": [fn.get(f, "?") for f in fids] if fids else [], "all_factories": not fids,
            "tomorrow": TR.label("SHIFT", tmr), "tomorrow_icon": TR.SHIFT[tmr][2], "source": R["source"],
            "filter": get_settings(db)["filter"]}


def coverage(db, now: datetime, cfg=None) -> list[dict]:
    """ใครอยู่กะตอนนี้ แยกตามโรงงาน (หน้า "ต้องจัดการวันนี้")"""
    R = load(db, now.date() - timedelta(days=1), now.date() + timedelta(days=1), cfg)
    techs = [p for p in team(db) if p["role"] == "technician"]
    out = []
    for fid, name in factory_names(db).items():
        staff = [p for p in techs if p["factories"] is None or fid in p["factories"]]
        now_on = [{"name": p["name"], "shift": TR.label("SHIFT", _owner_shift(R, p["id"], now)),
                   "icon": TR.SHIFT[_owner_shift(R, p["id"], now)][2]} for p in staff if on_duty(R, p["id"], now)]
        off = [{"name": p["name"], "shift": TR.label("SHIFT", shift_key(R, p["id"], now.date())),
                "icon": TR.SHIFT[shift_key(R, p["id"], now.date())][2]} for p in staff
               if shift_key(R, p["id"], now.date()) in ("day_off", "sick")]
        out.append({"id": fid, "name": name, "staff": len(staff), "on": now_on, "leave": off})
    return out


def in_scope(p: dict, factory_id) -> bool:
    return p["factories"] is None or factory_id is None or factory_id in p["factories"]


def responsible(db, factory_id, a: datetime, b: datetime, role: str = "technician", R: dict | None = None,
                members: list[dict] | None = None) -> list[dict]:
    """v0.51 ผู้รับผิดชอบช่วงเวลา a–b ของโรงงาน: ผู้ใช้บทบาทนี้ที่รับโรงงานนี้ และ (ช่าง + เปิดกรองตามกะ) อยู่ในกะ
    ไม่มีใครอยู่กะ → ทุกคนของโรงงาน (งานไม่ตกหล่น) · คืน [{id, name, ...}]"""
    members = members if members is not None else team(db)
    pool = [p for p in members if p["role"] == role and in_scope(p, factory_id)]
    if role != "technician" or not pool or not get_settings(db)["filter"]:
        return pool
    if R is None:
        R = load(db, a.date() - timedelta(days=1), b.date() + timedelta(days=1))
    on = [p for p in pool if covers(R, p["id"], a, b)]
    return on or pool


# ───────────────────────── v0.51 รูปแบบหมุนกะ (2 / 4 สัปดาห์) ─────────────────────────
# ช่องละวัน: '' = ตามวันทำงาน (กะเช้า / วันหยุด) · ot · night_shift · day_off · sick

CYCLES = (2, 4)
PRESETS = [
    {"id": "p2", "name": "2 สัปดาห์: เช้า ↔ ดึก", "weeks": 2,
     "cells": [""] * 7 + ["night_shift"] * 6 + [""]},
    {"id": "p4", "name": "4 สัปดาห์: เช้า เช้า ดึก ดึก", "weeks": 4,
     "cells": [""] * 14 + (["night_shift"] * 6 + [""]) * 2},
]


def patterns(db) -> list[dict]:
    row = db.execute("SELECT value FROM cs_meta WHERE key='roster_patterns'").fetchone()
    try:
        saved = json.loads(row[0]) if row and row[0] else None
    except ValueError:
        saved = None
    return saved if isinstance(saved, list) else [dict(p) for p in PRESETS]


def _clean_pattern(p: dict) -> dict:
    try:
        weeks = int(p.get("weeks") or 0)
    except (TypeError, ValueError):
        weeks = 0
    if weeks not in CYCLES:
        raise S.ValidationError("รอบการหมุนต้องเป็น 2 หรือ 4 สัปดาห์")
    cells = [str(c or "") for c in (p.get("cells") or [])][:weeks * 7]
    cells += [""] * (weeks * 7 - len(cells))
    if any(c and c not in PLAN_TYPES for c in cells):
        raise S.ValidationError("ประเภทกะในรูปแบบไม่ถูกต้อง")
    name = str(p.get("name") or "").strip()[:60] or f"{weeks} สัปดาห์"
    pid = str(p.get("id") or "").strip()[:20] or f"u{int(_time.time())}"
    return {"id": pid, "name": name, "weeks": weeks, "cells": cells}


def save_pattern(db, p: dict, actor_id) -> dict:
    clean = _clean_pattern(p)
    lst = [x for x in patterns(db) if x["id"] != clean["id"]]
    lst.append(clean)
    if len(lst) > 20:
        raise S.ValidationError("เก็บรูปแบบได้ไม่เกิน 20 แบบ")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('roster_patterns', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(lst, ensure_ascii=False),))
    S.audit(db, actor_id, "update", "cs_meta", None, after={"roster_pattern": clean})
    return clean


def delete_pattern(db, pid: str, actor_id) -> None:
    lst = [x for x in patterns(db) if x["id"] != pid]
    db.execute("INSERT INTO cs_meta(key, value) VALUES('roster_patterns', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(lst, ensure_ascii=False),))
    S.audit(db, actor_id, "delete", "cs_meta", None, before={"roster_pattern": pid})


def pattern_items(db, pattern: dict, people: list[dict], d0: date, d1: date, skip_holidays: bool = True,
                  cfg=None, keep_leave: bool = True) -> list[dict]:
    """people = [{user_id, start_week (1..weeks)}] → รายการช่องตารางกะ (สัปดาห์ที่ 1 = สัปดาห์ของวันเริ่ม)"""
    p = _clean_pattern(pattern)
    if d1 < d0:
        raise S.ValidationError("วันสิ้นสุดต้องไม่ก่อนวันเริ่ม")
    if (d1 - d0).days > 186:
        raise S.ValidationError("ลงตามรูปแบบได้ครั้งละไม่เกิน 6 เดือน")
    R = load(db, d0, d1, cfg)
    anchor = d0 - timedelta(days=d0.weekday())
    items = []
    for person in people:
        try:
            uid, sw = int(person["user_id"]), int(person.get("start_week") or 1)
        except (KeyError, TypeError, ValueError):
            raise S.ValidationError("ข้อมูลช่างไม่ถูกต้อง") from None
        if not 1 <= sw <= p["weeks"]:
            raise S.ValidationError(f"สัปดาห์เริ่มต้องอยู่ระหว่าง 1–{p['weeks']}")
        d = d0
        while d <= d1:
            wk = ((d - anchor).days // 7 + sw - 1) % p["weeks"]
            val = p["cells"][wk * 7 + d.weekday()]
            if skip_holidays and d.isoformat() in R["holidays"] and val in ("", "night_shift"):
                val = ""
            cur = plan_type(R, uid, d)
            if keep_leave and (cur in ("day_off", "sick") or (cur == "ot" and not val)):
                d += timedelta(days=1)                      # เก็บวันลา / OT ที่ลงไว้แล้ว
                continue
            items.append({"user_id": uid, "date": d.isoformat(), "shift_type": val})
            d += timedelta(days=1)
    return items


def apply_pattern(db, pattern_id: str, people: list[dict], d0: date, d1: date, actor_id, skip_holidays: bool = True,
                  cfg=None, keep_leave: bool = True) -> int:
    pat = next((x for x in patterns(db) if x["id"] == pattern_id), None)
    if not pat:
        raise S.ValidationError("ไม่พบรูปแบบหมุนกะ")
    if not people:
        raise S.ValidationError("กรุณาเลือกช่างอย่างน้อย 1 คน")
    items = pattern_items(db, pat, people, d0, d1, skip_holidays, cfg, keep_leave)
    n = set_plans(db, items, actor_id, cfg)
    S.audit(db, actor_id, "apply", "cs_shift_plan", None,
            after={"pattern": pat["name"], "from": d0.isoformat(), "to": d1.isoformat(), "people": people})
    return n
