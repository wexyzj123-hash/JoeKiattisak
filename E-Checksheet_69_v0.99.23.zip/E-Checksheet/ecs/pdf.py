"""ecs/pdf.py — แปลงหน้า HTML เป็น PDF ด้วยเบราว์เซอร์แบบไม่แสดงหน้าจอ (Microsoft Edge / Chrome / Chromium)

เหตุผลที่ใช้เบราว์เซอร์: Windows Server มี Edge ติดตั้งอยู่แล้ว ไม่ต้องลงโปรแกรมเพิ่ม และแสดงภาษาไทย (สระ/วรรณยุกต์)
ได้ถูกต้องเหมือนหน้าเว็บ — กำหนดเบราว์เซอร์เองได้ด้วยตัวแปร PDF_BROWSER ในไฟล์ .env
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile

CANDIDATES_WIN = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]
CANDIDATES_NIX = ["microsoft-edge", "microsoft-edge-stable", "google-chrome", "google-chrome-stable", "chromium",
                  "chromium-browser", "/opt/pw-browsers/chromium", "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]


class PdfError(Exception):
    pass


def find_browser() -> str | None:
    from .settings import env
    custom = env("PDF_BROWSER", "").strip()
    if custom:
        return custom if os.path.exists(custom) else shutil.which(custom)
    if sys.platform.startswith("win"):
        local = os.environ.get("LOCALAPPDATA", "")
        extra = [os.path.join(local, r"Microsoft\Edge\Application\msedge.exe"),
                 os.path.join(local, r"Google\Chrome\Application\chrome.exe")] if local else []
        for p in CANDIDATES_WIN + extra:
            if os.path.exists(p):
                return p
        return None
    for c in CANDIDATES_NIX:
        p = c if os.path.isabs(c) and os.path.exists(c) else shutil.which(c)
        if p:
            return p
    return None


def html_to_pdf(html: str, timeout: int = 90) -> bytes:
    exe = find_browser()
    if not exe:
        raise PdfError("ไม่พบ Microsoft Edge / Chrome บนเครื่องแม่ข่าย — ติดตั้ง หรือกำหนด PDF_BROWSER ในไฟล์ .env")
    with tempfile.TemporaryDirectory(prefix="ecs_pdf_") as tmp:
        src = os.path.join(tmp, "report.html")
        out = os.path.join(tmp, "report.pdf")
        with open(src, "w", encoding="utf-8") as fh:
            fh.write(html)
        args = [exe, "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check", "--disable-extensions",
                "--hide-scrollbars", "--mute-audio", f"--user-data-dir={os.path.join(tmp, 'profile')}",
                "--no-pdf-header-footer", "--print-to-pdf-no-header", "--run-all-compositor-stages-before-draw",
                "--virtual-time-budget=4000", f"--print-to-pdf={out}", "file:///" + src.replace(os.sep, "/").lstrip("/")]
        if not sys.platform.startswith("win") and hasattr(os, "geteuid") and os.geteuid() == 0:
            args.insert(1, "--no-sandbox")          # Linux ที่รันเป็น root
        errs = []
        # ลอง 2 แบบ: headless แบบใหม่ (Edge/Chrome ปัจจุบัน) → แบบเดิม (Edge/Chrome รุ่นเก่าบน Windows Server)
        for mode in ("--headless=new", "--headless"):
            args[1 if args[1].startswith("--headless") else 2] = mode
            try:
                proc = subprocess.run(args, capture_output=True, timeout=timeout, check=False)
            except subprocess.TimeoutExpired:
                errs.append(f"{mode}: ไม่เสร็จใน {timeout} วินาที")
                break
            except OSError as exc:
                raise PdfError(f"เปิดเบราว์เซอร์ไม่ได้ ({exe}): {exc}") from None
            if os.path.exists(out) and os.path.getsize(out) >= 100:
                break
            tail = (proc.stderr or b"").decode("utf-8", "replace").strip().splitlines()[-2:]
            errs.append(f"{mode}: exit {proc.returncode} {' | '.join(tail)[:200]}")
        if not os.path.exists(out) or os.path.getsize(out) < 100:
            raise PdfError("สร้าง PDF ไม่สำเร็จ (" + os.path.basename(exe) + "): " + " ; ".join(errs)[:400])
        with open(out, "rb") as fh:
            data = fh.read()
    if not data.startswith(b"%PDF"):
        raise PdfError("ไฟล์ที่ได้ไม่ใช่ PDF")
    return data
