"""ecs/machine360.py — v0.95 ประวัติเครื่องหน้าเดียว

build()  รวมทุกอย่างของเครื่อง 1 ตัวในช่วงวันที่:
  · ตัวชี้วัด: ตรวจแล้ว/ตรงเวลา/ขาดตรวจ · % ในเกณฑ์ · NG · ชั่วโมงหยุดซ่อม · MTBF · MTTR · ความพร้อมใช้งาน
  · ชั่วโมงเดินเครื่อง (จากหัวข้อมิเตอร์สะสมหน่วย ชม./hr)
  · Pareto หัวข้อที่ NG บ่อย · คุณภาพรายหัวข้อ (insights.quality)
  · งานค้าง: แจ้งเตือนเปิด · CAPA · ใบแจ้งซ่อม · แผน PM ถัดไป
  · ไทม์ไลน์เหตุการณ์รวม: ผลตรวจ · NG · แจ้งเตือน · CAPA · หยุด/เดินเครื่อง · ใบแจ้งซ่อม
MTBF/MTTR นับเฉพาะการหยุดหมวด "ซ่อม / เสีย" (repair) — PM/สำรอง/หยุดตามแผน ไม่นับเป็นเสีย
"""
from __future__ import annotations

import logging
import re
from datetime import date, datetime, time, timedelta

from . import services as S
from .services import parse_ts, ts

log = logging.getLogger(__name__)
HOUR_UNIT = re.compile(r"^\s*(h|hr|hrs|hour|hours|ชม\.?|ชั่วโมง)\s*$", re.I)
EV_TH = {"sub": "ผลตรวจ", "ng": "NG", "alert": "แจ้งเตือน", "capa": "CAPA", "down": "เครื่องหยุด", "up": "เดินเครื่อง", "wo": "ใบแจ้งซ่อม"}


def _overlap_h(a: datetime, b: datetime | None, lo: datetime, hi: datetime) -> float:
    b = b or hi
    s, e = max(a, lo), min(b, hi)
    return max(0.0, (e - s).total_seconds() / 3600)


def reliability(db, equipment_id: int, d_from: date, d_to: date, now: datetime | None = None) -> dict:
    now = now or S.now_dt()
    lo = datetime.combine(d_from, time(0, 0))
    hi = min(datetime.combine(d_to + timedelta(days=1), time(0, 0)), now)
    period_h = max(0.0, (hi - lo).total_seconds() / 3600)
    rows = db.execute("""SELECT start_at, end_at, category FROM cs_downtime WHERE equipment_id=?
                         AND start_at<? AND (end_at IS NULL OR end_at>?)""", (equipment_id, ts(hi), ts(lo))).fetchall()
    rep_h = other_h = 0.0
    fails, ttr = 0, []
    for r in rows:
        a, b = parse_ts(r["start_at"]), parse_ts(r["end_at"])
        if not a:
            continue
        h = _overlap_h(a, b, lo, hi)
        if (r["category"] or "repair") == "repair":
            rep_h += h
            if a >= lo:
                fails += 1
            if b and a >= lo:
                ttr.append((b - a).total_seconds() / 3600)
        else:
            other_h += h
    run_h = max(0.0, period_h - rep_h - other_h)
    return {"period_h": round(period_h, 1), "repair_h": round(rep_h, 1), "other_h": round(other_h, 1), "failures": fails,
            "mttr": round(sum(ttr) / len(ttr), 1) if ttr else None,
            "mtbf": round(run_h / fails, 1) if fails else None,
            "avail": round(100 * (period_h - rep_h) / period_h, 1) if period_h else None,
            "planned_h": round(period_h - other_h, 1)}


def run_hours(db, form_ids: list[int], d_from: date, d_to: date) -> dict | None:
    """ชั่วโมงเดินเครื่องจากหัวข้อมิเตอร์สะสมที่หน่วยเป็นชั่วโมง: ค่าล่าสุด และที่เพิ่มขึ้นในช่วง"""
    if not form_ids:
        return None
    ph = ",".join("?" * len(form_ids))
    rows = db.execute(f"""SELECT a.item_key, a.value_num, s.finished_at, fi.name, fi.unit, fi.item_type
                          FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id JOIN cs_form_items fi ON fi.id=a.item_id
                          WHERE s.form_id IN ({ph}) AND s.status<>'superseded' AND a.value_num IS NOT NULL
                            AND fi.item_type='counter' AND s.finished_at<?
                          ORDER BY s.finished_at""", [*form_ids, ts(datetime.combine(d_to + timedelta(days=1), time(0, 0)))]).fetchall()
    rows = [r for r in rows if HOUR_UNIT.match(r["unit"] or "")]
    if not rows:
        return None
    key = rows[-1]["item_key"]
    pts = [r for r in rows if r["item_key"] == key]
    start = ts(datetime.combine(d_from, time(0, 0)))
    before = [r for r in pts if r["finished_at"] < start]
    inside = [r for r in pts if r["finished_at"] >= start]
    base = before[-1]["value_num"] if before else (inside[0]["value_num"] if inside else None)
    last = pts[-1]
    delta = round(last["value_num"] - base, 1) if base is not None and inside else None
    return {"name": last["name"], "unit": last["unit"], "last": last["value_num"], "at": last["finished_at"],
            "delta": delta if delta is None or delta >= 0 else None}


def build(db, equipment_id: int, d_from: date, d_to: date, app_config=None, now: datetime | None = None) -> dict | None:
    from . import insights as IN
    from .downtime import CATEGORIES
    now = now or S.now_dt()
    eq = db.execute("""SELECT e.*, fa.name AS factory_name, ar.name AS area_name FROM equipment e
                       LEFT JOIN factories fa ON fa.id=e.factory_id LEFT JOIN areas ar ON ar.id=e.area_id WHERE e.id=?""",
                    (equipment_id,)).fetchone()
    if not eq:
        return None
    eq = dict(eq)
    forms = [dict(r) for r in db.execute("""SELECT id, name, code, active, current_version_id FROM cs_forms
                                            WHERE equipment_id=? AND is_template=0 ORDER BY active DESC, name""", (equipment_id,))]
    fids = [f["id"] for f in forms] or [0]
    ph = ",".join("?" * len(fids))
    lo, hi = ts(datetime.combine(d_from, time(0, 0))), ts(datetime.combine(d_to + timedelta(days=1), time(0, 0)))

    # ── รอบตรวจ ──
    rr = {r[0]: r[1] for r in db.execute(f"""SELECT status, COUNT(*) FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id
                                             WHERE r.form_id IN ({ph}) AND r.due_at>=? AND r.due_at<? AND r.due_at<=? AND {S.scheduled_sql()}
                                             GROUP BY status""", [*fids, lo, hi, ts(now)])}
    done = rr.get("done_on_time", 0) + rr.get("done_late", 0)
    want = done + rr.get("missed", 0) + rr.get("overdue", 0)
    subs = db.execute(f"""SELECT COUNT(*), COALESCE(SUM(ng_count),0) FROM cs_submissions
                          WHERE form_id IN ({ph}) AND status<>'superseded' AND finished_at>=? AND finished_at<?""", [*fids, lo, hi]).fetchone()
    Q = IN.quality(db, d_from, d_to, scope="all", equipment_id=equipment_id)
    rel = reliability(db, equipment_id, d_from, d_to, now)
    kpi = {"subs": subs[0], "ng": Q["ng"] if Q["n"] else subs[1], "done": done, "want": want, "on_time": rr.get("done_on_time", 0),
           "late": rr.get("done_late", 0), "missed": rr.get("missed", 0), "skipped": rr.get("skipped", 0),
           "rate": round(100 * rr.get("done_on_time", 0) / want, 1) if want else None,
           "quality": Q["pct"], "q_status": Q["status"], **rel}

    # ── Pareto NG ──
    pareto = [dict(r) for r in db.execute(f"""
        SELECT a.item_key, MAX(fi.name) AS name, COUNT(*) AS n, MAX(s.finished_at) AS last_at
        FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id JOIN cs_form_items fi ON fi.id=a.item_id
        WHERE s.form_id IN ({ph}) AND s.status<>'superseded' AND a.judgement='ng' AND s.finished_at>=? AND s.finished_at<?
        GROUP BY a.item_key ORDER BY n DESC LIMIT 8""", [*fids, lo, hi])]
    tot = sum(p["n"] for p in pareto) or 1
    acc = 0
    for p in pareto:
        acc += p["n"]
        p["pct"], p["cum"] = round(100 * p["n"] / tot), round(100 * acc / tot)

    # ── งานค้าง ──
    from .anomaly import OPEN_STATUSES
    alerts = [dict(r) for r in db.execute(f"""SELECT id, title, severity, status, created_at, occurrences FROM cs_alerts
        WHERE (equipment_id=? OR form_id IN ({ph})) AND status IN ({','.join('?' * len(OPEN_STATUSES))})
        ORDER BY created_at DESC LIMIT 10""", [equipment_id, *fids, *OPEN_STATUSES])]
    actions = [dict(r) for r in db.execute(f"""SELECT a.id, a.code, a.title, a.status, a.due_date, a.priority, u.name AS owner
        FROM cs_actions a LEFT JOIN users u ON u.id=a.owner_id
        WHERE (a.equipment_id=? OR a.form_id IN ({ph})) AND a.status IN ('open','in_progress')
        ORDER BY a.due_date IS NULL, a.due_date LIMIT 10""", [equipment_id, *fids])]
    today = now.date().isoformat()
    for a in actions:
        a["late"] = bool(a["due_date"] and a["due_date"] < today)
    wos, wo_ev = [], []
    try:
        from .cmms_wo import OPEN as WO_OPEN, STATUS_TH, ensure
        ensure(db)
        for r in db.execute(f"""SELECT id, wo_number, status, assignee, created_at, closed_at, root_cause, action_taken FROM cs_cmms_wo
                                WHERE equipment_id=? OR form_id IN ({ph}) ORDER BY created_at DESC LIMIT 60""", [equipment_id, *fids]):
            d = dict(r)
            d["status_th"] = STATUS_TH.get(d["status"], d["status"])
            if d["status"] in WO_OPEN:
                wos.append(d)
            if lo <= (d["created_at"] or "") < hi:
                wo_ev.append(d)
    except Exception:                                   # noqa: BLE001
        log.exception("machine360 wo failed")
    pm = []
    if app_config is not None:
        try:
            from .fieldinfo import next_pm
            pm = next_pm(db, app_config, fids)[:4]
        except Exception:                               # noqa: BLE001
            log.exception("machine360 pm failed")

    # ── ไทม์ไลน์ ──
    ev = []
    for r in db.execute(f"""SELECT s.id, s.finished_at, s.ng_count, s.warn_count, s.approval_status, f.name AS form_name, u.name AS who,
                                   r.status AS round_status
                            FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id LEFT JOIN users u ON u.id=s.inspector_id
                            LEFT JOIN cs_rounds r ON r.id=s.round_id
                            WHERE s.form_id IN ({ph}) AND s.status<>'superseded' AND s.finished_at>=? AND s.finished_at<?
                            ORDER BY s.finished_at DESC LIMIT 200""", [*fids, lo, hi]):
        ev.append({"t": r["finished_at"], "k": "sub", "title": r["form_name"], "who": r["who"] or "",
                   "sub": f"NG {r['ng_count']}" if r["ng_count"] else ("เตือน " + str(r["warn_count"]) if r["warn_count"] else "ปกติ"),
                   "late": r["round_status"] == "done_late", "url": ("review.submission_detail", {"sub_id": r["id"]}),
                   "lvl": "ng" if r["ng_count"] else ("warn" if r["warn_count"] else "ok")})
    for r in db.execute(f"""SELECT a.value_text, a.remark, s.id AS sid, s.finished_at, fi.name, fi.unit FROM cs_answers a
                            JOIN cs_submissions s ON s.id=a.submission_id JOIN cs_form_items fi ON fi.id=a.item_id
                            WHERE s.form_id IN ({ph}) AND s.status<>'superseded' AND a.judgement='ng' AND s.finished_at>=? AND s.finished_at<?
                            ORDER BY s.finished_at DESC LIMIT 100""", [*fids, lo, hi]):
        ev.append({"t": r["finished_at"], "k": "ng", "title": r["name"], "sub": f"{r['value_text'] or ''} {r['unit'] or ''}".strip(),
                   "who": "", "note": r["remark"] or "", "url": ("review.submission_detail", {"sub_id": r["sid"]}), "lvl": "ng"})
    for r in db.execute(f"""SELECT id, title, severity, status, created_at FROM cs_alerts WHERE (equipment_id=? OR form_id IN ({ph}))
                            AND created_at>=? AND created_at<? AND alert_type NOT IN ('ng') ORDER BY created_at DESC LIMIT 60""",
                        [equipment_id, *fids, lo, hi]):
        ev.append({"t": r["created_at"], "k": "alert", "title": r["title"], "sub": r["status"], "who": "",
                   "url": ("dash.alert_detail", {"alert_id": r["id"]}), "lvl": "ng" if r["severity"] == "critical" else "warn"})
    for r in db.execute(f"""SELECT a.id, a.code, a.title, a.status, a.created_at, a.closed_at, a.done_at, u.name AS owner FROM cs_actions a
                            LEFT JOIN users u ON u.id=a.owner_id WHERE (a.equipment_id=? OR a.form_id IN ({ph}))
                            AND (a.created_at>=? AND a.created_at<? OR COALESCE(a.closed_at, a.done_at, '')>=? AND COALESCE(a.closed_at, a.done_at, '')<?)
                            ORDER BY a.created_at DESC LIMIT 60""", [equipment_id, *fids, lo, hi, lo, hi]):
        if lo <= r["created_at"] < hi:
            ev.append({"t": r["created_at"], "k": "capa", "title": f"{r['code'] or ''} {r['title']}".strip(), "sub": "เปิดงานแก้ไข",
                       "who": r["owner"] or "", "url": ("work.action_detail", {"action_id": r["id"]}), "lvl": "warn"})
        fin = r["closed_at"] or r["done_at"]
        if fin and lo <= fin < hi:
            ev.append({"t": fin, "k": "capa", "title": f"{r['code'] or ''} {r['title']}".strip(), "sub": "แก้ไขเสร็จ/ปิดงาน",
                       "who": r["owner"] or "", "url": ("work.action_detail", {"action_id": r["id"]}), "lvl": "ok"})
    for r in db.execute("""SELECT d.*, u.name AS who, x.name AS who2 FROM cs_downtime d LEFT JOIN users u ON u.id=d.started_by
                           LEFT JOIN users x ON x.id=d.ended_by WHERE d.equipment_id=? AND d.start_at<? AND (d.end_at IS NULL OR d.end_at>=?)
                           ORDER BY d.start_at DESC LIMIT 60""", (equipment_id, hi, lo)):
        a, b = parse_ts(r["start_at"]), parse_ts(r["end_at"])
        cat = CATEGORIES.get(r["category"], r["category"] or "")
        if r["start_at"] >= lo:
            ev.append({"t": r["start_at"], "k": "down", "title": f"หยุดเครื่อง · {cat}", "sub": r["reason"] or "", "who": r["who"] or "",
                       "lvl": "ng" if r["category"] == "repair" else "none"})
        if b and r["end_at"] < hi:
            ev.append({"t": r["end_at"], "k": "up", "title": "เดินเครื่องแล้ว", "who": r["who2"] or "", "lvl": "ok",
                       "sub": f"หยุด {round((b - a).total_seconds() / 3600, 1)} ชม." if a else "", "note": r["end_note"] or ""})
    for d in wo_ev:
        ev.append({"t": d["created_at"], "k": "wo", "title": f"ใบแจ้งซ่อม {d['wo_number']}", "sub": d["status_th"],
                   "who": d["assignee"] or "", "note": d["action_taken"] or d["root_cause"] or "", "lvl": "warn"})
    ev.sort(key=lambda e: e["t"] or "", reverse=True)
    counts = {k: sum(1 for e in ev if e["k"] == k) for k in EV_TH}
    return {"eq": eq, "forms": forms, "kpi": kpi, "quality": Q, "pareto": pareto, "alerts": alerts, "actions": actions,
            "wos": wos, "pm": pm, "events": ev[:300], "counts": counts, "run": run_hours(db, [f["id"] for f in forms], d_from, d_to),
            "d_from": d_from, "d_to": d_to}
