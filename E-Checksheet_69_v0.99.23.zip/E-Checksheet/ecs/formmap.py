"""ecs/formmap.py — v0.46 จับคู่ค่าจาก SQL / SCADA จากฝั่งแบบฟอร์ม (หัวข้อ → Tag)

ใน Check Sheet ส่วนใหญ่ SCADA มีค่าให้เพียงบางหัวข้อ → หน้าเดียวต่อแบบฟอร์มเห็นทุกหัวข้อ:
- หัวข้อตัวเลข: เลือก "ช่างกรอก" หรือ เลือกแหล่งข้อมูล + Tag (มีคำแนะนำ + ค่าล่าสุด + สถานะรับค่า)
- หัวข้อ OK/NG / ตัวเลือก / ข้อความ: ช่างตรวจหน้างานเสมอ
- แถบความครอบคลุม: SCADA กี่หัวข้อ · ช่างกรอกกี่หัวข้อ
- แม่แบบ: ใส่รูปแบบ Tag ด้วย {EQ} = รหัสเครื่อง (เช่น {EQ}_OIL_PRESS) → ใช้กับทุกเครื่องที่ใช้แม่แบบในคลิกเดียว
"""
from __future__ import annotations

from datetime import datetime, timedelta

from . import connectors as CN
from . import services as S
from . import tagmatch as TM
from .services import ValidationError, parse_ts, ts

from .analytics import _spec

NUMERIC = ("number", "counter")
STALE_MIN = 180


def _status(last_seen: str | None, now: datetime) -> str:
    t = parse_ts(last_seen) if last_seen else None
    if not t:
        return "none"
    return "ok" if now - t <= timedelta(minutes=STALE_MIN) else "stale"


def form_view(db, form_id: int) -> dict:
    """ทุกหัวข้อของแบบฟอร์ม + การจับคู่ปัจจุบัน + คำแนะนำ + ความครอบคลุม"""
    form = S.get_form(db, form_id)
    if not form or not form["current_version_id"]:
        raise ValidationError("แบบฟอร์มยังไม่ Publish")
    items = S.get_items(db, form["current_version_id"])
    maps: dict[str, list[dict]] = {}
    for r in db.execute("""SELECT t.*, s.name AS source_name, s.kind FROM cs_source_tags t JOIN cs_sources s ON s.id=t.source_id
                           WHERE t.form_id=? AND t.item_key<>'' ORDER BY t.source_id, t.tag""", (form_id,)):
        maps.setdefault(r["item_key"], []).append(dict(r))
    sug = suggest_for_form(db, form_id, items, maps)
    now = S.now_dt()
    rows = []
    for it in items:
        m = maps.get(it["item_key"], [])
        cur = m[0] if m else None
        hint = ""
        if cur and cur["last_value"] is not None and (it["min_value"] is not None or it["max_value"] is not None):
            v = cur["last_value"] * float(cur["scale"] or 1) + float(cur["add_offset"] or 0)
            mn = it["min_value"] if it["min_value"] is not None else it["max_value"]
            mx = it["max_value"] if it["max_value"] is not None else it["min_value"]
            span = (mx - mn) or abs(mx) or 1
            if v > mx + span * 3 or v < mn - span * 3:
                for f in (0.001, 0.01, 0.1, 10, 100, 1000):
                    if mn <= v * f <= mx:
                        hint = f"ค่าห่างจากเกณฑ์มาก — หน่วยอาจต่างกัน ลองตัวคูณ {f:g}"
                        break
                else:
                    hint = "ค่าห่างจากเกณฑ์มาก — ตรวจ Tag / ตัวคูณ"
        rows.append({"hint": hint, "key": it["item_key"], "name": it["name"], "unit": it["unit"] or "", "type": it["item_type"],
                     "numeric": it["item_type"] in NUMERIC, "section": it.get("section") or "",
                     "spec": _spec(it["min_value"], it["max_value"]),
                     "min": it["min_value"], "max": it["max_value"],
                     "map": cur, "extra": m[1:], "status": _status(cur["last_seen"], now) if cur else "",
                     "sug": sug.get(it["item_key"]) if not cur else None})
    numeric = [r for r in rows if r["numeric"]]
    mapped = [r for r in numeric if r["map"]]
    return {"form": form, "rows": rows, "sources": sources(db),
            "cover": {"items": len(rows), "numeric": len(numeric), "scada": len(mapped), "manual": len(rows) - len(mapped),
                      "receiving": sum(1 for r in mapped if r["status"] == "ok"),
                      "pct": round(100 * len(mapped) / len(rows)) if rows else 0}}


def sources(db) -> list[dict]:
    return [dict(r) for r in db.execute("SELECT id, name, kind, active FROM cs_sources ORDER BY active DESC, name")]


def source_tags(db, sid: int, limit: int = 5000) -> list[dict]:
    return [dict(r) for r in db.execute("""SELECT tag, last_value, last_seen, form_id, item_key FROM cs_source_tags
                                            WHERE source_id=? ORDER BY tag LIMIT ?""", (sid, limit))]


def suggest_for_form(db, form_id: int, items: list[dict] | None = None, maps: dict | None = None) -> dict[str, dict]:
    """คำแนะนำ Tag ต่อหัวข้อตัวเลขที่ยังไม่จับคู่: {item_key: {source_id, source, tag, score, why, last_value}}"""
    form = S.get_form(db, form_id)
    items = items if items is not None else S.get_items(db, form["current_version_id"])
    maps = maps if maps is not None else {}
    tags = db.execute("""SELECT t.source_id, s.name AS source_name, t.tag, t.last_value, t.form_id, t.item_key
                         FROM cs_source_tags t JOIN cs_sources s ON s.id=t.source_id""").fetchall()
    free = [t for t in tags if not t["form_id"] or not t["item_key"]]
    out: dict[str, dict] = {}
    taken: set[tuple] = set()
    cands = []
    for it in items:
        if it["item_type"] not in NUMERIC or maps.get(it["item_key"]):
            continue
        target = {"form_id": form_id, "item_key": it["item_key"], "eq_code": form.get("eq_code") or "",
                  "eqc": TM._compact(form.get("eq_code")), "name": it["name"], "tok": TM._tokens(it["name"]),
                  "min_value": it["min_value"], "max_value": it["max_value"]}
        for t in free:
            sc, why = TM.score(t["tag"], t["last_value"], target, set())
            if sc >= TM.MIN_SHOW:
                cands.append((sc, it["item_key"], (t["source_id"], t["tag"]), {
                    "source_id": t["source_id"], "source": t["source_name"], "tag": t["tag"], "score": sc,
                    "why": " · ".join(why), "last_value": t["last_value"]}))
    for sc, key, tk, d in sorted(cands, key=lambda x: -x[0]):    # แต่ละ Tag แนะนำให้หัวข้อเดียว (คะแนนสูงสุดก่อน)
        if key in out or tk in taken:
            continue
        out[key] = d
        taken.add(tk)
    return out


def save_form_map(db, form_id: int, rows: list[dict], actor_id) -> dict:
    """rows = [{item_key, source_id, tag, scale, add_offset}] · tag ว่าง = ช่างกรอก (ยกเลิกการจับคู่เดิมของหัวข้อ)"""
    form = S.get_form(db, form_id)
    if not form or not form["current_version_id"]:
        raise ValidationError("แบบฟอร์มยังไม่ Publish")
    numeric = {i["item_key"] for i in S.get_items(db, form["current_version_id"]) if i["item_type"] in NUMERIC}
    src_ids = {s["id"] for s in sources(db)}
    errors, mapped, cleared = [], 0, 0
    for r in rows:
        key = str(r.get("item_key") or "")
        if key not in numeric:
            continue
        tag = str(r.get("tag") or "").strip()[:120]
        try:
            sid = int(r.get("source_id") or 0)
        except (TypeError, ValueError):
            sid = 0
        old = db.execute("SELECT source_id, tag FROM cs_source_tags WHERE form_id=? AND item_key=?", (form_id, key)).fetchall()
        keep = (sid, tag) if tag else None
        for o in old:                                   # หัวข้อละ 1 Tag — Tag เดิมที่ไม่ใช้แล้วกลับเป็น "ไม่ใช้"
            if (o["source_id"], o["tag"]) != keep:
                db.execute("UPDATE cs_source_tags SET form_id=NULL, item_key='' WHERE source_id=? AND tag=?", (o["source_id"], o["tag"]))
                cleared += 1
        if not tag:
            continue
        if sid not in src_ids:
            errors.append(f"{key}: กรุณาเลือกแหล่งข้อมูลของ Tag {tag}")
            continue
        try:
            CN.save_mapping(db, sid, [{"tag": tag, "target": f"{form_id}:{key}", "scale": r.get("scale"),
                                       "add_offset": r.get("add_offset")}], actor_id)
            mapped += 1
        except ValidationError as exc:
            errors.append(f"{key}: {exc.errors[0]}")
    if errors:
        raise ValidationError(errors)
    S.audit(db, actor_id, "map", "cs_forms", form_id, after={"mapped": mapped, "cleared": cleared})
    return {"mapped": mapped, "cleared": cleared}


# ───────────────────────── แม่แบบ: รูปแบบ Tag ด้วย {EQ} ─────────────────────────

def _child_key(db, child_id: int, tpl_key: str) -> str:
    o = db.execute("SELECT local_key FROM cs_template_overrides WHERE form_id=? AND template_key=?", (child_id, tpl_key)).fetchone()
    return (o["local_key"] if o and o["local_key"] else "") or tpl_key


def tpl_patterns(db, tpl_id: int) -> dict[str, dict]:
    r = db.execute("SELECT value FROM cs_meta WHERE key=?", (f"tagpat:{tpl_id}",)).fetchone()
    if not r:
        return {}
    import json
    try:
        return json.loads(r[0])
    except ValueError:
        return {}


def apply_patterns(db, tpl_id: int, rows: list[dict], actor_id, preview: bool = False) -> dict:
    """rows = [{item_key, source_id, pattern, scale, add_offset}] → จับคู่ให้ทุกเครื่องที่ใช้แม่แบบ ({EQ} = รหัสเครื่อง)"""
    import json

    from .formtpl import children
    tpl = S.get_form(db, tpl_id)
    if not tpl or not tpl.get("is_template"):
        raise ValidationError("ไม่ใช่แม่แบบ")
    pats = {}
    for r in rows:
        p = str(r.get("pattern") or "").strip()
        if not p:
            continue
        if "{EQ}" not in p.upper():
            raise ValidationError(f"{r.get('item_key')}: รูปแบบ Tag ต้องมี {{EQ}} แทนรหัสเครื่อง เช่น {{EQ}}_OIL_PRESS")
        pats[r["item_key"]] = {"source_id": int(r.get("source_id") or 0), "pattern": p,
                               "scale": r.get("scale") or 1, "add_offset": r.get("add_offset") or 0}
    kids = [k for k in children(db, tpl_id) if k["eq_code"] and k["active"]]
    plan = []
    for k in kids:
        for key, p in pats.items():
            tag = p["pattern"].replace("{EQ}", k["eq_code"]).replace("{eq}", k["eq_code"])
            plan.append({"form_id": k["id"], "eq_code": k["eq_code"], "item_key": _child_key(db, k["id"], key),
                         "source_id": p["source_id"], "tag": tag, "scale": p["scale"], "add_offset": p["add_offset"],
                         "seen": bool(db.execute("SELECT last_seen FROM cs_source_tags WHERE source_id=? AND tag=? AND last_seen IS NOT NULL",
                                                 (p["source_id"], tag)).fetchone())})
    if preview:
        return {"plan": plan, "forms": len(kids)}
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES(?,?)", (f"tagpat:{tpl_id}", json.dumps(pats, ensure_ascii=False)))
    errors, done = [], 0
    for k in kids:
        rows_k = [p for p in plan if p["form_id"] == k["id"]]
        try:
            done += save_form_map(db, k["id"], rows_k, actor_id)["mapped"]
        except ValidationError as exc:
            errors += [f"{k['eq_code']}: {e}" for e in exc.errors]
    S.audit(db, actor_id, "map_template", "cs_forms", tpl_id, after={"patterns": pats, "mapped": done, "errors": len(errors)})
    return {"forms": len(kids), "mapped": done, "errors": errors, "seen": sum(1 for p in plan if p["seen"]), "total": len(plan)}


def coverage_list(db, factory_id=None) -> list[dict]:
    """ภาพรวม: แบบฟอร์มที่มีหัวข้อตัวเลข → จับคู่ SCADA กี่หัวข้อ (สำหรับหน้ารวม)"""
    q = """SELECT f.id, f.code, f.name, e.code AS eq_code, fa.name AS factory_name,
                  (SELECT COUNT(*) FROM cs_form_items i WHERE i.version_id=f.current_version_id) AS items,
                  (SELECT COUNT(*) FROM cs_form_items i WHERE i.version_id=f.current_version_id AND i.item_type IN ('number','counter')) AS numeric,
                  (SELECT COUNT(DISTINCT t.item_key) FROM cs_source_tags t WHERE t.form_id=f.id AND t.item_key<>'') AS mapped
           FROM cs_forms f LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN factories fa ON fa.id=f.factory_id
           WHERE f.active=1 AND COALESCE(f.is_template,0)=0 AND f.current_version_id IS NOT NULL"""
    p: list = []
    if factory_id:
        q += " AND f.factory_id=?"
        p.append(factory_id)
    return [dict(r) for r in db.execute(q + " ORDER BY mapped DESC, fa.sort_no, e.code", p) if r["numeric"]]
