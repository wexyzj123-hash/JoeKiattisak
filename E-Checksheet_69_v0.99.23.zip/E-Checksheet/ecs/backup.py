"""ecs/backup.py — แบ็กอัปฐานข้อมูล + รูป (ทำได้ขณะระบบเปิดอยู่) · ใช้ทั้งงานอัตโนมัติทุกคืน และปุ่ม "แบ็กอัปตอนนี้"

- ฐานข้อมูล: SQLite online backup → ไฟล์ echecksheet_YYYYmmdd_HHMMSS.db (เก็บ N ชุดล่าสุด)
- รูป: คัดลอกเฉพาะไฟล์ใหม่ไปโฟลเดอร์ uploads/ ในที่เก็บแบ็กอัป
- ตั้งค่าใน .env: BACKUP_DIR (ค่าเริ่มต้น backup/auto ในโฟลเดอร์ระบบ — แนะนำให้ชี้ไปดิสก์อื่น/แชร์ไดรฟ์),
  BACKUP_TIME (02:00), BACKUP_KEEP (14)
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import time
from datetime import datetime, timedelta

PREFIX = "echecksheet_"


def settings(cfg: dict) -> dict:
    from .settings import abs_path, env, env_int
    return {"dir": abs_path(env("BACKUP_DIR", os.path.join("backup", "auto"))),
            "time": env("BACKUP_TIME", "02:00"), "keep": max(1, env_int("BACKUP_KEEP", 14)),
            "enabled": env("BACKUP_ENABLED", "1") not in ("0", "false", "no", "off")}


def list_backups(dest: str) -> list[dict]:
    if not os.path.isdir(dest):
        return []
    out = []
    for f in sorted(os.listdir(dest), reverse=True):
        if f.startswith(PREFIX) and f.endswith(".db"):
            p = os.path.join(dest, f)
            out.append({"name": f, "size": os.path.getsize(p), "at": datetime.fromtimestamp(os.path.getmtime(p))})
    return out


def run_backup(db_path: str, upload_dir: str, dest: str, keep: int = 14) -> dict:
    t0 = time.time()
    os.makedirs(dest, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = os.path.join(dest, f"{PREFIX}{stamp}.db")
    src = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=30)
    dst = sqlite3.connect(out)
    try:
        src.backup(dst)
        ok = dst.execute("PRAGMA quick_check").fetchone()[0] == "ok"
    finally:
        dst.close()
        src.close()
    copied = 0
    up_dest = os.path.join(dest, "uploads")
    if upload_dir and os.path.isdir(upload_dir):
        for root, _, files in os.walk(upload_dir):
            rel = os.path.relpath(root, upload_dir)
            for f in files:
                target = os.path.join(up_dest, rel, f)
                if not os.path.exists(target):
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    shutil.copy2(os.path.join(root, f), target)
                    copied += 1
    dbs = sorted(f for f in os.listdir(dest) if f.startswith(PREFIX) and f.endswith(".db"))
    for old in dbs[:-keep]:
        try:
            os.remove(os.path.join(dest, old))
        except OSError:
            pass
    return {"ok": ok, "file": out, "size": os.path.getsize(out), "photos": copied, "seconds": round(time.time() - t0, 1),
            "at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}


def record(db_path: str, result: dict) -> None:
    con = sqlite3.connect(db_path, timeout=15)
    try:
        con.execute("INSERT INTO cs_meta(key, value) VALUES('last_backup', ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(result, ensure_ascii=False),))
        con.commit()
    finally:
        con.close()


def last(db) -> dict | None:
    row = db.execute("SELECT value FROM cs_meta WHERE key='last_backup'").fetchone()
    try:
        return json.loads(row[0]) if row and row[0] else None
    except ValueError:
        return None


def backup_now(app) -> dict:
    s = settings(app.config)
    try:
        res = run_backup(app.config["DATABASE"], app.config["UPLOAD_FOLDER"], s["dir"], s["keep"])
    except Exception as exc:              # ดิสก์เต็ม / ไม่มีสิทธิ์เขียน ฯลฯ → บันทึกไว้ให้หน้า "สถานะระบบ" แสดง
        res = {"ok": False, "error": str(exc)[:300], "at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "file": ""}
    record(app.config["DATABASE"], res)
    return res


def due(app, now: datetime | None = None) -> bool:
    """ถึงเวลาแบ็กอัปประจำวันแล้ว และวันนี้ยังไม่ได้ทำ (สำเร็จ)"""
    s = settings(app.config)
    if not s["enabled"]:
        return False
    now = now or datetime.now()
    try:
        hh, mm = (int(x) for x in s["time"].split(":"))
    except ValueError:
        hh, mm = 2, 0
    at = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if now < at:
        return False
    con = sqlite3.connect(app.config["DATABASE"], timeout=15)
    try:
        con.row_factory = sqlite3.Row
        info = last(con)
    finally:
        con.close()
    if not info or not info.get("at"):
        return True
    try:
        prev = datetime.strptime(info["at"], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return True
    if not info.get("ok") and now - prev > timedelta(hours=1):     # ล้มเหลว → ลองใหม่ทุกชั่วโมง
        return True
    return prev < at
