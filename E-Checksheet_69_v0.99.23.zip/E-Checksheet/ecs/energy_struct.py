"""ecs/energy_struct.py — โครงสร้างมิเตอร์ Project → Section → Line → มิเตอร์ (v0.70)

  Project  โปรเจกต์หลัก (เช่น Kubota, AR5)                      en_projects          → en_meters.project_id
  Section  กลุ่ม/พื้นที่ (เช่น MFG.1–MFG.6, Utility)             en_sections (รายการตั้งเอง) + en_meters.grp (ชื่อ)
  Line     ไลน์ผลิตภายใต้ Section (เช่น Line 01, Machining)     en_lines (รายการตั้งเอง)    + en_meters.line (ชื่อ)

มิเตอร์อ้าง Section/Line ด้วย "ชื่อ" เหมือนเดิม (ไฟล์นำเข้า/แดชบอร์ด/ต้นทุนเดิมใช้ต่อได้) —
รายการที่ผู้ดูแลเพิ่มไว้ล่วงหน้า (ยังไม่มีมิเตอร์) ก็ขึ้นในตัวเลือกด้วย
"""
from __future__ import annotations

from . import services as S
from .services import ts

DDL = """
CREATE TABLE IF NOT EXISTS en_projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    color       TEXT NOT NULL DEFAULT '#2563eb',
    sort_no     INTEGER NOT NULL DEFAULT 0,
    active      INTEGER NOT NULL DEFAULT 1,
    note        TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS en_sections (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id  INTEGER,
    name        TEXT NOT NULL,
    sort_no     INTEGER NOT NULL DEFAULT 0,
    note        TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL DEFAULT '',
    UNIQUE (factory_id, name)
);
CREATE TABLE IF NOT EXISTS en_lines (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id  INTEGER,
    section     TEXT NOT NULL DEFAULT '',
    name        TEXT NOT NULL,
    sort_no     INTEGER NOT NULL DEFAULT 0,
    note        TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL DEFAULT '',
    UNIQUE (factory_id, section, name)
);
"""
PALETTE = ["#2563eb", "#f59e0b", "#10b981", "#8b5cf6", "#ef4444", "#14b8a6", "#ec4899", "#64748b"]
DEFAULT_PROJECTS = ("Kubota", "AR5")
DEFAULT_SECTIONS = tuple(f"MFG.{i}" for i in range(1, 7))


def ensure_struct(db) -> None:
    db.executescript(DDL)
    cols = {r[1] for r in db.execute("PRAGMA table_info(en_meters)")}
    if "project_id" not in cols:
        db.execute("ALTER TABLE en_meters ADD COLUMN project_id INTEGER")
    if "line" not in cols:
        db.execute("ALTER TABLE en_meters ADD COLUMN line TEXT NOT NULL DEFAULT ''")
    db.execute("CREATE INDEX IF NOT EXISTS idx_enm_struct ON en_meters(project_id, grp, line)")
    if not db.execute("SELECT 1 FROM en_projects LIMIT 1").fetchone():
        for i, n in enumerate(DEFAULT_PROJECTS):
            db.execute("INSERT OR IGNORE INTO en_projects(name, color, sort_no, created_at) VALUES (?,?,?,?)",
                       (n, PALETTE[i % len(PALETTE)], (i + 1) * 10, ts(S.now_dt())))
    if not db.execute("SELECT 1 FROM en_sections LIMIT 1").fetchone():
        for f in db.execute("SELECT id FROM factories WHERE active=1").fetchall():
            for i, n in enumerate(DEFAULT_SECTIONS):
                db.execute("INSERT OR IGNORE INTO en_sections(factory_id, name, sort_no, created_at) VALUES (?,?,?,?)",
                           (f[0], n, (i + 1) * 10, ts(S.now_dt())))


def _clean(v, n=80) -> str:
    return " ".join(str(v or "").split())[:n]


# ───────────────────────── Project ─────────────────────────

def projects(db, active_only: bool = False) -> list[dict]:
    rows = db.execute(f"""SELECT p.*, (SELECT COUNT(*) FROM en_meters m WHERE m.project_id=p.id) AS n_meters
                          FROM en_projects p {'WHERE p.active=1' if active_only else ''} ORDER BY p.sort_no, p.name""").fetchall()
    return [dict(r) for r in rows]


def save_project(db, data: dict, actor, pid: int | None = None) -> int:
    name = _clean(data.get("name"), 60)
    if not name:
        raise S.ValidationError("กรุณาระบุชื่อ Project")
    color = str(data.get("color") or "#2563eb")
    if not (len(color) == 7 and color[0] == "#"):
        color = "#2563eb"
    sort_no = int(str(data.get("sort_no") or "0").strip() or 0) if str(data.get("sort_no") or "0").strip().lstrip("-").isdigit() else 0
    vals = (name, color, sort_no, 0 if data.get("active") in ("0", 0, False) else 1, _clean(data.get("note"), 200))
    dup = db.execute("SELECT id FROM en_projects WHERE name=? AND id<>?", (name, pid or 0)).fetchone()
    if dup:
        raise S.ValidationError("มี Project ชื่อนี้แล้ว")
    if pid:
        before = db.execute("SELECT * FROM en_projects WHERE id=?", (pid,)).fetchone()
        if not before:
            raise S.ValidationError("ไม่พบ Project")
        db.execute("UPDATE en_projects SET name=?, color=?, sort_no=?, active=?, note=? WHERE id=?", (*vals, pid))
        S.audit(db, actor, "energy_project", "en_projects", pid, before=dict(before), after={"name": name, "color": color})
        return pid
    if not sort_no:
        sort_no = (db.execute("SELECT COALESCE(MAX(sort_no), 0) FROM en_projects").fetchone()[0] or 0) + 10
        vals = (vals[0], vals[1], sort_no, *vals[3:])
    pid = db.execute("INSERT INTO en_projects(name, color, sort_no, active, note, created_at) VALUES (?,?,?,?,?,?)",
                     (*vals, ts(S.now_dt()))).lastrowid
    S.audit(db, actor, "energy_project_new", "en_projects", pid, after={"name": name})
    return pid


def delete_project(db, pid: int, actor) -> int:
    p = db.execute("SELECT * FROM en_projects WHERE id=?", (pid,)).fetchone()
    if not p:
        raise S.ValidationError("ไม่พบ Project")
    n = db.execute("UPDATE en_meters SET project_id=NULL WHERE project_id=?", (pid,)).rowcount
    db.execute("DELETE FROM en_projects WHERE id=?", (pid,))
    S.audit(db, actor, "energy_project_del", "en_projects", pid, before=dict(p), after={"unassigned": n})
    return n


# ───────────────────────── Section ─────────────────────────

def sections(db, factory_id: int | None = None, kind: str | None = None, project_id: int | None = None) -> list[dict]:
    """Section ทั้งหมด = รายการที่ตั้งไว้ + ที่มีมิเตอร์ใช้อยู่ (รวมจำนวนมิเตอร์)"""
    w, a = ["1=1"], []
    if factory_id:
        w.append("m.factory_id=?")
        a.append(factory_id)
    if kind:
        w.append("m.kind=?")
        a.append(kind)
    if project_id:
        w.append("m.project_id=?")
        a.append(project_id)
    used = {(r["factory_id"], r["grp"]): dict(r) for r in db.execute(f"""
        SELECT m.factory_id, m.grp, COUNT(*) AS n, SUM(m.active) AS n_active FROM en_meters m WHERE {' AND '.join(w)}
        GROUP BY m.factory_id, m.grp""", a)}
    out = {}
    cat = db.execute("SELECT * FROM en_sections " + ("WHERE factory_id=?" if factory_id else ""), [factory_id] if factory_id else []).fetchall()
    for c in cat:
        u = used.get((c["factory_id"], c["name"]), {})
        out[(c["factory_id"], c["name"])] = {"id": c["id"], "factory_id": c["factory_id"], "name": c["name"], "sort_no": c["sort_no"],
                                              "note": c["note"], "n": u.get("n", 0), "n_active": u.get("n_active", 0) or 0, "cat": True}
    for (f, g), u in used.items():
        if (f, g) not in out:
            out[(f, g)] = {"id": None, "factory_id": f, "name": g, "sort_no": 9999, "note": "", "n": u["n"], "n_active": u["n_active"] or 0, "cat": False}
    fn = {r["id"]: r["name"] for r in db.execute("SELECT id, name FROM factories")}
    rows = sorted(out.values(), key=lambda x: (x["factory_id"] or 0, x["sort_no"], x["name"]))
    for r in rows:
        r["factory_name"] = fn.get(r["factory_id"], "")
    if project_id or kind:
        rows = [r for r in rows if r["n"]]
    return rows


def add_section(db, factory_id, name: str, actor, note: str = "") -> int:
    name = _clean(name)
    if not name:
        raise S.ValidationError("กรุณาระบุชื่อ Section")
    fid = int(factory_id) if factory_id else None
    if db.execute("SELECT 1 FROM en_sections WHERE factory_id IS ? AND name=?", (fid, name)).fetchone():
        raise S.ValidationError("มี Section ชื่อนี้ในโรงงานนี้แล้ว")
    nxt = (db.execute("SELECT COALESCE(MAX(sort_no), 0) FROM en_sections WHERE factory_id IS ?", (fid,)).fetchone()[0] or 0) + 10
    sid = db.execute("INSERT INTO en_sections(factory_id, name, sort_no, note, created_at) VALUES (?,?,?,?,?)",
                     (fid, name, nxt, _clean(note, 200), ts(S.now_dt()))).lastrowid
    S.audit(db, actor, "energy_section_new", "en_sections", sid, after={"factory_id": fid, "name": name})
    return sid


def rename_section(db, factory_id, old: str, new: str, actor) -> int:
    """เปลี่ยนชื่อ/รวม Section (ทุกหมวด) — อัปเดตมิเตอร์ รายการ Section และ Line ที่อยู่ใต้ Section"""
    fid = int(factory_id) if factory_id else None
    new = _clean(new)
    old = old or ""
    if not new:
        raise S.ValidationError("ชื่อ Section ใหม่ห้ามว่าง")
    if new == old:
        return 0
    n = db.execute("UPDATE en_meters SET grp=? WHERE factory_id IS ? AND grp=?", (new, fid, old)).rowcount
    if db.execute("SELECT 1 FROM en_sections WHERE factory_id IS ? AND name=?", (fid, new)).fetchone():
        db.execute("DELETE FROM en_sections WHERE factory_id IS ? AND name=?", (fid, old))        # รวมกับที่มีอยู่
    else:
        db.execute("UPDATE en_sections SET name=? WHERE factory_id IS ? AND name=?", (new, fid, old))
    for ln in db.execute("SELECT id, name FROM en_lines WHERE factory_id IS ? AND section=?", (fid, old)).fetchall():
        if db.execute("SELECT 1 FROM en_lines WHERE factory_id IS ? AND section=? AND name=?", (fid, new, ln["name"])).fetchone():
            db.execute("DELETE FROM en_lines WHERE id=?", (ln["id"],))
        else:
            db.execute("UPDATE en_lines SET section=? WHERE id=?", (new, ln["id"]))
    S.audit(db, actor, "energy_section", "en_sections", None, before={"factory_id": fid, "name": old}, after={"name": new, "meters": n})
    return n


def delete_section(db, factory_id, name: str, actor) -> None:
    fid = int(factory_id) if factory_id else None
    if db.execute("SELECT 1 FROM en_meters WHERE factory_id IS ? AND grp=? LIMIT 1", (fid, name)).fetchone():
        raise S.ValidationError("Section นี้ยังมีมิเตอร์ — ย้าย/รวมไป Section อื่นก่อน")
    db.execute("DELETE FROM en_lines WHERE factory_id IS ? AND section=?", (fid, name))
    db.execute("DELETE FROM en_sections WHERE factory_id IS ? AND name=?", (fid, name))
    S.audit(db, actor, "energy_section_del", "en_sections", None, before={"factory_id": fid, "name": name})


# ───────────────────────── Line ─────────────────────────

def lines(db, factory_id: int | None = None, section: str | None = None, project_id: int | None = None) -> list[dict]:
    w, a = ["m.line<>''"], []
    if factory_id:
        w.append("m.factory_id=?")
        a.append(factory_id)
    if section is not None and section != "":
        w.append("m.grp=?")
        a.append(section)
    if project_id:
        w.append("m.project_id=?")
        a.append(project_id)
    used = {(r["factory_id"], r["grp"], r["line"]): dict(r) for r in db.execute(f"""
        SELECT m.factory_id, m.grp, m.line, COUNT(*) AS n, SUM(m.active) AS n_active FROM en_meters m WHERE {' AND '.join(w)}
        GROUP BY m.factory_id, m.grp, m.line""", a)}
    out = {}
    cw, ca = ["1=1"], []
    if factory_id:
        cw.append("factory_id=?")
        ca.append(factory_id)
    if section:
        cw.append("section=?")
        ca.append(section)
    for c in db.execute(f"SELECT * FROM en_lines WHERE {' AND '.join(cw)}", ca):
        u = used.get((c["factory_id"], c["section"], c["name"]), {})
        out[(c["factory_id"], c["section"], c["name"])] = {"id": c["id"], "factory_id": c["factory_id"], "section": c["section"], "name": c["name"],
                                                           "sort_no": c["sort_no"], "n": u.get("n", 0), "n_active": u.get("n_active", 0) or 0, "cat": True}
    for k, u in used.items():
        if k not in out:
            out[k] = {"id": None, "factory_id": k[0], "section": k[1], "name": k[2], "sort_no": 9999, "n": u["n"], "n_active": u["n_active"] or 0, "cat": False}
    fn = {r["id"]: r["name"] for r in db.execute("SELECT id, name FROM factories")}
    rows = sorted(out.values(), key=lambda x: (x["factory_id"] or 0, x["section"], x["sort_no"], x["name"]))
    for r in rows:
        r["factory_name"] = fn.get(r["factory_id"], "")
    if project_id:
        rows = [r for r in rows if r["n"]]
    return rows


def add_line(db, factory_id, section: str, name: str, actor) -> int:
    name, section = _clean(name), _clean(section)
    if not name:
        raise S.ValidationError("กรุณาระบุชื่อ Line")
    fid = int(factory_id) if factory_id else None
    if db.execute("SELECT 1 FROM en_lines WHERE factory_id IS ? AND section=? AND name=?", (fid, section, name)).fetchone():
        raise S.ValidationError("มี Line ชื่อนี้ใน Section นี้แล้ว")
    if section and not db.execute("SELECT 1 FROM en_sections WHERE factory_id IS ? AND name=?", (fid, section)).fetchone():
        add_section(db, fid, section, actor)
    nxt = (db.execute("SELECT COALESCE(MAX(sort_no), 0) FROM en_lines WHERE factory_id IS ? AND section=?", (fid, section)).fetchone()[0] or 0) + 10
    lid = db.execute("INSERT INTO en_lines(factory_id, section, name, sort_no, created_at) VALUES (?,?,?,?,?)",
                     (fid, section, name, nxt, ts(S.now_dt()))).lastrowid
    S.audit(db, actor, "energy_line_new", "en_lines", lid, after={"factory_id": fid, "section": section, "name": name})
    return lid


def rename_line(db, factory_id, section: str, old: str, new: str, actor) -> int:
    fid = int(factory_id) if factory_id else None
    new = _clean(new)
    if not new:
        raise S.ValidationError("ชื่อ Line ใหม่ห้ามว่าง")
    if new == old:
        return 0
    n = db.execute("UPDATE en_meters SET line=? WHERE factory_id IS ? AND grp=? AND line=?", (new, fid, section or "", old)).rowcount
    if db.execute("SELECT 1 FROM en_lines WHERE factory_id IS ? AND section=? AND name=?", (fid, section or "", new)).fetchone():
        db.execute("DELETE FROM en_lines WHERE factory_id IS ? AND section=? AND name=?", (fid, section or "", old))
    else:
        db.execute("UPDATE en_lines SET name=? WHERE factory_id IS ? AND section=? AND name=?", (new, fid, section or "", old))
    S.audit(db, actor, "energy_line", "en_lines", None, before={"section": section, "name": old}, after={"name": new, "meters": n})
    return n


def delete_line(db, factory_id, section: str, name: str, actor) -> None:
    fid = int(factory_id) if factory_id else None
    if db.execute("SELECT 1 FROM en_meters WHERE factory_id IS ? AND grp=? AND line=? LIMIT 1", (fid, section or "", name)).fetchone():
        raise S.ValidationError("Line นี้ยังมีมิเตอร์ — ย้าย/รวมไป Line อื่นก่อน")
    db.execute("DELETE FROM en_lines WHERE factory_id IS ? AND section=? AND name=?", (fid, section or "", name))
    S.audit(db, actor, "energy_line_del", "en_lines", None, before={"section": section, "name": name})


# ───────────────────────── ใช้กับมิเตอร์ ─────────────────────────

def ensure_catalog(db, factory_id, section: str, line: str) -> None:
    """มิเตอร์ที่ตั้ง Section/Line ใหม่ → ใส่ในรายการให้อัตโนมัติ (ขึ้นในตัวเลือกครั้งถัดไป)"""
    fid = int(factory_id) if factory_id else None
    section, line = _clean(section), _clean(line)
    if section and not db.execute("SELECT 1 FROM en_sections WHERE factory_id IS ? AND name=?", (fid, section)).fetchone():
        nxt = (db.execute("SELECT COALESCE(MAX(sort_no), 0) FROM en_sections WHERE factory_id IS ?", (fid,)).fetchone()[0] or 0) + 10
        db.execute("INSERT INTO en_sections(factory_id, name, sort_no, created_at) VALUES (?,?,?,?)", (fid, section, nxt, ts(S.now_dt())))
    if line and not db.execute("SELECT 1 FROM en_lines WHERE factory_id IS ? AND section=? AND name=?", (fid, section, line)).fetchone():
        nxt = (db.execute("SELECT COALESCE(MAX(sort_no), 0) FROM en_lines WHERE factory_id IS ? AND section=?", (fid, section)).fetchone()[0] or 0) + 10
        db.execute("INSERT INTO en_lines(factory_id, section, name, sort_no, created_at) VALUES (?,?,?,?,?)", (fid, section, line, nxt, ts(S.now_dt())))


def bulk_assign(db, ids: list[int], actor, project_id=None, set_project=False, grp=None, line=None) -> int:
    """ตั้ง Project / Section / Line ให้หลายมิเตอร์พร้อมกัน (ค่า None = ไม่แก้)"""
    pid = None
    if set_project and project_id:
        if not db.execute("SELECT 1 FROM en_projects WHERE id=?", (project_id,)).fetchone():
            raise S.ValidationError("ไม่พบ Project")
        pid = int(project_id)
    n = 0
    for mid in ids:
        m = db.execute("SELECT id, factory_id, grp, line FROM en_meters WHERE id=?", (mid,)).fetchone()
        if not m:
            continue
        if set_project:
            db.execute("UPDATE en_meters SET project_id=? WHERE id=?", (pid, mid))
        if grp is not None:
            db.execute("UPDATE en_meters SET grp=? WHERE id=?", (_clean(grp), mid))
        if line is not None:
            db.execute("UPDATE en_meters SET line=? WHERE id=?", (_clean(line), mid))
        g = _clean(grp) if grp is not None else m["grp"]
        ln = _clean(line) if line is not None else m["line"]
        ensure_catalog(db, m["factory_id"], g, ln)
        n += 1
    S.audit(db, actor, "energy_struct_bulk", "en_meters", None, after={"ids": ids, "project_id": pid if set_project else "-", "grp": grp, "line": line})
    return n


def section_projects(db) -> dict:
    """{(factory_id, Section): {project_id หรือ 0 = ยังไม่กำหนด}} — ไว้แสดง Project ปัจจุบันของแต่ละ Section"""
    out: dict = {}
    for r in db.execute("SELECT factory_id, grp, project_id FROM en_meters GROUP BY factory_id, grp, project_id"):
        out.setdefault((r["factory_id"], r["grp"] or ""), set()).add(r["project_id"] or 0)
    return out


def set_section_project(db, factory_id, grp: str, project_id, actor, all_factories: bool = False) -> int:
    """ตั้ง Project ให้มิเตอร์ทุกตัวใน Section นั้น (ทุกหมวด) — all_factories = Section ชื่อเดียวกันทุกโรงงาน"""
    grp = _clean(grp)
    pid = int(project_id) if project_id else None
    if pid and not db.execute("SELECT 1 FROM en_projects WHERE id=?", (pid,)).fetchone():
        raise S.ValidationError("ไม่พบ Project")
    w, a = ["grp=?"], [grp]
    if not all_factories:
        w.append("factory_id IS ?")
        a.append(factory_id or None)
    ids = [r[0] for r in db.execute(f"SELECT id FROM en_meters WHERE {' AND '.join(w)}", a)]
    db.execute(f"UPDATE en_meters SET project_id=? WHERE {' AND '.join(w)}", [pid, *a])
    S.audit(db, actor, "energy_section_project", "en_meters", None, after={"grp": grp, "project_id": pid, "n": len(ids), "all": all_factories})
    return len(ids)


def apply_filter(ms: list[dict], project_id=None, grp=None, line=None) -> list[dict]:
    """กรองรายการมิเตอร์ด้วย Project / Section / Line (ใช้เหมือนกันทุกหน้า) — project_id = -1 คือยังไม่กำหนด"""
    out = ms
    if project_id:
        out = [m for m in out if (m.get("project_id") or -1) == project_id]
    if grp is not None and grp != "":
        out = [m for m in out if (m.get("grp") or "") == ("" if grp == "-" else grp)]
    if line is not None and line != "":
        out = [m for m in out if (m.get("line") or "") == ("" if line == "-" else line)]
    return out


def path(m: dict) -> str:
    return " › ".join(x for x in (m.get("project_name"), m.get("grp"), m.get("line")) if x)


def facets(ms: list[dict]) -> dict:
    """นับจำนวนมิเตอร์ต่อ Project / Section / Line จากรายการมิเตอร์ (ใช้ทำปุ่มกรองกดได้)"""
    pr, sc, ln = {}, {}, {}
    for m in ms:
        k = (m.get("project_id") or -1, m.get("project_name") or "ยังไม่กำหนด", m.get("project_color") or "#94a3b8")
        pr[k] = pr.get(k, 0) + 1
        sc[m.get("grp") or ""] = sc.get(m.get("grp") or "", 0) + 1
        ln[(m.get("grp") or "", m.get("line") or "")] = ln.get((m.get("grp") or "", m.get("line") or ""), 0) + 1
    return {"projects": [{"id": k[0], "name": k[1], "color": k[2], "n": v} for k, v in sorted(pr.items(), key=lambda x: (x[0][0] == -1, x[0][1]))],
            "sections": [{"name": k or "-", "label": k or "(ไม่ระบุ)", "n": v} for k, v in sorted(sc.items())],
            "lines": [{"section": k[0], "name": k[1] or "-", "label": k[1] or "(ไม่ระบุ)", "n": v} for k, v in sorted(ln.items())]}


# ───────────────────────── รายงานรายวัน ─────────────────────────

def _sub(ms: list[dict], key: str) -> float:
    """ยอดรวมของกลุ่ม — v0.90 กติกาเดียวทั้งระบบ (EN.counted: ไม่นับซ้ำมิเตอร์ที่ถูกครอบ · หักออกเป็นลบ)"""
    from . import energy as EN
    return round(sum(EN.sign(m) * (m[key] or 0) for m in EN.counted(ms)), 2)


def _group_sum(ms: list[dict]) -> dict:
    u, prev, mtd, avg = _sub(ms, "u"), _sub(ms, "prev"), _sub(ms, "mtd"), _sub(ms, "avg7")
    return {"u": u, "prev": prev, "mtd": mtd, "avg7": avg, "chg": round(100 * (u - prev) / prev, 1) if prev else None,
            "vs_avg": round(100 * (u - avg) / avg, 1) if avg else None, "n": len(ms), "n_read": sum(1 for m in ms if m["has"])}


def daily_report(db, day, factory_id: int | None, kind: str, project_id=None, grp=None, line=None) -> dict:
    """รายงานรายวันแบบต้นไม้ Project → Section → Line → มิเตอร์ · ใช้ตัวกรองชุดเดียวกับหน้ามิเตอร์/ตาราง/แดชบอร์ด"""
    from datetime import timedelta

    from . import energy as EN
    EN.ensure(db)
    all_ms = EN.meters(db, factory_id, kind)
    fac = facets(all_ms)
    ms = apply_filter(all_ms, project_id, grp, line)
    month_start = day.replace(day=1)
    d_from = min(month_start, day - timedelta(days=8))
    ser = EN.series(db, ms, d_from, day)
    ds, pd_ = day.isoformat(), (day - timedelta(days=1)).isoformat()
    w7 = [(day - timedelta(days=i)).isoformat() for i in range(2, 9)]
    rd = {r[0]: r[1] for r in db.execute(
        f"SELECT meter_id, value FROM en_readings WHERE day=? AND meter_id IN ({','.join('?' * len(ms)) or 'NULL'})", [ds, *[m['id'] for m in ms]])}
    rows = []
    for m in ms:
        s = ser[m["id"]]
        cur = s.get(ds) or {}
        u = cur.get("u") or 0
        vals7 = [(s.get(d) or {}).get("u") for d in w7 if (s.get(d) or {}).get("u") is not None]
        rows.append({**m, "label": EN.label(m), "u": round(u, 2), "prev": round((s.get(pd_) or {}).get("u") or 0, 2),
                     "avg7": round(sum(vals7) / len(vals7), 2) if vals7 else 0.0,
                     "mtd": round(sum((x.get("u") or 0) for d, x in s.items() if month_start.isoformat() <= d <= ds), 2),
                     "flag": cur.get("flag") or "", "has": m["id"] in rd, "reading": rd.get(m["id"])})
    for r in rows:
        r["chg"] = round(100 * (r["u"] - r["prev"]) / r["prev"], 1) if r["prev"] else None
        r["vs_avg"] = round(100 * (r["u"] - r["avg7"]) / r["avg7"], 1) if r["avg7"] else None
    tree: dict = {}
    for r in rows:
        pk = (r["project_id"] or 0, r.get("project_name") or "ยังไม่กำหนด Project", r.get("project_color") or "#94a3b8")
        tree.setdefault(pk, {}).setdefault(r["grp"] or "", {}).setdefault(r["line"] or "", []).append(r)
    groups = []
    for pk in sorted(tree, key=lambda x: (x[0] == 0, x[1])):
        secs = []
        for sn, lines_ in sorted(tree[pk].items()):
            ls = [{"name": ln, "meters": sorted(v, key=lambda x: (-x["is_main"], -x["u"])), "sub": _group_sum(v)} for ln, v in sorted(lines_.items())]
            secs.append({"name": sn, "lines": ls, "sub": _group_sum([r for v in lines_.values() for r in v])})
        groups.append({"id": pk[0], "name": pk[1], "color": pk[2], "sections": secs,
                       "sub": _group_sum([r for sn in tree[pk].values() for v in sn.values() for r in v])})
    tot_ms = EN.totals_set(ms)
    tt = {k: round(sum(EN.sign(m) * (m[k] or 0) for m in rows if m["id"] in {x["id"] for x in tot_ms}), 2) for k in ("u", "prev", "mtd", "avg7")}
    total = {**tt, "chg": round(100 * (tt["u"] - tt["prev"]) / tt["prev"], 1) if tt["prev"] else None, "n": len(rows),
             "n_read": sum(1 for r in rows if r["has"]), "flags": sum(1 for r in rows if r["flag"] in ("spike", "reset"))}
    return {"day": day, "prev_day": day - timedelta(days=1), "groups": groups, "total": total, "facets": fac, "rows": rows,
            "missing": [r for r in rows if not r["has"]]}


def daily_xlsx(db, day, factory_id, kind, project_id=None, grp=None, line=None) -> bytes:
    import io

    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    from . import energy as EN
    rep = daily_report(db, day, factory_id, kind, project_id, grp, line)
    K = EN.KINDS[kind]
    wb = Workbook()
    ws = wb.active
    ws.title = "รายงานรายวัน"
    fac = db.execute("SELECT name FROM factories WHERE id=?", (factory_id,)).fetchone() if factory_id else None
    ws.append([f"Energy Data · รายงานรายวัน · {K['th']} ({K['unit']}) · {fac[0] if fac else 'ทุกโรงงาน'} · {day:%d/%m/%Y}"])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append(["Project", "Section", "Line", "มิเตอร์", "เลขหน้าปัด", f"ใช้วันนี้ ({K['unit']})", "เมื่อวาน", "% เทียบเมื่อวาน",
               "เฉลี่ย 7 วันก่อน", "สะสมเดือนนี้", "สถานะ"])
    for c in ws[2]:
        c.font, c.fill, c.alignment = Font(bold=True), PatternFill("solid", fgColor="DBEAFE"), Alignment(wrap_text=True, horizontal="center")
    for g in rep["groups"]:
        for sec in g["sections"]:
            for ln in sec["lines"]:
                for m in ln["meters"]:
                    st = "ยังไม่จด" if not m["has"] else ("ค่ากระโดด" if m["flag"] == "spike" else ("ค่าลดลง/รีเซ็ต" if m["flag"] == "reset" else "ปกติ"))
                    ws.append([g["name"], sec["name"], ln["name"], m["label"], m["reading"], m["u"], m["prev"], m["chg"], m["avg7"], m["mtd"], st])
    ws.append([])
    t = rep["total"]
    ws.append(["รวม (มิเตอร์หลัก/ที่คิดยอด)", "", "", "", "", t["u"], t["prev"], t["chg"], t["avg7"], t["mtd"], f"จดแล้ว {t['n_read']}/{t['n']}"])
    for c in ws[ws.max_row]:
        c.font = Font(bold=True)
    for col, w in zip("ABCDEFGHIJK", (16, 18, 18, 34, 14, 16, 12, 14, 16, 16, 16)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A3"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
