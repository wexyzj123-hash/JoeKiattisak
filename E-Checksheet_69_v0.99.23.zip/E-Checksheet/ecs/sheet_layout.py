"""ecs/sheet_layout.py — v0.26 ผู้ดูแลระบบแก้รูปแบบใบบันทึกรายเดือน / รายครั้ง (PDF + Excel) ได้เองจากหน้าเว็บ

ข้อความหัวเอกสาร · ชื่อแถว/ช่องลงนาม · กล่อง Utility · คำอธิบายสัญลักษณ์ · ข้อความท้ายกระดาษ · ซ่อน/แสดงส่วนต่าง ๆ
รูปตรามุมซ้ายบน (UTILITY / SE) และโลโก้มุมขวาล่าง เปลี่ยนได้ด้วยการอัปโหลด (เก็บใน uploads/doc/)
เก็บใน cs_meta key 'sheet_layout' (JSON) — ค่าว่าง = ใช้ค่าเริ่มต้น
"""
from __future__ import annotations

import json
import os

from . import services as S

DEFAULTS = {
    "title_th": "ใบบันทึกผลการตรวจเช็คประจำเดือน",
    "record_title": "ใบบันทึกผลการตรวจเช็ค",
    "row_insp": "ผู้ตรวจ (Tech)",
    "row_sup": "หัวหน้างาน (Sr.Tech)",
    "sign_insp": "ผู้ตรวจ (Sr.Tech/FM)",
    "sign_sup": "หัวหน้างาน (SV/SSV)",
    "util_title": "Utility",
    "util_mgr": "Manager",
    "util_sv": "SV/SSV",
    "legend": "",
    "footer_note": "เอกสารนี้สร้างจากข้อมูลที่บันทึกในระบบ · สแกน QR เพื่อเปิดฉบับออนไลน์และเทียบรหัสตรวจสอบ",
    "brand_tag": "UTILITY · SAFETY · ENVIRONMENT",
    "show_summary": True,
    "show_legend": True,
    "show_qr": True,
    "show_logo": True,
}
LABELS = {
    "title_th": "ชื่อเอกสาร (ใบบันทึกรายเดือน)",
    "record_title": "ชื่อเอกสาร (ใบบันทึกรายครั้ง)",
    "row_insp": "แถวผู้ตรวจรายวันในตาราง",
    "row_sup": "แถวหัวหน้างานรายสัปดาห์ในตาราง",
    "sign_insp": "ช่องลงนามท้ายเอกสาร (ซ้าย)",
    "sign_sup": "ช่องลงนามท้ายเอกสาร (ขวา)",
    "util_title": "หัวกล่อง Utility",
    "util_mgr": "กล่อง Utility — ช่องซ้าย (Manager)",
    "util_sv": "กล่อง Utility — ช่องขวา (SV/SSV)",
    "legend": "คำอธิบายสัญลักษณ์ใต้ตาราง (ว่าง = ค่าเริ่มต้นพร้อมแถบสี)",
    "footer_note": "ข้อความท้ายกระดาษ",
    "brand_tag": "ข้อความใต้โลโก้",
    "show_summary": "แสดงกล่องสรุปผลประจำเดือน และรายการผิดปกติ",
    "show_legend": "แสดงคำอธิบายสัญลักษณ์",
    "show_qr": "แสดง QR Code ฉบับออนไลน์",
    "show_logo": "แสดงโลโก้มุมขวาล่าง",
}
IMAGES = {"doc-stamp.png": "ตรามุมซ้ายบน — PROTECTED · UTILITY", "doc-stamp-se.png": "ตรามุมซ้ายบน — PROTECTED · SE",
          "aisin-logo.png": "โลโก้มุมขวาล่าง"}


def get(db) -> dict:
    cfg = dict(DEFAULTS)
    r = db.execute("SELECT value FROM cs_meta WHERE key='sheet_layout'").fetchone()
    if r and r[0]:
        try:
            for k, v in json.loads(r[0]).items():
                if k in DEFAULTS:
                    if isinstance(DEFAULTS[k], bool):
                        cfg[k] = bool(v)
                    elif str(v or "").strip() or k == "legend":
                        cfg[k] = str(v)[:400]
        except ValueError:
            pass
    return cfg


def save(db, data, actor_id) -> dict:
    cfg = {}
    for k, d in DEFAULTS.items():
        if isinstance(d, bool):
            cfg[k] = bool(data.get(k))
        else:
            v = str(data.get(k) or "").strip()[:400]
            if v and v != d:
                cfg[k] = v
    db.execute("INSERT INTO cs_meta(key, value) VALUES('sheet_layout', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(cfg, ensure_ascii=False),))
    S.audit(db, actor_id, "update", "cs_meta", None, after={"sheet_layout": cfg})
    return get(db)


def reset(db, actor_id) -> None:
    db.execute("DELETE FROM cs_meta WHERE key='sheet_layout'")
    S.audit(db, actor_id, "reset", "cs_meta", None, after={"sheet_layout": "default"})


def override_path(upload_dir: str, name: str) -> str:
    return os.path.join(upload_dir, "doc", name)


def save_image(upload_dir: str, name: str, raw: bytes) -> None:
    """รูปตรา/โลโก้ใหม่ → PNG (ย่อไม่เกิน 1600 px)"""
    if name not in IMAGES:
        raise S.ValidationError("ไม่รู้จักรูปนี้")
    import io
    from PIL import Image, ImageOps
    try:
        im = ImageOps.exif_transpose(Image.open(io.BytesIO(raw)))
        im.load()
    except Exception as e:                                   # noqa: BLE001
        raise S.ValidationError("ไฟล์รูปไม่ถูกต้อง") from e
    im.thumbnail((1600, 1600))
    os.makedirs(os.path.join(upload_dir, "doc"), exist_ok=True)
    im.convert("RGBA").save(override_path(upload_dir, name), "PNG")


def delete_image(upload_dir: str, name: str) -> None:
    p = override_path(upload_dir, name)
    if name in IMAGES and os.path.exists(p):
        os.remove(p)
