"""ecs/handover.py — v0.51 ส่งกะ / รับกะ

ทุกเวลาเปลี่ยนกะ (ค่าเริ่มต้น 08:00 และ 17:00 ตามตารางกะ UT-CMMS) ระบบสรุปกะที่จบไปรายโรงงาน:
  รอบตรวจของกะ: ตรวจแล้ว / ขาดตรวจ / ค้างให้กะถัดไป (ยังส่งได้) · NG ที่เปิดอยู่ · เครื่องหยุด · คนส่งกะ / คนรับกะ
แจ้งช่างที่เข้ากะถัดไป (กระดิ่ง + ช่องทางส่วนตัว) → กด "รับกะ" (ใส่หมายเหตุได้) · ช่างกะที่ส่งเพิ่มหมายเหตุส่งกะได้จนกว่าจะมีคนรับ
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta

from . import roster as RO
from . import services as S
from .services import parse_ts, ts

DDL = """
CREATE TABLE IF NOT EXISTS cs_handovers (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id   INTEGER REFERENCES factories(id),
    point_at     TEXT NOT NULL,            -- เวลาเปลี่ยนกะ
    period_start TEXT NOT NULL,
    data_json    TEXT NOT NULL DEFAULT '{}',
    note         TEXT DEFAULT '',          -- หมายเหตุจากกะที่ส่ง
    note_by      INTEGER REFERENCES users(id),
    note_at      TEXT,
    ack_by       INTEGER REFERENCES users(id),
    ack_at       TEXT,
    ack_note     TEXT DEFAULT '',
    created_at   TEXT NOT NULL,
    UNIQUE (factory_id, point_at)
);
CREATE INDEX IF NOT EXISTS idx_csho_point ON cs_handovers(point_at);
"""
DEFAULTS = {"enabled": True, "times": "08:00,17:00"}
BACKFILL_H = 6          # สร้างย้อนหลังได้ไม่เกินกี่ชั่วโมง (เปิดระบบหลังเวลาเปลี่ยนกะ)
SHOW_H = 12             # แสดง "รอรับกะ" กับช่างไม่เกินกี่ชั่วโมงหลังเวลาเปลี่ยนกะ


def ensure(db) -> None:
    db.executescript(DDL)


def get_settings(db) -> dict:
    cfg = dict(DEFAULTS)
    row = db.execute("SELECT value FROM cs_meta WHERE key='handover'").fetchone()
    if row and row[0]:
        try:
            cfg.update({k: v for k, v in json.loads(row[0]).items() if k in DEFAULTS})
        except ValueError:
            pass
    return cfg


def save_settings(db, data: dict, actor_id) -> dict:
    from .itemfreq import fmt_times, parse_times
    mins = parse_times(data.get("times") or "")
    if not mins:
        raise S.ValidationError("กรุณาระบุเวลาเปลี่ยนกะอย่างน้อย 1 เวลา เช่น 08:00,17:00")
    cfg = {"enabled": data.get("enabled") in (1, True, "1", "on", "true"), "times": fmt_times(sorted(set(mins)))}
    db.execute("INSERT INTO cs_meta(key, value) VALUES('handover', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(cfg),))
    S.audit(db, actor_id, "update", "cs_meta", None, after={"handover": cfg})
    return cfg


def _points(cfg: dict) -> list[int]:
    from .itemfreq import parse_times
    return sorted(set(parse_times(cfg.get("times") or DEFAULTS["times"]))) or [480]


def last_point(cfg: dict, now: datetime) -> tuple[datetime, datetime]:
    """(เวลาเปลี่ยนกะล่าสุดที่ ≤ now, เวลาเปลี่ยนกะก่อนหน้า)"""
    pts = _points(cfg)
    cands = []
    for d in (now.date() - timedelta(days=1), now.date()):
        base = datetime.combine(d, datetime.min.time())
        cands += [base + timedelta(minutes=m) for m in pts]
    cands = sorted(c for c in cands if c <= now)
    p = cands[-1]
    prev = cands[-2] if len(cands) > 1 else p - timedelta(days=1)
    return p, prev


def summarize(db, factory_id: int, start: datetime, end: datetime, R: dict | None = None) -> dict:
    """สรุปกะ [start, end) ของโรงงาน"""
    rows = [dict(r) for r in db.execute("""
        SELECT r.id, r.status, r.due_at, r.deadline_at, r.close_at, r.form_id, f.name AS form_name, e.code AS eq_code,
               COALESCE(e.run_status,'running') AS run_status
        FROM cs_rounds r JOIN cs_schedules sc ON sc.id=r.schedule_id JOIN cs_forms f ON f.id=r.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id
        WHERE f.active=1 AND sc.active=1 AND f.factory_id=? AND r.due_at>=? AND r.due_at<?
        ORDER BY r.due_at""", (factory_id, ts(start), ts(end)))]
    done = [r for r in rows if r["status"] in ("done_on_time", "done_late")]
    late = [r for r in done if r["status"] == "done_late"]
    skipped = [r for r in rows if r["status"] == "skipped" or (r["run_status"] == "down" and r["status"] not in ("done_on_time", "done_late"))]
    open_ = [r for r in rows if r not in done and r not in skipped and r["status"] in ("pending", "in_progress", "overdue", "returned")]
    carry = [r for r in open_ if parse_ts(r["close_at"]) and parse_ts(r["close_at"]) > end]
    missed = [r for r in rows if r not in done and r not in skipped and r not in carry]
    ng = [dict(r) for r in db.execute("""
        SELECT a.id, a.title, a.severity, a.status, e.code AS eq_code FROM cs_alerts a
        JOIN cs_forms f ON f.id=a.form_id LEFT JOIN equipment e ON e.id=a.equipment_id
        WHERE f.factory_id=? AND a.alert_type IN ('ng','warn','trend') AND a.status IN ('open','acknowledged','in_progress')
        ORDER BY CASE a.severity WHEN 'critical' THEN 0 ELSE 1 END, a.created_at DESC LIMIT 12""", (factory_id,))]
    ng_new = db.execute("""SELECT COUNT(*) FROM cs_alerts a JOIN cs_forms f ON f.id=a.form_id
                           WHERE f.factory_id=? AND a.alert_type IN ('ng','warn') AND a.created_at>=? AND a.created_at<?""",
                        (factory_id, ts(start), ts(end))).fetchone()[0]
    downs = [dict(r) for r in db.execute("""SELECT id, code, name, down_reason, down_since FROM equipment
                                             WHERE active=1 AND run_status='down' AND factory_id=? ORDER BY down_since""", (factory_id,))]
    R = R or RO.load(db, start.date() - timedelta(days=1), end.date() + timedelta(days=1))
    members = RO.team(db)
    out_p = [p["name"] for p in RO.responsible(db, factory_id, start, end - timedelta(minutes=1), "technician", R, members)
             if RO.covers(R, p["id"], start, end)]
    in_p = [p["name"] for p in RO.responsible(db, factory_id, end, end + timedelta(hours=1), "technician", R, members)
            if RO.covers(R, p["id"], end, end + timedelta(hours=1))]
    slim = lambda lst: [{k: r[k] for k in ("id", "form_id", "form_name", "eq_code", "due_at", "deadline_at", "close_at", "status")}
                        for r in lst[:15]]
    return {"total": len(rows), "done": len(done), "late": len(late), "missed": len(missed), "skipped": len(skipped),
            "carry_n": len(carry), "carry": slim(carry), "missed_list": slim(missed),
            "ng_new": ng_new, "ng_open": ng, "down": downs[:10], "down_n": len(downs),
            "outgoing": out_p, "incoming": in_p}


def generate(db, now: datetime | None = None, base_url: str = "") -> int:
    """สร้างใบส่งกะที่ถึงเวลา (เรียกจากงานเบื้องหลังทุก 30 วิ — ซ้ำได้ไม่สร้างซ้ำ)"""
    ensure(db)
    cfg = get_settings(db)
    if not cfg["enabled"]:
        return 0
    now = now or S.now_dt()
    point, prev = last_point(cfg, now)
    if now - point > timedelta(hours=BACKFILL_H):
        return 0
    made = 0
    R = None
    for f in db.execute("SELECT id, name FROM factories WHERE active=1 ORDER BY sort_no, id").fetchall():
        if db.execute("SELECT 1 FROM cs_handovers WHERE factory_id=? AND point_at=?", (f["id"], ts(point))).fetchone():
            continue
        if not db.execute("SELECT 1 FROM cs_forms WHERE factory_id=? AND active=1 LIMIT 1", (f["id"],)).fetchone():
            continue
        R = R or RO.load(db, prev.date() - timedelta(days=1), point.date() + timedelta(days=1))
        data = summarize(db, f["id"], prev, point, R)
        cur = db.execute("""INSERT OR IGNORE INTO cs_handovers(factory_id, point_at, period_start, data_json, created_at)
                            VALUES (?,?,?,?,?)""", (f["id"], ts(point), ts(prev), json.dumps(data, ensure_ascii=False), ts(now)))
        if not cur.rowcount:
            continue
        made += 1
        _announce(db, cur.lastrowid, f, point, data, R, base_url, now)
    return made


def _announce(db, hid: int, fac, point: datetime, data: dict, R: dict, base_url: str, now: datetime) -> None:
    from . import notify as N
    subject = f"📋 รับกะ {fac['name']} {point:%H:%M}: ค้าง {data['carry_n']} งาน · NG เปิด {len(data['ng_open'])} · เครื่องหยุด {data['down_n']}"
    lines = [f"กะที่ผ่านมา ตรวจแล้ว {data['done']}/{data['total']} รอบ · ขาดตรวจ {data['missed']}"]
    lines += [f"• ค้าง: {r['eq_code'] or r['form_name']} (ต้องเสร็จ {parse_ts(r['deadline_at']):%H:%M})" for r in data["carry"][:8]]
    lines.append("เปิดดูและกด “รับกะ” ในระบบ")
    rec = [p for p in RO.responsible(db, fac["id"], point, point + timedelta(hours=1), "technician", R)]
    ids = [p["id"] for p in rec]
    users = [dict(u) for u in db.execute(f"SELECT * FROM users WHERE active=1 AND id IN ({','.join('?' * len(ids))})", ids)] if ids else []
    if users:
        N._deliver(db, N.get_settings(db), base_url, {"users": users, "groups": []}, kind="handover", subject=subject,
                   body="\n".join(lines), path=f"/m/handover/{hid}", severity="info", ref_key=f"handover:{hid}", now=now)


def get(db, hid: int) -> dict | None:
    ensure(db)
    r = db.execute("""SELECT h.*, f.name AS factory_name, un.name AS note_by_name, ua.name AS ack_by_name
                      FROM cs_handovers h LEFT JOIN factories f ON f.id=h.factory_id
                      LEFT JOIN users un ON un.id=h.note_by LEFT JOIN users ua ON ua.id=h.ack_by WHERE h.id=?""", (hid,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["data"] = json.loads(d.pop("data_json") or "{}")
    # งานค้าง: สถานะปัจจุบัน (กะใหม่ทำไปแล้วหรือยัง)
    ids = [c["id"] for c in d["data"].get("carry", [])]
    if ids:
        st = {x[0]: x[1] for x in db.execute(f"SELECT id, status FROM cs_rounds WHERE id IN ({','.join('?' * len(ids))})", ids)}
        for c in d["data"]["carry"]:
            c["now_status"] = st.get(c["id"], c["status"])
    return d


def pending_for(db, user_id: int, now: datetime | None = None) -> list[dict]:
    """ใบส่งกะที่ช่างคนนี้ (อยู่ในกะตอนนี้) ยังไม่มีใครรับ — แสดงบนหน้างานของฉัน"""
    ensure(db)
    now = now or S.now_dt()
    u = db.execute("SELECT role FROM users WHERE id=?", (user_id,)).fetchone()
    if not u or u["role"] not in RO.TEAM_ROLES:
        return []
    fids = RO.factories_of(db, user_id)
    R = RO.load(db, now.date() - timedelta(days=1), now.date() + timedelta(days=1))
    if u["role"] == "technician" and not RO.on_duty(R, user_id, now) and RO.get_settings(db)["filter"]:
        return []
    cond, params = "", []
    if fids:
        cond = f" AND h.factory_id IN ({','.join('?' * len(fids))})"
        params = list(fids)
    rows = db.execute(f"""SELECT h.id, h.point_at, h.data_json, h.note, f.name AS factory_name FROM cs_handovers h
                          LEFT JOIN factories f ON f.id=h.factory_id
                          WHERE h.ack_at IS NULL AND h.point_at>=? AND h.point_at<=?{cond} ORDER BY h.point_at DESC""",
                      [ts(now - timedelta(hours=SHOW_H)), ts(now)] + params).fetchall()
    out = []
    for r in rows:
        d = json.loads(r["data_json"] or "{}")
        out.append({"id": r["id"], "point_at": r["point_at"], "factory_name": r["factory_name"], "carry_n": d.get("carry_n", 0),
                    "ng_n": len(d.get("ng_open") or []), "down_n": d.get("down_n", 0), "missed": d.get("missed", 0),
                    "done": d.get("done", 0), "total": d.get("total", 0), "has_note": bool(r["note"])})
    return out


def acknowledge(db, hid: int, user_id: int, note: str = "") -> None:
    h = get(db, hid)
    if not h:
        raise S.ValidationError("ไม่พบใบส่งกะ")
    if h["ack_at"]:
        raise S.ValidationError(f"รับกะไปแล้วโดย {h['ack_by_name'] or '-'}")
    now_s = ts(S.now_dt())
    db.execute("UPDATE cs_handovers SET ack_by=?, ack_at=?, ack_note=? WHERE id=?", (user_id, now_s, (note or "").strip()[:500], hid))
    S.audit(db, user_id, "ack", "cs_handovers", hid, after={"note": note})


def add_note(db, hid: int, user_id: int, note: str) -> None:
    h = get(db, hid)
    if not h:
        raise S.ValidationError("ไม่พบใบส่งกะ")
    if h["ack_at"]:
        raise S.ValidationError("รับกะไปแล้ว — เพิ่มหมายเหตุส่งกะไม่ได้")
    note = (note or "").strip()[:1000]
    if not note:
        raise S.ValidationError("กรุณาพิมพ์หมายเหตุ")
    db.execute("UPDATE cs_handovers SET note=?, note_by=?, note_at=? WHERE id=?", (note, user_id, ts(S.now_dt()), hid))
    S.audit(db, user_id, "update", "cs_handovers", hid, after={"note": note})


def recent(db, fids=None, days: int = 3) -> list[dict]:
    ensure(db)
    cond, params = "", []
    if fids:
        cond = f" AND h.factory_id IN ({','.join('?' * len(fids))})"
        params = list(fids)
    rows = db.execute(f"""SELECT h.id, h.point_at, h.ack_at, h.note, h.data_json, f.name AS factory_name, ua.name AS ack_by_name
                          FROM cs_handovers h LEFT JOIN factories f ON f.id=h.factory_id LEFT JOIN users ua ON ua.id=h.ack_by
                          WHERE h.point_at>=?{cond} ORDER BY h.point_at DESC, f.sort_no LIMIT 60""",
                      [ts(S.now_dt() - timedelta(days=days))] + params).fetchall()
    out = []
    for r in rows:
        d = json.loads(r["data_json"] or "{}")
        out.append({"id": r["id"], "point_at": r["point_at"], "factory_name": r["factory_name"], "ack_at": r["ack_at"],
                    "ack_by_name": r["ack_by_name"], "has_note": bool(r["note"]), "carry_n": d.get("carry_n", 0),
                    "missed": d.get("missed", 0), "done": d.get("done", 0), "total": d.get("total", 0),
                    "ng_n": len(d.get("ng_open") or []), "down_n": d.get("down_n", 0)})
    return out
