"""ecs/fieldinfo.py — v0.39 ข้อมูลช่วยช่างหน้างาน

- machine_history : ประวัติเครื่องเมื่อสแกน QR / เปิดแบบฟอร์ม (NG ล่าสุด · ใบแจ้งซ่อม/งานแก้ไขที่ยังเปิด · PM ถัดไป · หยุดล่าสุด)
- plan            : ปฏิทินงานตรวจ 7 / 30 วันข้างหน้า (รอบตามตารางของแบบฟอร์มที่มอบหมาย + แผน PM/TPM)
- my_stats        : สถิติส่วนตัวของช่าง (เดือนนี้ เทียบเดือนก่อน + ค่าเฉลี่ยทีม) — ใช้เป็น feedback เชิงบวก ไม่จัดอันดับรายคน
ทุกฟังก์ชันอ่านอย่างเดียว · ส่วนที่ต่อ UT-CMMS ผิดพลาดได้ต้องไม่ทำให้หน้าเปิดไม่ได้
"""
from __future__ import annotations

import calendar
import logging
from datetime import date, datetime, timedelta

from . import services as S
from .services import parse_ts, ts

log = logging.getLogger(__name__)

WO_OPEN = ("pending", "approved", "in_progress")
ACT_OPEN = ("open", "in_progress")
FREQ_SHORT = {"shift": "รายกะ", "daily": "รายวัน", "weekly": "รายสัปดาห์", "monthly": "รายเดือน",
              "semimonthly": "ครึ่งเดือน"}
DAILY_KINDS = ("shift", "daily")
TH_MON = ("ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.")


def _freq_short(ft: str) -> str:
    if ft in FREQ_SHORT:
        return FREQ_SHORT[ft]
    from .itemfreq import interval, interval_label
    return interval_label(ft) if interval(ft or "") else ""


def _is_daily(ft: str) -> bool:
    return ft in DAILY_KINDS or (ft or "").startswith("d:")


# ───────────────────────── 4) ประวัติเครื่อง ─────────────────────────

def machine_history(db, form_id: int, app_config=None, limit: int = 5) -> dict:
    """สรุปสั้น ๆ ที่ช่างควรรู้ก่อนตรวจเครื่องนี้"""
    form = db.execute("SELECT id, equipment_id FROM cs_forms WHERE id=?", (form_id,)).fetchone()
    if not form:
        return {}
    eq_id = form["equipment_id"]
    forms = [r[0] for r in db.execute("SELECT id FROM cs_forms WHERE equipment_id=?", (eq_id,))] if eq_id else [form_id]
    ph = ",".join("?" * len(forms))
    last = db.execute(f"""SELECT s.id, s.finished_at, s.ng_count, u.name AS inspector FROM cs_submissions s
                          LEFT JOIN users u ON u.id=s.inspector_id WHERE s.form_id IN ({ph}) AND s.status<>'superseded'
                          ORDER BY s.finished_at DESC LIMIT 1""", forms).fetchone()
    ngs = []
    for r in db.execute(f"""SELECT a.item_key, a.value_text, a.judgement, a.remark, s.id AS sub_id, s.finished_at, s.form_version_id,
                                   u.name AS inspector
                            FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id LEFT JOIN users u ON u.id=s.inspector_id
                            WHERE s.form_id IN ({ph}) AND s.status<>'superseded' AND a.judgement='ng'
                            ORDER BY s.finished_at DESC LIMIT ?""", forms + [limit]):
        it = db.execute("SELECT name, unit FROM cs_form_items WHERE version_id=? AND item_key=?",
                        (r["form_version_id"], r["item_key"])).fetchone()
        ngs.append({"item": it["name"] if it else r["item_key"], "unit": (it["unit"] or "") if it else "",
                    "value": r["value_text"] or "", "remark": r["remark"] or "", "at": r["finished_at"],
                    "by": r["inspector"] or "", "sub_id": r["sub_id"]})
    # จำนวนครั้งที่ NG ใน 30 วัน (ต่อหัวข้อ) → เตือน "NG ซ้ำ"
    since = ts(S.now_dt() - timedelta(days=30))
    repeat = {r["item_key"]: r["n"] for r in db.execute(
        f"""SELECT a.item_key, COUNT(*) n FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
            WHERE s.form_id IN ({ph}) AND s.status<>'superseded' AND a.judgement='ng' AND s.finished_at>=?
            GROUP BY a.item_key HAVING n>=2""", forms + [since])}
    wos = []
    try:
        from .cmms_wo import STATUS_TH, ensure
        ensure(db)
        cond = "equipment_id=?" if eq_id else f"form_id IN ({ph})"
        for r in db.execute(f"""SELECT wo_number, status, created_at, assignee FROM cs_cmms_wo WHERE {cond}
                                AND status IN ({','.join('?' * len(WO_OPEN))}) ORDER BY created_at DESC LIMIT 5""",
                            ([eq_id] if eq_id else forms) + list(WO_OPEN)):
            wos.append({"no": r["wo_number"], "status": STATUS_TH.get(r["status"], r["status"]), "at": r["created_at"],
                        "assignee": r["assignee"] or ""})
    except Exception:                                   # noqa: BLE001
        log.exception("history wo failed")
    acts = [{"code": r["code"], "title": r["title"], "status": r["status"], "due": r["due_date"], "id": r["id"]}
            for r in db.execute(f"""SELECT id, code, title, status, due_date FROM cs_actions
                                    WHERE ({'equipment_id=?' if eq_id else 'form_id IN (' + ph + ')'})
                                    AND status IN ('open','in_progress') ORDER BY due_date LIMIT 5""",
                                [eq_id] if eq_id else forms)]
    down = None
    if eq_id:
        d = db.execute("""SELECT start_at, end_at, category, reason FROM cs_downtime WHERE equipment_id=?
                          ORDER BY start_at DESC LIMIT 1""", (eq_id,)).fetchone()
        if d:
            from .downtime import CATEGORIES
            down = {"start": d["start_at"], "end": d["end_at"], "cat": CATEGORIES.get(d["category"], d["category"]),
                    "reason": d["reason"] or ""}
    pms = next_pm(db, app_config, forms) if app_config is not None else []
    return {"last": dict(last) if last else None, "ngs": ngs, "repeat": repeat, "wos": wos, "actions": acts,
            "down": down, "pm": pms[:3]}


def next_pm(db, app_config, form_ids: list[int], until: date | None = None) -> list[dict]:
    """แผน PM/TPM (UT-CMMS) ที่เชื่อมกับแบบฟอร์ม เรียงตามกำหนดถัดไป"""
    try:
        from . import cmms_tpm as TPM
        TPM.ensure(db)
        if not TPM.get_settings(db)["enabled"] or not TPM.available(app_config):
            return []
        if not form_ids:
            return []
        links = [dict(r) for r in db.execute(
            f"""SELECT l.form_id, l.plan_id, f.name AS form_name, f.factory_id, e.code AS eq_code FROM cs_tpm_links l
                JOIN cs_forms f ON f.id=l.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
                WHERE l.form_id IN ({','.join('?' * len(form_ids))})""", form_ids)]
        plans = TPM.plans_by_ids(app_config, sorted({lk["plan_id"] for lk in links}))
        out, seen = [], set()
        for lk in links:
            p = plans.get(lk["plan_id"])
            if not p or p["id"] in seen or p["status"] not in ("scheduled", "pending"):
                continue
            try:
                due = date.fromisoformat(str(p["next_due"])[:10])
            except ValueError:
                continue
            if until and due > until:
                continue
            seen.add(p["id"])
            out.append({"task": p["task"], "due": due.isoformat(), "state": p["state"], "state_th": p["badge"][0],
                        "freq": p["freq_label"], "form_id": lk["form_id"], "form_name": lk["form_name"],
                        "eq_code": lk["eq_code"], "factory_id": lk["factory_id"], "assignee": p.get("assignee_name") or ""})
        return sorted(out, key=lambda x: x["due"])
    except Exception:                                   # noqa: BLE001
        log.exception("next pm failed")
        return []


# ───────────────────────── 8) ปฏิทินงานสัปดาห์นี้ / เดือนนี้ ─────────────────────────

def _my_schedules(db, user: dict) -> list[dict]:
    cond, params = ["s.active=1", "f.active=1", "COALESCE(f.is_template,0)=0", "f.current_version_id IS NOT NULL"], []
    if user.get("factory_id"):
        cond.append("(f.factory_id IS NULL OR f.factory_id=?)")
        params.append(user["factory_id"])
    if user.get("role") == "technician":
        cond.append("(s.assignee_user_id=? OR (s.assignee_user_id IS NULL AND COALESCE(s.assignee_role,'') IN ('', 'technician')))")
        params.append(user["id"])
    return [dict(r) for r in db.execute(f"""
        SELECT s.*, f.name AS form_name, f.code AS form_code, f.factory_id, f.category, e.code AS eq_code, e.name AS eq_name,
               e.eq_type, COALESCE(e.run_status,'running') AS run_status, fa.name AS factory_name, ar.name AS area_name,
               u.name AS assignee_name
        FROM cs_schedules s JOIN cs_forms f ON f.id=s.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id LEFT JOIN areas ar ON ar.id=f.area_id
        LEFT JOIN users u ON u.id=s.assignee_user_id
        WHERE {' AND '.join(cond)}""", params)]


def plan(db, user_id: int, days: int = 7, app_config=None, today: date | None = None) -> dict:
    """{days: [{date, items: [...]}], counts} — รอบตามตารางตรวจของงานที่มอบหมาย (ไม่ต้องรอระบบสร้างรอบล่วงหน้า)"""
    from .submissions import user_scope
    user = user_scope(db, user_id)
    today = today or S.now_dt().date()
    end = today + timedelta(days=max(1, days) - 1)
    holidays = S._holidays(db) if hasattr(S, "_holidays") else set()
    rounds = {}
    for r in db.execute("""SELECT id, schedule_id, due_at, status, submission_id FROM cs_rounds WHERE due_at BETWEEN ? AND ?""",
                        (ts(datetime.combine(today, datetime.min.time())), ts(datetime.combine(end, datetime.max.time())))):
        rounds[(r["schedule_id"], r["due_at"])] = dict(r)
    by_day: dict[date, list] = {today + timedelta(days=i): [] for i in range((end - today).days + 1)}
    form_ids = set()
    for s in _my_schedules(db, user):
        for due in S.occurrences(s, today, end, holidays):
            deadline = S.half_month_end(due) if s["freq_type"] == "semimonthly" else due + timedelta(minutes=int(s["window_min"]))
            rd = rounds.get((s["id"], ts(due)))
            st = rd["status"] if rd else ("skipped" if s["run_status"] == "down" else "planned")
            by_day[due.date()].append({
                "kind": "round", "form_id": s["form_id"], "form_name": s["form_name"], "eq_code": s["eq_code"] or "",
                "factory_id": s["factory_id"], "factory_name": s["factory_name"] or "", "area_name": s["area_name"] or "",
                "cat": S.form_category(s), "due": ts(due), "deadline": ts(deadline), "freq": s["freq_type"],
                "freq_th": _freq_short(s["freq_type"]), "daily": _is_daily(s["freq_type"]), "status": st,
                "round_id": rd["id"] if rd else None, "assignee": s["assignee_name"] or "", "down": s["run_status"] == "down"})
            form_ids.add(s["form_id"])
    if app_config is not None:
        from .submissions import mobile_forms
        mine = {f["id"] for f in mobile_forms(db, user_id)}
        for p in next_pm(db, app_config, sorted(mine), until=end):
            d = date.fromisoformat(p["due"])
            key = d if d >= today else today                 # เลยกำหนดแล้ว → แสดงวันนี้
            by_day[key].append({"kind": "pm", "form_id": p["form_id"], "form_name": p["form_name"], "eq_code": p["eq_code"] or "",
                                "factory_id": p["factory_id"], "task": p["task"], "due": p["due"], "freq_th": p["freq"],
                                "state": p["state"], "state_th": p["state_th"], "overdue": d < today, "daily": False,
                                "assignee": p["assignee"]})
    out = []
    for d, items in sorted(by_day.items()):
        items.sort(key=lambda x: (x["kind"] != "pm", x.get("due") or "", x.get("eq_code") or ""))
        out.append({"date": d.isoformat(), "items": items})
    all_items = [x for d in out for x in d["items"]]
    return {"from": today.isoformat(), "to": end.isoformat(), "days": out,
            "counts": {"rounds": sum(1 for x in all_items if x["kind"] == "round"),
                       "long": sum(1 for x in all_items if x["kind"] == "round" and not x["daily"]),
                       "pm": sum(1 for x in all_items if x["kind"] == "pm")}}


# ───────────────────────── 10) สถิติส่วนตัว ─────────────────────────

def _month_range(m: date) -> tuple[str, str]:
    last = calendar.monthrange(m.year, m.month)[1]
    return f"{m:%Y-%m}-01 00:00:00", f"{m:%Y-%m}-{last:02d} 23:59:59"


def _stats(db, a: str, b: str, user_id: int | None) -> dict:
    who = " AND s.inspector_id=?" if user_id else ""
    p = [a, b] + ([user_id] if user_id else [])
    r = db.execute(f"""SELECT COUNT(*) n, COUNT(DISTINCT s.form_id) machines, COUNT(DISTINCT substr(s.finished_at,1,10)) days,
                              COALESCE(SUM(s.ng_count>0),0) ng_subs, COALESCE(SUM(s.ng_count),0) ng_items,
                              COALESCE(SUM(s.status='returned' OR s.approval_status='rejected'),0) returned,
                              AVG(CASE WHEN s.duration_sec BETWEEN 10 AND 7200 THEN s.duration_sec END) avg_sec
                       FROM cs_submissions s WHERE s.status<>'superseded' AND s.finished_at BETWEEN ? AND ?{who}""", p).fetchone()
    rr = db.execute(f"""SELECT COALESCE(SUM(r.status='done_on_time'),0) on_time, COALESCE(SUM(r.status='done_late'),0) late
                        FROM cs_rounds r JOIN cs_submissions s ON s.id=r.submission_id
                        WHERE s.finished_at BETWEEN ? AND ?{who}""", p).fetchone()
    fixed = db.execute(f"""SELECT COUNT(*) FROM cs_actions c JOIN cs_submissions s ON s.id=c.submission_id
                           WHERE c.status IN ('done','closed') AND s.finished_at BETWEEN ? AND ?{who}""", p).fetchone()[0]
    done = (rr["on_time"] or 0) + (rr["late"] or 0)
    return {"n": r["n"], "machines": r["machines"], "days": r["days"], "ng_subs": r["ng_subs"], "ng_items": r["ng_items"],
            "returned": r["returned"], "avg_min": round(r["avg_sec"] / 60, 1) if r["avg_sec"] else None,
            "on_time": rr["on_time"] or 0, "late": rr["late"] or 0,
            "on_time_pct": round(100 * (rr["on_time"] or 0) / done) if done else None, "fixed": fixed}


def my_stats(db, user_id: int, today: date | None = None) -> dict:
    today = today or S.now_dt().date()
    m0 = today.replace(day=1)
    m1 = (m0 - timedelta(days=1)).replace(day=1)
    cur, prev = _stats(db, *_month_range(m0), user_id), _stats(db, *_month_range(m1), user_id)
    team = _stats(db, *_month_range(m0), None)
    n_insp = db.execute(f"""SELECT COUNT(DISTINCT inspector_id) FROM cs_submissions
                            WHERE status<>'superseded' AND finished_at BETWEEN ? AND ?""", _month_range(m0)).fetchone()[0] or 1
    trend = []
    m = m0
    for _ in range(6):
        a, b = _month_range(m)
        n = db.execute("SELECT COUNT(*) FROM cs_submissions WHERE status<>'superseded' AND inspector_id=? AND finished_at BETWEEN ? AND ?",
                       (user_id, a, b)).fetchone()[0]
        trend.append({"month": m.strftime("%Y-%m"), "n": n, "label": f"{TH_MON[m.month - 1]} {str(m.year + 543)[2:]}"})
        m = (m - timedelta(days=1)).replace(day=1)
    # วันต่อเนื่องที่มีการตรวจ (นับถึงวันนี้/เมื่อวาน)
    days = {r[0] for r in db.execute("""SELECT DISTINCT substr(finished_at,1,10) FROM cs_submissions
                                        WHERE inspector_id=? AND status<>'superseded' AND finished_at>=?""",
                                     (user_id, ts(datetime.combine(today - timedelta(days=90), datetime.min.time()))))}
    streak, d = 0, today if today.isoformat() in days else today - timedelta(days=1)
    while d.isoformat() in days:
        streak += 1
        d -= timedelta(days=1)
    full = ("มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน",
            "ตุลาคม", "พฤศจิกายน", "ธันวาคม")
    return {"month": m0.isoformat(), "month_th": f"{full[m0.month - 1]} {m0.year + 543}", "cur": cur, "prev": prev, "team_on_time_pct": team["on_time_pct"],
            "team_avg_n": round(team["n"] / n_insp, 1) if team["n"] else 0, "trend": list(reversed(trend)), "streak": streak}
