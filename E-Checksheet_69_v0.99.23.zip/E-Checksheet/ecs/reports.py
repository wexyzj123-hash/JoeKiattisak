"""ecs/reports.py — รายงาน Excel จากหน้า Dashboard (ผลตรวจรายวัน, รอบตรวจ, แจ้งเตือนค้าง, สรุปรายพื้นที่)"""
from __future__ import annotations

import io
import re
from datetime import date, datetime

from . import anomaly as A
from . import services as S

JUDGE_TH = {"ok": "ปกติ", "warn": "เตือน", "ng": "NG", "na": "-"}
from . import terms as _TR   # v0.50 ภาษากลาง
ROUND_TH = _TR.th("ROUND")
APPROVAL_TH = _TR.th("APPROVAL")
SEV_TH = _TR.th("SEVERITY")
STATUS_TH = _TR.th("ALERT")

REPORTS = {
    "results": "ผลตรวจประจำวัน",
    "rounds": "รอบตรวจประจำวัน",
    "alerts": "รายการแจ้งเตือนค้าง",
    "compliance": "สรุปการตรวจรายพื้นที่",
}


def _sheet(wb, first: bool, title: str, subtitle: str, headers: list[str], rows: list[list], widths: list[int],
           highlight=None, sheet_name: str | None = None):
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    ws = wb.active if first else wb.create_sheet()
    ws.title = re.sub(r"[\\/*?:\[\]]", "-", sheet_name or title)[:31]
    thin = Side(style="thin", color="D0D5DD")
    ws.append([title])
    ws["A1"].font = Font(bold=True, size=14)
    ws.append([subtitle])
    ws["A2"].font = Font(color="667085")
    ws.append([])
    ws.append(headers)
    for c in ws[4]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1D4ED8")
        c.alignment = Alignment(vertical="center", wrap_text=True)
        c.border = Border(bottom=thin)
    fills = {"ng": PatternFill("solid", fgColor="FDE2E1"), "warn": PatternFill("solid", fgColor="FEF3C7"),
             "ok": PatternFill("solid", fgColor="DCFCE7")}
    for r in rows:
        ws.append(r)
        mark = highlight(r) if highlight else None
        for c in ws[ws.max_row]:
            c.border = Border(bottom=thin)
            c.alignment = Alignment(vertical="top", wrap_text=True)
            if mark in fills:
                c.fill = fills[mark]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A5"
    if rows:
        ws.auto_filter.ref = f"A4:{get_column_letter(len(headers))}{ws.max_row}"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = "4:4"
    return ws


def workbook(sheets: list[dict]) -> bytes:
    """sheets = [{title, subtitle, headers, rows, widths, highlight?, sheet_name?}]"""
    from openpyxl import Workbook
    wb = Workbook()
    for i, sh in enumerate(sheets):
        _sheet(wb, i == 0, **sh)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _book(title: str, subtitle: str, headers: list[str], rows: list[list], widths: list[int],
          highlight=None) -> bytes:
    return workbook([{"title": title, "subtitle": subtitle, "headers": headers, "rows": rows, "widths": widths,
                      "highlight": highlight}])


def _fac_name(db, factory_id) -> str:
    if not factory_id:
        return "ทุกโรงงาน"
    r = db.execute("SELECT name FROM factories WHERE id=?", (factory_id,)).fetchone()
    return r["name"] if r else "-"


def _spec(mn, mx) -> str:
    if mn is None and mx is None:
        return ""
    if mn is None:
        return f"≤ {mx:g}"
    if mx is None:
        return f"≥ {mn:g}"
    return f"{mn:g} – {mx:g}"


def _dt(v, fmt="%d/%m/%Y %H:%M") -> str:
    d = S.parse_ts(v) if isinstance(v, str) else v
    return d.strftime(fmt) if isinstance(d, datetime) else ""


def results_report(db, day: date, factory_id=None) -> bytes:
    fc, fp = (" AND f.factory_id=?", [factory_id]) if factory_id else ("", [])
    rows = db.execute(f"""
        SELECT s.id AS sub_id, s.finished_at, s.duration_sec, s.approval_status, fa.name AS factory, ar.name AS area,
               e.code AS eq_code, f.name AS form_name, u.name AS inspector, i.name AS item, i.unit, i.min_value, i.max_value,
               a.value_text, a.value_num, a.judgement, a.remark, i.item_type
        FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id JOIN cs_form_items i ON i.id=a.item_id
        JOIN cs_forms f ON f.id=s.form_id LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN areas ar ON ar.id=COALESCE(f.area_id, e.area_id)
        LEFT JOIN users u ON u.id=s.inspector_id
        WHERE s.status<>'superseded' AND s.finished_at BETWEEN ? AND ? {fc}
        ORDER BY s.finished_at, s.id, i.order_no""", [f"{day} 00:00:00", f"{day} 23:59:59"] + fp).fetchall()
    data = [[r["sub_id"], _dt(r["finished_at"], "%H:%M"), r["factory"] or "", r["area"] or "", r["eq_code"] or "",
             r["form_name"], r["inspector"] or "", r["item"],
             r["value_num"] if r["value_num"] is not None else r["value_text"], r["unit"] or "",
             _spec(r["min_value"], r["max_value"]) if r["item_type"] in ("number", "counter", "calc") else "",
             JUDGE_TH.get(r["judgement"], r["judgement"]), r["remark"] or "",
             APPROVAL_TH.get(r["approval_status"], r["approval_status"])] for r in rows]
    return _book(f"ผลตรวจประจำวัน {day.strftime('%d/%m/%Y')}", f"{_fac_name(db, factory_id)} · {len(data)} หัวข้อ",
                 ["เลขที่", "เวลา", "โรงงาน", "พื้นที่", "เครื่อง", "แบบฟอร์ม", "ผู้ตรวจ", "หัวข้อ", "ค่า", "หน่วย",
                  "เกณฑ์", "ผล", "หมายเหตุ", "อนุมัติ"], data,
                 [8, 7, 12, 18, 11, 30, 18, 26, 10, 8, 12, 8, 30, 12],
                 highlight=lambda r: {"NG": "ng", "เตือน": "warn"}.get(r[11]))


def rounds_report(db, day: date, factory_id=None) -> bytes:
    ov = S.rounds_overview(db, day, factory_id)
    subs = {r["id"]: r for r in db.execute(
        f"SELECT id, duration_sec FROM cs_submissions WHERE id IN ({','.join(str(int(i['submission_id'])) for i in ov['items'] if i['submission_id']) or '0'})")}
    data = []
    for r in ov["items"]:
        dur = subs.get(r["submission_id"])
        data.append([_dt(r["due_at"], "%H:%M"), _dt(r["deadline_at"], "%H:%M"), r["factory_name"] or "", r["eq_code"] or "",
                     r["form_name"], ROUND_TH.get(r["status"], r["status"]), r["inspector_name"] or "",
                     _dt(r["finished_at"], "%H:%M"),
                     round(dur["duration_sec"] / 60, 1) if dur and dur["duration_sec"] else "", r["ng_count"] or 0,
                     APPROVAL_TH.get(r["approval_status"], "") if r["approval_status"] else ""])
    c = ov["counts"]
    sub = (f"{_fac_name(db, factory_id)} · ทั้งหมด {ov['total']} รอบ · ตรวจแล้ว {ov['done']} · ขาดตรวจ {c['missed']} "
           f"· เลยกำหนด {c['overdue']} · ตรงเวลา {'-' if ov['on_time_rate'] is None else str(ov['on_time_rate']) + '%'}")
    return _book(f"รอบตรวจประจำวัน {day.strftime('%d/%m/%Y')}", sub,
                 ["เริ่มตรวจ", "ต้องเสร็จ", "โรงงาน", "เครื่อง", "แบบฟอร์ม", "สถานะ", "ผู้ตรวจ", "ส่งผลเวลา",
                  "ใช้เวลา (นาที)", "NG", "อนุมัติ"], data, [10, 10, 12, 11, 34, 13, 20, 10, 12, 6, 12],
                 highlight=lambda r: "ng" if r[5] in ("ขาดตรวจ", "ตีกลับ") else ("warn" if r[5] in ("เลยกำหนด", "ตรวจล่าช้า") else None))


def alerts_report(db, factory_id=None) -> bytes:
    rows = A.list_alerts(db, status="open", factory_id=factory_id, limit=5000)
    data = [[a["id"], SEV_TH.get(a["severity"], a["severity"]), A.TYPE_TH.get(a["alert_type"], a["alert_type"]),
             a["factory_name"] or "", a["eq_code"] or "", a["title"], a["detail"], a["occurrences"],
             _dt(a["created_at"]), _dt(a["updated_at"]), STATUS_TH.get(a["status"], a["status"])] for a in rows]
    return _book("รายการแจ้งเตือนค้าง", f"{_fac_name(db, factory_id)} · {len(data)} รายการ · ออกรายงาน {datetime.now():%d/%m/%Y %H:%M}",
                 ["เลขที่", "ระดับ", "ประเภท", "โรงงาน", "เครื่อง", "รายการ", "รายละเอียด", "ครั้ง", "เกิดครั้งแรก",
                  "ล่าสุด", "สถานะ"], data, [8, 9, 20, 12, 11, 40, 50, 7, 16, 16, 13],
                 highlight=lambda r: "ng" if r[1] == "วิกฤต" else ("warn" if r[1] == "เตือน" else None))


def compliance_report(db, d_from: date, d_to: date, factory_id=None) -> bytes:
    from .analytics import ensure_stats, rate_status
    ensure_stats(db, d_from, d_to)
    fc, fp = (" AND f.factory_id=?", [factory_id]) if factory_id else ("", [])
    rows = db.execute(f"""
        SELECT COALESCE(fa.name, '-') fac, COALESCE(ar.name, 'ไม่ระบุพื้นที่') area, COUNT(DISTINCT f.id) forms,
               SUM(d.due) due, SUM(d.done_on_time) ot, SUM(d.done_late) late, SUM(d.missed) missed, SUM(d.ng) ng
        FROM cs_daily_stats d JOIN cs_forms f ON f.id=d.form_id LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN areas ar ON ar.id=COALESCE(f.area_id, e.area_id)
        WHERE d.stat_date BETWEEN ? AND ? {fc}
        GROUP BY fac, area ORDER BY MIN(COALESCE(fa.sort_no, 99)), fac, area""",
                      [d_from.isoformat(), d_to.isoformat()] + fp).fetchall()
    label = {"good": "ผ่านเป้าหมาย", "warning": "เฝ้าระวัง", "critical": "ต่ำกว่าเกณฑ์", "none": "-"}
    data = []
    for r in rows:
        closed = (r["ot"] or 0) + (r["late"] or 0) + (r["missed"] or 0)
        rate = round(100.0 * (r["ot"] or 0) / closed, 1) if closed else None
        data.append([r["fac"], r["area"], r["forms"], r["due"] or 0, r["ot"] or 0, r["late"] or 0, r["missed"] or 0,
                     rate if rate is not None else "", label[rate_status(rate)], r["ng"] or 0])
    return _book("สรุปการตรวจรายพื้นที่", f"{_fac_name(db, factory_id)} · {d_from:%d/%m/%Y} – {d_to:%d/%m/%Y} · เป้าหมายตรวจตรงเวลา ≥ 95%",
                 ["โรงงาน", "พื้นที่", "แบบฟอร์ม", "รอบที่กำหนด", "ตรงเวลา", "ล่าช้า", "ขาดตรวจ", "% ตรงเวลา", "สถานะ", "NG"],
                 data, [14, 26, 10, 12, 10, 10, 10, 11, 14, 8],
                 highlight=lambda r: {"ต่ำกว่าเกณฑ์": "ng", "เฝ้าระวัง": "warn"}.get(r[8]))
