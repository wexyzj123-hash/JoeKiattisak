"""ecs/sheet_actions.py — v0.85 อนุมัติ / ลงนามจากหน้าใบบันทึกประจำเดือน

- แถวหัวหน้างาน (Sr.Tech): อนุมัติผลตรวจที่รอในช่วงของช่องนั้น + รับรองค่าจาก SCADA ที่ระบบอนุมัติเอง (ยังไม่มีชื่อผู้อนุมัติ)
  → ช่องลงนามเติมอัตโนมัติด้วยลายเซ็นของผู้กด (signoffs.sync_week)
- ช่องลงนามอื่น (แถวหน่วยงาน / กล่องมุมขวาบน / ท้ายเอกสาร) → signoffs.sign ตามสิทธิ์และลำดับเดิม
"""
from __future__ import annotations

from datetime import date

from . import services as S
from . import signoffs as SO
from . import sign_blocks as SB
from .services import ValidationError, ts


def _bounds(month: date, start: int, span: int) -> tuple[str, str]:
    return (f"{SO.month_key(month)}-{start:02d} 00:00:00", f"{SO.month_key(month)}-{start + span - 1:02d} 23:59:59")


def _range_subs(db, form_id: int, a: str, b: str) -> list[dict]:
    return [dict(r) for r in db.execute(
        """SELECT id, approval_status, approved_by, ng_count, source FROM cs_submissions
           WHERE form_id=? AND status='submitted' AND finished_at BETWEEN ? AND ?""", (form_id, a, b))]


def seg_state(db, form_id: int, month: date, start: int, span: int) -> dict:
    """{pending, ng, unsigned} ของช่วงช่องหัวหน้างาน — unsigned = อนุมัติอัตโนมัติแล้วแต่ยังไม่มีผู้รับรอง"""
    rows = _range_subs(db, form_id, *_bounds(month, start, span))
    pend = [r for r in rows if r["approval_status"] == "pending"]
    return {"pending": len(pend), "ng": sum(1 for r in pend if r["ng_count"]),
            "unsigned": sum(1 for r in rows if r["approval_status"] == "approved" and not r["approved_by"]),
            "total": len(rows)}


def approve_range(db, form: dict, month: date, start: int, span: int, actor_id: int, include_ng: bool = False) -> dict:
    """อนุมัติผลตรวจที่รอ + รับรองค่าที่ระบบอนุมัติเอง ในช่วงวันที่ของช่อง → ลงนามแถวหัวหน้างานอัตโนมัติ"""
    from . import submissions as SUB
    if not SUB.can_approve(db, actor_id):
        raise ValidationError("เฉพาะหัวหน้างาน ผู้ดูแลระบบ หรือผู้ที่ได้รับสิทธิ์อนุมัติ")
    a, b = _bounds(month, start, span)
    approved = skipped_ng = certified = 0
    for r in _range_subs(db, form["id"], a, b):
        if r["approval_status"] == "pending":
            if r["ng_count"] and not include_ng:
                skipped_ng += 1
                continue
            SUB.approve(db, r["id"], actor_id, "อนุมัติจากหน้าใบบันทึก")
            approved += 1
        elif r["approval_status"] == "approved" and not r["approved_by"]:
            db.execute("""UPDATE cs_submissions SET approved_by=?, approved_at=?,
                          approval_note=TRIM(COALESCE(approval_note,'') || ' · รับรองในใบบันทึก') WHERE id=?""",
                       (actor_id, ts(), r["id"]))
            S.audit(db, actor_id, "certify", "cs_submissions", r["id"], after={"via": "month_sheet"})
            certified += 1
    SO.sync_week(db, form["id"], date(month.year, month.month, start), form=form)
    return {"approved": approved, "certified": certified, "skipped_ng": skipped_ng}


def actions(db, form: dict, month: date, user: dict) -> dict:
    """ปุ่มที่ผู้ใช้คนนี้กดได้ในใบบันทึก:
    sup {start: {pending, ng, unsigned, can}} · slots {slot: '' (ลงนามได้) | เหตุผลที่ยังลงไม่ได้} · n = จำนวนที่ทำได้ตอนนี้"""
    from . import submissions as SUB
    u = SO._user(db, user)
    last = SO._last_day(month)
    can_appr = SUB.can_approve(db, u["id"])
    sup = {}
    for sg in SB.sup_segments(db, form, month, last):
        st = seg_state(db, form["id"], month, sg["start"], sg["span"])
        st["can"] = can_appr and bool(st["pending"] or st["unsigned"])
        st["span"] = sg["span"]
        sup[sg["start"]] = st
    all_slots = SO.slots(db, form, month)
    groups = SO.user_groups(db, u["id"])
    slots = {}
    for sl in all_slots:
        if sl["slot"].startswith("row:sup:") or sl["rec"]:
            continue
        slots[sl["slot"]] = SO.check(db, sl, u, all_slots, groups=groups, form=form)
    n = sum(1 for x in sup.values() if x["can"]) + sum(1 for w in slots.values() if w == "")
    return {"sup": sup, "slots": slots, "n": n, "can_approve": can_appr}


def do_all(db, form: dict, month: date, user: dict) -> dict:
    """อนุมัติ / ลงนามทุกช่องที่ทำได้ (ไม่รวมผลตรวจที่มี NG — ตรวจรายการก่อน)"""
    acts = actions(db, form, month, user)
    res = {"approved": 0, "certified": 0, "skipped_ng": 0, "signed": 0}
    for start, st in acts["sup"].items():
        if st["can"]:
            r = approve_range(db, form, month, start, st["span"], user["id"])
            for k in ("approved", "certified", "skipped_ng"):
                res[k] += r[k]
    u = SO._user(db, user)
    for _ in range(6):                                      # ลำดับก่อน-หลัง (เช่น SV แล้วจึง Manager) — ทำซ้ำจนไม่มีช่องใหม่
        all_slots = SO.slots(db, form, month)
        ready = [sl for sl in all_slots if not sl["slot"].startswith("row:sup:") and not sl["rec"]
                 and SO.check(db, sl, u, all_slots, form=form) == ""]
        if not ready:
            break
        for sl in ready:
            try:
                SO.sign(db, form, month, sl["slot"], u)
                res["signed"] += 1
            except SO.SignError:
                pass
    return res
