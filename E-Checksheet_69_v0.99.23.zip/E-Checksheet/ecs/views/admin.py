"""ecs/views/admin.py — ข้อมูลหลัก: เครื่องจักร (+ QR), โรงงาน/พื้นที่, ผู้ใช้"""
from __future__ import annotations

import io

from flask import (Blueprint, Response, abort, current_app, flash, jsonify, redirect, render_template, request,
                   url_for)

from .. import downtime as DT
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, MANAGE_ROLES, current_user_id, require_role, safe_next
from ..services import ValidationError, list_forms

bp = Blueprint("admin", __name__)


def _flash_errors(exc: ValidationError):
    for e in exc.errors:
        flash(e, "error")


def _int(v):
    try:
        return int(v or 0) or None
    except ValueError:
        return None


def server_ips() -> list[str]:
    """IPv4 ทั้งหมดของเครื่องแม่ข่าย (โรงงานมีหลายวง LAN → ป้าย QR เลือกได้ว่าจะชี้ IP ไหน)"""
    import socket
    ips = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and ip not in ips:
                ips.append(ip)
    except OSError:
        pass
    return ips


def qr_bases() -> list[str]:
    """ที่อยู่ที่ใช้ทำ QR ได้: ที่อยู่ที่กำลังเปิดอยู่ + ทุก IP ของเครื่อง (+ QR_BASE_URL ถ้าตั้งไว้)"""
    root = request.script_root or ""
    host = request.host                       # เช่น 192.168.133.129:5000 — IP/ชื่อที่ผู้ใช้เปิดเข้ามาจริง
    port = host.rsplit(":", 1)[1] if ":" in host and not host.endswith("]") else ""
    scheme = request.scheme
    out = [f"{scheme}://{host}{root}"]
    for ip in server_ips():
        b = f"{scheme}://{ip}{':' + port if port else ''}{root}"
        if b not in out:
            out.append(b)
    fixed = (current_app.config.get("QR_BASE_URL") or "").rstrip("/")
    if fixed and fixed not in out:
        out.insert(0, fixed)
    return out


def qr_base() -> str:
    """ค่าเริ่มต้น = ที่อยู่ที่ผู้ใช้กำลังเปิดอยู่ (ไม่ล็อค IP) · เลือก IP อื่นได้ด้วย ?base= · QR_BASE_URL ใน .env บังคับค่าคงที่"""
    bases = qr_bases()
    want = (request.args.get("base") or "").rstrip("/")
    if want in bases:
        return want
    fixed = (current_app.config.get("QR_BASE_URL") or "").rstrip("/")
    return fixed or bases[0]


def qr_url(token: str, base: str | None = None) -> str:
    return f"{base or qr_base()}/e/{token}"


def qr_svg(data: str, box: int = 6) -> str | None:
    """คืน SVG ของ QR (ต้องติดตั้ง qrcode) — ถ้าไม่มีไลบรารีคืน None"""
    try:
        import qrcode
        import qrcode.image.svg
    except ImportError:
        return None
    img = qrcode.make(data, image_factory=qrcode.image.svg.SvgPathImage, box_size=box, border=2)
    buf = io.BytesIO()
    img.save(buf)
    svg = buf.getvalue().decode("utf-8")
    return svg[svg.index("<svg"):]


# ───────────────────────── equipment ─────────────────────────

@bp.route("/equipment")
@require_role(*ALL_ROLES)
def equipment():
    db = get_db()
    factory_id, area_id = _int(request.args.get("factory")), _int(request.args.get("area"))
    q = request.args.get("q", "").strip()
    inactive = request.args.get("inactive") == "1"
    has_forms = request.args.get("forms", "")            # "" | yes | no
    eq_type = request.args.get("type", "")
    items = M.list_equipment(db, factory_id, area_id, q, inactive)
    types = sorted({(i["eq_type"] or "").strip() for i in items if (i["eq_type"] or "").strip()}, key=str.lower)
    counts = {"all": len(items), "yes": sum(1 for i in items if i["form_count"]),
              "no": sum(1 for i in items if not i["form_count"]),
              "down": sum(1 for i in items if i.get("run_status") == "down")}
    if has_forms == "down":
        items = [i for i in items if i.get("run_status") == "down"]
    if has_forms == "yes":
        items = [i for i in items if i["form_count"]]
    elif has_forms == "no":
        items = [i for i in items if not i["form_count"]]
    if eq_type:
        items = [i for i in items if (i["eq_type"] or "").strip().lower() == eq_type.lower()]
    return render_template("admin/equipment.html", items=items, types=types, counts=counts,
                           factories=M.list_factories(db), areas=M.list_areas(db), has_forms=has_forms,
                           eq_type=eq_type, factory_id=factory_id, area_id=area_id, q=q, inactive=inactive)


@bp.route("/api/equipment/delete-check")
@require_role("admin")
def api_equipment_delete_check():
    from ..services import equipment_delete_impact
    ids = [int(x) for part in request.args.getlist("ids") for x in part.split(",") if x.strip().isdigit()]
    return jsonify({"items": equipment_delete_impact(get_db(), ids)})


@bp.route("/equipment/delete", methods=["POST"])
@require_role("admin")
def equipment_delete():
    """ลบเครื่องจักร (หลายเครื่องได้) — forms=keep เก็บแบบฟอร์มไว้ / forms=delete ลบแบบฟอร์มและผลตรวจด้วย"""
    from ..services import delete_equipment, remove_upload_files
    db = get_db()
    ids = [int(x) for x in request.form.getlist("ids") if str(x).isdigit()]
    mode = request.form.get("forms", "keep")
    if not ids:
        flash("ยังไม่ได้เลือกเครื่องจักร", "error")
        return redirect(url_for("admin.equipment"))
    files, codes, kept, dropped = [], [], 0, 0
    try:
        for eid in ids:
            res = delete_equipment(db, eid, current_user_id(), delete_forms=(mode == "delete"))
            files += res["files"]
            codes.append(res["code"])
            kept += res["forms_kept"]
            dropped += res["forms_deleted"]
        db.commit()
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return redirect(url_for("admin.equipment"))
    remove_upload_files(current_app.config["UPLOAD_FOLDER"], files)
    msg = f"ลบเครื่องจักร {len(codes)} เครื่อง: " + ", ".join(codes[:12]) + (" …" if len(codes) > 12 else "")
    if kept:
        msg += f" · เก็บแบบฟอร์ม {kept} ฉบับไว้เป็นแบบฟอร์มไม่ผูกเครื่อง"
    if dropped:
        msg += f" · ลบแบบฟอร์ม {dropped} ฉบับ"
    flash(msg, "ok")
    return redirect(safe_next(request.form.get("back"), url_for("admin.equipment")))


@bp.route("/equipment/new", methods=["GET", "POST"])
@bp.route("/equipment/<int:equipment_id>/edit", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def equipment_edit(equipment_id=None):
    db = get_db()
    item = M.get_equipment(db, equipment_id) if equipment_id else None
    if equipment_id and not item:
        abort(404)
    if request.method == "POST":
        data = request.form.to_dict()
        data["notify_channels"] = request.form.getlist("notify_channels")
        data["active"] = 1 if request.form.get("active") else 0
        try:
            eid = M.save_equipment(db, data, current_user_id(), equipment_id)
            db.commit()
            flash("บันทึกเครื่องจักรแล้ว", "ok")
            return redirect(url_for("admin.equipment_detail", equipment_id=eid))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
            item = {**(item or {}), **data}
    return render_template("admin/equipment_edit.html", item=item, factories=M.list_factories(db),
                           areas=M.list_areas(db))


@bp.route("/equipment/<int:equipment_id>")
@require_role(*ALL_ROLES)
def equipment_detail(equipment_id):
    db = get_db()
    item = M.get_equipment(db, equipment_id)
    if not item:
        abort(404)
    from ..submissions import list_submissions
    subs, total = list_submissions(db, equipment_id=equipment_id, limit=20)
    from ..analytics import equipment_summary
    base = qr_base()
    url = qr_url(item["qr_token"], base)
    from .. import points as PT
    scan_forms = [{"form": f, "n": len(PT.label_list(db, [f], base))} for f in PT.scan_forms(db, [equipment_id])]
    return render_template("admin/equipment_detail.html", item=item, scan_forms=scan_forms,
                           n_points=sum(x["n"] for x in scan_forms), forms=list_forms(db, equipment_id=equipment_id,
                           include_inactive=True), subs=subs, sub_total=total, qr_link=url, qr=qr_svg(url),
                           qr_bases=qr_bases(), qr_base_now=base,
                           summary=equipment_summary(db, equipment_id), downtime=DT.history(db, equipment_id, 20),
                           DT_CATS=DT.CATEGORIES)


@bp.route("/equipment/<int:equipment_id>/regenerate-qr", methods=["POST"])
@require_role("admin")
def equipment_regenerate_qr(equipment_id):
    db = get_db()
    if not M.get_equipment(db, equipment_id):
        abort(404)
    M.regenerate_qr(db, equipment_id, current_user_id())
    db.commit()
    flash("สร้าง QR ใหม่แล้ว — ป้าย QR เดิมจะใช้ไม่ได้ ต้องพิมพ์ติดใหม่", "ok")
    return redirect(url_for("admin.equipment_detail", equipment_id=equipment_id))


@bp.route("/equipment/import", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def equipment_import():
    db = get_db()
    result = None
    if request.method == "POST":
        f = request.files.get("file")
        text = request.form.get("text", "")
        if f and f.filename:
            raw = f.read(2 * 1024 * 1024)
            for enc in ("utf-8-sig", "cp874", "tis-620"):
                try:
                    text = raw.decode(enc)
                    break
                except UnicodeDecodeError:
                    continue
        try:
            result = M.import_equipment_csv(db, text, current_user_id())
            from ..services import sync_forms_to_equipment
            sync_forms_to_equipment(db)
            db.commit()
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
    return render_template("admin/equipment_import.html", result=result, headers=M.EQUIPMENT_CSV_HEADERS)


@bp.route("/equipment/template.csv")
@require_role(*MANAGE_ROLES)
def equipment_template():
    body = "﻿" + ",".join(M.EQUIPMENT_CSV_HEADERS) + "\n" + \
        "SCT0002,Air Compressor SCT0002,Air Compressor,F1,Compressor Room,อาคาร 1\n"
    return Response(body, mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=equipment_template.csv"})


@bp.route("/equipment/qr-labels")
@require_role(*MANAGE_ROLES)
def qr_labels():
    """หน้าพิมพ์ป้าย QR (A4) รวมที่เดียว แยก 2 หมวด: ก. ป้ายเครื่องจักร · ข. ป้ายจุดตรวจ (แบบฟอร์มที่ต้องสแกนก่อนตรวจ)
    เลือกตามโรงงาน/พื้นที่ หรือระบุ id · kind=all|machine|points · form=<id> จำกัดป้ายจุดตรวจเฉพาะแบบฟอร์ม"""
    from .. import points as PT
    db = get_db()
    ids = [int(x) for x in request.args.getlist("id") if x.isdigit()]
    form_ids = [int(x) for x in request.args.getlist("form") if x.isdigit()]
    kind = request.args.get("kind", "all")
    if kind not in ("all", "machine", "points"):
        kind = "all"
    items = M.list_equipment(db, _int(request.args.get("factory")), _int(request.args.get("area")))
    if ids:
        items = [i for i in items if i["id"] in ids]
    base = qr_base()
    labels = [{**i, "url": qr_url(i["qr_token"], base), "svg": qr_svg(qr_url(i["qr_token"], base), box=5)} for i in items]
    eq_by_id = {i["id"]: i for i in items}
    points = []
    for lb in PT.label_list(db, PT.scan_forms(db, list(eq_by_id), form_ids), base):
        lb["svg"] = qr_svg(lb["url"], box=5)
        lb["eq"] = eq_by_id.get(lb["form"]["equipment_id"])
        points.append(lb)
    # จัดกลุ่มป้ายจุดตรวจตามเครื่อง › แบบฟอร์ม (หาง่ายตอนติดป้าย)
    groups: list[dict] = []
    for lb in points:
        if not groups or groups[-1]["form"]["id"] != lb["form"]["id"]:
            groups.append({"form": lb["form"], "eq": lb["eq"], "labels": []})
        groups[-1]["labels"].append(lb)
    any_svg = next((x["svg"] for x in labels + points), "")
    return render_template("admin/qr_labels.html", labels=labels, point_groups=groups, n_points=len(points), kind=kind,
                           missing_lib=any_svg is None, qr_bases=qr_bases(), qr_base_now=base)


# ───────────────────────── factories & areas ─────────────────────────

@bp.route("/admin/locations", methods=["GET", "POST"])
@require_role("admin")
def locations():
    db = get_db()
    if request.method == "POST":
        kind = request.form.get("kind")
        data = request.form.to_dict()
        data["active"] = 1 if request.form.get("active", "1") == "1" else 0
        try:
            if kind == "factory":
                M.save_factory(db, data, current_user_id(), _int(request.form.get("id")))
            else:
                M.save_area(db, data, current_user_id(), _int(request.form.get("id")))
            db.commit()
            flash("บันทึกแล้ว", "ok")
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
        return redirect(url_for("admin.locations"))
    return render_template("admin/locations.html", factories=M.list_factories(db, include_inactive=True),
                           areas=M.list_areas(db, include_inactive=True))


# ───────────────────────── users ─────────────────────────

@bp.route("/admin/users")
@require_role("admin")
def users():
    db = get_db()
    return render_template("admin/users.html", users=M.list_users(db), factories=M.list_factories(db))


@bp.route("/admin/users/new", methods=["GET", "POST"])
@bp.route("/admin/users/<int:user_id>", methods=["GET", "POST"])
@require_role("admin")
def user_edit(user_id=None):
    db = get_db()
    user = M.get_user(db, user_id) if user_id else None
    if user_id and not user:
        abort(404)
    if request.method == "POST":
        data = request.form.to_dict()
        data["active"] = 1 if request.form.get("active") else 0
        data["can_delete_results"] = 1 if request.form.get("can_delete_results") else 0
        data["can_approve"] = 1 if request.form.get("can_approve") else 0
        data["restrict_view"] = 1 if request.form.get("restrict_view") else 0
        try:
            M.save_user(db, data, current_user_id(), user_id)
            db.commit()
            flash("บันทึกผู้ใช้แล้ว" + (" — ผู้ใช้ต้องเปลี่ยนรหัสผ่านเมื่อเข้าระบบครั้งแรก" if not user_id else ""), "ok")
            return redirect(url_for("admin.users"))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
            user = {**(user or {}), **data}
    return render_template("admin/user_edit.html", user=user, factories=M.list_factories(db))


# ───────────────────────── เวลากะ / วันทำงาน (ใช้กับความถี่รายหัวข้อ) ─────────────────────────

@bp.route("/admin/work-calendar", methods=["GET", "POST"])
@require_role("admin")
def work_calendar():
    from ..itemfreq import FREQS, UNIT_TH, FreqError, all_freqs, custom_freqs, get_calendar, save_calendar, save_custom_freqs
    db = get_db()
    if request.method == "POST" and request.form.get("action") == "freqs":        # v0.32 ความถี่ที่ผู้ดูแลระบบเพิ่มเอง
        rows = [{"label": lb, "n": n, "unit": u} for lb, n, u in zip(request.form.getlist("f_label"), request.form.getlist("f_n"),
                                                                     request.form.getlist("f_unit"))]
        try:
            out = save_custom_freqs(db, rows)
            __import__("ecs.services", fromlist=["audit"]).audit(db, current_user_id(), "update", "cs_meta", None, after={"custom_freqs": out})
            db.commit()
            flash(f"บันทึกความถี่แล้ว ({len(out)} แบบ) — เลือกได้ใน Builder ทันที", "ok")
        except FreqError as exc:
            db.rollback()
            flash(str(exc), "error")
        return redirect(url_for("admin.work_calendar") + "#freqs")
    if request.method == "POST":
        try:
            save_calendar(db, {"shift_times": request.form.get("shift_times"), "day_start": request.form.get("day_start")})
            db.commit()
            flash("บันทึกเวลากะแล้ว — มีผลกับหัวข้อ 'กะละ 1 ครั้ง' / 'วันละ 1 ครั้ง' ทันที", "ok")
            return redirect(url_for("admin.work_calendar"))
        except FreqError as exc:
            flash(str(exc), "error")
    used = db.execute("""SELECT i.check_freq, COUNT(*) n FROM cs_form_items i JOIN cs_forms f ON f.current_version_id=i.version_id
                         WHERE COALESCE(i.check_freq,'')<>'' GROUP BY i.check_freq""").fetchall()
    return render_template("admin/work_calendar.html", cal=get_calendar(db), used={r[0]: r[1] for r in used},
                           freqs=all_freqs(db), builtin=FREQS, custom=custom_freqs(db), units=UNIT_TH)


# เส้นทางที่แยกไปไฟล์ย่อย (ต้อง import ท้ายไฟล์ เพราะไฟล์ย่อยอ้างชื่อจากไฟล์นี้)
from . import admin_cmms  # noqa: E402,F401
from . import admin_ops  # noqa: E402,F401
from . import admin_areas  # noqa: E402,F401
from . import admin_areamap  # noqa: E402,F401
