"""ecs/views/forms_schedules.py — แยกจาก forms.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from flask import abort, current_app, flash, jsonify, redirect, render_template, request, url_for
from .. import masterdata as M
from .. import services as S
from ..db import get_db
from ..security import MANAGE_ROLES, ALL_ROLES, current_user_id, require_role
from .. import perms as PM   # v0.52 สิทธิ์แก้ไขแบบฟอร์มรายคน

from .forms import bp, _factory_arg, _flash_errors, _load_form  # noqa: E402


# ── schedules ──

def _schedule_form_data():
    data = request.form.to_dict()
    data["weekdays"] = request.form.getlist("weekdays")
    data["skip_holidays"] = 1 if request.form.get("skip_holidays") else 0
    data["active"] = 1
    return data


def _push_tpl(db, form: dict | None, replace_own: bool = False) -> str:
    """รอบตรวจของแม่แบบเปลี่ยน → ส่งต่อให้ทุกเครื่องที่ใช้แม่แบบ"""
    if not form or not form.get("is_template"):
        return ""
    from .. import formtpl as T
    st = T.push_schedules(db, form["id"], current_user_id(), replace_own=replace_own)
    return (f" · ส่งต่อให้ {st['forms']} เครื่อง (สร้าง {st['created']} · แก้ {st['updated']} · ปิด {st['closed']})"
            if st["forms"] else " · ยังไม่มีเครื่องที่ใช้แม่แบบนี้ (เครื่องที่เพิ่มภายหลังจะได้รอบนี้อัตโนมัติ)")


def _resync_spans(db, form_id) -> None:
    """v0.37 รอบตรวจเปลี่ยน → ช่องหัวหน้างาน (Sr.Tech) แบบอัตโนมัติอาจยาวขึ้น/สั้นลง → คำนวณลายเซ็นที่เติมอัตโนมัติใหม่"""
    from .. import signoffs as SO
    try:
        for fid in [form_id] + [r[0] for r in db.execute("SELECT id FROM cs_forms WHERE template_id=?", (form_id,))]:
            SO.resync_form(db, fid)
    except Exception:                                        # noqa: BLE001
        current_app.logger.exception("resync spans failed")


def _relink(db, form_id) -> str:
    """v0.41 รอบตรวจเปลี่ยน → ผูกผลตรวจย้อนหลังกับรอบใหม่ + คำนวณตรงเวลา/ล่าช้า/ขาดตรวจใหม่"""
    from .. import statfix as SF
    try:
        return " · " + SF.summary_th(SF.relink_forms(db, [form_id], actor_id=current_user_id(), reason="แก้รอบตรวจ"))
    except Exception:                                        # noqa: BLE001 — ไม่ให้การบันทึกรอบตรวจล้ม
        current_app.logger.exception("relink failed")
        return ""


@bp.route("/forms/<int:form_id>/schedules/push", methods=["POST"])
@require_role(*MANAGE_ROLES)
def schedule_push(form_id):
    """แม่แบบ: ใช้รอบตรวจของแม่แบบกับทุกเครื่องตอนนี้ (เลือกได้ว่าจะปิดรอบที่แต่ละเครื่องตั้งเองหรือไม่)"""
    db = get_db()
    form = _load_form(db, form_id)
    if not form.get("is_template"):
        abort(400)
    msg = _push_tpl(db, form, replace_own=request.form.get("replace_own") == "1")
    S.generate_rounds(db)
    msg += _relink(db, form_id)
    _resync_spans(db, form_id)
    db.commit()
    flash("อัปเดตรอบตรวจของเครื่องที่ใช้แม่แบบแล้ว" + msg, "ok")
    return redirect(url_for("forms.form_detail", form_id=form_id) + "#schedules")


@bp.route("/forms/<int:form_id>/schedules", methods=["POST"])
@PM.require_form("schedule")
def schedule_create(form_id):
    db = get_db()
    form = _load_form(db, form_id)
    try:
        S.create_schedule(db, form_id, _schedule_form_data(), current_user_id())
        msg = _push_tpl(db, form, replace_own=request.form.get("replace_own") == "1")
        S.generate_rounds(db)
        msg += _relink(db, form_id)
        _resync_spans(db, form_id)
        db.commit()
        flash("เพิ่มรอบตรวจแล้ว" + msg, "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("forms.form_detail", form_id=form_id) + "#schedules")


@bp.route("/schedules/<int:schedule_id>", methods=["POST"])
@PM.require_form("schedule", by_schedule=True)
def schedule_update(schedule_id):
    db = get_db()
    row = db.execute("SELECT form_id FROM cs_schedules WHERE id=?", (schedule_id,)).fetchone()
    if not row:
        abort(404)
    try:
        S.update_schedule(db, schedule_id, _schedule_form_data(), current_user_id())
        msg = _push_tpl(db, S.get_form(db, row["form_id"]))
        S.generate_rounds(db)
        msg += _relink(db, row["form_id"])
        _resync_spans(db, row["form_id"])
        db.commit()
        flash("บันทึกรอบตรวจแล้ว" + msg, "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("forms.form_detail", form_id=row["form_id"]) + "#schedules")


@bp.route("/schedules/<int:schedule_id>/delete", methods=["POST"])
@PM.require_form("schedule", by_schedule=True)
def schedule_delete(schedule_id):
    db = get_db()
    row = db.execute("SELECT form_id FROM cs_schedules WHERE id=?", (schedule_id,)).fetchone()
    if not row:
        abort(404)
    S.delete_schedule(db, schedule_id, current_user_id())
    msg = _push_tpl(db, S.get_form(db, row["form_id"]))
    msg += _relink(db, row["form_id"])
    _resync_spans(db, row["form_id"])
    db.commit()
    flash("ปิดรอบตรวจแล้ว (ผลตรวจที่ส่งแล้วยังอยู่ครบ)" + msg, "ok")
    return redirect(url_for("forms.form_detail", form_id=row["form_id"]) + "#schedules")


# ───────────────────────── rounds overview ─────────────────────────

@bp.route("/rounds")
@require_role(*ALL_ROLES)
def rounds():
    db = get_db()
    try:
        day = date.fromisoformat(request.args.get("date") or date.today().isoformat())
    except ValueError:
        day = date.today()
    factory_id = _factory_arg()
    status = request.args.get("status", "")
    S.generate_rounds(db)
    S.refresh_round_statuses(db)
    db.commit()
    data = S.rounds_overview(db, day, factory_id)
    items = [i for i in data["items"] if not status or i["status"] == status]
    GRP_KEYS = {"done": ("done_on_time", "done_late"), "wait": ("pending", "in_progress"), "late": ("overdue",),
                "ret": ("returned",), "miss": ("missed",), "down": ("skipped",)}
    items = data["items"]                           # v0.61 กรองฝั่งหน้าเว็บ (สลับตัวกรองได้ทันที) — status ใช้เลือกตัวกรองเริ่มต้น
    return render_template("forms/rounds.html", data=data, items=items, day=day, factory_id=factory_id, GRP_KEYS=GRP_KEYS,
                           status=status, now=datetime.now(), next_day=day + timedelta(days=1),
                           prev_day=day - timedelta(days=1), factories=M.list_factories(db))


@bp.route("/api/rounds")
@require_role(*ALL_ROLES)
def api_rounds():
    db = get_db()
    try:
        day = date.fromisoformat(request.args.get("date") or date.today().isoformat())
    except ValueError:
        return jsonify({"error": "รูปแบบวันที่ต้องเป็น YYYY-MM-DD"}), 400
    return jsonify(S.rounds_overview(db, day, _factory_arg()))
