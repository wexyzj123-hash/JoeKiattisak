"""ecs/views/admin_cmms.py — แยกจาก admin.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

from flask import (flash, redirect, render_template, request, url_for)
from ..db import get_db
from ..security import current_user_id, require_role
from ..services import ValidationError

from .admin import bp, _flash_errors  # noqa: E402


# ───────────────────────── ใบแจ้งซ่อม UT-CMMS จาก NG ─────────────────────────

@bp.route("/admin/cmms-wo", methods=["GET", "POST"])
@require_role("admin")
def cmms_wo_settings():
    from flask import current_app

    from .. import cmms_wo as W
    db = get_db()
    if request.method == "POST":
        try:
            W.save_settings(db, request.form.to_dict(), current_user_id())
            db.commit()
            flash("บันทึกการเชื่อมใบแจ้งซ่อม UT-CMMS แล้ว", "ok")
            return redirect(url_for("admin.cmms_wo_settings"))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
    if request.args.get("sync") == "1":
        from ..jobs import sync_cmms
        res = sync_cmms(current_app) or {}
        flash(f"ดึงสถานะจาก UT-CMMS แล้ว: ตรวจ {res.get('checked', 0)} · เปลี่ยน {res.get('changed', 0)} · ปิดงาน {res.get('closed', 0)}", "ok")
        return redirect(url_for("admin.cmms_wo_settings"))
    return render_template("admin/cmms_wo.html", cfg=W.get_settings(db), info=W.status_info(db, current_app.config),
                           links=W.recent_links(db), MODE_TH=W.MODE_TH)


# ───────────────────────── แผน TPM ของ UT-CMMS ─────────────────────────

@bp.route("/admin/cmms-tpm", methods=["GET", "POST"])
@require_role("admin")
def cmms_tpm_settings():
    from flask import current_app

    from .. import cmms_tpm as TPM
    db = get_db()
    if request.method == "POST":
        try:
            if request.form.get("action") == "auto_link":
                res = TPM.auto_link(db, current_app.config, current_user_id())
                db.commit()
                flash(f"เชื่อมอัตโนมัติแล้ว {res['links']} แผน ใน {res['forms']} แบบฟอร์ม — ตรวจทานได้ที่แบบฟอร์ม › แท็บแผน TPM", "ok")
            else:
                TPM.save_settings(db, request.form.to_dict(), current_user_id())
                db.commit()
                flash("บันทึกการเชื่อมแผน TPM แล้ว", "ok")
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
        return redirect(url_for("admin.cmms_tpm_settings"))
    if request.args.get("sync") == "1":
        n = TPM.safe(TPM.refresh_states, db, current_app.config)
        flash(f"ดึงสถานะยืนยันจาก UT-CMMS แล้ว — อัปเดต {n} รายการ", "ok")
        return redirect(url_for("admin.cmms_tpm_settings"))
    available = TPM.available(current_app.config)
    ov, err = {"forms": [], "n_links": 0, "n_suggest": 0}, ""
    try:
        ov = TPM.overview(db, current_app.config)
    except Exception as exc:                            # noqa: BLE001
        err = str(exc)
    return render_template("admin/cmms_tpm.html", cfg=TPM.get_settings(db), available=available, ov=ov, err=err,
                           syncs=TPM.recent_syncs(db))


# ───────────────────────── สถานะช่าง UT-CMMS ─────────────────────────

@bp.route("/admin/cmms-status", methods=["GET", "POST"])
@require_role("admin")
def cmms_status_settings():
    from flask import current_app

    from .. import cmms_status as ST
    db = get_db()
    if request.method == "POST":
        ST.save_settings(db, request.form.to_dict(), current_user_id())
        db.commit()
        flash("บันทึกการเชื่อมสถานะช่างแล้ว", "ok")
        return redirect(url_for("admin.cmms_status_settings"))
    return render_template("admin/cmms_status.html", cfg=ST.get_settings(db), available=ST.available(current_app.config),
                           rows=ST.recent(db), STATE_TH=ST.STATE_TH, AFTER_TH=ST.AFTER_TH,
                           unlinked=ST.unlinked_inspectors(db))
