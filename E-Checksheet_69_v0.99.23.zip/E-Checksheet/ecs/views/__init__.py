"""ecs/views — หน้าเว็บและ API แยกตามส่วนงาน"""
from __future__ import annotations

from datetime import datetime

from flask import jsonify, render_template

from ..security import wants_json
from ..services import parse_ts


def register(app) -> None:
    from .admin import bp as admin_bp
    from .auth import bp as auth_bp
    from .dash import bp as dash_bp
    from .work import bp as work_bp
    from .rep import bp as rep_bp
    from .src import bp as src_bp
    from .forms import bp as forms_bp
    from .mobile import bp as mobile_bp
    from .review import bp as review_bp
    from .route import bp as route_bp
    from .sign import bp as sign_bp
    from .team import bp as team_bp
    from .energy import bp as energy_bp
    from .energy_m import bp as energy_m_bp
    from .energy_cost import bp as energy_cost_bp
    from .energy_live import bp as energy_live_bp
    from .energy_summary import bp as energy_sum_bp
    from .energy_src import bp as energy_src_bp
    from .energy_power import bp as energy_pw_bp
    for bp in (auth_bp, forms_bp, admin_bp, mobile_bp, review_bp, dash_bp, work_bp, rep_bp, src_bp, route_bp, sign_bp, team_bp, energy_bp, energy_m_bp, energy_cost_bp, energy_src_bp, energy_live_bp, energy_sum_bp, energy_pw_bp):
        app.register_blueprint(bp)

    from markupsafe import Markup, escape

    from .. import terms as TR

    @app.template_global()
    def term(group: str, key, with_icon: bool = True):
        """v0.50 ภาษากลาง: <span class="badge …">ไอคอน คำ</span> — ใช้คำ/สีเดียวกันทุกหน้า"""
        v = TR.ALL.get(group, {}).get(key or "")
        if not v:
            return Markup(f'<span class="badge b-none">{escape(key or "–")}</span>')
        return Markup(f'<span class="badge {v[1]}" title="{escape(v[3])}">{escape(v[2]) + " " if with_icon else ""}{escape(v[0])}</span>')

    @app.template_global()
    def term_label(group: str, key) -> str:
        return TR.label(group, key)

    @app.template_global()
    def terms_js():
        return TR.js()

    @app.template_filter("thdt")
    def _thdt(value, fmt="%d/%m/%Y %H:%M"):
        dt = parse_ts(value) if isinstance(value, str) else value
        return dt.strftime(fmt) if isinstance(dt, datetime) else "–"

    @app.template_filter("todt_d")
    def _todt_d(value):
        from datetime import date as _date
        return _date.fromisoformat(str(value)[:10])

    @app.template_filter("todt")
    def _todt(value):
        return parse_ts(value) if isinstance(value, str) else value

    @app.template_filter("tdur")
    def _tdur(td):
        """ระยะเวลาแบบสั้น: 45 นาที · 2 ชม. 10 น. · 3 วัน"""
        try:
            m = max(0, int(td.total_seconds() // 60))
        except AttributeError:
            return ""
        if m >= 2880:
            return f"{m // 1440} วัน"
        if m < 60:
            return f"{m} นาที"
        return f"{m // 60} ชม." + (f" {m % 60} น." if m % 60 else "")

    TH_MONTHS = ("ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.")

    @app.template_filter("fromjson")
    def _fromjson(value):
        import json as _json
        try:
            v = _json.loads(value or "[]")
            return v if isinstance(v, list) else []
        except ValueError:
            return []

    @app.template_filter("thdate")
    def _thdate(value):
        """23 ก.ย. 2569 (พ.ศ.)"""
        from datetime import date as _date
        d = parse_ts(value) if isinstance(value, str) and len(value) > 10 else value
        if isinstance(value, str) and len(value) == 10:
            try:
                d = _date.fromisoformat(value)
            except ValueError:
                return value
        if not hasattr(d, "month"):
            return "–"
        return f"{d.day} {TH_MONTHS[d.month - 1]} {d.year + 543}"

    @app.template_filter("mmss")
    def _mmss(seconds):
        if not seconds:
            return "–"
        m, s = divmod(int(seconds), 60)
        return f"{m}:{s:02d}"

    @app.template_filter("dict_merge")
    def _dict_merge(base, other):
        return {k: v for k, v in {**base, **other}.items() if v not in (None, "")}

    @app.template_filter("dur")
    def _dur(seconds):
        if seconds is None:
            return "–"
        m, s = divmod(int(seconds), 60)
        h, m = divmod(m, 60)
        return f"{h} ชม. {m} นาที" if h else (f"{m} นาที {s} วิ" if m else f"{s} วินาที")

    def _err(code, message):
        if wants_json():
            return jsonify({"error": message}), code
        return render_template("error.html", code=code, message=message), code

    @app.errorhandler(400)
    def _400(err):
        return _err(400, getattr(err, "description", None) or "คำขอไม่ถูกต้อง")

    @app.errorhandler(404)
    def _404(_exc):
        return _err(404, "ไม่พบข้อมูลที่ต้องการ")

    @app.errorhandler(413)
    def _413(_exc):
        return _err(413, "ไฟล์ที่ส่งมีขนาดใหญ่เกินไป")
