"""ecs/views/energy_import.py — แยกจาก energy.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

import json
import os
import re
import secrets
from flask import (Response, current_app, flash, redirect, render_template, request, url_for)
from .. import energy as EN
from .. import energy_field as EF
from .. import energy_ops as OPS
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import ValidationError, now_dt

from .energy import bp, ENTRY_ROLES, _ctx, _facs_scope, _is_lead, _kind  # noqa: E402


# ───────────────────────── นำเข้า Excel ─────────────────────────

def _tmp_dir() -> str:
    d = os.path.join(os.path.dirname(current_app.config["DATABASE"]), "energy_tmp")
    os.makedirs(d, exist_ok=True)
    return d


def _load_tmp(token: str):
    if not re.fullmatch(r"[0-9a-f]{24}", token or ""):
        return None, None
    path = os.path.join(_tmp_dir(), f"{token}.json")
    if not os.path.exists(path):
        return None, path
    with open(path, encoding="utf-8") as fh:
        return json.load(fh), path


def _save_tmp(data) -> str:
    token = secrets.token_hex(12)
    with open(os.path.join(_tmp_dir(), f"{token}.json"), "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, default=str)
    return token


@bp.route("/import", methods=["GET", "POST"])
@require_role(*ENTRY_ROLES)
def import_page():
    db = get_db()
    facs = _facs_scope(db)
    sc = EF.user_scope(db, current_user_id())
    tab = "registry" if request.args.get("tab") == "registry" else "readings"
    pv = None
    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename:
            flash("เลือกไฟล์ Excel ก่อน", "error")
            return redirect(url_for("energy.import_page"))
        raw = f.read()
        if len(raw) > 30 * 1024 * 1024:
            flash("ไฟล์ใหญ่เกิน 30 MB", "error")
            return redirect(url_for("energy.import_page"))
        g = EN.guess(f.filename, facs)
        fid = sc["factory_id"] or request.form.get("factory", type=int) or g["factory_id"]
        kind = _kind(request.form.get("kind")) or g["kind"]
        year = request.form.get("year", type=int) or now_dt().year
        try:
            parsed = EN.parse_file(raw, f.filename, year)
        except ValidationError as exc:
            flash(exc.errors[0], "error")
            return redirect(url_for("energy.import_page"))
        from .. import energy_register as ER
        det = ER.detect(parsed, db)                       # v0.90 ตรงทะเบียนมาตรฐาน → เลือกโรงงาน/ประเภทให้เอง
        if det:
            if not request.form.get("kind"):
                kind = det["kind"]
            if not sc["factory_id"] and not request.form.get("factory", type=int):
                fid = det["factory_id"]
        token = _save_tmp({"parsed": parsed, "filename": f.filename, "year": year})
        pv = {"token": token, "filename": f.filename, "fid": fid, "kind": kind, "year": year, "months": parsed["months"], "det": det,
              "skipped": parsed["skipped"], "future": parsed.get("future", 0), **EN.preview(db, parsed, fid, kind)}
    hist = EN.imports(db)
    if sc["factory_id"]:
        hist = [h for h in hist if h["factory_id"] == sc["factory_id"]]
    return render_template("energy/import.html", **_ctx(pv=pv, hist=hist, year=now_dt().year, tab=tab, facs_scope=facs,
                                                      uid=current_user_id(), is_lead=_is_lead()))


@bp.route("/import/confirm", methods=["POST"])
@require_role(*ENTRY_ROLES)
def import_confirm():
    db = get_db()
    blob, path = _load_tmp(request.form.get("token", ""))
    if not blob:
        flash("หมดอายุแล้ว — อัปโหลดไฟล์ใหม่" if path else "รายการนำเข้าไม่ถูกต้อง", "error")
        return redirect(url_for("energy.import_page"))
    sc = EF.user_scope(db, current_user_id())
    fid = sc["factory_id"] or request.form.get("factory", type=int)
    kind = _kind(request.form.get("kind"))
    if not kind:
        flash("เลือกประเภทมิเตอร์", "error")
        return redirect(url_for("energy.import_page"))
    sel = [int(x) for x in request.form.getlist("sel") if x.isdigit()] if request.form.get("sel_present") else None
    edits = {}
    for i, m in enumerate(blob["parsed"]["meters"]):
        e = {}
        for fld, src in (("code", "code"), ("name", "name"), ("grp", "grp")):
            v = request.form.get(f"{fld}_{i}")
            if v is not None and v.strip() != (m[src] or "").strip():
                e[fld] = v.strip()
        mv = request.form.get(f"main_{i}")
        if mv is not None and mv != request.form.get(f"main0_{i}"):
            e["is_main"] = mv
        if e:
            edits[str(i)] = e
    try:
        res = EN.commit(db, blob["parsed"], fid, kind, blob["year"], blob["filename"], current_user_id(),
                        overwrite=request.form.get("overwrite") == "1", select=sel, edits=edits, mode=request.form.get("mode") or "all")
        db.commit()
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return redirect(url_for("energy.import_page"))
    os.remove(path)
    flash(f"นำเข้าแล้ว: มิเตอร์ {res['meters']} (ใหม่ {res['new_meters']}) · ค่าอ่านใหม่ {res['readings']} · ทับค่าเดิม {res['changed']}"
          + (f" · ข้าม {res['skipped_meters']} มิเตอร์ที่ยังไม่มีในระบบ" if res["skipped_meters"] else ""), "ok")
    return redirect(url_for("energy.import_page"))


@bp.route("/import/<int:iid>/undo", methods=["POST"])
@require_role(*ENTRY_ROLES)
def import_undo(iid):
    db = get_db()
    imp = db.execute("SELECT * FROM en_imports WHERE id=?", (iid,)).fetchone()
    if not imp or not (_is_lead() or imp["user_id"] == current_user_id()):
        flash("ยกเลิกได้เฉพาะผู้ที่นำเข้าเอง หรือหัวหน้างาน/ผู้ดูแล", "error")
        return redirect(url_for("energy.import_page"))
    try:
        r = EN.undo_import(db, iid, current_user_id())
        db.commit()
        flash(f"ยกเลิกการนำเข้าแล้ว: ลบค่า {r['removed']} · คืนค่าเดิม {r['restored']} · ลบมิเตอร์ {r['meters_removed']}"
              + (f" · คงไว้ {r['kept']} ค่า (ถูกแก้หลังนำเข้า)" if r["kept"] else ""), "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy.import_page"))


# ───────────────────────── ทะเบียนมิเตอร์: ส่งออก / นำเข้า Excel ─────────────────────────

@bp.route("/meters.xlsx")
@require_role(*ALL_ROLES)
def meters_xlsx():
    from .. import energy_registry as REG
    db = get_db()
    sc = EF.user_scope(db, current_user_id())
    fid = sc["factory_id"] or request.args.get("factory", type=int) or None
    data = REG.export_xlsx(db, fid, _kind(request.args.get("kind")))
    fn = f"energy_meters{'_F' + str(fid) if fid else ''}_{now_dt():%Y%m%d}.xlsx"
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{fn}"'})


@bp.route("/import/registry", methods=["POST"])
@require_role(*ENTRY_ROLES)
def import_registry():
    from .. import energy_registry as REG
    db = get_db()
    f = request.files.get("file")
    if not f or not f.filename:
        flash("เลือกไฟล์ทะเบียนมิเตอร์ (.xlsx)", "error")
        return redirect(url_for("energy.import_page", tab="registry"))
    try:
        rows = REG.parse(f.read(), f.filename)
        plan = REG.plan(db, rows, current_user_id())
    except ValidationError as exc:
        flash(exc.errors[0], "error")
        return redirect(url_for("energy.import_page", tab="registry"))
    token = _save_tmp({"rows": [{k: v for k, v in r.items()} for r in rows], "filename": f.filename})
    return render_template("energy/import.html", **_ctx(pv=None, hist=EN.imports(db), year=now_dt().year, tab="registry",
                                                      facs_scope=_facs_scope(db), rp=plan, rtoken=token, rfile=f.filename,
                                                      uid=current_user_id(), is_lead=_is_lead()))


@bp.route("/import/registry/confirm", methods=["POST"])
@require_role(*ENTRY_ROLES)
def import_registry_confirm():
    from .. import energy_registry as REG
    db = get_db()
    blob, path = _load_tmp(request.form.get("token", ""))
    if not blob:
        flash("หมดอายุแล้ว — อัปโหลดไฟล์ใหม่", "error")
        return redirect(url_for("energy.import_page", tab="registry"))
    try:
        r = REG.apply(db, blob["rows"], current_user_id())
        db.commit()
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return redirect(url_for("energy.import_page", tab="registry"))
    os.remove(path)
    flash(f"อัปเดตทะเบียนมิเตอร์แล้ว: เพิ่ม {r['new']} · แก้ {r['update']} · ลบ {r['delete']} · ปิดใช้งาน {r['deactivate']}", "ok")
    return redirect(url_for("energy.meters"))


# ───────────────────────── แก้ค่าอ่าน ─────────────────────────

@bp.route("/meters/<int:mid>/fix", methods=["POST"])
@require_role(*ENTRY_ROLES)
def meter_fix(mid):
    db = get_db()
    m = EN.meter(db, mid)
    if not m or not EF.can_touch(db, current_user_id(), m):
        return render_template("error.html", code=403, message="ไม่มีสิทธิ์แก้มิเตอร์ของโรงงานนี้"), 403
    if not EF.back_limit_ok(db, current_user_id(), request.form.get("day", "")[:10] or now_dt().date().isoformat(), EN.settings(db)):
        flash(f"แก้ค่าย้อนหลังได้ไม่เกิน {int(EN.settings(db)['tech_back_days'])} วัน — แจ้งหัวหน้างาน", "error")
        return redirect(url_for("energy.meter_detail", mid=mid))
    try:
        r = OPS.correct(db, mid, request.form.get("day", ""), request.form.get("value"), request.form.get("u_fix"),
                        request.form.get("reason", ""), current_user_id())
        db.commit()
        flash("บันทึกการแก้ไขแล้ว" if r["changed"] else "ค่าไม่เปลี่ยน", "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy.meter_detail", mid=mid, days=request.args.get("days") or None))
