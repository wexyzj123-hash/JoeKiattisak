"""ecs/views/forms_templates.py — แยกจาก forms.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

import re
from flask import flash, redirect, request, url_for
from .. import services as S
from ..db import get_db
from ..security import MANAGE_ROLES, current_user_id, require_role

from .forms import bp, _flash_errors, _ids_arg, _load_form  # noqa: E402


# ───────────────────────── แม่แบบ (1 แม่แบบ → หลายเครื่อง) ─────────────────────────

def _tpl_redirect(fid, tab="items"):
    return redirect(url_for("forms.form_detail", form_id=fid) + "#" + tab)


@bp.route("/forms/templates", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_create():
    from .. import formtpl as T
    db = get_db()
    try:
        tid = T.new_template(db, request.form.to_dict(), current_user_id())
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return redirect(url_for("forms.forms"))
    flash("สร้างแม่แบบแล้ว — เพิ่มหัวข้อแล้ว Publish จากนั้นกด 'ใช้กับเครื่องจักร'", "ok")
    return redirect(url_for("forms.builder", form_id=tid))


@bp.route("/forms/<int:form_id>/make-template", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_make(form_id):
    from .. import formtpl as T
    db = get_db()
    _load_form(db, form_id)
    try:
        tid = T.make_template(db, form_id, current_user_id(), request.form.get("name", ""))
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return _tpl_redirect(form_id, "settings")
    flash("สร้างแม่แบบแล้ว แบบฟอร์มนี้เป็นเครื่องแรกของแม่แบบ — กด 'ใช้กับเครื่องจักร' เพื่อเพิ่มเครื่องอื่น", "ok")
    return _tpl_redirect(tid, "children")


@bp.route("/forms/<int:form_id>/apply", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_apply(form_id):
    from .. import formtpl as T
    db = get_db()
    eq_ids = _ids_arg(request.form.getlist("equipment"))
    schedule = None
    if request.form.get("sched_times", "").strip():
        schedule = {"freq_type": request.form.get("sched_freq", "daily"), "times": request.form.get("sched_times"),
                    "window_min": request.form.get("sched_window") or 240}
    try:
        res = T.apply_to_equipment(db, form_id, eq_ids, current_user_id(), schedule)
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return _tpl_redirect(form_id, "children")
    msg = f"สร้างแบบฟอร์มให้ {len(res['created'])} เครื่อง"
    if res["skipped"]:
        msg += f" · ข้าม {len(res['skipped'])} เครื่องที่มีอยู่แล้ว"
    flash(msg, "ok")
    return _tpl_redirect(form_id, "children")


@bp.route("/forms/<int:form_id>/link", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_link(form_id):
    from .. import formtpl as T
    db = get_db()
    try:
        n = T.link_forms(db, form_id, _ids_arg(request.form.getlist("forms")), current_user_id())
        db.commit()
        flash(f"ผูกแบบฟอร์มเดิม {n} ฉบับเข้าแม่แบบแล้ว (หัวข้อชื่อเดียวกันใช้ประวัติเดิมต่อ)", "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return _tpl_redirect(form_id, "children")


@bp.route("/forms/<int:form_id>/detach", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_detach(form_id):
    from .. import formtpl as T
    db = get_db()
    form = _load_form(db, form_id)
    tpl_id = form.get("template_id")
    T.detach(db, form_id, current_user_id())
    db.commit()
    flash("แยกออกจากแม่แบบแล้ว — แบบฟอร์มนี้แก้หัวข้อเองได้ และจะไม่เปลี่ยนตามแม่แบบอีก", "ok")
    return _tpl_redirect(tpl_id if request.form.get("back") == "tpl" and tpl_id else form_id,
                         "children" if request.form.get("back") == "tpl" else "settings")


@bp.route("/forms/<int:form_id>/overrides", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_overrides(form_id):
    from .. import formtpl as T
    db = get_db()
    _load_form(db, form_id)
    data: dict = {}
    for k, v in request.form.items():
        m = re.match(r"^ov\[(.+?)\]\[(\w+)\]$", k)
        if m:
            data.setdefault(m.group(1), {})[m.group(2)] = v
    try:
        n = T.save_overrides(db, form_id, data, current_user_id())
        db.commit()
        flash(f"บันทึกเกณฑ์เฉพาะเครื่องแล้ว ({n} หัวข้อ) — ออกเวอร์ชันใหม่ให้เครื่องนี้แล้ว", "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return _tpl_redirect(form_id, "items")


# ───────────────────────── v0.99.5 ปรับหัวข้อเฉพาะเครื่อง (แม่แบบไม่เปลี่ยน) ─────────────────────────

def _local_raw(f) -> dict:
    """ฟอร์มหัวข้อเฉพาะเครื่อง → dict สำหรับ normalize_item (ช่องติ๊กที่ไม่ส่งมา = ปิด)"""
    raw = {k: f.get(k, "") for k in ("section", "name", "item_type", "unit", "min_value", "max_value",
                                       "warn_low", "warn_high", "counter_max_step", "guide")}
    for k in ("required", "critical", "photo_on_ng", "photo_required"):
        raw[k] = "1" if f.get(k) else "0"
    opts = []
    for line in (f.get("options") or "").splitlines():
        line = line.strip()
        if not line:
            continue
        ng = bool(re.search(r"\(\s*NG\s*\)\s*$", line, re.I))
        opts.append({"label": re.sub(r"\s*\(\s*NG\s*\)\s*$", "", line, flags=re.I), "ng": 1 if ng else 0})
    raw["options"] = opts
    return raw


@bp.route("/forms/<int:form_id>/local/exclude", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_local_exclude(form_id):
    """เลือกหัวข้อของแม่แบบที่ใช้กับเครื่องนี้ (use=รหัสหัวข้อที่ใช้) หรือ restore=รหัสหัวข้อ เพื่อนำกลับมาใช้ 1 หัวข้อ"""
    from .. import formtpl as T
    db = get_db()
    form = _load_form(db, form_id)
    tpl = T.get_template(db, form)
    if not tpl or not tpl["current_version_id"]:
        flash("แบบฟอร์มนี้ไม่ได้ใช้แม่แบบ", "error")
        return _tpl_redirect(form_id, "items")
    t_keys = [i["item_key"] for i in S.get_items(db, tpl["current_version_id"])]
    if request.form.get("restore"):
        cur = {k for k, o in T.overrides(db, form_id).items() if o.get("excluded")}
        want = cur - {request.form["restore"]}
    else:
        use = set(request.form.getlist("use"))
        want = {k for k in t_keys if k not in use}
    try:
        res = T.set_excluded(db, form_id, want, current_user_id())
        db.commit()
        if res["changed"]:
            flash(f"บันทึกแล้ว — เครื่องนี้ใช้ {len(t_keys) - res['excluded']} จาก {len(t_keys)} หัวข้อของแม่แบบ "
                  "(ออกเวอร์ชันใหม่ให้เครื่องนี้เท่านั้น แม่แบบและเครื่องอื่นไม่เปลี่ยน)", "ok")
        else:
            flash("ไม่มีการเปลี่ยนแปลง", "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return _tpl_redirect(form_id, "items")


@bp.route("/forms/<int:form_id>/local/items", methods=["POST"])
@require_role(*MANAGE_ROLES)
def template_local_item(form_id):
    from .. import formtpl as T
    db = get_db()
    _load_form(db, form_id)
    key = request.form.get("item_key", "").strip()
    try:
        if request.form.get("action") == "delete":
            T.delete_local_item(db, form_id, key, current_user_id())
            msg = "ลบหัวข้อเฉพาะเครื่องแล้ว — ผลตรวจเก่าของหัวข้อนี้ยังอยู่ในประวัติ"
        else:
            T.save_local_item(db, form_id, _local_raw(request.form), current_user_id(), key)
            msg = ("แก้" if key else "เพิ่ม") + "หัวข้อเฉพาะเครื่องนี้แล้ว (แม่แบบและเครื่องอื่นไม่เปลี่ยน)"
        db.commit()
        flash(msg, "ok")
    except S.ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return _tpl_redirect(form_id, "items")
