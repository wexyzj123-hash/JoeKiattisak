"""ecs/views/sign.py — v0.24 ลายเซ็นของฉัน + ลงนามหน่วยงาน (ENVIRONMENT / SAFETY) ในระบบ"""
from __future__ import annotations

import base64
from datetime import date, timedelta

from flask import Blueprint, Response, flash, redirect, render_template, request, session, url_for

from .. import masterdata as M
from .. import services as S
from .. import sheet_report as SR
from .. import signoffs as SO
from .. import view_scope as VS
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role, safe_next

bp = Blueprint("sign", __name__)


def _me(db) -> dict:
    r = db.execute("SELECT id, name, role, factory_id, COALESCE(position,'') AS position FROM users WHERE id=?",
                   (current_user_id(),)).fetchone()
    return dict(r) if r else {"id": current_user_id(), "role": session.get("role"), "name": ""}


def _month(v: str | None) -> date:
    try:
        y, m = (int(x) for x in (v or "").split("-"))
        return date(y, m, 1)
    except (TypeError, ValueError):
        return date.today().replace(day=1)


# ───────────────────────── ลายเซ็นของฉัน ─────────────────────────

@bp.route("/account/signature", methods=["GET", "POST"])
@require_role(*ALL_ROLES)
def my_signature():
    db = get_db()
    uid = current_user_id()
    if request.method == "POST":
        try:
            if request.form.get("action") == "delete":
                SO.delete_signature(db, uid)
                db.commit()
                flash("ลบลายเซ็นแล้ว — เอกสารจะแสดงเป็นชื่อแทน", "success")
            else:
                f = request.files.get("file")
                raw = f.read() if f and f.filename else b""
                if not raw:
                    data = request.form.get("drawn") or ""
                    if data.startswith("data:image/png;base64,"):
                        raw = base64.b64decode(data.split(",", 1)[1], validate=False)
                SO.save_signature(db, uid, raw)
                db.commit()
                flash("บันทึกลายเซ็นแล้ว — ใช้ในใบบันทึกรายเดือนทันที", "success")
        except (SO.SignError, ValueError) as e:
            flash(str(e), "error")
        return redirect(safe_next(request.form.get("next"), url_for("sign.my_signature")))
    has = bool(SO.signature_png(db, uid))
    return render_template("sign/signature.html", has=has, groups=[SO.GROUPS[g] for g in sorted(SO.user_groups(db, uid))],
                           next=request.args.get("next") or "")


@bp.route("/account/signature.png")
@require_role(*ALL_ROLES)
def my_signature_png():
    uid = request.args.get("user", type=int) or current_user_id()
    if uid != current_user_id() and session.get("role") != "admin":
        uid = current_user_id()
    png = SO.signature_png(get_db(), uid)
    if not png:                                              # ยังไม่มีลายเซ็น → รูปว่าง (โปร่งใส 1×1)
        png = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==")
    return Response(png, mimetype="image/png", headers={"Cache-Control": "no-store"})


# ───────────────────────── ลงนามหน่วยงาน ─────────────────────────

@bp.route("/signoffs")
@require_role(*ALL_ROLES)
def signoffs():
    db = get_db()
    me = _me(db)
    month = _month(request.args.get("month"))
    mine = request.args.get("mine", "1") == "1"
    groups = SO.user_groups(db, me["id"])
    today = S.now_dt().date()
    forms = []
    n_can = 0
    fac = me.get("factory_id") if mine and not groups else None
    for form, al in SO.form_slots(db, month, fac):
        for sl in al:
            sl["why"] = SO.check(db, sl, me, al, today, groups, form)
            sl["can"] = not sl["why"]
            sl["mine_group"] = bool(groups & set(sl["groups"])) or me["position"] in sl["positions"]
        show = [sl for sl in al if (not mine or sl["mine_group"]) and (not sl["na"] or sl["rec"])]
        if not show:
            continue
        n_can += sum(1 for sl in show if sl["can"])
        need = [sl for sl in al if not sl["na"]]
        alld = sorted({d for sl in al for d in sl.get("days") or []})
        for sl in show:
            sl["days_th"] = SO.days_text(month, sl.get("days"))
        forms.append({"form": form, "slots": show, "done": sum(1 for sl in need if sl["rec"]), "total": len(need),
                      "can": sum(1 for sl in show if sl["can"]), "n_days": len(alld), "days_th": SO.days_text(month, alld),
                      "last_day": alld[-1] if alld else None})
    forms.sort(key=lambda x: (-x["can"], x["form"]["code"] or ""))
    factories = sorted({(x["form"].get("factory_id"), x["form"].get("factory_name") or "-") for x in forms}, key=lambda t: t[1])
    prev = (month - timedelta(days=1)).replace(day=1)
    nxt = (month.replace(day=28) + timedelta(days=4)).replace(day=1)
    ctx = {"forms": forms, "month": month, "month_th": SR.th_month(month),
           "prev": prev, "next_m": nxt if nxt <= today.replace(day=1) else None, "mine": mine, "groups": groups,
           "GROUPS": SO.GROUPS, "POS": SO.POSITIONS, "n_can": n_can, "factories": factories, "has_sig": bool(SO.signature_png(db, me["id"])), "me": me}
    if me["role"] == "admin":
        ctx["roles"] = SO.get_roles(db)
        ctx["users"] = [u for u in M.list_users(db, include_inactive=False)]
    return render_template("sign/signoffs.html", **ctx)


@bp.route("/signoffs/sign", methods=["POST"])
@require_role(*ALL_ROLES)
def signoff_sign():
    db = get_db()
    me = _me(db)
    month = _month(request.form.get("month"))
    items = request.form.getlist("slot")                   # "form_id|slot"
    ok, errs = 0, []
    for it in items[:500]:
        fid, _, slot = it.partition("|")
        form = S.get_form(db, int(fid)) if fid.isdigit() and VS.can_see_form(int(fid)) else None
        if not form:
            continue
        try:
            SO.sign(db, form, month, slot, me)
            ok += 1
        except SO.SignError as e:
            errs.append(f"{form['code'] or form['name']}: {e}")
    db.commit()
    if ok:
        flash(f"ยืนยันลงนามแล้ว {ok} ช่อง", "success")
    for e in errs[:5]:
        flash(e, "error")
    return redirect(safe_next(request.form.get("next"), url_for("sign.signoffs", month=month.strftime("%Y-%m"))))


@bp.route("/signoffs/cancel", methods=["POST"])
@require_role(*ALL_ROLES)
def signoff_cancel():
    db = get_db()
    me = _me(db)
    month = _month(request.form.get("month"))
    fid, _, slot = (request.form.get("cancel") or "").partition("|")         # ปุ่มยกเลิกในรายการ: "form_id|slot"
    form = S.get_form(db, int(fid)) if fid.isdigit() and VS.can_see_form(int(fid)) else None
    try:
        if not form:
            raise SO.SignError("ไม่พบแบบฟอร์ม")
        SO.unsign(db, form, month, slot, me)
        db.commit()
        flash("ยกเลิกการลงนามแล้ว", "success")
    except SO.SignError as e:
        flash(str(e), "error")
    return redirect(safe_next(request.form.get("next"), url_for("sign.signoffs", month=month.strftime("%Y-%m"))))


@bp.route("/signoffs/roles", methods=["POST"])
@require_role("admin")
def signoff_roles():
    db = get_db()
    SO.save_roles(db, {g: request.form.getlist(g) for g in SO.GROUPS}, current_user_id())
    pos = {int(k[4:]): v for k, v in request.form.items() if k.startswith("pos_") and k[4:].isdigit()}
    SO.save_positions(db, pos, current_user_id())
    for uid in pos:                                           # v0.26 สิทธิ์อนุมัติแบบกลุ่ม (ติ๊กในตารางเดียวกัน)
        ca = 1 if request.form.get(f"ca_{uid}") else 0
        r = db.execute("SELECT role, COALESCE(can_approve,0) FROM users WHERE id=?", (uid,)).fetchone()
        if r and r[0] not in ("admin", "supervisor") and r[1] != ca:
            db.execute("UPDATE users SET can_approve=? WHERE id=?", (ca, uid))
            S.audit(db, current_user_id(), "can_approve", "users", uid, before=r[1], after=ca)
        M.set_restrict_view(db, uid, request.form.get(f"rv_{uid}"), current_user_id())   # v0.29 จำกัดการดู
    db.commit()
    flash("บันทึกตำแหน่ง / ผู้มีสิทธิ์ลงนามแล้ว", "success")
    return redirect(url_for("sign.signoffs", month=request.form.get("month") or None) + "#roles")
