"""ecs/views/admin_ops.py — แยกจาก admin.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

import os
import re
from flask import (abort, current_app, flash, redirect, render_template, request, send_from_directory, url_for)
from .. import downtime as DT
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, MANAGE_ROLES, current_user_id, require_role, safe_next
from ..services import ValidationError

from .admin import bp, _int  # noqa: E402


# ───────────────────────── เครื่องหยุด / ซ่อม ─────────────────────────

@bp.route("/equipment/<int:equipment_id>/down", methods=["POST"])
@require_role(*MANAGE_ROLES)
def equipment_down(equipment_id):
    db = get_db()
    f = request.form
    try:
        if f.get("start_at") or f.get("end_at"):             # v0.58 กรอกวันหยุดเครื่องย้อนหลัง
            res = DT.record_down(db, equipment_id, current_user_id(), f.get("reason", ""), f.get("category", "repair"),
                                 f.get("start_at"), f.get("end_at") or None, f.get("note", ""))
        else:
            res = DT.set_down(db, equipment_id, current_user_id(), f.get("reason", ""), f.get("category", "repair"),
                              f.get("expected_end") or None)
        db.commit()
        flash(f"{'บันทึกช่วงหยุดย้อนหลังของ' if f.get('start_at') else 'แจ้ง'} {res['code']} หยุด/ซ่อมแล้ว — งดรอบตรวจ {res['skipped']} รอบ (ไม่นับขาดตรวจ)"
              + (f" · ทับแทนช่วงเดิม {res['replaced']} ช่วง" if res.get("replaced") else ""), "ok")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    return redirect(safe_next(request.form.get("back"), url_for("admin.equipment_detail", equipment_id=equipment_id)))


@bp.route("/equipment/<int:equipment_id>/running", methods=["POST"])
@require_role(*MANAGE_ROLES)
def equipment_running(equipment_id):
    db = get_db()
    try:
        res = DT.set_running_at(db, equipment_id, current_user_id(), request.form.get("at") or None, request.form.get("note", ""))
        db.commit()
        flash(f"{res['code']} กลับมาใช้งานแล้ว" + (f" ตั้งแต่ {res['at'][8:10]}/{res['at'][5:7]} {res['at'][11:16]}" if res.get("at") else "")
              + f" — เปิดรอบตรวจคืน {res['restored']} รอบ", "ok")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    return redirect(safe_next(request.form.get("back"), url_for("admin.equipment_detail", equipment_id=equipment_id)))


@bp.route("/equipment/down")
@require_role(*ALL_ROLES)
def equipment_down_list():
    db = get_db()
    return render_template("admin/downtime.html", items=DT.down_list(db, _int(request.args.get("factory"))),
                           history=DT.history(db, None, 100), factories=M.list_factories(db),
                           factory_id=_int(request.args.get("factory")), DT_CATS=DT.CATEGORIES,
                           equipment=M.list_equipment(db), stale_n=len(DT.stale_downtimes(db)))


@bp.route("/equipment/down/fix", methods=["GET", "POST"])
@require_role("admin", "supervisor")
def equipment_down_fix():
    """v0.57 แก้ข้อมูลเก่า: มีผลตรวจระหว่างที่ระบบค้างสถานะหยุด → เดินเครื่องตั้งแต่เริ่มกะของผู้ตรวจ"""
    db = get_db()
    if request.method == "POST":
        ids = [int(x) for x in request.form.getlist("id") if x.isdigit()]
        if not ids:
            flash("เลือกรายการที่จะแก้อย่างน้อย 1 รายการ", "error")
        else:
            res = DT.fix_stale_downtimes(db, current_user_id(), ids)
            db.commit()
            flash(f"แก้ข้อมูลแล้ว {res['fixed']} ช่วงหยุด · คืนสถานะรอบ {res['rounds']} รอบ · ผูกผลตรวจนอกรอบเข้ารอบ {res['linked']} ใบ", "ok")
        return redirect(url_for("admin.equipment_down_fix"))
    return render_template("admin/downtime_fix.html", rows=DT.stale_downtimes(db))


# ───────────────────────── สถานะระบบ / แบ็กอัป ─────────────────────────

@bp.route("/admin/health")
@require_role("admin")
def health():
    from .. import health as H
    db = get_db()
    info = H.collect(db, current_app)
    return render_template("admin/health.html", h=info, integrity=request.args.get("integrity"))


@bp.route("/admin/health/backup", methods=["POST"])
@require_role("admin")
def health_backup():
    from .. import backup as BK
    res = BK.backup_now(current_app._get_current_object())
    if res.get("ok"):
        flash(f"แบ็กอัปสำเร็จ: {os.path.basename(res['file'])} ({res['size'] // 1024:,} KB · รูปใหม่ {res['photos']} ไฟล์ · {res['seconds']} วินาที)", "ok")
    else:
        flash("แบ็กอัปไม่สำเร็จ: " + str(res.get("error") or "ตรวจไฟล์ไม่ผ่าน"), "error")
    return redirect(url_for("admin.health"))


@bp.route("/admin/health/integrity", methods=["POST"])
@require_role("admin")
def health_integrity():
    from .. import health as H
    res = H.integrity(get_db())
    flash("ตรวจความสมบูรณ์ฐานข้อมูล: " + ("ปกติ (ok)" if res == "ok" else res), "ok" if res == "ok" else "error")
    return redirect(url_for("admin.health"))


@bp.route("/admin/health/download/<name>")
@require_role("admin")
def health_download(name):
    from .. import backup as BK
    if not re.fullmatch(r"echecksheet_\d{8}_\d{6}\.db", name):
        abort(404)
    folder = BK.settings(current_app.config)["dir"]
    if not os.path.exists(os.path.join(folder, name)):
        abort(404)
    return send_from_directory(folder, name, as_attachment=True)
