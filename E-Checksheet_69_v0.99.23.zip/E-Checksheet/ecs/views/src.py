"""ecs/views/src.py — Phase 5: ตั้งค่าแหล่งข้อมูลภายนอก (SCADA SQL / CSV / REST), จับคู่ Tag, ทดสอบ, ดึงข้อมูล"""
from __future__ import annotations

import json

from flask import Blueprint, abort, flash, jsonify, redirect, render_template, request, url_for

from .. import connectors as CN
from .. import tagmatch as TM
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from .. import services as S
from ..services import ValidationError

bp = Blueprint("src", __name__)


def _form_data() -> dict:
    f = request.form
    data = {k: f.get(k) for k in ("name", "kind", "interval_min", "bucket_min", "agg", "ts_shift_min", "keep_days", "late_min")}
    data["active"] = "1" if f.get("active") else "0"
    cr = f.get("confirm_required")                                          # v0.45 · v0.83 0/1/2
    data["confirm_required"] = cr if cr in ("0", "1", "2") else ("1" if cr else "0")
    data["prefill"] = "1" if f.get("prefill") else "0"
    kind = f.get("kind")
    cfg = {}
    for key in CN.DEFAULT_CONFIG.get(kind, {}):
        name = f"cfg.{key}"
        if name not in f:
            continue
        val = f.get(name)
        if key == "headers":
            try:
                val = json.loads(val or "{}")
            except ValueError:
                raise ValidationError("headers ต้องเป็น JSON เช่น {\"Authorization\": \"Bearer ${API_TOKEN}\"}") from None
        elif key == "backfill_days":
            try:
                val = max(0.0, min(float(val or 1), 90.0))
            except ValueError:
                val = 1
        cfg[key] = val
    data["config"] = cfg
    return data


@bp.route("/admin/sources", methods=["GET", "POST"])
@require_role("admin")
def sources():
    db = get_db()
    if request.method == "POST":
        try:
            sid = CN.save_source(db, _form_data(), current_user_id())
            db.commit()
            flash("เพิ่มแหล่งข้อมูลแล้ว — กด “ทดสอบการเชื่อมต่อ” แล้วจับคู่ Tag กับหัวข้อในแบบฟอร์ม", "ok")
            return redirect(url_for("src.source_detail", sid=sid))
        except ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
    from .. import srcmap as SM
    rows = CN.list_sources(db)
    for r in rows:                                        # v0.73 สรุปการลงค่าอัตโนมัติ 3 วันล่าสุด
        try:
            r["health"] = SM.health(db, r["id"])
        except Exception:                                 # noqa: BLE001 — ไม่ให้หน้ารายการล้มเพราะแบบฟอร์มเดียว
            r["health"] = None
    from .. import srcissues as SI
    n_issues = sum(1 for r in rows if r.get("active") and SI.has_issue(db, r))
    return render_template("admin/sources.html", rows=rows, kinds=CN.KIND_TH, defaults=CN.DEFAULT_CONFIG,
                           aggs=CN.AGG_TH, now=S.now_dt(), n_issues=n_issues)


@bp.route("/admin/sources/<int:sid>", methods=["GET", "POST"])
@require_role("admin")
def source_detail(sid):
    db = get_db()
    src = CN.get_source(db, sid)
    if not src:
        abort(404)
    if request.method == "POST":
        try:
            data = _form_data()
            data["kind"] = src["kind"]
            CN.save_source(db, data, current_user_id(), sid)
            db.commit()
            flash("บันทึกการตั้งค่าแล้ว", "ok")
            new = CN.get_source(db, sid)
            if int(new.get("ts_shift_min") or 0) != int(src.get("ts_shift_min") or 0):   # v0.76 เปลี่ยนเวลา → ลงค่าใหม่ย้อนหลัง
                from .. import srcmap as SM
                try:
                    r = SM.reapply(db, sid, _reapply_days(), current_user_id(), shift=True)
                    db.commit()
                    if r:
                        flash(f"เปลี่ยนเลื่อนเวลาแล้ว — ลงค่าใหม่ย้อนหลัง {r['days']} วัน: ค่าดิบ {r['fetched']} · สร้างใหม่ {r['created']} รายการ", "ok")
                except (ValidationError, CN.SourceError) as exc:
                    db.rollback()
                    flash(f"ลงค่าใหม่ย้อนหลังไม่สำเร็จ: {exc.errors[0] if isinstance(exc, ValidationError) else exc}", "error")
            return redirect(url_for("src.source_detail", sid=sid))
        except ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
    cfg = {**CN.DEFAULT_CONFIG.get(src["kind"], {}), **src["config"]}      # v0.75 ช่องตั้งค่าใหม่แสดงให้แหล่งเดิมด้วย
    if src["kind"] == "mssql":
        cfg["conn"] = CN.mask_secret(cfg.get("conn", ""))
    runs = [dict(r) for r in db.execute("SELECT * FROM cs_source_runs WHERE source_id=? ORDER BY id DESC LIMIT 30", (sid,))]
    subs = db.execute("SELECT COUNT(*) FROM cs_submissions WHERE source='auto' AND client_uuid LIKE ?", (f"src{sid}:%",)).fetchone()[0]
    from datetime import date, timedelta

    from .. import srcmap as SM
    try:
        pday = date.fromisoformat(request.args.get("pday") or "")
    except ValueError:
        pday = date.today() - timedelta(days=1)
    try:
        sday = date.fromisoformat(request.args.get("sday") or "")
    except ValueError:
        sday = S.now_dt().date()
    sstat = SM.slot_status(db, sid, sday)
    hl = SM.health(db, sid)
    tags, sug = CN.list_tags(db, sid), TM.suggest(db, sid)
    return render_template("admin/source_detail.html", s=src, cfg=cfg, kinds=CN.KIND_TH, aggs=CN.AGG_TH,
                           sday=sday, sstat=sstat, hl=hl, STATES=SM.STATES, now=S.now_dt(), raw=SM.raw_stats(db, sid),
                           compact_after=SM.COMPACT_AFTER_DAYS, relay_max=SM.RELAY_MAX_DAYS, timedelta=timedelta,
                           tags=tags, targets=CN.mapping_targets(db), grp=TM.group_tags(db, sid, tags, sug), runs=runs, subs=subs,
                           pyodbc=_has_pyodbc(), fcfgs=SM.form_cfgs(db, sid), modes=SM.MODES, picks=SM.PICKS,
                           pday=pday, pview=SM.preview_day(db, sid, pday), today=date.today(), sug=sug)


@bp.route("/admin/sources/<int:sid>/mapping.xlsx")
@require_role("admin")
def source_mapping_xlsx(sid):
    """v0.45 ส่งออกการจับคู่ Tag เป็น Excel (พร้อมคำแนะนำของระบบ และรายการหัวข้อที่เลือกได้)"""
    from flask import Response
    db = get_db()
    src = CN.get_source(db, sid)
    if not src:
        abort(404)
    data = TM.export_xlsx(db, sid)
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="tag-mapping-{sid}.xlsx"'})


@bp.route("/admin/sources/<int:sid>/mapping-import", methods=["POST"])
@require_role("admin")
def source_mapping_import(sid):
    db = get_db()
    if not CN.get_source(db, sid):
        abort(404)
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(".xlsx"):
        flash("กรุณาเลือกไฟล์ .xlsx", "error")
        return redirect(url_for("src.source_detail", sid=sid) + "#tags")
    from .. import srcmap as SM
    before = SM.mapping_snapshot(db)
    try:
        res = TM.import_xlsx(db, sid, f.read(5 * 1024 * 1024), current_user_id())
        db.commit()
        _flash_reapply(SM.reapply_mapping(db, before, _reapply_days(), current_user_id()))
        db.commit()
        flash(f"นำเข้าการจับคู่แล้ว: จับคู่ {res['mapped']} Tag · ไม่ใช้ {res['unmapped']} Tag"
              + (f" · มีปัญหา {len(res['errors'])} แถว" if res["errors"] else ""), "ok" if not res["errors"] else "error")
        for e in res["errors"][:15]:
            flash(e, "error")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    return redirect(url_for("src.source_detail", sid=sid) + "#tags")


@bp.route("/admin/sources/<int:sid>/forms", methods=["POST"])
@require_role("admin")
def source_forms(sid):
    """v0.44 ตั้งค่าการลงค่ารายแบบฟอร์ม (ตามเวลารอบตรวจ / เวลาที่กำหนด / ทุกช่วง)"""
    from .. import srcmap as SM
    db = get_db()
    if not CN.get_source(db, sid):
        abort(404)
    f = request.form
    rows = [{"form_id": fid, "mode": f.get(f"mode.{fid}"), "times": f.get(f"times.{fid}"), "pick": f.get(f"pick.{fid}"),
             "window_min": f.get(f"win.{fid}")} for fid in f.getlist("form_id")]
    key = ("effective", "times", "pick", "window_min")
    before = {c["form_id"]: tuple(c[k] for k in key) for c in SM.form_cfgs(db, sid)}
    try:
        n = SM.save_form_cfgs(db, sid, rows, current_user_id())
        db.commit()
        flash(f"บันทึกการลงค่าแล้ว ({n} แบบฟอร์ม)", "ok")
        changed = {c["form_id"] for c in SM.form_cfgs(db, sid) if before.get(c["form_id"]) != tuple(c[k] for k in key)}
        if changed:                                       # v0.76 เปลี่ยนวิธีลงค่า → ลงค่าใหม่ย้อนหลังให้แบบฟอร์มที่เปลี่ยน
            r = SM.reapply(db, sid, _reapply_days(), current_user_id(), changed)
            db.commit()
            if r:
                flash(f"ลงค่าใหม่ย้อนหลัง {r['days']} วัน: {r['forms']} แบบฟอร์ม · สร้างใหม่ {r['created']} รายการ", "ok")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    return redirect(url_for("src.source_detail", sid=sid) + "#fmap")


@bp.route("/admin/sources/<int:sid>/relay", methods=["POST"])
@require_role("admin")
def source_relay(sid):
    """v0.44 ลงค่าใหม่ช่วงวันที่ · v0.81 เลือกโหมด: fill = เติมเฉพาะช่องที่ขาด · replace (ค่าเริ่มต้น) = ลงค่าใหม่ทั้งหมด"""
    from datetime import date, timedelta

    from .. import srcmap as SM
    db = get_db()
    mode = request.form.get("mode") or "replace"
    try:
        d1 = date.fromisoformat(request.form.get("day_from") or "")
        d2 = date.fromisoformat(request.form.get("day_to") or "")
        if d1 > d2:
            d1, d2 = d2, d1
        if (d2 - d1).days >= SM.RELAY_MAX_DAYS:
            raise ValidationError(f"เลือกช่วงไม่เกิน {SM.RELAY_MAX_DAYS} วันต่อครั้ง (เลือกไว้ {(d2 - d1).days + 1} วัน) — แบ่งดึงเป็นหลายครั้ง")
        fid = int(request.form.get("form_id") or 0)
        span = f"{d1:%d/%m/%Y}–{d2:%d/%m/%Y} ({(d2 - d1).days + 1} วัน)"
        if mode == "fill":
            src = CN.get_source(db, sid)
            tot = {"gaps": 0, "fetched": 0, "created": 0}
            a = d1
            while a <= d2:                                  # ตรวจสอบได้ครั้งละไม่เกิน 31 วัน → แบ่งเป็นช่วง
                b = min(d2, a + timedelta(days=SM.AUDIT_MAX_DAYS - 2))
                r = SM.fill_range(db, src, a, b)
                for k in tot:
                    tot[k] += r[k]
                a = b + timedelta(days=1)
            db.commit()
            flash(f"เติมช่องที่ขาด {span}: ช่องที่ขาด {tot['gaps']} · ค่าจาก SCADA {tot['fetched']} ค่า · ลงค่าเพิ่ม {tot['created']} รายการ",
                  "ok" if tot["created"] or not tot["gaps"] else "error")
            if tot["gaps"] and not tot["fetched"]:
                flash("ไม่พบค่าใน SCADA ของช่องที่ขาด — ตรวจว่าฐานข้อมูล SCADA มีข้อมูลย้อนหลังถึงวันที่เลือก และ “เลื่อนเวลา” ถูกต้อง", "error")
        else:
            r = SM.relay(db, sid, d1, d2, current_user_id(), {fid} if fid else None)
            db.commit()
            flash(f"ลงค่าใหม่ {span}: {r['forms']} แบบฟอร์ม · ค่าจาก SCADA {r['fetched']} ค่า ({r['src_days']} วันที่มีข้อมูล) · "
                  f"ลบผลตรวจอัตโนมัติเดิม {r['removed']} · สร้างใหม่ {r['created']} รายการ (ตรงเวลารอบ)"
                  + (f" · อัปเดตค่า SCADA ในผลของช่าง {r['human_updated']} รายการ" if r.get("human_updated") else ""), "ok")
            if r["removed"] > r["created"]:
                flash(f"สร้างใหม่น้อยกว่าที่ลบ: ผลตรวจเดิมบางรายการเป็นเวลาที่ไม่ได้ใช้แล้วตามการตั้งค่าปัจจุบัน (เช่น เคยลงทุกชั่วโมง)"
                      + (f" · ช่างกรอกรอบนั้นเองแล้ว {r['human']} รอบ (ระบบไม่ลงซ้ำ)" if r["human"] else ""), "ok")
            if r["no_data"]:
                ds = ", ".join(d.strftime("%d/%m") for d in r["no_data"][:15]) + (" …" if len(r["no_data"]) > 15 else "")
                flash(f"ไม่มีค่าใน SCADA {len(r['no_data'])} วัน: {ds} — วันเหล่านี้คงผลตรวจเดิมไว้", "error")
            if r["incomplete"]:
                flash(f"ข้อมูลบางช่วงมากเกินไป ดึงได้ไม่ครบ {r['incomplete']} ช่วง — เลือกช่วงวันที่สั้นลงแล้วลองอีกครั้ง", "error")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    except ValueError:
        db.rollback()
        flash("กรุณาเลือกช่วงวันที่", "error")
    if request.form.get("back") == "audit":
        return redirect(url_for("src.source_audit", sid=sid, **{"from": request.form.get("day_from"), "to": request.form.get("day_to")},
                                form=request.form.get("form_id") or None))
    return redirect(url_for("src.source_detail", sid=sid) + "#backfill")


def _reapply_days() -> int:
    """v0.76 จำนวนวันที่ให้ลงค่าใหม่ย้อนหลังหลังแก้การตั้งค่า (ค่าเริ่มต้น 7)"""
    from .. import srcmap as SM
    v = request.form.get("reapply_days", type=int)
    return v if v in SM.REAPPLY_CHOICES else 7


def _flash_reapply(msgs):
    for m in msgs:
        flash(m, "error" if "ไม่สำเร็จ" in m else "ok")


def _has_pyodbc() -> bool:
    import importlib.util
    return importlib.util.find_spec("pyodbc") is not None


@bp.route("/admin/sources/<int:sid>/test", methods=["POST"])
@require_role("admin")
def source_test(sid):
    db = get_db()
    try:
        res = CN.preview(db, sid)
        db.commit()                                       # v0.79 จำรายชื่อ Tag ที่พบไว้ให้จับคู่ได้ทันที (ไม่สร้างผลตรวจ)
        return jsonify({"ok": True, **res})
    except (CN.SourceError, ValidationError) as exc:
        db.rollback()
        return jsonify({"error": str(exc) if isinstance(exc, CN.SourceError) else "; ".join(exc.errors)}), 400


@bp.route("/admin/sources/<int:sid>/discover", methods=["POST"])
@require_role("admin")
def source_discover(sid):
    """v0.79 ค้นหา Tag จากแหล่งข้อมูล แล้วจำรายชื่อไว้ให้จับคู่ (ไม่ลงค่า ไม่สร้างผลตรวจ)"""
    db = get_db()
    if not CN.get_source(db, sid):
        abort(404)
    before = db.execute("SELECT COUNT(*) FROM cs_source_tags WHERE source_id=?", (sid,)).fetchone()[0]
    try:
        res = CN.preview(db, sid)
        db.commit()
        after = db.execute("SELECT COUNT(*) FROM cs_source_tags WHERE source_id=?", (sid,)).fetchone()[0]
        flash(f"พบ Tag {len(res['tags'])} ตัว (ใหม่ {after - before}) — เลือก เครื่อง → หัวข้อ ด้านล่าง แล้วกดบันทึก", "ok")
    except (CN.SourceError, ValidationError) as exc:
        db.rollback()
        flash(f"ค้นหา Tag ไม่สำเร็จ: {exc if isinstance(exc, CN.SourceError) else exc.errors[0]}", "error")
    return redirect(url_for("src.source_detail", sid=sid) + "#tags")


@bp.route("/admin/sources/<int:sid>/run", methods=["POST"])
@require_role("admin")
def source_run(sid):
    from ..notify import wake
    db = get_db()
    res = CN.run_source(db, sid, manual=True)
    db.commit()
    wake()
    flash(res["message"], "ok" if res["ok"] else "error")
    return redirect(url_for("src.source_detail", sid=sid) + "#runs")


@bp.route("/admin/sources/<int:sid>/tags", methods=["POST"])
@require_role("admin")
def source_tags(sid):
    db = get_db()
    tags = request.form.getlist("tag")
    idxs = request.form.getlist("idx")                    # v0.78 หน้าจัดกลุ่มตามเครื่อง: แถวไม่เรียงตามลำดับเดิม
    if len(idxs) != len(tags):
        idxs = [str(i) for i in range(len(tags))]
    new_tag = (request.form.get("new_tag") or "").strip()
    mapping = [{"tag": t, "target": request.form.get(f"target.{i}", ""), "scale": request.form.get(f"scale.{i}"),
                "add_offset": request.form.get(f"offset.{i}"),
                **({"valid_min": request.form.get(f"vmin.{i}"), "valid_max": request.form.get(f"vmax.{i}")}
                   if f"vmin.{i}" in request.form or f"vmax.{i}" in request.form else {})} for i, t in zip(idxs, tags)]
    if new_tag:
        mapping.append({"tag": new_tag, "target": request.form.get("new_target", ""), "scale": 1, "add_offset": 0})
    from .. import srcmap as SM
    before = SM.mapping_snapshot(db)
    try:
        n = CN.save_mapping(db, sid, mapping, current_user_id())
        db.commit()
        flash(f"บันทึกการจับคู่แล้ว ({n} Tag)", "ok")
        _flash_reapply(SM.reapply_mapping(db, before, _reapply_days(), current_user_id()))
        db.commit()
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    return redirect(url_for("src.source_detail", sid=sid) + "#tags")


@bp.route("/admin/sources/<int:sid>/heal", methods=["POST"])
@require_role("admin")
def source_heal(sid):
    """v0.73 เติมช่องเวลาที่ขาดตอนนี้ (ดึงย้อนหลังเฉพาะช่วงที่ขาด ภายใน 2 วันล่าสุด)"""
    from ..notify import wake
    from .. import srcmap as SM
    db = get_db()
    src = CN.get_source(db, sid)
    if not src:
        abort(404)
    before = SM.health(db, sid)["count"]["missing"]
    try:
        made = SM.heal(db, src, force=True)
        made += SM.fill_slots(db, CN.get_source(db, sid))
        db.commit()
        after = SM.health(db, sid)["count"]["missing"]
        flash(f"เติมช่องที่ขาดแล้ว {made} ช่อง" + (f" · ยังขาด {after} ช่อง (แหล่งข้อมูลไม่มีค่าในช่วงเวลานั้น)" if after else " · ครบทุกช่อง")
              if before or made else "ไม่มีช่องที่ขาดใน 2 วันล่าสุด", "ok")
        wake()
    except CN.SourceError as exc:
        db.rollback()
        flash(f"ดึงข้อมูลย้อนหลังไม่สำเร็จ: {exc}", "error")
    if request.form.get("back") == "issues":
        return redirect(url_for("src.source_issues"))
    return redirect(url_for("src.source_detail", sid=sid, sday=request.form.get("sday") or None) + "#status")


@bp.route("/admin/sources/<int:sid>/upload", methods=["POST"])
@require_role("admin")
def source_upload(sid):
    from ..notify import wake
    db = get_db()
    src = CN.get_source(db, sid)
    if not src:
        abort(404)
    f = request.files.get("file")
    if not f or not f.filename:
        flash("กรุณาเลือกไฟล์ CSV", "error")
        return redirect(url_for("src.source_detail", sid=sid))
    raw = f.read(CN.MAX_FILE_MB * 1024 * 1024 + 1)
    if len(raw) > CN.MAX_FILE_MB * 1024 * 1024:
        flash(f"ไฟล์ใหญ่เกิน {CN.MAX_FILE_MB} MB", "error")
        return redirect(url_for("src.source_detail", sid=sid))
    cfg = dict(CN.DEFAULT_CONFIG["csv"])
    cfg.update({k: v for k, v in src["config"].items() if k in cfg})
    try:
        text = raw.decode(cfg.get("encoding") or "utf-8-sig", errors="replace")
        rows = CN.parse_csv(text, cfg)
    except CN.SourceError as exc:
        flash(str(exc), "error")
        return redirect(url_for("src.source_detail", sid=sid))
    res = CN.run_source(db, sid, manual=True, rows_override=rows, label=f"อัปโหลด {f.filename}")
    db.commit()
    wake()
    flash(res["message"], "ok" if res["ok"] else "error")
    return redirect(url_for("src.source_detail", sid=sid) + "#runs")


@bp.route("/admin/sources/<int:sid>/delete", methods=["POST"])
@require_role("admin")
def source_delete(sid):
    db = get_db()
    CN.delete_source(db, sid, current_user_id())
    db.commit()
    flash("ลบแหล่งข้อมูลแล้ว (ผลตรวจที่นำเข้าแล้วยังอยู่)", "ok")
    return redirect(url_for("src.sources"))


# ───────────────────────── v0.46 จับคู่จากฝั่งแบบฟอร์ม ─────────────────────────

@bp.route("/forms/<int:form_id>/scada", methods=["GET", "POST"])
@require_role("admin")
def form_scada(form_id):
    """ทุกหัวข้อของแบบฟอร์ม → เลือก 'ช่างกรอก' หรือ แหล่งข้อมูล + Tag · แม่แบบ = รูปแบบ Tag ด้วย {EQ}"""
    from .. import formmap as FM
    from .. import services as S
    db = get_db()
    form = S.get_form(db, form_id)
    if not form:
        abort(404)
    f = request.form
    if request.method == "POST":
        keys = f.getlist("item_key")
        try:
            if form.get("is_template"):
                rows = [{"item_key": k, "source_id": f.get(f"src.{k}"), "pattern": f.get(f"pat.{k}"),
                         "scale": f.get(f"scale.{k}"), "add_offset": f.get(f"off.{k}")} for k in keys]
                from .. import srcmap as SM
                before = SM.mapping_snapshot(db)
                res = FM.apply_patterns(db, form_id, rows, current_user_id())
                db.commit()
                _flash_reapply(SM.reapply_mapping(db, before, _reapply_days(), current_user_id()))
                db.commit()
                flash(f"ใช้รูปแบบ Tag กับ {res['forms']} เครื่องแล้ว · จับคู่ {res['mapped']} รายการ · "
                      f"พบ Tag ในแหล่งข้อมูลแล้ว {res['seen']}/{res['total']}", "ok" if not res["errors"] else "error")
                for e in res["errors"][:10]:
                    flash(e, "error")
            else:
                rows = [{"item_key": k, "source_id": f.get(f"src.{k}"), "tag": f.get(f"tag.{k}"),
                         "scale": f.get(f"scale.{k}"), "add_offset": f.get(f"off.{k}")} for k in keys]
                from .. import srcmap as SM
                before = SM.mapping_snapshot(db)
                res = FM.save_form_map(db, form_id, rows, current_user_id())
                db.commit()
                _flash_reapply(SM.reapply_mapping(db, before, _reapply_days(), current_user_id()))
                db.commit()
                flash(f"บันทึกแล้ว · หัวข้อที่ใช้ค่าจาก SCADA/SQL {res['mapped']} หัวข้อ"
                      + (f" · ยกเลิก Tag เดิม {res['cleared']}" if res["cleared"] else ""), "ok")
            return redirect(url_for("src.form_scada", form_id=form_id))
        except ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
    srcs = FM.sources(db)
    if form.get("is_template"):
        from ..formtpl import children
        items = S.get_items(db, form["current_version_id"]) if form["current_version_id"] else []
        kids = [k for k in children(db, form_id) if k["eq_code"]]
        return render_template("admin/form_scada_tpl.html", form=form, items=items, sources=srcs,
                               pats=FM.tpl_patterns(db, form_id), kids=kids[:200])
    try:
        v = FM.form_view(db, form_id)
    except ValidationError as exc:
        flash(exc.errors[0], "error")
        return redirect(url_for("forms.form_detail", form_id=form_id))
    tags = {s["id"]: FM.source_tags(db, s["id"]) for s in srcs}
    return render_template("admin/form_scada.html", v=v, form=form, sources=srcs, tags=tags)


@bp.route("/admin/sources/coverage")
@require_role("admin")
def sources_coverage():
    from .. import formmap as FM
    db = get_db()
    return render_template("admin/source_coverage.html", rows=FM.coverage_list(db))


# ───────────────────────── v0.47 ศูนย์ผูกข้อมูล ─────────────────────────

@bp.route("/admin/binding")
@require_role("admin")
def binding():
    from datetime import date

    from .. import binding as BD
    db = get_db()
    try:
        day = date.fromisoformat(request.args.get("day") or "")
    except ValueError:
        day = None
    st = BD.status(db, day)
    db.rollback()
    return render_template("admin/binding.html", b=st, kinds=CN.KIND_TH)


@bp.route("/admin/binding/shift", methods=["POST"])
@require_role("admin")
def binding_shift():
    from .. import binding as BD
    db = get_db()
    try:
        BD.apply_shift(db, int(request.form.get("sid") or 0), int(request.form.get("minutes") or 0), current_user_id())
        db.commit()
        flash("ปรับเวลาของแหล่งข้อมูลแล้ว — กด “ดึงข้อมูลตอนนี้” แล้ว “ลงค่าใหม่ย้อนหลัง” เพื่อแก้ค่าที่ลงไปแล้ว", "ok")
    except (ValueError, ValidationError) as exc:
        db.rollback()
        flash(getattr(exc, "errors", [str(exc)])[0], "error")
    return redirect(url_for("src.binding") + "#s2")


@bp.route("/admin/binding/run", methods=["POST"])
@require_role("admin")
def binding_run():
    """ดึงข้อมูลทุกแหล่งที่เปิดใช้งานตอนนี้"""
    from ..notify import wake
    db = get_db()
    msgs = []
    for s in CN.list_sources(db):
        if s["active"]:
            r = CN.run_source(db, s["id"], manual=True)
            msgs.append(f"{s['name']}: {r['message']}")
    db.commit()
    wake()
    flash(" · ".join(msgs) if msgs else "ไม่มีแหล่งข้อมูลที่เปิดใช้งาน", "ok")
    return redirect(url_for("src.binding"))


# ───────────────────────── v0.74 ตรวจสอบ / แก้ไข การลงค่าจาก SCADA ย้อนหลัง ─────────────────────────

def _need_fixer(db) -> None:
    from .. import submissions as SUB
    if not SUB.can_approve(db, current_user_id()):
        abort(403)


def _range():
    from datetime import date, timedelta
    today = S.now_dt().date()
    try:
        d2 = date.fromisoformat(request.values.get("to") or "")
    except ValueError:
        d2 = today
    try:
        d1 = date.fromisoformat(request.values.get("from") or "")
    except ValueError:
        d1 = d2 - timedelta(days=6)
    if d1 > d2:
        d1, d2 = d2, d1
    if (d2 - d1).days > 30:
        d1 = d2 - timedelta(days=30)
    return d1, d2


@bp.route("/sources/audit")
@require_role(*ALL_ROLES)
def sources_audit_home():
    db = get_db()
    _need_fixer(db)
    rows = [r for r in CN.list_sources(db) if r["active"]] or CN.list_sources(db)
    if not rows:
        flash("ยังไม่มีแหล่งข้อมูล SCADA", "error")
        return redirect(url_for("review.approvals"))
    return redirect(url_for("src.source_audit", sid=rows[0]["id"], **request.args))


@bp.route("/admin/sources/<int:sid>/audit")
@require_role(*ALL_ROLES)
def source_audit(sid):
    """ตรวจสอบการลงค่าจาก SCADA ช่วงวันที่: ค่าไหนมา / ไม่มา / ปัญหาอยู่ตรงไหน + แก้ค่า ยกเลิกค่า คืนค่า ดึงช่องที่ขาด"""
    from .. import srcmap as SM
    db = get_db()
    _need_fixer(db)
    src = CN.get_source(db, sid)
    if not src:
        abort(404)
    d1, d2 = _range()
    fid = request.args.get("form", type=int)
    only = request.args.get("only") if request.args.get("only") in ("problem", "pending", "fixed") else ""
    rep = SM.audit(db, sid, d1, d2, fid)
    allforms = [] if not fid else [f for f in SM.form_cfgs(db, sid) if f["slotted"]]
    return render_template("admin/source_audit.html", s=src, rep=rep, d1=d1, d2=d2, fid=fid, only=only, CELL=SM.CELL,
                           sources=CN.list_sources(db), forms=allforms or [f for f in SM.form_cfgs(db, sid) if f["slotted"]],
                           is_admin=session_role() == "admin", today=S.now_dt().date())


def session_role():
    from flask import session
    return session.get("role")


@bp.route("/admin/sources/<int:sid>/audit.xlsx")
@require_role(*ALL_ROLES)
def source_audit_xlsx(sid):
    from flask import Response
    from .. import srcmap as SM
    db = get_db()
    _need_fixer(db)
    if not CN.get_source(db, sid):
        abort(404)
    d1, d2 = _range()
    data = SM.audit_xlsx(db, sid, d1, d2, request.args.get("form", type=int))
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="scada-audit-{sid}-{d1:%Y%m%d}-{d2:%Y%m%d}.xlsx"'})


def _back(sid):
    return redirect(url_for("src.source_audit", sid=sid, **{"from": request.form.get("from"), "to": request.form.get("to")},
                            form=request.form.get("form") or None, only=request.form.get("only") or None)
                    + (f"#r{request.form.get('anchor')}" if request.form.get("anchor") else ""))


@bp.route("/admin/sources/<int:sid>/fix", methods=["POST"])
@require_role(*ALL_ROLES)
def source_fix(sid):
    """แก้ค่า / ยกเลิกค่า / คืนค่าจาก SCADA ของช่องเวลา (รายหัวข้อ หรือทั้งรอบ)"""
    from datetime import datetime

    from .. import srcmap as SM
    db = get_db()
    _need_fixer(db)
    f = request.form
    try:
        fid = int(f.get("form_id") or 0)
        t = datetime.strptime(f.get("at") or "", "%Y-%m-%d %H:%M:%S")
        act = f.get("act")
        key = f.get("item_key") or ""
        if act == "clear":
            SM.clear_fix(db, sid, fid, t, key if key else "*", current_user_id())
            msg = f"คืนค่าจาก SCADA แล้ว ({t:%d/%m %H:%M})"
        elif act in ("void", "value"):
            SM.set_fix(db, sid, fid, t, key, act, f.get("value"), f.get("reason"), current_user_id())
            msg = (f"ยกเลิกค่า{'ทั้งรอบ' if not key else ''}แล้ว" if act == "void" else "บันทึกค่าที่แก้แล้ว") + f" ({t:%d/%m %H:%M}) — ระบบจะไม่ลงทับเมื่อดึงซ้ำ"
        elif act == "refetch":
            src = CN.get_source(db, sid)
            cfg = SM.get_cfg(db, sid, fid)
            win = int(cfg.get("window_min") or 30)
            from datetime import timedelta
            rows, _k, _b = CN.fetch(db, dict(src), tags=CN.mapped_tags(db, sid) or None,
                                    since=t - timedelta(minutes=win + 1), until=min(t + timedelta(minutes=win + 1), S.now_dt()))
            n = SM.store_values(db, src, rows, prune=False)
            SM.rebuild_slot(db, src, fid, t, current_user_id(), "ดึงค่าช่องนี้จาก SCADA ใหม่")
            msg = f"ดึงช่อง {t:%d/%m %H:%M} ใหม่แล้ว · ค่าดิบ {n} ค่า"
        else:
            raise ValidationError("คำสั่งไม่ถูกต้อง")
        db.commit()
        flash(msg, "ok")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    except CN.SourceError as exc:
        db.rollback()
        flash(f"ดึงข้อมูลจาก SCADA ไม่สำเร็จ: {exc}", "error")
    except ValueError:
        db.rollback()
        flash("ข้อมูลไม่ครบ", "error")
    return _back(sid)


@bp.route("/admin/sources/<int:sid>/fill-range", methods=["POST"])
@require_role(*ALL_ROLES)
def source_fill_range(sid):
    """ดึงเฉพาะช่องที่ขาดในช่วงวันที่ (ไม่ลบค่าที่ลงแล้ว)"""
    from .. import srcmap as SM
    db = get_db()
    _need_fixer(db)
    src = CN.get_source(db, sid)
    if not src:
        abort(404)
    d1, d2 = _range()
    try:
        r = SM.fill_range(db, src, d1, d2)
        db.commit()
        flash(f"ดึงช่องที่ขาดแล้ว: ช่องที่ขาด {r['gaps']} · ค่าดิบที่ได้ {r['fetched']} · ลงค่าเพิ่ม {r['created']} รายการ", "ok")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    return _back(sid)


@bp.route("/admin/sources/purge-down", methods=["POST"])
@require_role("admin")
def source_purge_down():
    """v0.84.1 ล้างค่าจาก SCADA ที่ลงไว้ในช่วงเครื่องหยุด/สำรอง ย้อนหลัง 62 วัน (ทุกแหล่ง)"""
    from .. import srcmap as SM
    db = get_db()
    try:
        n = SM.purge_down_all(db, SM.SWEEP_DAYS, current_user_id())
        db.commit()
        flash(f"เอาค่าจาก SCADA ในช่วงเครื่องหยุด / สำรองออกแล้ว {n} รอบ — ใบบันทึกแสดง \"หยุด\" ตามสถานะเครื่อง" if n
              else "ไม่มีค่าจาก SCADA ค้างในช่วงเครื่องหยุด", "ok")
    except Exception as exc:                            # noqa: BLE001
        db.rollback()
        flash(f"ล้างค่าไม่สำเร็จ: {exc}", "error")
    return redirect(url_for("src.source_issues"))


@bp.route("/admin/sources/issues")
@require_role("admin")
def source_issues():
    """v0.83 รวมปัญหา SCADA ทุกแหล่งในหน้าเดียว พร้อมปุ่มแก้"""
    from .. import srcissues as SI
    db = get_db()
    return render_template("admin/source_issues.html", rep=SI.collect(db), now=S.now_dt())
