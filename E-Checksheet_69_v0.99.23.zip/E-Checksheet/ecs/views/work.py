"""ecs/views/work.py — Phase 4: กระดิ่งแจ้งเตือน, งานแก้ไข (CAPA), ตั้งค่าการแจ้งเตือน/ส่งต่อ/ช่วงเงียบ"""
from __future__ import annotations

import json
from datetime import date, datetime, timedelta

from flask import (Blueprint, abort, current_app, flash, jsonify, redirect, render_template, request, session,
                   url_for)

from .. import capa as C
from .. import masterdata as M
from .. import notify as N
from ..db import get_db
from ..security import ALL_ROLES, MANAGE_ROLES, current_user_id, require_role, safe_next, wants_json
from ..services import ValidationError, list_forms

bp = Blueprint("work", __name__)


@bp.app_context_processor
def _inject():
    out = {"nav_bell": 0, "nav_capa": 0, "CAPA_STATUS_TH": C.STATUS_TH, "CAPA_STATUS_CLASS": C.STATUS_CLASS,
           "CAPA_PRIORITY_TH": C.PRIORITY_TH}
    if "user_id" in session:
        try:
            db = get_db()
            out["nav_bell"] = N.unread_count(db, session["user_id"])
            out["nav_capa"] = db.execute("""SELECT COUNT(*) FROM cs_actions WHERE owner_id=? AND status IN ('open','in_progress')""",
                                         (session["user_id"],)).fetchone()[0]
        except Exception:  # noqa: BLE001 — ตัวนับต้องไม่ทำให้หน้าเว็บล่ม
            pass
    return out


def _int(v):
    try:
        return int(v or 0) or None
    except (TypeError, ValueError):
        return None


def _flash_errors(exc: ValidationError):
    for e in exc.errors:
        flash(e, "error")


def _safe_path(p: str) -> str:
    """เส้นทางภายในที่เก็บไว้ในการแจ้งเตือน (เช่น /alerts/5) → URL จริง (เติม /echeck เมื่อรวมกับ UT-CMMS)"""
    if isinstance(p, str) and p.startswith("/") and not p.startswith("//"):
        root = request.script_root or ""
        return p if root and p.startswith(root + "/") else root + p
    return url_for("index")


# ───────────────────────── กระดิ่ง ─────────────────────────

@bp.route("/api/account/theme", methods=["POST"])
@require_role(*ALL_ROLES)
def api_theme():
    """บันทึกธีมสีของผู้ใช้ (บัญชีที่ผูก UT-CMMS หน้าเว็บจะบันทึกที่ UT-CMMS ด้วย /api/theme ให้ตรงกันทั้งสองระบบ)"""
    from ..security import THEME_IDS
    theme = str((request.get_json(silent=True) or {}).get("theme") or "")
    if theme not in THEME_IDS:
        return jsonify({"error": "ไม่รู้จักธีมนี้"}), 400
    db = get_db()
    db.execute("UPDATE users SET theme=? WHERE id=?", (theme, current_user_id()))
    db.commit()
    return jsonify({"ok": True, "theme": theme, "cmms": bool(session.get("cmms_uid"))})


@bp.route("/api/notifications")
@require_role(*ALL_ROLES)
def api_notifications():
    db = get_db()
    uid = current_user_id()
    return jsonify({"unread": N.unread_count(db, uid), "items": N.list_notifications(db, uid, 15)})


@bp.route("/api/notifications/read", methods=["POST"])
@require_role(*ALL_ROLES)
def api_notifications_read():
    db = get_db()
    ids = [int(x) for x in (request.get_json(silent=True) or {}).get("ids", []) if str(x).isdigit()]
    n = N.mark_read(db, current_user_id(), ids or None)
    db.commit()
    return jsonify({"ok": True, "marked": n, "unread": N.unread_count(db, current_user_id())})


@bp.route("/notifications")
@require_role(*ALL_ROLES)
def notifications():
    db = get_db()
    return render_template("work/notifications.html", items=N.list_notifications(db, current_user_id(), 200))


@bp.route("/notifications/read-all", methods=["POST"])
@require_role(*ALL_ROLES)
def notifications_read_all():
    db = get_db()
    N.mark_read(db, current_user_id())
    db.commit()
    return redirect(url_for("work.notifications"))


@bp.route("/n/<int:nid>")
@require_role(*ALL_ROLES)
def open_notification(nid):
    db = get_db()
    row = db.execute("SELECT url FROM cs_notifications WHERE id=? AND user_id=?", (nid, current_user_id())).fetchone()
    if not row:
        abort(404)
    N.mark_read(db, current_user_id(), [nid])
    db.commit()
    return redirect(_safe_path(row["url"] or "/notifications"))


# ───────────────────────── CAPA ─────────────────────────

def _is_manager() -> bool:
    return session.get("role") in MANAGE_ROLES


def _load_action(db, action_id):
    c = C.get_action(db, action_id)
    if not c:
        abort(404)
    if session.get("role") == "technician" and c["owner_id"] != current_user_id() and c["created_by"] != current_user_id():
        abort(404)
    return c


def _users(db):
    return [u for u in M.list_users(db) if u["active"]]


@bp.route("/actions")
@require_role(*ALL_ROLES)
def actions():
    db = get_db()
    me = current_user_id()
    tech = session.get("role") == "technician"
    mine = tech or request.args.get("mine") == "1"
    status = request.args.get("status", "open")
    factory_id = _int(request.args.get("factory"))
    owner = me if mine else _int(request.args.get("owner"))
    overdue = request.args.get("overdue") == "1"
    q = request.args.get("q", "").strip()[:60]
    rows = C.list_actions(db, status=status, owner_id=owner, factory_id=factory_id, overdue=overdue, q=q)
    return render_template("work/actions.html", rows=rows, status=status, mine=mine, owner=owner, overdue=overdue, q=q,
                           factory_id=factory_id, factories=M.list_factories(db), users=_users(db),
                           counts=C.action_counts(db, owner_id=owner, factory_id=factory_id))


@bp.route("/actions/new", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def action_new():
    db = get_db()
    if request.method == "POST":
        data = request.form.to_dict()
        data["source"] = "manual"
        try:
            aid = C.create_action(db, data, current_user_id())
            db.commit()
            N.wake()
            flash("สร้างงานแก้ไขแล้ว", "ok")
            return redirect(url_for("work.action_detail", action_id=aid))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
    eq = M.list_equipment(db)
    return render_template("work/action_new.html", users=_users(db), equipment=eq,
                           forms=list_forms(db), default_due=(date.today() + timedelta(days=7)).isoformat(),
                           data=request.form if request.method == "POST" else {})


@bp.route("/submissions/<int:sub_id>/capa", methods=["POST"])
@require_role(*MANAGE_ROLES)
def capa_from_ng(sub_id):
    db = get_db()
    try:
        aid = C.create_from_ng(db, sub_id, request.form.get("item", ""), current_user_id())
        db.commit()
        N.wake()
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return redirect(url_for("review.submission_detail", sub_id=sub_id))
    flash("สร้างงานแก้ไข (CAPA) แล้ว — ตรวจสอบผู้รับผิดชอบและกำหนดเสร็จ", "ok")
    return redirect(url_for("work.action_detail", action_id=aid))


@bp.route("/actions/<int:action_id>")
@require_role(*ALL_ROLES)
def action_detail(action_id):
    db = get_db()
    c = _load_action(db, action_id)
    me = current_user_id()
    return render_template("work/action_detail.html", c=c, users=_users(db), is_manager=_is_manager(),
                           is_owner=c["owner_id"] == me, before=[p for p in c["photos"] if p["kind"] == "before"],
                           after=[p for p in c["photos"] if p["kind"] == "after"])


@bp.route("/actions/delete", methods=["POST"])
@require_role(*MANAGE_ROLES)
def actions_delete():
    """v0.33 ลบงานแก้ไข (ทีละรายการจากหน้ารายละเอียด หรือหลายรายการจากหน้ารายการ) — ต้องระบุเหตุผล"""
    from flask import current_app
    db = get_db()
    ids = [int(x) for x in request.form.getlist("ids") if str(x).isdigit()]
    if session.get("role") == "supervisor" and session.get("factory_id"):
        own = session["factory_id"]                              # หัวหน้างานที่ผูกโรงงาน ลบได้เฉพาะงานของโรงงานตัวเอง
        ids = [i for i in ids if (r := db.execute("SELECT factory_id FROM cs_actions WHERE id=?", (i,)).fetchone())
               and r[0] in (None, own)]
    try:
        n = C.delete_actions(db, ids, current_user_id(), request.form.get("reason"), current_app.config.get("UPLOAD_FOLDER"))
        db.commit()
        flash(f"ลบงานแก้ไขแล้ว {n} รายการ (เก็บประวัติไว้ใน Audit Trail)" if n else "ไม่มีรายการที่ลบได้", "ok" if n else "error")
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        if len(ids) == 1:
            return redirect(url_for("work.action_detail", action_id=ids[0]))
    return redirect(safe_next(request.form.get("next"), url_for("work.actions")))


@bp.route("/actions/<int:action_id>/edit", methods=["POST"])
@require_role(*MANAGE_ROLES)
def action_edit(action_id):
    db = get_db()
    _load_action(db, action_id)
    try:
        C.update_action(db, action_id, request.form.to_dict(), current_user_id())
        db.commit()
        N.wake()
        flash("บันทึกแล้ว", "ok")
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("work.action_detail", action_id=action_id))


@bp.route("/actions/<int:action_id>/comment", methods=["POST"])
@require_role(*ALL_ROLES)
def action_comment(action_id):
    db = get_db()
    _load_action(db, action_id)
    try:
        C.add_comment(db, action_id, current_user_id(), request.form.get("text", ""))
        db.commit()
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("work.action_detail", action_id=action_id) + "#timeline")


@bp.route("/actions/<int:action_id>/photo", methods=["POST"])
@require_role(*ALL_ROLES)
def action_photo(action_id):
    db = get_db()
    c = _load_action(db, action_id)
    if not (_is_manager() or c["owner_id"] == current_user_id()):
        abort(403)
    files = [f for f in request.files.getlist("photo") if f and f.filename][:C.MAX_PHOTOS]
    try:
        if not files:
            raise ValidationError("กรุณาเลือกรูป")
        for f in files:
            C.add_photo(db, action_id, request.form.get("kind", "after"), f, current_app.config["UPLOAD_FOLDER"],
                        current_app.config["MAX_PHOTO_MB"] * 1024 * 1024, current_user_id())
        db.commit()
        flash(f"แนบรูปแล้ว {len(files)} รูป", "ok")
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("work.action_detail", action_id=action_id) + "#photos")


@bp.route("/actions/<int:action_id>/<act>", methods=["POST"])
@require_role(*ALL_ROLES)
def action_transition(action_id, act):
    db = get_db()
    c = _load_action(db, action_id)
    owner_ok = act in ("start", "done") and c["owner_id"] == current_user_id()
    if not (_is_manager() or owner_ok):
        if wants_json():
            return jsonify({"error": "ไม่มีสิทธิ์ทำรายการนี้"}), 403
        abort(403)
    try:
        C.transition(db, action_id, act, current_user_id(), note=request.form.get("note", ""),
                     root_cause=request.form.get("root_cause", ""), action_taken=request.form.get("action_taken", ""))
        db.commit()
        N.wake()
        flash({"start": "เริ่มดำเนินการแล้ว", "done": "ส่งตรวจรับแล้ว", "verify": "ตรวจรับและปิดงานแล้ว",
               "reject": "ส่งกลับให้แก้ไขเพิ่ม", "cancel": "ยกเลิกงานแล้ว", "reopen": "เปิดงานใหม่แล้ว"}.get(act, "บันทึกแล้ว"), "ok")
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("work.action_detail", action_id=action_id))


# ───────────────────────── บัญชีของฉัน: ช่องทางรับแจ้งเตือน ─────────────────────────

@bp.route("/account/notify", methods=["GET", "POST"])
@require_role(*ALL_ROLES)
def my_notify():
    db = get_db()
    uid = current_user_id()
    if request.method == "POST":
        data = request.form.to_dict()
        data["notify_channels"] = request.form.getlist("channels")
        try:
            M.set_contacts(db, uid, data, uid)
            db.commit()
            flash("บันทึกช่องทางรับแจ้งเตือนแล้ว", "ok")
            return redirect(url_for("work.my_notify"))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
    user = dict(db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone())
    return render_template("work/my_notify.html", user=user, cfg=N.get_settings(db, with_secrets=False))


@bp.route("/account/notify/test", methods=["POST"])
@require_role(*ALL_ROLES)
def my_notify_test():
    db = get_db()
    u = dict(db.execute("SELECT * FROM users WHERE id=?", (current_user_id(),)).fetchone())
    cfg = N.get_settings(db)
    results = []
    for ch, target in N._user_targets(u, cfg):
        try:
            N.SENDERS[ch](cfg, target, "ทดสอบการแจ้งเตือน E-Checksheet", f"ถึง {u['name']} — ตั้งค่าช่องทางนี้ถูกต้อง", "")
            results.append(f"{N.CHANNEL_TH[ch]}: ส่งสำเร็จ")
        except N.SendError as exc:
            results.append(f"{N.CHANNEL_TH[ch]}: ไม่สำเร็จ ({exc})")
    N.notify_user_app(db, u["id"], "summary", "ทดสอบการแจ้งเตือนในระบบ", "กระดิ่งทำงานปกติ", "/account/notify")
    db.commit()
    flash(" · ".join(results) if results else "ส่งทดสอบเข้ากระดิ่งแล้ว (ยังไม่มีช่องทางภายนอกที่พร้อมใช้)", "ok")
    return redirect(url_for("work.my_notify"))


# ───────────────────────── ผู้ดูแลระบบ: ตั้งค่าการแจ้งเตือน ─────────────────────────

@bp.route("/admin/notify", methods=["GET", "POST"])
@require_role("admin")
def admin_notify():
    db = get_db()
    if request.method == "POST":
        f = request.form
        data = {ch: {k[len(ch) + 1:]: v for k, v in f.items() if k.startswith(ch + ".")} for ch in N.CHANNELS}
        data["sla_hours"] = {s: f.get(f"sla.{s}", 0) for s in ("critical", "warning", "info")}
        data["round_due_before_min"] = f.get("round_due_before_min", 0)
        data["round_overdue"] = f.get("round_overdue") == "1"
        data["capa_remind"] = f.get("capa_remind") == "1"
        data["daily_summary"] = {"enabled": f.get("summary.enabled") == "1", "time": f.get("summary.time", "17:00")}
        data["round_start"] = {"enabled": f.get("rs.enabled") == "1", "freqs": f.getlist("rs.freqs"),
                               "channels": f.getlist("rs.channels"), "use_l1_groups": f.get("rs.use_l1_groups") == "1"}
        data["weekly_approval"] = {"enabled": f.get("wa.enabled") == "1", "weekday": f.get("wa.weekday", 0),
                                   "time": f.get("wa.time", "08:30")}
        try:
            N.save_settings(db, data, current_user_id())
            db.commit()
            flash("บันทึกการตั้งค่าแล้ว", "ok")
            return redirect(url_for("work.admin_notify"))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
    stats = {r["status"]: r["n"] for r in db.execute(
        "SELECT status, COUNT(*) n FROM cs_msg_outbox WHERE created_at >= ? GROUP BY status",
        ((datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S"),))}
    return render_template("admin/notify.html", cfg=N.get_settings(db, with_secrets=False), stats=stats,
                           FREQ_LABEL=N.FREQ_LABEL, CHANNEL_TH=N.CHANNEL_TH, CHANNELS=N.CHANNELS, WEEKDAY_TH=N.WEEKDAY_TH,
                           n_approvers=len(N.approvers(db)),
                           base_url=current_app.config.get("BASE_URL", ""))


@bp.route("/admin/notify/test", methods=["POST"])
@require_role("admin")
def admin_notify_test():
    db = get_db()
    data = request.get_json(silent=True) or request.form
    try:
        N.send_test(db, data.get("channel", ""), data.get("target", ""))
        return jsonify({"ok": True, "message": "ส่งข้อความทดสอบแล้ว — ตรวจดูที่ปลายทาง"})
    except N.SendError as exc:
        return jsonify({"error": str(exc)}), 400


@bp.route("/admin/notify/summary-now", methods=["POST"])
@require_role("admin")
def admin_summary_now():
    db = get_db()
    N.daily_summary(db, base_url=current_app.config.get("BASE_URL", ""), force=True)
    db.commit()
    N.wake()
    flash("เข้าคิวส่งสรุปประจำวันไปยังกลุ่มหลักของทุกช่องทางที่เปิดไว้แล้ว", "ok")
    return redirect(url_for("work.admin_outbox"))


@bp.route("/admin/notify/weekly-approval-now", methods=["POST"])
@require_role("admin")
def admin_wkappr_now():
    """v0.38 ส่งเตือนผู้อนุมัติเรื่องผลตรวจที่ยังไม่อนุมัติทันที (ทดสอบ)"""
    db = get_db()
    res = N.weekly_approval_reminders(db, base_url=current_app.config.get("BASE_URL", ""), force=True)
    db.commit()
    N.wake()
    flash(f"ส่งเตือนผู้อนุมัติแล้ว {res['wk_appr']} คน" if res["wk_appr"] else "ไม่มีผลตรวจค้างอนุมัติของสัปดาห์ก่อน ๆ — ไม่ได้ส่ง", "ok")
    return redirect(url_for("work.admin_notify"))


@bp.route("/admin/outbox")
@require_role("admin")
def admin_outbox():
    db = get_db()
    status = request.args.get("status", "")
    cond, params = ("WHERE status=?", [status]) if status in ("pending", "sent", "failed") else ("", [])
    rows = [dict(r) for r in db.execute(f"SELECT * FROM cs_msg_outbox {cond} ORDER BY id DESC LIMIT 300", params)]
    counts = {r["status"]: r["n"] for r in db.execute("SELECT status, COUNT(*) n FROM cs_msg_outbox GROUP BY status")}
    return render_template("admin/outbox.html", rows=rows, status=status, counts=counts)


@bp.route("/admin/outbox/<int:msg_id>/retry", methods=["POST"])
@require_role("admin")
def admin_outbox_retry(msg_id):
    db = get_db()
    N.retry_message(db, msg_id)
    db.commit()
    N.wake()
    flash("เข้าคิวส่งใหม่แล้ว", "ok")
    return redirect(url_for("work.admin_outbox"))


@bp.route("/admin/escalation", methods=["GET", "POST"])
@require_role("admin")
def admin_escalation():
    db = get_db()
    factories = M.list_factories(db)
    fid = _int(request.values.get("factory"))
    if request.method == "POST":
        if request.form.get("action") == "reset" and fid:
            N.reset_factory_levels(db, fid, current_user_id())
            db.commit()
            flash("โรงงานนี้กลับไปใช้ค่ารวมแล้ว", "ok")
            return redirect(url_for("work.admin_escalation", factory=fid))
        try:
            levels = json.loads(request.form.get("payload") or "[]")
            if not isinstance(levels, list):
                raise ValueError
            N.save_levels(db, fid, levels, current_user_id())
            db.commit()
            flash("บันทึกลำดับการส่งต่อแล้ว", "ok")
            return redirect(url_for("work.admin_escalation", factory=fid or None))
        except ValueError:
            db.rollback()
            flash("ข้อมูลไม่ถูกต้อง", "error")
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
    own = bool(fid and db.execute("SELECT 1 FROM cs_esc_levels WHERE factory_id=?", (fid,)).fetchone())
    levels = N.get_levels(db, fid)
    by_level = {lv["level"]: lv for lv in levels}
    rows = [by_level.get(n) or {"level": n, "after_min": {1: 0, 2: 30, 3: 120}[n], "min_severity": "warning",
                                "active": 0, "recipients": []} for n in (1, 2, 3)]
    # ตัวอย่างผู้รับจริงของแต่ละระดับ (ให้เห็นว่าบทบาทแปลเป็นใครบ้าง)
    cfg = N.get_settings(db)
    preview = {r["level"]: N.level_recipients(db, r, fid, cfg) if r.get("recipients") else {"users": [], "groups": []}
               for r in rows}
    return render_template("admin/escalation.html", factories=factories, factory_id=fid, own=own, rows=rows,
                           users=_users(db), preview=preview, cfg=N.get_settings(db, with_secrets=False))


@bp.route("/admin/silences", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def silences():
    db = get_db()
    if request.method == "POST":
        try:
            N.save_silence(db, request.form.to_dict(), current_user_id())
            db.commit()
            flash("ตั้งช่วงเงียบแล้ว — แจ้งเตือนในช่วงนี้จะบันทึกไว้แต่ไม่ส่งออก", "ok")
            return redirect(url_for("work.silences"))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
    now = datetime.now()
    return render_template("admin/silences.html", rows=N.list_silences(db, include_past=request.args.get("all") == "1"),
                           factories=M.list_factories(db), equipment=M.list_equipment(db), forms=list_forms(db),
                           now=now, default_start=now.strftime("%Y-%m-%dT%H:%M"),
                           default_end=(now + timedelta(hours=8)).strftime("%Y-%m-%dT%H:%M"),
                           show_all=request.args.get("all") == "1", data=request.form)


@bp.route("/admin/silences/<int:sid>/cancel", methods=["POST"])
@require_role(*MANAGE_ROLES)
def silence_cancel(sid):
    db = get_db()
    N.cancel_silence(db, sid, current_user_id())
    db.commit()
    flash("ยกเลิกช่วงเงียบแล้ว", "ok")
    return redirect(url_for("work.silences"))
