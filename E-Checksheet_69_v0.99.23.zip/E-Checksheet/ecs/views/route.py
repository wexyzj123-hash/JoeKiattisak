"""ecs/views/route.py — เส้นทางเดินตรวจ (หน้าจัดการ + หน้ามือถือ + API)"""
from __future__ import annotations

from flask import Blueprint, abort, flash, jsonify, redirect, render_template, request, url_for

from .. import masterdata as M
from .. import services as S
from .. import walkroutes as R
from ..db import get_db
from ..security import INSPECT_ROLES, MANAGE_ROLES, current_user_id, require_role

bp = Blueprint("route", __name__)


def _ids(values) -> list[int]:
    out = []
    for v in values:
        for p in str(v).split(","):
            if p.strip().isdigit():
                out.append(int(p))
    return out


@bp.route("/routes")
@require_role(*MANAGE_ROLES)
def routes():
    db = get_db()
    rows = []
    for r in R.list_routes(db, include_inactive=True):
        st = R.route_status(db, r["id"]) if r["active"] else None
        rows.append({**r, "st": st})
    return render_template("routes/list.html", routes=rows)


def _form_choices(db):
    return [f for f in S.list_forms(db) if not f.get("is_template") and f["current_version_id"]]


@bp.route("/routes/new", methods=["GET", "POST"])
@bp.route("/routes/<int:route_id>", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def route_edit(route_id=None):
    db = get_db()
    route = R.get_route(db, route_id) if route_id else None
    if route_id and not route:
        abort(404)
    if request.method == "POST":
        try:
            rid = R.save_route(db, request.form.to_dict(), _ids(request.form.getlist("stops")), current_user_id(), route_id)
            db.commit()
            flash("บันทึกเส้นทางแล้ว", "ok")
            return redirect(url_for("route.route_edit", route_id=rid))
        except S.ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
            route = {**(route or {}), **request.form.to_dict(),
                     "stops": [{"form_id": i} for i in _ids(request.form.getlist("stops"))]}
    status = R.route_status(db, route_id) if route_id else None
    forms = _form_choices(db)
    return render_template("routes/edit.html", route=route, forms=forms, factories=M.list_factories(db),
                           status=status, CAT=S.form_category, cats=sorted({S.form_category(f) for f in forms}, key=str.lower))


@bp.route("/routes/<int:route_id>/delete", methods=["POST"])
@require_role(*MANAGE_ROLES)
def route_delete(route_id):
    db = get_db()
    R.delete_route(db, route_id, current_user_id())
    db.commit()
    flash("ลบเส้นทางแล้ว (ผลตรวจยังอยู่ครบ)", "ok")
    return redirect(url_for("route.routes"))


# ── มือถือ ──

@bp.route("/m/route")
@require_role(*INSPECT_ROLES)
def m_route():
    return render_template("mobile/route.html")


@bp.route("/api/m/routes")
@require_role(*INSPECT_ROLES)
def api_routes():
    from ..submissions import user_scope
    db = get_db()
    S.generate_rounds(db)
    S.refresh_round_statuses(db)
    db.commit()
    return jsonify({"routes": R.routes_for_user(db, user_scope(db, current_user_id()))})


@bp.route("/api/m/routes/<int:route_id>")
@require_role(*INSPECT_ROLES)
def api_route(route_id):
    db = get_db()
    S.refresh_round_statuses(db)
    db.commit()
    st = R.route_status(db, route_id)
    if not st:
        return jsonify({"error": "ไม่พบเส้นทาง"}), 404
    r = R.get_route(db, route_id)
    me = _me()
    if r.get("owner_id") is not None and r["owner_id"] != me["id"] and me["role"] not in ("admin", "supervisor"):
        return jsonify({"error": "ไม่พบเส้นทาง"}), 404                 # เส้นทางส่วนตัวของคนอื่น
    st["can_edit"] = R.can_edit(r, me)
    st["mine"] = r.get("owner_id") == me["id"]
    return jsonify(st)


# ── v0.30 ช่างสร้าง/แก้เส้นทางของตัวเองบนมือถือ ──

def _me():
    from ..submissions import user_scope
    return user_scope(get_db(), current_user_id())


@bp.route("/m/route/edit")
@require_role(*INSPECT_ROLES)
def m_route_edit():
    return render_template("mobile/route_edit.html")


@bp.route("/api/m/route-forms")
@require_role(*INSPECT_ROLES)
def api_route_forms():
    return jsonify(R.form_catalog(get_db(), _me()))


@bp.route("/api/m/routes/<int:route_id>/edit")
@require_role(*INSPECT_ROLES)
def api_route_get(route_id):
    db = get_db()
    r = R.get_route(db, route_id)
    if not r or not R.can_edit(r, _me()):
        return jsonify({"error": "แก้ไขได้เฉพาะเส้นทางของคุณเอง"}), 403
    return jsonify({"id": r["id"], "name": r["name"], "description": r["description"] or "",
                    "stops": [s["form_id"] for s in r["stops"]], "mine": r.get("owner_id") is not None})


@bp.route("/api/m/routes/save", methods=["POST"])
@require_role(*INSPECT_ROLES)
def api_route_save():
    db = get_db()
    me = _me()
    d = request.get_json(silent=True) or {}
    rid = d.get("id")
    rid = int(rid) if str(rid or "").isdigit() else None
    manager = me["role"] in ("admin", "supervisor")
    if rid:
        r = R.get_route(db, rid)
        if not r or not R.can_edit(r, me):
            return jsonify({"error": "แก้ไขได้เฉพาะเส้นทางของคุณเอง"}), 403
        data = {"name": d.get("name"), "description": d.get("description"), "factory_id": r["factory_id"], "active": r["active"]}
    else:
        data = {"name": d.get("name"), "description": d.get("description"), "factory_id": me.get("factory_id"), "active": 1}
    try:
        rid = R.save_route(db, data, _ids(d.get("stops") or []), me["id"], rid,
                           owner_id=None if rid else me["id"],
                           allowed_factory=None if manager else me.get("factory_id"))
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0]}), 400
    return jsonify({"ok": True, "id": rid})


@bp.route("/api/m/routes/<int:route_id>/delete", methods=["POST"])
@require_role(*INSPECT_ROLES)
def api_route_delete(route_id):
    db = get_db()
    r = R.get_route(db, route_id)
    if not r or not R.can_edit(r, _me()) or r.get("owner_id") is None and _me()["role"] not in ("admin", "supervisor"):
        return jsonify({"error": "ลบได้เฉพาะเส้นทางของคุณเอง"}), 403
    R.delete_route(db, route_id, current_user_id())
    db.commit()
    return jsonify({"ok": True})
