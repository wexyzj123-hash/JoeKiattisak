"""ecs/views/forms_builder_api.py — แยกจาก forms.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

from flask import jsonify, request
from .. import services as S
from ..db import get_db
from ..security import current_user_id
from .. import perms as PM   # v0.52 สิทธิ์แก้ไขแบบฟอร์มรายคน

from .forms import bp, _load_form  # noqa: E402


# ── builder API ──

@bp.route("/api/forms/<int:form_id>/import-items", methods=["POST"])
@PM.require_form("edit")
def api_import_items(form_id):
    """อ่านไฟล์ PDF / Excel / CSV / TXT → ข้อความหัวข้อ (ให้ตรวจแก้ในกล่อง "วางหลายหัวข้อ" ก่อนเพิ่ม)"""
    from ..item_import import ImportError_, extract
    _load_form(get_db(), form_id)
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "กรุณาเลือกไฟล์"}), 400
    data = f.read(25 * 1024 * 1024 + 1)
    if len(data) > 25 * 1024 * 1024:
        return jsonify({"error": "ไฟล์ใหญ่เกิน 25 MB"}), 400
    try:
        return jsonify(extract(f.filename, data))
    except ImportError_ as exc:
        return jsonify({"error": str(exc)}), 400


@bp.route("/api/forms/<int:form_id>/draft", methods=["GET"])
@PM.require_form("edit")
def api_draft_get(form_id):
    db = get_db()
    form = _load_form(db, form_id)
    current = S.get_items(db, form["current_version_id"]) if form["current_version_id"] else []
    draft = S.get_draft(db, form_id)
    items = S.get_items(db, draft["id"]) if draft else current
    if not draft:
        for it in items:
            it.pop("id", None)
    from ..itemfreq import get_calendar
    src_version = draft["id"] if draft else form["current_version_id"]
    return jsonify({"form": form, "draft": draft, "version_id": draft["id"] if draft else None,
                    "items": items, "published_keys": [i["item_key"] for i in current],
                    "sections": S.get_sections(db, src_version, items), "calendar": get_calendar(db),
                    "schedules": [{"freq_type": s["freq_type"], "times": s["times"]}
                                  for s in S.list_schedules(db, form_id) if s["active"]]})


@bp.route("/api/forms/<int:form_id>/draft", methods=["PUT"])
@PM.require_form("edit")
def api_draft_save(form_id):
    db = get_db()
    _load_form(db, form_id)
    payload = request.get_json(silent=True) or {}
    if S.get_form(db, form_id).get("template_id"):
        return jsonify({"error": "แบบฟอร์มนี้ใช้แม่แบบ — แก้หัวข้อที่แม่แบบ"}), 409
    draft = S.get_draft(db, form_id)
    sent = payload.get("version_id")
    # กันเขียนทับกัน: หน้าที่เปิดค้างไว้ถือร่างเก่า/ร่างถูก Publish ไปแล้ว → ให้รีเฟรชก่อน
    if (draft and sent and int(sent) != draft["id"]) or (not draft and sent):
        return jsonify({"error": "ฉบับร่างถูกเปลี่ยนโดยผู้อื่น กรุณารีเฟรชหน้า"}), 409
    try:
        if not draft:
            draft = S.get_or_create_draft(db, form_id, current_user_id())
        count = S.save_draft_items(db, draft["id"], payload.get("items") or [], current_user_id())
        if "sections" in payload:
            S.save_sections(db, draft["id"], payload.get("sections"))
        if not PM.form_access(db, current_user_id(), form_id)["publish"]:
            PM.notify_draft(db, form_id, current_user_id())       # v0.52 แจ้งผู้ดูแลให้ตรวจและ Publish
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        return jsonify({"error": "ข้อมูลไม่ถูกต้อง", "errors": exc.errors}), 422
    return jsonify({"success": True, "count": count, "version_id": draft["id"], "saved_at": S.ts()})


@bp.route("/api/forms/<int:form_id>/publish", methods=["POST"])
@PM.require_form("publish")
def api_publish(form_id):
    db = get_db()
    _load_form(db, form_id)
    draft = S.get_draft(db, form_id)
    if not draft:
        return jsonify({"error": "ไม่มีฉบับร่างให้ Publish"}), 400
    try:
        body = request.get_json(silent=True) or {}
        version = S.publish_version(db, draft["id"], current_user_id(), body.get("note", ""),
                                    body.get("effective_date"), body.get("approved_by_name", ""))
        synced = 0
        if S.get_form(db, form_id).get("is_template"):
            from .. import formtpl as T
            synced = T.sync_all(db, form_id, current_user_id(), body.get("note", ""))
        S.generate_rounds(db)
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0], "errors": exc.errors}), 422
    return jsonify({"success": True, "version_no": version["version_no"], "synced": synced})


@bp.route("/api/forms/<int:form_id>/discard", methods=["POST"])
@PM.require_form("edit")
def api_discard(form_id):
    db = get_db()
    _load_form(db, form_id)
    try:
        S.discard_draft(db, form_id, current_user_id())
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0]}), 422
    return jsonify({"success": True})
