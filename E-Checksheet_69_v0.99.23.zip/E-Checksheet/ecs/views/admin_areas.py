"""ecs/views/admin_areas.py — แยกจาก admin.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

from flask import (abort, current_app, flash, jsonify, redirect, render_template, request, url_for)
from .. import masterdata as M
from ..db import get_db
from ..security import MANAGE_ROLES, current_user_id, require_role
from ..services import ValidationError

from .admin import bp, _flash_errors, _int  # noqa: E402


# ───────────────────────── ผังโรงงาน ─────────────────────────

@bp.route("/admin/layout")
@require_role("admin")
def layout():
    db = get_db()
    factories = M.list_factories(db)
    if not factories:
        return redirect(url_for("admin.locations"))
    fid = _int(request.args.get("factory")) or factories[0]["id"]
    factory = next((f for f in factories if f["id"] == fid), factories[0])
    from ..analytics import area_status
    from datetime import date
    areas = area_status(db, date.today(), factory["id"])
    return render_template("admin/layout.html", factories=factories, factory=factory, areas=areas)


@bp.route("/admin/layout/<int:factory_id>", methods=["POST"])
@require_role("admin")
def layout_upload(factory_id):
    db = get_db()
    try:
        if request.form.get("action") == "remove":
            M.set_factory_layout(db, factory_id, None, current_app.config["UPLOAD_FOLDER"], current_user_id())
            flash("ลบผังแล้ว — Dashboard จะแสดงเป็นผังแบบกล่องแทน", "ok")
        else:
            f = request.files.get("layout")
            M.set_factory_layout(db, factory_id, f.read(M.MAX_LAYOUT_BYTES + 1) if f else b"",
                                 current_app.config["UPLOAD_FOLDER"], current_user_id())
            flash("อัปโหลดผังแล้ว — เลือกพื้นที่ทางขวา แล้วคลิกบนผังเพื่อวางหมุด", "ok")
        db.commit()
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("admin.layout", factory=factory_id))


@bp.route("/admin/areas/<int:area_id>", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def area_detail(area_id):
    """จัดการพื้นที่: เลือกเครื่องจักร / แบบฟอร์มที่มีอยู่แล้วเข้าพื้นที่ → แสดงบนผังพื้นที่และสถานะทันที"""
    from ..services import get_form, set_equipment_location, sync_forms_to_equipment
    db = get_db()
    area = db.execute("""SELECT a.*, f.name AS factory_name FROM areas a JOIN factories f ON f.id=a.factory_id
                         WHERE a.id=?""", (area_id,)).fetchone()
    if not area:
        abort(404)
    area = dict(area)
    if request.method == "POST":
        act = request.form.get("action", "")
        ids = [int(x) for x in request.form.getlist("ids") if str(x).isdigit()]
        n = 0
        if act == "add_eq":
            for eid in ids:
                if db.execute("SELECT 1 FROM equipment WHERE id=?", (eid,)).fetchone():
                    set_equipment_location(db, eid, area["factory_id"], area_id, current_user_id())
                    n += 1
            flash(f"เพิ่มเครื่องจักร {n} เครื่องเข้าพื้นที่ {area['name']} แล้ว (แบบฟอร์มของเครื่องย้ายตามให้อัตโนมัติ)", "ok")
        elif act == "remove_eq":
            for eid in ids:
                row = db.execute("SELECT factory_id FROM equipment WHERE id=? AND area_id=?", (eid, area_id)).fetchone()
                if row:
                    set_equipment_location(db, eid, row["factory_id"], None, current_user_id())
                    n += 1
            flash(f"นำเครื่องจักรออกจากพื้นที่ {n} เครื่อง", "ok")
        elif act in ("add_form", "remove_form"):
            for fid in ids:
                form = get_form(db, fid)
                if not form or form["equipment_id"]:
                    continue                       # แบบฟอร์มที่ผูกเครื่อง ย้ายผ่านเครื่องจักรเท่านั้น
                new_area = area_id if act == "add_form" else None
                db.execute("UPDATE cs_forms SET factory_id=?, area_id=?, updated_at=? WHERE id=?",
                           (area["factory_id"] if act == "add_form" else form["factory_id"], new_area, _now(), fid))
                n += 1
            flash(("เพิ่ม" if act == "add_form" else "นำออก") + f"แบบฟอร์ม {n} รายการ", "ok")
        sync_forms_to_equipment(db)
        db.commit()
        return redirect(url_for("admin.area_detail", area_id=area_id))
    in_eq = M.list_equipment(db, area_id=area_id)
    candidates = [e for e in M.list_equipment(db) if e["area_id"] != area_id
                  and (e["factory_id"] in (None, area["factory_id"]))]
    others = [e for e in M.list_equipment(db) if e["factory_id"] not in (None, area["factory_id"])]
    loose_in = [dict(r) for r in db.execute("""SELECT id, code, name FROM cs_forms
                    WHERE area_id=? AND equipment_id IS NULL ORDER BY code""", (area_id,))]
    loose_out = [dict(r) for r in db.execute("""SELECT f.id, f.code, f.name, a.name AS area_name FROM cs_forms f
                    LEFT JOIN areas a ON a.id=f.area_id WHERE f.equipment_id IS NULL AND IFNULL(f.area_id, 0)<>?
                    AND (f.factory_id IS NULL OR f.factory_id=?) ORDER BY f.code""", (area_id, area["factory_id"]))]
    forms_by_eq = {}
    for r in db.execute("SELECT id, code, name, equipment_id FROM cs_forms WHERE equipment_id IS NOT NULL ORDER BY code"):
        forms_by_eq.setdefault(r["equipment_id"], []).append(dict(r))
    from ..analytics import area_status
    from datetime import date
    st = next((a for a in area_status(db, date.today(), area["factory_id"]) if a["id"] == area_id), None)
    return render_template("admin/area_detail.html", area=area, in_eq=in_eq, candidates=candidates, others=others,
                           loose_in=loose_in, loose_out=loose_out, forms_by_eq=forms_by_eq, st=st,
                           areas=M.list_areas(db, area["factory_id"]))


def _now():
    from ..services import ts
    return ts()


@bp.route("/api/areas/<int:area_id>/pin", methods=["POST"])
@require_role("admin")
def area_pin(area_id):
    db = get_db()
    data = request.get_json(silent=True) or {}
    try:
        if data.get("clear"):
            M.set_area_pin(db, area_id, None, None, current_user_id())
        else:
            M.set_area_pin(db, area_id, data.get("x"), data.get("y"), current_user_id())
        db.commit()
    except ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0]}), 400
    return jsonify({"ok": True})
