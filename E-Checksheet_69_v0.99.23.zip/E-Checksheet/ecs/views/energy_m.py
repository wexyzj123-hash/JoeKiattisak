"""ecs/views/energy_m.py — Energy Data v0.64: จดมิเตอร์หน้างาน (มือถือ · ออฟไลน์ · QR · รูปหน้าปัด · อ่านเลขจากรูป)

/m/energy                  หน้าจดมิเตอร์ (หน้าเดียว ใช้ต่อได้แม้สัญญาณหลุด — ค่าเก็บในเครื่องแล้วส่งเมื่อมีสัญญาณ)
/q/<token>                 QR ที่ติดมิเตอร์ → เปิดมิเตอร์ตัวนั้นในหน้าจด
/api/m/energy/pack         ข้อมูลมิเตอร์ + ค่าที่ควรเป็น + ประวัติ 7 วัน (เก็บในเครื่อง)
/api/m/energy/submit       บันทึก: อ่านค่า / อ่านไม่ได้ / เปลี่ยนมิเตอร์ (+ รูป) — ส่งซ้ำได้ผลเดิม
/api/m/energy/ocr-box      จำกรอบตัวเลขบนรูปของมิเตอร์ (อ่านเลขครั้งหน้าแม่นขึ้น)
"""
from __future__ import annotations

import json

from flask import Blueprint, current_app, jsonify, redirect, render_template, request, url_for

from .. import energy_field as EF
from .. import services as S
from ..db import get_db
from ..security import INSPECT_ROLES, current_user_id, require_role

bp = Blueprint("energy_m", __name__)


@bp.route("/m/energy")
@require_role(*INSPECT_ROLES)
def home():
    return render_template("mobile/energy.html", now_date=S.now_dt().date().isoformat())


@bp.route("/q/<token>")
@require_role(*INSPECT_ROLES)
def qr(token):
    db = get_db()
    m = EF.by_token(db, token[:40])
    if not m:
        return render_template("error.html", code=404, message="ไม่พบมิเตอร์ของป้าย QR นี้ (อาจถูกลบ/เปลี่ยนป้าย)"), 404
    return redirect(url_for("energy_m.home") + f"#m={m['id']}")


@bp.route("/api/m/energy/pack")
@require_role(*INSPECT_ROLES)
def api_pack():
    db = get_db()
    data = EF.pack(db, current_user_id(), request.args.get("factory", type=int))
    db.commit()                                           # สร้างรหัส QR ให้มิเตอร์ที่ยังไม่มี
    resp = jsonify(data)
    resp.headers["Cache-Control"] = "no-store"
    return resp


@bp.route("/api/m/energy/submit", methods=["POST"])
@require_role(*INSPECT_ROLES)
def api_submit():
    db = get_db()
    try:
        payload = json.loads(request.form.get("payload") or (request.get_data(as_text=True) if request.is_json else "{}") or "{}")
    except ValueError:
        return jsonify({"error": "ข้อมูลที่ส่งมาไม่ถูกต้อง"}), 400
    try:
        res = EF.submit(db, payload, dict(request.files.items()), current_user_id(), current_app.config["UPLOAD_FOLDER"],
                        current_app.config)
        if payload.get("box") and payload.get("meter_id"):
            EF.save_ocr_box(db, int(payload["meter_id"]), payload.get("box"), current_user_id())
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0], "errors": exc.errors}), 422
    return jsonify(res)


@bp.route("/api/m/energy/ocr-box", methods=["POST"])
@require_role(*INSPECT_ROLES)
def api_ocr_box():
    db = get_db()
    body = request.get_json(silent=True) or {}
    from .. import energy as EN
    m = EN.meter(db, int(body.get("meter_id") or 0))
    if not m or not EF.can_touch(db, current_user_id(), m):
        return jsonify({"error": "ไม่พบมิเตอร์"}), 404
    EF.save_ocr_box(db, m["id"], body.get("box"), current_user_id())
    db.commit()
    return jsonify({"ok": True})
