"""ecs/views/forms_requests.py — แยกจาก forms.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

from flask import abort, flash, jsonify, redirect, render_template, request, session, url_for
from .. import services as S
from ..db import get_db
from ..security import MANAGE_ROLES, current_user_id, require_role

from .forms import bp, _factory_arg  # noqa: E402


# ───────────────────────── v0.28 คำขอแก้ไขแบบฟอร์ม · ประเภทหัวข้อที่เพิ่มเอง ─────────────────────────

@bp.route("/forms/change-requests")
@require_role(*MANAGE_ROLES)
def change_requests():
    from .. import change_requests as CR
    db = get_db()
    status = request.args.get("status", "active")
    fac = session.get("factory_id") if session.get("role") == "supervisor" else _factory_arg()
    rows = CR.listing(db, status, form_id=_int_arg("form"), factory_id=fac)
    counts = {k: len(CR.listing(db, k, factory_id=fac)) for k in ("active", "open", "accepted", "done", "rejected")}
    return render_template("forms/change_requests.html", rows=rows, status=status, counts=counts, KINDS=CR.KINDS,
                           STATUS_TH=CR.STATUS_TH, sel=None)


@bp.route("/forms/change-requests/<int:cid>", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def change_request_detail(cid):
    from .. import change_requests as CR
    db = get_db()
    c = CR.get(db, cid)
    if not c:
        abort(404)
    if request.method == "POST":
        try:
            CR.set_status(db, cid, request.form.get("status", ""), current_user_id(), request.form.get("reply", ""))
            db.commit()
            flash("อัปเดตคำขอแล้ว — แจ้งผู้ขอในกระดิ่งแล้ว", "ok")
        except CR.ChangeError as e:
            flash(str(e), "error")
        return redirect(url_for("forms.change_request_detail", cid=cid))
    form = S.get_form(db, c["form_id"])
    edit_id = form.get("template_id") or form["id"]
    return render_template("forms/change_requests.html", rows=[c], status="", counts=None, KINDS=CR.KINDS,
                           STATUS_TH=CR.STATUS_TH, sel=c, edit_url=url_for("forms.builder", form_id=edit_id, item=c["item_key"] or None),
                           is_tpl_child=bool(form.get("template_id")))


@bp.route("/forms/item-types", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def item_types():
    from .. import change_requests as CR
    db = get_db()
    if request.method == "POST":
        try:
            if request.form.get("delete"):
                CR.delete_preset(db, int(request.form["delete"]), current_user_id())
                flash("ลบประเภทแล้ว (หัวข้อที่ใช้อยู่ไม่เปลี่ยน)", "ok")
            else:
                labels, ngs = request.form.getlist("opt_label"), set(request.form.getlist("opt_ng"))
                opts = [{"label": l, "ng": str(i) in ngs} for i, l in enumerate(labels)]
                CR.save_preset(db, {**request.form.to_dict(), "options": opts}, current_user_id(),
                               int(request.form.get("id") or 0) or None)
                flash("บันทึกประเภทแล้ว — เลือกใช้ได้ในช่อง \"ประเภท\" ของ Builder", "ok")
            db.commit()
        except (CR.ChangeError, ValueError) as e:
            flash(str(e), "error")
        return redirect(url_for("forms.item_types"))
    return render_template("forms/item_types.html", presets=CR.presets(db), edit=_int_arg("edit"))


@bp.route("/api/item-presets", methods=["POST"])
@require_role(*MANAGE_ROLES)
def api_item_presets():
    from .. import change_requests as CR
    db = get_db()
    try:
        CR.save_preset(db, request.get_json(silent=True) or {}, current_user_id())
        db.commit()
    except CR.ChangeError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"ok": True, "presets": CR.presets(db)})


def _int_arg(name):
    try:
        return int(request.args.get(name) or 0) or None
    except ValueError:
        return None
