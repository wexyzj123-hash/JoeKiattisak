"""ecs/views/energy_report.py — แยกจาก energy.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

from flask import (Response, flash, redirect, render_template, request, url_for)
from .. import energy_ops as OPS
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import ValidationError, now_dt

from .energy import bp, LEAD, _ctx, _is_lead, _kind, _sf  # noqa: E402


# ───────────────────────── รายงาน ─────────────────────────

@bp.route("/report")
@require_role(*ALL_ROLES)
def report():
    db = get_db()
    facs = M.list_factories(db)
    tab = "cost" if request.args.get("tab") == "cost" else "sections"
    year = request.args.get("year", type=int) or now_dt().year
    fid = request.args.get("factory", type=int) or (facs[0]["id"] if facs and tab == "sections" else None)
    kind = _kind(request.args.get("kind"), allow_empty=False) if request.args.get("kind") else "elec"
    sf = _sf()
    by = "line" if request.args.get("by") == "line" else "section"
    rep = OPS.section_report(db, fid, kind, year, by=by, **sf) if tab == "sections" and fid else None
    fc = dict(rep["facets"]) if rep else {"projects": [], "sections": [], "lines": []}
    if sf["grp"]:
        fc["lines"] = [x for x in fc["lines"] if x["section"] == ("" if sf["grp"] == "-" else sf["grp"])]
    cost = OPS.cost_report(db, year, fid) if tab == "cost" else None
    return render_template("energy/report.html", **_ctx(tab=tab, year=year, fid=fid, kind=kind, rep=rep, cost=cost, sf=sf, fc=fc, by=by,
                                                      can_edit=_is_lead()))


@bp.route("/report/sections.xlsx")
@require_role(*ALL_ROLES)
def report_xlsx():
    db = get_db()
    fid = request.args.get("factory", type=int)
    kind = _kind(request.args.get("kind"), allow_empty=False)
    year = request.args.get("year", type=int) or now_dt().year
    if not fid:
        return redirect(url_for("energy.report"))
    data = OPS.section_xlsx(db, fid, kind, year, by="line" if request.args.get("by") == "line" else "section", **_sf())
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="energy_sections_{kind}_F{fid}_{year}.xlsx"'})


@bp.route("/report/cost", methods=["POST"])
@require_role(*LEAD)
def report_cost_save():
    db = get_db()
    act = request.form.get("act")
    try:
        if act == "bill":
            OPS.save_bill(db, request.form, current_user_id())
            msg = "บันทึกบิลค่าไฟแล้ว"
        elif act == "bill_del":
            OPS.del_bill(db, request.form.get("id", type=int) or 0, current_user_id())
            msg = "ลบบิลแล้ว"
        elif act == "prod":
            OPS.save_production(db, request.form, current_user_id())
            msg = "บันทึกยอดผลิตแล้ว"
        else:
            raise ValidationError("คำสั่งไม่ถูกต้อง")
        db.commit()
        flash(msg, "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy.report", tab="cost", year=request.form.get("year") or None,
                            factory=request.form.get("view_factory") or None))
