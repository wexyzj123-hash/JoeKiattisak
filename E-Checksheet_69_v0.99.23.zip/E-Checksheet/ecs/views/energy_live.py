"""ecs/views/energy_live.py — v0.87 Dashboard รายช่วงเวลา (ทุก 15 นาที) แยกแท็บ ไฟฟ้า / ลมอัด / น้ำ"""
from __future__ import annotations

from datetime import date, timedelta

from flask import Blueprint, render_template, request

from .. import energy as EN
from .. import energy_live as LV
from .. import energy_struct as ST
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, require_role
from ..services import now_dt
from .energy import _ctx

bp = Blueprint("energy_live", __name__, url_prefix="/energy/live")


@bp.route("/")
@require_role(*ALL_ROLES)
def page():
    db = get_db()
    today = now_dt().date()
    kind = request.args.get("kind") if request.args.get("kind") in LV.LIVE_KINDS else "elec"
    try:
        day = min(date.fromisoformat(request.args.get("day") or ""), today)
    except ValueError:
        day = today
    fid = request.args.get("factory", type=int) or None
    project_id = request.args.get("project", type=int) or None
    grp = (request.args.get("grp") or "")[:80] or None
    line = (request.args.get("line") or "")[:80] or None
    cmp = "week" if request.args.get("cmp") == "week" else "yday"
    d = LV.data(db, kind, day, fid, project_id, grp, line, cmp)
    # ตัวเลือกตัวกรอง (เฉพาะหมวดนี้)
    base = EN.meters(db, fid, kind, True)
    fc_all = ST.facets(base)
    fc_p = ST.facets(ST.apply_filter(base, project_id)) if project_id else fc_all
    fc_s = ST.facets(ST.apply_filter(base, project_id, grp)) if grp else fc_p
    facs = M.list_factories(db)
    crumbs = [{"label": "ทุกโรงงาน", "q": {}}]
    q: dict = {}
    if fid:
        q = {"factory": fid}
        crumbs.append({"label": next((f["name"] for f in facs if f["id"] == fid), f"#{fid}"), "q": dict(q)})
    if project_id:
        q = {**q, "project": project_id}
        crumbs.append({"label": next((p["name"] for p in fc_all["projects"] if p["id"] == project_id), "ยังไม่กำหนด Project"), "q": dict(q)})
    if grp:
        q = {**q, "grp": grp}
        crumbs.append({"label": "ไม่ระบุ Section" if grp == "-" else grp, "q": dict(q)})
    if line:
        q = {**q, "line": line}
        crumbs.append({"label": "ไม่ระบุ Line" if line == "-" else line, "q": dict(q)})
    return render_template("energy/live.html", **_ctx(
        d=d, kind=kind, day=day, today=today, fid=fid, project_id=project_id, grp=grp, line=line, cmp=cmp, crumbs=crumbs, filt=q,
        facs=facs, fc_p=fc_all["projects"], fc_s=fc_p["sections"], fc_l=[x for x in fc_s["lines"] if not grp or x["section"] == ("" if grp == "-" else grp)],
        live_kinds=LV.LIVE_KINDS, with_data=LV.has_intervals(db), prev=day - timedelta(days=1), nxt=day + timedelta(days=1)))
