"""ecs/views/auth.py — เข้าสู่ระบบ, ตั้งค่าผู้ดูแลคนแรก, เปลี่ยนรหัสผ่าน"""
from __future__ import annotations

from flask import Blueprint, flash, make_response, redirect, render_template, request, session, url_for

from .. import cmms_bridge as CB
from .. import masterdata as M
from ..db import get_db
from ..security import hash_password, needs_rehash, require_role, safe_next, verify_password
from ..services import ValidationError, audit, ts

bp = Blueprint("auth", __name__)

_FAILED: dict[str, list[float]] = {}     # กันเดารหัส: จำครั้งที่ผิดต่อ username+IP (ในหน่วยความจำ)
MAX_FAILS, WINDOW_SEC = 8, 600


def _throttled(key: str) -> bool:
    import time
    now = time.time()
    attempts = [t for t in _FAILED.get(key, []) if now - t < WINDOW_SEC]
    _FAILED[key] = attempts
    return len(attempts) >= MAX_FAILS


def _record_fail(key: str) -> None:
    import time
    _FAILED.setdefault(key, []).append(time.time())


@bp.route("/login", methods=["GET", "POST"])
def login():
    db = get_db()
    linked = CB.enabled()
    if M.count_users(db) == 0 and not linked:
        return redirect(url_for("auth.setup"))
    if "user_id" in session and request.method == "GET":
        return redirect(safe_next(request.values.get("next"), url_for("index")))
    next_url = safe_next(request.values.get("next"), url_for("index"))
    error = ""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        key = f"{username.lower()}|{request.remote_addr}"
        if _throttled(key):
            error = "ใส่รหัสผ่านผิดหลายครั้ง กรุณารอ 10 นาทีแล้วลองใหม่"
        else:
            cu = CB.cmms_check_password(username, password) if linked else None
            if cu:                                   # บัญชี UT-CMMS → login ทั้งสองระบบพร้อมกัน
                _FAILED.pop(key, None)
                try:
                    user = CB.link_user(db, cu)
                except CB.LinkError as exc:
                    return render_template("login.html", error=str(exc), next_url=next_url)
                if not user["active"]:
                    return render_template("login.html", error="บัญชีนี้ถูกปิดการใช้งาน E-Checksheet", next_url=next_url)
                CB.start_session(user, cu["id"])
                resp = make_response(redirect(next_url))
                CB.set_cmms_cookie(resp, cu)
                return resp
            user = db.execute("SELECT * FROM users WHERE username=? AND active=1", (username,)).fetchone()
            if user and linked and user["legacy_id"]:
                user = None                          # ผู้ใช้ที่ผูกกับ UT-CMMS ต้องใช้รหัสของ UT-CMMS เท่านั้น
            if user and verify_password(user["password"], password):
                _FAILED.pop(key, None)
                if needs_rehash(user["password"]):
                    db.execute("UPDATE users SET password=? WHERE id=?", (hash_password(password), user["id"]))
                db.execute("UPDATE users SET last_login_at=? WHERE id=?", (ts(), user["id"]))
                audit(db, user["id"], "login", "users", user["id"])
                db.commit()
                session.clear()
                session.update(user_id=user["id"], role=user["role"], name=user["name"],
                               factory_id=user["factory_id"], must_change_pw=bool(user["must_change_pw"]))
                return redirect(next_url)
            _record_fail(key)
            error = "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"
    return render_template("login.html", error=error, next_url=next_url)


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    if CB.enabled():                             # ออกจากระบบทั้ง UT-CMMS และ E-Checksheet
        resp = make_response(redirect(CB.home_url()))
        CB.clear_cmms_cookie(resp)
        return resp
    return redirect(url_for("auth.login"))


@bp.route("/setup", methods=["GET", "POST"])
def setup():
    """สร้างผู้ดูแลระบบคนแรก — ใช้ได้เฉพาะตอนที่ยังไม่มีผู้ใช้ในระบบ"""
    db = get_db()
    if M.count_users(db) > 0 or CB.enabled():
        return redirect(url_for("auth.login"))
    errors = []
    if request.method == "POST":
        data = request.form.to_dict()
        data.update(role="admin", must_change_pw=0, active=1)
        if data.get("password") != data.get("confirm"):
            errors.append("ยืนยันรหัสผ่านไม่ตรงกัน")
        else:
            try:
                uid = M.save_user(db, data, None)
                db.commit()
                session.clear()
                session.update(user_id=uid, role="admin", name=data["name"], factory_id=None, must_change_pw=False)
                flash("สร้างผู้ดูแลระบบแล้ว เริ่มจากเพิ่มเครื่องจักรและผู้ใช้", "ok")
                return redirect(url_for("admin.equipment"))
            except ValidationError as exc:
                db.rollback()
                errors = exc.errors
    return render_template("setup.html", errors=errors, form=request.form)


@bp.route("/account/password", methods=["GET", "POST"])
@require_role()
def password():
    if session.get("cmms_uid"):
        flash("บัญชีนี้ใช้รหัสผ่านร่วมกับ UT-CMMS — เปลี่ยนรหัสผ่านได้ที่เมนูบัญชีผู้ใช้ของ UT-CMMS", "ok")
        return redirect(url_for("index"))
    db = get_db()
    if request.method == "POST":
        try:
            M.change_own_password(db, session["user_id"], request.form.get("current", ""),
                                  request.form.get("new", ""), request.form.get("confirm", ""))
            db.commit()
            session["must_change_pw"] = False
            flash("เปลี่ยนรหัสผ่านแล้ว", "ok")
            return redirect(url_for("index"))
        except ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
    return render_template("password.html", forced=session.get("must_change_pw"))
