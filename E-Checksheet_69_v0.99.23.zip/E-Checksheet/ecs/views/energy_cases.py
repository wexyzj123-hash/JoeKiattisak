"""ecs/views/energy_cases.py — แยกจาก energy.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

from datetime import date, timedelta
from flask import (flash, redirect, render_template, request, url_for)
from .. import energy as EN
from .. import energy_ops as OPS
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import ValidationError, now_dt

from .energy import bp, ENTRY_ROLES, _ctx, _kind  # noqa: E402


# ───────────────────────── ความผิดปกติ + เคส ─────────────────────────

@bp.route("/anomalies")
@require_role(*ALL_ROLES)
def anomalies():
    db = get_db()
    fid = request.args.get("factory", type=int) or None
    kind = _kind(request.args.get("kind"))
    tab = "cases" if request.args.get("tab") == "cases" else "scan"
    days = request.args.get("days", 30, type=int)
    days = days if days in (7, 14, 30, 60, 90) else 30
    rule = request.args.get("rule") if request.args.get("rule") in OPS.RULES else None
    res = st = None
    if tab == "scan":
        res = OPS.scan(db, fid, kind, days)
        if rule:
            res["items"] = [x for x in res["items"] if x["rule"] == rule]
    st = request.args.get("status") or "active"
    cs = OPS.cases(db, st if tab == "cases" else "active", fid, kind)
    return render_template("energy/anomalies.html", **_ctx(res=res, cs=cs, tab=tab, fid=fid, kind=kind, days=days, rule=rule,
                                                         status=st, summ=OPS.case_summary(db, fid), can_case=_is_entry()))


def _is_entry() -> bool:
    from ..security import current_role
    return current_role() in ENTRY_ROLES


@bp.route("/cases/open", methods=["POST"])
@require_role(*ENTRY_ROLES)
def case_open():
    db = get_db()
    try:
        cid = OPS.open_case(db, request.form, current_user_id())
        db.commit()
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return redirect(request.referrer or url_for("energy.anomalies"))
    flash("เปิดเคสติดตามแล้ว", "ok")
    return redirect(url_for("energy.case_detail", cid=cid))


@bp.route("/cases/<int:cid>", methods=["GET", "POST"])
@require_role(*ALL_ROLES)
def case_detail(cid):
    db = get_db()
    c = OPS.case(db, cid)
    if not c:
        return render_template("error.html", code=404, message="ไม่พบเคส"), 404
    if request.method == "POST":
        if not _is_entry():
            return render_template("error.html", code=403, message="ไม่มีสิทธิ์แก้ไขเคส"), 403
        try:
            OPS.update_case(db, cid, request.form, current_user_id())
            db.commit()
            flash("บันทึกเคสแล้ว", "ok")
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
        return redirect(url_for("energy.case_detail", cid=cid))
    det = None
    if c["meter_id"]:
        m = EN.meter(db, c["meter_id"])
        if m:
            d0 = date.fromisoformat(c["day"])
            d_from, d_to = d0 - timedelta(days=20), min(d0 + timedelta(days=10), now_dt().date())
            s = EN.series(db, [m], d_from, d_to)[m["id"]]
            dl = EN._days(d_from, d_to)
            det = {"days": dl, "u": [None if (s.get(x) or {}).get("u") is None else round(s[x]["u"], 2) for x in dl],
                   "label": EN.label(m), "unit": m["unit"], "color": EN.KINDS[m["kind"]]["color"], "mark": c["day"]}
    return render_template("energy/case.html", **_ctx(c=c, det=det, causes=OPS.CAUSES, users=OPS.assignees(db),
                                                    can_case=_is_entry()))
