"""ecs/views/energy_forms_ui.py — แยกจาก energy.py (v0.99.1) · ใช้ Blueprint เดิม จึงไม่มีผลต่อ URL / endpoint"""
from __future__ import annotations

from flask import (flash, jsonify, redirect, render_template, request, url_for)
from .. import energy as EN
from .. import energy_field as EF
from ..db import get_db
from ..security import current_user_id, require_role
from ..services import ValidationError

from .energy import bp, ENTRY_ROLES, _ctx, _facs_scope  # noqa: E402


# ───────────────────────── แบบฟอร์มการจด (ออกแบบเอง) ─────────────────────────

@bp.route("/forms")
@require_role(*ENTRY_ROLES)
def forms():
    from .. import energy_forms as FM
    db = get_db()
    fs = FM.forms(db, current_user_id())
    for f in fs:
        f["can_edit"] = FM.can_edit(db, current_user_id(), f)
    return render_template("energy/forms.html", **_ctx(forms=fs))


@bp.route("/forms/new")
@bp.route("/forms/<int:form_id>")
@require_role(*ENTRY_ROLES)
def form_builder(form_id=None):
    from .. import energy_forms as FM
    db = get_db()
    sc = EF.user_scope(db, current_user_id())
    f = FM.form(db, form_id) if form_id else None
    if form_id and not f:
        return render_template("error.html", code=404, message="ไม่พบแบบฟอร์ม"), 404
    fid = (f or {}).get("factory_id") or sc["factory_id"] or request.args.get("factory", type=int)
    if not f:
        facs = _facs_scope(db)
        fid = fid or (facs[0]["id"] if facs else None)
        f = {"id": None, "name": "", "factory_id": fid, "note": "", "active": 1, "sort_no": 0,
             "items": FM.from_sections(db, fid) if request.args.get("draft") == "1" else []}
    ms = [{"id": m["id"], "label": EN.label(m), "kind": m["kind"], "grp": m["grp"], "loc": m.get("location") or "",
           "factory_id": m["factory_id"], "factory": m["factory_name"] or "", "unit": m["unit"]}
          for m in EN.meters(db, sc["factory_id"])]
    its = [{k: i.get(k) for k in ("type", "meter_id", "title", "photo", "hint")} for i in f["items"]]
    return render_template("energy/form_builder.html", **_ctx(f=f, items_json=its, meters_json=ms, facs_scope=_facs_scope(db),
                                                            can_edit=FM.can_edit(db, current_user_id(), f if f.get("id") else None)))


@bp.route("/forms/save", methods=["POST"])
@bp.route("/forms/<int:form_id>/save", methods=["POST"])
@require_role(*ENTRY_ROLES)
def form_save(form_id=None):
    from .. import energy_forms as FM
    db = get_db()
    body = request.get_json(silent=True) or {}
    try:
        nid = FM.save(db, form_id, body, current_user_id())
        db.commit()
    except ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0]}), 422
    return jsonify({"ok": True, "id": nid, "url": url_for("energy.form_builder", form_id=nid)})


@bp.route("/forms/<int:form_id>/act", methods=["POST"])
@require_role(*ENTRY_ROLES)
def form_act(form_id):
    from .. import energy_forms as FM
    db = get_db()
    try:
        if request.form.get("act") == "delete":
            FM.delete(db, form_id, current_user_id())
            db.commit()
            flash("ลบแบบฟอร์มแล้ว", "ok")
            return redirect(url_for("energy.forms"))
        nid = FM.copy(db, form_id, current_user_id())
        db.commit()
        flash("คัดลอกแบบฟอร์มแล้ว", "ok")
        return redirect(url_for("energy.form_builder", form_id=nid))
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return redirect(url_for("energy.forms"))
