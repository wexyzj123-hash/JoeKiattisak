"""ecs/db.py — การเชื่อมต่อ SQLite (1 connection ต่อ request)"""
from __future__ import annotations

import os
import sqlite3

from flask import current_app, g


def connect(path: str) -> sqlite3.Connection:
    con = sqlite3.connect(path, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")      # อ่านพร้อมกันได้ไม่บล็อกกัน
    con.execute("PRAGMA busy_timeout=15000")    # รอคิวเขียนแทนการ error 'database is locked'
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def close_db(_exc=None) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_app(app) -> None:
    from .schema import ensure_schema
    os.makedirs(os.path.dirname(app.config["DATABASE"]), exist_ok=True)
    con = connect(app.config["DATABASE"])
    try:
        ensure_schema(con)
    finally:
        con.close()
    app.teardown_appcontext(close_db)
