"""ecs/shiftsign.py — v0.54 ลงนามรับทราบ / ลงนามย้อนหลัง ในใบบันทึกรายเดือน

แถวผู้ตรวจ (Tech) กะกลางวัน / กะกลางคืน (หรือแถวผู้ตรวจรายวัน) ช่องที่ว่างเพราะไม่มีผลตรวจในกะนั้น:
  - "รับทราบ" — ช่างกะนั้น (หรือกะถัดไป) ลงนามรับทราบสถานะเครื่องของกะนั้น → ลายเซ็นขึ้นในช่อง
  - "กรอกข้อมูลย้อนหลัง" — เปิดหน้ากรอกของรอบที่ขาด (ลงช่องของวัน/เวลารอบนั้น นับเป็นตรวจล่าช้า) แล้วลายเซ็นขึ้นตามผลตรวจ
ทุกการลงนามบันทึกเวลาที่ลงจริง + Audit · ย้อนหลังได้ไม่เกิน MAX_BACK_DAYS วัน · ยกเลิกได้โดยเจ้าของ/หัวหน้างาน
"""
from __future__ import annotations

import calendar
from datetime import date, datetime, timedelta

from . import services as S
from .services import ts

DDL = """
CREATE TABLE IF NOT EXISTS cs_sheet_acks (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id    INTEGER NOT NULL REFERENCES cs_forms(id),
    day        TEXT NOT NULL,                -- YYYY-MM-DD
    shift      TEXT NOT NULL DEFAULT 'all',  -- day | night | all
    user_id    INTEGER NOT NULL REFERENCES users(id),
    note       TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE (form_id, day, shift, user_id)
);
CREATE INDEX IF NOT EXISTS idx_csack_form ON cs_sheet_acks(form_id, day);
"""
MAX_BACK_DAYS = 62
SHIFT_TH = {"day": "กะกลางวัน", "night": "กะกลางคืน", "all": "ทั้งวัน"}


def ensure(db) -> None:
    db.executescript(DDL)


def acks_for(db, form_id: int, month: date) -> dict[tuple[int, str], list[tuple]]:
    """{(วันที่, กะ): [(user_id, ชื่อย่อ)]}"""
    ensure(db)
    from .sheet_report import _short
    last = calendar.monthrange(month.year, month.month)[1]
    out: dict[tuple[int, str], list[tuple]] = {}
    for r in db.execute("""SELECT a.day, a.shift, a.user_id, u.name FROM cs_sheet_acks a JOIN users u ON u.id=a.user_id
                           WHERE a.form_id=? AND a.day BETWEEN ? AND ? ORDER BY a.created_at""",
                        (form_id, month.replace(day=1).isoformat(), month.replace(day=last).isoformat())):
        out.setdefault((int(r["day"][8:10]), r["shift"]), []).append((r["user_id"], _short(r["name"])))
    return out


def merge_into(sheet: dict, acks: dict) -> None:
    """ใส่ลายเซ็นรับทราบลงช่องผู้ตรวจของใบบันทึก (แถวรายกะ หรือแถวรายวัน)"""
    ins = (sheet.get("signs") or {}).get("insp") or {}
    if ins.get("shifts"):
        for sh in ins["shifts"]:
            cells = sh.get("cells") or []
            for (d, k), ppl in acks.items():
                if k == sh["key"] and 0 < d <= len(cells):
                    for p in ppl:
                        if p not in cells[d - 1]:
                            cells[d - 1].append(p)
    else:
        for c in sheet.get("days") or []:
            for p in acks.get((c["day"], "all"), []):
                if p not in c["insp"]:
                    c["insp"].append(p)
            c["inspectors"] = "/".join(n for _u, n in c["insp"])


def missing(db, form_id: int, month: date) -> list[dict]:
    """ช่องผู้ตรวจที่ยังว่าง (ไม่มีผลตรวจ / ไม่มีรับทราบ / ไม่ใช่วันหยุด-เครื่องหยุด) + รอบที่กรอกย้อนหลังได้"""
    from . import sign_blocks as SB
    from .itemfreq import get_calendar
    from .sheet_report import build_month_sheet
    sh = build_month_sheet(db, form_id, month, "x")
    cal = get_calendar(db)
    today = S.now_dt().date()
    ins = sh["signs"]["insp"] or {}
    keys = [(x["key"], x.get("cells") or [], x.get("down") or [], x.get("times") or "") for x in ins.get("shifts") or []]
    if not keys:
        if ins.get("segs"):
            return []                                       # ช่องผู้ตรวจรวมรายสัปดาห์/เดือน — ไม่ใช่รายวัน
        keys = [("all", [c["insp"] for c in sh["days"]], [], "")]
    last = sh["last_day"]
    first = datetime(month.year, month.month, 1)
    rounds: dict[tuple[int, str], list[dict]] = {}
    for r in db.execute("""SELECT r.id, r.due_at, r.deadline_at, r.status FROM cs_rounds r JOIN cs_schedules s ON s.id=r.schedule_id
                           WHERE r.form_id=? AND s.active=1 AND r.submission_id IS NULL AND r.status IN ('missed','overdue','pending','in_progress')
                             AND r.due_at>=? AND r.due_at<? AND r.due_at<=?""",
                        (form_id, ts(first), ts(first + timedelta(days=last)), ts(S.now_dt()))):
        t = S.parse_ts(r["due_at"])
        k = SB.shift_of(t.hour * 60 + t.minute, cal) if ins.get("shifts") else "all"
        rounds.setdefault((t.day, k), []).append(dict(r))
    out = []
    for d in range(1, last + 1):
        dd = date(month.year, month.month, d)
        c = sh["days"][d - 1]
        if dd > today or c["state"] in ("off", "down", "future") or (today - dd).days > MAX_BACK_DAYS:
            continue
        for k, cells, downs, times in keys:
            if (cells[d - 1] if d - 1 < len(cells) else []) or (downs[d - 1] if d - 1 < len(downs) else None):
                continue
            out.append({"day": dd, "shift": k, "shift_th": SHIFT_TH[k], "times": times,
                        "rounds": rounds.get((d, k), [])})
    return out


def sign(db, form_id: int, day: date, shift: str, user_id: int, note: str = "") -> int:
    ensure(db)
    if shift not in SHIFT_TH:
        raise S.ValidationError("กะไม่ถูกต้อง")
    today = S.now_dt().date()
    if day > today:
        raise S.ValidationError("ลงนามล่วงหน้าไม่ได้")
    if (today - day).days > MAX_BACK_DAYS:
        raise S.ValidationError(f"ลงนามย้อนหลังได้ไม่เกิน {MAX_BACK_DAYS} วัน")
    if not db.execute("SELECT 1 FROM cs_forms WHERE id=?", (form_id,)).fetchone():
        raise S.ValidationError("ไม่พบแบบฟอร์ม")
    if db.execute("SELECT 1 FROM cs_sheet_acks WHERE form_id=? AND day=? AND shift=? AND user_id=?",
                  (form_id, day.isoformat(), shift, user_id)).fetchone():
        raise S.ValidationError("คุณลงนามช่องนี้แล้ว")
    aid = db.execute("""INSERT INTO cs_sheet_acks(form_id, day, shift, user_id, note, created_at) VALUES (?,?,?,?,?,?)""",
                     (form_id, day.isoformat(), shift, user_id, (note or "").strip()[:300], ts(S.now_dt()))).lastrowid
    S.audit(db, user_id, "sheet_ack", "cs_sheet_acks", aid,
            after={"form_id": form_id, "day": day.isoformat(), "shift": shift, "note": note,
                   "backdated_days": (today - day).days})
    return aid


def unsign(db, aid: int, actor_id: int, role: str) -> None:
    ensure(db)
    r = db.execute("SELECT * FROM cs_sheet_acks WHERE id=?", (aid,)).fetchone()
    if not r:
        raise S.ValidationError("ไม่พบการลงนาม")
    if r["user_id"] != actor_id and role not in ("admin", "supervisor"):
        raise S.ValidationError("ยกเลิกได้เฉพาะผู้ลงนามหรือหัวหน้างาน")
    db.execute("DELETE FROM cs_sheet_acks WHERE id=?", (aid,))
    S.audit(db, actor_id, "sheet_unack", "cs_sheet_acks", aid, before=dict(r))


def my_acks(db, form_id: int, month: date) -> list[dict]:
    ensure(db)
    last = calendar.monthrange(month.year, month.month)[1]
    return [dict(r) for r in db.execute("""SELECT a.*, u.name AS user_name FROM cs_sheet_acks a JOIN users u ON u.id=a.user_id
                                           WHERE a.form_id=? AND a.day BETWEEN ? AND ? ORDER BY a.day, a.shift""",
                                        (form_id, month.replace(day=1).isoformat(), month.replace(day=last).isoformat()))]
