"""ecs/formula.py — v0.95 หัวข้อคำนวณ (item_type = "calc")

สูตรอ้างหัวข้อตัวเลขในแบบฟอร์มเดียวกันด้วย {item_key} เช่น  {p_in} - {p_out}  ·  ({t_out} - {t_in}) * 1.8
รองรับ  + - * / ( ) ตัวเลข  และฟังก์ชัน abs min max avg round sqrt
ไม่ใช้ eval — แยกคำเอง (ปลอดภัย) · ตัวแปลงฝั่งมือถือ (static/m/fill.js) ใช้ไวยากรณ์เดียวกัน
"""
from __future__ import annotations

import math
import re

FUNCS = {"abs": (1, 1), "min": (1, 20), "max": (1, 20), "avg": (1, 20), "round": (1, 2), "sqrt": (1, 1)}
_TOKEN = re.compile(r"\s*(?:(\d+(?:\.\d+)?|\.\d+)|\{([A-Za-z0-9_\-]+)\}|([A-Za-z_]+)|(.))")
MAX_LEN = 300


class FormulaError(ValueError):
    pass


def _tokens(expr: str) -> list[tuple[str, str]]:
    out, pos, s = [], 0, (expr or "").strip()
    if not s:
        raise FormulaError("ยังไม่ได้ใส่สูตร")
    if len(s) > MAX_LEN:
        raise FormulaError(f"สูตรยาวเกิน {MAX_LEN} ตัวอักษร")
    while pos < len(s):
        m = _TOKEN.match(s, pos)
        if not m or m.end() == pos:
            break
        pos = m.end()
        num, ref, name, op = m.groups()
        if num is not None:
            out.append(("num", num))
        elif ref is not None:
            out.append(("ref", ref))
        elif name is not None:
            if name.lower() not in FUNCS:
                raise FormulaError(f"ไม่รู้จักฟังก์ชัน '{name}' (ใช้ได้: {', '.join(FUNCS)})")
            out.append(("fn", name.lower()))
        elif op is not None and op.strip():
            if op not in "+-*/(),":
                raise FormulaError(f"ใช้เครื่องหมาย '{op}' ในสูตรไม่ได้")
            out.append(("op", op))
    return out


class _P:
    """recursive descent → AST (tuple)"""

    def __init__(self, toks):
        self.t, self.i = toks, 0

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None)

    def take(self, kind=None, val=None):
        k, v = self.peek()
        if k is None or (kind and k != kind) or (val and v != val):
            raise FormulaError("สูตรไม่สมบูรณ์" if k is None else f"สูตรผิดตรง '{v}'")
        self.i += 1
        return v

    def expr(self):
        node = self.term()
        while self.peek() in (("op", "+"), ("op", "-")):
            node = ("bin", self.take(), node, self.term())
        return node

    def term(self):
        node = self.factor()
        while self.peek() in (("op", "*"), ("op", "/")):
            node = ("bin", self.take(), node, self.factor())
        return node

    def factor(self):
        k, v = self.peek()
        if (k, v) in (("op", "-"), ("op", "+")):
            self.take()
            f = self.factor()
            return ("neg", f) if v == "-" else f
        if k == "num":
            self.take()
            return ("num", float(v))
        if k == "ref":
            self.take()
            return ("ref", v)
        if k == "fn":
            self.take()
            self.take("op", "(")
            args = [self.expr()]
            while self.peek() == ("op", ","):
                self.take()
                args.append(self.expr())
            self.take("op", ")")
            lo, hi = FUNCS[v]
            if not lo <= len(args) <= hi:
                raise FormulaError(f"ฟังก์ชัน {v} ใส่ค่าได้ {lo}–{hi} ค่า")
            return ("fn", v, args)
        if (k, v) == ("op", "("):
            self.take()
            node = self.expr()
            self.take("op", ")")
            return node
        raise FormulaError("สูตรไม่สมบูรณ์" if k is None else f"สูตรผิดตรง '{v}'")


def parse(expr: str):
    p = _P(_tokens(expr))
    node = p.expr()
    if p.i != len(p.t):
        raise FormulaError(f"สูตรผิดตรง '{p.t[p.i][1]}'")
    return node


def refs(expr: str) -> list[str]:
    out: list[str] = []

    def walk(n):
        if n[0] == "ref" and n[1] not in out:
            out.append(n[1])
        elif n[0] == "bin":
            walk(n[2]); walk(n[3])
        elif n[0] == "neg":
            walk(n[1])
        elif n[0] == "fn":
            for a in n[2]:
                walk(a)
    walk(parse(expr))
    return out


def _ev(n, vals):
    t = n[0]
    if t == "num":
        return n[1]
    if t == "ref":
        v = vals.get(n[1])
        if v is None:
            raise KeyError(n[1])
        return float(v)
    if t == "neg":
        return -_ev(n[1], vals)
    if t == "bin":
        a, b = _ev(n[2], vals), _ev(n[3], vals)
        if n[1] == "+":
            return a + b
        if n[1] == "-":
            return a - b
        if n[1] == "*":
            return a * b
        if b == 0:
            raise ZeroDivisionError
        return a / b
    f, args = n[1], [_ev(a, vals) for a in n[2]]
    if f == "abs":
        return abs(args[0])
    if f == "min":
        return min(args)
    if f == "max":
        return max(args)
    if f == "avg":
        return sum(args) / len(args)
    if f == "round":
        return round(args[0], int(args[1]) if len(args) > 1 else 0)
    if args[0] < 0:
        raise ValueError
    return math.sqrt(args[0])


def compute(expr: str, values: dict) -> float | None:
    """คืนผลลัพธ์ (ปัด 4 ตำแหน่ง) · None = ยังขาดค่าที่อ้างถึง / หารศูนย์ / ค่าไม่ถูกต้อง"""
    try:
        v = _ev(parse(expr), values)
    except (KeyError, ZeroDivisionError, ValueError, OverflowError, FormulaError):
        return None
    if math.isnan(v) or math.isinf(v):
        return None
    return round(v, 4)


def check(expr: str, own_key: str, items: list[dict]) -> list[str]:
    """ตรวจสูตรของหัวข้อ own_key: อ้างได้เฉพาะหัวข้อตัวเลข/มิเตอร์/คำนวณอื่นในแบบฟอร์มเดียวกัน · ห้ามวนกลับมาที่ตัวเอง"""
    try:
        rs = refs(expr)
    except FormulaError as exc:
        return [str(exc)]
    if not rs:
        return ["สูตรต้องอ้างอย่างน้อย 1 หัวข้อ เช่น {key}"]
    by = {i["item_key"]: i for i in items}
    errs = []
    for r in rs:
        it = by.get(r)
        if not it:
            errs.append(f"สูตรอ้างหัวข้อ {{{r}}} ที่ไม่มีในแบบฟอร์ม")
        elif it.get("item_type") not in ("number", "counter", "calc"):
            errs.append(f"สูตรอ้าง “{it.get('name')}” ซึ่งไม่ใช่หัวข้อตัวเลข")
    if errs:
        return errs
    if own_key in rs:
        return ["สูตรอ้างตัวเองไม่ได้"]
    seen, stack = set(rs), list(rs)                    # วนซ้ำ (A ใช้ B, B ใช้ A)
    while stack:
        it = by.get(stack.pop())
        if not it or it.get("item_type") != "calc" or not it.get("formula"):
            continue
        try:
            nxt = refs(it["formula"])
        except FormulaError:
            continue
        for r in nxt:
            if r == own_key:
                return ["สูตรวนกลับมาอ้างตัวเอง"]
            if r not in seen:
                seen.add(r)
                stack.append(r)
    return []


def rename_refs(expr: str, mapping: dict) -> str:
    return re.sub(r"\{([A-Za-z0-9_\-]+)\}", lambda m: "{" + mapping.get(m.group(1), m.group(1)) + "}", expr or "")


def compute_all(items: list[dict], values: dict) -> dict:
    """คำนวณหัวข้อ calc ทั้งแบบฟอร์ม (calc อ้าง calc ได้ — วนจนนิ่ง) · values = {item_key: ตัวเลข} ของหัวข้อที่กรอก"""
    vals = {k: v for k, v in values.items() if v is not None}
    calcs = [i for i in items if i.get("item_type") == "calc" and i.get("formula")]
    out: dict = {}
    for _ in range(len(calcs) + 1):
        changed = False
        for it in calcs:
            if it["item_key"] in out:
                continue
            v = compute(it["formula"], vals)
            if v is not None:
                out[it["item_key"]] = vals[it["item_key"]] = v
                changed = True
        if not changed:
            break
    return out
