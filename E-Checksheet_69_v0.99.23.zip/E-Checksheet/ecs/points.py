"""ecs/points.py — ยืนยันว่าไปตรวจที่จุดจริง: สแกน QR ที่ติดไว้ ณ จุดตรวจ ก่อนกรอกหัวข้อของจุดนั้น

รหัสจุด (6 ตัว) คำนวณจาก HMAC(SECRET_KEY, แบบฟอร์ม + ชื่อจุด) — ไม่ต้องเก็บในฐานข้อมูล
- แต่ละเครื่อง (แบบฟอร์ม) ได้รหัสไม่ซ้ำกัน แม้ใช้แม่แบบเดียวกัน → ป้ายของเครื่อง A ใช้กับเครื่อง B ไม่ได้
- เปลี่ยนชื่อจุดตรวจ = รหัสใหม่ ต้องพิมพ์ป้ายใหม่
- แพ็กเกจที่ส่งให้มือถือมีแค่ค่า SHA-256 ของรหัส (ใช้ตรวจตอนออฟไลน์) ไม่มีรหัสจริง
QR = {base}/p/<form_id>/<รหัส> → เปิดหน้ากรอกและยืนยันจุดนั้นทันที · สแกนไม่ได้ พิมพ์รหัสใต้ QR แทนได้
"""
from __future__ import annotations

import hashlib
import hmac
import json

ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"      # ตัดตัวที่สับสนง่าย (0/O, 1/I/L)
CODE_LEN = 6


def _secret() -> bytes:
    try:
        from flask import current_app
        return str(current_app.secret_key or "").encode()
    except RuntimeError:                            # นอก app context (สคริปต์)
        from .settings import secret_key
        return secret_key().encode()


def point_code(form_id: int, section: str, secret: bytes | None = None) -> str:
    digest = hmac.new(secret or _secret(), f"pt:{form_id}:{section or ''}".encode(), hashlib.sha256).digest()
    n = int.from_bytes(digest[:8], "big")
    out = ""
    for _ in range(CODE_LEN):
        n, r = divmod(n, len(ALPHABET))
        out += ALPHABET[r]
    return out


def code_hash(code: str) -> str:
    return hashlib.sha256(normalize(code).encode()).hexdigest()


def normalize(code: str) -> str:
    """รับได้ทั้งรหัสเปล่า และ URL จาก QR (…/p/<form>/<code>)"""
    code = str(code or "").strip()
    if "/p/" in code:
        code = code.rstrip("/").rsplit("/", 1)[-1]
    return code.upper().replace(" ", "").replace("-", "")[:12]


def verify(form_id: int, section: str, code: str) -> bool:
    return hmac.compare_digest(point_code(form_id, section), normalize(code))


def check_scans(form_id: int, sections_answered: list[str], scans) -> tuple[list[dict], list[str]]:
    """คืน (บันทึกการสแกนที่ถูกต้อง [{section, at}], จุดที่ยังไม่ได้สแกน)"""
    ok: dict[str, str] = {}
    for s in scans or []:
        if not isinstance(s, dict):
            continue
        sec = str(s.get("section") or "")
        if sec in sections_answered and sec not in ok and verify(form_id, sec, s.get("code")):
            ok[sec] = str(s.get("at") or "")[:19]
    missing = [s for s in sections_answered if s not in ok]
    return [{"section": k, "at": v} for k, v in ok.items()], missing


def dumps(scans: list[dict]) -> str:
    return json.dumps(scans, ensure_ascii=False) if scans else ""


def loads(text: str | None) -> list[dict]:
    try:
        v = json.loads(text or "[]")
        return v if isinstance(v, list) else []
    except ValueError:
        return []


def label_list(db, forms: list[dict], base: str) -> list[dict]:
    """ป้ายจุดตรวจของแบบฟอร์มที่ให้มา (เฉพาะที่ Publish แล้ว) — [{form, sec, code, url}] เรียงตามแบบฟอร์ม › ลำดับจุด"""
    from . import services as S
    out: list[dict] = []
    for f in forms:
        if not f or not f.get("current_version_id"):
            continue
        for sec in S.get_sections(db, f["current_version_id"]):
            code = point_code(f["id"], sec["name"])
            out.append({"form": f, "sec": sec, "code": code, "url": f"{base}/p/{f['id']}/{code}"})
    return out


def scan_forms(db, equipment_ids: list[int], form_ids: list[int] | None = None) -> list[dict]:
    """แบบฟอร์มที่ตั้ง 'ต้องสแกน QR ที่จุดตรวจ' ของเครื่องที่เลือก (ใช้งานอยู่ และ Publish แล้ว)"""
    from . import services as S
    if not equipment_ids:
        return []
    ph = ",".join("?" for _ in equipment_ids)
    params: list = list(equipment_ids)
    cond = ""
    if form_ids:
        cond = f" AND id IN ({','.join('?' for _ in form_ids)})"
        params += list(form_ids)
    rows = db.execute(f"""SELECT id FROM cs_forms WHERE equipment_id IN ({ph}) AND require_point_scan=1 AND active=1
                          AND current_version_id IS NOT NULL{cond} ORDER BY equipment_id, name""", params).fetchall()
    return [S.get_form(db, r["id"]) for r in rows]
