"""ecs/walkroutes.py — เส้นทางเดินตรวจ: รวมหลายเครื่อง/แบบฟอร์มเป็นเส้นทางเดียว เรียงตามทางเดินจริง

ช่างเปิดเส้นทาง → เห็นทุกจุดพร้อมสถานะ (ถึงเวลา / เลยกำหนด / ตรวจแล้ว) → กด "ตรวจจุดถัดไป"
ส่งผลแล้วระบบพาไปเครื่องถัดไปทันที ไม่ต้องกลับหน้ารายการ
สถานะแต่ละจุดคิดจากรอบตรวจของแบบฟอร์มนั้น (รอบล่าสุดที่ถึงเวลาแล้ว) — แบบฟอร์มที่ไม่มีรอบตรวจ = "ตรวจแล้วตั้งแต่เริ่มวันทำงาน"
"""
from __future__ import annotations

from datetime import datetime, timedelta

from . import services as S
from .services import ValidationError, audit, parse_ts, ts

EARLY_MIN = 120          # เหมือนหน้างานของฉัน: เปิดตรวจก่อนเวลาได้ 2 ชม.


def list_routes(db, factory_id: int | None = None, include_inactive: bool = False, owner_id: int | None = None,
                shared_and_mine: bool = False) -> list[dict]:
    """shared_and_mine=True: เส้นทางใช้ร่วมกัน + เส้นทางส่วนตัวของ owner_id (หน้ามือถือ)"""
    where, params = ["1=1"], []
    if shared_and_mine:
        where.append("(r.owner_id IS NULL OR r.owner_id=?)")
        params.append(owner_id or 0)
    if not include_inactive:
        where.append("r.active=1")
    if factory_id:
        where.append("(r.factory_id IS NULL OR r.factory_id=?)")
        params.append(factory_id)
    rows = db.execute(f"""
        SELECT r.*, fa.name AS factory_name, ou.name AS owner_name,
               (SELECT COUNT(*) FROM cs_route_stops s JOIN cs_forms f ON f.id=s.form_id
                 WHERE s.route_id=r.id AND f.active=1) AS stop_count
        FROM cs_routes r LEFT JOIN factories fa ON fa.id=r.factory_id LEFT JOIN users ou ON ou.id=r.owner_id
        WHERE {' AND '.join(where)} ORDER BY r.owner_id IS NULL, fa.sort_no, r.name""", params).fetchall()
    return [dict(r) for r in rows]


def get_route(db, route_id: int) -> dict | None:
    r = db.execute("""SELECT r.*, fa.name AS factory_name, ou.name AS owner_name FROM cs_routes r
                      LEFT JOIN factories fa ON fa.id=r.factory_id LEFT JOIN users ou ON ou.id=r.owner_id
                      WHERE r.id=?""", (route_id,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["stops"] = [dict(x) for x in db.execute("""
        SELECT s.order_no, f.id AS form_id, f.code, f.name, f.active, f.current_version_id, f.equipment_id,
               e.code AS eq_code, e.name AS eq_name, ar.name AS area_name, COALESCE(f.category,'') AS category,
               (SELECT COUNT(*) FROM cs_form_items i WHERE i.version_id=f.current_version_id) AS item_count
        FROM cs_route_stops s JOIN cs_forms f ON f.id=s.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN areas ar ON ar.id=f.area_id
        WHERE s.route_id=? ORDER BY s.order_no""", (route_id,))]
    return d


def save_route(db, data: dict, form_ids: list[int], actor_id: int | None, route_id: int | None = None,
               owner_id: int | None = None, allowed_factory: int | None = None) -> int:
    """owner_id = เส้นทางส่วนตัวของช่าง (สร้างจากมือถือ) · allowed_factory = จำกัดแบบฟอร์มให้อยู่ในโรงงานของช่าง"""
    name = str(data.get("name") or "").strip()[:120]
    if not name:
        raise ValidationError("กรุณาระบุชื่อเส้นทาง")
    ids = []
    for fid in dict.fromkeys(form_ids):
        f = db.execute("SELECT id, is_template, factory_id FROM cs_forms WHERE id=?", (fid,)).fetchone()
        if f and allowed_factory and f["factory_id"] not in (None, allowed_factory):
            continue
        if f and not f["is_template"]:
            ids.append(f["id"])
    if not ids:
        raise ValidationError("เลือกแบบฟอร์ม/เครื่องในเส้นทางอย่างน้อย 1 รายการ")
    if len(ids) > 200:
        raise ValidationError("จุดในเส้นทางต้องไม่เกิน 200 จุด")
    try:
        factory_id = int(data.get("factory_id") or 0) or None
    except (TypeError, ValueError):
        factory_id = None
    active = 1 if data.get("active", 1) in (1, True, "1", "on", "true") else 0
    now = ts()
    if route_id:
        if not db.execute("SELECT 1 FROM cs_routes WHERE id=?", (route_id,)).fetchone():
            raise ValidationError("ไม่พบเส้นทาง")
        db.execute("UPDATE cs_routes SET name=?, description=?, factory_id=?, active=?, updated_at=? WHERE id=?",
                   (name, str(data.get("description") or "")[:500], factory_id, active, now, route_id))
        db.execute("DELETE FROM cs_route_stops WHERE route_id=?", (route_id,))
    else:
        route_id = db.execute("""INSERT INTO cs_routes(name, description, factory_id, active, created_by, created_at, updated_at, owner_id)
                                 VALUES (?,?,?,?,?,?,?,?)""",
                              (name, str(data.get("description") or "")[:500], factory_id, active, actor_id, now, now, owner_id)).lastrowid
    for n, fid in enumerate(ids, start=1):
        db.execute("INSERT INTO cs_route_stops(route_id, form_id, order_no) VALUES (?,?,?)", (route_id, fid, n))
    audit(db, actor_id, "save", "cs_routes", route_id, after={"name": name, "stops": ids})
    return route_id


def delete_route(db, route_id: int, actor_id: int | None) -> None:
    db.execute("DELETE FROM cs_route_stops WHERE route_id=?", (route_id,))
    db.execute("UPDATE cs_submissions SET route_id=NULL WHERE route_id=?", (route_id,))
    db.execute("DELETE FROM cs_routes WHERE id=?", (route_id,))
    audit(db, actor_id, "delete", "cs_routes", route_id)


def _day_start(now: datetime, db) -> datetime:
    from .itemfreq import get_calendar, parse_times
    mins = parse_times(get_calendar(db).get("day_start")) or [480]
    start = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(minutes=mins[0])
    return start if start <= now else start - timedelta(days=1)


def stop_status(db, form_id: int, now: datetime, day_start: datetime) -> dict:
    """สถานะจุด: returned | overdue | due | done | missed | upcoming | free (ไม่มีรอบ ยังไม่ได้ตรวจวันนี้)"""
    early = now + timedelta(minutes=EARLY_MIN)
    rnd = db.execute("""SELECT r.*, sb.finished_at, sb.ng_count FROM cs_rounds r
                        LEFT JOIN cs_submissions sb ON sb.id=r.submission_id
                        WHERE r.form_id=? AND r.due_at<=? ORDER BY CASE r.status WHEN 'returned' THEN 0 ELSE 1 END,
                              r.due_at DESC LIMIT 1""", (form_id, ts(early))).fetchone()
    last = db.execute("""SELECT id, finished_at, ng_count FROM cs_submissions WHERE form_id=? AND status='submitted'
                         ORDER BY finished_at DESC LIMIT 1""", (form_id,)).fetchone()
    out = {"status": "free", "round_id": None, "due_at": None, "deadline_at": None,
           "last_at": last["finished_at"] if last else None, "ng": last["ng_count"] if last else 0}
    has_sched = db.execute("SELECT 1 FROM cs_schedules WHERE form_id=? AND active=1", (form_id,)).fetchone()
    down = db.execute("""SELECT e.down_reason FROM cs_forms f JOIN equipment e ON e.id=f.equipment_id
                         WHERE f.id=? AND e.run_status='down'""", (form_id,)).fetchone()
    if down:
        out.update(status="down", down_reason=down["down_reason"])
        return out
    if rnd:
        st = rnd["status"]
        out.update(round_id=rnd["id"], due_at=rnd["due_at"], deadline_at=rnd["deadline_at"])
        if st in ("done_on_time", "done_late"):
            out.update(status="done", last_at=rnd["finished_at"], ng=rnd["ng_count"] or 0)
        elif st in ("returned", "overdue", "missed"):
            out["status"] = st
        else:
            dl = parse_ts(rnd["deadline_at"])
            out["status"] = "overdue" if dl and dl < now else "due"
        return out
    if has_sched:
        nxt = db.execute("SELECT due_at FROM cs_rounds WHERE form_id=? AND due_at>? ORDER BY due_at LIMIT 1",
                         (form_id, ts(early))).fetchone()
        if last and parse_ts(last["finished_at"]) >= day_start:
            out["status"] = "done"
        else:
            out["status"] = "upcoming"
        out["due_at"] = nxt["due_at"] if nxt else None
        return out
    if last and parse_ts(last["finished_at"]) >= day_start:
        out["status"] = "done"
    return out


TODO = ("returned", "overdue", "due", "free")


def route_status(db, route_id: int, now: datetime | None = None) -> dict | None:
    now = now or S.now_dt()
    r = get_route(db, route_id)
    if not r:
        return None
    ds = _day_start(now, db)
    stops = []
    for s in r["stops"]:
        if not s["active"] or not s["current_version_id"]:
            continue
        stops.append({**s, **stop_status(db, s["form_id"], now, ds)})
    done = sum(1 for s in stops if s["status"] == "done")
    todo = [s for s in stops if s["status"] in TODO]
    nxt = todo[0]["form_id"] if todo else None
    return {"route": {k: r[k] for k in ("id", "name", "description", "factory_name")}, "stops": stops,
            "done": done, "total": len(stops), "todo": len(todo), "next_form_id": nxt, "now": ts(now)}


def can_edit(route: dict, user: dict) -> bool:
    """หัวหน้างาน/ผู้ดูแลระบบแก้ได้ทุกเส้นทาง · ช่างแก้ได้เฉพาะเส้นทางส่วนตัวของตัวเอง"""
    if not route:
        return False
    return user.get("role") in ("admin", "supervisor") or (route.get("owner_id") is not None and route["owner_id"] == user.get("id"))


def routes_for_user(db, user: dict, now: datetime | None = None) -> list[dict]:
    out = []
    for r in list_routes(db, user.get("factory_id"), owner_id=user.get("id"), shared_and_mine=True):
        st = route_status(db, r["id"], now)
        mine = r.get("owner_id") is not None and r["owner_id"] == user.get("id")
        if st and (st["total"] or mine):
            out.append({"id": r["id"], "name": r["name"], "factory_name": r["factory_name"], "description": r["description"],
                        "done": st["done"], "total": st["total"], "todo": st["todo"], "mine": mine,
                        "can_edit": can_edit(r, user)})
    return out


def form_catalog(db, user: dict) -> dict:
    """แบบฟอร์มที่ช่างเลือกใส่เส้นทางได้ (โรงงานของตัวเอง) + หมวดหมู่ / พื้นที่ สำหรับตัวกรองบนมือถือ"""
    fac = user.get("factory_id")
    forms = []
    for f in S.list_forms(db, fac):
        if f.get("is_template") or not f["current_version_id"]:
            continue
        forms.append({"id": f["id"], "code": f["code"] or "", "name": f["name"], "eq_code": f["eq_code"] or "",
                      "eq_name": f["eq_name"] or "", "area": f["area_name"] or "", "factory": f["factory_name"] or "",
                      "category": S.form_category(f), "items": f["item_count"]})
    cats = sorted({f["category"] for f in forms}, key=lambda c: (c == "ทั่วไป", c.lower()))
    areas = sorted({f["area"] for f in forms if f["area"]}, key=str.lower)
    return {"forms": forms, "categories": cats, "areas": areas}
