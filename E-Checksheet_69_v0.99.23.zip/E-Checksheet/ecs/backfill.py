"""ecs/backfill.py — v0.55 สิทธิ์ลงข้อมูลเช็คชีทย้อนหลัง (ให้เป็นรายวัน)

รอบที่ตัดรอบแล้ว (เลย close_at) ถ้าจะกรอกผลย้อนหลัง ต้องได้รับสิทธิ์ก่อน:
  - ผู้ดูแลระบบ (admin) และหัวหน้างานระดับ FM / SV / SSV / DM — ลงย้อนหลังได้เอง และให้สิทธิ์คนอื่นได้
  - ช่าง/ผู้ใช้อื่น — ได้รับสิทธิ์ "เป็นรายวัน" เฉพาะวันที่ยังมีรอบตรวจที่ไม่ได้ลงข้อมูล
    (นับจากวันที่เปิดรอบตรวจ ย้อนหลังไม่เกิน MAX_BACK_DAYS) · เลือกทุกแบบฟอร์ม หรือเฉพาะแบบฟอร์มได้
ทุกการให้/ยกเลิกสิทธิ์ และทุกการกรอกย้อนหลังบันทึก Audit Trail
งานที่ส่งแบบออฟไลน์ (ทำเสร็จก่อนตัดรอบแล้วค่อย Sync) ไม่ถือเป็นการกรอกย้อนหลัง
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

from . import services as S
from .services import ts

DDL = """
CREATE TABLE IF NOT EXISTS cs_backfill_days (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id),
    day        TEXT NOT NULL,                 -- YYYY-MM-DD วันของรอบตรวจ (due_at)
    form_id    INTEGER NOT NULL DEFAULT 0,    -- 0 = ทุกแบบฟอร์ม
    granted_by INTEGER NOT NULL REFERENCES users(id),
    note       TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE (user_id, day, form_id)
);
CREATE INDEX IF NOT EXISTS idx_csbf_user ON cs_backfill_days(user_id, day);
"""
GRANTOR_POS = ("fm", "sv", "ssv", "dm")
MAX_BACK_DAYS = 62
DENIED = "รอบนี้ตัดรอบแล้ว — การลงข้อมูลย้อนหลังของวันนี้ต้องได้รับสิทธิ์จากผู้ดูแลระบบหรือหัวหน้างาน (FM/SV)"


def ensure(db) -> None:
    db.executescript(DDL)


def _user(db, uid):
    r = db.execute("SELECT id, role, COALESCE(position,'') AS pos, active FROM users WHERE id=?", (uid,)).fetchone()
    return dict(r) if r else None


def can_grant(db, uid) -> bool:
    u = _user(db, uid) if uid else None
    return bool(u) and (u["role"] == "admin" or u["pos"] in GRANTOR_POS)


def granted_days(db, uid, form_id: int | None = None) -> set[str]:
    """วันที่ผู้ใช้ได้รับสิทธิ์ (ทุกแบบฟอร์ม + เฉพาะแบบฟอร์มนี้)"""
    ensure(db)
    if form_id:
        q = db.execute("SELECT day FROM cs_backfill_days WHERE user_id=? AND form_id IN (0, ?)", (uid, form_id))
    else:
        q = db.execute("SELECT day FROM cs_backfill_days WHERE user_id=?", (uid,))
    return {r[0] for r in q}


def allowed(db, uid, rnd: dict | None = None) -> bool:
    """มีสิทธิ์กรอกรอบนี้ย้อนหลังหรือไม่ (rnd=None → มีสิทธิ์ใด ๆ อยู่บ้างหรือไม่)"""
    if not uid:
        return False
    if can_grant(db, uid):
        return True
    if rnd is None:
        return bool(granted_days(db, uid))
    return (rnd.get("due_at") or "")[:10] in granted_days(db, uid, rnd.get("form_id"))


def is_backfill(rnd: dict | None, finished, now) -> bool:
    """กรอกรอบที่ตัดรอบไปแล้ว และทำเสร็จหลังตัดรอบ (ไม่ใช่งานออฟไลน์ที่ทำทันเวลา / ไม่ใช่ใบที่ถูกตีกลับ)"""
    if not rnd or rnd.get("status") == "returned" or not rnd.get("close_at"):
        return False
    close = S.parse_ts(rnd["close_at"])
    return bool(close and close <= now and finished > close)


def check(db, uid, rnd, finished, now) -> None:
    if is_backfill(rnd, finished, now) and not allowed(db, uid, rnd):
        raise S.ValidationError(DENIED)


def open_days(db, form_id: int | None = None) -> list[dict]:
    """วันที่ยังมีรอบตรวจที่ตัดรอบแล้วแต่ยังไม่ได้ลงข้อมูล (เฉพาะรอบตรวจที่เปิดใช้อยู่ · ย้อนหลังไม่เกิน MAX_BACK_DAYS)
    → [{day, n, forms}] ใหม่ → เก่า"""
    now = S.now_dt()
    since = ts(now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=MAX_BACK_DAYS))
    sql = """SELECT substr(r.due_at,1,10) AS day, COUNT(*) AS n, COUNT(DISTINCT r.form_id) AS forms
             FROM cs_rounds r JOIN cs_schedules s ON s.id=r.schedule_id
             WHERE s.active=1 AND r.submission_id IS NULL AND r.status IN ('missed','overdue','pending','in_progress')
               AND r.close_at<=? AND r.due_at>=?"""
    args: list = [ts(now), since]
    if form_id:
        sql += " AND r.form_id=?"
        args.append(form_id)
    out = [dict(r) for r in db.execute(sql + " GROUP BY day ORDER BY day DESC", args)]
    for d in out:
        d["wd"] = date.fromisoformat(d["day"]).weekday()
    return out


def grant(db, user_ids: list[int], days: list[str], form_id: int, note: str, actor: int) -> int:
    """ให้สิทธิ์รายวัน — เลือกได้เฉพาะวันที่ยังมีรอบไม่ได้ลงข้อมูล"""
    ensure(db)
    if not can_grant(db, actor):
        raise S.ValidationError("ให้สิทธิ์ได้เฉพาะผู้ดูแลระบบหรือหัวหน้างาน FM/SV")
    if not user_ids:
        raise S.ValidationError("เลือกผู้ใช้อย่างน้อย 1 คน")
    if not days:
        raise S.ValidationError("เลือกวันที่อย่างน้อย 1 วัน")
    form_id = int(form_id or 0)
    if form_id and not db.execute("SELECT 1 FROM cs_forms WHERE id=?", (form_id,)).fetchone():
        raise S.ValidationError("ไม่พบแบบฟอร์ม")
    ok_days = {d["day"] for d in open_days(db, form_id or None)}
    bad = [d for d in days if d not in ok_days]
    if bad:
        raise S.ValidationError(f"วันที่ {', '.join(sorted(bad))} ไม่มีรอบตรวจที่ยังไม่ได้ลงข้อมูล — เลือกได้เฉพาะวันที่ขาดข้อมูล")
    n = 0
    stamp = ts(S.now_dt())
    for u in user_ids:
        usr = _user(db, u)
        if not usr or not usr["active"]:
            raise S.ValidationError("ไม่พบผู้ใช้")
        for d in days:
            cur = db.execute("""INSERT OR IGNORE INTO cs_backfill_days(user_id, day, form_id, granted_by, note, created_at)
                                VALUES (?,?,?,?,?,?)""", (u, d, form_id, actor, (note or "").strip()[:300], stamp))
            if cur.rowcount:
                n += 1
                S.audit(db, actor, "backfill_grant", "cs_backfill_days", cur.lastrowid,
                        after={"user_id": u, "day": d, "form_id": form_id, "note": note})
    return n


def revoke(db, gid: int, actor: int) -> None:
    ensure(db)
    if not can_grant(db, actor):
        raise S.ValidationError("ยกเลิกสิทธิ์ได้เฉพาะผู้ดูแลระบบหรือหัวหน้างาน FM/SV")
    r = db.execute("SELECT * FROM cs_backfill_days WHERE id=?", (gid,)).fetchone()
    if r:
        db.execute("DELETE FROM cs_backfill_days WHERE id=?", (gid,))
        S.audit(db, actor, "backfill_revoke", "cs_backfill_days", gid, before=dict(r))


def users(db) -> list[dict]:
    out = []
    for r in db.execute("""SELECT id, name, username, role, COALESCE(position,'') AS pos FROM users
                           WHERE active=1 ORDER BY role, name"""):
        d = dict(r)
        d["auto"] = d["role"] == "admin" or d["pos"] in GRANTOR_POS
        out.append(d)
    return out


def grants(db) -> list[dict]:
    """สิทธิ์ที่ให้ไว้ + จำนวนรอบที่ยังค้างของวันนั้น (0 = ลงครบแล้ว)"""
    ensure(db)
    rows = [dict(r) for r in db.execute("""SELECT g.*, u.name AS user_name, gb.name AS by_name, f.name AS form_name
                                            FROM cs_backfill_days g JOIN users u ON u.id=g.user_id
                                            LEFT JOIN users gb ON gb.id=g.granted_by LEFT JOIN cs_forms f ON f.id=g.form_id
                                            ORDER BY g.day DESC, u.name""")]
    left = {}
    for g in rows:
        key = (g["day"], g["form_id"])
        if key not in left:
            left[key] = next((d["n"] for d in open_days(db, g["form_id"] or None) if d["day"] == g["day"]), 0)
        g["left"] = left[key]
    return rows


def recent_backfills(db, limit: int = 30) -> list[dict]:
    return [dict(r) for r in db.execute("""SELECT a.created_at, a.entity_id, u.name AS user_name, a.after_json
                                           FROM cs_audit a LEFT JOIN users u ON u.id=a.actor_id
                                           WHERE a.action='backfill_submit' ORDER BY a.id DESC LIMIT ?""", (limit,))]


def parse_day(s: str) -> str:
    return date.fromisoformat(s).isoformat()


def missing_rounds(db, uid: int, d_from: date, d_to: date, factory_id: int | None = None, form_id: int | None = None,
                   only_allowed: bool = False, limit: int = 500) -> dict:
    """v0.58 หน้าตัวเลือกลงข้อมูลย้อนหลัง: รอบที่ตัดรอบแล้วแต่ยังไม่มีผลตรวจ (เฉพาะแบบฟอร์มที่ผู้ใช้ตรวจได้)
    → {days: [{day, rows}], total, allowed, forms, factories}"""
    from .submissions import mobile_forms
    now = S.now_dt()
    floor = now.date() - timedelta(days=MAX_BACK_DAYS)
    d_from = max(d_from, floor)
    d_to = min(d_to, now.date())
    forms = mobile_forms(db, uid)
    ids = [f["id"] for f in forms if (not factory_id or f["factory_id"] == factory_id) and (not form_id or f["id"] == form_id)]
    out = {"days": [], "total": 0, "allowed": 0, "from": d_from, "to": d_to, "truncated": False,
           "forms": sorted(forms, key=lambda f: (f["eq_code"] or f["code"] or "")),
           "factories": sorted({(f["factory_id"], f["factory_name"]) for f in forms if f["factory_id"]}, key=lambda x: x[1] or "")}
    if not ids or d_from > d_to:
        return out
    grantor = can_grant(db, uid)
    granted = {}
    if not grantor:
        ensure(db)
        for r in db.execute("SELECT day, form_id FROM cs_backfill_days WHERE user_id=?", (uid,)):
            granted.setdefault(r[0], set()).add(r[1])
    ph = ",".join("?" * len(ids))
    rows = db.execute(f"""SELECT r.id, r.form_id, r.due_at, r.deadline_at, r.close_at, r.status,
                                 f.name AS form_name, f.code AS form_code, e.code AS eq_code, e.name AS eq_name,
                                 COALESCE(e.run_status,'running') AS run_status, fa.name AS factory_name
                          FROM cs_rounds r JOIN cs_schedules s ON s.id=r.schedule_id JOIN cs_forms f ON f.id=r.form_id
                          LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN factories fa ON fa.id=f.factory_id
                          WHERE s.active=1 AND r.form_id IN ({ph}) AND r.submission_id IS NULL
                            AND r.status IN ('missed','overdue','pending','in_progress') AND r.close_at <= ?
                            AND r.due_at >= ? AND r.due_at < ?
                          ORDER BY r.due_at DESC, e.code, f.name LIMIT ?""",
                      [*ids, ts(now), ts(datetime.combine(d_from, datetime.min.time())),
                       ts(datetime.combine(d_to + timedelta(days=1), datetime.min.time())), limit + 1]).fetchall()
    if len(rows) > limit:
        rows = rows[:limit]
        out["truncated"] = True
    by: dict[str, list] = {}
    for r in rows:
        x = dict(r)
        day = x["due_at"][:10]
        g = granted.get(day, set())
        x["can"] = grantor or 0 in g or x["form_id"] in g
        if only_allowed and not x["can"]:
            continue
        out["total"] += 1
        out["allowed"] += 1 if x["can"] else 0
        by.setdefault(day, []).append(x)
    out["days"] = [{"day": date.fromisoformat(d), "rows": v, "can": sum(1 for x in v if x["can"])} for d, v in by.items()]
    out["grantor"] = grantor
    return out
