"""ecs/srcmap.py — v0.44 ลงค่าจาก SCADA ให้ตรงช่อง/ตรงเวลาในใบตรวจ

ปัญหาเดิม: ค่าจาก SCADA ถูกรวมเป็นช่วง (เช่น ชั่วโมงละ 1 ผลตรวจ เวลา HH:59:59) และไม่ผูกรอบตรวจ
→ ในใบบันทึกรายเดือนค่าไปลงช่องเวลาผิด (ค่าตอน 23:59 ไปอยู่ช่อง 20:30) และรอบตรวจยังขึ้นขาดตรวจ

แนวทาง:
- เก็บค่าดิบของ Tag ที่จับคู่แล้วไว้ (นาทีละ 1 ค่า, เก็บ keep_days วัน) ใน cs_source_values
- ตั้งค่ารายแบบฟอร์ม (cs_source_forms):
    round  = ลงค่าตามเวลารอบตรวจของแบบฟอร์ม (ค่าเริ่มต้นเมื่อแบบฟอร์มมีรอบตรวจ)
    times  = ลงค่าตามเวลาที่กำหนดเองทุกวัน เช่น 07:00 (มิเตอร์รายวัน)
    bucket = ทุกช่วงเวลาแบบเดิม
  วิธีเลือกค่า: ใกล้เวลาที่สุด / ค่าล่าสุดก่อนเวลา / ค่าแรกหลังเวลา / เฉลี่ย / ต่ำสุด / สูงสุด ภายใน ± window นาที
- 1 ผลตรวจต่อ 1 เวลา · เวลาที่บันทึก = เวลารอบพอดี → ลงช่องเวลาถูก · ผูกรอบตรวจ (ตรงเวลา) ถ้ารอบยังว่าง
- เลื่อนเวลาของแหล่งข้อมูล (ts_shift_min) แก้กรณี Historian เก็บเวลาเป็น UTC (+420 = เวลาไทย)
"""
from __future__ import annotations

import logging
import re
from datetime import date, datetime, time, timedelta

from . import services as S
from .services import ValidationError, parse_ts, ts

log = logging.getLogger(__name__)

MODES = {"auto": "อัตโนมัติ (มีรอบตรวจ → ตามเวลารอบตรวจ)", "round": "ตามเวลารอบตรวจของแบบฟอร์ม",
         "times": "ตามเวลาที่กำหนดเอง (ทุกวัน)", "bucket": "ทุกช่วงเวลา (แบบเดิม)"}
PICKS = {"nearest": "ค่าที่ใกล้เวลาที่สุด", "before": "ค่าล่าสุดก่อนถึงเวลา", "after": "ค่าแรกหลังเวลา",
         "avg": "ค่าเฉลี่ยในช่วง", "min": "ค่าต่ำสุดในช่วง", "max": "ค่าสูงสุดในช่วง"}
LOOKBACK_DAYS = 2                       # ทุกครั้งที่ดึงข้อมูล เติมช่องที่ยังว่างย้อนหลังกี่วัน
HEAL_EVERY_MIN = 15                     # v0.73 เติมช่องที่ขาด (ดึงย้อนหลังเฉพาะช่วง) ได้ทุกกี่นาที
STATES = {"done": "ลงแล้ว", "human": "ช่างกรอกแล้ว", "ready": "มีค่าแล้ว รอลง", "waiting": "ยังไม่ถึงเวลา",
          "missing": "ขาด — ไม่มีค่าจาก SCADA ในช่วงเวลา", "invalid": "ค่านอกช่วงที่เป็นไปได้ (ไม่ลง)", "down": "เครื่องหยุด / สำรอง — ไม่ลงค่า"}


def _fmt_min(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M")


# ───────────────────────── ค่าดิบ ─────────────────────────

def store_values(db, source: dict, rows, prune: bool = True) -> int:
    """เก็บค่าดิบของ Tag ที่จับคู่แล้ว (นาทีละ 1 ค่า = ค่าล่าสุดในนาทีนั้น) + ลบค่าที่เก่าเกิน keep_days"""
    mapped = {r[0] for r in db.execute("SELECT tag FROM cs_source_tags WHERE source_id=? AND form_id IS NOT NULL AND item_key<>''",
                                       (source["id"],))}
    n = 0
    for tag, dt, val in rows:
        if tag in mapped:
            db.execute("INSERT OR REPLACE INTO cs_source_values(source_id, tag, ts, value) VALUES (?,?,?,?)",
                       (source["id"], tag, _fmt_min(dt), val))
            n += 1
    if not prune:                                      # v0.74 ดึงย้อนหลังเกินอายุค่าดิบ → ใช้ลงค่าก่อน แล้วรอบปกติค่อยล้าง
        return n
    keep = int(source.get("keep_days") or 35)
    db.execute("DELETE FROM cs_source_values WHERE source_id=? AND ts<?",
               (source["id"], _fmt_min(S.now_dt() - timedelta(days=max(keep, LOOKBACK_DAYS + 1)))))
    return n


# ───────────────────────── ตั้งค่ารายแบบฟอร์ม ─────────────────────────

def _has_rounds(db, form_id: int) -> bool:
    return db.execute("SELECT 1 FROM cs_schedules WHERE form_id=? AND active=1", (form_id,)).fetchone() is not None


def form_cfgs(db, sid: int) -> list[dict]:
    """แบบฟอร์มที่มี Tag จับคู่จากแหล่งนี้ + การตั้งค่าการลงค่า (ค่าเริ่มต้นถ้ายังไม่ตั้ง)"""
    out = []
    sr = db.execute("SELECT bucket_min, agg FROM cs_sources WHERE id=?", (sid,)).fetchone()
    bmin, agg = (int(sr[0] or 0), sr[1] or "last") if sr else (60, "last")
    for r in db.execute("""SELECT t.form_id, f.name AS form_name, f.code AS form_code, e.code AS eq_code, COUNT(*) AS tags,
                                  GROUP_CONCAT(t.item_key) AS keys
                           FROM cs_source_tags t JOIN cs_forms f ON f.id=t.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
                           WHERE t.source_id=? AND t.item_key<>'' GROUP BY t.form_id ORDER BY e.code, f.name""", (sid,)):
        c = db.execute("SELECT * FROM cs_source_forms WHERE source_id=? AND form_id=?", (sid, r["form_id"])).fetchone()
        c = dict(c) if c else {"mode": "auto", "times": "", "pick": "nearest", "window_min": 30}
        sch = [dict(x) for x in db.execute("SELECT * FROM cs_schedules WHERE form_id=? AND active=1", (r["form_id"],))]
        eff = c["mode"] if c["mode"] != "auto" else ("round" if sch else "bucket")
        out.append({**dict(r), **{k: c[k] for k in ("mode", "times", "pick", "window_min")}, "effective": eff,
                    "schedules": [S.describe_schedule(x) for x in sch], "bucket_min": bmin, "agg": agg,
                    "slotted": eff != "bucket" or bmin > 0})       # v0.76 แบบทุกช่วงเวลาใช้กลไกช่องเวลาเดียวกัน
    return out


def get_cfg(db, sid: int, form_id: int) -> dict:
    for c in form_cfgs(db, sid):
        if c["form_id"] == form_id:
            return c
    sr = db.execute("SELECT bucket_min, agg FROM cs_sources WHERE id=?", (sid,)).fetchone()
    eff = "round" if _has_rounds(db, form_id) else "bucket"
    bmin = int(sr[0] or 0) if sr else 60
    return {"form_id": form_id, "mode": "auto", "times": "", "pick": "nearest", "window_min": 30, "effective": eff,
            "bucket_min": bmin, "agg": (sr[1] if sr else "last") or "last", "slotted": eff != "bucket" or bmin > 0}


def save_form_cfgs(db, sid: int, rows: list[dict], actor_id) -> int:
    from .itemfreq import fmt_times, parse_times
    errors, n = [], 0
    for r in rows:
        try:
            fid = int(r.get("form_id"))
        except (TypeError, ValueError):
            continue
        mode = r.get("mode") if r.get("mode") in MODES else "auto"
        pick = r.get("pick") if r.get("pick") in PICKS else "nearest"
        times = ""
        if mode == "times":
            mins = parse_times(r.get("times"))
            if not mins:
                errors.append(f"แบบฟอร์ม #{fid}: กรุณาระบุเวลา เช่น 07:00 หรือ 08:30, 20:30")
                continue
            times = fmt_times(mins)
        try:
            win = max(1, min(int(r.get("window_min") or 30), 720))
        except (TypeError, ValueError):
            win = 30
        db.execute("""INSERT INTO cs_source_forms(source_id, form_id, mode, times, pick, window_min, updated_at) VALUES (?,?,?,?,?,?,?)
                      ON CONFLICT(source_id, form_id) DO UPDATE SET mode=excluded.mode, times=excluded.times, pick=excluded.pick,
                      window_min=excluded.window_min, updated_at=excluded.updated_at""", (sid, fid, mode, times, pick, win, ts()))
        n += 1
    if errors:
        raise ValidationError(errors)
    S.audit(db, actor_id, "update", "cs_source_forms", sid, after={"forms": rows[:50]})
    return n


def bucket_forms(db, sid: int) -> set[int]:
    """แบบฟอร์มที่ยังใช้การลงค่าแบบทุกช่วง (แบบเดิม)"""
    return {c["form_id"] for c in form_cfgs(db, sid) if c["effective"] == "bucket"}


# ───────────────────────── เวลาที่ต้องลงค่า ─────────────────────────

def slot_times(db, form_id: int, cfg: dict, d_from: date, d_to: date) -> list[datetime]:
    if cfg["effective"] == "times":
        from .itemfreq import parse_times
        mins = parse_times(cfg.get("times"))
        out, d = [], d_from
        while d <= d_to:
            out += [datetime.combine(d, time(m // 60, m % 60)) for m in mins]
            d += timedelta(days=1)
        return out
    if cfg["effective"] == "bucket":                     # v0.76 ช่วงละ bucket_min นาที เริ่มใหม่ทุกเที่ยงคืน (เหมือนแบบเดิม)
        b = int(cfg.get("bucket_min") or 0)
        out, d = [], d_from
        while b > 0 and d <= d_to:
            base = datetime.combine(d, time(0, 0))
            out += [base + timedelta(minutes=m + b) - timedelta(seconds=1) for m in range(0, 1440, b)]
            d += timedelta(days=1)
        return out
    if cfg["effective"] == "round":
        hol = S._holidays(db)
        out = set()
        for s in db.execute("SELECT * FROM cs_schedules WHERE form_id=? AND active=1", (form_id,)).fetchall():
            out.update(S.occurrences(dict(s), d_from, d_to, hol))
        return sorted(out)
    return []


def plan(db, sid: int, form_id: int, cfg: dict, d_from: date, d_to: date) -> list[tuple[datetime, set[str] | None]]:
    """[(เวลา, หัวข้อที่ลงเวลานี้ | None = ทุกหัวข้อ)] — ตามเวลารอบตรวจ + ความถี่รายหัวข้อของแบบฟอร์ม
    หัวข้อ 'ตามเวลาที่กำหนด' → เวลาของหัวข้อเอง · รายกะ → เวลากะ · วันละครั้ง → รอบแรกของวัน ·
    สัปดาห์/เดือนละครั้ง → รอบแรกของสัปดาห์/เดือน · ไม่กำหนด → ทุกรอบ"""
    if cfg["effective"] != "round":
        return [(t, None) for t in slot_times(db, form_id, cfg, d_from, d_to)]
    from .itemfreq import get_calendar, parse_times
    form = S.get_form(db, form_id)
    keys = {r[0] for r in db.execute("SELECT item_key FROM cs_source_tags WHERE source_id=? AND form_id=? AND item_key<>''",
                                     (sid, form_id))}
    items = [i for i in S.get_items(db, form["current_version_id"]) if i["item_key"] in keys] if form and form["current_version_id"] else []
    base = slot_times(db, form_id, cfg, d_from - timedelta(days=31), d_to)
    out: dict[datetime, set[str]] = {}
    cal = get_calendar(db)

    def add(t, k):
        if d_from <= t.date() <= d_to:
            out.setdefault(t, set()).add(k)
    for it in items:
        f, k = it.get("check_freq") or "", it["item_key"]
        if f in ("times", "shift"):
            mins = parse_times(it.get("check_times") if f == "times" else cal.get("shift_times"))
            d = d_from
            while d <= d_to:
                for m in mins:
                    add(datetime.combine(d, time(m // 60, m % 60)), k)
                d += timedelta(days=1)
        elif f in ("day", "week", "month"):
            seen = set()
            for t in base:
                g = t.date() if f == "day" else (t.isocalendar()[:2] if f == "week" else (t.year, t.month))
                if g not in seen:
                    seen.add(g)
                    add(t, k)
        else:
            for t in base:
                add(t, k)
    return sorted(out.items())


def _pick(vals: list[tuple[datetime, float]], t: datetime, pick: str, win: int) -> float | None:
    lo, hi = t - timedelta(minutes=win), t + timedelta(minutes=win)
    if pick == "before":
        xs = [v for v in vals if lo <= v[0] <= t]
        return xs[-1][1] if xs else None
    if pick == "after":
        xs = [v for v in vals if t <= v[0] <= hi]
        return xs[0][1] if xs else None
    xs = [v for v in vals if lo <= v[0] <= hi]
    if not xs:
        return None
    if pick == "avg":
        return sum(v[1] for v in xs) / len(xs)
    if pick == "min":
        return min(v[1] for v in xs)
    if pick == "max":
        return max(v[1] for v in xs)
    return min(xs, key=lambda v: (abs((v[0] - t).total_seconds()), v[0] > t))[1]


def slot_values(db, sid: int, form_id: int, cfg: dict, t: datetime, keys: set[str] | None = None,
                check_range: bool = True) -> dict[str, dict]:
    """{item_key: {value, tag, raw}} ของเวลา t (ค่าหลังคูณ/บวกแล้ว) · keys = เฉพาะหัวข้อเหล่านี้
    check_range = ตัดค่าที่อยู่นอกช่วงค่าที่เป็นไปได้ของ Tag ออกก่อนเลือกค่า (v0.77)"""
    out = {}
    for m in db.execute("""SELECT tag, item_key, scale, add_offset, valid_min, valid_max FROM cs_source_tags
                           WHERE source_id=? AND form_id=? AND item_key<>''""", (sid, form_id)).fetchall():
        if keys is not None and m["item_key"] not in keys:
            continue
        lo, hi = slot_window(cfg, t)
        rows = db.execute("SELECT ts, value FROM cs_source_values WHERE source_id=? AND tag=? AND ts BETWEEN ? AND ? ORDER BY ts",
                          (sid, m["tag"], _fmt_min(lo), _fmt_min(hi))).fetchall()
        k_, o_ = float(m["scale"] or 1), float(m["add_offset"] or 0)
        vals = [(datetime.strptime(r[0], "%Y-%m-%d %H:%M"), r[1]) for r in rows
                if not check_range or _in_range(r[1] * k_ + o_, m["valid_min"], m["valid_max"])]
        v = value_at(vals, t, cfg)
        if v is not None:
            out[m["item_key"]] = {"value": v * float(m["scale"] or 1) + float(m["add_offset"] or 0), "raw": v, "tag": m["tag"]}
    return out


def _in_range(v: float, lo, hi) -> bool:
    return (lo is None or v >= lo) and (hi is None or v <= hi)


def slot_window(cfg: dict, t: datetime) -> tuple[datetime, datetime]:
    """ช่วงค่าดิบที่ใช้ของช่องเวลา t — ตามเวลา: t ± window · ทุกช่วงเวลา: ทั้งช่วง (ไม่ข้ามเที่ยงคืน)"""
    if cfg.get("effective") == "bucket":
        b = int(cfg.get("bucket_min") or 60)
        start = t + timedelta(seconds=1) - timedelta(minutes=b)
        return start, min(t, datetime.combine(start.date(), time(23, 59, 59)))
    win = int(cfg.get("window_min") or 30)
    return t - timedelta(minutes=win), t + timedelta(minutes=win)


def value_at(vals: list[tuple[datetime, float]], t: datetime, cfg: dict) -> float | None:
    """ค่าของช่องเวลา t จากค่าดิบ (เรียงตามเวลา) ตามวิธีเลือกค่าของแบบฟอร์ม"""
    if cfg.get("effective") == "bucket":
        lo, hi = slot_window(cfg, t)
        xs = [v[1] for v in vals if lo - timedelta(seconds=59) <= v[0] <= hi]
        if not xs:
            return None
        agg = cfg.get("agg") or "last"
        return {"last": xs[-1], "avg": sum(xs) / len(xs), "min": min(xs), "max": max(xs)}.get(agg, xs[-1])
    return _pick(vals, t, cfg.get("pick") or "nearest", int(cfg.get("window_min") or 30))


def ready_at(cfg: dict, t: datetime) -> datetime:
    """เวลาที่ช่อง t พร้อมลงค่า (ค่าดิบครบช่วงแล้ว)"""
    if cfg.get("effective") == "bucket" or cfg.get("pick") == "before":
        return t
    return t + timedelta(minutes=int(cfg.get("window_min") or 30))


def _uuid(sid: int, form_id: int, t: datetime, cfg: dict | None = None) -> str:
    if cfg and cfg.get("effective") == "bucket":      # รหัสเดียวกับแบบเดิม → ไม่สร้างซ้ำกับรายการที่ลงไว้แล้ว
        return f"src{sid}:{form_id}:{t:%Y%m%d%H%M%S}"
    return f"src{sid}:{form_id}:r{t:%Y%m%d%H%M}"


# ───────────────────────── v0.45 ฟอร์มผสม (SCADA + หน้างาน) ─────────────────────────
PREFILL_MAX_AGE_MIN = 180


def is_mixed(db, source: dict, form_id: int) -> bool:
    """ฟอร์มผสม = แหล่งข้อมูลเปิด 'เติมค่าในฟอร์มของช่าง' และแบบฟอร์มยังมีหัวข้อที่ SCADA ไม่ได้ส่งค่า (ช่างต้องตรวจหน้างาน)
    → ค่าอัตโนมัติไม่ปิดรอบตรวจแทนช่าง"""
    if not int(source.get("prefill", 0) or 0):
        return False
    form = S.get_form(db, form_id)
    if not form or not form["current_version_id"]:
        return False
    mapped = {r[0] for r in db.execute("SELECT item_key FROM cs_source_tags WHERE source_id=? AND form_id=? AND item_key<>''",
                                       (source["id"], form_id))}
    return any(i["item_key"] not in mapped and i["item_type"] != "text" for i in S.get_items(db, form["current_version_id"]))


def prefill_values(db, form_id: int, now: datetime | None = None) -> dict[str, dict]:
    """ค่าล่าสุดจาก SCADA (≤ 3 ชม.) ของหัวข้อที่จับคู่ไว้ สำหรับเติมในฟอร์มของช่าง {item_key: {value, at, tag, source}}"""
    now = now or S.now_dt()
    out: dict[str, dict] = {}
    try:
        maps = db.execute("""SELECT t.source_id, t.tag, t.item_key, t.scale, t.add_offset, t.valid_min, t.valid_max, s.name FROM cs_source_tags t
                             JOIN cs_sources s ON s.id=t.source_id
                             WHERE t.form_id=? AND t.item_key<>'' AND s.active=1 AND COALESCE(s.prefill,1)=1""", (form_id,)).fetchall()
    except Exception:                                       # noqa: BLE001 — ฐานข้อมูลเก่า
        return out
    eq = db.execute("SELECT equipment_id FROM cs_forms WHERE id=?", (form_id,)).fetchone()
    if eq and equipment_down_at(db, eq[0], now):            # v0.84 เครื่องหยุด/สำรอง → ไม่เติมค่าจาก SCADA
        return out
    lo = _fmt_min(now - timedelta(minutes=PREFILL_MAX_AGE_MIN))
    for m in maps:
        r = db.execute("""SELECT ts, value FROM cs_source_values WHERE source_id=? AND tag=? AND ts BETWEEN ? AND ?
                          ORDER BY ts DESC LIMIT 1""", (m["source_id"], m["tag"], lo, _fmt_min(now + timedelta(minutes=5)))).fetchone()
        if not r:
            continue
        v = r["value"] * float(m["scale"] or 1) + float(m["add_offset"] or 0)
        if not _in_range(v, m["valid_min"], m["valid_max"]):     # v0.77 ค่านอกช่วง → ไม่เติมให้ช่าง
            continue
        prev = out.get(m["item_key"])
        if not prev or r["ts"] > prev["at"]:
            out[m["item_key"]] = {"value": float("%.6g" % v), "at": r["ts"], "tag": m["tag"], "source": m["name"]}
    return out


def prefill_slot(db, form_id: int, t: datetime) -> dict[str, dict]:
    """v0.82 ค่าจาก SCADA ของรอบเวลา t สำหรับเติมในฟอร์มของช่าง (รอบปัจจุบันที่เลยเวลาแล้ว / ลงข้อมูลย้อนหลัง)
    ใช้ค่าที่ระบบลงไว้แล้วของรอบนั้นก่อน (รวมค่าที่ผู้ดูแลแก้) ไม่มีจึงคำนวณจากค่าดิบรอบเวลานั้น
    {item_key: {value, at, tag, source, auto}}"""
    out: dict[str, dict] = {}
    try:
        srcs = db.execute("""SELECT DISTINCT s.id, s.name FROM cs_source_tags t JOIN cs_sources s ON s.id=t.source_id
                             WHERE t.form_id=? AND t.item_key<>'' AND s.active=1 AND COALESCE(s.prefill,1)=1""", (form_id,)).fetchall()
    except Exception:                                       # noqa: BLE001 — ฐานข้อมูลเก่า
        return out
    if down_checker(db, form_id, t.date(), t.date())(t):     # v0.84 เครื่องหยุด/สำรอง → ไม่เติมค่าจาก SCADA
        return out
    at = t.strftime("%Y-%m-%d %H:%M")
    for src in srcs:
        tags = {r[0]: r[1] for r in db.execute("SELECT item_key, tag FROM cs_source_tags WHERE source_id=? AND form_id=? AND item_key<>''",
                                               (src["id"], form_id))}
        sub = db.execute("""SELECT id FROM cs_submissions WHERE form_id=? AND source='auto' AND client_uuid LIKE ? AND finished_at=?
                            ORDER BY id DESC LIMIT 1""", (form_id, f"src{src['id']}:%", ts(t))).fetchone()
        if sub:
            for r in db.execute("""SELECT item_key, value_num FROM cs_answers WHERE submission_id=? AND judgement<>'na'
                                   AND value_num IS NOT NULL""", (sub[0],)):
                out.setdefault(r[0], {"value": float("%.6g" % r[1]), "at": at, "tag": tags.get(r[0], ""), "source": src["name"], "auto": True})
            continue
        try:
            vals = slot_values(db, src["id"], form_id, get_cfg(db, src["id"], form_id), t)
        except Exception:                                   # noqa: BLE001
            vals = {}
        for k, v in vals.items():
            out.setdefault(k, {"value": float("%.6g" % v["value"]), "at": at, "tag": v["tag"], "source": src["name"], "auto": False})
    return out


def update_human_scada(db, sid: int, d_from: date, d_to: date, form_ids: set[int], actor_id) -> int:
    """v0.83 ลงค่าใหม่: อัปเดตหัวข้อที่มาจาก SCADA ในผลตรวจของช่าง (value_src='scada' = ช่างไม่ได้แก้) ตามการตั้งค่าปัจจุบัน
    ค่าที่ช่างแก้เอง ไม่แตะ · คืนจำนวนผลตรวจที่เปลี่ยน"""
    lo, hi = ts(datetime.combine(d_from, time(0, 0))), ts(datetime.combine(d_to + timedelta(days=1), time(0, 0)))
    changed = 0
    for fid in form_ids:
        cfg = get_cfg(db, sid, fid)
        keys = {r[0] for r in db.execute("SELECT item_key FROM cs_source_tags WHERE source_id=? AND form_id=? AND item_key<>''", (sid, fid))}
        if not keys:
            continue
        for sub in db.execute("""SELECT s.id, s.form_version_id, r.due_at FROM cs_submissions s JOIN cs_rounds r ON r.id=s.round_id
                                 WHERE s.form_id=? AND COALESCE(s.source,'')<>'auto' AND r.due_at>=? AND r.due_at<?""",
                              (fid, lo, hi)).fetchall():
            ans = {r["item_key"]: dict(r) for r in db.execute(
                "SELECT id, item_key, value_num FROM cs_answers WHERE submission_id=? AND value_src='scada'", (sub["id"],))}
            want = keys & set(ans)
            if not want:
                continue
            vals = slot_values(db, sid, fid, cfg, parse_ts(sub["due_at"]), want)
            items = {i["item_key"]: i for i in S.get_items(db, sub["form_version_id"])}
            diff = {}
            for k, v in vals.items():
                if k not in items or ans[k]["value_num"] is not None and abs(ans[k]["value_num"] - v["value"]) < 1e-9:
                    continue
                try:
                    res = S.evaluate(items[k], "%g" % round(v["value"], 3))
                except ValidationError:
                    continue
                db.execute("UPDATE cs_answers SET value_num=?, value_text=?, judgement=? WHERE id=?",
                           (res["value_num"], res["value_text"], res["judgement"], ans[k]["id"]))
                diff[k] = [ans[k]["value_num"], res["value_num"]]
            if diff:
                db.execute("""UPDATE cs_submissions SET ng_count=(SELECT COUNT(*) FROM cs_answers WHERE submission_id=? AND judgement='ng'),
                              warn_count=(SELECT COUNT(*) FROM cs_answers WHERE submission_id=? AND judgement='warn') WHERE id=?""",
                           (sub["id"], sub["id"], sub["id"]))
                S.audit(db, actor_id, "scada_update", "cs_submissions", sub["id"], after={"source": sid, "values": diff})
                changed += 1
    return changed


def absorb_auto(db, sub_id: int, actor_id) -> int:
    """v0.82 ช่างส่งผลของรอบที่ระบบลงค่า SCADA ไว้แล้ว → รวมเป็นรายการเดียว
    หัวข้อที่ช่างไม่ได้กรอก ใช้ค่าจาก SCADA เดิม แล้วลบรายการอัตโนมัติของรอบนั้น (ใบบันทึกไม่ซ้ำ 2 ค่า)"""
    from . import submissions as SUB
    s = db.execute("""SELECT s.id, s.form_id, s.source, r.due_at FROM cs_submissions s JOIN cs_rounds r ON r.id=s.round_id
                      WHERE s.id=?""", (sub_id,)).fetchone()
    if not s or (s["source"] or "") == "auto":
        return 0
    autos = [r[0] for r in db.execute("""SELECT id FROM cs_submissions WHERE form_id=? AND source='auto' AND client_uuid LIKE 'src%'
                                         AND finished_at=? AND id<>?""", (s["form_id"], s["due_at"], sub_id))]
    if not autos:
        return 0
    cols = [c[1] for c in db.execute("PRAGMA table_info(cs_answers)") if c[1] not in ("id", "submission_id")]
    have = {r[0] for r in db.execute("SELECT item_key FROM cs_answers WHERE submission_id=? AND judgement<>'na'", (sub_id,))}
    for aid in autos:
        for r in db.execute(f"SELECT {', '.join(cols)} FROM cs_answers WHERE submission_id=? AND judgement<>'na'", (aid,)).fetchall():
            row = dict(zip(cols, r))
            if row["item_key"] in have:
                continue
            row["value_src"] = "scada"
            db.execute("DELETE FROM cs_answers WHERE submission_id=? AND item_key=?", (sub_id, row["item_key"]))
            db.execute(f"INSERT INTO cs_answers(submission_id, {', '.join(row)}) VALUES (?, {', '.join('?' * len(row))})",
                       (sub_id, *row.values()))
            have.add(row["item_key"])
    db.execute("""UPDATE cs_submissions SET ng_count=(SELECT COUNT(*) FROM cs_answers WHERE submission_id=? AND judgement='ng'),
                  warn_count=(SELECT COUNT(*) FROM cs_answers WHERE submission_id=? AND judgement='warn') WHERE id=?""",
               (sub_id, sub_id, sub_id))
    SUB.delete_submissions(db, autos, actor_id, f"รวมค่าจาก SCADA เข้ากับผลตรวจของช่าง #{sub_id}", check_perm=False)
    return len(autos)


def _human_keys(db, form_id: int, t: datetime) -> set[str]:
    """หัวข้อที่ช่างกรอกไว้แล้วในรอบของเวลา t (ไม่ต้องลงค่าอัตโนมัติซ้ำ)"""
    r = db.execute("""SELECT s.id FROM cs_rounds r JOIN cs_submissions s ON s.id=r.submission_id
                      WHERE r.form_id=? AND r.due_at=? AND COALESCE(s.source,'')<>'auto'""", (form_id, ts(t))).fetchone()
    if not r:
        return set()
    return {x[0] for x in db.execute("SELECT item_key FROM cs_answers WHERE submission_id=? AND judgement<>'na'", (r[0],))}


def _link_round(db, sub_id: int, form_id: int, t: datetime) -> None:
    r = db.execute("""SELECT * FROM cs_rounds WHERE form_id=? AND due_at=? AND submission_id IS NULL AND status<>'skipped'""",
                   (form_id, ts(t))).fetchone()
    if not r:
        return
    st = S.round_status_for_submission(dict(r), t)
    db.execute("UPDATE cs_rounds SET submission_id=?, status=?, updated_at=? WHERE id=?", (sub_id, st, ts(), r["id"]))
    db.execute("UPDATE cs_submissions SET round_id=? WHERE id=?", (r["id"], sub_id))


# ───────────────────────── v0.84 เครื่องหยุด / สำรอง → ไม่ลงค่าจาก SCADA (ยึดสถานะเครื่องจักร) ─────────────────────────

def down_checker(db, form_id: int, d_from: date, d_to: date):
    """คืนฟังก์ชัน t → ข้อมูลช่วงหยุด | None
    ช่องเวลา t = "เครื่องหยุด" เมื่อ (1) เครื่องอยู่ในช่วงหยุด/สำรอง/PM ตอนเวลา t หรือ (2) รอบตรวจเวลา t ถูกงดเพราะเครื่องหยุด"""
    eq = db.execute("SELECT equipment_id FROM cs_forms WHERE id=?", (form_id,)).fetchone()
    a = datetime.combine(d_from - timedelta(days=1), time(0, 0))
    b = datetime.combine(d_to + timedelta(days=2), time(0, 0))
    spans = []
    if eq and eq[0]:
        try:
            from .downtime import CATEGORIES
            for r in db.execute("""SELECT start_at, end_at, category, reason FROM cs_downtime WHERE equipment_id=? AND start_at<?
                                   AND (end_at IS NULL OR end_at>?) ORDER BY start_at""", (eq[0], ts(b), ts(a))):
                spans.append((parse_ts(r["start_at"]), parse_ts(r["end_at"]) if r["end_at"] else None,
                              {"cat": CATEGORIES.get(r["category"], r["category"] or ""), "reason": r["reason"] or ""}))
        except Exception:                                   # noqa: BLE001 — ฐานข้อมูลเก่า
            spans = []
    skipped = {r[0] for r in db.execute("""SELECT due_at FROM cs_rounds WHERE form_id=? AND status='skipped'
                                           AND due_at>=? AND due_at<?""", (form_id, ts(a), ts(b)))}

    def check(t: datetime):
        for st, en, info in spans:
            if st <= t and (en is None or t < en):
                return info
        if ts(t) in skipped:
            return {"cat": "งดรอบตรวจ (เครื่องหยุด)", "reason": ""}
        return None
    return check


def equipment_down_at(db, equipment_id, t: datetime) -> bool:
    """เครื่องอยู่ในช่วงหยุด/สำรอง/PM ตอนเวลา t"""
    if not equipment_id:
        return False
    try:
        return db.execute("""SELECT 1 FROM cs_downtime WHERE equipment_id=? AND start_at<=? AND (end_at IS NULL OR end_at>?)
                             LIMIT 1""", (equipment_id, ts(t), ts(t))).fetchone() is not None
    except Exception:                                       # noqa: BLE001
        return False


def down_auto_subs(db, form_ids, d_from: date, d_to: date) -> list[tuple[int, int]]:
    """[(submission_id, form_id)] ผลตรวจอัตโนมัติจาก SCADA ที่อยู่ในช่องเครื่องหยุด/สำรอง"""
    lo, hi = ts(datetime.combine(d_from, time(0, 0))), ts(datetime.combine(d_to + timedelta(days=1), time(0, 0)))
    out = []
    for fid in sorted(set(form_ids or [])):
        rows = db.execute("""SELECT id, finished_at FROM cs_submissions WHERE form_id=? AND source='auto' AND client_uuid LIKE 'src%'
                             AND finished_at>=? AND finished_at<?""", (fid, lo, hi)).fetchall()
        if not rows:
            continue
        chk = down_checker(db, fid, d_from, d_to)
        out += [(r[0], fid) for r in rows if parse_ts(r[1]) and chk(parse_ts(r[1]))]
    return out


def purge_down(db, form_ids, d_from: date, d_to: date, actor_id=None) -> int:
    """ลบผลตรวจอัตโนมัติจาก SCADA ที่อยู่ในช่วงเครื่องหยุด/สำรอง (รายงานยึดสถานะเครื่องจักร) · รอบตรวจของช่องนั้น → งดตรวจ
    ค่าที่ผู้ดูแลแก้ (cs_source_fixes) ยังเก็บไว้ — ถ้าภายหลังแก้ช่วงหยุดออก ระบบจะลงค่ากลับได้"""
    from . import submissions as SUB
    hit = down_auto_subs(db, form_ids, d_from, d_to)
    total = 0
    for i in range(0, len(hit), 200):                     # ทีละชุด — ข้อมูลย้อนหลังจำนวนมาก
        ids = [h[0] for h in hit[i:i + 200]]
        rounds = [r[0] for r in db.execute(f"SELECT id FROM cs_rounds WHERE submission_id IN ({','.join('?' * len(ids))})", ids)]
        total += SUB.delete_submissions(db, ids, actor_id, "เครื่องหยุด / สำรอง — ไม่ลงค่าจาก SCADA (ยึดสถานะเครื่องจักร)",
                                        check_perm=False)["deleted"]
        if rounds:
            db.execute(f"UPDATE cs_rounds SET status='skipped', updated_at=? WHERE id IN ({','.join('?' * len(rounds))})"
                       " AND submission_id IS NULL", [ts(), *rounds])
    return total


def on_downtime_change(db, equipment_id: int, since: datetime, until: datetime | None = None, actor_id=None) -> dict:
    """แจ้งหยุด / เดินเครื่อง / บันทึกย้อนหลัง → ลบค่าจาก SCADA ในช่วงหยุด แล้วลงค่าช่องที่กลับมาเป็นเครื่องเดินจากค่าดิบที่เก็บไว้"""
    from . import connectors as CN
    fids = [r[0] for r in db.execute("SELECT id FROM cs_forms WHERE equipment_id=?", (equipment_id,))]
    if not fids:
        return {"removed": 0, "created": 0}
    now = S.now_dt()
    d_from, d_to = (since - timedelta(days=1)).date(), (until or now).date()
    removed = purge_down(db, fids, d_from, d_to, actor_id)
    made = 0
    try:
        sids = {r[0] for r in db.execute(f"""SELECT DISTINCT t.source_id FROM cs_source_tags t JOIN cs_sources s ON s.id=t.source_id
                                             WHERE s.active=1 AND t.form_id IN ({','.join('?' * len(fids))})""", fids)}
    except Exception:                                       # noqa: BLE001
        sids = set()
    for sid in sorted(sids):
        src = CN.get_source(db, sid)
        if src:
            made += fill_slots(db, src, now, d_from=d_from, d_to=d_to, form_ids=set(fids))
    return {"removed": removed, "created": made}


SWEEP_DAYS = 62                          # v0.84.1 ล้างค่าจาก SCADA ในช่วงเครื่องหยุด ย้อนหลังกี่วัน
SWEEP_EVERY_MIN = 60


def _auto_forms(db, days: int) -> list[int]:
    return [r[0] for r in db.execute("""SELECT DISTINCT form_id FROM cs_submissions WHERE source='auto' AND client_uuid LIKE 'src%'
                                        AND finished_at>=?""", (ts(S.now_dt() - timedelta(days=days)),))]


def count_down(db, days: int = SWEEP_DAYS) -> int:
    """จำนวนผลตรวจจาก SCADA ที่ยังค้างอยู่ในช่วงเครื่องหยุด (แสดงในหน้ารวมปัญหา)"""
    now = S.now_dt()
    return len(down_auto_subs(db, _auto_forms(db, days), (now - timedelta(days=days)).date(), now.date()))


def purge_down_all(db, days: int = SWEEP_DAYS, actor_id=None) -> int:
    """ล้างค่าจาก SCADA ที่ลงไว้แล้วในช่วงเครื่องหยุด ย้อนหลัง N วัน (ทุกแบบฟอร์ม)"""
    now = S.now_dt()
    return purge_down(db, _auto_forms(db, days), (now - timedelta(days=days)).date(), now.date(), actor_id)


def sweep_down(db, now: datetime | None = None, force: bool = False) -> int | None:
    """v0.84.1 งานเบื้องหลัง: ล้างค่าจาก SCADA ในช่วงเครื่องหยุด ย้อนหลัง SWEEP_DAYS วัน ทุก SWEEP_EVERY_MIN นาที
    (ครอบคลุมช่วงหยุดที่บันทึกก่อนอัปเดต / แก้ข้อมูลตรงในฐานข้อมูล) — ล้มเหลวรอบนี้จะลองใหม่รอบหน้า"""
    now = now or S.now_dt()
    r = db.execute("SELECT value FROM cs_meta WHERE key='scada_down_sweep_at'").fetchone()
    last = parse_ts(r[0]) if r and r[0] else None
    if not force and last and now - last < timedelta(minutes=SWEEP_EVERY_MIN):
        return None
    n = purge_down_all(db)
    db.execute("INSERT INTO cs_meta(key, value) VALUES('scada_down_sweep_at', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (ts(now),))
    if n:
        log.info("removed %s SCADA submissions inside equipment downtime", n)
    return n


def fill_slots(db, source: dict, now: datetime | None = None, d_from: date | None = None, d_to: date | None = None,
               form_ids: set[int] | None = None) -> int:
    """สร้างผลตรวจอัตโนมัติ 1 รายการต่อเวลาที่ต้องลงค่า (เฉพาะเวลาที่ผ่านไปแล้วเกินช่วงเลือกค่า และยังไม่มี)"""
    now = now or S.now_dt()
    d_to = d_to or now.date()
    d_from = d_from or (now - timedelta(days=LOOKBACK_DAYS)).date()
    made = 0
    slotted = [c for c in form_cfgs(db, source["id"]) if c["slotted"] and (not form_ids or c["form_id"] in form_ids)]
    purge_down(db, [c["form_id"] for c in slotted], d_from, d_to)   # v0.84 ช่องที่เครื่องหยุดภายหลัง → เอาค่าออก
    for cfg in slotted:
        down = down_checker(db, cfg["form_id"], d_from, d_to)
        for t, keys in plan(db, source["id"], cfg["form_id"], cfg, d_from, d_to):
            if ready_at(cfg, t) > now or down(t):           # v0.84 เครื่องหยุด/สำรอง → ไม่ลงค่า
                continue
            uuid = _uuid(source["id"], cfg["form_id"], t, cfg)
            if db.execute("SELECT 1 FROM cs_submissions WHERE client_uuid=?", (uuid,)).fetchone():
                continue
            if _create_slot(db, source, cfg, t, keys, uuid):
                made += 1
    return made


def _slot_vals(db, source: dict, cfg: dict, t: datetime, keys: set[str] | None, base: dict[str, float] | None = None) -> dict[str, float]:
    """ค่าที่จะลงของช่องเวลา t = ค่าจาก SCADA (หรือค่าเดิมถ้าไม่มีค่าดิบแล้ว) − หัวข้อที่ช่างกรอกแล้ว − ค่าที่ถูกยกเลิก + ค่าที่แก้"""
    vals = {k: v["value"] for k, v in slot_values(db, source["id"], cfg["form_id"], cfg, t, keys).items()}
    for k, v in (base or {}).items():
        vals.setdefault(k, v)
    if is_mixed(db, source, cfg["form_id"]):              # ช่างกรอกหัวข้อนั้นในรอบนี้แล้ว → ไม่ลงซ้ำ
        for k in _human_keys(db, cfg["form_id"], t):
            vals.pop(k, None)
    fx = fixes_at(db, source["id"], cfg["form_id"], t)
    if fx["void_all"]:
        return {}
    for k in fx["void"]:
        vals.pop(k, None)
    for k, v in fx["value"].items():
        if keys is None or k in keys or k in vals:
            vals[k] = v
    return vals


def _create_slot(db, source: dict, cfg: dict, t: datetime, keys, uuid: str, base: dict[str, float] | None = None) -> int | None:
    from .connectors import create_auto_submission
    vals = _slot_vals(db, source, cfg, t, keys, base)
    if not vals:
        return None
    sub = create_auto_submission(db, source, cfg["form_id"], t, vals, uuid=uuid)
    if sub:
        fx = fixes_at(db, source["id"], cfg["form_id"], t)
        for k in fx["value"]:                              # ค่าที่ผู้ดูแลแก้ → บอกที่มาในผลตรวจ
            db.execute("UPDATE cs_answers SET value_src='fixed', remark=? WHERE submission_id=? AND item_key=?",
                       (f"แก้ค่าโดยผู้ดูแล: {fx['reason'].get(k, '')}"[:300], sub, k))
        if not is_mixed(db, source, cfg["form_id"]):     # ฟอร์มที่ SCADA ส่งค่าครบ → ปิดรอบแทนช่างได้
            _link_round(db, sub, cfg["form_id"], t)
    return sub


# ───────────────────────── ตรวจสอบ / ลงค่าใหม่ ─────────────────────────

def preview_day(db, sid: int, day: date) -> list[dict]:
    """ตัวอย่างการลงค่าของวันที่เลือก: ต่อแบบฟอร์ม → เวลา × หัวข้อ = ค่าที่จะลง (และค่าที่ลงไว้แล้ว)"""
    out = []
    for cfg in form_cfgs(db, sid):
        form = S.get_form(db, cfg["form_id"])
        items = {i["item_key"]: i for i in S.get_items(db, form["current_version_id"])} if form and form["current_version_id"] else {}
        keys = [k for k in (cfg["keys"] or "").split(",") if k]
        if not cfg["slotted"]:
            out.append({**cfg, "slots": [], "items": [{"key": k, "name": items.get(k, {}).get("name", k),
                                                        "unit": items.get(k, {}).get("unit", "")} for k in keys]})
            continue
        slots = []
        for t, tkeys in plan(db, sid, cfg["form_id"], cfg, day, day):
            vals = slot_values(db, sid, cfg["form_id"], cfg, t, tkeys)
            have = db.execute("SELECT id FROM cs_submissions WHERE client_uuid=?", (_uuid(sid, cfg["form_id"], t, cfg),)).fetchone()
            slots.append({"t": t.strftime("%H:%M"), "vals": {k: round(v["value"], 4) for k, v in vals.items()},
                          "done": bool(have)})
        out.append({**cfg, "slots": slots, "items": [{"key": k, "name": items.get(k, {}).get("name", k),
                                                       "unit": items.get(k, {}).get("unit", "")} for k in keys]})
    return out


RELAY_MAX_DAYS = 62
FETCH_MAX_PAGES = 60            # v0.81 ต่อหน้าต่างเวลา: ดึงต่อเป็นชุด ๆ เมื่อข้อมูลถึงเพดาน MAX_ROWS


def _merge(iv: list[tuple[datetime, datetime]], gap_min: int = 5) -> list[tuple[datetime, datetime]]:
    out: list[list[datetime]] = []
    for a, b in sorted(iv):
        if out and a <= out[-1][1] + timedelta(minutes=gap_min):
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(a, b) for a, b in out]


def fetch_windows(db, src: dict, windows: list[tuple[datetime, datetime]], tags: list[str] | None = None,
                  now: datetime | None = None) -> dict:
    """v0.81 ดึงค่าดิบเฉพาะช่วงเวลาที่ต้องใช้ (มีเวลาสิ้นสุด + เฉพาะ Tag ที่จับคู่) และดึงต่อเป็นชุดจนครบ
    (เดิมดึงตั้งแต่วันเริ่มโดยไม่มีเวลาสิ้นสุด → ได้แค่ 50,000 แถวแรก = ไม่กี่ชั่วโมง ค่าวันหลัง ๆ จึงไม่เปลี่ยน)"""
    from . import connectors as CN
    now = now or S.now_dt()
    out = {"fetched": 0, "queries": 0, "incomplete": 0, "days": set()}
    for a, b in windows:
        b = min(b, now)
        if b <= a:
            continue
        w = a
        for _page in range(FETCH_MAX_PAGES):
            s2 = dict(src)
            rows, _k, _b = CN.fetch(db, s2, now, tags=tags, since=w, until=b)
            out["queries"] += 1
            out["fetched"] += store_values(db, src, rows, prune=False)
            out["days"].update(r[1].date() for r in rows)
            if not s2.get("_truncated") or not rows:
                break
            nw = max(r[1] for r in rows) - timedelta(seconds=1)     # ดึงต่อจากเวลาสุดท้าย (ซ้ำได้ — เก็บแบบแทนที่)
            if nw <= w:
                out["incomplete"] += 1
                break
            w = nw
        else:
            out["incomplete"] += 1
    out["days"] = sorted(out["days"])
    return out


def refetch(db, src: dict, d_from: date, d_to: date, form_ids: set[int] | None = None, now: datetime | None = None) -> dict:
    """ดึงค่าย้อนหลังจากแหล่งข้อมูลอีกครั้งสำหรับช่วงวันที่ — SQL / REST: เฉพาะช่วงรอบเวลาที่ต้องลงค่า · CSV: อ่านทุกไฟล์"""
    from . import connectors as CN
    start = datetime.combine(d_from, time(0, 0)) - timedelta(hours=12)
    end = datetime.combine(d_to + timedelta(days=1), time(0, 0)) + timedelta(hours=12)
    if src.get("kind") == "csv":
        rows, _keys, _bad = CN.fetch(db, {**src, "watermark": ts(start)}, force_files=True)
        rows = [r for r in rows if start <= r[1] < end]
        return {"fetched": store_values(db, src, rows, prune=False), "queries": 1, "incomplete": 0,
                "days": sorted({r[1].date() for r in rows})}
    iv = []
    for c in form_cfgs(db, src["id"]):
        if not c["slotted"] or (form_ids is not None and c["form_id"] not in form_ids):
            continue
        cfg = get_cfg(db, src["id"], c["form_id"])
        down = down_checker(db, c["form_id"], d_from, d_to)
        for t, _keys in plan(db, src["id"], c["form_id"], cfg, d_from, d_to):
            if down(t):
                continue
            lo, hi = slot_window(cfg, t)
            iv.append((lo - timedelta(minutes=3), hi + timedelta(minutes=3)))
    return fetch_windows(db, src, _merge(iv), CN.mapped_tags(db, src["id"]) or None, now)


def relay(db, sid: int, d_from: date, d_to: date, actor_id, form_ids: set[int] | None = None, refetch_src: bool = True,
          check_perm: bool = True) -> dict:
    """ลงค่าใหม่ช่วงวันที่: ดึงค่าจากแหล่งข้อมูลอีกครั้ง → ลบผลตรวจอัตโนมัติเดิมของแหล่งนี้ (เฉพาะวันที่มีค่าใหม่)
    → สร้างใหม่ 1 รายการต่อเวลารอบ ลงช่องเวลาที่ถูกต้อง"""
    from . import connectors as CN
    from . import submissions as SUB
    if d_from > d_to or (d_to - d_from).days >= RELAY_MAX_DAYS:
        raise ValidationError(f"ช่วงวันที่ไม่ถูกต้อง (ไม่เกิน {RELAY_MAX_DAYS} วัน)")
    src = CN.get_source(db, sid)
    if not src:
        raise ValidationError("ไม่พบแหล่งข้อมูล")
    targets = {c["form_id"] for c in form_cfgs(db, sid) if c["slotted"]}
    if form_ids:
        targets &= set(form_ids)
    if not targets:
        raise ValidationError("ยังไม่มีแบบฟอร์มที่ตั้งให้ลงค่าตามเวลา")
    fetched, got = 0, {"days": [], "incomplete": 0}
    if refetch_src:
        try:
            got = refetch(db, src, d_from, d_to, targets)
        except CN.SourceError as exc:
            raise ValidationError(f"ดึงข้อมูลย้อนหลังไม่สำเร็จ: {exc}") from None
        fetched = got["fetched"]
    removed = 0
    for fid in sorted(targets):
        cfg = get_cfg(db, sid, fid)
        days = sorted({t.date() for t, keys in plan(db, sid, fid, cfg, d_from, d_to) if slot_values(db, sid, fid, cfg, t, keys)})
        ids = []
        for d in days:                                  # ลบเฉพาะวันที่มีค่าใหม่ — วันที่ไม่มีค่าดิบ คงผลตรวจเดิมไว้
            ids += [r[0] for r in db.execute(
                """SELECT id FROM cs_submissions WHERE source='auto' AND client_uuid LIKE ? AND form_id=?
                   AND finished_at>=? AND finished_at<?""",
                (f"src{sid}:%", fid, ts(datetime.combine(d, time(0, 0))), ts(datetime.combine(d + timedelta(days=1), time(0, 0)))))]
        if ids:
            removed += SUB.delete_submissions(db, ids, actor_id, "ลงค่าจาก SCADA ใหม่ตามการตั้งค่าเวลา", check_perm=check_perm)["deleted"]
    made = fill_slots(db, src, d_from=d_from, d_to=d_to, form_ids=targets)
    human_upd = update_human_scada(db, sid, d_from, d_to, targets, actor_id)   # v0.83
    human = sum(1 for fid in targets for t, _k in plan(db, sid, fid, get_cfg(db, sid, fid), d_from, d_to) if _human_done(db, fid, t))
    from .analytics import refresh_form_stats
    refresh_form_stats(db, targets)
    S.audit(db, actor_id, "relay", "cs_sources", sid, after={"from": d_from.isoformat(), "to": d_to.isoformat(), "fetched": fetched,
                                                             "removed": removed, "created": made, "forms": sorted(targets)})
    n_days = (d_to - d_from).days + 1
    return {"fetched": fetched, "removed": removed, "created": made, "forms": len(targets), "n_days": n_days, "human": human,
            "human_updated": human_upd,
            "src_days": len(got["days"]), "incomplete": got["incomplete"],
            "no_data": [d_from + timedelta(days=i) for i in range(n_days)
                        if refetch_src and d_from + timedelta(days=i) not in set(got["days"])]}


# ───────────────────────── v0.73 สถานะการลงค่าอัตโนมัติ + เติมช่องที่ขาดเอง ─────────────────────────

def _human_done(db, form_id: int, t: datetime) -> bool:
    return db.execute("""SELECT 1 FROM cs_rounds r JOIN cs_submissions s ON s.id=r.submission_id
                         WHERE r.form_id=? AND r.due_at=? AND COALESCE(s.source,'')<>'auto'""", (form_id, ts(t))).fetchone() is not None


def slot_status(db, sid: int, day: date, now: datetime | None = None) -> list[dict]:
    """สถานะทุกช่องเวลาของวันที่เลือก ต่อแบบฟอร์ม: done / human / ready / waiting / missing"""
    now = now or S.now_dt()
    out = []
    for cfg in form_cfgs(db, sid):
        if not cfg["slotted"]:
            continue
        slots = []
        down = down_checker(db, cfg["form_id"], day, day)
        for t, keys in plan(db, sid, cfg["form_id"], cfg, day, day):
            if _human_done(db, cfg["form_id"], t):
                st = "human"
            elif down(t):                                  # v0.84
                st = "down"
            elif db.execute("SELECT 1 FROM cs_submissions WHERE client_uuid=?", (_uuid(sid, cfg["form_id"], t, cfg),)).fetchone():
                st = "done"
            elif ready_at(cfg, t) > now:
                st = "waiting"
            elif slot_values(db, sid, cfg["form_id"], cfg, t, keys):
                st = "ready"
            else:                                         # v0.77 มีค่าดิบแต่นอกช่วงที่เป็นไปได้ทั้งหมด
                st = "invalid" if slot_values(db, sid, cfg["form_id"], cfg, t, keys, check_range=False) else "missing"
            slots.append({"t": t.strftime("%H:%M"), "at": t, "state": st, "label": STATES[st]})
        out.append({**cfg, "slots": slots, "n_missing": sum(1 for x in slots if x["state"] == "missing")})
    return out


def health(db, sid: int, now: datetime | None = None, days: int = LOOKBACK_DAYS) -> dict:
    """สรุปช่องเวลาย้อนหลัง N วัน (รวมวันนี้): ลงแล้ว / ขาด / รอ — สำหรับหน้ารายการแหล่งข้อมูล"""
    now = now or S.now_dt()
    cnt = {k: 0 for k in STATES}
    missing = []
    for i in range(days, -1, -1):
        d = (now - timedelta(days=i)).date()
        for f in slot_status(db, sid, d, now):
            for x in f["slots"]:
                cnt[x["state"]] += 1
                if x["state"] == "missing":
                    missing.append({"form_id": f["form_id"], "form": f.get("eq_code") or f.get("form_code") or f["form_name"],
                                    "at": x["at"], "win": int(f.get("bucket_min") if f["effective"] == "bucket" else f.get("window_min") or 30)})
    due = cnt["done"] + cnt["human"] + cnt["ready"] + cnt["missing"] + cnt["invalid"]
    return {"count": cnt, "missing": missing, "pct": round(100 * (cnt["done"] + cnt["human"]) / due) if due else None}


def _windows(gaps: list[dict]) -> list[tuple[datetime, datetime]]:
    iv = sorted((g["at"] - timedelta(minutes=g["win"] + 2), g["at"] + timedelta(minutes=g["win"] + 2)) for g in gaps)
    out: list[list[datetime]] = []
    for a, b in iv:
        if out and a <= out[-1][1] + timedelta(minutes=5):
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(a, b) for a, b in out]


def heal(db, src: dict, now: datetime | None = None, force: bool = False) -> int:
    """เติมช่องเวลาที่ขาด (เลยเวลาแล้วแต่ยังไม่มีค่า): ดึงจากแหล่งข้อมูลย้อนหลังเฉพาะช่วงรอบช่องนั้น แล้วลงค่า
    ทำได้ทุก HEAL_EVERY_MIN นาที (force = สั่งเองจากหน้าแหล่งข้อมูล) · ค่าที่มาช้า (Historian เขียนย้อนหลัง) จะถูกเก็บได้ครบ"""
    from . import connectors as CN
    now = now or S.now_dt()
    if src.get("kind") == "csv":
        return 0
    last = parse_ts(src["last_heal_at"]) if src.get("last_heal_at") else None
    if not force and last and now - last < timedelta(minutes=HEAL_EVERY_MIN):
        return 0
    created = parse_ts(src["created_at"]) if src.get("created_at") else None
    gaps = [g for g in health(db, src["id"], now)["missing"] if not created or g["at"] >= created - timedelta(days=LOOKBACK_DAYS + 1)]
    if not gaps:
        return 0
    db.execute("UPDATE cs_sources SET last_heal_at=? WHERE id=?", (ts(now), src["id"]))
    tags = CN.mapped_tags(db, src["id"]) or None
    for a, b in _windows(gaps)[:12]:
        try:
            rows, _k, _b = CN.fetch(db, dict(src), now, tags=tags, since=a, until=min(b, now))
        except CN.SourceError as exc:
            log.warning("heal source %s failed: %s", src["id"], exc)
            break
        store_values(db, src, rows, prune=False)
    return fill_slots(db, src, now, form_ids={g["form_id"] for g in gaps})


# ───────────────────────── v0.74 ยกเลิกค่า / แก้ค่า รายช่อง (คงอยู่เมื่อดึงซ้ำ/ลงค่าใหม่) ─────────────────────────

def fixes_at(db, sid: int, form_id: int, t: datetime) -> dict:
    out = {"void_all": False, "void": set(), "value": {}, "reason": {}}
    for r in db.execute("SELECT * FROM cs_source_fixes WHERE source_id=? AND form_id=? AND slot_at=?", (sid, form_id, ts(t))):
        k = r["item_key"] or ""
        out["reason"][k] = r["reason"] or ""
        if r["action"] == "void":
            if k:
                out["void"].add(k)
            else:
                out["void_all"] = True
        elif r["action"] == "value" and k and r["value_num"] is not None:
            out["value"][k] = float(r["value_num"])
    return out


def _slot_sub(db, sid: int, form_id: int, t: datetime, cfg: dict | None = None):
    if cfg is not None:
        return db.execute("SELECT * FROM cs_submissions WHERE client_uuid=?", (_uuid(sid, form_id, t, cfg),)).fetchone()
    return db.execute("SELECT * FROM cs_submissions WHERE client_uuid IN (?,?) ORDER BY id DESC",
                      (_uuid(sid, form_id, t), _uuid(sid, form_id, t, {"effective": "bucket"}))).fetchone()


def rebuild_slot(db, src: dict, form_id: int, t: datetime, actor_id, reason: str) -> int | None:
    """ลงค่าช่องเวลา t ใหม่ (หลังแก้/ยกเลิก/คืนค่า): ใช้ค่าดิบที่มี หรือค่าเดิมของผลตรวจอัตโนมัติถ้าค่าดิบหมดอายุแล้ว"""
    from . import submissions as SUB
    cfg = get_cfg(db, src["id"], form_id)
    old = _slot_sub(db, src["id"], form_id, t, cfg)
    base = {}
    if old:
        base = {r["item_key"]: r["value_num"] for r in db.execute(
            "SELECT item_key, value_num FROM cs_answers WHERE submission_id=? AND value_num IS NOT NULL AND COALESCE(value_src,'')<>'fixed'",
            (old["id"],))}
        SUB.delete_submissions(db, [old["id"]], actor_id, reason or "แก้ค่าจาก SCADA", check_perm=False)
    keys = next((k for tt, k in plan(db, src["id"], form_id, cfg, t.date(), t.date()) if tt == t), None)
    return _create_slot(db, src, cfg, t, keys, _uuid(src["id"], form_id, t, cfg), base)


def _can_fix(db, actor_id) -> None:
    from . import submissions as SUB
    if not SUB.can_approve(db, actor_id):
        raise ValidationError("เฉพาะผู้ดูแลระบบ หัวหน้างาน หรือผู้มีสิทธิ์อนุมัติ แก้/ยกเลิกค่าจาก SCADA ได้")


def set_fix(db, sid: int, form_id: int, t: datetime, item_key: str, action: str, value, reason: str, actor_id) -> dict:
    """action: void (ยกเลิกค่า — item_key '' = ทั้งรอบ) | value (ใช้ค่าที่แก้) — บันทึกแล้วลงค่าช่องนั้นใหม่ทันที"""
    from . import connectors as CN
    _can_fix(db, actor_id)
    src = CN.get_source(db, sid)
    if not src:
        raise ValidationError("ไม่พบแหล่งข้อมูล")
    reason = str(reason or "").strip()
    if len(reason) < 3:
        raise ValidationError("กรุณาระบุเหตุผล (อย่างน้อย 3 ตัวอักษร)")
    item_key = str(item_key or "")
    if action not in ("void", "value"):
        raise ValidationError("คำสั่งไม่ถูกต้อง")
    num = None
    if action == "value":
        if not item_key:
            raise ValidationError("เลือกหัวข้อที่จะแก้ค่า")
        try:
            num = float(str(value).replace(",", "").strip())
        except (TypeError, ValueError):
            raise ValidationError("ค่าที่แก้ต้องเป็นตัวเลข") from None
    old = _slot_sub(db, sid, form_id, t)
    oldv = None
    if old and item_key:
        r = db.execute("SELECT value_num FROM cs_answers WHERE submission_id=? AND item_key=?", (old["id"], item_key)).fetchone()
        oldv = r[0] if r else None
    db.execute("""INSERT INTO cs_source_fixes(source_id, form_id, slot_at, item_key, action, value_num, old_value, reason, created_by, created_at)
                  VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(source_id, form_id, slot_at, item_key) DO UPDATE SET
                  action=excluded.action, value_num=excluded.value_num, old_value=excluded.old_value, reason=excluded.reason,
                  created_by=excluded.created_by, created_at=excluded.created_at""",
               (sid, form_id, ts(t), item_key, action, num, oldv, reason[:300], actor_id, ts()))
    if not item_key and action == "void":                 # ยกเลิกทั้งรอบ → ไม่ต้องเก็บการแก้รายหัวข้อ
        db.execute("DELETE FROM cs_source_fixes WHERE source_id=? AND form_id=? AND slot_at=? AND item_key<>''", (sid, form_id, ts(t)))
    new = rebuild_slot(db, src, form_id, t, actor_id, f"{'ยกเลิกค่า' if action == 'void' else 'แก้ค่า'}จาก SCADA: {reason}")
    S.audit(db, actor_id, "fix", "cs_source_fixes", sid, before={"form_id": form_id, "slot": ts(t), "item": item_key, "value": oldv},
            after={"action": action, "value": num, "reason": reason, "submission": new})
    return {"submission_id": new}


def clear_fix(db, sid: int, form_id: int, t: datetime, item_key: str, actor_id) -> dict:
    """คืนค่าจาก SCADA (ลบการแก้/ยกเลิก) แล้วลงค่าช่องนั้นใหม่"""
    from . import connectors as CN
    _can_fix(db, actor_id)
    src = CN.get_source(db, sid)
    if not src:
        raise ValidationError("ไม่พบแหล่งข้อมูล")
    q, a = "DELETE FROM cs_source_fixes WHERE source_id=? AND form_id=? AND slot_at=?", [sid, form_id, ts(t)]
    if item_key is not None and item_key != "*":
        q += " AND item_key=?"
        a.append(item_key or "")
    n = db.execute(q, a).rowcount
    new = rebuild_slot(db, src, form_id, t, actor_id, "คืนค่าจาก SCADA")
    S.audit(db, actor_id, "unfix", "cs_source_fixes", sid, after={"form_id": form_id, "slot": ts(t), "item": item_key, "removed": n,
                                                                  "submission": new})
    return {"removed": n, "submission_id": new}


def parse_uuid(uuid: str) -> tuple[int, int, datetime] | None:
    """client_uuid ของผลตรวจอัตโนมัติ → (source_id, form_id, เวลาช่อง)"""
    import re
    m = re.match(r"^src(\d+):(\d+):(r?)(\d{12,14})$", uuid or "")
    if not m:
        return None
    d = m.group(4)
    t = datetime.strptime(d[:12], "%Y%m%d%H%M") if m.group(3) else datetime.strptime(d.ljust(14, "0"), "%Y%m%d%H%M%S")
    return int(m.group(1)), int(m.group(2)), t


def void_submission(db, sub_id: int, reason: str, actor_id) -> dict:
    """ยกเลิกค่าอัตโนมัติทั้งรายการ (จากหน้ารออนุมัติ) — ค่าจะไม่ถูกลงซ้ำแม้ดึงข้อมูลใหม่"""
    from . import submissions as SUB
    s = db.execute("SELECT * FROM cs_submissions WHERE id=?", (sub_id,)).fetchone()
    p = parse_uuid(s["client_uuid"]) if s and s["source"] == "auto" else None
    if not p:
        raise ValidationError("รายการนี้ไม่ใช่ค่าอัตโนมัติจาก SCADA")
    sid, fid, t = p
    if get_cfg(db, sid, fid)["slotted"]:                # ตามเวลา / ทุกช่วงเวลา → ยกเลิกแบบคงอยู่ทุกครั้งที่ลงค่า
        return set_fix(db, sid, fid, t, "", "void", None, reason, actor_id)
    _can_fix(db, actor_id)                               # แบบรวมเป็นช่วง (bucket): บันทึกการยกเลิกแล้วลบรายการ
    reason = str(reason or "").strip()
    if len(reason) < 3:
        raise ValidationError("กรุณาระบุเหตุผล (อย่างน้อย 3 ตัวอักษร)")
    db.execute("""INSERT OR REPLACE INTO cs_source_fixes(source_id, form_id, slot_at, item_key, action, reason, created_by, created_at)
                  VALUES (?,?,?,?,?,?,?,?)""", (sid, fid, ts(t), "", "void", reason[:300], actor_id, ts()))
    SUB.delete_submissions(db, [sub_id], actor_id, f"ยกเลิกค่าจาก SCADA: {reason}", check_perm=False)
    return {"submission_id": None}


def slot_voided(db, sid: int, form_id: int, t: datetime) -> bool:
    return db.execute("""SELECT 1 FROM cs_source_fixes WHERE source_id=? AND form_id=? AND slot_at=? AND item_key='' AND action='void'""",
                      (sid, form_id, ts(t))).fetchone() is not None


def notify_pending(db, src: dict, now: datetime | None = None) -> int:
    """ค่าอัตโนมัติรอยืนยัน → แจ้งในระบบ (กระดิ่ง) ผู้มีสิทธิ์อนุมัติของโรงงานนั้น วันละ 1 ครั้งต่อแหล่ง (+ ครั้งใหม่ถ้ามี NG)"""
    from .notify import approvers, notify_user_app
    now = now or S.now_dt()
    rows = db.execute("""SELECT f.factory_id, COUNT(*) n, SUM(s.ng_count>0) ng FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
                         WHERE s.source='auto' AND s.approval_status='pending' AND s.status='submitted' AND s.client_uuid LIKE ?
                         GROUP BY f.factory_id""", (f"src{src['id']}:%",)).fetchall()
    sent = 0
    for r in rows:
        for u in approvers(db) + [dict(x) for x in db.execute("SELECT * FROM users WHERE active=1 AND role='admin'")]:
            if u.get("factory_id") and r["factory_id"] and u["factory_id"] != r["factory_id"] and u["role"] != "admin":
                continue
            ng = int(r["ng"] or 0)
            key = f"autopend:{src['id']}:{r['factory_id']}:{now:%Y%m%d}" + (":ng" if ng else "")
            if notify_user_app(db, u["id"], "auto_pending", f"ค่าจาก SCADA รอยืนยัน {r['n']} รายการ" + (f" (NG {ng})" if ng else ""),
                               f"{src['name']} — ค่าลงในใบตรวจ/รายงานแล้ว ตรวจและยืนยัน หรือยกเลิกค่าที่ผิด",
                               "/approvals?src=auto", "warning" if ng else "info", ref_key=key, now=now):
                sent += 1
    return sent


# ───────────────────────── v0.74 ตรวจสอบการลงค่าย้อนหลัง (ช่วงวันที่) ─────────────────────────
CELL = {"ok": "ลงแล้ว (ยืนยันแล้ว)", "pending": "ลงแล้ว รอยืนยัน", "fixed": "ค่าที่ผู้ดูแลแก้", "void": "ยกเลิกค่าแล้ว",
        "human": "ช่างกรอก", "ready": "มีค่าดิบ ยังไม่ลง", "diff": "ค่าที่ลงไม่ตรงค่าดิบปัจจุบัน", "missing": "ขาด — ไม่มีค่าดิบในช่วงเวลา",
        "invalid": "ค่านอกช่วงที่เป็นไปได้ (ไม่ลง)",
        "noraw": "ไม่มีค่าดิบให้ตรวจ (เก่ากว่าที่เก็บไว้)", "waiting": "ยังไม่ถึงเวลา",
        "down": "เครื่องหยุด / สำรอง — ไม่ลงค่าจาก SCADA"}
AUDIT_MAX_DAYS = 31


def _raw_cache(db, sid: int, tags: list[str], a: datetime, b: datetime) -> dict[str, list[tuple[datetime, float]]]:
    out: dict[str, list] = {t: [] for t in tags}
    if not tags:
        return out
    q = f"""SELECT tag, ts, value FROM cs_source_values WHERE source_id=? AND tag IN ({','.join('?' * len(tags))})
            AND ts BETWEEN ? AND ? ORDER BY ts"""
    for r in db.execute(q, [sid, *tags, _fmt_min(a), _fmt_min(b)]):
        out[r[0]].append((datetime.strptime(r[1], "%Y-%m-%d %H:%M"), r[2]))
    return out


def audit(db, sid: int, d_from: date, d_to: date, form_id: int | None = None, now: datetime | None = None) -> dict:
    """ทุกช่องเวลา × หัวข้อ ในช่วงวันที่: ค่าที่ลง / ที่มา / สถานะยืนยัน / ขาดเพราะอะไร / ค่าดิบตอนนี้ — พร้อมรายการปัญหาที่ต้องแก้"""
    from . import connectors as CN
    now = now or S.now_dt()
    if d_from > d_to:
        d_from, d_to = d_to, d_from
    if (d_to - d_from).days >= AUDIT_MAX_DAYS:
        raise ValidationError(f"เลือกช่วงไม่เกิน {AUDIT_MAX_DAYS} วัน")
    src = CN.get_source(db, sid)
    keep = int(src.get("keep_days") or 35) if src else 35
    raw_since = (now - timedelta(days=keep)).date()
    tot = {k: 0 for k in CELL}
    tot["ng"] = 0
    issues: list[dict] = []
    forms = []
    for cfg in form_cfgs(db, sid):
        if not cfg["slotted"] or (form_id and cfg["form_id"] != form_id):
            continue
        form = S.get_form(db, cfg["form_id"])
        items_all = {i["item_key"]: i for i in S.get_items(db, form["current_version_id"])} if form and form["current_version_id"] else {}
        maps = [dict(r) for r in db.execute("""SELECT tag, item_key, scale, add_offset, valid_min, valid_max FROM cs_source_tags
                                               WHERE source_id=? AND form_id=? AND item_key<>'' ORDER BY item_key""", (sid, cfg["form_id"]))]
        win = int(cfg.get("bucket_min") if cfg["effective"] == "bucket" else cfg.get("window_min") or 30)
        raw = _raw_cache(db, sid, [m["tag"] for m in maps], datetime.combine(d_from, time(0, 0)) - timedelta(minutes=win + 1),
                         datetime.combine(d_to, time(23, 59)) + timedelta(minutes=win + 1))
        items = []
        for m in maps:
            it = items_all.get(m["item_key"], {})
            last = db.execute("SELECT last_seen FROM cs_source_tags WHERE source_id=? AND tag=?", (sid, m["tag"])).fetchone()
            items.append({"key": m["item_key"], "name": it.get("name", m["item_key"]), "unit": it.get("unit", ""), "tag": m["tag"],
                          "scale": m["scale"], "offset": m["add_offset"], "raw_n": len(raw[m["tag"]]),
                          "last_seen": last[0] if last else None, "missing": 0, "invalid": 0,
                          "vmin": m["valid_min"], "vmax": m["valid_max"],
                          "ok_raw": [x for x in raw[m["tag"]] if _in_range(x[1] * float(m["scale"] or 1) + float(m["add_offset"] or 0),
                                                                           m["valid_min"], m["valid_max"])]})
        rows, cnt = [], {k: 0 for k in CELL}
        exact = cfg["effective"] != "bucket" or cfg.get("agg") == "last"     # ค่าเฉลี่ย/ต่ำสุด/สูงสุดแบบเดิมคิดจากค่าละเอียดกว่า → ไม่เทียบ
        cnt["ng"] = 0
        mixed = is_mixed(db, src, cfg["form_id"]) if src else False
        down = down_checker(db, cfg["form_id"], d_from, d_to)
        for t, keys in plan(db, sid, cfg["form_id"], cfg, d_from, d_to):
            dn = down(t)
            sub = _slot_sub(db, sid, cfg["form_id"], t, cfg)
            ans = {r["item_key"]: dict(r) for r in db.execute("SELECT * FROM cs_answers WHERE submission_id=?", (sub["id"],))} if sub else {}
            hum = db.execute("""SELECT s.id FROM cs_rounds r JOIN cs_submissions s ON s.id=r.submission_id
                                WHERE r.form_id=? AND r.due_at=? AND COALESCE(s.source,'')<>'auto'""", (cfg["form_id"], ts(t))).fetchone()
            hans = {r["item_key"]: dict(r) for r in db.execute("SELECT * FROM cs_answers WHERE submission_id=?", (hum[0],))} if hum else {}
            fx = fixes_at(db, sid, cfg["form_id"], t)
            cells = {}
            for itm in items:
                k = itm["key"]
                if keys is not None and k not in keys:
                    cells[k] = None
                    continue
                rv = value_at(itm["ok_raw"], t, cfg)
                rawv = rv * float(itm["scale"] or 1) + float(itm["offset"] or 0) if rv is not None else None
                a = ans.get(k)
                c = {"raw": rawv, "value": None, "ng": False, "note": ""}
                if fx["void_all"] or k in fx["void"]:
                    c["state"] = "void"
                    c["note"] = fx["reason"].get("" if fx["void_all"] else k, "")
                elif a and a.get("value_num") is not None:
                    c["value"] = a["value_num"]
                    c["ng"] = a.get("judgement") == "ng"
                    if k in fx["value"]:
                        c["state"], c["note"] = "fixed", fx["reason"].get(k, "")
                    elif exact and rawv is not None and abs(rawv - a["value_num"]) > max(1e-6, abs(rawv) * 1e-4):
                        c["state"] = "diff"
                    else:
                        c["state"] = "pending" if sub["approval_status"] == "pending" else "ok"
                elif k in hans and (hans[k].get("value_num") is not None or hans[k].get("value_text")):
                    c["state"], c["value"] = "human", hans[k].get("value_num")
                    c["ng"] = hans[k].get("judgement") == "ng"
                elif dn:                                    # v0.84 เครื่องหยุด/สำรอง → ไม่ลงค่า (ยึดสถานะเครื่อง)
                    c["state"], c["note"] = "down", dn["cat"] + (f": {dn['reason']}" if dn["reason"] else "")
                elif ready_at(cfg, t) > now:
                    c["state"] = "waiting"
                elif rawv is not None:
                    c["state"] = "ready"
                elif value_at(raw[itm["tag"]], t, cfg) is not None:     # v0.77 มีค่าแต่นอกช่วงที่เป็นไปได้
                    bad = value_at(raw[itm["tag"]], t, cfg)
                    c["state"], c["raw"] = "invalid", bad * float(itm["scale"] or 1) + float(itm["offset"] or 0)
                    itm["invalid"] += 1
                elif t.date() < raw_since and not itm["raw_n"]:
                    c["state"] = "noraw"
                else:
                    c["state"] = "missing"
                    itm["missing"] += 1
                cnt[c["state"]] += 1
                cnt["ng"] += 1 if c["ng"] else 0
                cells[k] = c
            st = [c["state"] for c in cells.values() if c]
            rows.append({"t": t, "day": t.date(), "hm": t.strftime("%H:%M"), "cells": cells, "sub_id": sub["id"] if sub else None,
                         "approval": sub["approval_status"] if sub else None, "human_id": hum[0] if hum else None,
                         "void_all": fx["void_all"], "down": dn, "problem": any(s in ("missing", "ready", "diff") for s in st)})
        for k in tot:
            tot[k] += cnt.get(k, 0)
        name = cfg.get("eq_code") or cfg.get("form_code") or cfg["form_name"]
        for itm in items:
            if itm["key"] not in items_all:               # v0.75 หัวข้อถูกลบ/เปลี่ยนรหัสในแบบฟอร์มฉบับใหม่
                issues.append({"level": "ng", "form_id": cfg["form_id"], "where": f"{name} · {itm['key']}",
                               "text": f"Tag {itm['tag']} จับคู่กับหัวข้อที่ไม่มีในแบบฟอร์มฉบับปัจจุบันแล้ว — ค่าจะไม่ลง "
                                       "(จับคู่ Tag ใหม่ที่หน้าแหล่งข้อมูล หรือหน้าเลือกหัวข้อของแบบฟอร์ม)"})
        for itm in items:
            if not itm["raw_n"] and d_to >= raw_since:
                issues.append({"level": "ng", "form_id": cfg["form_id"], "where": f"{name} · {itm['name']}",
                               "text": f"Tag {itm['tag']} ไม่มีค่าเลยในช่วงที่เลือก"
                                       + (f" (เห็นล่าสุด {itm['last_seen'][:16]})" if itm["last_seen"] else " (ยังไม่เคยได้ค่า)")
                                       + " — ตรวจชื่อ Tag / การจับคู่ / SCADA ว่ายังส่งค่าอยู่"})
            if itm["invalid"]:
                rng = " – ".join("%g" % x if x is not None else "∞" for x in (itm["vmin"], itm["vmax"]))
                issues.append({"level": "ng", "form_id": cfg["form_id"], "where": f"{name} · {itm['name']}",
                               "text": f"ค่านอกช่วงที่เป็นไปได้ ({rng}) {itm['invalid']} ช่อง — ไม่ลงรายงาน · ตรวจ Sensor/Tag "
                                       "หรือแก้ช่วงที่ตั้ง แล้วกดค่าในช่องเพื่อแก้/ดึงใหม่"})
            if itm["missing"] and not (not itm["raw_n"] and d_to >= raw_since):
                issues.append({"level": "warn", "form_id": cfg["form_id"], "where": f"{name} · {itm['name']}",
                               "text": f"ขาดค่า {itm['missing']} ช่อง (ไม่มีค่าในช่วง ±{win} นาที) — ขยายช่วงเวลา หรือกด “ดึงช่องที่ขาด”"})
        if cnt["ready"]:
            issues.append({"level": "warn", "form_id": cfg["form_id"], "where": name,
                           "text": f"มีค่าดิบแล้วแต่ยังไม่ลง {cnt['ready']} ช่อง — กด “ดึงช่องที่ขาด” เพื่อลงค่า"})
        if cnt["diff"]:
            issues.append({"level": "warn", "form_id": cfg["form_id"], "where": name,
                           "text": f"ค่าที่ลงไว้ไม่ตรงกับค่าดิบปัจจุบัน {cnt['diff']} ช่อง (เปลี่ยนตัวคูณ/Tag/เวลา หลังลงค่า) — กด “ลงค่าใหม่ช่วงนี้”"})
        if cnt["pending"]:
            issues.append({"level": "info", "form_id": cfg["form_id"], "where": name,
                           "text": f"รอยืนยัน {cnt['pending']} ค่า — ค่าลงในรายงานแล้ว ตรวจแล้วยืนยันที่หน้ารออนุมัติ หรือยกเลิกค่าที่ผิด"})
        forms.append({**cfg, "items": items, "rows": rows, "count": cnt, "mixed": mixed})
    if d_from < raw_since:
        issues.append({"level": "info", "form_id": None, "where": "ค่าดิบ",
                       "text": f"เก็บค่าดิบไว้ {keep} วัน — ก่อน {raw_since:%d/%m/%Y} ตรวจเทียบค่าดิบไม่ได้ (ใช้ “ลงค่าใหม่ช่วงนี้” เพื่อดึงจาก SCADA อีกครั้ง)"})
    lvl = {"ng": 0, "warn": 1, "info": 2}
    issues.sort(key=lambda x: lvl[x["level"]])
    due = sum(tot[k] for k in ("ok", "pending", "fixed", "human", "ready", "diff", "missing"))
    return {"from": d_from, "to": d_to, "forms": forms, "count": tot, "issues": issues,
            "pct": round(100 * (tot["ok"] + tot["pending"] + tot["fixed"] + tot["human"]) / due) if due else None}


def fill_range(db, src: dict, d_from: date, d_to: date, now: datetime | None = None) -> dict:
    """ดึงเฉพาะช่องที่ขาดในช่วงวันที่ (ไม่ลบค่าที่ลงแล้ว): ดึงค่าดิบรอบช่องเวลาที่ขาดจาก SCADA → ลงค่า"""
    from . import connectors as CN
    now = now or S.now_dt()
    rep = audit(db, src["id"], d_from, d_to, now=now)
    gaps = []
    for f in rep["forms"]:
        win = int(f.get("bucket_min") if f["effective"] == "bucket" else f.get("window_min") or 30)
        for r in f["rows"]:
            if any(c and c["state"] in ("missing", "noraw") for c in r["cells"].values()):
                gaps.append({"form_id": f["form_id"], "at": r["t"], "win": win})
    fetched = 0
    if gaps and src.get("kind") != "csv":
        try:
            fetched = fetch_windows(db, src, _windows(gaps)[:1000], CN.mapped_tags(db, src["id"]) or None, now)["fetched"]
        except CN.SourceError as exc:
            raise ValidationError(f"ดึงข้อมูลจาก SCADA ไม่สำเร็จ: {exc}") from None
    made = fill_slots(db, src, now, d_from=d_from, d_to=d_to)
    return {"gaps": len(gaps), "fetched": fetched, "created": made}


def audit_xlsx(db, sid: int, d_from: date, d_to: date, form_id: int | None = None) -> bytes:
    import io

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    rep = audit(db, sid, d_from, d_to, form_id)
    fill = {"ok": "DCFCE7", "pending": "FEF9C3", "fixed": "DBEAFE", "void": "E5E7EB", "human": "EDE9FE", "ready": "FFEDD5",
            "diff": "FFEDD5", "missing": "FEE2E2", "noraw": "F3F4F6", "waiting": "FFFFFF"}
    wb = Workbook()
    ws = wb.active
    ws.title = "สรุปปัญหา"
    ws.append([f"ตรวจสอบการลงค่าจาก SCADA {d_from:%d/%m/%Y} – {d_to:%d/%m/%Y}" + (f" · ครบ {rep['pct']}%" if rep["pct"] is not None else "")])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append(["สถานะ", "จำนวนช่อง"])
    for k, v in CELL.items():
        ws.append([v, rep["count"][k]])
    ws.append(["NG", rep["count"]["ng"]])
    ws.append([])
    ws.append(["ระดับ", "ที่", "ปัญหา / สิ่งที่ต้องทำ"])
    for i in rep["issues"]:
        ws.append([{"ng": "ต้องแก้", "warn": "ตรวจ", "info": "ข้อมูล"}[i["level"]], i["where"], i["text"]])
    ws.column_dimensions["A"].width, ws.column_dimensions["B"].width, ws.column_dimensions["C"].width = 30, 36, 90
    for f in rep["forms"]:
        name = (f.get("eq_code") or f.get("form_code") or f["form_name"] or str(f["form_id"]))[:28]
        w = wb.create_sheet("".join("_" if ch in "[]:*?/\\" else ch for ch in name))
        w.append(["วันที่", "เวลา", "สถานะรายการ"] + [f"{i['name']} ({i['unit']})" if i["unit"] else i["name"] for i in f["items"]])
        w.append(["", "", "Tag →"] + [i["tag"] for i in f["items"]])
        for c in w[1]:
            c.font = Font(bold=True)
        for r in f["rows"]:
            st = "ยกเลิกทั้งรอบ" if r["void_all"] else ({"pending": "รอยืนยัน", "approved": "ยืนยันแล้ว"}.get(r["approval"] or "", "") or
                                                     ("ช่างกรอก" if r["human_id"] else "ยังไม่ลง"))
            vals = []
            for i in f["items"]:
                c = r["cells"].get(i["key"])
                vals.append("" if not c else (c["value"] if c["value"] is not None else CELL[c["state"]]))
            w.append([r["t"].strftime("%d/%m/%Y"), r["hm"], st] + vals)
            for j, i in enumerate(f["items"]):
                c = r["cells"].get(i["key"])
                if c:
                    w.cell(row=w.max_row, column=4 + j).fill = PatternFill("solid", fgColor=fill[c["state"]])
                    if c["ng"]:
                        w.cell(row=w.max_row, column=4 + j).font = Font(color="B91C1C", bold=True)
        w.freeze_panes = "D3"
        for j in range(len(f["items"]) + 3):
            w.column_dimensions[w.cell(row=1, column=j + 1).column_letter].width = 12 if j > 2 else 11
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


# ───────────────────────── v0.76 แก้การตั้งค่าแล้วลงค่าย้อนหลังให้เอง ─────────────────────────
REAPPLY_CHOICES = (0, 1, 3, 7, 14, 31, 62)


def mapping_snapshot(db) -> dict:
    """{(source_id, tag): (form_id, item_key, scale, add_offset)} ของ Tag ที่จับคู่แล้วทุกแหล่ง"""
    return {(r[0], r[1]): (r[2], r[3], float(r[4] or 1), float(r[5] or 0), r[6], r[7]) for r in db.execute(
        """SELECT source_id, tag, form_id, item_key, scale, add_offset, valid_min, valid_max FROM cs_source_tags
           WHERE form_id IS NOT NULL AND item_key<>''""")}


def changed_forms(before: dict, after: dict) -> dict[int, set[int]]:
    """แบบฟอร์มที่การจับคู่เปลี่ยน (Tag ใหม่ / ถอด / เปลี่ยนหัวข้อ / ตัวคูณ / ค่าบวก) ต่อแหล่ง"""
    out: dict[int, set[int]] = {}
    for k in set(before) | set(after):
        a, b = before.get(k), after.get(k)
        if a != b:
            for x in (a, b):
                if x:
                    out.setdefault(k[0], set()).add(x[0])
    return out


def reapply(db, sid: int, days: int, actor_id, form_ids: set[int] | None = None, shift: bool = False, now: datetime | None = None) -> dict | None:
    """ลงค่าใหม่ย้อนหลัง N วัน (รวมวันนี้) หลังแก้การตั้งค่า — ดึงจาก SCADA อีกครั้ง · ค่าที่แก้/ยกเลิกไว้ยังคงอยู่
    shift=True (เปลี่ยนเลื่อนเวลา) → ล้างค่าดิบช่วงนั้นก่อน เพราะเวลาเดิมผิด"""
    days = int(days or 0)
    if days <= 0:
        return None
    now = now or S.now_dt()
    d_to = now.date()
    d_from = d_to - timedelta(days=min(days, RELAY_MAX_DAYS) - 1)
    targets = {c["form_id"] for c in form_cfgs(db, sid) if c["slotted"]}
    if form_ids is not None:
        targets &= set(form_ids)
    if not targets:
        return None
    if shift:
        db.execute("DELETE FROM cs_source_values WHERE source_id=? AND ts>=?", (sid, _fmt_min(datetime.combine(d_from, time(0, 0)) - timedelta(days=1))))
    res = relay(db, sid, d_from, d_to, actor_id, targets, check_perm=False)   # ระบบลงค่าใหม่ตามการตั้งค่าที่ผู้ดูแลเพิ่งแก้
    res["days"] = (d_to - d_from).days + 1
    return res


def reapply_mapping(db, before: dict, days: int, actor_id) -> list[str]:
    """เรียกหลังบันทึกการจับคู่: ลงค่าใหม่ย้อนหลังเฉพาะแบบฟอร์มที่เปลี่ยน · คืนข้อความสรุป"""
    msgs = []
    for sid, fids in changed_forms(before, mapping_snapshot(db)).items():
        try:
            r = reapply(db, sid, days, actor_id, fids)
        except ValidationError as exc:
            msgs.append(f"ลงค่าย้อนหลังไม่สำเร็จ: {exc.errors[0]}")
            continue
        if r:
            msgs.append(f"ลงค่าใหม่ย้อนหลัง {r['days']} วัน: {r['forms']} แบบฟอร์ม · สร้างใหม่ {r['created']} รายการ"
                        + (f" · อัปเดตค่า SCADA ในผลของช่าง {r['human_updated']} รายการ" if r.get("human_updated") else ""))
    return msgs


# ───────────────────────── v0.76 ย่อค่าดิบ (เก็บละเอียดเฉพาะที่ต้องใช้) ─────────────────────────
COMPACT_AFTER_DAYS = 3          # เก็บนาทีละค่าเต็มทุก Tag ไว้ N วันล่าสุด (ใช้กับเติมช่องที่ขาด / ค่ามาช้า / เติมค่าในฟอร์มช่าง)
COMPACT_DAYS_PER_RUN = 2


def _keep_windows(db, sid: int, day: date) -> tuple[dict[str, list[tuple[str, str]]], set[str], set[str]]:
    """ช่วงเวลาที่ต้องเก็บค่าดิบของวันนั้น ต่อ Tag: ตามเวลา → ช่องเวลา ± ช่วงเลือกค่า · ทุกช่วง (ค่าล่าสุด) → นาทีสุดท้ายของช่วง
    คืน (ช่วงต่อ Tag, Tag ที่ต้องเก็บทั้งหมด, Tag ที่ใช้เฉพาะนาทีสุดท้ายของช่วง)"""
    win: dict[str, list[tuple[str, str]]] = {}
    keep_all: set[str] = set()
    last_only: set[str] = set()
    for cfg in form_cfgs(db, sid):
        tags = {r[0]: r[1] for r in db.execute("SELECT tag, item_key FROM cs_source_tags WHERE source_id=? AND form_id=? AND item_key<>''",
                                               (sid, cfg["form_id"]))}
        if not cfg["slotted"] or (cfg["effective"] == "bucket" and cfg.get("agg") != "last"):
            keep_all |= set(tags)                         # เฉลี่ย/ต่ำสุด/สูงสุด ต้องใช้ทุกค่าในช่วง
            continue
        if cfg["effective"] == "bucket":
            last_only |= set(tags)
            continue
        for t, keys in plan(db, sid, cfg["form_id"], cfg, day - timedelta(days=1), day + timedelta(days=1)):
            lo, hi = slot_window(cfg, t)
            for tag, k in tags.items():
                if keys is None or k in keys:
                    win.setdefault(tag, []).append((_fmt_min(lo), _fmt_min(hi)))
    return win, keep_all, last_only


def compact_day(db, sid: int, day: date) -> int:
    """ลบค่าดิบของวันนั้นที่ไม่ได้ใช้ลงค่าช่องใดเลย · คืนจำนวนแถวที่ลบ"""
    win, keep_all, last_only = _keep_windows(db, sid, day)
    a, b = f"{day.isoformat()} 00:00", f"{day.isoformat()} 23:59"
    cfg_b = next((c for c in form_cfgs(db, sid) if c["effective"] == "bucket" and c["slotted"]), None)
    drop: list[tuple] = []
    last_seen: dict[tuple[str, str], str] = {}
    rows = db.execute("SELECT tag, ts FROM cs_source_values WHERE source_id=? AND ts BETWEEN ? AND ? ORDER BY tag, ts", (sid, a, b)).fetchall()
    for tag, t in rows:
        if tag in keep_all:
            continue
        if any(lo <= t <= hi for lo, hi in win.get(tag, ())):
            continue
        if tag in last_only and cfg_b:
            key = (tag, _bucket_key(t, int(cfg_b["bucket_min"])))
            prev = last_seen.get(key)
            if prev:
                drop.append((sid, tag, prev))
            last_seen[key] = t
            continue
        drop.append((sid, tag, t))
    db.executemany("DELETE FROM cs_source_values WHERE source_id=? AND tag=? AND ts=?", drop)
    return len(drop)


def _bucket_key(t: str, minutes: int) -> str:
    m = int(t[11:13]) * 60 + int(t[14:16])
    return f"{t[:10]}:{m - m % minutes if minutes else m}"


def compact(db, src: dict, now: datetime | None = None, max_days: int = COMPACT_DAYS_PER_RUN) -> int:
    """ย่อค่าดิบที่เก่ากว่า COMPACT_AFTER_DAYS วัน (ทีละไม่เกิน max_days วันต่อรอบ) — ช่องเวลาทุกช่องยังตรวจสอบ/ลงค่าใหม่ได้"""
    now = now or S.now_dt()
    limit = (now - timedelta(days=COMPACT_AFTER_DAYS)).date()
    done = date.fromisoformat(src["compacted_until"]) if src.get("compacted_until") else None
    if done is None:
        r = db.execute("SELECT MIN(ts) FROM cs_source_values WHERE source_id=?", (src["id"],)).fetchone()[0]
        if not r:
            return 0
        d = date.fromisoformat(r[:10])
    else:
        d = done + timedelta(days=1)
    n, k = 0, 0
    while d < limit and k < max_days:
        n += compact_day(db, src["id"], d)
        db.execute("UPDATE cs_sources SET compacted_until=? WHERE id=?", (d.isoformat(), src["id"]))
        d += timedelta(days=1)
        k += 1
    return n


def raw_stats(db, sid: int) -> dict:
    r = db.execute("SELECT COUNT(*), MIN(ts), COUNT(DISTINCT tag) FROM cs_source_values WHERE source_id=?", (sid,)).fetchone()
    return {"rows": r[0], "oldest": r[1], "tags": r[2], "mb": round(r[0] * 60 / 1e6, 1)}



# ───────────────────────── v0.77 แจ้งค่านอกช่วงที่เป็นไปได้ ─────────────────────────

def check_ranges(db, src: dict, rows, now: datetime | None = None, kind: str = "echeck") -> dict[str, int]:
    """นับค่าที่อยู่นอกช่วงที่เป็นไปได้ต่อ Tag ในข้อมูลรอบนี้ → แจ้งผู้ดูแลระบบ วันละครั้งต่อ Tag"""
    from .srcwatch import _send
    now = now or S.now_dt()
    table = "cs_source_tags" if kind == "echeck" else "en_source_tags"
    rng = {r[0]: (float(r[1] or 1), float(r[2] or 0), r[3], r[4]) for r in db.execute(
        f"SELECT tag, scale, add_offset, valid_min, valid_max FROM {table} WHERE source_id=? AND (valid_min IS NOT NULL OR valid_max IS NOT NULL)",
        (src["id"],))}
    if not rng:
        return {}
    bad: dict[str, list] = {}
    for tag, dt, val in rows:
        r = rng.get(tag)
        if r and val is not None:
            v = float(val) * r[0] + r[1]
            if not _in_range(v, r[2], r[3]):
                bad.setdefault(tag, []).append((dt, v))
    for tag, xs in bad.items():
        lo, hi = rng[tag][2], rng[tag][3]
        span = " – ".join("%g" % x if x is not None else "∞" for x in (lo, hi))
        dt, v = xs[-1]
        _send(db, kind, src, f"⚠ ค่านอกช่วงที่เป็นไปได้: {tag}",
              f"แหล่ง {src['name']} · Tag {tag} ได้ค่านอกช่วง ({span}) {len(xs)} ครั้งในรอบดึงล่าสุด · ล่าสุด {v:g} เมื่อ {dt:%d/%m %H:%M}\n"
              "ค่าเหล่านี้ไม่ลงรายงาน — ตรวจ Sensor / Tag / ตัวคูณ หรือช่วงที่ตั้งไว้",
              "warning", f"srcrange:{kind}:{src['id']}:{tag}:{now:%Y%m%d}", now)
    return {t: len(x) for t, x in bad.items()}
