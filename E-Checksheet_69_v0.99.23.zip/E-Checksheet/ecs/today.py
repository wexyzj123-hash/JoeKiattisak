"""ecs/today.py — v0.50 หน้า "ต้องจัดการวันนี้" ของหัวหน้างาน: 4 กล่อง + ใครอยู่กะตอนนี้

1 รออนุมัติ (ใบที่ปกติทั้งใบ อนุมัติได้ในคลิกเดียว — อ่านเฉพาะใบที่มี NG)
2 NG / แจ้งเตือนที่ยังไม่มีใครรับทราบ
3 ขาดตรวจ / เลยกำหนด แยกตามผู้รับผิดชอบตามตารางกะ
4 เครื่องหยุดที่ค้างอยู่
"""
from __future__ import annotations

from datetime import datetime, timedelta

from . import roster as RO
from . import services as S
from .services import parse_ts, ts

LONG_DOWN_H = 24


def _fac_sql(fids, col: str = "f.factory_id") -> tuple[str, list]:
    if not fids:
        return "", []
    return f" AND ({col} IS NULL OR {col} IN ({','.join('?' * len(fids))}))", list(fids)


def _ago(now: datetime, s) -> str:
    dt = parse_ts(s) if isinstance(s, str) else s
    if not dt:
        return ""
    m = max(0, int((now - dt).total_seconds() // 60))
    if m < 60:
        return f"{m} นาที"
    if m < 2880:
        return f"{m // 60} ชม."
    return f"{m // 1440} วัน"


def build(db, actor_id: int, now: datetime | None = None, cfg=None) -> dict:
    now = now or S.now_dt()
    u = db.execute("SELECT role FROM users WHERE id=?", (actor_id,)).fetchone()
    fids = None if (u and u["role"] == "admin") else RO.factories_of(db, actor_id)
    from .view_scope import sql as _vs_sql
    vs, vp = _vs_sql("f.id")
    fc, fp = _fac_sql(fids)

    # ── 1 รออนุมัติ ──
    pend = [dict(r) for r in db.execute(f"""
        SELECT s.id, s.ng_count, s.warn_count, s.finished_at, s.source, f.name AS form_name, e.code AS eq_code,
               fa.name AS factory_name, iu.name AS inspector_name
        FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN users iu ON iu.id=s.inspector_id
        WHERE s.approval_status='pending' AND s.status='submitted'{fc}{vs}
        ORDER BY s.ng_count DESC, s.warn_count DESC, s.finished_at""", fp + vp)]
    ok_ids = [p["id"] for p in pend if not p["ng_count"]]
    pending = {"total": len(pend), "ok": len(ok_ids), "ok_ids": ok_ids, "warn": sum(1 for p in pend if p["warn_count"] and not p["ng_count"]),
               "ng": [p for p in pend if p["ng_count"]][:12], "ng_n": sum(1 for p in pend if p["ng_count"])}

    # ── 2 NG ยังไม่รับทราบ ──
    al = [dict(r) for r in db.execute(f"""
        SELECT a.id, a.title, a.severity, a.created_at, a.occurrences, a.alert_type, f.name AS form_name, e.code AS eq_code,
               fa.name AS factory_name, iu.name AS reporter
        FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id LEFT JOIN equipment e ON e.id=a.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN cs_submissions sb ON sb.id=a.submission_id LEFT JOIN users iu ON iu.id=sb.inspector_id
        WHERE a.status='open' AND a.alert_type IN ('ng','warn','trend'){fc}{vs}
        ORDER BY CASE a.severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END, a.created_at""", fp + vp)]
    for a in al:
        a["ago"] = _ago(now, a["created_at"])
    alerts = {"n": len(al), "critical": sum(1 for a in al if a["severity"] == "critical"), "rows": al[:12]}

    # ── 3 ขาดตรวจ (24 ชม.) / เลยกำหนดตอนนี้ แยกตามผู้รับผิดชอบ ──
    rr = [dict(r) for r in db.execute(f"""
        SELECT r.id, r.status, r.due_at, r.deadline_at, r.close_at, r.form_id, f.name AS form_name, f.factory_id,
               e.code AS eq_code, fa.name AS factory_name, COALESCE(e.run_status,'running') AS run_status
        FROM cs_rounds r JOIN cs_schedules sc ON sc.id=r.schedule_id JOIN cs_forms f ON f.id=r.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN factories fa ON fa.id=f.factory_id
        WHERE f.active=1 AND sc.active=1 AND (
              (r.status='missed' AND r.close_at >= ? AND r.close_at <= ?)
           OR (r.status IN ('pending','in_progress','overdue') AND r.deadline_at <= ? AND r.close_at > ?)
           OR (r.status IN ('pending','in_progress','overdue') AND r.close_at <= ? AND r.close_at >= ?)){fc}{vs}
        ORDER BY r.due_at""", [ts(now - timedelta(hours=24)), ts(now), ts(now), ts(now), ts(now),
                               ts(now - timedelta(hours=24))] + fp + vp)]
    rr = [r for r in rr if r["run_status"] != "down"]
    techs = [p for p in RO.team(db) if p["role"] == "technician"]
    d0 = min([now] + [parse_ts(r["due_at"]) for r in rr]).date() - timedelta(days=1)
    R = RO.load(db, d0, now.date() + timedelta(days=1), cfg)
    people: dict[str, dict] = {}
    for r in rr:
        due, dl = parse_ts(r["due_at"]), parse_ts(r["deadline_at"])
        missed = r["status"] == "missed" or (parse_ts(r["close_at"]) and parse_ts(r["close_at"]) <= now)
        owners = [p["name"] for p in techs if (p["factories"] is None or r["factory_id"] is None or r["factory_id"] in p["factories"])
                  and RO.covers(R, p["id"], due, dl)]
        key = ", ".join(owners[:3]) + (f" +{len(owners) - 3}" if len(owners) > 3 else "") if owners else "— ไม่มีช่างเข้ากะ —"
        g = people.setdefault(key, {"who": key, "nobody": not owners, "missed": 0, "overdue": 0, "rows": []})
        g["missed" if missed else "overdue"] += 1
        if len(g["rows"]) < 6:
            r["kind"] = "missed" if missed else "overdue"
            g["rows"].append(r)
    late = {"missed": sum(g["missed"] for g in people.values()), "overdue": sum(g["overdue"] for g in people.values()),
            "people": sorted(people.values(), key=lambda g: (-g["missed"] - g["overdue"], g["who"]))}

    # ── 4 เครื่องหยุดค้าง ──
    ec, ep = _fac_sql(fids, "e.factory_id")
    downs = [dict(r) for r in db.execute(f"""
        SELECT e.id, e.code, e.name, e.down_reason, e.down_since, e.down_until, fa.name AS factory_name, du.name AS down_by_name
        FROM equipment e LEFT JOIN factories fa ON fa.id=e.factory_id LEFT JOIN users du ON du.id=e.down_by
        WHERE e.active=1 AND e.run_status='down'{ec} ORDER BY e.down_since""", ep)]
    for d in downs:
        d["ago"] = _ago(now, d["down_since"])
        ds = parse_ts(d["down_since"])
        d["long"] = bool(ds and (now - ds) >= timedelta(hours=LONG_DOWN_H))
    down = {"n": len(downs), "long": sum(1 for d in downs if d["long"]), "rows": downs[:12]}

    cov = RO.coverage(db, now, cfg)
    if fids:
        cov = [c for c in cov if c["id"] in fids]
    total = pending["total"] + alerts["n"] + late["missed"] + late["overdue"] + down["n"]
    from . import handover as HO
    try:
        HO.generate(db, now)
        handovers = HO.recent(db, fids, days=1)[:6]
    except Exception:                                          # noqa: BLE001
        handovers = []
    return {"now": now, "pending": pending, "alerts": alerts, "late": late, "down": down, "coverage": cov, "total": total,
            "source": R["source"], "scoped": bool(fids), "handovers": handovers}
