"""ecs/tagmatch.py — v0.45 เดาการจับคู่ Tag → หัวข้อในแบบฟอร์ม + นำเข้า/ส่งออกการจับคู่เป็น Excel

การเดา (คะแนน 0–100):
- รหัสเครื่องอยู่ในชื่อ Tag (เช่น SCT0003_OIL_PRESS → SCT0003)              สูงสุด 45
- คำในชื่อ Tag ตรงกับชื่อหัวข้อ (แปลงคำย่อ PRESS→PRESSURE, TEMP→TEMPERATURE,
  และคำไทย อุณหภูมิ/แรงดัน/ระดับ ... เป็นคำเดียวกัน)                          สูงสุด 40
- ค่าล่าสุดของ Tag อยู่ในช่วงเกณฑ์ของหัวข้อ                                 15
- หัวข้อที่มี Tag อื่นจับคู่แล้ว −25
"""
from __future__ import annotations

import io
import re
from difflib import SequenceMatcher

from . import services as S
from .services import ValidationError

ABBR = {
    "PRESS": "PRESSURE", "PRS": "PRESSURE", "PRES": "PRESSURE", "PR": "PRESSURE", "PT": "PRESSURE",
    "TEMP": "TEMPERATURE", "TMP": "TEMPERATURE", "TT": "TEMPERATURE", "TE": "TEMPERATURE",
    "LVL": "LEVEL", "LEV": "LEVEL", "LT": "LEVEL", "CURR": "CURRENT", "CUR": "CURRENT", "AMP": "CURRENT", "AMPS": "CURRENT",
    "HR": "HOUR", "HRS": "HOUR", "HOURS": "HOUR", "RUN": "RUNNING", "RUNHR": "HOUR", "DIS": "DISCHARGE", "DISCH": "DISCHARGE",
    "DISC": "DISCHARGE", "SUC": "SUCTION", "SUCT": "SUCTION", "FLW": "FLOW", "FT": "FLOW", "VOLT": "VOLTAGE", "VOL": "VOLTAGE",
    "WTR": "WATER", "IN": "INLET", "INL": "INLET", "INLT": "INLET", "OUT": "OUTLET", "OUTL": "OUTLET", "SPD": "SPEED",
    "VIB": "VIBRATION", "FREQ": "FREQUENCY", "HZ": "FREQUENCY", "DP": "DIFFERENTIAL", "DIFF": "DIFFERENTIAL",
    "FIRST": "1ST", "SECOND": "2ND", "TOT": "TOTAL", "LD": "LOAD", "LOADHR": "LOAD", "CHW": "CHILLED", "CW": "COOLING",
    "SUP": "SUPPLY", "RET": "RETURN", "RTN": "RETURN", "HUM": "HUMIDITY", "RH": "HUMIDITY",
}
THAI = (("อุณหภูมิ", "TEMPERATURE"), ("แรงดันไฟ", "VOLTAGE"), ("แรงดัน", "PRESSURE"), ("ความดัน", "PRESSURE"),
        ("ระดับ", "LEVEL"), ("กระแส", "CURRENT"), ("ชั่วโมง", "HOUR"), ("อัตราการไหล", "FLOW"), ("การไหล", "FLOW"),
        ("น้ำมัน", "OIL"), ("น้ำ", "WATER"), ("ขาเข้า", "INLET"), ("ขาออก", "OUTLET"), ("ความชื้น", "HUMIDITY"),
        ("ความเร็ว", "SPEED"), ("สั่น", "VIBRATION"), ("ความถี่", "FREQUENCY"), ("โหลด", "LOAD"))
KINDS = {"PRESSURE", "TEMPERATURE", "LEVEL", "CURRENT", "VOLTAGE", "FLOW", "HOUR", "HUMIDITY", "SPEED", "VIBRATION",
         "FREQUENCY", "PH", "KW", "KWH", "PF"}
STOP = {"THE", "OF", "AND", "VALUE", "PV", "AI", "DI", "TAG", "SIGNAL"}
MIN_SHOW = 45


def _compact(s: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(s or "").upper())


def _tokens(s: str) -> set[str]:
    raw = str(s or "")
    out = set()
    for th, en in THAI:
        if th in raw:
            out.add(en)
    for w in re.split(r"[^A-Za-z0-9]+", re.sub(r"([a-z])([A-Z])", r"\1 \2", raw).upper()):
        if not w or w in STOP:
            continue
        m = re.match(r"^(\d+)(ST|ND|RD|TH)$", w)
        w = ABBR.get(w, w)
        if w == "TEMPERATURE" or w.startswith("TEMP"):
            w = "TEMPERATURE"
        if w.startswith("PRESS"):
            w = "PRESSURE"
        if not m and w.isdigit():                      # เลขลำดับหัวข้อ (12.) ไม่ใช่ส่วนของชื่อ
            continue
        out.add(w)
    return out


def _targets(db) -> list[dict]:
    rows = db.execute("""
        SELECT f.id AS form_id, f.code AS form_code, f.name AS form_name, e.code AS eq_code, i.item_key, i.name, i.unit,
               i.item_type, i.min_value, i.max_value
        FROM cs_forms f JOIN cs_form_items i ON i.version_id=f.current_version_id LEFT JOIN equipment e ON e.id=f.equipment_id
        WHERE f.active=1 AND COALESCE(f.is_template,0)=0 AND i.item_type IN ('number','counter')
        ORDER BY e.code, f.name, i.order_no""").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["eqc"] = _compact(d["eq_code"])
        d["tok"] = _tokens(d["name"])
        out.append(d)
    return out


def score(tag: str, last_value, t: dict, used: set) -> tuple[int, list[str]]:
    tc = _compact(tag)
    why = []
    sc = 0.0
    rest = tag
    if t["eqc"] and len(t["eqc"]) >= 3 and t["eqc"] in tc:
        sc += 45
        why.append(f"รหัสเครื่อง {t['eq_code']}")
        rest = re.sub(re.escape(t["eq_code"] or ""), " ", tag, flags=re.I)
    tt = _tokens(rest)
    it = t["tok"] or _tokens(t["name"])
    if tt and it:
        inter = tt & it
        cov = len(inter) / len(it)
        prec = len(inter) / len(tt)
        name = 0.7 * cov + 0.3 * prec
        name = max(name, 0.8 * SequenceMatcher(None, " ".join(sorted(tt)), " ".join(sorted(it))).ratio() - 0.2)
        sc += 40 * min(1.0, name)
        if inter:
            why.append("ชื่อตรง: " + ", ".join(sorted(inter)[:4]))
    mn, mx = t["min_value"], t["max_value"]
    ot, oi = {w for w in tt if re.match(r"^\d+(ST|ND|RD|TH)$", w)}, {w for w in it if re.match(r"^\d+(ST|ND|RD|TH)$", w)}
    if ot and oi and not (ot & oi):                     # ลำดับขัดกัน (1st ≠ 2nd)
        sc -= 30
        why.append("ลำดับไม่ตรง")
    kt, ki = tt & KINDS, it & KINDS
    if kt and ki and not (kt & ki):                     # ชนิดค่าขัดกัน (Tag = ความดัน แต่หัวข้อ = อุณหภูมิ)
        sc -= 30
        why.append("ชนิดค่าไม่ตรง")
    if last_value is not None and (mn is not None or mx is not None):
        if mn is not None and mx is not None:
            span = (mx - mn) or abs(mx) or 1
            inside = mn - span * 0.5 <= last_value <= mx + span * 0.5
        elif mx is not None:                            # มีแค่ค่าสูงสุด เช่น ≤ 200 °C → ค่าควรอยู่ราว 10–150% ของเกณฑ์
            inside = (mx * 0.1 <= last_value <= mx * 1.5) if mx > 0 else last_value <= mx + 1
        else:
            inside = (mn * 0.5 <= last_value <= mn * 10) if mn > 0 else last_value >= mn - 1
        if inside:
            sc += 15
            why.append("ค่าล่าสุดอยู่ในช่วงเกณฑ์")
    if (t["form_id"], t["item_key"]) in used:
        sc -= 25
        why.append("หัวข้อนี้มี Tag อื่นแล้ว")
    if "รหัสเครื่อง" not in " ".join(why):
        sc = min(sc, 55)                                 # ไม่พบรหัสเครื่อง → ไม่มั่นใจ
    return max(0, min(100, round(sc))), why


def suggest(db, sid: int) -> dict[str, dict]:
    """คำแนะนำสำหรับ Tag ที่ยังไม่จับคู่: {tag: {target, label, score, why}}"""
    tags = db.execute("SELECT tag, last_value, form_id, item_key FROM cs_source_tags WHERE source_id=?", (sid,)).fetchall()
    used = {(r["form_id"], r["item_key"]) for r in tags if r["form_id"] and r["item_key"]}
    targets = _targets(db)
    out = {}
    for r in tags:
        if r["form_id"] and r["item_key"]:
            continue
        best = None
        for t in targets:
            sc, why = score(r["tag"], r["last_value"], t, used)
            if not best or sc > best[0]:
                best = (sc, why, t)
        if best and best[0] >= MIN_SHOW:
            t = best[2]
            out[r["tag"]] = {"target": f"{t['form_id']}:{t['item_key']}", "score": best[0], "why": " · ".join(best[1]),
                             "label": f"{t['eq_code'] or t['form_name']} · {t['name']}" + (f" ({t['unit']})" if t["unit"] else "")}
    return out


# ───────────────────────── Excel ─────────────────────────
HEAD = ["Tag", "ค่าล่าสุด", "เวลาล่าสุด", "รหัสแบบฟอร์ม", "รหัสเครื่อง", "รหัสหัวข้อ", "ชื่อหัวข้อ", "หน่วย", "ตัวคูณ", "ค่าบวก",
        "ค่าต่ำสุดที่เป็นไปได้", "ค่าสูงสุดที่เป็นไปได้", "คำแนะนำของระบบ (ไม่ต้องแก้)"]


def export_xlsx(db, sid: int) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    src = db.execute("SELECT name FROM cs_sources WHERE id=?", (sid,)).fetchone()
    tags = db.execute("""SELECT t.*, f.code AS form_code, e.code AS eq_code, i.name AS item_name, i.unit
                         FROM cs_source_tags t LEFT JOIN cs_forms f ON f.id=t.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
                         LEFT JOIN cs_form_items i ON i.version_id=f.current_version_id AND i.item_key=t.item_key
                         WHERE t.source_id=? ORDER BY (t.form_id IS NULL), t.tag""", (sid,)).fetchall()
    sug = suggest(db, sid)
    wb = Workbook()
    ws = wb.active
    ws.title = "จับคู่ Tag"
    ws.append(HEAD)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1D4ED8")
        c.alignment = Alignment(vertical="center", wrap_text=True)
    for r in tags:
        s = sug.get(r["tag"])
        ws.append([r["tag"], r["last_value"], r["last_seen"], r["form_code"] or "", r["eq_code"] or "", r["item_key"] or "",
                   r["item_name"] or "", r["unit"] or "", r["scale"], r["add_offset"], r["valid_min"], r["valid_max"],
                   f"{s['label']} [{s['target'].split(':', 1)[1]}] {s['score']}%" if s else ""])
    for col, w in zip("ABCDEFGHIJKLM", (28, 11, 18, 14, 12, 14, 30, 10, 9, 9, 12, 12, 46)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "B2"
    ref = wb.create_sheet("หัวข้อที่เลือกได้")
    ref.append(["รหัสแบบฟอร์ม", "รหัสเครื่อง", "ชื่อแบบฟอร์ม", "รหัสหัวข้อ", "ชื่อหัวข้อ", "หน่วย", "เกณฑ์ต่ำ", "เกณฑ์สูง"])
    for c in ref[1]:
        c.font = Font(bold=True)
    for t in _targets(db):
        ref.append([t["form_code"], t["eq_code"] or "", t["form_name"], t["item_key"], t["name"], t["unit"] or "",
                    t["min_value"], t["max_value"]])
    for col, w in zip("ABCDEFGH", (14, 12, 34, 14, 30, 10, 10, 10)):
        ref.column_dimensions[col].width = w
    help_ = wb.create_sheet("วิธีใช้")
    for line in (f"แหล่งข้อมูล: {src['name'] if src else sid}",
                 "1) กรอก รหัสแบบฟอร์ม (หรือ รหัสเครื่อง ถ้าเครื่องมีแบบฟอร์มเดียว) และ รหัสหัวข้อ (หรือ ชื่อหัวข้อ) ของแต่ละ Tag",
                 "2) ดูรหัสได้จากชีต 'หัวข้อที่เลือกได้' · คอลัมน์คำแนะนำของระบบใช้ช่วยกรอก",
                 "3) เว้นว่างทั้งรหัสแบบฟอร์มและรหัสเครื่อง = ไม่ใช้ Tag นั้น · เพิ่มแถว Tag ใหม่ได้",
                 "4) ตัวคูณ/ค่าบวก: ค่าที่ใช้ = ค่าจาก Tag × ตัวคูณ + ค่าบวก (ว่าง = 1 และ 0)",
                 "   ค่าต่ำสุด/สูงสุดที่เป็นไปได้: ค่า (หลังคูณ/บวก) ที่อยู่นอกช่วงถือว่า Sensor ผิดพลาด ไม่ลงรายงาน (ว่าง = ไม่จำกัด)",
                 "5) บันทึกแล้วนำเข้าที่หน้าแหล่งข้อมูล › จับคู่ Tag › นำเข้า Excel"):
        help_.append([line])
    help_.column_dimensions["A"].width = 120
    dv = DataValidation(type="decimal", allow_blank=True)
    ws.add_data_validation(dv)
    dv.add("I2:L5000")
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _resolve(db, form_code: str, eq_code: str, item: str) -> tuple[str | None, str]:
    """→ ('form_id:item_key' | '' = ไม่ใช้, ข้อผิดพลาด)"""
    form_code, eq_code, item = (str(x or "").strip() for x in (form_code, eq_code, item))
    if not form_code and not eq_code:
        return "", ""
    if form_code:
        forms = db.execute("SELECT id FROM cs_forms WHERE UPPER(code)=UPPER(?) AND COALESCE(is_template,0)=0", (form_code,)).fetchall()
        if not forms:
            return None, f"ไม่พบรหัสแบบฟอร์ม {form_code}"
    else:
        forms = db.execute("""SELECT f.id FROM cs_forms f JOIN equipment e ON e.id=f.equipment_id
                              WHERE UPPER(e.code)=UPPER(?) AND f.active=1 AND COALESCE(f.is_template,0)=0""", (eq_code,)).fetchall()
        if not forms:
            return None, f"ไม่พบแบบฟอร์มของเครื่อง {eq_code}"
        if len(forms) > 1:
            return None, f"เครื่อง {eq_code} มี {len(forms)} แบบฟอร์ม — กรุณาใส่รหัสแบบฟอร์ม"
    fid = forms[0][0]
    if not item:
        return None, "ยังไม่ได้ระบุหัวข้อ"
    form = S.get_form(db, fid)
    items = [i for i in S.get_items(db, form["current_version_id"]) if i["item_type"] in ("number", "counter")] \
        if form and form["current_version_id"] else []
    hit = next((i for i in items if i["item_key"] == item), None) \
        or next((i for i in items if i["name"].strip().lower() == item.lower()), None)
    if not hit:
        return None, f"ไม่พบหัวข้อตัวเลข '{item}' ในแบบฟอร์ม {form_code or eq_code}"
    return f"{fid}:{hit['item_key']}", ""


def import_xlsx(db, sid: int, data: bytes, actor_id) -> dict:
    from openpyxl import load_workbook

    from .connectors import save_mapping
    try:
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except Exception:                                   # noqa: BLE001
        raise ValidationError("อ่านไฟล์ Excel ไม่ได้ — ใช้ไฟล์ .xlsx ที่ส่งออกจากหน้านี้") from None
    ws = wb["จับคู่ Tag"] if "จับคู่ Tag" in wb.sheetnames else wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        raise ValidationError("ไฟล์ว่าง")
    head = [str(c or "").strip() for c in rows[0]]
    col = {h: i for i, h in enumerate(head)}
    if "Tag" not in col:
        raise ValidationError("ไม่พบคอลัมน์ 'Tag' ในแถวแรก")

    def get(r, name):
        i = col.get(name)
        return r[i] if i is not None and i < len(r) else None
    ok, unmapped, errors = 0, 0, []
    for n, r in enumerate(rows[1:], start=2):
        tag = str(get(r, "Tag") or "").strip()
        if not tag:
            continue
        target, err = _resolve(db, get(r, "รหัสแบบฟอร์ม"), get(r, "รหัสเครื่อง"), get(r, "รหัสหัวข้อ") or get(r, "ชื่อหัวข้อ"))
        if target is None:
            errors.append(f"แถว {n} ({tag}): {err}")
            continue
        try:
            m = {"tag": tag, "target": target, "scale": get(r, "ตัวคูณ"), "add_offset": get(r, "ค่าบวก")}
            if "ค่าต่ำสุดที่เป็นไปได้" in col or "ค่าสูงสุดที่เป็นไปได้" in col:
                m.update(valid_min=get(r, "ค่าต่ำสุดที่เป็นไปได้"), valid_max=get(r, "ค่าสูงสุดที่เป็นไปได้"))
            save_mapping(db, sid, [m], actor_id)
        except ValidationError as exc:
            errors.append(f"แถว {n} ({tag}): {exc.errors[0]}")
            continue
        if target:
            ok += 1
        else:
            unmapped += 1
    S.audit(db, actor_id, "import", "cs_source_tags", sid, after={"mapped": ok, "unmapped": unmapped, "errors": len(errors)})
    return {"mapped": ok, "unmapped": unmapped, "errors": errors}


# ───────────────────────── v0.78 จัดกลุ่ม Tag ตามเครื่อง (หน้าจับคู่) ─────────────────────────
_SEPS = ".:/\\|"


def _short(tags: list[str]) -> dict[str, str]:
    """ชื่อสั้นของ Tag ในกลุ่ม = ตัดส่วนหน้าที่เหมือนกัน (ถึงตัวคั่น . : /) ออก"""
    import os
    if not tags:
        return {}
    cp = os.path.commonprefix(tags) if len(tags) > 1 else tags[0]
    cut = max((cp.rfind(c) for c in _SEPS), default=-1)
    out = {}
    for t in tags:
        s = t[cut + 1:] if cut >= 0 and len(t) > cut + 1 else t
        out[t] = s.strip() or t
    return out


def _forms(db) -> list[dict]:
    """แบบฟอร์มที่มีหัวข้อตัวเลข (เลือกจับคู่ได้) + รหัสสำหรับเดาเครื่องจากชื่อ Tag"""
    rows = db.execute("""SELECT f.id, f.code, f.name, e.code AS eq_code, e.name AS eq_name FROM cs_forms f
                         LEFT JOIN equipment e ON e.id=f.equipment_id
                         WHERE f.active=1 AND COALESCE(f.is_template,0)=0 AND EXISTS (SELECT 1 FROM cs_form_items i
                               WHERE i.version_id=f.current_version_id AND i.item_type IN ('number','counter'))
                         ORDER BY e.code, f.name""").fetchall()
    return [dict(r) for r in rows]


def _guess(tag: str, codes: list[tuple[str, int]]) -> int | None:
    """เดาเครื่องจากรหัสที่อยู่ในชื่อ Tag (ต้องเป็นคำเต็ม เช่น .SCT0004.) — เลือกรหัสที่ยาวที่สุด"""
    t = tag.upper()
    for code, fid in codes:
        i = t.find(code)
        while i >= 0:
            before = t[i - 1] if i > 0 else " "
            after = t[i + len(code)] if i + len(code) < len(t) else " "
            if not before.isalnum() and not after.isalnum():
                return fid
            i = t.find(code, i + 1)
    return None


def _device(tag: str) -> str:
    """ชื่อเครื่องจากโครงสร้าง Tag (ส่วนก่อนชื่อจุดวัด) เช่น data:F2 Air compressor.SCT0018.2DIS_PRESS → SCT0018"""
    parts = [p for p in re.split(r"[./\\|]", tag or "") if p.strip()]
    return parts[-2].strip() if len(parts) >= 2 else ""


def _limits(db, form_id: int) -> dict:
    """{item_key: [min, max, unit]} ของแบบฟอร์มฉบับปัจจุบัน (หัวข้อตัวเลข)"""
    return {r[0]: [r[1], r[2], r[3] or ""] for r in db.execute(
        """SELECT i.item_key, i.min_value, i.max_value, i.unit FROM cs_forms f JOIN cs_form_items i ON i.version_id=f.current_version_id
           WHERE f.id=? AND i.item_type IN ('number','counter')""", (form_id,))}


def group_tags(db, sid: int, tags: list[dict], sug: dict) -> dict:
    """จัด Tag ของแหล่งข้อมูลเป็นกลุ่มต่อเครื่อง/แบบฟอร์ม
    - จับคู่แล้ว → กลุ่มของแบบฟอร์มที่จับคู่
    - ยังไม่จับคู่ → เดาเครื่องจากรหัสในชื่อ Tag (หรือคำแนะนำของระบบ) · เดาไม่ได้ → กลุ่ม "ไม่รู้เครื่อง"
    คืน {groups, forms (สำหรับเลือก เครื่อง → หัวข้อ), totals}"""
    from .connectors import mapping_targets
    forms = {f["id"]: f for f in _forms(db)}
    extra = {t["form_id"] for t in tags if t.get("form_id") and t["form_id"] not in forms}
    for fid in extra:                                     # จับคู่ไว้กับแบบฟอร์มที่ไม่อยู่ในรายการเลือก (เช่น แม่แบบ) — ไม่ให้หลุด
        r = db.execute("""SELECT f.id, f.code, f.name, e.code AS eq_code, e.name AS eq_name FROM cs_forms f
                          LEFT JOIN equipment e ON e.id=f.equipment_id WHERE f.id=?""", (fid,)).fetchone()
        if r:
            forms[fid] = dict(r)
    items: dict[int, list[dict]] = {}
    for x in mapping_targets(db):
        items.setdefault(x["form_id"], []).append({"key": x["item_key"], "name": x["name"], "unit": x["unit"] or ""})
    codes = sorted({(str(c).upper(), fid) for fid, f in forms.items() for c in (f.get("eq_code"), f.get("code")) if c and len(str(c)) >= 3},
                   key=lambda x: -len(x[0]))
    groups: dict = {}
    for i, t in enumerate(tags):
        row = dict(t, idx=i)
        fid = t.get("form_id") if t.get("form_id") and t.get("item_key") else None
        kind = "mapped"
        if fid not in forms:
            fid = None
        if not fid:
            fid = _guess(t["tag"], codes)
            s = sug.get(t["tag"])
            if not fid and s and s.get("score", 0) >= 70:      # v0.80 คำแนะนำที่ไม่มั่นใจ ไม่ดึง Tag เครื่องอื่นมาปน
                fid = int(s["target"].split(":", 1)[0])
                fid = fid if fid in forms else None
            kind = "guess" if fid else "unknown"
        gk = fid if fid else ("u", _device(t["tag"]))           # v0.79 ไม่รู้เครื่อง → แยกการ์ดตามชื่อเครื่องใน Tag
        g = groups.setdefault(gk, {"form_id": fid or None, "tags": [], "form": forms.get(fid) if fid else None,
                                   "dev": "" if fid else gk[1]})
        row["kind"] = kind
        row["adv"] = (float(t.get("scale") or 1) != 1 or float(t.get("add_offset") or 0) != 0
                      or t.get("valid_min") is not None or t.get("valid_max") is not None)
        g["tags"].append(row)
    out = []
    for gi, (gk, g) in enumerate(groups.items()):
        fid = g["form_id"]
        short = _short([r["tag"] for r in g["tags"]])
        mapped_keys: dict[str, list[str]] = {}
        for r in g["tags"]:
            r["short"] = short[r["tag"]]
            if r["kind"] == "mapped" and r.get("form_id") == fid:
                mapped_keys.setdefault(r["item_key"], []).append(r["tag"])
        for r in g["tags"]:
            r["dup"] = r["kind"] == "mapped" and len(mapped_keys.get(r.get("item_key"), [])) > 1
        its = items.get(fid, []) if fid else []
        known = {x["key"] for x in its}
        for r in g["tags"]:
            r["gone"] = r["kind"] == "mapped" and r.get("item_key") not in known   # หัวข้อถูกลบจากแบบฟอร์มฉบับปัจจุบัน
        missing = [x for x in its if x["key"] not in mapped_keys]
        n_unmapped = sum(1 for r in g["tags"] if r["kind"] != "mapped")
        n_dup = sum(1 for r in g["tags"] if r["dup"])
        # v0.79 ครบ = ทุกหัวข้อมี Tag และไม่ซ้ำ (Tag ที่เหลือไม่ใช้ได้) · ต้องทำ = หัวข้อยังขาดและยังมี Tag ให้เลือก
        status = "unknown" if not fid else ("warn" if n_dup else ("ok" if not missing else ("todo" if n_unmapped else "warn")))
        f = g["form"] or {}
        g["tags"].sort(key=lambda r: (r["kind"] == "mapped", r["short"].lower()))
        out.append({"form_id": fid or None, "gid": f"g{fid}" if fid else f"gu{gi}", "dev": g["dev"],
                    "eq_code": (f.get("eq_code") or f.get("code") or "") if fid else g["dev"], "form_name": f.get("name") or "",
                    "eq_name": f.get("eq_name") or "", "tags": g["tags"], "n_items": len(its), "n_mapped_items": len(mapped_keys),
                    "missing": missing, "n_unmapped": n_unmapped, "n_dup": n_dup, "status": status,
                    "n_sug": sum(1 for r in g["tags"] if r["kind"] != "mapped" and r["tag"] in sug)})
    out.sort(key=lambda g: (g["status"] == "unknown", not g["dev"] if g["status"] == "unknown" else 0, g["eq_code"] or "~", g["form_name"]))
    fjson = {fid: {"label": f"{(f.get('eq_code') or f.get('code') or '')} · {f['name']}".strip(" ·"),
                   "items": [[x["key"], x["name"] + (f" ({x['unit']})" if x["unit"] else "")] for x in items.get(fid, [])],
                   "lim": _limits(db, fid)}                   # v0.83 เกณฑ์ของหัวข้อ → ดูตัวอย่างค่าที่จะลง / เตือนหน่วยไม่ตรง
             for fid, f in forms.items() if items.get(fid)}
    tot = {"groups": sum(1 for g in out if g["form_id"]), "tags": len(tags),
           "mapped": sum(1 for t in tags if t.get("form_id") and t.get("item_key")),
           "todo": sum(1 for g in out if g["status"] == "todo"), "warn": sum(1 for g in out if g["status"] == "warn"),
           "unknown": sum(g["n_unmapped"] for g in out if not g["form_id"])}
    tot["unmapped"] = tot["tags"] - tot["mapped"]
    return {"groups": out, "forms": fjson, "totals": tot}
