"""ecs/insights.py — v0.93 Dashboard E-Check: เจาะลึกการตรวจ

trending()     ค่าที่ยังผ่านเกณฑ์ แต่กำลังเข้าใกล้ Min/Max หรือผิดกฎ SPC (จะ NG ก่อนจะ NG จริง)
shift_rate()   ตรวจตรงเวลา แยก พื้นที่ × กะ (กลางวัน/กลางคืน ตามเวลากะในปฏิทิน) + สรุปรายผู้ตรวจ
machines()     สถานะเครื่องจักร เดิน / หยุดซ่อม / สำรอง · รอบที่ข้ามเพราะเครื่องหยุด แยกจากรอบที่ขาดตรวจจริง
doc_ready()    เอกสารพร้อมรับตรวจ: ใบบันทึกรายเดือนลงนามครบหรือยัง · ผลตรวจที่ยังไม่อนุมัติ
"""
from __future__ import annotations

import statistics
from datetime import date, datetime, time, timedelta

from . import services as S
from .services import parse_ts, ts

NUMERIC = ("number", "counter", "calc", "numeric", "float", "int")
ROUND_DONE = ("done_on_time", "done_late")


def _fac_sql(factory_id, alias="f") -> tuple[str, list]:
    return (f" AND {alias}.factory_id=?", [factory_id]) if factory_id else ("", [])


# ───────────────────────── 3) ค่าที่กำลังเข้าใกล้เกณฑ์ ─────────────────────────

def _slope_per_day(pts: list[tuple[datetime, float]]) -> float | None:
    if len(pts) < 4:
        return None
    t0 = pts[0][0]
    xs = [(t - t0).total_seconds() / 86400 for t, _ in pts]
    ys = [v for _, v in pts]
    mx, my = statistics.mean(xs), statistics.mean(ys)
    den = sum((x - mx) ** 2 for x in xs)
    if den <= 0:
        return None
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den


def trending(db, day: date, factory_id: int | None = None, days: int = 30, horizon: int = 14, limit: int = 12) -> list[dict]:
    """หัวข้อตัวเลขที่ค่าล่าสุดยังไม่ NG แต่:
    · near    อยู่ใน 10% สุดท้ายของช่วงเกณฑ์ (ใกล้ Min หรือ Max)
    · slope   แนวโน้มวิ่งเข้าหาเกณฑ์ และจะถึงภายใน horizon วัน
    · run     7 จุดล่าสุดอยู่ฝั่งเดียวของค่าเฉลี่ย (SPC)
    · sigma   ค่าล่าสุดหลุด ±3σ ของช่วงก่อนหน้า (SPC)
    · warn    เข้าช่วงเตือนบ่อย (≥ 3 ครั้งใน N วัน)
    เรียงตามความเร่งด่วน (วันที่จะถึงเกณฑ์ → จำนวนกฎที่เข้า)"""
    end = datetime.combine(day + timedelta(days=1), time(0, 0))
    start = end - timedelta(days=days)
    fac, fp = _fac_sql(factory_id)
    rows = db.execute(f"""
        SELECT s.form_id, a.item_key, a.value_num, a.judgement, s.finished_at,
               fi.name AS item_name, fi.unit, fi.min_value, fi.max_value, fi.warn_low, fi.warn_high, fi.item_type,
               f.name AS form_name, f.code AS form_code, e.code AS eq_code, e.name AS eq_name, fa.name AS factory_name
        FROM cs_answers a
        JOIN cs_submissions s ON s.id=a.submission_id
        JOIN cs_forms f ON f.id=s.form_id
        JOIN cs_form_items fi ON fi.id=a.item_id
        LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        WHERE s.status<>'superseded' AND s.finished_at>=? AND s.finished_at<? AND a.value_num IS NOT NULL
          AND f.active=1 AND (fi.min_value IS NOT NULL OR fi.max_value IS NOT NULL) {fac}
        ORDER BY s.form_id, a.item_key, s.finished_at""", [ts(start), ts(end), *fp]).fetchall()
    series: dict[tuple, dict] = {}
    for r in rows:
        k = (r["form_id"], r["item_key"])
        g = series.setdefault(k, {"meta": dict(r), "pts": [], "j": []})
        t = parse_ts(r["finished_at"])
        if t:
            g["pts"].append((t, float(r["value_num"])))
            g["j"].append(r["judgement"])
            g["meta"].update({x: r[x] for x in ("item_name", "unit", "min_value", "max_value", "warn_low", "warn_high")})
    out = []
    for (fid, key), g in series.items():
        pts, m = g["pts"], g["meta"]
        if len(pts) < 3 or g["j"][-1] == "ng":
            continue                                       # NG แล้ว = อยู่ในแจ้งเตือน/CAPA อยู่แล้ว
        lo, hi = m["min_value"], m["max_value"]
        last_t, last = pts[-1]
        if (lo is not None and last < lo) or (hi is not None and last > hi):
            continue                                       # นอกเกณฑ์แล้ว = NG
        rules, eta, side = [], None, None
        span = (hi - lo) if lo is not None and hi is not None and hi > lo else None
        if span:
            pos = (last - lo) / span
            if pos >= 0.9:
                rules.append("near")
                side = "max"
            elif pos <= 0.1:
                rules.append("near")
                side = "min"
        else:
            ref = abs(hi if hi is not None else lo) or 1.0
            if hi is not None and hi - last <= 0.1 * ref:
                rules.append("near")
                side = "max"
            if lo is not None and last - lo <= 0.1 * ref:
                rules.append("near")
                side = "min"
        sl = _slope_per_day(pts[-14:])
        if sl:
            if sl > 0 and hi is not None and last < hi:
                d = (hi - last) / sl
                if d <= horizon:
                    eta, side = d, "max"
            elif sl < 0 and lo is not None and last > lo:
                d = (last - lo) / -sl
                if d <= horizon:
                    eta, side = d, "min"
            if eta is not None:
                rules.append("slope")
        vals = [v for _, v in pts]
        base = vals[:-7] if len(vals) >= 14 else vals[:-1]
        if len(base) >= 7:
            mu = statistics.mean(base)
            sd = statistics.pstdev(base)
            tail = vals[-7:]
            if len(tail) == 7 and (all(v > mu for v in tail) or all(v < mu for v in tail)) and sd > 0:
                rules.append("run")
            if sd > 0 and abs(last - mu) > 3 * sd:
                rules.append("sigma")
        n_warn = sum(1 for j in g["j"] if j == "warn")
        if n_warn >= 3:
            rules.append("warn")
        if not rules:
            continue
        limit_v = hi if side == "max" else (lo if side == "min" else None)
        score = (0 if eta is not None else 1, eta if eta is not None else 99, -len(rules))
        out.append({"form_id": fid, "item_key": key, "item": m["item_name"], "unit": m["unit"] or "", "form": m["form_name"],
                    "eq": m["eq_code"] or m["form_code"] or "", "factory": m["factory_name"] or "", "last": round(last, 3),
                    "last_at": last_t, "min": lo, "max": hi, "limit": limit_v, "side": side, "rules": rules,
                    "eta": round(eta, 1) if eta is not None else None, "slope": round(sl, 4) if sl else None,
                    "n_warn": n_warn, "spark": [round(v, 3) for v in vals[-20:]], "_s": score})
    out.sort(key=lambda x: x["_s"])
    for x in out:
        x.pop("_s")
    return out[:limit]


RULE_TH = {"near": "ใกล้เกณฑ์", "slope": "แนวโน้มวิ่งเข้าเกณฑ์", "run": "7 จุดฝั่งเดียว (SPC)", "sigma": "หลุด ±3σ (SPC)",
           "warn": "เข้าช่วงเตือนบ่อย"}


# ───────────────────────── 4) ตรงเวลา แยกพื้นที่ × กะ + รายผู้ตรวจ ─────────────────────────

def shift_rate(db, d_from: date, d_to: date, factory_id: int | None = None) -> dict:
    """% ตรวจตรงเวลา = ตรงเวลา / (รอบทั้งหมด − รอบที่ข้ามเพราะเครื่องหยุด/ยกเว้น) ต่อ พื้นที่ × กะ
    กะ = เวลาเริ่มรอบเทียบเวลากะในปฏิทิน (ไม่ได้ตั้ง → 06:00–17:59 กลางวัน)"""
    from .itemfreq import get_calendar
    from .sign_blocks import shift_of
    cal = get_calendar(db)
    fac, fp = _fac_sql(factory_id)
    a = ts(datetime.combine(d_from, time(0, 0)))
    b = ts(datetime.combine(d_to + timedelta(days=1), time(0, 0)))
    rows = db.execute(f"""
        SELECT r.status, r.due_at, COALESCE(ar.name, 'ไม่ระบุพื้นที่') AS area, fa.name AS factory_name,
               sb.inspector_id, u.name AS inspector, sb.duration_sec, sb.ng_count, sb.approval_status, sb.status AS sub_status
        FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN areas ar ON ar.id=COALESCE(e.area_id, f.area_id)
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN cs_submissions sb ON sb.id=r.submission_id LEFT JOIN users u ON u.id=sb.inspector_id
        WHERE r.due_at>=? AND r.due_at<? AND {S.scheduled_sql()} {fac}""", [a, b, *fp]).fetchall()
    now = ts(S.now_dt())
    cells: dict[tuple, dict] = {}
    tot = {"day": {"n": 0, "ok": 0, "late": 0, "miss": 0}, "night": {"n": 0, "ok": 0, "late": 0, "miss": 0}}
    insp: dict[int, dict] = {}
    for r in rows:
        if r["status"] == "skipped" or (r["status"] in ("pending", "in_progress") and r["due_at"] > now):
            continue
        t = parse_ts(r["due_at"])
        sh = shift_of(t.hour * 60 + t.minute, cal)
        area = r["area"]
        c = cells.setdefault((area, sh), {"n": 0, "ok": 0, "late": 0, "miss": 0})
        for d in (c, tot[sh]):
            d["n"] += 1
            if r["status"] == "done_on_time":
                d["ok"] += 1
            elif r["status"] == "done_late":
                d["late"] += 1
            elif r["status"] in ("missed", "overdue"):
                d["miss"] += 1
        if r["inspector_id"] and r["status"] in ROUND_DONE:
            p = insp.setdefault(r["inspector_id"], {"name": r["inspector"] or "–", "n": 0, "ok": 0, "late": 0, "ng": 0,
                                                    "returned": 0, "dur": [], "day": 0, "night": 0})
            p["n"] += 1
            p["ok" if r["status"] == "done_on_time" else "late"] += 1
            p["ng"] += r["ng_count"] or 0
            p["returned"] += 1 if r["approval_status"] == "rejected" or r["sub_status"] == "returned" else 0
            p[sh] += 1
            if r["duration_sec"]:
                p["dur"].append(r["duration_sec"])

    def pct(d):
        return round(100 * d["ok"] / d["n"], 1) if d["n"] else None
    areas = sorted({k[0] for k in cells})
    grid = [{"area": ar, "day": {**cells.get((ar, "day"), {"n": 0, "ok": 0, "late": 0, "miss": 0}),
                                 "rate": pct(cells.get((ar, "day"), {"n": 0, "ok": 0}))},
             "night": {**cells.get((ar, "night"), {"n": 0, "ok": 0, "late": 0, "miss": 0}),
                       "rate": pct(cells.get((ar, "night"), {"n": 0, "ok": 0}))}} for ar in areas]
    grid.sort(key=lambda g: min(x for x in (g["day"]["rate"], g["night"]["rate"], 101) if x is not None))
    people = []
    for uid, p in insp.items():
        people.append({"id": uid, "name": p["name"], "n": p["n"], "rate": round(100 * p["ok"] / p["n"], 1) if p["n"] else None,
                       "late": p["late"], "ng": p["ng"], "returned": p["returned"], "day": p["day"], "night": p["night"],
                       "avg_sec": round(statistics.median(p["dur"])) if p["dur"] else None,
                       "fast": sum(1 for x in p["dur"] if x < 30)})
    people.sort(key=lambda x: (-(x["n"]),))
    return {"grid": grid, "tot": {k: {**v, "rate": pct(v)} for k, v in tot.items()}, "people": people,
            "has_cal": bool(cal.get("shift_times"))}


def rate_status(v) -> str:
    if v is None:
        return "none"
    return "ok" if v >= 95 else ("warn" if v >= 80 else "crit")


# ───────────────────────── 5) สถานะเครื่องจักร ─────────────────────────

def machines(db, day: date, factory_id: int | None = None, days: int = 30) -> dict:
    """เครื่องที่มีแบบฟอร์มตรวจ: เดิน / หยุดซ่อม / สำรอง · รอบวันนี้และ N วัน: ข้ามเพราะเครื่องหยุด vs ขาดตรวจจริง"""
    from .downtime import CATEGORIES
    fac, fp = _fac_sql(factory_id, "e")
    eqs = db.execute(f"""SELECT e.id, e.code, e.name, COALESCE(e.run_status,'running') AS run_status, e.down_reason, e.down_since,
                                e.down_until, fa.name AS factory_name, ar.name AS area_name,
                                (SELECT d.category FROM cs_downtime d WHERE d.equipment_id=e.id AND d.end_at IS NULL
                                 ORDER BY d.start_at DESC LIMIT 1) AS category
                         FROM equipment e LEFT JOIN factories fa ON fa.id=e.factory_id LEFT JOIN areas ar ON ar.id=e.area_id
                         WHERE e.active=1 AND EXISTS (SELECT 1 FROM cs_forms f WHERE f.equipment_id=e.id AND f.active=1) {fac}
                         ORDER BY e.down_since""", fp).fetchall()
    now = S.now_dt()
    cnt = {"running": 0, "repair": 0, "standby": 0}
    down = []
    for e in eqs:
        if e["run_status"] != "down":
            cnt["running"] += 1
            continue
        cat = "standby" if e["category"] == "standby" else "repair"
        cnt[cat] += 1
        since = parse_ts(e["down_since"])
        until = parse_ts(e["down_until"])
        down.append({**dict(e), "cat": cat, "cat_th": CATEGORIES.get(e["category"] or "", "หยุด"),
                     "hours": round((now - since).total_seconds() / 3600, 1) if since else None,
                     "late": bool(until and until < now)})
    down.sort(key=lambda x: (x["cat"] != "repair", -(x["hours"] or 0)))

    def rounds(a: date, b: date) -> dict:
        f2, p2 = _fac_sql(factory_id)
        r = db.execute(f"""SELECT r.status, COUNT(*) FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id
                           WHERE r.due_at>=? AND r.due_at<? AND {S.scheduled_sql()} {f2} GROUP BY r.status""",
                       [ts(datetime.combine(a, time(0, 0))), ts(datetime.combine(b + timedelta(days=1), time(0, 0))), *p2]).fetchall()
        d = {x[0]: x[1] for x in r}
        return {"skipped": d.get("skipped", 0), "missed": d.get("missed", 0), "overdue": d.get("overdue", 0),
                "done": d.get("done_on_time", 0) + d.get("done_late", 0), "total": sum(d.values())}
    hours_down = db.execute(f"""SELECT COALESCE(SUM((julianday(COALESCE(d.end_at, ?)) - julianday(MAX(d.start_at, ?))) * 24), 0)
                                FROM cs_downtime d JOIN equipment e ON e.id=d.equipment_id
                                WHERE COALESCE(d.end_at, ?) > ? {fac}""",
                            [ts(now), ts(datetime.combine(day - timedelta(days=days - 1), time(0, 0))), ts(now),
                             ts(datetime.combine(day - timedelta(days=days - 1), time(0, 0))), *fp]).fetchone()[0]
    return {"count": cnt, "total": len(eqs), "down": down[:12], "n_down": len(down), "today": rounds(day, day),
            "period": rounds(day - timedelta(days=days - 1), day), "days": days, "down_hours": round(hours_down or 0, 1)}


# ───────────────────────── 9) เอกสารพร้อมรับตรวจ ─────────────────────────

def doc_ready(db, today: date | None = None, factory_id: int | None = None, n_months: int = 3) -> dict:
    """ใบบันทึกผลการตรวจรายเดือน: ช่องลงนามที่ถึงเวลาแล้ว (มีผลตรวจในช่วงนั้น) ลงครบหรือยัง + ผลตรวจที่ยังไม่อนุมัติ
    ครบ = ลงนามทุกช่องที่ถึงเวลา และอนุมัติผลตรวจครบ"""
    from . import signoffs as SO
    today = today or S.now_dt().date()
    m = today.replace(day=1)
    months = []
    for _ in range(n_months):
        months.append(m)
        m = (m - timedelta(days=1)).replace(day=1)
    out = []
    for mo in months:
        forms = []
        for form, al in SO.form_slots(db, mo, factory_id):
            need = [s for s in al if not s["na"] and s["opens"] <= today]
            if not need and not any(not s["na"] for s in al):
                continue                                   # ไม่มีผลตรวจทั้งเดือน
            signed = [s for s in need if s.get("rec")]
            pend = max((s.get("pending") or 0) for s in al) if al else 0
            missing = [s for s in need if not s.get("rec")]
            forms.append({"id": form["id"], "name": form["name"], "code": form.get("code") or form.get("eq_code") or "",
                          "factory": form.get("factory_name") or "", "need": len(need), "signed": len(signed), "pending": pend,
                          "missing": [s["label"] + (f" ({s['part']})" if s.get("part") and s["part"] not in ("ประจำเดือน", "ทั้งเดือน") else "")
                                      for s in missing][:3],
                          "status": "ok" if len(signed) == len(need) and not pend else ("warn" if signed else "crit")})
        n = len(forms)
        ok = sum(1 for f in forms if f["status"] == "ok")
        forms.sort(key=lambda f: ({"crit": 0, "warn": 1, "ok": 2}[f["status"]], -(f["need"] - f["signed"]), -f["pending"]))
        out.append({"month": mo, "n": n, "ok": ok, "partial": sum(1 for f in forms if f["status"] == "warn"),
                    "none": sum(1 for f in forms if f["status"] == "crit"), "pct": round(100 * ok / n, 1) if n else None,
                    "pending": sum(f["pending"] for f in forms), "missing_slots": sum(f["need"] - f["signed"] for f in forms),
                    "forms": [f for f in forms if f["status"] != "ok"][:8], "current": mo == today.replace(day=1)})
    return {"months": out}


# ───────────────────────── v0.94 % คุณภาพเครื่องจักร (อยู่ในเกณฑ์มาตรฐาน) ─────────────────────────

def q_status(pct) -> str:
    """≥ 98% ดี · ≥ 95% เฝ้าระวัง · ต่ำกว่า = ต้องแก้ไข"""
    if pct is None:
        return "none"
    return "ok" if pct >= 98 else ("warn" if pct >= 95 else "ng")


def _cpk(vals: list[float], lo, hi):
    if lo is None or hi is None or hi <= lo or len(vals) < 5:
        return None
    sd = statistics.stdev(vals)
    if sd <= 0:
        return None
    mu = statistics.mean(vals)
    return round(min(hi - mu, mu - lo) / (3 * sd), 2)


def quality(db, d_from: date, d_to: date, factory_id: int | None = None, scope: str = "num", equipment_id: int | None = None,
            form_id: int | None = None) -> dict:
    """% ผลตรวจที่อยู่ในเกณฑ์มาตรฐาน แยกรายเครื่อง (แบบฟอร์ม) และรายหัวข้อ
    scope = "num"  เฉพาะหัวข้อตัวเลขที่กำหนด Min/Max (หัวข้อควบคุมค่ามาตรฐาน)
            "all"  รวมหัวข้อ OK/NG และตัวเลือกด้วย
    ในเกณฑ์ = judgement ok หรือ warn (ยังไม่หลุด Min/Max) · นอกเกณฑ์ = ng · na/ไม่ได้ตอบ ไม่นับ"""
    fac, fp = _fac_sql(factory_id)
    if equipment_id:                                    # v0.95 หน้าประวัติเครื่อง
        fac += " AND f.equipment_id=?"
        fp = [*fp, equipment_id]
    if form_id:                                         # v0.96 หน้าแนวโน้ม: เฉพาะเครื่องที่เลือก
        fac += " AND f.id=?"
        fp = [*fp, form_id]
    std = "(fi.min_value IS NOT NULL OR fi.max_value IS NOT NULL)"
    if scope == "all":
        std = f"({std} OR fi.item_type IN ('ok_ng','choice'))"
    rows = db.execute(f"""
        SELECT s.form_id, a.item_key, a.value_num, a.judgement, fi.name AS item_name, fi.unit, fi.item_type,
               fi.min_value, fi.max_value, fi.critical, f.name AS form_name, e.code AS eq_code, e.name AS eq_name,
               fa.name AS factory_name, ar.name AS area_name, f.equipment_id
        FROM cs_answers a
        JOIN cs_submissions s ON s.id=a.submission_id
        JOIN cs_forms f ON f.id=s.form_id
        JOIN cs_form_items fi ON fi.id=a.item_id
        LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN areas ar ON ar.id=f.area_id
        WHERE s.status<>'superseded' AND s.finished_at>=? AND s.finished_at<? AND f.active=1 AND f.is_template=0
          AND a.judgement IN ('ok','warn','ng') AND {std} {fac}
        ORDER BY s.form_id, s.finished_at""",
                      [ts(datetime.combine(d_from, time(0, 0))), ts(datetime.combine(d_to + timedelta(days=1), time(0, 0))), *fp]).fetchall()
    mach: dict[int, dict] = {}
    for r in rows:
        m = mach.setdefault(r["form_id"], {"form_id": r["form_id"], "form_name": r["form_name"], "eq_code": r["eq_code"],
                                           "equipment_id": r["equipment_id"],
                                           "eq_name": r["eq_name"], "factory_name": r["factory_name"], "area_name": r["area_name"],
                                           "items": {}})
        it = m["items"].setdefault(r["item_key"], {"item_key": r["item_key"], "ok": 0, "warn": 0, "ng": 0, "vals": []})
        it.update({x: r[x] for x in ("item_name", "unit", "item_type", "min_value", "max_value", "critical")})
        j = r["judgement"]
        if r["value_num"] is not None and (r["min_value"] is not None or r["max_value"] is not None):
            v = float(r["value_num"])                    # ตัวเลข: ตัดสินจากค่าจริงเทียบ Min/Max ของเวอร์ชันที่ใช้ตรวจ
            out_ = (r["min_value"] is not None and v < r["min_value"]) or (r["max_value"] is not None and v > r["max_value"])
            j = "ng" if out_ else ("warn" if j in ("warn", "ng") else "ok")
        it[j] += 1
        if r["value_num"] is not None:
            it["vals"].append(float(r["value_num"]))

    def pct(a, n):
        return round(100.0 * a / n, 1) if n else None

    out, tot = [], {"ok": 0, "warn": 0, "ng": 0}
    for m in mach.values():
        items = []
        for it in m["items"].values():
            n = it["ok"] + it["warn"] + it["ng"]
            v = it.pop("vals")
            it.update({"n": n, "pct": pct(it["ok"] + it["warn"], n), "warn_pct": pct(it["warn"], n), "ng_pct": pct(it["ng"], n),
                       "mean": round(statistics.mean(v), 3) if v else None, "vmin": min(v) if v else None,
                       "vmax": max(v) if v else None, "cpk": _cpk(v, it["min_value"], it["max_value"])})
            it["status"] = q_status(it["pct"])
            items.append(it)
        items.sort(key=lambda x: (x["pct"] if x["pct"] is not None else 101, -x["ng"], x["item_name"] or ""))
        ok, warn, ng = (sum(i[k] for i in items) for k in ("ok", "warn", "ng"))
        for k, v in (("ok", ok), ("warn", warn), ("ng", ng)):
            tot[k] += v
        n = ok + warn + ng
        cpks = [i["cpk"] for i in items if i["cpk"] is not None]
        m.update({"items": items, "n": n, "n_items": len(items), "ok": ok, "warn": warn, "ng": ng,
                  "pct": pct(ok + warn, n), "warn_pct": pct(warn, n), "ng_pct": pct(ng, n),
                  "items_ok": sum(1 for i in items if i["ng"] == 0), "cpk_min": min(cpks) if cpks else None,
                  "worst": items[0] if items and items[0]["ng"] else None})
        m["status"] = q_status(m["pct"])
        out.append(m)
    out.sort(key=lambda x: (x["pct"] if x["pct"] is not None else 101, -x["ng"], x["eq_code"] or x["form_name"] or ""))
    n = tot["ok"] + tot["warn"] + tot["ng"]
    return {"machines": out, "n": n, "pct": pct(tot["ok"] + tot["warn"], n), "ng": tot["ng"], "warn": tot["warn"],
            "n_machines": len(out), "full": sum(1 for m in out if m["ng"] == 0),
            "below": sum(1 for m in out if m["pct"] is not None and m["pct"] < 95),
            "low_cpk": sum(1 for m in out if m["cpk_min"] is not None and m["cpk_min"] < 1.33),
            "scope": scope, "d_from": d_from, "d_to": d_to, "status": q_status(pct(tot["ok"] + tot["warn"], n))}


def quality_xlsx(Q: dict) -> bytes:
    """Excel: แผ่น 1 สรุปรายเครื่อง · แผ่น 2 รายหัวข้อ"""
    from io import BytesIO
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "รายเครื่อง"
    ws.append([f"% คุณภาพเครื่องจักร (อยู่ในเกณฑ์มาตรฐาน) {Q['d_from']:%d/%m/%Y} – {Q['d_to']:%d/%m/%Y}"])
    ws.append([f"รวม {Q['n']} ค่า · ในเกณฑ์ {Q['pct'] if Q['pct'] is not None else '-'}% · นอกเกณฑ์ {Q['ng']}"])
    ws.append([])
    head = ["รหัสเครื่อง", "แบบฟอร์ม", "โรงงาน", "พื้นที่", "หัวข้อ", "หัวข้อผ่านครบ", "ผลตรวจ", "ในเกณฑ์", "เตือน", "นอกเกณฑ์",
            "% ในเกณฑ์", "Cpk ต่ำสุด", "หัวข้อที่หลุดมากสุด"]
    ws.append(head)
    fill = {"ok": "C6EFCE", "warn": "FFEB9C", "ng": "FFC7CE"}
    for m in Q["machines"]:
        ws.append([m["eq_code"] or "", m["form_name"], m["factory_name"] or "", m["area_name"] or "", m["n_items"], m["items_ok"],
                   m["n"], m["ok"] + m["warn"], m["warn"], m["ng"], m["pct"], m["cpk_min"], (m["worst"] or {}).get("item_name", "")])
        if m["status"] in fill:
            ws.cell(ws.max_row, 11).fill = PatternFill("solid", fgColor=fill[m["status"]])
    ws2 = wb.create_sheet("รายหัวข้อ")
    ws2.append(["รหัสเครื่อง", "แบบฟอร์ม", "หัวข้อ", "หน่วย", "Min", "Max", "ผลตรวจ", "ในเกณฑ์", "เตือน", "นอกเกณฑ์", "% ในเกณฑ์",
                "เฉลี่ย", "ต่ำสุด", "สูงสุด", "Cpk"])
    for m in Q["machines"]:
        for i in m["items"]:
            ws2.append([m["eq_code"] or "", m["form_name"], i["item_name"], i["unit"] or "", i["min_value"], i["max_value"], i["n"],
                        i["ok"] + i["warn"], i["warn"], i["ng"], i["pct"], i["mean"], i["vmin"], i["vmax"], i["cpk"]])
            if i["status"] in fill:
                ws2.cell(ws2.max_row, 11).fill = PatternFill("solid", fgColor=fill[i["status"]])
    for w, hr in ((ws, 4), (ws2, 1)):
        for c in w[hr]:
            c.font = Font(bold=True)
        for col in w.columns:
            w.column_dimensions[col[0].column_letter].width = 14
    ws["A1"].font = Font(bold=True, size=13)
    bio = BytesIO()
    wb.save(bio)
    return bio.getvalue()
