"""ecs/srcissues.py — v0.83 รวมปัญหาค่าจาก SCADA ทุกแหล่งข้อมูลในหน้าเดียว (สำหรับผู้ดูแลระบบ)

ประเภท: ดึงข้อมูลไม่สำเร็จ · ช่องเวลาที่ขาด · ค่านอกช่วงที่เป็นไปได้ · Tag ไม่ส่งค่า · ค่ารอยืนยัน · แบบฟอร์มที่จับคู่แล้วแต่ยังไม่ลงค่าตามเวลา
"""
from __future__ import annotations

from datetime import datetime, timedelta

from . import connectors as CN
from . import services as S
from . import srcmap as SM

STALE_HOURS = 3


def collect(db, now: datetime | None = None) -> dict:
    now = now or S.now_dt()
    out = []
    tot = {"failed": 0, "missing": 0, "invalid": 0, "stale": 0, "pending": 0, "unslotted": 0}
    for src in CN.list_sources(db):
        if not src["active"]:
            continue
        sid = src["id"]
        it = {"src": src, "failed": None, "missing": [], "n_missing": 0, "n_invalid": 0, "stale": [], "pending": 0, "unslotted": []}
        if (src.get("last_status") or "ok") not in ("ok", ""):
            it["failed"] = src.get("last_message") or "ดึงข้อมูลไม่สำเร็จ"
            tot["failed"] += 1
        try:
            hl = SM.health(db, sid, now)
            it["n_missing"], it["n_invalid"] = hl["count"]["missing"], hl["count"].get("invalid", 0)
            it["missing"] = hl["missing"][:12]
        except Exception:                               # noqa: BLE001 — แหล่งเดียวล้ม ไม่ให้ทั้งหน้าล้ม
            pass
        lim = S.ts(now - timedelta(hours=STALE_HOURS))
        it["stale"] = [dict(r) for r in db.execute(
            """SELECT t.tag, t.last_seen, t.last_value, f.name AS form_name, e.code AS eq_code FROM cs_source_tags t
               LEFT JOIN cs_forms f ON f.id=t.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
               WHERE t.source_id=? AND t.form_id IS NOT NULL AND t.item_key<>'' AND (t.last_seen IS NULL OR t.last_seen<?)
               ORDER BY t.last_seen""", (sid, lim))]
        it["pending"] = db.execute("""SELECT COUNT(*) FROM cs_submissions WHERE source='auto' AND client_uuid LIKE ?
                                      AND approval_status='pending' AND status='submitted'""", (f"src{sid}:%",)).fetchone()[0]
        try:
            it["unslotted"] = [c for c in SM.form_cfgs(db, sid) if not c["slotted"]]
        except Exception:                               # noqa: BLE001
            pass
        tot["missing"] += it["n_missing"]
        tot["invalid"] += it["n_invalid"]
        tot["stale"] += len(it["stale"])
        tot["pending"] += it["pending"]
        tot["unslotted"] += len(it["unslotted"])
        it["ok"] = not (it["failed"] or it["n_missing"] or it["n_invalid"] or it["stale"] or it["pending"] or it["unslotted"])
        out.append(it)
    out.sort(key=lambda x: (x["ok"], x["src"]["name"]))
    try:                                                  # v0.84.1 ค่าจาก SCADA ที่ยังค้างในช่วงเครื่องหยุด
        n_down = SM.count_down(db)
    except Exception:                                     # noqa: BLE001
        n_down = 0
    return {"sources": out, "total": tot, "n_down": n_down,
            "n_problem": sum(1 for x in out if not x["ok"]) + (1 if n_down else 0)}


def has_issue(db, src: dict, now: datetime | None = None) -> bool:
    """ตรวจแบบเร็วสำหรับหน้ารายการ: ดึงไม่สำเร็จ / ช่องขาดหรือนอกช่วง (จาก health ที่คำนวณไว้แล้ว) / Tag ไม่ส่งค่า / รอยืนยัน"""
    now = now or S.now_dt()
    sid = src["id"]
    if (src.get("last_status") or "ok") not in ("ok", ""):
        return True
    hl = src.get("health")
    if hl and (hl["count"]["missing"] or hl["count"].get("invalid", 0)):
        return True
    if db.execute("""SELECT 1 FROM cs_source_tags WHERE source_id=? AND form_id IS NOT NULL AND item_key<>''
                     AND (last_seen IS NULL OR last_seen<?) LIMIT 1""", (sid, S.ts(now - timedelta(hours=STALE_HOURS)))).fetchone():
        return True
    return db.execute("""SELECT 1 FROM cs_submissions WHERE source='auto' AND client_uuid LIKE ? AND approval_status='pending'
                         AND status='submitted' LIMIT 1""", (f"src{sid}:%",)).fetchone() is not None
