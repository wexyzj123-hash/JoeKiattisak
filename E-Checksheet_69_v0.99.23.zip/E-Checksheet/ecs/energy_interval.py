"""ecs/energy_interval.py — v0.87 ค่าพลังงานรายช่วงเวลา (ทุก 15 นาที / รายชั่วโมง) จาก SCADA

แหล่งข้อมูลที่ตั้ง "ชนิดค่า = ค่าใช้ต่อช่วงเวลา" (value_kind = 'interval'):
- เก็บค่าทุกแถวที่ได้ (kWh / m³ ที่ใช้ในช่วงนั้น) ลง en_intervals ระดับนาที → Dashboard รายช่วงเวลา (Sum ตาม Project/Section/Line)
- สร้างค่าอ่านรายวัน (en_readings) ให้เอง = ผลรวมสะสมถึงเวลาอ่าน (เช่น 08:00) → รายงานรายวัน/รายเดือน/ต้นทุนเดิมใช้ได้ทันที
- ค่าติดลบ / ค่าเกินเพดานต่อช่วง (ค่าเสียจาก register เช่น 2,157,641,728) ไม่เก็บ
"""
from __future__ import annotations

import io
import logging
from datetime import date, datetime, time, timedelta

from . import services as S
from .services import parse_ts, ts

log = logging.getLogger(__name__)

DDL = """
CREATE TABLE IF NOT EXISTS en_intervals (
    meter_id  INTEGER NOT NULL,
    ts        TEXT NOT NULL,
    value     REAL NOT NULL,
    PRIMARY KEY (meter_id, ts)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS ix_en_int_ts ON en_intervals(ts);
CREATE TABLE IF NOT EXISTS en_interval_base (
    meter_id  INTEGER PRIMARY KEY,
    base      REAL NOT NULL DEFAULT 0
);
"""
VALUE_KINDS = {"reading": "เลขหน้าปัดสะสม (ค่าอ่านมิเตอร์)", "interval": "ค่าใช้ต่อช่วงเวลา (kWh / m³ ทุก 15 นาที หรือรายชั่วโมง)"}
CAP_PER_SLOT = 1_000_000.0                  # ค่าต่อช่วงเกินนี้ = ค่าเสีย (เช่น 2,157,641,728) ไม่เก็บ
KEEP_DAYS = 400


def ensure(db) -> None:
    if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='en_intervals'").fetchone():
        db.executescript(DDL)
    have = {r[1] for r in db.execute("PRAGMA table_info(en_sources)")}
    if have and "value_kind" not in have:
        db.execute("ALTER TABLE en_sources ADD COLUMN value_kind TEXT NOT NULL DEFAULT 'reading'")


def is_interval(src: dict | None) -> bool:
    return bool(src) and (src.get("value_kind") or "reading") == "interval"


def _tagmap(db, sid: int) -> tuple[dict[str, list[int]], dict[str, float]]:
    tagmap: dict[str, list[int]] = {}
    for r in db.execute("SELECT id, scada_tag FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>'' AND active=1", (sid,)):
        tagmap.setdefault(r[1].strip(), []).append(r[0])
    scale = {r[0].strip(): float(r[1] or 1) for r in db.execute("SELECT tag, scale FROM en_source_tags WHERE source_id=?", (sid,))}
    return tagmap, scale


def store(db, src: dict, rows) -> dict:
    """เก็บค่าต่อช่วงของ Tag ที่ผูกมิเตอร์แล้ว → {stored, bad, meters: {mid: วันแรกที่มีค่าใหม่}}"""
    ensure(db)
    tagmap, scale = _tagmap(db, src["id"])
    if not tagmap:
        return {"stored": 0, "bad": 0, "meters": {}}
    agg: dict[tuple[int, str], float] = {}
    bad = 0
    first: dict[int, date] = {}
    for tag, dt, val in rows:
        t = str(tag).strip()
        mids = tagmap.get(t)
        if not mids or val is None or dt is None:
            continue
        try:
            v = float(val) * scale.get(t, 1.0)
        except (TypeError, ValueError):
            bad += 1
            continue
        if v < 0 or v > CAP_PER_SLOT or v != v:
            bad += 1
            continue
        k = dt.replace(second=0, microsecond=0)
        for mid in mids:
            agg[(mid, ts(k))] = v                          # แถวเวลาเดียวกันซ้ำ (อ่านทับ) → ใช้ค่าล่าสุด
            if mid not in first or k.date() < first[mid]:
                first[mid] = k.date()
    for (mid, stamp), v in agg.items():
        db.execute("""INSERT INTO en_intervals(meter_id, ts, value) VALUES (?,?,?)
                      ON CONFLICT(meter_id, ts) DO UPDATE SET value=excluded.value""", (mid, stamp, v))
    return {"stored": len(agg), "bad": bad, "meters": first}


def _read_at(db) -> tuple[int, int]:
    """เวลาตัดยอดของค่าอ่านรายวันที่สร้างจากค่าต่อช่วง: นับตามวันที่ใช้จริง → 00:00 (การใช้วัน D = 00:00–24:00 ตรงวันปฏิทิน)
    · แบบเดิม → เวลาอ่านค่าที่ตั้งไว้ (เช่น 08:00)"""
    from . import energy as EN
    cfg = EN.settings(db)
    if int(cfg.get("usage_day", 1)):
        return 0, 0
    return int(cfg["scada_hh"]), int(cfg["scada_mm"])


def rebuild_all(db, now: datetime | None = None) -> int:
    """สร้างค่าอ่านรายวันจากค่าต่อช่วงใหม่ทั้งหมด (หลังเปลี่ยนวิธีนับวัน) — เฉพาะมิเตอร์ที่ค่าอ่านทั้งหมดมาจาก SCADA/ค่าต่อช่วง"""
    ensure(db)
    n = 0
    for mid, d0 in db.execute("SELECT meter_id, MIN(ts) FROM en_intervals GROUP BY meter_id").fetchall():
        if db.execute("SELECT 1 FROM en_readings WHERE meter_id=? AND src NOT IN ('scada') LIMIT 1", (mid,)).fetchone():
            continue
        db.execute("DELETE FROM en_readings WHERE meter_id=? AND src='scada'", (mid,))
        n += rebuild_readings(db, [mid], date.fromisoformat(d0[:10]) - timedelta(days=1), now, _cut=False)
    return n


def ensure_cut(db, now: datetime | None = None) -> int:
    """v0.89 ค่าอ่านรายวันจากค่าต่อช่วงต้องตัดยอดที่เวลาเดียวกับการตั้งค่าปัจจุบัน — ถ้าเคยสร้างไว้ด้วยเวลาอื่น (เช่น ติดตั้งก่อน v0.89 = 08:00)
    สร้างใหม่ครั้งเดียว แล้วจำเวลาที่ใช้ไว้ใน cs_meta (สำเร็จเท่านั้นจึงจำ)"""
    ensure(db)
    hh, mm = _read_at(db)
    key = f"{hh:02d}:{mm:02d}"
    row = db.execute("SELECT value FROM cs_meta WHERE key='en_interval_cut'").fetchone()
    if row and row[0] == key:
        return 0
    n = rebuild_all(db, now) if db.execute("SELECT 1 FROM en_intervals LIMIT 1").fetchone() else 0
    db.execute("INSERT INTO cs_meta(key, value) VALUES('en_interval_cut', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key,))
    return n


def rebuild_readings(db, meter_ids, d_from: date, now: datetime | None = None, _cut: bool = True) -> int:
    """ค่าอ่านรายวันจากผลรวมสะสมของค่าต่อช่วง: ค่าอ่านวัน D = ฐาน + Σ ค่าที่เวลา ≤ D เวลาอ่าน
    ลงเฉพาะวันที่ข้อมูลมาถึงเวลาอ่านแล้ว · ค่าที่ช่างแก้ (fix/swap) และวันที่ยกเลิกไว้ไม่แตะ"""
    ensure(db)
    if _cut:
        ensure_cut(db, now)                                  # เวลาตัดยอดเปลี่ยน → สร้างใหม่ทั้งหมดก่อน (ครั้งเดียว)
    now = now or S.now_dt()
    hh, mm = _read_at(db)
    n = 0
    stamp = ts(now)
    for mid in sorted(set(meter_ids or [])):
        last = db.execute("SELECT MAX(ts) FROM en_intervals WHERE meter_id=?", (mid,)).fetchone()[0]
        if not last:
            continue
        last_dt = parse_ts(last)
        b = db.execute("SELECT base FROM en_interval_base WHERE meter_id=?", (mid,)).fetchone()
        base = float(b[0]) if b else 0.0
        d = d_from
        cut = datetime.combine(d, time(hh, mm))
        run = base + (db.execute("SELECT COALESCE(SUM(value),0) FROM en_intervals WHERE meter_id=? AND ts<=?",
                                 (mid, ts(cut))).fetchone()[0] or 0.0)
        prev_cut = cut
        while d <= now.date():
            cut = datetime.combine(d, time(hh, mm))
            if cut > last_dt or cut > now:
                break
            if cut != prev_cut:
                run += db.execute("SELECT COALESCE(SUM(value),0) FROM en_intervals WHERE meter_id=? AND ts>? AND ts<=?",
                                  (mid, ts(prev_cut), ts(cut))).fetchone()[0] or 0.0
                prev_cut = cut
            day = d.isoformat()
            d += timedelta(days=1)
            if not db.execute("SELECT 1 FROM en_intervals WHERE meter_id=? AND ts<=? LIMIT 1", (mid, ts(cut))).fetchone():
                continue
            if db.execute("SELECT 1 FROM en_skips WHERE meter_id=? AND day=? AND reason='scada_void'", (mid, day)).fetchone():
                continue
            old = db.execute("SELECT value, src FROM en_readings WHERE meter_id=? AND day=?", (mid, day)).fetchone()
            if old and old[1] in ("fix", "swap"):
                continue
            val = round(run, 4)
            if old and old[1] == "scada" and abs(old[0] - val) < 1e-6:
                continue
            db.execute("""INSERT INTO en_readings(meter_id, day, value, src, updated_at, read_at) VALUES (?,?,?,?,?,?)
                          ON CONFLICT(meter_id, day) DO UPDATE SET value=excluded.value, src=excluded.src, u_override=NULL,
                          updated_at=excluded.updated_at, read_at=excluded.read_at""", (mid, day, val, "scada", stamp, ts(cut)))
            db.execute("DELETE FROM en_skips WHERE meter_id=? AND day=?", (mid, day))
            n += 1
    return n


def ingest(db, src: dict, rows, now: datetime | None = None) -> int:
    """เก็บค่าต่อช่วง แล้วสร้างค่าอ่านรายวันของมิเตอร์ที่มีค่าใหม่ → จำนวนค่าอ่านที่ลง/เปลี่ยน"""
    r = store(db, src, rows)
    if not r["meters"]:
        return 0
    d0 = min(r["meters"].values()) - timedelta(days=1)
    return rebuild_readings(db, list(r["meters"]), d0, now)


def clear(db, meter_ids, d_from: date, d_to: date) -> int:
    ensure(db)
    ids = list(meter_ids or [])
    n = 0
    for i in range(0, len(ids), 500):
        ch = ids[i:i + 500]
        n += db.execute(f"DELETE FROM en_intervals WHERE ts>=? AND ts<? AND meter_id IN ({','.join('?' * len(ch))})",
                        [ts(datetime.combine(d_from, time(0, 0))), ts(datetime.combine(d_to + timedelta(days=1), time(0, 0))), *ch]).rowcount
    return n


def prune(db, now: datetime | None = None, keep_days: int = KEEP_DAYS) -> int:
    """ลบค่าต่อช่วงที่เก่ากว่า keep_days — เก็บผลรวมไว้เป็นฐาน (ค่าอ่านสะสมไม่กระโดด)"""
    ensure(db)
    now = now or S.now_dt()
    lim = ts(now - timedelta(days=keep_days))
    rows = db.execute("SELECT meter_id, SUM(value) FROM en_intervals WHERE ts<? GROUP BY meter_id", (lim,)).fetchall()
    for mid, s in rows:
        db.execute("""INSERT INTO en_interval_base(meter_id, base) VALUES (?,?)
                      ON CONFLICT(meter_id) DO UPDATE SET base=base+excluded.base""", (mid, s or 0.0))
    return db.execute("DELETE FROM en_intervals WHERE ts<?", (lim,)).rowcount if rows else 0


# ───────────────────────── v0.88 นำเข้าไฟล์ค่าต่อช่วง (ทุก 15 นาที / รายชั่วโมง) ─────────────────────────
IMPORT_DDL = """
CREATE TABLE IF NOT EXISTS en_interval_imports (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at  TEXT NOT NULL,
    user_id     INTEGER,
    filename    TEXT NOT NULL DEFAULT '',
    meters      INTEGER NOT NULL DEFAULT 0,
    rows        INTEGER NOT NULL DEFAULT 0,
    d_from      TEXT,
    d_to        TEXT,
    rebuilt     TEXT NOT NULL DEFAULT '',
    undone_at   TEXT
);
CREATE TABLE IF NOT EXISTS en_interval_import_rows (
    import_id   INTEGER NOT NULL,
    meter_id    INTEGER NOT NULL,
    ts          TEXT NOT NULL,
    old_value   REAL,
    PRIMARY KEY (import_id, meter_id, ts)
) WITHOUT ROWID;
"""
_TS_KEYS = ("timestamp", "ts", "datetime", "date time", "วันเวลา", "เวลา", "time stamp", "วันที่เวลา")
_KEY_KEYS = ("meter", "มิเตอร์", "tag", "pointname", "point", "code", "รหัส", "no", "no.", "meter_id")
_VAL_KEYS = ("value", "ค่า", "kwh", "usage", "ใช้", "หน่วย", "m3")


def _cell_dt(v, v2=None):
    from .services import ValidationError  # noqa: F401
    if isinstance(v, datetime):
        dt = v
    elif isinstance(v, date):
        dt = datetime.combine(v, time(0, 0))
    else:
        dt = parse_ts(str(v or "").strip().replace("T", " ").replace("/", "-")) if v not in (None, "") else None
        if dt is None and v not in (None, ""):
            for f in ("%d-%m-%Y %H:%M", "%d-%m-%Y %H:%M:%S", "%d-%m-%y %H:%M"):
                try:
                    dt = datetime.strptime(str(v).strip().replace("/", "-"), f)
                    break
                except ValueError:
                    continue
    if dt is not None and v2 not in (None, ""):
        if isinstance(v2, time):
            dt = datetime.combine(dt.date(), v2)
        elif isinstance(v2, datetime):
            dt = datetime.combine(dt.date(), v2.time())
        else:
            try:
                hh, mm = str(v2).strip()[:5].split(":")
                dt = datetime.combine(dt.date(), time(int(hh), int(mm)))
            except ValueError:
                pass
    if dt is not None and dt.year > 2400:
        dt = dt.replace(year=dt.year - 543)
    return dt


def _num(v):
    if v is None or v == "":
        return None
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        return None


def parse_file(raw: bytes, filename: str) -> dict:
    """อ่าน Excel / CSV ค่าต่อช่วง 2 แบบ:
    แนวยาว: คอลัมน์ มิเตอร์ (No./ชื่อ/Tag/ID) · เวลา (หรือ วันที่ + เวลา) · ค่า
    แนวกว้าง: คอลัมน์แรก = เวลา · คอลัมน์ถัดไป = 1 มิเตอร์ต่อคอลัมน์ (หัวคอลัมน์ = No./ชื่อ/Tag)"""
    from .services import ValidationError
    name = (filename or "").lower()
    rows: list[list] = []
    if name.endswith((".xlsx", ".xlsm")):
        from openpyxl import load_workbook
        try:
            wb = load_workbook(io.BytesIO(raw), data_only=True, read_only=True)
        except Exception:                                  # noqa: BLE001
            raise ValidationError(["อ่านไฟล์ Excel ไม่ได้"]) from None
        ws = wb.worksheets[0]
        rows = [list(r) for r in ws.iter_rows(values_only=True)]
    elif name.endswith((".csv", ".txt")):
        import csv
        text = None
        for enc in ("utf-8-sig", "cp874", "latin-1"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        dialect = csv.Sniffer().sniff(text[:4000], delimiters=",;\t") if text and text.strip() else csv.excel
        rows = [list(r) for r in csv.reader(io.StringIO(text or ""), dialect)]
    else:
        raise ValidationError(["รองรับไฟล์ .xlsx หรือ .csv"])
    rows = [r for r in rows if r and any(c not in (None, "") for c in r)]
    if len(rows) < 2:
        raise ValidationError(["ไฟล์ว่าง / ไม่มีข้อมูล"])
    head = [str(c or "").strip() for c in rows[0]]
    low = [h.lower() for h in head]

    def find(keys):
        for i, h in enumerate(low):
            if h in keys or any(h.startswith(k) for k in keys if len(k) > 3):
                return i
        return None
    i_key, i_ts, i_val = find(_KEY_KEYS), find(_TS_KEYS), find(_VAL_KEYS)
    i_date = next((i for i, h in enumerate(low) if h in ("date", "วันที่", "day")), None)
    i_time = next((i for i, h in enumerate(low) if h in ("time", "เวลา", "hh:mm")), None)
    out, bad = [], 0
    if i_key is not None and i_val is not None and (i_ts is not None or i_date is not None):
        fmt = "long"
        for r in rows[1:]:
            r = r + [None] * (len(head) - len(r))
            if i_date is not None:
                dt = _cell_dt(r[i_date], r[i_time] if i_time is not None and i_time != i_date else None)
            else:
                dt = _cell_dt(r[i_ts])
            v = _num(r[i_val])
            k = str(r[i_key] or "").strip()
            if dt is None or v is None or not k:
                bad += 1
                continue
            out.append((k, dt, v))
    else:
        fmt = "wide"
        i0 = 0
        cols = [(j, head[j]) for j in range(1, len(head)) if head[j]]
        if i_date is not None and i_time is not None and i_date != i_time:
            i0 = None
            cols = [(j, head[j]) for j in range(len(head)) if head[j] and j not in (i_date, i_time)]
        if not cols:
            raise ValidationError(["ไม่พบคอลัมน์มิเตอร์ — ใช้ไฟล์ตัวอย่างจากระบบ"])
        for r in rows[1:]:
            r = r + [None] * (len(head) - len(r))
            dt = _cell_dt(r[i0]) if i0 is not None else _cell_dt(r[i_date], r[i_time])
            if dt is None:
                bad += 1
                continue
            for j, h in cols:
                v = _num(r[j])
                if v is not None:
                    out.append((h, dt, v))
    if not out:
        raise ValidationError(["ไม่พบค่าที่อ่านได้ — ตรวจหัวคอลัมน์ (มิเตอร์ · เวลา · ค่า) หรือใช้ไฟล์ตัวอย่าง"])
    return {"rows": out, "format": fmt, "bad": bad}


def match_meters(db, keys, factory_id=None, kind=None) -> dict[str, int]:
    """จับคู่ชื่อในไฟล์ → มิเตอร์: #ID · Tag SCADA · No. · ชื่อ · No.+ชื่อ (ไม่สนตัวพิมพ์/ช่องว่าง)"""
    from . import energy as EN
    norm = lambda x: " ".join(str(x or "").lower().split())                     # noqa: E731
    ms = EN.meters(db, factory_id, kind, True)
    idx: dict[str, int] = {}
    for m in ms:
        for k in (m.get("scada_tag"), m.get("code"), m.get("name"), f"{m.get('code') or ''} {m.get('name') or ''}", EN.label(m)):
            if k and norm(k) not in idx:
                idx[norm(k)] = m["id"]
    ids = {m["id"] for m in ms}
    out = {}
    for k in keys:
        s = str(k).strip()
        if s.startswith("#") and s[1:].split()[0].isdigit() and int(s[1:].split()[0]) in ids:
            out[k] = int(s[1:].split()[0])
        elif norm(s) in idx:
            out[k] = idx[norm(s)]
    return out


def preview(db, parsed: dict, factory_id=None, kind=None, shift_min: int = 0) -> dict:
    from . import energy as EN
    rows = parsed["rows"]
    keys = sorted({k for k, _, _ in rows})
    mp = match_meters(db, keys, factory_id, kind)
    per: dict[int, dict] = {}
    unmatched: dict[str, int] = {}
    for k, dt, v in rows:
        mid = mp.get(k)
        if not mid:
            unmatched[k] = unmatched.get(k, 0) + 1
            continue
        dt = dt + timedelta(minutes=shift_min)
        p = per.setdefault(mid, {"n": 0, "sum": 0.0, "a": dt, "b": dt, "bad": 0, "key": k})
        if v < 0 or v > CAP_PER_SLOT:
            p["bad"] += 1
            continue
        p["n"] += 1
        p["sum"] += v
        p["a"], p["b"] = min(p["a"], dt), max(p["b"], dt)
    out = []
    for mid, p in per.items():
        m = EN.meter(db, mid)
        have = db.execute("SELECT COUNT(*) FROM en_intervals WHERE meter_id=? AND ts BETWEEN ? AND ?", (mid, ts(p["a"]), ts(p["b"]))).fetchone()[0]
        man = db.execute("SELECT COUNT(*) FROM en_readings WHERE meter_id=? AND src NOT IN ('scada') AND day BETWEEN ? AND ?",
                         (mid, p["a"].date().isoformat(), p["b"].date().isoformat())).fetchone()[0]
        out.append({"id": mid, "label": EN.label(m), "key": p["key"], "n": p["n"], "sum": round(p["sum"], 3), "bad": p["bad"],
                    "from": ts(p["a"])[:16], "to": ts(p["b"])[:16], "have": have, "manual": man, "unit": m["unit"],
                    "path": " › ".join(x for x in (m.get("factory_name"), m.get("project_name"), m.get("grp"), m.get("line")) if x)})
    out.sort(key=lambda x: x["label"])
    return {"meters": out, "unmatched": sorted(unmatched.items(), key=lambda x: -x[1])[:50], "n_unmatched": sum(unmatched.values()),
            "rows": len(rows), "format": parsed["format"], "bad_rows": parsed["bad"]}


def commit_import(db, parsed: dict, filename: str, actor, factory_id=None, kind=None, shift_min: int = 0,
                  select: set[int] | None = None, rebuild: bool = True) -> dict:
    """บันทึกค่าต่อช่วง (ทับค่าเดิมของเวลาเดียวกัน) + เก็บค่าเดิมไว้ยกเลิกได้ · rebuild = สร้างค่าอ่านรายวันใหม่
    (เฉพาะมิเตอร์ที่ไม่มีค่าจด/แก้เองในช่วงนั้น — กันเลขหน้าปัดจริงถูกแทน)"""
    ensure(db)
    db.executescript(IMPORT_DDL)
    mp = match_meters(db, sorted({k for k, _, _ in parsed["rows"]}), factory_id, kind)
    iid = db.execute("INSERT INTO en_interval_imports(created_at, user_id, filename) VALUES (?,?,?)", (ts(), actor, filename[:200])).lastrowid
    agg: dict[tuple[int, str], float] = {}
    for k, dt, v in parsed["rows"]:
        mid = mp.get(k)
        if not mid or (select is not None and mid not in select) or v < 0 or v > CAP_PER_SLOT:
            continue
        agg[(mid, ts((dt + timedelta(minutes=shift_min)).replace(second=0, microsecond=0)))] = v
    first: dict[int, str] = {}
    last: dict[int, str] = {}
    for (mid, stamp), v in agg.items():
        old = db.execute("SELECT value FROM en_intervals WHERE meter_id=? AND ts=?", (mid, stamp)).fetchone()
        db.execute("INSERT OR IGNORE INTO en_interval_import_rows(import_id, meter_id, ts, old_value) VALUES (?,?,?,?)",
                   (iid, mid, stamp, old[0] if old else None))
        db.execute("""INSERT INTO en_intervals(meter_id, ts, value) VALUES (?,?,?)
                      ON CONFLICT(meter_id, ts) DO UPDATE SET value=excluded.value""", (mid, stamp, v))
        first[mid] = min(first.get(mid, stamp), stamp)
        last[mid] = max(last.get(mid, stamp), stamp)
    rebuilt = []
    n_read = 0
    if rebuild:
        for mid in first:
            man = db.execute("SELECT 1 FROM en_readings WHERE meter_id=? AND src NOT IN ('scada') AND day BETWEEN ? AND ? LIMIT 1",
                             (mid, first[mid][:10], last[mid][:10])).fetchone()
            if man:
                continue
            n_read += rebuild_readings(db, [mid], date.fromisoformat(first[mid][:10]) - timedelta(days=1))
            rebuilt.append(mid)
    d_from = min(first.values())[:10] if first else None
    d_to = max(last.values())[:10] if last else None
    db.execute("UPDATE en_interval_imports SET meters=?, rows=?, d_from=?, d_to=?, rebuilt=? WHERE id=?",
               (len(first), len(agg), d_from, d_to, ",".join(map(str, rebuilt)), iid))
    S.audit(db, actor, "energy_interval_import", "en_interval_imports", iid,
            after={"file": filename, "meters": len(first), "rows": len(agg), "from": d_from, "to": d_to, "readings": n_read})
    return {"id": iid, "meters": len(first), "rows": len(agg), "readings": n_read, "rebuilt": len(rebuilt),
            "skipped_rebuild": len(first) - len(rebuilt), "from": d_from, "to": d_to}


def imports(db, limit: int = 30) -> list[dict]:
    ensure(db)
    db.executescript(IMPORT_DDL)
    return [dict(r) for r in db.execute("""SELECT i.*, u.name AS user_name FROM en_interval_imports i LEFT JOIN users u ON u.id=i.user_id
                                           ORDER BY i.id DESC LIMIT ?""", (limit,))]


def undo_import(db, iid: int, actor) -> dict:
    db.executescript(IMPORT_DDL)
    imp = db.execute("SELECT * FROM en_interval_imports WHERE id=?", (iid,)).fetchone()
    from .services import ValidationError
    if not imp or imp["undone_at"]:
        raise ValidationError(["ไม่พบรายการ หรือยกเลิกไปแล้ว"])
    n = 0
    mids = set()
    for mid, stamp, old in db.execute("SELECT meter_id, ts, old_value FROM en_interval_import_rows WHERE import_id=?", (iid,)).fetchall():
        if old is None:
            db.execute("DELETE FROM en_intervals WHERE meter_id=? AND ts=?", (mid, stamp))
        else:
            db.execute("UPDATE en_intervals SET value=? WHERE meter_id=? AND ts=?", (old, mid, stamp))
        mids.add(mid)
        n += 1
    rebuilt = [int(x) for x in (imp["rebuilt"] or "").split(",") if x.strip().isdigit()]
    if rebuilt and imp["d_from"]:
        d0 = date.fromisoformat(imp["d_from"])
        for mid in rebuilt:
            db.execute("DELETE FROM en_readings WHERE meter_id=? AND src='scada' AND day>=?", (mid, d0.isoformat()))
        rebuild_readings(db, rebuilt, d0 - timedelta(days=1))
    db.execute("UPDATE en_interval_imports SET undone_at=? WHERE id=?", (ts(), iid))
    S.audit(db, actor, "energy_interval_import_undo", "en_interval_imports", iid, after={"rows": n})
    return {"rows": n, "meters": len(mids)}


def sample_xlsx() -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    ws = wb.active
    ws.title = "แนวยาว"
    ws.append(["มิเตอร์", "เวลา", "ค่า"])
    for c in ws[1]:
        c.font = Font(bold=True)
    base = datetime.combine(date.today() - timedelta(days=1), time(0, 0))
    for i in range(1, 9):
        ws.append(["112", base + timedelta(minutes=15 * i), 12.5])
        ws.append(["ac_PMF1_165114 ACP2_114kwh", base + timedelta(minutes=15 * i), 3.25])
    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 20
    for r in ws.iter_rows(min_row=2, min_col=2, max_col=2):
        r[0].number_format = "dd/mm/yyyy hh:mm"
    w2 = wb.create_sheet("แนวกว้าง")
    w2.append(["เวลา", "112", "114", "ac_PMF1_1655 SCT0013_5kwh"])
    for c in w2[1]:
        c.font = Font(bold=True)
    for i in range(1, 9):
        w2.append([base + timedelta(minutes=15 * i), 12.5, 3.25, 40])
    w2.column_dimensions["A"].width = 20
    for r in w2.iter_rows(min_row=2, min_col=1, max_col=1):
        r[0].number_format = "dd/mm/yyyy hh:mm"
    w3 = wb.create_sheet("วิธีใช้")
    for line in ("ไฟล์ค่าต่อช่วงเวลา = พลังงานที่ใช้ในช่วงนั้น (kWh / m³) ทุก 15 นาที หรือรายชั่วโมง — ไม่ใช่เลขหน้าปัดสะสม",
                 "แนวยาว: 1 แถว = 1 มิเตอร์ × 1 เวลา (คอลัมน์ มิเตอร์ · เวลา · ค่า หรือ มิเตอร์ · วันที่ · เวลา · ค่า)",
                 "แนวกว้าง: คอลัมน์แรก = เวลา · คอลัมน์ถัดไป = 1 มิเตอร์ (หัวคอลัมน์ = No. / ชื่อ / Tag SCADA / #ID)",
                 "ชื่อมิเตอร์จับคู่ได้จาก: #ID · Tag SCADA · No. · ชื่อ · No.+ชื่อ (ไม่สนตัวพิมพ์เล็ก-ใหญ่)",
                 "ระบบใช้เฉพาะชีทแรกของไฟล์ · เวลาเป็น UTC ให้ใส่ 'เลื่อนเวลา' 420 นาทีตอนนำเข้า",
                 "นำเข้าซ้ำได้ (ทับค่าเวลาเดียวกัน) · ยกเลิกการนำเข้าได้ที่ประวัติ"):
        w3.append([line])
    w3.column_dimensions["A"].width = 120
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()
