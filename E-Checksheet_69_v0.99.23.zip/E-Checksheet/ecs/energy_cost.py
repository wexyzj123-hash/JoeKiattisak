"""ecs/energy_cost.py — ศูนย์ต้นทุนพลังงาน (v0.67)

เอกสาร 3 ชุดที่เชื่อมกันอัตโนมัติ
  ① ประจำวัน      ค่าอ่านมิเตอร์รายวันของแต่ละโรงงาน (en_readings) → หน่วยใช้รายวัน/รายเดือนต่อมิเตอร์
  ② ปันส่วนตามบิล  มิเตอร์ × ตัวคูณ → พื้นที่ (en_areas/en_area_links) → ปรับให้ “เท่ากับบิล” ทั้ง kWh และบาท (ไม่เกินบิล)
  ③ Energy management  พลังงาน + ค่าใช้จ่าย เทียบยอดผลิต/ยอดขาย · kWh/หน่วย เทียบเป้า (y = a·x + b) · ภาพรวม 3 โรงงาน

แหล่งหน่วยรายเดือนของมิเตอร์ (en_month_usage) — ใช้ก่อนข้อมูลรายวันเมื่อมี
  import = นำเข้าจากไฟล์ Energy management (ประวัติย้อนหลัง) · manual = ผู้ดูแลกรอก/แก้เอง
"""
from __future__ import annotations

import calendar
import io
import json
import re
from datetime import date

from . import services as S
from .services import ts

DDL = """
CREATE TABLE IF NOT EXISTS en_areas (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id  INTEGER NOT NULL,
    name        TEXT NOT NULL,
    grp         TEXT NOT NULL DEFAULT 'MFG',          -- MFG | SUPPORT | OFFICE | OTHER (หมวดในรายงาน)
    driver      TEXT NOT NULL DEFAULT 'total',        -- total | item | days | none  (ตัวหารของ kWh/หน่วย)
    item_id     INTEGER,                              -- driver = item
    target_a    REAL,                                 -- เป้า kWh/หน่วย = a·x + b  (x = ปริมาณตัวหาร)
    target_b    REAL,
    is_residual INTEGER NOT NULL DEFAULT 0,           -- รับส่วนต่าง “บิล − มิเตอร์” (วิธีส่วนต่าง)
    sort_no     INTEGER NOT NULL DEFAULT 0,
    active      INTEGER NOT NULL DEFAULT 1,
    note        TEXT NOT NULL DEFAULT '',
    updated_at  TEXT NOT NULL DEFAULT '',
    UNIQUE (factory_id, name)
);
CREATE TABLE IF NOT EXISTS en_area_links (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    area_id     INTEGER NOT NULL,
    meter_id    INTEGER NOT NULL,
    factor      REAL NOT NULL DEFAULT 1,              -- สูตรคูณ: หน่วยมิเตอร์ × factor (ติดลบ = หักออก, 0.5 = แบ่งครึ่ง)
    note        TEXT NOT NULL DEFAULT '',
    UNIQUE (area_id, meter_id)
);
CREATE INDEX IF NOT EXISTS idx_enal_meter ON en_area_links(meter_id);
CREATE TABLE IF NOT EXISTS en_month_usage (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    meter_id    INTEGER NOT NULL,
    month       TEXT NOT NULL,                        -- YYYY-MM
    kwh         REAL NOT NULL,
    src         TEXT NOT NULL DEFAULT 'manual',       -- import | manual
    note        TEXT NOT NULL DEFAULT '',
    user_id     INTEGER,
    updated_at  TEXT NOT NULL,
    UNIQUE (meter_id, month)
);
CREATE TABLE IF NOT EXISTS en_prod_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id  INTEGER NOT NULL,
    name        TEXT NOT NULL,
    unit        TEXT NOT NULL DEFAULT 'ชิ้น',
    weight      REAL NOT NULL DEFAULT 1,              -- น้ำหนักเข้า “ยอดผลิตรวม” (เช่น ชิ้น ÷ 20 → 0.05 · 0 = ไม่นับ)
    sort_no     INTEGER NOT NULL DEFAULT 0,
    active      INTEGER NOT NULL DEFAULT 1,
    UNIQUE (factory_id, name)
);
CREATE TABLE IF NOT EXISTS en_prod_qty (
    item_id     INTEGER NOT NULL,
    month       TEXT NOT NULL,
    qty         REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (item_id, month)
);
CREATE TABLE IF NOT EXISTS en_month_info (
    factory_id  INTEGER NOT NULL,
    month       TEXT NOT NULL,
    work_days   REAL,
    sales       REAL,
    note        TEXT NOT NULL DEFAULT '',
    updated_at  TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (factory_id, month)
);
"""

GROUPS = {"MFG": "ผลิต (MFG)", "SUPPORT": "สนับสนุน (Support/Utility)", "OFFICE": "สำนักงาน/สวัสดิการ", "OTHER": "อื่นๆ"}
DRIVERS = {"total": "ยอดผลิตรวม", "item": "ยอดผลิตรายการ", "days": "วันทำงาน", "none": "ไม่คิดต่อหน่วย"}
METHODS = {"prop": "เฉลี่ยตามสัดส่วนมิเตอร์ (ทุกพื้นที่ปรับเท่ากัน)", "residual": "ส่วนต่างเข้าพื้นที่ “อื่นๆ” (เกินบิล → ปรับตามสัดส่วน)"}
BASIS = {"amount": "ก่อน VAT (ตามไฟล์เดิม)", "total": "รวม VAT"}
CFG_DEFAULT = {"method": "prop", "basis": "amount", "sales_unit": "บาท"}
TH_M = ("ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.")


def ensure_cost(db) -> None:
    db.executescript(DDL)


def _f(v, label: str, allow_empty=True, minimum: float | None = None):
    s = str(v if v is not None else "").replace(",", "").strip()
    if s == "":
        if allow_empty:
            return None
        raise S.ValidationError(f"กรอก{label}")
    try:
        x = float(s)
    except ValueError:
        raise S.ValidationError(f"{label} ต้องเป็นตัวเลข") from None
    if x != x or abs(x) > 1e13:
        raise S.ValidationError(f"{label} ไม่ถูกต้อง")
    if minimum is not None and x < minimum:
        raise S.ValidationError(f"{label} ต้องไม่น้อยกว่า {minimum:g}")
    return x


def _ym(year: int, mo: int) -> str:
    return f"{year}-{mo:02d}"


def meter_key(section: str, name: str, no) -> str:
    """คีย์มิเตอร์เดียวกันทั้งไฟล์ประจำวัน (Daily_*) และไฟล์ Energy management → จับคู่กันได้อัตโนมัติ"""
    def c(x):
        if isinstance(x, float) and x.is_integer():
            x = int(x)
        return re.sub(r"\s+", " ", str(x or "")).strip()
    return " | ".join(p for p in (c(section), c(name), c(no)) if p).upper()[:150] or "?"


# ───────────────────────── ตั้งค่า ─────────────────────────

def config(db) -> dict:
    out = {"_": dict(CFG_DEFAULT)}
    r = db.execute("SELECT value FROM cs_meta WHERE key='energy_cost'").fetchone()
    if r and r[0]:
        try:
            raw = json.loads(r[0])
            for k, v in raw.items():
                if isinstance(v, dict):
                    out[k] = {**CFG_DEFAULT, **{x: y for x, y in v.items() if x in CFG_DEFAULT}}
        except (ValueError, TypeError):
            pass
    return out


def fcfg(db, fid) -> dict:
    c = config(db)
    return {**c["_"], **c.get(str(fid), {})}


def save_config(db, fid, data: dict, actor) -> dict:
    c = config(db)
    cur = {**c["_"], **c.get(str(fid), {})}
    if data.get("method") in METHODS:
        cur["method"] = data["method"]
    if data.get("basis") in BASIS:
        cur["basis"] = data["basis"]
    if "sales_unit" in data:
        cur["sales_unit"] = str(data.get("sales_unit") or "บาท").strip()[:20] or "บาท"
    c[str(fid)] = cur
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('energy_cost', ?)", (json.dumps(c, ensure_ascii=False),))
    S.audit(db, actor, "energy_cost_cfg", "cs_meta", None, after={"factory_id": fid, **cur})
    return cur


# ───────────────────────── พื้นที่ (ศูนย์ต้นทุน) + สูตรเชื่อมมิเตอร์ ─────────────────────────

def areas(db, fid: int, active_only=False) -> list[dict]:
    ensure_cost(db)
    w = " AND a.active=1" if active_only else ""
    rows = [dict(r) for r in db.execute(f"""SELECT a.*, i.name AS item_name, i.unit AS item_unit,
                    (SELECT COUNT(*) FROM en_area_links l WHERE l.area_id=a.id) AS n_links
                    FROM en_areas a LEFT JOIN en_prod_items i ON i.id=a.item_id
                    WHERE a.factory_id=?{w} ORDER BY a.sort_no, a.id""", (fid,))]
    return rows


def area(db, aid: int) -> dict | None:
    ensure_cost(db)
    r = db.execute("SELECT * FROM en_areas WHERE id=?", (aid,)).fetchone()
    return dict(r) if r else None


def links(db, aid: int) -> list[dict]:
    return [dict(r) for r in db.execute("""SELECT l.*, m.code, m.name, m.grp, m.multiplier, m.is_main, m.active, m.key
                                           FROM en_area_links l JOIN en_meters m ON m.id=l.meter_id
                                           WHERE l.area_id=? ORDER BY m.grp, m.sort_no, m.id""", (aid,))]


def save_area(db, fid: int, data: dict, actor, aid: int | None = None) -> int:
    ensure_cost(db)
    name = re.sub(r"\s+", " ", str(data.get("name") or "")).strip()[:80]
    if not name:
        raise S.ValidationError("กรอกชื่อพื้นที่")
    grp = data.get("grp") if data.get("grp") in GROUPS else "MFG"
    driver = data.get("driver") if data.get("driver") in DRIVERS else "total"
    item_id = int(data.get("item_id") or 0) or None
    if driver == "item":
        if not item_id or not db.execute("SELECT 1 FROM en_prod_items WHERE id=? AND factory_id=?", (item_id, fid)).fetchone():
            raise S.ValidationError("เลือกรายการผลิตที่ใช้เป็นตัวหาร")
    else:
        item_id = None
    ta = _f(data.get("target_a"), "เป้า a")
    tb = _f(data.get("target_b"), "เป้า b")
    resid = 1 if str(data.get("is_residual") or "") in ("1", "on", "true") else 0
    active = 0 if str(data.get("active", "1")) in ("0", "") else 1
    note = str(data.get("note") or "").strip()[:200]
    dup = db.execute("SELECT id FROM en_areas WHERE factory_id=? AND name=? AND id IS NOT ?", (fid, name, aid)).fetchone()
    if dup:
        raise S.ValidationError(f"มีพื้นที่ชื่อ “{name}” แล้ว")
    stamp = ts(S.now_dt())
    if resid:
        db.execute("UPDATE en_areas SET is_residual=0 WHERE factory_id=? AND id IS NOT ?", (fid, aid))
    if aid:
        before = area(db, aid)
        if not before or before["factory_id"] != fid:
            raise S.ValidationError("ไม่พบพื้นที่")
        db.execute("""UPDATE en_areas SET name=?, grp=?, driver=?, item_id=?, target_a=?, target_b=?, is_residual=?, active=?,
                      note=?, updated_at=? WHERE id=?""", (name, grp, driver, item_id, ta, tb, resid, active, note, stamp, aid))
        S.audit(db, actor, "energy_area", "en_areas", aid, before=before, after=area(db, aid))
        return aid
    so = (db.execute("SELECT MAX(sort_no) FROM en_areas WHERE factory_id=?", (fid,)).fetchone()[0] or 0) + 10
    aid = db.execute("""INSERT INTO en_areas(factory_id, name, grp, driver, item_id, target_a, target_b, is_residual, sort_no,
                        active, note, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (fid, name, grp, driver, item_id, ta, tb, resid, so, active, note, stamp)).lastrowid
    S.audit(db, actor, "energy_area_new", "en_areas", aid, after=area(db, aid))
    return aid


def delete_area(db, aid: int, actor) -> None:
    a = area(db, aid)
    if not a:
        return
    db.execute("DELETE FROM en_area_links WHERE area_id=?", (aid,))
    db.execute("DELETE FROM en_areas WHERE id=?", (aid,))
    S.audit(db, actor, "energy_area_del", "en_areas", aid, before=a)


def reorder_areas(db, fid: int, ids: list[int], actor) -> None:
    for i, aid in enumerate(ids):
        db.execute("UPDATE en_areas SET sort_no=? WHERE id=? AND factory_id=?", ((i + 1) * 10, int(aid), fid))
    S.audit(db, actor, "energy_area_order", "en_areas", None, after={"factory_id": fid, "ids": ids})


def save_links(db, aid: int, rows: list[dict], actor) -> int:
    """แทนที่สูตรของพื้นที่ทั้งชุด: [{meter_id, factor, note}] — มิเตอร์ต้องอยู่โรงงานเดียวกัน"""
    a = area(db, aid)
    if not a:
        raise S.ValidationError("ไม่พบพื้นที่")
    ok = {r[0] for r in db.execute("SELECT id FROM en_meters WHERE factory_id=?", (a["factory_id"],))}
    before = links(db, aid)
    seen = {}
    for r in rows:
        mid = int(r.get("meter_id") or 0)
        if mid not in ok:
            continue
        fac = _f(r.get("factor"), "ตัวคูณ")
        fac = 1.0 if fac is None else fac
        seen[mid] = (fac, str(r.get("note") or "").strip()[:120])
    db.execute("DELETE FROM en_area_links WHERE area_id=?", (aid,))
    for mid, (fac, note) in seen.items():
        db.execute("INSERT INTO en_area_links(area_id, meter_id, factor, note) VALUES (?,?,?,?)", (aid, mid, fac, note))
    db.execute("UPDATE en_areas SET updated_at=? WHERE id=?", (ts(S.now_dt()), aid))
    S.audit(db, actor, "energy_area_links", "en_area_links", aid,
            before={"links": [(x["meter_id"], x["factor"]) for x in before]}, after={"links": [(m, f) for m, (f, _) in seen.items()]})
    return len(seen)


def sync_sections(db, fid: int, actor, replace: bool = False) -> dict:
    """v0.90 พื้นที่ = Section ของมิเตอร์ไฟฟ้า (ชุดเดียวกับหน้า Dashboard/รายงาน) · สูตร = มิเตอร์ที่นับในยอดของ Section
    (กติกาเดียวทั้งระบบ EN.counted) · replace = เขียนสูตรของพื้นที่ชื่อเดียวกันทับ"""
    from . import energy as EN
    ensure_cost(db)
    ms = EN.meters(db, fid, "elec")
    by: dict[str, list] = {}
    fm = EN.factory_mains(ms)
    for m in ms:
        if m["id"] not in fm:
            by.setdefault((m["grp"] or "").strip() or "ไม่ระบุ Section", []).append(m)
    res = {"new": 0, "updated": 0, "kept": 0}
    for g, lst in by.items():
        cm = EN.counted(lst)
        if not cm:
            continue
        r = db.execute("SELECT id FROM en_areas WHERE factory_id=? AND name=?", (fid, g[:80])).fetchone()
        if r and not replace:
            res["kept"] += 1
            continue
        aid = r[0] if r else save_area(db, fid, {"name": g, "grp": "MFG" if "LINE" in g.upper() or "PRODUCTION" in g.upper() else "SUPPORT",
                                                 "driver": "total", "note": "สร้างจาก Section ของมิเตอร์"}, actor)
        save_links(db, aid, [{"meter_id": m["id"], "factor": EN.sign(m)} for m in cm], actor)
        res["updated" if r else "new"] += 1
    return res


def link_map(db, fid: int) -> dict[int, list[tuple[int, float]]]:
    """meter_id → [(area_id, factor)] — ใช้แสดงว่ามิเตอร์ไหนยังไม่ถูกเชื่อม/ถูกนับซ้ำ"""
    out: dict[int, list] = {}
    for r in db.execute("""SELECT l.meter_id, l.area_id, l.factor FROM en_area_links l JOIN en_areas a ON a.id=l.area_id
                           WHERE a.factory_id=? AND a.active=1""", (fid,)):
        out.setdefault(r[0], []).append((r[1], r[2]))
    return out


# ───────────────────────── รายการผลิต · ยอดผลิต · ยอดขาย · วันทำงาน ─────────────────────────

def items(db, fid: int, active_only=False) -> list[dict]:
    ensure_cost(db)
    w = " AND active=1" if active_only else ""
    return [dict(r) for r in db.execute(f"SELECT * FROM en_prod_items WHERE factory_id=?{w} ORDER BY sort_no, id", (fid,))]


def save_item(db, fid: int, data: dict, actor, iid: int | None = None) -> int:
    ensure_cost(db)
    name = re.sub(r"\s+", " ", str(data.get("name") or "")).strip()[:60]
    if not name:
        raise S.ValidationError("กรอกชื่อรายการผลิต")
    unit = str(data.get("unit") or "ชิ้น").strip()[:20] or "ชิ้น"
    w = _f(data.get("weight"), "น้ำหนักรวมยอด", minimum=0)
    w = 1.0 if w is None else w
    active = 0 if str(data.get("active", "1")) in ("0", "") else 1
    if db.execute("SELECT 1 FROM en_prod_items WHERE factory_id=? AND name=? AND id IS NOT ?", (fid, name, iid)).fetchone():
        raise S.ValidationError(f"มีรายการ “{name}” แล้ว")
    if iid:
        db.execute("UPDATE en_prod_items SET name=?, unit=?, weight=?, active=? WHERE id=? AND factory_id=?", (name, unit, w, active, iid, fid))
    else:
        so = (db.execute("SELECT MAX(sort_no) FROM en_prod_items WHERE factory_id=?", (fid,)).fetchone()[0] or 0) + 10
        iid = db.execute("INSERT INTO en_prod_items(factory_id, name, unit, weight, sort_no, active) VALUES (?,?,?,?,?,?)",
                         (fid, name, unit, w, so, active)).lastrowid
    S.audit(db, actor, "energy_prod_item", "en_prod_items", iid, after={"name": name, "unit": unit, "weight": w, "active": active})
    return iid


def delete_item(db, iid: int, actor) -> None:
    r = db.execute("SELECT * FROM en_prod_items WHERE id=?", (iid,)).fetchone()
    if not r:
        return
    if db.execute("SELECT 1 FROM en_areas WHERE item_id=?", (iid,)).fetchone():
        raise S.ValidationError("รายการนี้ถูกใช้เป็นตัวหารของพื้นที่ — เปลี่ยนตัวหารก่อน")
    db.execute("DELETE FROM en_prod_qty WHERE item_id=?", (iid,))
    db.execute("DELETE FROM en_prod_items WHERE id=?", (iid,))
    S.audit(db, actor, "energy_prod_item_del", "en_prod_items", iid, before=dict(r))


def save_month_grid(db, fid: int, year: int, form, actor) -> int:
    """ตารางรายเดือนทั้งปี: q_<item>_<mo> · wd_<mo> · sales_<mo> (ช่องว่าง = ลบค่า)"""
    ensure_cost(db)
    n = 0
    its = {i["id"] for i in items(db, fid)}
    stamp = ts(S.now_dt())
    for mo in range(1, 13):
        ym = _ym(year, mo)
        for iid in its:
            k = f"q_{iid}_{mo}"
            if k not in form:
                continue
            v = _f(form.get(k), f"ยอดผลิต {TH_M[mo - 1]}", minimum=0)
            if v is None:
                db.execute("DELETE FROM en_prod_qty WHERE item_id=? AND month=?", (iid, ym))
            else:
                db.execute("""INSERT INTO en_prod_qty(item_id, month, qty) VALUES (?,?,?)
                              ON CONFLICT(item_id, month) DO UPDATE SET qty=excluded.qty""", (iid, ym, v))
            n += 1
        if f"wd_{mo}" in form or f"sales_{mo}" in form:
            wd = _f(form.get(f"wd_{mo}"), f"วันทำงาน {TH_M[mo - 1]}", minimum=0)
            sl = _f(form.get(f"sales_{mo}"), f"ยอดขาย {TH_M[mo - 1]}", minimum=0)
            db.execute("""INSERT INTO en_month_info(factory_id, month, work_days, sales, updated_at) VALUES (?,?,?,?,?)
                          ON CONFLICT(factory_id, month) DO UPDATE SET work_days=excluded.work_days, sales=excluded.sales,
                          updated_at=excluded.updated_at""", (fid, ym, wd, sl, stamp))
            n += 1
    S.audit(db, actor, "energy_prod_grid", "en_prod_qty", None, after={"factory_id": fid, "year": year, "cells": n})
    return n


def prod_year(db, fid: int, year: int) -> dict:
    """ยอดผลิตรายการ × 12 เดือน · ยอดผลิตรวม (Σ qty × weight; ไม่มีรายการ → en_production เดิม) · วันทำงาน · ยอดขาย"""
    ensure_cost(db)
    its = items(db, fid)
    q = {(r[0], r[1]): r[2] for r in db.execute("""SELECT q.item_id, q.month, q.qty FROM en_prod_qty q
                    JOIN en_prod_items i ON i.id=q.item_id WHERE i.factory_id=? AND q.month LIKE ?""", (fid, f"{year}-%"))}
    info = {r["month"]: dict(r) for r in db.execute("SELECT * FROM en_month_info WHERE factory_id=? AND month LIKE ?",
                                                     (fid, f"{year}-%"))}
    legacy = {r["month"]: dict(r) for r in db.execute("SELECT * FROM en_production WHERE factory_id=? AND month LIKE ?",
                                                       (fid, f"{year}-%"))}
    total, wd, sales = [], [], []
    for mo in range(1, 13):
        ym = _ym(year, mo)
        vals = [(i, q.get((i["id"], ym))) for i in its if i["active"]]
        if any(v is not None for _, v in vals):
            total.append(round(sum((v or 0) * i["weight"] for i, v in vals), 4))
        elif ym in legacy:
            total.append(legacy[ym]["qty"])
        else:
            total.append(None)
        wd.append((info.get(ym) or {}).get("work_days"))
        sales.append((info.get(ym) or {}).get("sales"))
    for i in its:
        i["qty"] = [q.get((i["id"], _ym(year, mo))) for mo in range(1, 13)]
    return {"items": its, "total": total, "work_days": wd, "sales": sales}


# ───────────────────────── หน่วยรายเดือนต่อมิเตอร์ (ประจำวัน / นำเข้า / กรอกเอง) ─────────────────────────

def elec_meters(db, fid: int) -> list[dict]:
    from . import energy as EN
    return EN.meters(db, fid, "elec", active_only=False)


def meter_months(db, fid: int, year: int, today: date | None = None) -> dict:
    """{meter_id: {"kwh": [12], "src": [12], "days": [12]}}
    v0.90 ใช้ค่าจดมิเตอร์ดิบเป็นหลัก (ตัวคำนวณเดียวกับทุกหน้า):
      แก้เอง (manual) → ใช้ค่าที่แก้เสมอ · มีค่ารายวันครบ ≥ 80% ของวันในเดือน → ใช้ผลรวมรายวัน
      · ไม่งั้นใช้ยอดที่นำเข้าจาก Excel (ถ้ามี) — นำเข้าใช้แค่เติมเดือนที่ยังไม่มีค่าจด"""
    from . import energy as EN
    ensure_cost(db)
    ms = elec_meters(db, fid)
    today = today or S.now_dt().date()
    d_from = date(year, 1, 1)
    d_to = min(date(year, 12, 31), today)
    ser = EN.series(db, ms, d_from, d_to) if ms and d_to >= d_from else {}
    mon = {}
    if ms:
        ids = ",".join(str(m["id"]) for m in ms)
        for r in db.execute(f"SELECT meter_id, month, kwh, src FROM en_month_usage WHERE month LIKE ? AND meter_id IN ({ids})",
                            (f"{year}-%",)):
            mon[(r[0], r[1])] = (r[2], r[3])
    out = {}
    for m in ms:
        kwh, src, days = [None] * 12, [None] * 12, [0] * 12
        for d, x in (ser.get(m["id"]) or {}).items():
            if x.get("u") is None:
                continue
            i = int(d[5:7]) - 1
            kwh[i] = (kwh[i] or 0) + x["u"]
            days[i] += 1
            src[i] = "daily"
        for i in range(12):
            hit = mon.get((m["id"], _ym(year, i + 1)))
            n_days = calendar.monthrange(year, i + 1)[1]
            if date(year, i + 1, 1) <= today < date(year, i + 1, n_days):
                n_days = max(1, (today - date(year, i + 1, 1)).days)
            if hit and (hit[1] == "manual" or days[i] < 0.8 * n_days):
                kwh[i], src[i] = hit
            elif kwh[i] is not None:
                kwh[i] = round(kwh[i], 3)
        out[m["id"]] = {"kwh": kwh, "src": src, "days": days, "meter": m}
    return out


def set_month_usage(db, mid: int, ym: str, kwh, actor, note: str = "", src: str = "manual") -> None:
    ensure_cost(db)
    if not re.match(r"^\d{4}-\d{2}$", ym or ""):
        raise S.ValidationError("เดือนไม่ถูกต้อง")
    old = db.execute("SELECT kwh, src FROM en_month_usage WHERE meter_id=? AND month=?", (mid, ym)).fetchone()
    v = _f(kwh, "หน่วยรายเดือน")
    if v is None:
        db.execute("DELETE FROM en_month_usage WHERE meter_id=? AND month=?", (mid, ym))
    else:
        db.execute("""INSERT INTO en_month_usage(meter_id, month, kwh, src, note, user_id, updated_at) VALUES (?,?,?,?,?,?,?)
                      ON CONFLICT(meter_id, month) DO UPDATE SET kwh=excluded.kwh, src=excluded.src, note=excluded.note,
                      user_id=excluded.user_id, updated_at=excluded.updated_at""",
                   (mid, ym, v, src, note[:200], actor, ts(S.now_dt())))
    S.audit(db, actor, "energy_month_usage", "en_month_usage", mid,
            before={"month": ym, "kwh": old[0] if old else None}, after={"month": ym, "kwh": v, "note": note[:200]})


# ───────────────────────── ② ปันส่วนให้เท่ากับบิล ─────────────────────────

def _round_to(vals: list[float], total: float, nd: int = 2) -> list[float]:
    """ปัดเศษให้ผลรวม “เท่ากับ total พอดี” (largest remainder) — ไม่เกินบิลแม้แต่สตางค์เดียว"""
    if not vals:
        return []
    k = 10 ** nd
    raw = [v * k for v in vals]
    fl = [int(x // 1) for x in raw]
    target = int(round(total * k))
    rest = target - sum(fl)
    order = sorted(range(len(vals)), key=lambda i: -(raw[i] - fl[i]))
    step = 1 if rest > 0 else -1
    i = 0
    while rest and order:
        fl[order[i % len(order)]] += step
        rest -= step
        i += 1
    return [x / k for x in fl]


def allocate(measured: list[float], bill: float, method: str, resid_idx: int | None) -> tuple[list[float], float]:
    """measured[i] = kWh ตามมิเตอร์ของพื้นที่ i → (kWh หลังปันส่วน, ส่วนที่ไม่มีพื้นที่รับ)
    prop      ทุกพื้นที่ × (บิล ÷ ผลรวมมิเตอร์)
    residual  มิเตอร์ ≤ บิล → ส่วนต่างเข้าพื้นที่ “อื่นๆ” · มิเตอร์ > บิล → ปรับตามสัดส่วน (ไม่เกินบิล)"""
    m = [max(0.0, x or 0.0) for x in measured]
    s = sum(m)
    if bill <= 0:
        return [0.0] * len(m), 0.0
    if s <= 0:
        out = [0.0] * len(m)
        if resid_idx is not None:
            out[resid_idx] = bill
            return _round_to(out, bill), 0.0
        return out, round(bill, 2)
    if method == "residual" and s <= bill:
        out = list(m)
        gap = bill - s
        if resid_idx is not None:
            out[resid_idx] += gap
            return _round_to(out, bill), 0.0
        return _round_to(out, s), round(gap, 2)
    k = bill / s
    return _round_to([x * k for x in m], bill), 0.0


def reconcile(db, fid: int, year: int, today: date | None = None) -> dict:
    """ปันส่วนรายเดือนของโรงงาน: พื้นที่ × เดือน → kWh มิเตอร์ / kWh ตามบิล / บาท / ตัวปรับ / kWh-หน่วย เทียบเป้า"""
    ensure_cost(db)
    today = today or S.now_dt().date()
    cfg = fcfg(db, fid)
    ars = areas(db, fid, active_only=True)
    mm = meter_months(db, fid, year, today)
    lk = {a["id"]: [(l["meter_id"], l["factor"]) for l in links(db, a["id"])] for a in ars}
    bills = {r["month"]: dict(r) for r in db.execute("SELECT * FROM en_bills WHERE factory_id=? AND month LIKE ?",
                                                      (fid, f"{year}-%"))}
    prod = prod_year(db, fid, year)
    resid_idx = next((i for i, a in enumerate(ars) if a["is_residual"]), None)
    months = []
    rows = [{"area": a, "meas": [None] * 12, "kwh": [None] * 12, "baht": [None] * 12, "x": [None] * 12,
             "per": [None] * 12, "target": [None] * 12, "status": [None] * 12} for a in ars]
    unalloc_kwh, unalloc_baht = [None] * 12, [None] * 12
    missing = {}
    for i in range(12):
        ym = _ym(year, i + 1)
        if date(year, i + 1, 1) > today and ym not in bills:
            continue
        meas = []
        for a in ars:
            tot = None
            for mid, fac in lk[a["id"]]:
                v = (mm.get(mid) or {}).get("kwh", [None] * 12)[i]
                if v is None:
                    missing.setdefault(ym, set()).add(mid)
                    continue
                tot = (tot or 0) + v * fac
            meas.append(tot)
        b = bills.get(ym)
        bkwh = b["kwh"] if b else None
        bbaht = ((b["amount"] + b["vat"]) if cfg["basis"] == "total" else b["amount"]) if b else None
        s_meas = round(sum(max(0, x or 0) for x in meas), 2)
        info = {"i": i, "ym": ym, "bill": b, "bill_kwh": bkwh, "bill_baht": bbaht, "meas": s_meas,
                "rate": round(bbaht / bkwh, 4) if b and bkwh and bbaht else None,
                "factor": round(bkwh / s_meas, 4) if bkwh and s_meas else None,
                "cover": round(100 * s_meas / bkwh, 1) if bkwh and s_meas else None,
                "prod": prod["total"][i], "work_days": prod["work_days"][i], "sales": prod["sales"][i]}
        for r, x in zip(rows, meas):
            r["meas"][i] = round(x, 2) if x is not None else None
        if b and bkwh:
            kw, rest = allocate(meas, bkwh, cfg["method"], resid_idx)
            baht_raw = [x * bbaht / bkwh for x in kw] + ([rest * bbaht / bkwh] if rest else [])
            baht = _round_to(baht_raw, bbaht) if bbaht else [0.0] * len(baht_raw)
            for j, r in enumerate(rows):
                r["kwh"][i], r["baht"][i] = kw[j], baht[j]
            if rest:
                unalloc_kwh[i], unalloc_baht[i] = rest, baht[-1]
            info["kwh_unit"] = round(bkwh / info["prod"], 4) if info["prod"] else None
            info["baht_unit"] = round(bbaht / info["prod"], 4) if info["prod"] and bbaht else None
            info["pct_sales"] = round(100 * bbaht / info["sales"], 3) if info["sales"] and bbaht else None
        months.append(info)
        for r in rows:
            a = r["area"]
            if a["driver"] == "total":
                x = prod["total"][i]
            elif a["driver"] == "days":
                x = prod["work_days"][i]
            elif a["driver"] == "item":
                it = next((t for t in prod["items"] if t["id"] == a["item_id"]), None)
                x = it["qty"][i] if it else None
            else:
                x = None
            r["x"][i] = x
            k = r["kwh"][i] if r["kwh"][i] is not None else r["meas"][i]
            if x and k is not None:
                r["per"][i] = round(k / x, 4)
                if a["target_a"] is not None or a["target_b"] is not None:
                    t = (a["target_a"] or 0) * x + (a["target_b"] or 0)
                    r["target"][i] = round(t, 4)
                    if t > 0:
                        r["status"][i] = "ok" if r["per"][i] <= t else ("warn" if r["per"][i] <= t * 1.1 else "bad")
    for r in rows:
        r["sum_kwh"] = round(sum(x for x in r["kwh"] if x), 2)
        r["sum_baht"] = round(sum(x for x in r["baht"] if x), 2)
        r["sum_meas"] = round(sum(x for x in r["meas"] if x), 2)
    used = {mid for a in ars for mid, _ in lk[a["id"]]}
    unlinked = [m for mid, m in ((k, v["meter"]) for k, v in mm.items()) if mid not in used and m["active"] and m["is_main"] == 0
                and any(x for x in mm[mid]["kwh"])]
    sb = [m for m in months if m["bill"]]
    totals = {"bill_kwh": round(sum(m["bill_kwh"] for m in sb), 2), "bill_baht": round(sum(m["bill_baht"] or 0 for m in sb), 2),
              "meas": round(sum(m["meas"] for m in sb), 2), "prod": round(sum(m["prod"] or 0 for m in sb), 2),
              "sales": round(sum(m["sales"] or 0 for m in sb), 2)}
    totals["rate"] = round(totals["bill_baht"] / totals["bill_kwh"], 4) if totals["bill_kwh"] else None
    totals["kwh_unit"] = round(totals["bill_kwh"] / totals["prod"], 4) if totals["prod"] else None
    totals["baht_unit"] = round(totals["bill_baht"] / totals["prod"], 4) if totals["prod"] else None
    totals["pct_sales"] = round(100 * totals["bill_baht"] / totals["sales"], 3) if totals["sales"] else None
    return {"year": year, "fid": fid, "cfg": cfg, "areas": ars, "rows": rows, "months": months, "unalloc_kwh": unalloc_kwh,
            "unalloc_baht": unalloc_baht, "has_unalloc": any(x for x in unalloc_kwh), "totals": totals, "unlinked": unlinked,
            "missing": {k: len(v) for k, v in missing.items()}, "prod": prod, "resid_idx": resid_idx}


def daily_areas(db, fid: int, month: date) -> dict:
    """① ประจำวัน → แยกพื้นที่: kWh รายวันต่อพื้นที่ (มิเตอร์ × ตัวคูณ) + ค่าไฟประมาณ (บาท/kWh ของบิลเดือนนั้น/ล่าสุด)"""
    from . import energy as EN
    ensure_cost(db)
    d_from, d_to = EN.month_bounds(month)
    d_to = min(d_to, S.now_dt().date())
    ars = areas(db, fid, active_only=True)
    ms = elec_meters(db, fid)
    days = EN._days(d_from, d_to) if d_to >= d_from else []
    ser = EN.series(db, ms, d_from, d_to) if ms and days else {}
    cfg = fcfg(db, fid)
    b = db.execute("SELECT * FROM en_bills WHERE factory_id=? AND month<=? ORDER BY month DESC LIMIT 1",
                   (fid, month.strftime("%Y-%m"))).fetchone()
    rate = None
    if b and b["kwh"]:
        rate = ((b["amount"] + b["vat"]) if cfg["basis"] == "total" else b["amount"]) / b["kwh"]
    rows = []
    for a in ars:
        vals = []
        for d in days:
            t = None
            for l in links(db, a["id"]):
                x = (ser.get(l["meter_id"]) or {}).get(d, {})
                if x.get("u") is not None:
                    t = (t or 0) + x["u"] * l["factor"]
            vals.append(round(t, 2) if t is not None else None)
        s = round(sum(v for v in vals if v), 2)
        rows.append({"area": a, "vals": vals, "sum": s, "baht": round(s * rate, 2) if rate else None})
    tot = [round(sum(r["vals"][i] or 0 for r in rows), 2) for i in range(len(days))]
    return {"days": days, "rows": rows, "total": tot, "rate": round(rate, 4) if rate else None,
            "rate_month": b["month"] if b else None, "grand": round(sum(tot), 2)}


# ───────────────────────── ③ Energy management (ภาพรวมหลายโรงงาน) ─────────────────────────

def overview(db, year: int, today: date | None = None) -> dict:
    from . import masterdata as M
    facs = M.list_factories(db)
    out = []
    for f in facs:
        rc = reconcile(db, f["id"], year, today)
        grp = {}
        for r in rc["rows"]:
            g = r["area"]["grp"]
            grp.setdefault(g, [0.0] * 12)
            for i in range(12):
                grp[g][i] += r["kwh"][i] or 0
        out.append({"factory": f, "rc": rc, "grp": {k: [round(x, 2) for x in v] for k, v in grp.items()}})
    tot = {"bill_kwh": [0.0] * 12, "bill_baht": [0.0] * 12, "prod": [0.0] * 12, "sales": [0.0] * 12}
    for F in out:
        for m in F["rc"]["months"]:
            i = m["i"]
            tot["bill_kwh"][i] += m["bill_kwh"] or 0
            tot["bill_baht"][i] += m["bill_baht"] or 0
            tot["prod"][i] += m["prod"] or 0
            tot["sales"][i] += m["sales"] or 0
    tot["rate"] = [round(b / k, 4) if k else None for k, b in zip(tot["bill_kwh"], tot["bill_baht"])]
    tot["pct_sales"] = [round(100 * b / s, 3) if s else None for b, s in zip(tot["bill_baht"], tot["sales"])]
    g = {k: round(sum(v), 2) for k, v in tot.items() if k in ("bill_kwh", "bill_baht", "prod", "sales")}
    g["rate"] = round(g["bill_baht"] / g["bill_kwh"], 4) if g["bill_kwh"] else None
    g["pct_sales"] = round(100 * g["bill_baht"] / g["sales"], 3) if g["sales"] else None
    from . import energy as EN
    ef = EN.settings(db)["ef_elec"]
    g["tco2"] = round(g["bill_kwh"] * ef / 1000, 2)
    return {"year": year, "factories": out, "tot": tot, "g": g, "ef": ef}


# ───────────────────────── Excel ─────────────────────────

def _wb_styles():
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    thin = Side(style="thin", color="CBD5E1")
    return {"h": Font(bold=True, color="FFFFFF"), "hf": PatternFill("solid", fgColor="1E3A5F"),
            "sub": PatternFill("solid", fgColor="E2E8F0"), "tot": PatternFill("solid", fgColor="FEF3C7"),
            "b": Font(bold=True), "t": Font(bold=True, size=14), "bd": Border(top=thin, bottom=thin, left=thin, right=thin),
            "c": Alignment(horizontal="center", vertical="center", wrap_text=True)}


def _hdr(ws, r, vals, st, widths=None):
    for c, v in enumerate(vals, 1):
        x = ws.cell(r, c, v)
        x.font, x.fill, x.alignment, x.border = st["h"], st["hf"], st["c"], st["bd"]
    if widths:
        from openpyxl.utils import get_column_letter as L
        for c, w in enumerate(widths, 1):
            ws.column_dimensions[L(c)].width = w


def _put(ws, r, vals, st, fmt="#,##0.00", fill=None, bold=False):
    for c, v in enumerate(vals, 1):
        x = ws.cell(r, c, v)
        x.border = st["bd"]
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            x.number_format = fmt
        if fill:
            x.fill = fill
        if bold:
            x.font = st["b"]


def cost_xlsx(db, fid: int, year: int) -> bytes:
    """เอกสาร ② ปันส่วนค่าไฟตามบิล — ชีต: สรุปบิล · kWh พื้นที่ · บาทพื้นที่ · มิเตอร์รายเดือน · สูตรเชื่อมโยง"""
    from openpyxl import Workbook

    from . import energy as EN
    from . import masterdata as M
    st = _wb_styles()
    fac = next((f for f in M.list_factories(db, True) if f["id"] == fid), {"name": f"F{fid}"})
    rc = reconcile(db, fid, year)
    wb = Workbook()
    ws = wb.active
    ws.title = "สรุปบิล"
    ws["A1"] = f"ปันส่วนค่าไฟฟ้าตามบิล · {fac['name']} · ปี {year}"
    ws["A1"].font = st["t"]
    ws["A2"] = f"วิธี: {METHODS[rc['cfg']['method']]} · ฐานบาท: {BASIS[rc['cfg']['basis']]} · ผลรวมทุกพื้นที่ = บิลพอดี"
    _hdr(ws, 4, ["เดือน", "บิล kWh", "บิล บาท", "Ft", "Demand", "VAT", "บาท/kWh", "มิเตอร์รวม kWh", "ครอบคลุม %",
                 "ตัวปรับ (บิล÷มิเตอร์)", "ยอดผลิตรวม", "kWh/หน่วย", "บาท/หน่วย", f"ยอดขาย ({rc['cfg']['sales_unit']})", "ค่าไฟ % ยอดขาย"],
         st, [10, 14, 16, 12, 12, 12, 10, 16, 11, 14, 14, 11, 11, 16, 12])
    r = 5
    for m in rc["months"]:
        b = m["bill"] or {}
        _put(ws, r, [TH_M[m["i"]], m["bill_kwh"], m["bill_baht"], b.get("ft"), b.get("demand"), b.get("vat"), m["rate"], m["meas"],
                     m["cover"], m["factor"], m["prod"], m.get("kwh_unit"), m.get("baht_unit"), m["sales"], m.get("pct_sales")], st)
        r += 1
    t = rc["totals"]
    _put(ws, r, ["รวม", t["bill_kwh"], t["bill_baht"], None, None, None, t["rate"], t["meas"], None, None, t["prod"],
                 t["kwh_unit"], t["baht_unit"], t["sales"], t["pct_sales"]], st, fill=st["tot"], bold=True)
    for title, key in (("kWh พื้นที่", "kwh"), ("บาท พื้นที่", "baht"), ("kWh มิเตอร์ (ก่อนปรับ)", "meas")):
        w = wb.create_sheet(title)
        _hdr(w, 1, ["หมวด", "พื้นที่", *TH_M, "รวม"], st, [16, 30] + [12] * 13)
        rr = 2
        for row in rc["rows"]:
            vals = row[key]
            _put(w, rr, [GROUPS.get(row["area"]["grp"], row["area"]["grp"]), row["area"]["name"], *vals,
                         round(sum(x for x in vals if x), 2)], st)
            rr += 1
        if key != "meas" and rc["has_unalloc"]:
            vals = rc["unalloc_kwh"] if key == "kwh" else rc["unalloc_baht"]
            _put(w, rr, ["", "ไม่มีพื้นที่รับ (ส่วนต่าง)", *vals, round(sum(x for x in vals if x), 2)], st)
            rr += 1
        col = [None] * 12
        for row in rc["rows"]:
            for i, x in enumerate(row[key]):
                if x is not None:
                    col[i] = (col[i] or 0) + x
        if key != "meas":
            ua = rc["unalloc_kwh"] if key == "kwh" else rc["unalloc_baht"]
            col = [((c or 0) + (u or 0)) if (c is not None or u) else None for c, u in zip(col, ua)]
        _put(w, rr, ["", "รวม", *[round(x, 2) if x is not None else None for x in col],
                     round(sum(x for x in col if x), 2)], st, fill=st["tot"], bold=True)
        w.freeze_panes = "C2"
    w = wb.create_sheet("มิเตอร์รายเดือน")
    _hdr(w, 1, ["Section", "มิเตอร์", "รหัส", "CT ×", *TH_M, "รวม", "ที่มา"], st, [22, 26, 14, 7] + [12] * 13 + [20])
    rr = 2
    for mid, x in meter_months(db, fid, year).items():
        m = x["meter"]
        srcs = sorted({s for s in x["src"] if s})
        _put(w, rr, [m["grp"], m["name"], m["code"], m["multiplier"], *x["kwh"], round(sum(v for v in x["kwh"] if v), 2),
                     ", ".join({"daily": "ประจำวัน", "import": "นำเข้า", "manual": "กรอกเอง"}.get(s, s) for s in srcs)], st)
        rr += 1
    w.freeze_panes = "E2"
    w = wb.create_sheet("สูตรเชื่อมโยง")
    _hdr(w, 1, ["พื้นที่", "หมวด", "ตัวหาร", "เป้า a", "เป้า b", "มิเตอร์", "รหัส", "Section", "ตัวคูณ"], st, [28, 14, 16, 10, 10, 26, 14, 22, 9])
    rr = 2
    for a in rc["areas"]:
        ls = links(db, a["id"]) or [None]
        for l in ls:
            _put(w, rr, [a["name"], GROUPS.get(a["grp"], a["grp"]), DRIVERS.get(a["driver"]) + (f" · {a['item_name']}" if a["item_name"] else ""),
                         a["target_a"], a["target_b"], (l or {}).get("name"), (l or {}).get("code"), (l or {}).get("grp"),
                         (l or {}).get("factor")], st, fmt="0.######")
            rr += 1
    del EN
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def em_xlsx(db, year: int) -> bytes:
    """เอกสาร ③ Energy management — ภาพรวม 3 โรงงาน + ชีตต่อโรงงาน (บิล/ผลิต/ขาย/พื้นที่/kWh-หน่วย/เป้า)"""
    from openpyxl import Workbook
    st = _wb_styles()
    ov = overview(db, year)
    wb = Workbook()
    ws = wb.active
    ws.title = "ภาพรวม"
    ws["A1"] = f"Energy management {year} · ไฟฟ้า"
    ws["A1"].font = st["t"]
    ws["A2"] = f"EF ไฟฟ้า {ov['ef']} kgCO2e/kWh · รวมทั้งปี {ov['g']['bill_kwh']:,.0f} kWh · {ov['g']['bill_baht']:,.0f} บาท · {ov['g']['tco2']:,.2f} tCO2e"
    _hdr(ws, 4, ["โรงงาน", "รายการ", *TH_M, "รวม/เฉลี่ย"], st, [18, 22] + [13] * 13)
    r = 5
    for F in ov["factories"]:
        ms = {m["i"]: m for m in F["rc"]["months"]}
        for lab, key, agg in (("บิล kWh", "bill_kwh", "sum"), ("ค่าไฟ บาท", "bill_baht", "sum"), ("บาท/kWh", "rate", "avg"),
                              ("ยอดผลิตรวม", "prod", "sum"), ("kWh/หน่วย", "kwh_unit", "avg"), ("ยอดขาย", "sales", "sum"),
                              ("ค่าไฟ % ยอดขาย", "pct_sales", "avg")):
            vals = [(ms.get(i) or {}).get(key) for i in range(12)]
            t = F["rc"]["totals"].get(key if key != "bill_baht" else "bill_baht")
            _put(ws, r, [F["factory"]["name"] if lab == "บิล kWh" else "", lab, *vals, t], st)
            r += 1
    for lab, key in (("รวมทุกโรงงาน kWh", "bill_kwh"), ("รวมทุกโรงงาน บาท", "bill_baht"), ("บาท/kWh เฉลี่ย", "rate"),
                     ("ยอดขายรวม", "sales"), ("ค่าไฟ % ยอดขาย", "pct_sales")):
        vals = [x or None for x in ov["tot"][key]]
        _put(ws, r, ["รวม", lab, *vals, ov["g"].get(key)], st, fill=st["tot"], bold=True)
        r += 1
    ws.freeze_panes = "C5"
    for F in ov["factories"]:
        rc = F["rc"]
        w = wb.create_sheet(F["factory"]["name"][:28] or f"F{F['factory']['id']}")
        _hdr(w, 1, ["หมวด", "พื้นที่ / รายการ", "หน่วย", *TH_M, "รวม"], st, [16, 30, 12] + [12] * 13)
        rr = 2
        ms = {m["i"]: m for m in rc["months"]}
        for lab, key, u in (("บิล", "bill_kwh", "kWh"), ("บิล", "bill_baht", "บาท"), ("บิล", "rate", "บาท/kWh")):
            vals = [(ms.get(i) or {}).get(key) for i in range(12)]
            _put(w, rr, [lab, {"bill_kwh": "หน่วยตามบิล", "bill_baht": "ค่าไฟ", "rate": "ราคาเฉลี่ย"}[key], u, *vals,
                         rc["totals"].get(key)], st, fill=st["sub"], bold=True)
            rr += 1
        for it in rc["prod"]["items"]:
            _put(w, rr, ["ผลิต", it["name"], it["unit"], *it["qty"], round(sum(x for x in it["qty"] if x), 2)], st)
            rr += 1
        _put(w, rr, ["ผลิต", "ยอดผลิตรวม", "หน่วย", *rc["prod"]["total"], rc["totals"]["prod"]], st, bold=True)
        rr += 1
        _put(w, rr, ["ผลิต", "วันทำงาน", "วัน", *rc["prod"]["work_days"], None], st)
        rr += 1
        _put(w, rr, ["ขาย", "ยอดขาย", rc["cfg"]["sales_unit"], *rc["prod"]["sales"], rc["totals"]["sales"]], st)
        rr += 1
        for title, key, u in (("kWh (ปรับตามบิล)", "kwh", "kWh"), ("ค่าไฟ", "baht", "บาท"), ("ต่อหน่วย", "per", "kWh/หน่วย"),
                              ("เป้า", "target", "kWh/หน่วย")):
            rr += 1
            w.cell(rr, 1, title).font = st["b"]
            rr += 1
            for row in rc["rows"]:
                vals = row[key]
                if key in ("per", "target") and not any(v is not None for v in vals):
                    continue
                tot = round(sum(v for v in vals if v), 2) if key in ("kwh", "baht") else None
                _put(w, rr, [GROUPS.get(row["area"]["grp"], ""), row["area"]["name"], u, *vals, tot], st,
                     fmt="#,##0.00" if key in ("kwh", "baht") else "0.0000")
                rr += 1
        w.freeze_panes = "D2"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ───────────────────────── นำเข้าไฟล์ Energy management (ย้อนหลัง) ─────────────────────────

MON_RE = {m: i + 1 for i, m in enumerate(("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"))}
BILL_LAB = (("kwh", re.compile(r"^total\s*\(?\s*kwh|^total kwh", re.I)), ("amount", re.compile(r"^ba[th]{2}\b(?!.*/)|^baht\b(?!.*/)|^bath\s*\(", re.I)),
            ("ft", re.compile(r"^ft\b", re.I)), ("demand", re.compile(r"^d[ae]mand", re.I)), ("vat", re.compile(r"^vat", re.I)))
END_RE = re.compile(r"^(electric|summary|project|production|gentani|cost)\b", re.I)
SKIP_RE = re.compile(r"^(sum|total|รวม|price|check|co2|kwh\s*\(unit\))\b|ราคา|/\s*kwh|^ba[th]{2}\b", re.I)
REF_RE = re.compile(r"\$?([A-Z]{1,3})\$?(\d+)(?::\$?([A-Z]{1,3})\$?(\d+))?")


def _labels(row, n=4):
    return [(str(x).strip() if x is not None and not isinstance(x, (int, float)) else (None if x is None else x)) for x in row[:n]]


def _month_cols(rows, year: int) -> dict[int, int]:
    """คอลัมน์ของเดือน 1–12 ในปีที่เลือก — หัวตารางแบบวันที่ หรือชื่อเดือน (JAN…DEC ต่อเนื่องหลายปี)"""
    for r in rows[:8]:
        hit = {}
        for c, v in enumerate(r):
            if hasattr(v, "year") and v.year == year and 1 <= v.month <= 12:
                hit.setdefault(v.month, c)
        if len(hit) >= 1:
            return hit
    for r in rows[:8]:
        seq = [(c, MON_RE.get(str(v).strip().upper()[:3])) for c, v in enumerate(r) if isinstance(v, str) and str(v).strip().upper()[:3] in MON_RE]
        if len(seq) >= 6:
            jans = [i for i, (_, m) in enumerate(seq) if m == 1]
            if not jans:
                return {}
            # ชุดหลัง JAN ตัวสุดท้าย = ปีปัจจุบัน · ย้อนเป็นปีก่อนๆ ตามลำดับ JAN
            k = len(jans) - 1 - max(0, S.now_dt().year - year)
            if k < 0:
                return {}
            end = jans[k + 1] if k + 1 < len(jans) else len(seq)
            return {m: c for c, m in seq[jans[k]:end]}
    return {}


def _refs(formula: str) -> list[int] | None:
    """=SUM(DR60:DR69,DR10:DR29) / =DR8+DR9 → แถวที่อ้างอิง (คอลัมน์เดียวกัน) · มีตัวคูณ/หาร/ชีตอื่น → None"""
    f = formula.lstrip("=").replace(" ", "")
    if "!" in f or re.search(r"[*/]|SUMIF|IF\(", f, re.I):
        return None
    body = re.sub(r"^SUM\((.*)\)$", r"\1", f, flags=re.I)
    if re.search(r"[A-Za-z]{4,}\(", body):
        return None
    out = []
    for a, r1, b, r2 in REF_RE.findall(body):
        r1 = int(r1)
        r2 = int(r2) if r2 else r1
        out.extend(range(min(r1, r2), max(r1, r2) + 1))
    return out


def _roles(rows, first_month_col: int) -> dict:
    """บทบาทคอลัมน์ป้ายชื่อ (ก่อนคอลัมน์เดือน) จากหัวตาราง: section / name / no / loc / tag"""
    ncol = max(1, min(first_month_col, 6))
    for r in rows[:6]:
        hdr = {c: str(v).strip().lower() for c, v in enumerate(r[:ncol]) if isinstance(v, str) and v.strip()}
        got = {}
        for c, t in hdr.items():
            if "section" in t:
                got["sec"] = c
            elif "name" in t or t in ("meter", "mount"):
                got["name"] = c
            elif re.match(r"^no\.?$", t):
                got["no"] = c
            elif "location" in t:
                got["loc"] = c
            elif t == "code":
                got["tag"] = c
        if "name" in got:
            if "sec" not in got and got["name"] > 0:
                got["sec"] = got["name"] - 1
            if "no" not in got and got["name"] + 1 < ncol and got["name"] + 1 not in got.values():
                got["no"] = got["name"] + 1
            return got
    return {"sec": 0, "name": 1, "no": 2, "loc": 3}


def _book(raw: bytes, filename: str) -> list[tuple[str, list[list], list[list]]]:
    """[(ชื่อชีต, ค่า, สูตร)] — .xlsx อ่านทั้งค่าและสูตร · .xls (xlrd) ไม่มีสูตร และแปลงเซลล์วันที่เป็น datetime"""
    if filename.lower().endswith((".xlsx", ".xlsm")):
        from openpyxl import load_workbook
        wf = load_workbook(io.BytesIO(raw), read_only=True)
        wv = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        out = []
        for n in wv.sheetnames:
            v = [list(r) for r in wv[n].iter_rows(max_col=200, values_only=True)]
            f = [list(r) for r in wf[n].iter_rows(max_col=200, values_only=True)]
            out.append((n, v, f + [[]] * (len(v) - len(f))))
        return out
    try:
        import xlrd
    except ImportError:
        from ._vendor import xlrd
    book = xlrd.open_workbook(file_contents=raw)
    out = []
    for sh in book.sheets():
        rows = []
        for r in range(sh.nrows):
            row = []
            for c in range(min(sh.ncols, 200)):
                v = sh.cell_value(r, c)
                t = sh.cell_type(r, c)
                if t == xlrd.XL_CELL_DATE:
                    try:
                        v = xlrd.xldate_as_datetime(v, book.datemode)
                    except Exception:  # noqa: BLE001
                        pass
                elif t in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK) or v == "":
                    v = None
                elif t == xlrd.XL_CELL_ERROR:
                    v = None
                row.append(v)
            rows.append(row)
        out.append((sh.name, rows, rows))
    return out


def _file_idx(filename: str, rows: list[list], name: str) -> int:
    """โรงงาน 1–3 จากชื่อชีต / หัวตาราง (Factory No.2) / ชื่อไฟล์ (ไอชิน 2) — ไม่พบ = 0"""
    for txt in (name, " ".join(str(x) for r in rows[:2] for x in r[:6] if isinstance(x, str)), filename):
        m = re.search(r"(?:aisin|ไอชิน|fac(?:tory)?(?:\s*no\.?)?|โรง(?:งาน)?)\s*(?:no\.?)?\s*(\d)(?!\d)", txt, re.I)
        if m:
            return int(m.group(1))
    return 0


def parse_em(raw: bytes, year: int, filename: str = "x.xlsx") -> dict:
    """ไฟล์เดิมของโรงงาน → บิล · มิเตอร์รายเดือน · พื้นที่ (จากสูตร SUM/SUMIF) · ยอดผลิต
    รองรับ: Energy management (.xlsx, ชีต Aisin1/Aisin 2/Aisin3) · ELECTRICITY cost (.xlsx/.xls: ชีต คำนวน/Electric cost) ของไอชิน 1–3"""
    from openpyxl.utils import column_index_from_string as CI
    try:
        book = _book(raw, filename)
    except Exception as exc:  # noqa: BLE001
        raise S.ValidationError(f"อ่านไฟล์ไม่ได้: {exc}") from None
    sheets = []
    sales_rows = {}

    def num(r, c):
        return r[c] if c < len(r) and isinstance(r[c], (int, float)) and not isinstance(r[c], bool) else None

    cand = {}
    for name, vrows, frows in book:
        if re.match(r"^sale", name.strip(), re.I):
            mc = _month_cols(vrows, year)
            for r in vrows:
                lab = next((str(x).strip().upper() for x in r[:3] if isinstance(x, str) and x.strip()), "")
                m = re.match(r"^FAC\s*(\d)$", lab)
                if m and mc:
                    sales_rows[int(m.group(1))] = {mo: num(r, c) for mo, c in mc.items()}
            continue
        mc = _month_cols(vrows, year)
        if not mc:
            continue
        top = [[x for x in r[:6] if isinstance(x, str)] for r in vrows[:16]]
        has_kwh = any(re.match(r"^total\s*\(?\s*kwh", x, re.I) for r in top for x in r)
        has_amt = any(re.match(r"^ba[th]{2}\b", x, re.I) and "/" not in x for r in top for x in r)
        is_em = bool(re.search(r"aisin\s*\d|fac(tory)?\s*\d|โรง\s*\d", name, re.I))
        if not (is_em or (has_kwh and has_amt)):
            continue
        idx = _file_idx(filename, vrows, name) if is_em else -1
        score = (10 if has_amt else 0) + (2 if re.search(r"คำนว", name) else 0) + (1 if is_em else 0)
        if idx not in cand or score > cand[idx][0]:
            cand[idx] = (score, name, vrows, frows, mc)
    if -1 in cand or 0 in cand:
        # ชีตที่ไม่ได้ระบุโรงงานในชื่อ → ใช้โรงงานจากชื่อไฟล์/หัวตารางของชีตใดก็ได้ในไฟล์เดียวกัน
        fidx = _file_idx(filename, [], "") or next((i for i in (_file_idx(filename, c[2], c[1]) for k, c in cand.items() if k in (-1, 0)) if i), 0)
        for k in (-1, 0):
            if k in cand:
                c = cand.pop(k)
                if fidx not in cand or c[0] > cand[fidx][0]:
                    cand[fidx] = c
    for idx, (_score, name, vrows, frows, mc) in sorted(cand.items()):
        sh = {"sheet": name, "idx": idx, "months": sorted(mc), "bill": {}, "meters": [], "areas": [], "items": [], "work_days": {},
              "skipped_areas": []}
        c0 = mc[min(mc)]
        first_c = 0
        for r in vrows[:8]:
            cs = [c for c, v in enumerate(r) if hasattr(v, "year") or (isinstance(v, str) and v.strip().upper()[:3] in MON_RE)]
            if cs:
                first_c = min(cs)
                break
        ro = {k: v for k, v in _roles(vrows, first_c or 4).items() if not first_c or v < first_c}
        if "name" not in ro:
            ro = {"sec": 0, "name": 1}
        ncol = max(ro.values()) + 1

        def lab_of(r):
            return [(str(x).strip() if isinstance(x, str) else x) for x in (r[:ncol] + [None] * ncol)[:ncol]]

        bill_end = 0
        for ri, r in enumerate(vrows[:15]):
            labs = [x for x in lab_of(r) if isinstance(x, str) and x]
            if any(re.search(r"/\s*kwh", x, re.I) for x in labs):
                bill_end = ri
                continue
            for key, rx in BILL_LAB:
                if any(rx.search(x) for x in labs) and key not in sh["bill"]:
                    sh["bill"][key] = {mo: num(r, c) for mo, c in mc.items()}
                    bill_end = ri
                    break
        # ── มิเตอร์ ──
        sec, name_ff = "", ""
        row_meter: dict[int, int] = {}
        occ: dict[tuple, int] = {}
        end_at = len(vrows)
        for ri in range(bill_end + 1, len(vrows)):
            r, fr = vrows[ri], frows[ri]
            labs = lab_of(r)
            text = [x for x in labs if isinstance(x, str) and x]
            if text and END_RE.search(text[0]):
                end_at = ri
                break
            g = lambda k: labs[ro[k]] if k in ro and ro[k] < len(labs) else None  # noqa: E731
            s_, n_, no_, loc_ = g("sec"), g("name"), g("no"), g("loc")
            if isinstance(s_, str) and s_ and not SKIP_RE.search(s_):
                sec, name_ff = s_, ""
            if isinstance(n_, str) and n_:
                name_ff = n_
            if any(SKIP_RE.search(x) for x in text):
                continue
            vals = {mo: num(r, col) for mo, col in mc.items()}
            if not any(v is not None for v in vals.values()):
                continue
            fs = [fr[col] for col in mc.values() if col < len(fr) and fr[col] is not None]
            if fs and all(isinstance(x, str) and x.startswith("=") for x in fs):
                continue
            nm = n_ if isinstance(n_, str) and n_ else (name_ff if no_ is not None else "")
            if not nm and not no_:
                continue
            sec_ = sec if sec.upper() != str(nm).upper() else ""
            key = meter_key(sec_, nm, no_)
            if any(x["key"] == key for x in sh["meters"]):
                key = f"{key} #{sum(1 for x in sh['meters'] if x['key'].split(' #')[0] == key) + 1}"[:150]
            k2 = (sec_.upper(), str(nm).upper())
            occ[k2] = occ.get(k2, 0) + 1
            row_meter[ri + 1] = len(sh["meters"])
            sh["meters"].append({"row": ri + 1, "key": key, "grp": sec_[:80], "name": str(nm)[:120], "occ": occ[k2],
                                 "code": str(int(no_) if isinstance(no_, float) and no_.is_integer() else (no_ or ""))[:60],
                                 "location": (loc_ if isinstance(loc_, str) else "")[:120],
                                 "tag": (labs[ro["tag"]] if "tag" in ro else None), "vals": vals})
        # ── พื้นที่ (สูตร SUM / SUMIF) · ยอดผลิต ──
        cands = []
        prod_state = 0                          # 0 ยังไม่เจอ · 1 กำลังอ่าน · 2 จบแล้ว
        for ri in range(end_at, len(vrows)):
            r, fr = vrows[ri], frows[ri]
            labs = [x for x in lab_of(r) if isinstance(x, str) and x]
            if not labs:
                continue
            is_p = [i for i, x in enumerate(labs) if re.match(r"^production$", x, re.I)]
            lab = next((x for x in labs if not END_RE.search(x)), labs[-1])
            f0 = fr[c0] if c0 < len(fr) else None
            if is_p and prod_state == 0:
                prod_state = 1
                if lab == labs[is_p[0]] or len(labs) == 1:
                    continue
            if prod_state == 1:
                if re.match(r"^(gentani|cost|production\s+all|lpg|propane|heat\s+lpg)", lab, re.I):
                    prod_state = 2
                elif re.match(r"^work", lab, re.I):
                    sh["work_days"] = {mo: num(r, c) for mo, c in mc.items()}
                    continue
                elif re.match(r"^total$", lab, re.I):
                    if isinstance(f0, str) and f0.startswith("="):
                        sh["total_f"] = f0
                    continue
                elif re.match(r"^day$", lab, re.I):
                    continue
                elif not (isinstance(f0, str) and str(f0).startswith("=")):
                    if any(num(r, c) is not None for c in mc.values()) and len(sh["items"]) < 20:
                        unit = next((x for x in labs if x != lab and len(x) <= 10 and not re.match(r"^production$", x, re.I)), "ชิ้น")
                        sh["items"].append({"name": lab[:60], "unit": unit[:20], "row": ri + 1, "weight": 1.0,
                                            "qty": {mo: num(r, c) for mo, c in mc.items()}})
                    continue
                else:
                    prod_state = 2
            if not isinstance(f0, str) or not f0.startswith("=") or re.search(r"work\s*day|^day$|plan", lab, re.I):
                continue
            body = f0.lstrip("=").replace(" ", "")
            m_si = re.match(r"^SUMIF\(\$?([A-Z]{1,3})\$?(\d+):\$?[A-Z]{1,3}\$?(\d+),\$?([A-Z]{1,3})\$?(\d+),", body, re.I)
            resid = bool(re.match(r"^\$?[A-Z]{1,3}\$?(\d+)-SUM\(", body, re.I))
            if m_si:
                tc, r1, r2, cc, cr = m_si.groups()
                tci, cci = CI(tc.upper()) - 1, CI(cc.upper()) - 1
                crit = vrows[int(cr) - 1][cci] if int(cr) - 1 < len(vrows) and cci < len(vrows[int(cr) - 1]) else None
                rows_ = [x for x in range(int(r1), int(r2) + 1)
                         if x in row_meter and crit is not None and tci < len(vrows[x - 1]) and vrows[x - 1][tci] == crit]
            elif resid:
                rows_ = []
            else:
                refs = _refs(f0)
                if refs is None:
                    sh["skipped_areas"].append(lab[:60])
                    continue
                rows_ = []
                bad = 0
                for x in refs:
                    if x in row_meter:
                        rows_.append(x)
                    else:
                        hit = next((cd for cd in cands if cd["src_row"] == x), None)
                        if hit:
                            rows_.extend(hit["rows"])
                        else:
                            bad += 1
                if not rows_ or bad > len(refs) * 0.4:
                    continue
            nm = re.sub(r"\s+", " ", re.sub(r"[（(]\s*kwh\s*[）)]", "", lab, flags=re.I)).strip(" .　")[:80]
            if not nm or re.match(r"^(kwh|unit|total|energy budget|budget|sum)$", nm, re.I):
                continue
            cands.append({"src_row": ri + 1, "name": nm, "rows": sorted(set(rows_)), "residual": resid, "grp": _guess_grp(nm)})
        if sh.get("total_f") and sh["items"]:
            _weights(sh["items"], sh["total_f"])
        # เลือกชุดพื้นที่ไม่ซ้อนกัน: บล็อกที่มีพื้นที่มากที่สุดก่อน แล้วเติมพื้นที่ที่ไม่ทับ
        blocks, cur, last = [], [], -9
        for cd in cands:
            if cd["src_row"] - last > 3 and cur:
                blocks.append(cur)
                cur = []
            cur.append(cd)
            last = cd["src_row"]
        if cur:
            blocks.append(cur)
        blocks.sort(key=lambda b: -len([x for x in b if x["rows"] or x["residual"]]))
        covered, names, has_resid = set(), set(), False
        for b in blocks:
            for cd in b:
                if cd["name"].upper() in names:
                    continue
                if cd["residual"]:
                    if has_resid:
                        continue
                    has_resid = True
                elif not cd["rows"] or covered & set(cd["rows"]):
                    sh["skipped_areas"].append(cd["name"] + " (ซ้อน)")
                    continue
                covered |= set(cd["rows"])
                names.add(cd["name"].upper())
                sh["areas"].append({"name": cd["name"], "rows": cd["rows"], "residual": cd["residual"], "grp": cd["grp"]})
        sheets.append(sh)
    if not sheets:
        raise S.ValidationError(f"ไม่พบชีตโรงงาน (เช่น Aisin1, Aisin 2) ที่มีข้อมูลปี {year}")
    for sh in sheets:
        sh["sales"] = sales_rows.get(sh["idx"], {})
    return {"year": year, "sheets": sheets}


def _weights(items: list[dict], formula: str) -> None:
    """แถว TOTAL เช่น =DR187+((DR189+DR190)/20) → น้ำหนักรายการ: อ้างตรง = 1 · ในวงเล็บ ÷N = 1/N · ไม่ถูกอ้าง = 0"""
    f = formula.lstrip("=").replace(" ", "").replace("$", "")
    w: dict[int, float] = {}
    for body, n in re.findall(r"\(([^()]*)\)\)?/(\d+(?:\.\d+)?)", f):
        for a, r1, b, r2 in REF_RE.findall(body):
            for x in range(int(r1), int(r2 or r1) + 1):
                w[x] = 1 / float(n)
    rest = re.sub(r"\(([^()]*)\)\)?/(\d+(?:\.\d+)?)", "", f)
    for a, r1, b, r2 in REF_RE.findall(rest):
        for x in range(int(r1), int(r2 or r1) + 1):
            w.setdefault(x, 1.0)
    if not w:
        return
    for it in items:
        it["weight"] = round(w.get(it["row"], 0.0), 6)


def _guess_grp(name: str) -> str:
    n = name.lower()
    if re.search(r"office|canteen|locker|guard|ป้อม|โรงอาหาร|สำนักงาน|gard", n):
        return "OFFICE"
    if re.search(r"compress|utility|light|ligh|tool|inspection|pm\b|lc\b|ro\b|waste|boiler|jetfan|me\b|แสงสว่าง", n):
        return "SUPPORT"
    if re.search(r"^other|อื่น", n):
        return "OTHER"
    return "MFG"


def em_preview(db, parsed: dict, fmap: dict[int, int]) -> list[dict]:
    """สรุปก่อนยืนยัน: ต่อชีต → โรงงานปลายทาง · มิเตอร์ใหม่/ตรงกัน · พื้นที่ · เดือนที่มีบิล"""
    out = []
    for sh in parsed["sheets"]:
        fid = fmap.get(sh["idx"])
        exist = set()
        if fid:
            exist = {r[0] for r in db.execute("SELECT key FROM en_meters WHERE factory_id=? AND kind='elec'", (fid,))}
        n_match = sum(1 for m in sh["meters"] if m["key"] in exist)
        bill_m = [mo for mo in sh["months"] if (sh["bill"].get("kwh") or {}).get(mo)]
        out.append({"sheet": sh["sheet"], "idx": sh["idx"], "fid": fid, "n_meters": len(sh["meters"]), "n_match": n_match,
                    "n_new": len(sh["meters"]) - n_match, "areas": sh["areas"], "skipped_areas": sh["skipped_areas"],
                    "bill_months": bill_m, "items": [i["name"] for i in sh["items"]], "has_sales": any(v for v in sh["sales"].values()),
                    "kwh": [round((sh["bill"].get("kwh") or {}).get(mo) or 0) for mo in range(1, 13)]})
    return out


def em_commit(db, parsed: dict, fmap: dict[int, int], opts: dict, actor) -> dict:
    """นำเข้า: บิล · มิเตอร์ (สร้าง/จับคู่ key) · หน่วยรายเดือน (src=import, ไม่ทับค่า “กรอกเอง”) · พื้นที่+สูตร · ยอดผลิต/ขาย/วันทำงาน"""
    from . import energy as EN
    from . import energy_ops as OPS
    ensure_cost(db)
    year = parsed["year"]
    res = {"bills": 0, "meters_new": 0, "usage": 0, "areas": 0, "links": 0, "items": 0, "prod": 0, "sales": 0}
    now = S.now_dt()
    cur_ym = (now.year, now.month)
    stamp = ts(S.now_dt())
    for sh in parsed["sheets"]:
        fid = fmap.get(sh["idx"])
        if not fid:
            continue
        if opts.get("bills", True):
            for mo in sh["months"]:
                k = (sh["bill"].get("kwh") or {}).get(mo)
                if not k or k <= 0 or (year, mo) > cur_ym:
                    continue
                amt = (sh["bill"].get("amount") or {}).get(mo) or 0
                OPS.save_bill(db, {"factory_id": fid, "month": _ym(year, mo), "kwh": k, "amount": amt,
                                   "ft": (sh["bill"].get("ft") or {}).get(mo) or 0, "demand": (sh["bill"].get("demand") or {}).get(mo) or 0,
                                   "vat": (sh["bill"].get("vat") or {}).get(mo) or round(amt * 0.07, 2), "note": f"นำเข้า {sh['sheet']}"}, actor)
                res["bills"] += 1
        row_mid = {}
        if opts.get("meters", True):
            for i, m in enumerate(sh["meters"]):
                r = db.execute("SELECT id FROM en_meters WHERE factory_id=? AND kind='elec' AND key=?", (fid, m["key"])).fetchone()
                if not r and m["name"]:
                    same = db.execute("""SELECT id FROM en_meters WHERE factory_id=? AND kind='elec' AND UPPER(grp)=? AND UPPER(name)=?
                                         ORDER BY sort_no, id""", (fid, m["grp"].upper(), m["name"].upper())).fetchall()
                    taken = set(row_mid.values())
                    same = [x for x in same if x[0] not in taken]
                    if len(same) >= m.get("occ", 1):
                        r = same[m.get("occ", 1) - 1]
                if r:
                    mid = r[0]
                    res["meters_match"] = res.get("meters_match", 0) + 1
                else:
                    mid, _ = EN.upsert_meter(db, fid, "elec", m["key"], m["code"], m["name"], m["grp"], "kWh", None, (i + 1) * 10)
                    if m["location"]:
                        db.execute("UPDATE en_meters SET location=? WHERE id=?", (m["location"], mid))
                    res["meters_new"] += 1
                row_mid[m["row"]] = mid
                for mo, v in m["vals"].items():
                    if v is None or (year, mo) > cur_ym:
                        continue
                    ym = _ym(year, mo)
                    cur = db.execute("SELECT src FROM en_month_usage WHERE meter_id=? AND month=?", (mid, ym)).fetchone()
                    if cur and cur[0] == "manual":
                        continue
                    db.execute("""INSERT INTO en_month_usage(meter_id, month, kwh, src, note, user_id, updated_at) VALUES (?,?,?,?,?,?,?)
                                  ON CONFLICT(meter_id, month) DO UPDATE SET kwh=excluded.kwh, src='import', note=excluded.note,
                                  user_id=excluded.user_id, updated_at=excluded.updated_at""",
                               (mid, ym, float(v), "import", f"นำเข้า {sh['sheet']}", actor, stamp))
                    res["usage"] += 1
        if opts.get("areas", True) and row_mid:
            for a in sh["areas"]:
                r = db.execute("SELECT id FROM en_areas WHERE factory_id=? AND name=?", (fid, a["name"])).fetchone()
                if r and not opts.get("areas_overwrite"):
                    continue
                aid = r[0] if r else save_area(db, fid, {"name": a["name"], "grp": a["grp"], "driver": "total",
                                                          "is_residual": "1" if a["residual"] else ""}, actor)
                if not r:
                    res["areas"] += 1
                rows = [{"meter_id": row_mid[x], "factor": 1} for x in a["rows"] if x in row_mid]
                if rows or r:
                    res["links"] += save_links(db, aid, rows, actor)
        if opts.get("prod", True):
            for it in sh["items"]:
                r = db.execute("SELECT id FROM en_prod_items WHERE factory_id=? AND name=?", (fid, it["name"])).fetchone()
                iid = r[0] if r else save_item(db, fid, {"name": it["name"], "unit": it["unit"], "weight": it.get("weight", 1)}, actor)
                res["items"] += 0 if r else 1
                for mo, q in it["qty"].items():
                    if q is None:
                        continue
                    db.execute("""INSERT INTO en_prod_qty(item_id, month, qty) VALUES (?,?,?)
                                  ON CONFLICT(item_id, month) DO UPDATE SET qty=excluded.qty""", (iid, _ym(year, mo), float(q)))
                    res["prod"] += 1
            for mo in range(1, 13):
                wd = (sh["work_days"] or {}).get(mo)
                sl = (sh["sales"] or {}).get(mo)
                if wd is None and sl is None:
                    continue
                db.execute("""INSERT INTO en_month_info(factory_id, month, work_days, sales, updated_at) VALUES (?,?,?,?,?)
                              ON CONFLICT(factory_id, month) DO UPDATE SET work_days=COALESCE(excluded.work_days, work_days),
                              sales=COALESCE(excluded.sales, sales), updated_at=excluded.updated_at""",
                           (fid, _ym(year, mo), wd, sl, stamp))
                res["sales"] += 1 if sl is not None else 0
    S.audit(db, actor, "energy_em_import", "en_month_usage", None, after=dict(res, year=year))
    return res
