#!/usr/bin/env python3
"""E-Checksheet — เริ่มระบบ

    python run.py              เปิดระบบ (Waitress, พอร์ตตาม .env ค่าเริ่มต้น 5100)
    python run.py --dev        โหมดพัฒนา (auto-reload)
    python run.py --https      เปิดผ่าน HTTPS (ต้องมี cert.pem / key.pem) — จำเป็นถ้าต้องการใช้งานออฟไลน์เต็มรูปแบบ
    python run.py --demo       ใส่ข้อมูลตัวอย่าง 3 โรงงาน (เฉพาะฐานข้อมูลว่าง) แล้วออก
"""
from __future__ import annotations

import os
import sys

from ecs import create_app

for _stream in (sys.stdout, sys.stderr):      # Windows service / cmd ที่ไม่รองรับภาษาไทย → ไม่ล้ม
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


def main() -> int:
    if "--demo" in sys.argv:
        from tools.seed_demo import seed
        app = create_app({"ENABLE_JOBS": False})
        with app.app_context():
            print(seed(app, force="--force" in sys.argv))
        return 0

    app = create_app()
    cfg = app.config
    use_https, use_dev = "--https" in sys.argv, "--dev" in sys.argv
    port = cfg["HTTPS_PORT"] if use_https else cfg["PORT"]
    print("=" * 60)
    print(f"  {cfg['APP_NAME']}  —  {'https' if use_https else 'http'}://localhost:{port}")
    print(f"  ฐานข้อมูล: {cfg['DATABASE']}")
    print(f"  ไฟล์รูป  : {cfg['UPLOAD_FOLDER']}")
    print("=" * 60)
    if use_https:
        base = os.path.dirname(os.path.abspath(__file__))
        cert, key = os.path.join(base, "cert.pem"), os.path.join(base, "key.pem")
        if not os.path.exists(cert):
            print("ไม่พบ cert.pem / key.pem — ดู README หัวข้อ HTTPS")
            return 1
        app.run(host=cfg["HOST"], port=port, ssl_context=(cert, key), debug=use_dev, threaded=True)
    elif use_dev:
        app.run(host=cfg["HOST"], port=port, debug=True)
    else:
        try:
            from waitress import serve
        except ImportError:
            print("ยังไม่ได้ติดตั้ง waitress:  pip install -r requirements.txt")
            return 1
        serve(app, host=cfg["HOST"], port=port, threads=16, connection_limit=300, channel_timeout=120,
              max_request_body_size=200 * 1024 * 1024)
    return 0


if __name__ == "__main__":
    sys.exit(main())
