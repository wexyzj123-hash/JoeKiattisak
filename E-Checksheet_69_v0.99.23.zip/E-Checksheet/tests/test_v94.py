"""v0.94: หน้าแนวโน้ม — % คุณภาพเครื่องจักร (ผลตรวจหัวข้อที่ควบคุมค่ามาตรฐาน อยู่ในเกณฑ์หรือไม่)"""
import uuid
from datetime import datetime, timedelta

from conftest import login, uid
from ecs import insights as IN
from ecs import services as S
from ecs.services import ts

TODAY = S.now_dt().date()


def _sub(db, form, at, answers, insp):
    sid = db.execute("""INSERT INTO cs_submissions(client_uuid, form_id, form_version_id, equipment_id, inspector_id, finished_at,
                        received_at, duration_sec, status, approval_status) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                     (str(uuid.uuid4()), form["form_id"], form["version_id"], form["equipment_id"], insp, ts(at), ts(at), 60,
                      "submitted", "pending")).lastrowid
    for key, (v, j) in answers.items():
        item = db.execute("SELECT id FROM cs_form_items WHERE version_id=? AND item_key=?", (form["version_id"], key)).fetchone()[0]
        db.execute("INSERT INTO cs_answers(submission_id, item_id, item_key, value_num, judgement) VALUES (?,?,?,?,?)",
                   (sid, item, key, v, j))


def _seed(db, form):
    insp = uid(db, "t_tech")
    vals = [2.0, 2.1, 2.2, 2.45, 2.6, 2.0, 2.1, 2.05, 1.9, 2.0]          # 2.45 เตือน (ยังในเกณฑ์) · 2.6 NG
    for i, v in enumerate(vals):
        j = "ng" if v > 2.5 else ("warn" if v >= 2.4 else "ok")
        at = datetime.combine(TODAY - timedelta(days=9 - i), datetime.min.time()).replace(hour=9)
        _sub(db, form, at, {"oil": (v, j), "noise": (None, "ng" if i == 3 else "ok"), "note": (None, "na")}, insp)
    db.commit()


def test_quality_calc(app, db, published_form):
    _seed(db, published_form)
    q = IN.quality(db, TODAY - timedelta(days=29), TODAY)
    assert q["n_machines"] == 1 and q["n"] == 10
    m = q["machines"][0]
    assert m["n_items"] == 1 and m["ng"] == 1 and m["warn"] == 1 and m["pct"] == 90.0 and m["status"] == "ng"
    it = m["items"][0]
    assert it["item_key"] == "oil" and it["vmax"] == 2.6 and it["cpk"] is not None and it["cpk"] < 1.33
    assert m["worst"]["item_key"] == "oil" and q["below"] == 1 and q["full"] == 0 and q["low_cpk"] == 1
    qa = IN.quality(db, TODAY - timedelta(days=29), TODAY, scope="all")     # รวม OK/NG · ไม่นับ N/A
    ma = qa["machines"][0]
    assert ma["n_items"] == 2 and ma["n"] == 20 and ma["ng"] == 2 and ma["pct"] == 90.0
    assert not IN.quality(db, TODAY - timedelta(days=29), TODAY, factory_id=app.config["F1"] + 999)["machines"]
    assert IN.q_status(98) == "ok" and IN.q_status(96) == "warn" and IN.q_status(None) == "none"


def test_trends_page_quality(app, db, client, published_form):
    _seed(db, published_form)
    login(client, "t_admin")
    # v0.96 หน้าแนวโน้ม: เฉพาะเครื่องที่เลือก · ทุกเครื่องอยู่ที่ /quality
    page = client.get("/trends", query_string={"days": 30, "form": published_form["form_id"]}).get_data(as_text=True)
    assert 'id="quality"' in page and "คุณภาพเครื่องนี้" in page and "90.0%" in page and "Oil Pressure" in page and "ดูทุกเครื่อง" in page
    page = client.get("/quality", query_string={"days": 30, "qscope": "all", "qfac": app.config["F1"]}).get_data(as_text=True)
    assert "% คุณภาพเครื่องจักร" in page and "เสียงผิดปกติ" in page
    r = client.get("/trends/quality.xlsx", query_string={"days": 30})
    assert r.status_code == 200 and r.data[:2] == b"PK"


def test_quality_uses_real_value(app, db, published_form):
    """ค่าตัวเลขเกิน Max แต่ถูกบันทึกเป็น warn (ข้อมูลเก่า/นำเข้า) → นับเป็นนอกเกณฑ์ตามค่าจริง"""
    insp = uid(db, "t_tech")
    for i, (v, j) in enumerate([(2.0, "ok"), (2.9, "warn"), (1.5, "ok")]):
        _sub(db, published_form, datetime.combine(TODAY - timedelta(days=i), datetime.min.time()).replace(hour=9), {"oil": (v, j)}, insp)
    db.commit()
    m = IN.quality(db, TODAY - timedelta(days=6), TODAY)["machines"][0]
    assert m["ng"] == 2 and m["ok"] == 1
