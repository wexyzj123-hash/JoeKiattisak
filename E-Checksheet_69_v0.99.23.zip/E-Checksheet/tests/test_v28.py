"""v0.28: คำขอแก้ไขแบบฟอร์มจากหน้างาน · ประเภทหัวข้อที่เพิ่มเอง"""
from conftest import login, uid

from ecs import change_requests as CR


def test_change_request_flow(app, db, published_form):
    fid = published_form["form_id"]
    ct = app.test_client()
    tt = login(ct, "t_tech")
    assert "data-chreq" in open(app.root_path + "/static/m/fill.js", encoding="utf-8").read()
    r = ct.post("/api/m/change-requests", json={"form_id": fid, "item_key": "oil", "kind": "criteria",
                                                "detail": "เกณฑ์หน้างานจริง 1.5–2.8 bar", "proposed": "1.5–2.8"},
                headers={"X-CSRF-Token": tt})
    assert r.status_code == 200
    cid = r.get_json()["id"]
    c = CR.get(db, cid)
    assert c["item_name"] == "Oil Pressure" and c["status"] == "open"
    assert ct.post("/api/m/change-requests", json={"form_id": fid, "detail": "x"}, headers={"X-CSRF-Token": tt}).status_code == 400
    # หัวหน้างานได้รับแจ้งในกระดิ่ง + เห็นในรายการ / Builder / หน้าแบบฟอร์ม
    sup = uid(db, "t_sup")
    assert db.execute("SELECT COUNT(*) FROM cs_notifications WHERE user_id=? AND kind='change_request'", (sup,)).fetchone()[0] == 1
    cs = app.test_client()
    ts = login(cs, "t_sup")
    assert "เกณฑ์หน้างานจริง" in cs.get("/forms/change-requests").get_data(as_text=True)
    b = cs.get(f"/forms/{fid}/builder").get_data(as_text=True)
    assert "คำขอแก้ไขจากหน้างาน 1 รายการ" in b
    assert "มีคำขอแก้ไขจากหน้างาน 1 รายการ" in cs.get(f"/forms/{fid}").get_data(as_text=True)
    # ไม่แก้ต้องมีเหตุผล · แก้แล้ว → แจ้งกลับผู้ขอ
    cs.post(f"/forms/change-requests/{cid}", data={"csrf_token": ts, "status": "rejected", "reply": ""})
    assert CR.get(db, cid)["status"] == "open"
    cs.post(f"/forms/change-requests/{cid}", data={"csrf_token": ts, "status": "done", "reply": "แก้เกณฑ์เป็น 1.5–2.8 แล้ว (v2)"})
    assert CR.get(db, cid)["status"] == "done"
    tech = uid(db, "t_tech")
    assert db.execute("SELECT COUNT(*) FROM cs_notifications WHERE user_id=? AND kind='change_request'", (tech,)).fetchone()[0] == 1
    assert "แก้เกณฑ์เป็น 1.5–2.8" in ct.get("/m/requests").get_data(as_text=True)
    assert ct.get("/forms/change-requests").status_code in (302, 403)


def test_item_presets(app, db, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_sup")
    r = c.post("/api/item-presets", json={"name": "สถานะระบบ", "item_type": "choice",
                                          "options": [{"label": "ปกติ"}, {"label": "ผิดปกติ", "ng": 1}, {"label": "หยุดระบบชั่วคราว"}]},
               headers={"X-CSRF-Token": tok})
    assert r.status_code == 200 and r.get_json()["presets"][0]["options"][1]["ng"] == 1
    assert c.post("/api/item-presets", json={"name": "สถานะระบบ", "item_type": "choice", "options": [{"label": "a"}, {"label": "b"}]},
                  headers={"X-CSRF-Token": tok}).status_code == 400                    # ชื่อซ้ำ
    assert c.post("/api/item-presets", json={"name": "x", "item_type": "choice", "options": [{"label": "a"}]},
                  headers={"X-CSRF-Token": tok}).status_code == 400                    # ตัวเลือก < 2
    c.post("/forms/item-types", data={"csrf_token": tok, "name": "ค่า pH", "item_type": "number", "unit": "pH",
                                      "min_value": "6.5", "max_value": "8.5"})
    ps = {p["name"]: p for p in CR.presets(db)}
    assert ps["ค่า pH"]["min_value"] == 6.5 and ps["ค่า pH"]["unit"] == "pH"
    b = c.get(f"/forms/{fid}/builder").get_data(as_text=True)
    import json
    assert json.dumps("สถานะระบบ")[1:-1] in b and json.dumps("หยุดระบบชั่วคราว")[1:-1] in b
    c.post("/forms/item-types", data={"csrf_token": tok, "delete": str(ps["ค่า pH"]["id"])})
    assert "ค่า pH" not in {p["name"] for p in CR.presets(db)}
