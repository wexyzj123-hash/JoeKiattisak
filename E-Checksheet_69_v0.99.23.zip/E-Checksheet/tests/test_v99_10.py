"""v0.99.10: ปุ่มส่งแบบเครื่องบินกระดาษ + ใบรับผลตรวจ — ช่างรู้ว่าผลตรวจถึงระบบแล้วจริง (ยืนยันซ้ำจากฐานข้อมูล)"""
import json
import uuid
from pathlib import Path

from conftest import GOOD, login, payload

ROOT = Path(__file__).resolve().parents[1] / "ecs"


def _post(client, tok, p):
    return client.post("/api/m/submissions", headers={"X-CSRF-Token": tok},
                       data={"payload": json.dumps(p)}, content_type="multipart/form-data")


def test_submit_returns_server_received_time_and_receipt_confirms(client, db, published_form):
    tok = login(client, "t_tech")
    p = payload(published_form, GOOD)
    body = _post(client, tok, p).get_json()
    assert body["received_at"] and body["id"]
    r = client.get(f"/api/m/receipt/{p['client_uuid']}")
    assert r.status_code == 200 and r.headers["Cache-Control"] == "no-store"
    d = r.get_json()
    assert d["found"] and d["id"] == body["id"] and d["received_at"] == body["received_at"]
    assert d["answers"] == db.execute("SELECT COUNT(*) FROM cs_answers WHERE submission_id=?", (body["id"],)).fetchone()[0] > 0
    dup = _post(client, tok, p).get_json()                       # ส่งซ้ำ → ใบรับเดิม (เวลารับเดิม)
    assert dup["duplicate"] and dup["id"] == body["id"] and dup["received_at"] == body["received_at"]


def test_receipt_not_found_for_unsent_or_other_users(client, app, db, published_form):
    tok = login(client, "t_tech")
    p = payload(published_form, GOOD)
    assert client.get(f"/api/m/receipt/{uuid.uuid4()}").status_code == 404       # ยังไม่ถึงระบบ
    assert client.get("/api/m/receipt/not-a-uuid").get_json() == {"found": False}
    _post(client, tok, p)
    other = app.test_client()
    login(other, "t_tech2")
    assert other.get(f"/api/m/receipt/{p['client_uuid']}").status_code == 404   # ของคนอื่น ไม่เปิดเผย
    anon = app.test_client()
    assert anon.get(f"/api/m/receipt/{p['client_uuid']}").status_code in (302, 401)


def test_fill_page_loads_send_button_assets(client):
    login(client, "t_tech")
    html = client.get("/m/fill").get_data(as_text=True)
    assert "m/sendfx.js" in html and html.index("m/sendfx.js") < html.index("m/fill.js")
    js = (ROOT / "static/m/fill.js").read_text(encoding="utf-8")
    assert "SendFx.launch" in js and "verifyReceipt" in js and "watchQueued" in js
    css = (ROOT / "static/css/m.css").read_text(encoding="utf-8")
    assert "cubic-bezier(.30,.10,.00,.90)" in css and "cubic-bezier(.698,.187,.322,.847)" in css
    assert "prefers-reduced-motion" in css
