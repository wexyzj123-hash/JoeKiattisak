"""v0.82: ฟอร์มของช่างเติมค่าจาก SCADA ของเวลารอบนั้น (รวมลงข้อมูลย้อนหลัง) · ส่งแล้วรวมกับรายการอัตโนมัติเป็นรายการเดียว"""
import sqlite3
from datetime import datetime, time, timedelta

from conftest import GOOD, payload, uid

from ecs import connectors as CN
from ecs import services as S
from ecs import submissions as SUB
from ecs.services import ts


def _setup(db, form, path, days=3):
    fid = form["form_id"]
    S.create_schedule(db, fid, {"freq_type": "shift", "times": "08:30,20:30", "window_min": 240}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (ts(S.now_dt() - timedelta(days=days)),))
    S.generate_rounds(db)
    today = S.now_dt().date()
    rows = []
    for d in range(days, 0, -1):
        day = today - timedelta(days=d)
        for m in range(0, 24 * 60, 10):
            rows.append(("OIL", ts(datetime.combine(day, time(m // 60, m % 60))), 2.2))
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    con.executemany("INSERT INTO h VALUES (?,?,?)", rows)
    con.commit()
    con.close()
    sid = CN.save_source(db, {"name": "SCADA", "kind": "sqlite", "bucket_min": 60, "agg": "last", "prefill": "1",
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                         "backfill_days": days + 1}}, None)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil"}], None)
    db.commit()
    CN.run_source(db, sid)
    db.commit()
    return sid


def _round(db, fid, t):
    return dict(db.execute("SELECT * FROM cs_rounds WHERE form_id=? AND due_at=?", (fid, ts(t))).fetchone())


def test_backfill_package_has_slot_values_and_submit_merges(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    sid = _setup(db, published_form, str(tmp_path / "h.db"))
    day = S.now_dt().date() - timedelta(days=1)
    t = datetime.combine(day, time(8, 30))
    auto = db.execute("SELECT COUNT(*) FROM cs_submissions WHERE source='auto' AND finished_at=?", (ts(t),)).fetchone()[0]
    assert auto == 1                                                  # ระบบลงค่า SCADA ของรอบนั้นไว้แล้ว
    rnd = _round(db, fid, t)
    assert rnd["submission_id"] is None                               # ฟอร์มผสม: ยังรอช่างกรอกหัวข้ออื่น (ลงย้อนหลังได้)
    pkg = SUB.form_package(db, fid, rnd["id"])
    assert pkg["scada_slot"] == rnd["due_at"] and pkg["scada"]["oil"]["value"] == 2.2 and pkg["scada"]["oil"]["auto"]
    live = SUB.form_package(db, fid, None)
    assert "scada" in live                                            # ฟอร์มรอบปัจจุบันยังเปิดได้
    admin = uid(db, "t_admin")
    ans = dict(GOOD, oil={"value": "2.0", "src": ""})                 # ช่างแก้ค่าจาก SCADA
    res = SUB.create_submission(db, payload(published_form, ans, round_id=rnd["id"], finished_at=ts(t + timedelta(minutes=20)),
                                            scanned_at=ts(t)), {}, admin, app.config["UPLOAD_FOLDER"])
    db.commit()
    subs = db.execute("SELECT id, source FROM cs_submissions WHERE form_id=? AND (finished_at=? OR id=?)", (fid, ts(t), res["id"])).fetchall()
    assert [r["id"] for r in subs] == [res["id"]] and subs[0]["source"] != "auto"   # รายการอัตโนมัติถูกรวมแล้ว ไม่ซ้ำ
    assert db.execute("SELECT value_num FROM cs_answers WHERE submission_id=? AND item_key='oil'", (res["id"],)).fetchone()[0] == 2.0
    from ecs import srcmap as SM
    assert SM.fill_slots(db, CN.get_source(db, sid)) == 0             # ไม่สร้างรายการอัตโนมัติซ้ำหลังรวม


def test_slot_prefill_from_raw_when_no_auto(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    _setup(db, published_form, str(tmp_path / "h.db"))
    t = datetime.combine(S.now_dt().date() - timedelta(days=1), time(20, 30))
    db.execute("DELETE FROM cs_answers WHERE submission_id IN (SELECT id FROM cs_submissions WHERE source='auto' AND finished_at=?)", (ts(t),))
    db.execute("DELETE FROM cs_submissions WHERE source='auto' AND finished_at=?", (ts(t),))
    from ecs import srcmap as SM
    v = SM.prefill_slot(db, fid, t)
    assert v["oil"]["value"] == 2.2 and v["oil"]["auto"] is False and v["oil"]["at"] == t.strftime("%Y-%m-%d %H:%M")


def test_backfill_needs_no_point_scan(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    _setup(db, published_form, str(tmp_path / "h.db"))
    db.execute("UPDATE cs_forms SET require_point_scan=1 WHERE id=?", (fid,))
    db.commit()
    t = datetime.combine(S.now_dt().date() - timedelta(days=1), time(8, 30))
    rnd = _round(db, fid, t)
    admin = uid(db, "t_admin")
    now = S.now_dt()
    res = SUB.create_submission(db, payload(published_form, GOOD, round_id=rnd["id"], finished_at=ts(now), scanned_at=ts(now)),
                                {}, admin, app.config["UPLOAD_FOLDER"])
    db.commit()
    assert res["id"] and db.execute("SELECT COUNT(*) FROM cs_submissions WHERE source='auto' AND finished_at=?", (ts(t),)).fetchone()[0] == 0
    cur = [r for r in db.execute("SELECT * FROM cs_rounds WHERE form_id=? AND due_at>? ORDER BY due_at", (fid, ts(now)))][0]
    try:                                                              # รอบปัจจุบันยังต้องสแกนตามเดิม
        SUB.create_submission(db, payload(published_form, GOOD, round_id=cur["id"]), {}, admin, app.config["UPLOAD_FOLDER"])
        assert False, "ต้องสแกน QR"
    except S.ValidationError as exc:
        assert any("สแกน QR" in e for e in exc.errors)
