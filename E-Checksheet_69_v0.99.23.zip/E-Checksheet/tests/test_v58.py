"""v0.58: กรอกวันหยุดเครื่องย้อนหลัง · เดินเครื่องย้อนหลัง · หน้าตัวเลือกลงข้อมูลย้อนหลัง"""
from datetime import datetime, timedelta

import pytest
from conftest import login, uid

from ecs import anomaly as A
from ecs import backfill as BF
from ecs import downtime as DT
from ecs import services as S


def _sched(db, fid):
    sid = S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00"}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    return sid


def _round(db, sid, fid, due, hours=2, status="missed"):
    return db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                         VALUES (?,?,?,?,?,?,?)""", (sid, fid, S.ts(due), S.ts(due + timedelta(hours=hours)),
                                                     S.ts(due + timedelta(hours=hours * 2)), status, S.ts(due))).lastrowid


def test_record_past_downtime_period(app, client, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    sid = _sched(db, fid)
    base = datetime.combine(S.now_dt().date() - timedelta(days=3), datetime.min.time())
    inside = _round(db, sid, fid, base + timedelta(hours=9))                  # ปิด 13:00 → อยู่ในช่วงหยุด
    after = _round(db, sid, fid, base + timedelta(days=1, hours=9))           # หลังเดินเครื่อง
    A.raise_alert(db, alert_type="missed", form=S.get_form(db, fid), severity="warning", round_id=inside, title="ขาด", detail="x")
    db.commit()
    tok = login(client, "t_sup")
    r = client.post(f"/equipment/{eq}/down", data={"csrf_token": tok, "category": "pm", "reason": "PM ประจำปี",
                    "start_at": (base + timedelta(hours=8)).strftime("%Y-%m-%dT%H:%M"),
                    "end_at": (base + timedelta(hours=17)).strftime("%Y-%m-%dT%H:%M")})
    assert r.status_code == 302
    st = {x[0]: x[1] for x in db.execute("SELECT id, status FROM cs_rounds WHERE form_id=?", (fid,))}
    assert st[inside] == "skipped" and st[after] == "missed"
    assert db.execute("SELECT status FROM cs_alerts WHERE round_id=?", (inside,)).fetchone()[0] == "closed"
    d = db.execute("SELECT end_at, started_by, end_note FROM cs_downtime WHERE equipment_id=?", (eq,)).fetchone()
    assert d["end_at"] == S.ts(base + timedelta(hours=17)) and d["started_by"] == uid(db, "t_sup") and "บันทึกย้อนหลัง" in d["end_note"]
    assert db.execute("SELECT run_status FROM equipment WHERE id=?", (eq,)).fetchone()[0] == "running"
    # อนาคต / เกิน 62 วัน → ไม่ได้
    with pytest.raises(S.ValidationError):
        DT.record_down(db, eq, uid(db, "t_sup"), "x", "pm", S.now_dt() + timedelta(hours=1))
    with pytest.raises(S.ValidationError):
        DT.record_down(db, eq, uid(db, "t_sup"), "x", "pm", S.now_dt() - timedelta(days=70), S.now_dt() - timedelta(days=69))
    assert "กรอกวันหยุดเครื่องย้อนหลัง" in client.get(f"/equipment/{eq}").get_data(as_text=True)


def test_backdated_running(app, client, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    sid = _sched(db, fid)
    now = S.now_dt().replace(second=0, microsecond=0)
    DT.record_down(db, eq, uid(db, "t_sup"), "ซ่อม", "repair", now - timedelta(hours=30))      # ยังหยุดอยู่
    rr = _round(db, sid, fid, now - timedelta(hours=10), status="pending")                    # ปิด 6 ชม.ก่อน (เดินแล้วแต่ไม่มีคนตรวจ)
    db.execute("UPDATE cs_rounds SET status='skipped' WHERE id=?", (rr,))
    db.commit()
    assert db.execute("SELECT run_status FROM equipment WHERE id=?", (eq,)).fetchone()[0] == "down"
    with pytest.raises(S.ValidationError):
        DT.set_running_at(db, eq, uid(db, "t_sup"), now - timedelta(hours=40))                # ก่อนเวลาหยุด
    tok = login(client, "t_sup")
    client.post(f"/equipment/{eq}/running", data={"csrf_token": tok, "at": (now - timedelta(hours=12)).strftime("%Y-%m-%dT%H:%M")})
    d = db.execute("SELECT end_at FROM cs_downtime WHERE equipment_id=?", (eq,)).fetchone()[0]
    assert d == S.ts(now - timedelta(hours=12))
    r = db.execute("SELECT status, updated_at FROM cs_rounds WHERE id=?", (rr,)).fetchone()
    assert r["status"] == "missed" and r["updated_at"] == S.ts(now - timedelta(hours=12))     # ไม่เตือนย้อนหลัง


def test_backfill_pick_page(app, client, db, published_form):
    fid = published_form["form_id"]
    sid = _sched(db, fid)
    day = S.now_dt().date() - timedelta(days=2)
    rid = _round(db, sid, fid, datetime.combine(day, datetime.min.time()) + timedelta(hours=8))
    db.commit()
    tech = uid(db, "t_tech")
    d = BF.missing_rounds(db, tech, day - timedelta(days=1), day)
    assert d["total"] == 1 and d["allowed"] == 0 and d["days"][0]["rows"][0]["id"] == rid
    login(client, "t_tech")
    html = client.get(f"/backfill/pick?from={day}&to={day}").get_data(as_text=True)
    assert "ลงข้อมูลย้อนหลัง" in html and "ไม่มีสิทธิ์" in html
    BF.grant(db, [tech], [day.isoformat()], 0, "", uid(db, "t_admin"))
    db.commit()
    html = client.get(f"/backfill/pick?from={day}&to={day}").get_data(as_text=True)
    assert f"#f={fid}&amp;r={rid}" in html or f"#f={fid}&r={rid}" in html
    assert BF.missing_rounds(db, tech, day, day, only_allowed=True)["allowed"] == 1
    assert BF.missing_rounds(db, uid(db, "t_admin"), day, day)["allowed"] == 1
    assert "ลงข้อมูลย้อนหลัง" in client.get("/m/").get_data(as_text=True)
