"""v0.92: Dashboard — ตัวเลขไม่หลอกตา (ข้อมูลไม่ครบ · ค่าผิดปกติ · ความสดของข้อมูล · ที่มาอัตรา) · ใช้ทุกวัน · การ์ดกดได้ · สรุปผู้บริหาร"""
from datetime import date, timedelta

from conftest import login
from ecs import energy as EN
from ecs import energy_dash as DASH
from ecs import energy_manage as MG

ACTUAL_DAY = True
SPLIT_GAP = True
M0 = date(2026, 9, 1)
TODAY = date(2026, 9, 21)


def _mk(db, fid, code, grp="A", kind="elec"):
    return EN.save_meter(db, None, {"factory_id": fid, "kind": kind, "code": code, "name": f"M {code}", "grp": grp, "multiplier": "1"}, None)


def _feed(db, mid, per, days=20, skip_last=0, spike_day=None):
    v = 0.0
    for i in range(days + 1 - skip_last):
        d = M0 + timedelta(days=i)
        EN.set_reading(db, mid, d.isoformat(), v, None, src="t")
        v += per * (50 if d == spike_day else 1)


def test_clean_and_partial(app, db):
    f1 = app.config["F1"]
    days = [(M0 + timedelta(days=i)).isoformat() for i in range(10)]
    daily, bad = DASH._clean([100, 110, 90, 105, 5000, 95, 100, -3, 98, 102], days)
    assert daily[4] is None and daily[7] is None and [b["day"] for b in bad] == [days[4], days[7]]
    a, b, c = _mk(db, f1, "A"), _mk(db, f1, "B"), _mk(db, f1, "C")
    _feed(db, a, 100)
    _feed(db, b, 100)
    _feed(db, c, 100, skip_last=3)                      # C ขาดจด 3 วันล่าสุด
    db.commit()
    cc = DASH.control(db, M0, f1, today=TODAY)
    e = cc["kp"]["elec"]
    assert e["partial"] and e["chg"] is None and e["cov"][1] == 3
    assert cc["money"]["partial"] and cc["money"]["chg"] is None


def test_freshness_rate_exec(app, db):
    f1 = app.config["F1"]
    a = _mk(db, f1, "A")
    _feed(db, a, 100, days=25)
    EN.set_reading(db, a, "2026-12-31", 99999, None, src="t")     # วันที่อนาคต (ไฟล์ผิด)
    db.commit()
    fr = DASH.freshness(db, [f1], today=date(2026, 9, 26))
    assert fr[0]["last"] == "2026-09-26" and fr[0]["future"] == 1 and fr[0]["status"] == "ok"
    rs = DASH.rate_source(db, [f1], M0)
    assert rs["estimate"] and "ประมาณ" in rs["items"][0]["src"]
    db.execute("INSERT INTO en_bills(factory_id, month, kwh, amount, ft, demand, vat, updated_at) VALUES (?,?,?,?,?,?,?,?)",
               (f1, "2026-09", 1000, 4000, 0, 0, 280, "x"))
    rs = DASH.rate_source(db, [f1], M0)
    assert not rs["estimate"] and rs["items"][0]["rate"] == 4.28
    # คาดการณ์สิ้นเดือน · เป้าตั้งเอง 90/วัน → 2,700/เดือน
    from ecs import energy_summary as SMY
    SMY.save_target(db, "elec", f1, "factory", str(f1), "90", "", None)
    cc = DASH.control(db, M0, f1, today=date(2026, 9, 21))
    U = MG.build(db, M0, f1, today=date(2026, 9, 21))
    ex = DASH.executive(db, M0, [f1], cc["kp"], U, today=date(2026, 9, 21))
    g = ex["goals"][0]
    assert g["target"] == 2700 and g["current"] and g["forecast"] == 3000 and g["pct"] > 100


def test_exec_top_increase(app, db):
    f1 = app.config["F1"]
    a, b = _mk(db, f1, "A", "Press"), _mk(db, f1, "B", "Paint")
    for mid, prev, cur in ((a, 100, 150), (b, 100, 90)):
        v = 0.0
        d = date(2026, 8, 1)
        while d <= date(2026, 9, 21):
            EN.set_reading(db, mid, d.isoformat(), v, None, src="t")
            v += prev if d < M0 else cur
            d += timedelta(days=1)
    db.commit()
    cc = DASH.control(db, M0, f1, today=date(2026, 9, 21))
    U = MG.build(db, M0, f1, today=date(2026, 9, 21))
    ex = DASH.executive(db, M0, [f1], cc["kp"], U, today=date(2026, 9, 21))
    assert [u["name"] for u in ex["ups"]] == ["Press"] and ex["ups"][0]["pct"] == 50.0


def test_dashboard_page_filters_tv(app, db, client):
    f1 = app.config["F1"]
    a = _mk(db, f1, "A")
    w = _mk(db, f1, "W", kind="water")
    _feed(db, a, 100)
    _feed(db, w, 5)
    db.commit()
    login(client, "t_admin")
    page = client.get("/energy/", query_string={"factory": f1, "month": "2026-09"}).get_data(as_text=True)
    assert 'href="#units-water"' in page and "/energy/power" in page and "พิมพ์ / PDF" in page and "โหมดจอทีวี" in page
    assert "สรุปผู้บริหาร" in page and "cr-fresh" in page
    r = client.get("/energy/")                                     # จำตัวกรองล่าสุด
    assert r.status_code == 302 and f"factory={f1}" in r.headers["Location"]
    client.get("/energy/", query_string={"factory": "", "month": "2026-09"})
    assert client.get("/energy/").status_code == 200              # เลือกทุกโรงงาน → ไม่มีตัวกรองค้าง
    tv = client.get("/energy/", query_string={"tv": "1", "month": "2026-09"}).get_data(as_text=True)
    assert "cr-tv" in tv and "ออกจากโหมดทีวี" in tv and f"factory={f1}" in tv   # วนไปโรงงานถัดไป
    assert client.get("/energy/").status_code == 200              # โหมดทีวีไม่เปลี่ยนตัวกรองที่จำไว้


def test_sheet_dial_view_actual_day(app, db, client):
    """v0.92.1 ตาราง › เลขหน้าปัด: วันที่ไม่มีค่าอ่าน (เฉลี่ยจากช่วงขาด / วันสุดท้ายนับตามวันที่ใช้จริง) ไม่ทำหน้าเด้ง"""
    f1 = app.config["F1"]
    a = _mk(db, f1, "A")
    for d, v in (("2026-08-01", 0), ("2026-08-05", 400), ("2026-08-06", 500)):   # 2–4 ขาดค่าอ่าน → เฉลี่ย
        EN.set_reading(db, a, d, v, None, src="t")
    db.commit()
    sh = EN.month_sheet(db, f1, "elec", date(2026, 8, 1))
    cells = {r["day"]: r["cells"][0] for r in sh["grid"]}
    assert cells["2026-08-02"]["v"] is None and cells["2026-08-02"]["u"] == 100
    assert cells["2026-08-06"]["v"] == 500 and cells["2026-08-06"]["u"] is None
    login(client, "t_admin")
    for view in ("v", "u"):
        assert client.get("/energy/sheet", query_string={"factory": f1, "kind": "elec", "month": "2026-08", "view": view}).status_code == 200
    assert client.get("/energy/sheet.xlsx", query_string={"factory": f1, "kind": "elec", "month": "2026-08"}).status_code == 200


def test_dashboard_unknown_loc_not_sticky(app, db, client):
    """v0.92.2 /energy/?loc=ไม่ระบุ: ไม่ค้าง “ไม่มีข้อมูล” · โรงงานยังเลือกได้ · มีปุ่มล้างตัวกรอง · มิเตอร์ไม่มี Section ดูได้ด้วย loc=-"""
    f1 = app.config["F1"]
    a = _mk(db, f1, "A", "")
    _feed(db, a, 100)
    db.commit()
    login(client, "t_admin")
    page = client.get("/energy/", query_string={"loc": "ไม่ระบุ", "month": "2026-09"}).get_data(as_text=True)
    assert "cr-kpis" in page                                       # ไม่ระบุ → มิเตอร์ที่ไม่มี Section
    page = client.get("/energy/", query_string={"loc": "ไม่มีพื้นที่นี้", "month": "2026-09", "factory": f1}).get_data(as_text=True)
    assert "ล้างตัวกรอง" in page and "Factory" in page
    r = client.get("/energy/")
    assert r.status_code == 302 and "loc=" not in r.headers["Location"]
