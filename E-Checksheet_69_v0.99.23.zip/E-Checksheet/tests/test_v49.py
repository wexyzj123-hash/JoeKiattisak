"""v0.49: ตรวจทานก่อนส่ง + ดักค่าที่น่าจะพิมพ์ผิด · โหมด "งานตอนนี้" + งานถัดไป · ยืนยันค่า SCADA ตรงกับหน้าปัด"""
from conftest import login


def test_fill_js_review_and_suspect(app):
    c = app.test_client()
    login(c, "t_tech")
    js = c.get("/static/m/fill.js").get_data(as_text=True)
    for s in ("function suspect", "reviewSheet", "ตรวจทานก่อนส่ง", "data-fixval", "data-okval", "อาจพิมพ์จุดทศนิยมผิด",
              "data-scadaok", "ตรงกับหน้าปัด", "ดูหน้าปัดแล้วกด", "doSubmit"):
        assert s in js, s


def test_home_js_now_mode(app):
    c = app.test_client()
    login(c, "t_tech")
    js = c.get("/static/m/home.js").get_data(as_text=True)
    for s in ("nextBar", "งานถัดไป", "งานตอนนี้", "data-mode", "mmode", "แสดงทั้งหมด"):
        assert s in js, s
    css = c.get("/static/css/m.css").get_data(as_text=True)
    assert ".m-next" in css and ".m-rv-tiles" in css and ".m-susp" in css
