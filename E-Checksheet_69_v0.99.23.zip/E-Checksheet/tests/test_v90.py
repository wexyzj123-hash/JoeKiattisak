"""v0.90: กติกานับยอดเดียวทั้งระบบ · มิเตอร์แม่ · ทะเบียนมาตรฐาน · บริหารพลังงาน · ต้นทุนจากค่าจดดิบ"""
from datetime import date, timedelta

import pytest

from ecs import energy as EN
from ecs import energy_cost as C
from ecs import energy_manage as MG
from ecs import energy_register as ER
from ecs import services as S

ACTUAL_DAY = True
SPLIT_GAP = True
D0 = date(2026, 9, 1)


def _mk(db, fid, code, grp="", role=0, kind="elec", line="", parent=None):
    mid = EN.save_meter(db, None, {"factory_id": fid, "kind": kind, "code": code, "name": f"M {code}", "grp": grp, "line": line,
                                   "is_main": str(role), "multiplier": "1", **({"parent_id": str(parent)} if parent else {})}, None)
    return mid


def _feed(db, mid, per_day, days=20, start=1000.0):
    v = start
    for i in range(days + 1):
        EN.set_reading(db, mid, (D0 + timedelta(days=i)).isoformat(), v, None, src="t")
        v += per_day


def _plant(db, fid):
    inc = _mk(db, fid, "INC", "", 1)                     # มิเตอร์หลักรวม (ไม่ระบุ Section)
    sa = _mk(db, fid, "SA", "A", 1)                      # หลักของ Section A
    a1, a2 = _mk(db, fid, "A1", "A", line="L1"), _mk(db, fid, "A2", "A", line="L2")
    b1, b2 = _mk(db, fid, "B1", "B", line="L1"), _mk(db, fid, "B2", "B", line="L1")   # Section B ไม่มีหลัก
    x = _mk(db, fid, "X", "B", 2)                        # ไม่นับรวม
    sol = _mk(db, fid, "SOL", "", -1)                    # หักออก
    for mid, u in ((inc, 1000), (sa, 600), (a1, 300), (a2, 250), (b1, 200), (b2, 150), (x, 999), (sol, 50)):
        _feed(db, mid, u)
    db.commit()
    return dict(inc=inc, sa=sa, a1=a1, a2=a2, b1=b1, b2=b2, x=x, sol=sol)


def test_counted_rules(app, db):
    f1 = app.config["F1"]
    ids = _plant(db, f1)
    ms = EN.meters(db, f1, "elec")
    cv = EN.covers(ms)
    assert cv[ids["a1"]] == {ids["sa"]} and cv[ids["sa"]] == {ids["inc"]} and cv[ids["b1"]] == {ids["inc"]} and not cv[ids["sol"]]
    assert {m["id"] for m in EN.counted(ms)} == {ids["inc"], ids["sol"]}               # ทั้งโรงงาน = หลักรวม − Solar
    sec_a = [m for m in ms if m["grp"] == "A"]
    assert {m["id"] for m in EN.counted(sec_a)} == {ids["sa"]}
    sec_b = [m for m in ms if m["grp"] == "B"]
    assert {m["id"] for m in EN.counted(sec_b)} == {ids["b1"], ids["b2"]}           # ไม่นับรวม (2) ถูกตัด
    assert {m["id"] for m in EN.counted([m for m in ms if m.get("line") == "L1"])} == {ids["a1"], ids["b1"], ids["b2"]}
    assert EN.factory_mains(ms) == {ids["inc"]}
    use = {m["id"]: 10.0 for m in ms}
    use[ids["inc"]], use[ids["sa"]] = 100.0, 40.0
    bal = {tuple(p["id"] for p in b["parents"]): b for b in EN.balance(ms, use)}
    assert bal[(ids["sa"],)]["ku"] == 20 and bal[(ids["sa"],)]["diff"] == 20
    assert bal[(ids["inc"],)]["ku"] == 40 + 10 + 10                                   # SA + B1 + B2 (ไม่รวม X, A1, A2)
    # ทุกหน้าใช้กติกาเดียวกัน: Dashboard · ตาราง · รายงาน Section
    d = EN.dashboard(db, D0, f1, "elec", today=D0 + timedelta(days=21))
    assert d["kinds"][0]["total"] == 20 * (1000 - 50)
    sh = EN.month_sheet(db, f1, "elec", D0)
    assert sh["grand"] == 20 * 950
    rep = __import__("ecs.energy_ops", fromlist=["x"]).section_report(db, f1, "elec", 2026)
    g = {r["grp"]: r["sum"] for r in rep["rows"]}
    assert g["A"] == 20 * 600 and g["B"] == 20 * 350 and "" not in g
    assert rep["unmetered"] is not None


def test_parent_explicit_and_cycle(app, db):
    f1 = app.config["F1"]
    p = _mk(db, f1, "P", "S", 1)
    c = _mk(db, f1, "C", "T", 0, parent=p)                # คนละ Section แต่ตั้งแม่เอง
    assert EN.covers(EN.meters(db, f1, "elec"))[c] == {p}
    with pytest.raises(S.ValidationError):
        EN.save_meter(db, p, {"kind": "elec", "code": "P", "name": "M P", "grp": "S", "is_main": "1", "parent_id": str(c)}, None)
    w = _mk(db, f1, "W", "", 0, kind="water")
    with pytest.raises(S.ValidationError):
        EN.save_meter(db, c, {"kind": "elec", "code": "C", "name": "M C", "grp": "T", "parent_id": str(w)}, None)
    assert [x["id"] for x in EN.children(db, p)] == [c]


def test_register_plan_apply_detect(app, db):
    p = ER.plan(db)
    n = len(ER.rows())
    assert n > 300 and p["counts"]["new"] == sum(1 for r in ER.rows() if r["f"] in p["fmap"])
    kinds = {(r["f"], r["kind"]) for r in ER.rows()}
    assert {(1, "elec"), (2, "air"), (3, "water"), (3, "hours")} <= kinds
    r = ER.apply(db, "fill", None)
    db.commit()
    assert r["new"] == p["counts"]["new"] and r["parents"] >= 3
    p2 = ER.plan(db)
    assert p2["counts"]["new"] == 0 and p2["counts"]["diff"] == 0
    # มิเตอร์แม่จากทะเบียน: น้ำ ไอชิน 1 Main RO อยู่ใต้ Raw water
    fid1 = p["fmap"][1]
    ro = db.execute("SELECT id, parent_id FROM en_meters WHERE factory_id=? AND kind='water' AND name LIKE 'Main RO%'", (fid1,)).fetchone()
    raw = db.execute("SELECT id FROM en_meters WHERE factory_id=? AND kind='water' AND name LIKE 'Main Raw water%'", (fid1,)).fetchone()
    assert ro["parent_id"] == raw["id"]
    # แก้ Section เอง → fill ไม่ทับ · sync ทับ
    db.execute("UPDATE en_meters SET grp='แก้เอง' WHERE id=?", (ro["id"],))
    assert ER.plan(db, 1, "water")["counts"]["diff"] == 1
    ER.apply(db, "fill", None, 1, "water")
    assert db.execute("SELECT grp FROM en_meters WHERE id=?", (ro["id"],)).fetchone()[0] == "แก้เอง"
    ER.apply(db, "sync", None, 1, "water")
    assert db.execute("SELECT grp FROM en_meters WHERE id=?", (ro["id"],)).fetchone()[0] == "RO"
    # ไฟล์ที่นำเข้า → ตรวจโรงงาน/ประเภทจากทะเบียน
    keys = [r["key"] for r in ER.rows() if r["f"] == 2 and r["kind"] == "air"]
    det = ER.detect({"meters": [{"key": k} for k in keys]}, db)
    assert det["kind"] == "air" and det["factory_id"] == p["fmap"][2]
    assert ER.detect({"meters": [{"key": "ไม่มีจริง"}]}, db) is None
    assert ER.norm_section("การใช้น้ำ R.O ฝั่ง D10 C LINE") == "D10C LINE"


def test_import_uses_register(app, db):
    rows = [r for r in ER.rows() if r["f"] == 1 and r["kind"] == "water"]
    fid1 = ER.factory_map(db)[1]
    parsed = {"meters": [{"key": r["key"], "code": r["code"], "name": r["name"], "grp": "หัวตารางดิบ", "price": None, "order": i,
                          "readings": {"2026-09-01": 100.0 + i, "2026-09-02": 110.0 + i}} for i, r in enumerate(rows)], "months": [{"month": 9}]}
    pv = EN.preview(db, parsed, fid1, "water")
    std = {r["key"]: r for r in rows}
    assert all(x["std"] for x in pv["meters"]) and all(x["grp"] == std[x["key"]]["grp"] for x in pv["meters"])
    EN.commit(db, parsed, fid1, "water", 2026, "x.xls", None)
    m = db.execute("SELECT grp, is_main, parent_id FROM en_meters WHERE factory_id=? AND kind='water' AND name LIKE 'Main Filtrate%'",
                   (fid1,)).fetchone()
    assert m["grp"] == "Filtrate" and m["is_main"] == 1 and m["parent_id"]
    waste = db.execute("SELECT is_main FROM en_meters WHERE factory_id=? AND kind='water' AND name LIKE 'Brine%'", (fid1,)).fetchone()
    assert waste[0] == 2


def test_manage_build_and_pages(app, db, client):
    from conftest import login
    f1 = app.config["F1"]
    ids = _plant(db, f1)
    w = _mk(db, f1, "W1", "Utility", kind="water")
    _feed(db, w, 3.5, days=10)
    db.commit()
    d = MG.build(db, D0, f1, today=D0 + timedelta(days=21))
    k = {x["kind"]: x for x in d["kinds"]}
    fe = k["elec"]["factories"][0]
    assert fe["u"] == 20 * 950
    secs = {s["name"]: s for s in fe["sections"]}
    assert secs["A"]["u"] == 20 * 600 and secs["B"]["u"] == 20 * 350
    assert {ln["name"]: ln["u"] for ln in secs["A"]["lines"]} == {"L1": 20 * 300, "L2": 20 * 250}
    assert fe["loss"] == 20 * 950 - (20 * 600 + 20 * 350 - 20 * 50) and round(sum(s["share"] for s in fe["sections"])) == 100
    assert fe["complete"] == 100.0 and k["water"]["factories"][0]["complete"] < 100
    miss = [r for r in d["complete"]["rows"] if r["m"]["id"] == w]
    assert miss and miss[0]["miss"] == 10
    assert MG.to_xlsx(d)[:2] == b"PK"
    login(client, "t_admin")
    page = client.get("/energy/manage", query_string={"month": "2026-09"}).get_data(as_text=True)
    assert "บริหารพลังงาน" in page and "หน่วยงาน &amp; ไลน์" in page and "สมดุล" in page and "ความครบของการจด" in page
    assert client.get("/energy/manage", query_string={"month": "2026-09", "fmt": "xlsx"}).data[:2] == b"PK"
    dash = client.get("/energy/", query_string={"month": "2026-09"}).get_data(as_text=True)
    assert 'id="units"' in dash and "L1" in dash
    assert client.get(f"/energy/meters/{ids['sa']}").status_code == 200
    reg = client.get("/energy/register").get_data(as_text=True)
    assert "ทะเบียนมิเตอร์มาตรฐาน" in reg
    tok = login(client, "t_admin")
    r = client.post("/energy/register", data={"csrf_token": tok, "mode": "fill", "f": "2", "kind": "ro"})
    assert r.status_code == 302
    assert db.execute("SELECT COUNT(*) FROM en_meters WHERE kind='ro'").fetchone()[0] == sum(1 for x in ER.rows() if x["f"] == 2 and x["kind"] == "ro")


def test_cost_prefers_raw_readings(app, db):
    f1 = app.config["F1"]
    a = _mk(db, f1, "CA", "Press")
    b = _mk(db, f1, "CB", "Press")
    _feed(db, a, 100, days=30)
    db.commit()
    C.set_month_usage(db, a, "2026-09", 5, None, src="import")           # ยอดนำเข้าเดิม → ค่าจดครบแล้วใช้ค่าจด
    C.set_month_usage(db, b, "2026-09", 777, None, src="import")         # ไม่มีค่าจด → ใช้ยอดนำเข้า
    mm = C.meter_months(db, f1, 2026, today=date(2026, 10, 20))
    assert mm[a]["kwh"][8] == 3000 and mm[a]["src"][8] == "daily"
    assert mm[b]["kwh"][8] == 777 and mm[b]["src"][8] == "import"
    C.set_month_usage(db, a, "2026-09", 2500, None, src="manual")        # แก้เอง → ชนะเสมอ
    assert C.meter_months(db, f1, 2026, today=date(2026, 10, 20))[a]["kwh"][8] == 2500
    r = C.sync_sections(db, f1, None)
    assert r["new"] == 1
    aid = db.execute("SELECT id FROM en_areas WHERE factory_id=? AND name='Press'", (f1,)).fetchone()[0]
    assert {x["meter_id"] for x in C.links(db, aid)} == {a, b}
    assert C.sync_sections(db, f1, None)["kept"] == 1
