"""v0.72: แหล่งข้อมูล SCADA ของ Energy Data แยกจาก E-Check"""
import io
import sqlite3
from datetime import date, datetime, timedelta

from conftest import login, uid

from ecs import energy as EN
from ecs import energy_src as ES

TODAY = date.today()


def _scada(tmp_path, tags=("T1", "T2")):
    p = tmp_path / "s.db"
    con = sqlite3.connect(p)
    con.execute("CREATE TABLE t (tag TEXT, ts TEXT, v REAL)")
    base = datetime.combine(TODAY - timedelta(days=2), datetime.min.time())
    for d in range(3):
        for h in (7, 8, 9):
            for i, tg in enumerate(tags):
                dt = base + timedelta(days=d, hours=h, minutes=3)
                con.execute("INSERT INTO t VALUES (?,?,?)", (tg, dt.strftime("%Y-%m-%d %H:%M:%S"), 1000 * (i + 1) + d * 100 + h))
    con.commit()
    con.close()
    return str(p)


def _src(db, path, name="S"):
    import json
    return ES.save_source(db, {"name": name, "kind": "sqlite", "interval_min": "15", "active": "1",
                               "config": json.dumps({"path": path, "query": "SELECT tag, ts, v AS value FROM t WHERE ts > ?", "backfill_days": 5})}, None)


def test_separate_tables_and_mapping(app, db, tmp_path):
    f1 = app.config["F1"]
    path = _scada(tmp_path)
    sid = _src(db, path)
    assert db.execute("SELECT COUNT(*) FROM cs_sources WHERE name='S'").fetchone()[0] == 0     # ไม่ปนกับ E-Check
    m1 = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "A1", "name": "Press 1"}, None)
    m2 = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "A2", "name": "Press 2"}, None)
    t = ES.test(db, sid)
    assert t["tags"] == 2 and t["plan"] == []
    assert db.execute("SELECT COUNT(*) FROM en_readings WHERE meter_id IN (?,?)", (m1, m2)).fetchone()[0] == 0
    rows = ES.tag_rows(db, sid)
    assert [r["tag"] for r in rows] == ["T1", "T2"] and not rows[0]["meter"]
    sg = ES.suggest(db, sid, rows)
    assert isinstance(sg, dict)
    r = ES.save_mapping(db, sid, [{"tag": "T1", "meter": f"#{m1} · x", "scale": 2, "offset": 5}, {"tag": "T2", "meter": str(m2)}], None)
    assert r["mapped"] == 2
    t = ES.test(db, sid, days=5)
    p1 = [x for x in t["plan"] if x["meter_id"] == m1]
    assert len(p1) == 3 and p1[0]["value"] == (1000 + 8) * 2 + 5
    res = ES.run_source(db, sid, manual=True)
    assert res["ok"] and res["readings"] == 6
    assert db.execute("SELECT src FROM en_readings WHERE meter_id=? LIMIT 1", (m1,)).fetchone()[0] == "scada"
    # v0.86 เลือกมิเตอร์ซ้ำ: แถวที่เพิ่งเปลี่ยน (T1 → m2) ได้มิเตอร์ · T2 ถูกถอด (ย้าย) — ไม่ทำให้ทั้งหน้าบันทึกไม่ได้
    r = ES.save_mapping(db, sid, [{"tag": "T1", "meter": str(m2)}, {"tag": "T2", "meter": str(m2)}], None)
    assert r["moved"] == 1 and any("ย้าย" in w for w in r["warnings"])
    assert EN.meter(db, m2)["scada_tag"] == "T1" and EN.meter(db, m1)["scada_tag"] == ""
    ES.save_mapping(db, sid, [{"tag": "T1", "meter": str(m1)}, {"tag": "T2", "meter": str(m2)}], None)
    ES.save_mapping(db, sid, [{"tag": "T2", "meter": ""}], None)     # ถอดการผูก
    assert EN.meter(db, m2)["scada_tag"] == ""
    x = ES.export_xlsx(db, sid)
    assert x[:2] == b"PK"
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(x))
    ws = wb["จับคู่ Tag"]
    for row in ws.iter_rows(min_row=2):
        if row[0].value == "T2":
            row[3].value = m2
    bio = io.BytesIO()
    wb.save(bio)
    assert ES.import_xlsx(db, sid, bio.getvalue(), None)["mapped"] == 1
    assert EN.meter(db, m2)["scada_source_id"] == sid
    n = ES.delete_source(db, sid, None)
    assert n == 2 and EN.meter(db, m1)["scada_source_id"] is None
    db.commit()


def test_migrate_from_echeck(app, db):
    """มิเตอร์เดิมที่ผูกแหล่งของ E-Check → ย้ายมาเป็นของ Energy (คง id เดิม)"""
    from ecs import connectors as C
    f1 = app.config["F1"]
    cid = C.save_source(db, {"name": "OLD", "kind": "csv", "interval_min": "15", "bucket_min": "60", "agg": "last", "active": "1",
                             "config": {"folder": "/tmp"}}, uid(db, "t_admin"))
    mid = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "M9", "name": "Old link", "scada_source_id": str(cid),
                                   "scada_tag": "X"}, None)
    db.execute("DROP TABLE en_sources")
    db.execute("DROP TABLE en_source_tags")
    ES.ensure_src(db)
    s = ES.get_source(db, cid)
    assert s and s["name"] == "OLD" and EN.meter(db, mid)["scada_source_id"] == cid
    db.commit()


def test_pages(app, client, db, tmp_path):
    f1 = app.config["F1"]
    sid = _src(db, _scada(tmp_path))
    mid = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "Z1", "name": "Z", "scada_source_id": str(sid), "scada_tag": "T1"}, None)
    db.commit()
    tok = login(client, "t_admin")
    for u in ("/energy/sources", f"/energy/sources/{sid}", f"/energy/sources/{sid}?show=free", f"/energy/sources/{sid}/mapping.xlsx",
              f"/energy/meters/{mid}", "/energy/meters", "/energy/settings"):
        assert client.get(u).status_code == 200, u
    r = client.post(f"/energy/sources/{sid}/test", json={"days": 2}, headers={"X-CSRF-Token": tok})
    assert r.status_code == 200 and r.get_json()["ok"]
    r = client.post(f"/energy/meters/{mid}/scada-test", json={}, headers={"X-CSRF-Token": tok})
    assert r.status_code == 200 and r.get_json()["found"] and r.get_json()["plan"]
    r = client.post(f"/energy/sources/{sid}/tags", data={"csrf_token": tok, "tag": ["T1"], "meter.0": f"#{mid}", "scale.0": "1", "offset.0": "0"})
    assert r.status_code in (302, 303)
    r = client.post(f"/energy/sources/{sid}/run", data={"csrf_token": tok})
    assert r.status_code in (302, 303)
