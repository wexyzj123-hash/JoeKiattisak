"""v0.19: รออนุมัติในหน้าแจ้งเตือน · รับทราบแบบกลุ่มไม่หลุดไป Not Found เมื่ออยู่ใต้ /echeck"""
import json

from conftest import GOOD, login, payload, uid

from ecs import anomaly as A
from ecs import submissions as SUB


def _submit(app, db, form, ans=None):
    res = SUB.create_submission(db, payload(form, ans or GOOD), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    return res["id"]


def _appr(db, sid):
    return db.execute("SELECT * FROM cs_alerts WHERE alert_type='approval' AND submission_id=?", (sid,)).fetchone()


def test_approval_alert_lifecycle(app, db, published_form):
    sid = _submit(app, db, published_form)
    a = _appr(db, sid)
    assert a and a["severity"] == "info" and a["status"] == "open" and a["title"].startswith("รออนุมัติ: Daily AC")
    assert "ผลปกติ" in a["detail"] and A.open_alert_counts(db)["info"] >= 1
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get("/alerts").get_data(as_text=True)
    assert "รออนุมัติ: Daily AC" in page and "ตรวจสอบ/อนุมัติ" in page and f"/submissions/{sid}" in page
    r = c.get(f"/alerts/{a['id']}")
    assert r.status_code == 302 and r.headers["Location"].endswith(f"/submissions/{sid}")
    c.post(f"/submissions/{sid}/approve", data={"csrf_token": tok})
    assert _appr(db, sid)["status"] == "closed"
    # ตีกลับ → ปิด · ส่งใหม่ → เปิดรายการใหม่
    sid2 = _submit(app, db, published_form)
    c.post(f"/submissions/{sid2}/return", data={"csrf_token": tok, "note": "กรอกค่าผิด"})
    a2 = _appr(db, sid2)
    assert a2["status"] == "closed" and "ตีกลับ" in a2["close_note"]
    # ลบผลตรวจ → ปิด
    sid3 = _submit(app, db, published_form)
    SUB.delete_submissions(db, [sid3], uid(db, "t_admin"), "ทดสอบลบ")
    db.commit()
    assert db.execute("SELECT status FROM cs_alerts WHERE alert_type='approval' AND title LIKE 'รออนุมัติ%' "
                      "ORDER BY id DESC LIMIT 1").fetchone()[0] == "closed"
    # ไม่นับในสถิติความผิดปกติของแดชบอร์ด
    assert all(x["alert_type"] != "approval" for x in A.recent_alerts(db))


def test_bulk_ack_redirect_keeps_prefix(app, db, published_form):
    from ecs import services as S
    form = S.get_form(db, published_form["form_id"])
    A.raise_alert(db, alert_type="ng", form=form, title="NG: test", detail="x", severity="warning", item_key="oil")
    A.raise_alert(db, alert_type="stuck", form=form, title="stuck", detail="x", severity="info", item_key="hour")
    db.commit()
    ids = [r[0] for r in db.execute("SELECT id FROM cs_alerts WHERE status='open'")]
    c = app.test_client()
    tok = login(c, "t_sup")
    base = {"csrf_token": tok, "action": "ack", "ids": [str(i) for i in ids], "next": "/alerts?status=open&severity=warning"}
    r = c.post("/alerts/bulk", data=base, environ_overrides={"SCRIPT_NAME": "/echeck"})
    assert r.status_code == 302 and r.headers["Location"].startswith("/echeck/alerts?")
    # ปุ่มรับทราบรายการเดียว
    aid = db.execute("SELECT id FROM cs_alerts WHERE alert_type='ng' ORDER BY id DESC LIMIT 1").fetchone()[0]
    db.execute("UPDATE cs_alerts SET status='open' WHERE id=?", (aid,))
    db.commit()
    r = c.post(f"/alerts/{aid}/ack", data={"csrf_token": tok, "next": "/alerts?status=open"},
               environ_overrides={"SCRIPT_NAME": "/echeck"})
    assert r.headers["Location"] == "/echeck/alerts?status=open"
    # กัน open redirect
    r = c.post("/alerts/bulk", data=dict(base, next="//evil.example/x"))
    assert "evil" not in r.headers["Location"]
