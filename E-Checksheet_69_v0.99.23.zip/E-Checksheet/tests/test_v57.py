"""v0.57: แก้ข้อมูลเก่า — มีผลตรวจระหว่างที่ระบบค้างสถานะหยุด → เดินเครื่องตั้งแต่เริ่มกะของผู้ตรวจ + ผูกผลนอกรอบเข้ารอบ"""
from datetime import datetime, timedelta

from conftest import login, uid

from ecs import downtime as DT
from ecs import services as S


def _round(db, sid, fid, due, hours=4, status="skipped"):
    return db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                         VALUES (?,?,?,?,?,?,?)""", (sid, fid, S.ts(due), S.ts(due + timedelta(hours=hours)),
                                                     S.ts(due + timedelta(hours=hours * 2)), status, S.ts(due))).lastrowid


def _sub(db, fid, at, user):
    ver = db.execute("SELECT current_version_id FROM cs_forms WHERE id=?", (fid,)).fetchone()[0]
    import uuid
    return db.execute("""INSERT INTO cs_submissions(client_uuid, form_id, form_version_id, inspector_id, scanned_at, finished_at,
                         received_at, status) VALUES (?,?,?,?,?,?,?,'submitted')""",
                      (str(uuid.uuid4()), fid, ver, user, S.ts(at), S.ts(at + timedelta(minutes=3)), S.ts(at))).lastrowid


def _reported(db, at):
    """ข้อมูลจริง: แจ้งหยุดตอนเครื่องหยุด (เวลาบันทึก Audit = เวลาหยุด)"""
    db.execute("UPDATE cs_audit SET created_at=? WHERE action='down'", (S.ts(at),))


def test_backdated_stop_over_existing_check_is_ignored(app, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    now = S.now_dt()
    _sub(db, fid, now - timedelta(hours=1), uid(db, "t_tech"))                    # ตรวจไปแล้ว 1 ชม.ก่อน
    DT.set_down(db, eq, uid(db, "t_tech2"), "ซ่อม", "repair", start_at=now - timedelta(hours=3))   # แจ้งหยุดย้อนหลังทีหลัง
    db.commit()
    assert DT.stale_downtimes(db) == []


def test_fix_open_downtime_with_old_check(app, client, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    sid = S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00"}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    base = datetime.combine(S.now_dt().date() - timedelta(days=2), datetime.min.time())
    DT.set_down(db, eq, uid(db, "t_tech2"), "หยุดตามแผน", "stop", start_at=base - timedelta(hours=3))     # 21:00
    _reported(db, base - timedelta(hours=3))
    night = _round(db, sid, fid, base - timedelta(hours=2), hours=1)                                      # 22:00 (หยุดจริง)
    day = _round(db, sid, fid, base + timedelta(hours=9))                                                 # 09:00 วันถัดไป
    later = _round(db, sid, fid, base + timedelta(days=1, hours=9))                                       # อีกวัน ไม่มีคนตรวจ
    tech = uid(db, "t_tech")
    sub = _sub(db, fid, base + timedelta(hours=9, minutes=1), tech)                                       # ตรวจ "นอกรอบ" 09:01
    db.commit()
    rows = DT.stale_downtimes(db)
    assert len(rows) == 1 and rows[0]["sub_id"] == sub and rows[0]["new_end"] == S.ts(base + timedelta(hours=8))
    assert rows[0]["offround"] == 1 and rows[0]["rounds"] == 2
    tok = login(client, "t_sup")
    assert "ยังค้างหยุด" in client.get("/equipment/down/fix").get_data(as_text=True)
    client.post("/equipment/down/fix", data={"csrf_token": tok, "id": str(rows[0]["id"])})
    assert db.execute("SELECT run_status FROM equipment WHERE id=?", (eq,)).fetchone()[0] == "running"
    d = db.execute("SELECT end_at, ended_by, end_note FROM cs_downtime WHERE equipment_id=?", (eq,)).fetchone()
    assert d["end_at"] == S.ts(base + timedelta(hours=8)) and d["ended_by"] == tech and "แก้ข้อมูลย้อนหลัง" in d["end_note"]
    st = {r[0]: r[1] for r in db.execute("SELECT id, status FROM cs_rounds WHERE form_id=?", (fid,))}
    assert st[night] == "skipped" and st[day] == "done_on_time" and st[later] == "missed"
    assert db.execute("SELECT round_id FROM cs_submissions WHERE id=?", (sub,)).fetchone()[0] == day
    assert DT.stale_downtimes(db) == []                                                                    # แก้แล้วไม่ขึ้นซ้ำ
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE action='downtime_fix'").fetchone()[0] == 1


def test_fix_closed_downtime_and_skip_unchecked(app, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    base = datetime.combine(S.now_dt().date() - timedelta(days=3), datetime.min.time())
    DT.set_down(db, eq, uid(db, "t_tech2"), "PM", "pm", start_at=base - timedelta(hours=7))              # 17:00
    _reported(db, base - timedelta(hours=7))
    db.commit()
    DT.set_running(db, eq, uid(db, "t_admin"), "", now=base + timedelta(days=1, hours=15))                # กดเดินช้า 1 วัน
    _sub(db, fid, base + timedelta(hours=21), uid(db, "t_tech"))                                          # ตรวจกะดึก 21:00
    db.commit()
    rows = DT.stale_downtimes(db)
    assert len(rows) == 1 and rows[0]["new_end"] == S.ts(base + timedelta(hours=20)) and rows[0]["shift"] == "กะกลางคืน"
    res = DT.fix_stale_downtimes(db, uid(db, "t_admin"))
    assert res["fixed"] == 1
    d = db.execute("SELECT end_note FROM cs_downtime WHERE equipment_id=?", (eq,)).fetchone()[0]
    assert "เดิมเดินเครื่อง" in d and "ทดสอบ t_admin" in d
    # ไม่มีผลตรวจระหว่างหยุด → ไม่แก้
    DT.set_down(db, eq, uid(db, "t_tech2"), "ซ่อม", "repair")
    assert DT.stale_downtimes(db) == []
