"""v0.55: สิทธิ์ลงข้อมูลเช็คชีทย้อนหลัง (ผู้ดูแลระบบ / หัวหน้างาน FM-SV กำหนดให้)"""
from datetime import timedelta

import pytest
from conftest import GOOD, login, payload, uid

from ecs import backfill as BF
from ecs import services as S
from ecs import submissions as SUB


def _closed_round(db, fid):
    sid = S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00"}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    due = S.now_dt() - timedelta(hours=10)
    rid = db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                        VALUES (?,?,?,?,?,'missed',?)""", (sid, fid, S.ts(due), S.ts(due + timedelta(hours=1)),
                                                          S.ts(due + timedelta(hours=2)), S.ts(due))).lastrowid
    db.commit()
    return rid


def test_backfill_needs_grant(app, db, published_form):
    fid = published_form["form_id"]
    rid = _closed_round(db, fid)
    tech, sup = uid(db, "t_tech"), uid(db, "t_sup")
    p = payload(published_form, GOOD, round_id=rid)
    with pytest.raises(S.ValidationError) as e:
        SUB.create_submission(db, p, {}, tech, app.config["UPLOAD_FOLDER"])
    assert "สิทธิ์" in e.value.errors[0]
    db.rollback()
    # ช่างให้สิทธิ์ไม่ได้ · หัวหน้างานที่ไม่ใช่ FM/SV ก็ไม่ได้
    with pytest.raises(S.ValidationError):
        BF.grant(db, [tech], ["2026-01-01"], 0, "", uid(db, "t_tech2"))
    db.execute("UPDATE users SET position='' WHERE id=?", (sup,))
    assert not BF.can_grant(db, sup)
    db.execute("UPDATE users SET position='fm' WHERE id=?", (sup,))
    assert BF.can_grant(db, sup) and BF.allowed(db, sup)
    day = db.execute("SELECT substr(due_at,1,10) FROM cs_rounds WHERE id=?", (rid,)).fetchone()[0]
    other = (S.now_dt().date() - timedelta(days=20)).isoformat()
    with pytest.raises(S.ValidationError):                       # เลือกได้เฉพาะวันที่ยังขาดข้อมูล
        BF.grant(db, [tech], [other], 0, "", sup)
    assert day in {d["day"] for d in BF.open_days(db)}
    BF.grant(db, [tech], [day], fid, "กรอกจากกระดาษ", sup)
    db.commit()
    assert not BF.allowed(db, tech, {"due_at": other + " 08:00:00", "form_id": fid})
    res = SUB.create_submission(db, p, {}, tech, app.config["UPLOAD_FOLDER"])
    db.commit()
    assert res["round_status"] == "done_late"
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE action='backfill_submit'").fetchone()[0] == 1
    g = BF.grants(db)[0]
    assert g["left"] == 0                                          # วันนั้นลงครบแล้ว
    assert day not in {d["day"] for d in BF.open_days(db)}
    BF.revoke(db, g["id"], sup)
    assert not BF.allowed(db, tech, {"due_at": day + " 08:00:00", "form_id": fid})


def test_offline_done_before_close_is_not_backfill(app, db, published_form):
    fid = published_form["form_id"]
    rid = _closed_round(db, fid)
    r = db.execute("SELECT due_at FROM cs_rounds WHERE id=?", (rid,)).fetchone()
    fin = S.parse_ts(r[0]) + timedelta(minutes=30)
    p = payload(published_form, GOOD, round_id=rid, finished_at=fin.isoformat(), scanned_at=fin.isoformat())
    res = SUB.create_submission(db, p, {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    assert res["id"]


def test_backfill_page_and_flags(app, client, db, published_form):
    fid = published_form["form_id"]
    rid = _closed_round(db, fid)
    day = db.execute("SELECT substr(due_at,1,10) FROM cs_rounds WHERE id=?", (rid,)).fetchone()[0]
    tech = uid(db, "t_tech")
    login(client, "t_tech")
    assert client.get("/team/backfill").status_code == 403
    pkg = client.get(f"/api/m/forms/{fid}/package?round={rid}").get_json()
    assert pkg["can_backfill"] is False
    tok = login(client, "t_admin")
    html = client.get("/team/backfill").get_data(as_text=True)
    assert "สิทธิ์ลงข้อมูลเช็คชีทย้อนหลัง" in html and "รอบไม่ได้ลง" in html
    client.post("/team/backfill/grant", data={"csrf_token": tok, "user_id": str(tech), "day": day, "form": "0", "note": "x"})
    assert BF.granted_days(db, tech) == {day}
    assert "ค้าง 1 รอบ" in client.get("/team/backfill").get_data(as_text=True)
    login(client, "t_tech")
    assert client.get(f"/api/m/forms/{fid}/package?round={rid}").get_json()["can_backfill"] is True
    month = day[:7]
    assert "กรอกย้อนหลัง รอบ" in client.get(f"/reports/sheets/sign?form={fid}&month={month}").get_data(as_text=True)
    js = client.get("/static/m/fill.js").get_data(as_text=True)
    assert "can_backfill" in js
