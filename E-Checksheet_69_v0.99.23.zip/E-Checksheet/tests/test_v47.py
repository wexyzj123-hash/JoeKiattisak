"""v0.47: ศูนย์ผูกข้อมูล SCADA / SQL — ขั้นตอน 1→5 พร้อมสถานะ · ตรวจเวลา UTC · ผลการลงค่ารายวัน"""
import sqlite3
from datetime import datetime, time, timedelta

from conftest import login, uid

from ecs import binding as BD
from ecs import connectors as CN
from ecs import services as S
from ecs.services import ts


def _src(db, tmp_path, rows, **kw):
    path = str(tmp_path / "scada.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE IF NOT EXISTS h (tag TEXT, ts TEXT, value REAL)")
    con.executemany("INSERT INTO h VALUES (?,?,?)", rows)
    con.commit()
    con.close()
    return CN.save_source(db, {"name": "GENESIS64", "kind": "sqlite", "prefill": "0", "config": {"path": path,
                               "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 2}, **kw}, None)


def test_empty_state(app, db):
    st = BD.status(db)
    assert st["steps"][0] == "todo" and st["done"] == 0
    c = app.test_client()
    login(c, "t_admin")
    html = c.get("/admin/binding").get_data(as_text=True)
    assert "ศูนย์ผูกข้อมูล" in html and "ยังไม่มีแหล่งข้อมูล" in html and "ผูกข้อมูล SCADA / SQL" in html


def test_utc_detect_and_apply(app, db, published_form, tmp_path):
    now = S.now_dt()
    rows = [("SCT0002_OIL_PRESS", ts(now - timedelta(hours=7) - timedelta(minutes=m)), 2.1) for m in range(0, 60, 10)]
    sid = _src(db, tmp_path, rows)
    CN.run_source(db, sid, manual=True)
    db.commit()
    tc = BD.time_check(db, CN.get_source(db, sid))
    assert tc["state"] == "warn" and tc["suggest"] == 420 and "UTC" in tc["msg"]
    c = app.test_client()
    tok = login(c, "t_admin")
    html = c.get("/admin/binding").get_data(as_text=True)
    assert "ใช้เลื่อนเวลา +420 นาที" in html
    c.post("/admin/binding/shift", data={"csrf_token": tok, "sid": str(sid), "minutes": "420"})
    assert CN.get_source(db, sid)["ts_shift_min"] == 420
    c.post("/admin/binding/run", data={"csrf_token": tok})
    assert BD.time_check(db, CN.get_source(db, sid))["state"] == "ok"


def test_steps_and_fill_check(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    S.create_schedule(db, fid, {"freq_type": "shift", "times": "08:30,20:30", "window_min": 240}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (ts(S.now_dt() - timedelta(days=3)),))
    S.generate_rounds(db)
    day = (S.now_dt() - timedelta(days=1)).date()
    now = S.now_dt()
    rows = [("SCT0002_OIL_PRESS", ts(datetime.combine(day, time(8, 30))), 2.0), ("SCT0002_OIL_PRESS", ts(now), 2.1),
            ("SCT0002_RUN_HR", ts(now), 1500)]
    sid = _src(db, tmp_path, rows)
    CN.run_source(db, sid, manual=True)
    st = BD.status(db, day)
    assert st["steps"][0] == "ok" and st["s3"]["total"] == 2 and st["steps"][3] == "todo"
    CN.save_mapping(db, sid, [{"tag": "SCT0002_OIL_PRESS", "target": f"{fid}:oil"}], None)
    db.execute("UPDATE cs_sources SET watermark='' WHERE id=?", (sid,))
    CN.run_source(db, sid, manual=True)
    db.commit()
    st = BD.status(db, day)
    f = st["s5"]["fill"]
    assert f["total"] == 2 and f["filled"] == 1 and f["missing"][0]["time"] == "20:30" and "±" in f["missing"][0]["why"]
    assert st["s4"]["mapped_forms"] == 1 and st["s4"]["sug_forms"]          # RUN_HR ยังมีคำแนะนำรออยู่
    assert st["s5"]["pending"] >= 1 and st["s5"]["modes"]["round"] == 1
    c = app.test_client()
    login(c, "t_admin")
    html = c.get(f"/admin/binding?day={day.isoformat()}").get_data(as_text=True)
    assert "1/2" in html and "20:30" in html and "ยืนยันค่าที่รออยู่" in html and "จับคู่" in html
    login(c, "t_sup")
    assert c.get("/admin/binding").status_code in (302, 403)


def test_stale_source_no_shift_suggestion(app, db, published_form, tmp_path):
    now = S.now_dt()
    sid = _src(db, tmp_path, [("T1", ts(now - timedelta(minutes=100)), 1.0)])
    CN.run_source(db, sid, manual=True)
    CN.run_source(db, sid, manual=True)                    # รอบที่ 2 ไม่มีค่าใหม่
    tc = BD.time_check(db, CN.get_source(db, sid))
    assert tc["suggest"] is None and "ไม่มีค่าใหม่" in tc["msg"]
