"""v0.87: Energy ค่าต่อช่วงเวลา (15 นาที) → Dashboard รายช่วงเวลา + ค่าอ่านรายวันอัตโนมัติ"""
import json
from datetime import datetime, time, timedelta

from conftest import login
from test_v73 import _hist

from ecs import energy as EN
from ecs import energy_interval as EI
from ecs import energy_live as LV
from ecs import energy_src as ES
from ecs import services as S
from ecs.services import ts


def _rows(days=3, bad=True):
    today = S.now_dt().date()
    out = []
    for dd in range(days, -1, -1):
        d = today - timedelta(days=dd)
        for i in range(96):
            t = datetime.combine(d, time(0, 0)) + timedelta(minutes=15 * (i + 1))
            if t > S.now_dt():
                break
            out.append(("A_kwh", ts(t), 10.0))                     # 10 kWh/15 นาที = 40 kW
            out.append(("B_kwh", ts(t), 5.0 if 32 <= i < 72 else 0.0))
    if bad:
        out.append(("A_kwh", ts(datetime.combine(today - timedelta(days=1), time(3, 7))), 2157641728.0))   # ค่าเสีย
    return out


def _setup(app, db, tmp_path, kind="interval"):
    path = str(tmp_path / "i.db")
    _hist(path, _rows())
    sid = ES.save_source(db, {"name": "DL", "kind": "sqlite", "active": "1", "value_kind": kind,
                              "config": json.dumps({"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                                    "backfill_days": 4})}, None)
    f1 = app.config["F1"]
    a = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "A", "name": "A", "grp": "PM", "line": "L1",
                                 "scada_source_id": str(sid), "scada_tag": "A_kwh"}, None)
    b = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "B", "name": "B", "grp": "MFG", "line": "L2",
                                 "scada_source_id": str(sid), "scada_tag": "B_kwh"}, None)
    db.commit()
    return sid, a, b, path


def test_interval_ingest_and_daily_readings(app, db, tmp_path):
    sid, a, b, _ = _setup(app, db, tmp_path)
    r = ES.run_source(db, sid, manual=True)
    db.commit()
    assert r["ok"], r
    yd = (S.now_dt().date() - timedelta(days=1))
    n = db.execute("SELECT COUNT(*) FROM en_intervals WHERE meter_id=? AND ts LIKE ?", (a, f"{yd}%")).fetchone()[0]
    assert n == 96                                                  # ค่าเสีย 2,157,641,728 ไม่เก็บ
    assert db.execute("SELECT MAX(value) FROM en_intervals").fetchone()[0] == 10.0
    rd = {r_[0]: r_[1] for r_ in db.execute("SELECT day, value FROM en_readings WHERE meter_id=? ORDER BY day", (a,))}
    assert abs(rd[yd.isoformat()] - rd[(yd - timedelta(days=1)).isoformat()] - 960.0) < 1e-6   # 96 × 10 kWh ต่อวัน (08:00→08:00)
    assert db.execute("SELECT src FROM en_readings WHERE meter_id=? LIMIT 1", (a,)).fetchone()[0] == "scada"


def test_live_dashboard(app, db, client, tmp_path):
    sid, a, b, _ = _setup(app, db, tmp_path)
    ES.run_source(db, sid, manual=True)
    db.commit()
    yd = S.now_dt().date() - timedelta(days=1)
    d = LV.data(db, "elec", yd)
    assert d["kpi"]["sum"] == 960 + 200 and d["kpi"]["res"] == 15
    assert d["kpi"]["peak"] == (10 + 5) * 4 and d["level"] == "factory"
    d2 = LV.data(db, "elec", yd, fid=app.config["F1"])
    assert d2["level"] == "project" and d2["rows"][0]["sum"] == 1160
    d3 = LV.data(db, "elec", yd, fid=app.config["F1"], grp="PM")
    assert d3["level"] == "line" and [r["name"] for r in d3["rows"]] == ["L1"]
    assert d["heat"] and d["heat_max"] == 15
    tok = login(client, "t_admin")
    page = client.get("/energy/live/", query_string={"day": yd.isoformat()}).get_data(as_text=True)
    assert "รายช่วงเวลา" in page and "chLoad" in page and "lv-data" in page
    w = client.get("/energy/live/", query_string={"kind": "water"}).get_data(as_text=True)
    assert "ไม่มีมิเตอร์" in w or "ยังไม่มีค่ารายช่วงเวลา" in w
    assert client.get("/energy/live/", query_string={"factory": app.config["F1"], "grp": "PM", "line": "L1",
                                                    "day": yd.isoformat(), "cmp": "week"}).status_code == 200
    _ = tok


def test_switch_kind_and_backfill(app, db, client, tmp_path):
    sid, a, b, path = _setup(app, db, tmp_path, kind="reading")
    yd = S.now_dt().date() - timedelta(days=1)
    db.execute("INSERT INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,?,?)", (a, yd.isoformat(), 2157641728.0, "scada", ts()))
    db.commit()
    tok = login(client, "t_admin")
    src = ES.get_source(db, sid)
    data = {"csrf_token": tok, "name": "DL", "kind": "sqlite", "interval_min": "15", "ts_shift_min": "0", "late_min": "180",
            "value_kind": "interval", "active": "1", "reapply_days": "3", "cfg.path": path, "cfg.query": src["config"]["query"],
            "cfg.backfill_days": "4"}
    r = client.post(f"/energy/sources/{sid}", data=data, follow_redirects=True)
    assert "เปลี่ยนชนิดค่า" in r.get_data(as_text=True)
    assert ES.get_source(db, sid)["value_kind"] == "interval"
    assert db.execute("SELECT MAX(value) FROM en_readings WHERE meter_id=?", (a,)).fetchone()[0] < 1e6
    assert db.execute("SELECT COUNT(*) FROM en_intervals WHERE meter_id=?", (a,)).fetchone()[0] >= 96 * 2
    r = ES.backfill(db, sid, yd - timedelta(days=2), yd, "replace", None)
    assert r["readings"] >= 2 and not r["no_data"]


def test_prune_keeps_cumulative(app, db, tmp_path):
    sid, a, b, _ = _setup(app, db, tmp_path)
    ES.run_source(db, sid, manual=True)
    db.commit()
    yd = (S.now_dt().date() - timedelta(days=1)).isoformat()
    before = db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (a, yd)).fetchone()[0]
    EI.prune(db, keep_days=2)
    db.execute("DELETE FROM en_readings WHERE meter_id=?", (a,))
    EI.rebuild_readings(db, [a], S.now_dt().date() - timedelta(days=1))
    assert abs(db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (a, yd)).fetchone()[0] - before) < 1e-6
