"""v0.83.1: หน้าตรวจสอบค่า SCADA — dialog แก้ค่าต้องบันทึกได้หลังเคยเตือนให้ใส่เหตุผล"""
from conftest import login
from test_v73 import _day, _hist, _rows, _setup

from ecs import connectors as CN
from ecs import srcmap as SM
from test_v73 import _at


def test_fix_dialog_validity_not_stuck(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid)
    db.commit()
    c = app.test_client()
    tok = login(c, "t_admin")
    q = {"from": day.isoformat(), "to": day.isoformat()}
    page = c.get(f"/admin/sources/{sid}/audit", query_string=q).get_data(as_text=True)
    # ข้อความเตือนต้องถูกล้างเมื่อพิมพ์ และเมื่อเปิด dialog ใหม่ (เดิมค้างจนกดบันทึกไม่ได้)
    assert "f.reason.addEventListener('input', () => f.reason.setCustomValidity(''))" in page
    assert "f.reason.value = ''; f.reason.setCustomValidity('')" in page
    assert "f.addEventListener('submit'" not in page
    # ค่าที่แก้นอกช่วงที่เป็นไปได้ของ Tag ยังบันทึกได้ (เหตุผลภาษาไทย)
    fid = published_form["form_id"]
    r = c.post(f"/admin/sources/{sid}/fix", data={"csrf_token": tok, "form_id": fid, "at": f"{day} 20:30:00", "item_key": "oil",
                                                 "act": "value", "value": "2.5", "reason": "ไม่ได้เดิน", **q})
    assert r.status_code in (302, 303)
    assert SM.fixes_at(db, sid, fid, _at(day, 20, 30))["value"] == {"oil": 2.5}
