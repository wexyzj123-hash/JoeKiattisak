"""v0.33 (ต่อจาก v0.32.0): ลบงานแก้ไข (CAPA) · หน้าแนวโน้มเป็นแดชบอร์ดรายเครื่อง (ทุกหัวข้อ + ผู้ตรวจ + NG สูงสุด)"""
from datetime import date, timedelta

from conftest import GOOD, login, payload, uid

from ecs import analytics as AN
from ecs import capa as C
from ecs import submissions as SUB


def _submit(app, db, form, answers):
    import io

    from conftest import png_bytes
    from werkzeug.datastructures import FileStorage
    photos = {"p1": FileStorage(io.BytesIO(png_bytes()), filename="p.png"), "p2": FileStorage(io.BytesIO(png_bytes()), filename="q.png")}
    SUB.create_submission(db, payload(form, answers), photos, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()


def test_delete_capa(app, db, published_form):
    admin = uid(db, "t_admin")
    a1 = C.create_action(db, {"title": "งานซ้ำ", "form_id": published_form["form_id"]}, admin)
    a2 = C.create_action(db, {"title": "งานเก็บไว้"}, admin)
    db.commit()
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get("/actions").get_data(as_text=True)
    assert 'id="delForm"' in page and "ลบที่เลือก" in page
    assert "ลบงานแก้ไขนี้" in c.get(f"/actions/{a1}").get_data(as_text=True)
    c.post("/actions/delete", data={"csrf_token": tok, "ids": [str(a1)], "reason": ""})
    assert db.execute("SELECT 1 FROM cs_actions WHERE id=?", (a1,)).fetchone()          # ต้องมีเหตุผล
    c.post("/actions/delete", data={"csrf_token": tok, "ids": [str(a1)], "reason": "สร้างซ้ำ"})
    assert not db.execute("SELECT 1 FROM cs_actions WHERE id=?", (a1,)).fetchone()
    assert db.execute("SELECT 1 FROM cs_actions WHERE id=?", (a2,)).fetchone()
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE entity='cs_actions' AND action='delete' AND entity_id=?", (a1,)).fetchone()[0] == 1
    t = app.test_client()
    tt = login(t, "t_tech")
    assert t.post("/actions/delete", data={"csrf_token": tt, "ids": [str(a2)], "reason": "x"}).status_code in (302, 403)
    assert db.execute("SELECT 1 FROM cs_actions WHERE id=?", (a2,)).fetchone()
    assert 'id="delForm"' not in t.get("/actions").get_data(as_text=True)


def test_machine_dashboard(app, db, published_form):
    fid = published_form["form_id"]
    _submit(app, db, published_form, GOOD)
    _submit(app, db, published_form, {**GOOD, "oil": {"value": "3.1", "remark": "สูง", "photos": ["p1"]}, "hour": {"value": "1010"},
                                      "noise": {"value": "NG", "remark": "ดัง", "photos": ["p2"]}})
    today = date.today()
    ov = AN.machine_overview(db, fid, today - timedelta(days=29), today)
    k = ov["kpi"]
    assert k["subs"] == 2 and k["n_items"] == 5 and k["types"]["numeric"] == 2 and k["types"]["okng"] == 1
    items = {i["item_key"]: i for i in ov["items"]}
    assert items["oil"]["status"] == "ng" and items["oil"]["ng"] == 1 and len(items["oil"]["pts"]) == 2
    assert items["noise"]["hist"][-1][2] == "ng" and items["filter"]["status"] == "ok"
    assert ov["items"][0]["status"] == "ng"                                              # ผิดปกติขึ้นก่อน
    assert ov["inspectors"][0]["n"] == 2 and ov["pareto"][0][1] == 1
    assert sum(ov["daily"]["subs"]) == 2 and sum(ov["daily"]["ng"]) == 1
    c = app.test_client()
    login(c, "t_sup")
    h = c.get(f"/trends?form={fid}").get_data(as_text=True)
    assert "แดชบอร์ดรายเครื่อง" in h and 'id="mc-grid"' in h and 'id="ov-data"' in h and "สถิติผู้ตรวจ" in h
    assert "เจาะลึกหัวข้อตัวเลข" in h and 'id="c-trend"' in h
    assert c.get("/static/js/machine.js").status_code == 200
