"""v0.99.6: หน้าภาพรวมเป็นแดชบอร์ดหน้าเดียว · กดการ์ด/แถว = แผงดูต่อ (data-od) · API ข้อมูลเครื่องสำหรับแผง"""
import json
import re

from conftest import login


def _ods(html):
    return [json.loads(m.replace("&#34;", '"').replace("&#39;", "'").replace("&amp;", "&"))
            for m in re.findall(r"data-od='([^']*)'", html)]


def test_dashboard_one_page_all_sections_and_drill_specs(client, published_form):
    login(client, "t_sup")
    html = client.get("/dashboard").get_data(as_text=True)
    for sec in ("areas", "todo", "mv", "cl", "ins-trend", "ins-mach", "hourly", "c-week", "c-comp", "ins-shift", "ins-docs", "ov-docs",
                "ov-today", "ov-deep", "ov-hist"):
        assert f'id="{sec}"' in html, sec
    assert html.count('class="kx lift"') == 6 and "js/drill.js" in html and "data-od-root" in html
    specs = _ods(html)
    assert len(specs) >= 6 and all(s["t"] in ("panel", "machine", "item") for s in specs)
    kpi = [s for s in specs if s["t"] == "panel" and s.get("links")]
    assert all(l[1].startswith("/") for s in kpi for l in s["links"])          # ทุกลิงก์ในแผงเป็นลิงก์ภายใน
    assert "<script" not in "".join(re.findall(r"data-od='([^']*)'", html))  # tojson กัน HTML ในข้อมูล


def test_dashboard_drill_spec_escapes_user_text(client, app, db, published_form):
    """ชื่อแบบฟอร์ม/แจ้งเตือนที่มีอักขระพิเศษ ต้องไม่หลุดออกจาก attribute"""
    db.execute("UPDATE cs_forms SET name=? WHERE id=?", ("Pump 'A' <b>x</b> & \"q\"", published_form["form_id"]))
    db.commit()
    login(client, "t_admin")
    html = client.get("/dashboard").get_data(as_text=True)
    assert "<b>x</b>" not in html
    for raw in re.findall(r"data-od='([^']*)'", html):
        assert "'" not in raw and "<" not in raw


def test_equipment_drill_api(client, app, db, published_form):
    from conftest import payload, uid, GOOD
    from ecs import submissions as SUB
    SUB.create_submission(db, payload({"form_id": published_form["form_id"], "version_id": published_form["version_id"]}, GOOD), {},
                          uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    eid = published_form["equipment_id"]
    login(client, "t_tech")
    d = client.get(f"/api/equipment/{eid}/drill?date=bad").get_json()
    assert d["machine"]["id"] == eid and d["machine"]["code"] and isinstance(d["rounds"], list)
    assert d["items"] and {"name", "last", "judgement", "values", "form_id", "item_key"} <= set(d["items"][0])
    assert d["links"]["m360"].endswith(f"/machines/{eid}") and d["links"]["latest"].startswith("/submissions/")
    for u in d["links"].values():
        if u:
            assert client.get(u).status_code == 200, u
    assert client.get("/api/equipment/999999/drill").status_code == 404


def test_equipment_drill_requires_login(app):
    c = app.test_client()
    r = c.get("/api/equipment/1/drill")
    assert r.status_code in (302, 401)


def test_machine_list_has_equipment_id(app, db, published_form):
    from conftest import payload, uid, GOOD
    from ecs import analytics as AN
    from ecs import submissions as SUB
    SUB.create_submission(db, payload({"form_id": published_form["form_id"], "version_id": published_form["version_id"]}, GOOD), {},
                          uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    rows = AN.machine_list(db)
    assert rows and rows[0]["equipment_id"] == published_form["equipment_id"]
