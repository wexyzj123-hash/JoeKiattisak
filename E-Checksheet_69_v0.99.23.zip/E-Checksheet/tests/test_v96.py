"""v0.96: หน้าแนวโน้มแสดง % คุณภาพเฉพาะเครื่องที่เลือก · การ์ดคุณภาพรวมในหน้าภาพรวม → หน้าคุณภาพทุกเครื่อง"""
from datetime import datetime, timedelta

from conftest import login, uid
from ecs import insights as IN
from ecs import masterdata as M
from ecs import services as S
from test_v94 import TODAY, _seed


def _other_form(app, db):
    admin = uid(db, "t_admin")
    eq = M.save_equipment(db, {"code": "PMP09", "name": "Pump", "factory_id": app.config["F1"]}, admin)
    fid = S.create_form(db, {"name": "Daily Pump", "equipment_id": eq}, admin)
    d = S.get_draft(db, fid)
    S.save_draft_items(db, d["id"], [{"item_key": "amp", "name": "Motor Current", "item_type": "number", "unit": "A",
                                      "min_value": 1, "max_value": 20}], admin)
    S.publish_version(db, d["id"], admin)
    db.commit()
    return fid


def test_quality_form_filter(app, db, published_form):
    _seed(db, published_form)
    _other_form(app, db)
    q = IN.quality(db, TODAY - timedelta(days=29), TODAY, form_id=published_form["form_id"])
    assert [m["form_id"] for m in q["machines"]] == [published_form["form_id"]]


def test_trends_only_selected_and_dashboard_card(app, db, client, published_form):
    _seed(db, published_form)
    login(client, "t_admin")
    page = client.get("/trends", query_string={"form": published_form["form_id"], "days": 30}).get_data(as_text=True)
    assert "คุณภาพเครื่องนี้" in page and "ทุกโรงงาน" not in page.split('id="quality"')[1].split("</section>")[0]
    dash = client.get("/dashboard", query_string={"days": 30}).get_data(as_text=True)
    assert "คุณภาพเครื่องจักร (30 วัน)" in dash and "/quality?days=30" in dash and "90.0%" in dash
    q = client.get("/quality", query_string={"days": 30}).get_data(as_text=True)
    assert "ทุกเครื่อง" in q and "SCT0002" in q and f"/trends?form={published_form['form_id']}" in q
    x = client.get("/trends/quality.xlsx", query_string={"days": 30, "form": published_form["form_id"]})
    assert x.status_code == 200 and x.data[:2] == b"PK"
