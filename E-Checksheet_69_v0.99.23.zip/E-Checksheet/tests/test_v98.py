"""v0.98: เช็คชีทประจำวันเลือกวันที่ได้ + ลิงก์รอบ · กราฟ 7 วันกดได้ · รายผู้ตรวจแสดงเลย · หน้ารายงานแบบแดชบอร์ด"""
from conftest import login


def test_dashboard_checklist_and_people(client, db, published_form):
    login(client, "t_admin")
    page = client.get("/dashboard", query_string={"date": "2026-10-01"}).get_data(as_text=True)
    assert 'id="cl"' in page and 'name="date" value="2026-10-01"' in page and "#cl" in page
    assert "<details class=\"ins-people\"" not in page
    assert "link: (d) => U('/rounds?date='" in page
    js = client.get("/static/js/charts.js").get_data(as_text=True)
    assert "convertFromPixel" in js
    assert "rt-hl" in client.get("/rounds", query_string={"date": "2026-10-01"}).get_data(as_text=True)


def test_reports_dashboard(client, db, published_form):
    login(client, "t_admin")
    page = client.get("/reports").get_data(as_text=True)
    for s in ("rp-kpis", "data-kf=\"st:pending\"", "รายงานสรุป", "เปิดด่วน", "ข้อมูลดิบ", "fRaw", "sfMonth", "ตัวกรองเพิ่ม"):
        assert s in page, s
