"""หน้าเว็บ/สิทธิ์/ความปลอดภัย/ข้อมูลหลัก"""
import pytest

from conftest import PASSWORD, csrf_of, login, uid
from ecs import masterdata as M
from ecs import services as S


def test_first_run_setup(tmp_path):
    from ecs import create_app
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "x.db"), "UPLOAD_FOLDER": str(tmp_path / "u"), "ENABLE_JOBS": False})
    c = app.test_client()
    assert c.get("/login").headers["Location"].endswith("/setup")
    c.get("/setup")
    with c.session_transaction() as s:
        tok = s["_csrf"]
    r = c.post("/setup", data={"csrf_token": tok, "name": "Admin", "username": "boss", "password": "short", "confirm": "short"})
    assert "อย่างน้อย 8".encode() in r.data
    r = c.post("/setup", data={"csrf_token": tok, "name": "Admin", "username": "boss", "password": "Strong#123", "confirm": "Strong#123"})
    assert r.status_code == 302
    assert c.get("/setup").headers["Location"].endswith("/login")        # ใช้ได้ครั้งเดียว


def test_login_and_wrong_password_throttle(client):
    from ecs.views import auth
    auth._FAILED.clear()
    tok = csrf_of(client)
    for _ in range(auth.MAX_FAILS):
        r = client.post("/login", data={"username": "t_tech", "password": "nope", "csrf_token": tok})
        assert "ไม่ถูกต้อง".encode() in r.data
    r = client.post("/login", data={"username": "t_tech", "password": PASSWORD, "csrf_token": tok})
    assert "รอ 10 นาที".encode() in r.data
    auth._FAILED.clear()


def test_must_change_password_forced(client, db):
    M.save_user(db, {"username": "newbie", "name": "ใหม่", "role": "technician", "password": "Start#123"}, uid(db, "t_admin"))
    db.commit()
    tok = csrf_of(client)
    client.post("/login", data={"username": "newbie", "password": "Start#123", "csrf_token": tok})
    assert client.get("/m/").headers["Location"].endswith("/account/password")
    assert client.get("/api/m/tasks").status_code == 403
    client.get("/account/password")
    with client.session_transaction() as s:
        tok = s["_csrf"]
    r = client.post("/account/password", data={"csrf_token": tok, "current": "Start#123", "new": "Better#456", "confirm": "Better#456"})
    assert r.status_code == 302 and client.get("/m/").status_code == 200


def test_legacy_sha256_password_upgraded(client, db):
    import hashlib
    db.execute("UPDATE users SET password=? WHERE username='t_tech'", (hashlib.sha256(b"Old#12345").hexdigest(),))
    db.commit()
    login(client, "t_tech", "Old#12345")
    assert db.execute("SELECT password FROM users WHERE username='t_tech'").fetchone()[0].startswith("pbkdf2:")


@pytest.mark.parametrize("user,path,code", [
    ("t_tech", "/m/", 200), ("t_tech", "/approvals", 403), ("t_tech", "/admin/users", 403), ("t_tech", "/equipment/new", 403),
    ("t_view", "/m/", 403), ("t_view", "/submissions", 200), ("t_view", "/rounds", 200), ("t_view", "/forms/1/builder", 403),
    ("t_sup", "/approvals", 200), ("t_sup", "/admin/users", 403), ("t_sup", "/equipment/new", 200),
    ("t_admin", "/admin/users", 200), ("t_admin", "/admin/locations", 200),
])
def test_role_matrix(client, user, path, code):
    login(client, user)
    assert client.get(path).status_code == code


def test_anonymous_redirects(client):
    for p in ("/rounds", "/m/", "/forms", "/approvals"):
        r = client.get(p)
        assert r.status_code == 302 and "/login" in r.headers["Location"]
    assert client.get("/api/m/tasks").status_code == 401


def test_csrf_and_open_redirect(client):
    login(client, "t_admin")
    assert client.post("/forms", data={"name": "x"}).status_code == 400
    c2 = client.application.test_client()
    tok = csrf_of(c2)
    r = c2.post("/login", data={"username": "t_admin", "password": PASSWORD, "csrf_token": tok, "next": "//evil.com/x"})
    assert r.headers["Location"] in ("/", "http://localhost/")


def test_security_headers(client):
    r = client.get("/login")
    assert r.headers["X-Frame-Options"] == "SAMEORIGIN" and r.headers["X-Content-Type-Options"] == "nosniff"


def test_builder_publish_and_schedule(client, db, app):
    tok = login(client, "t_sup")
    h = {"X-CSRF-Token": tok}
    r = client.post("/forms", data={"name": "Daily Chiller", "factory_id": app.config["F1"], "csrf_token": tok})
    fid = int(r.headers["Location"].rstrip("/").split("/")[-2])
    vid = client.get(f"/api/forms/{fid}/draft").get_json()["version_id"]
    bad = client.put(f"/api/forms/{fid}/draft", headers=h, json={"version_id": vid, "items": [{"name": "", "item_type": "number", "min_value": 5, "max_value": 1}]})
    assert bad.status_code == 422
    ok = client.put(f"/api/forms/{fid}/draft", headers=h, json={"version_id": vid, "items": [
        {"name": "CHW supply", "item_type": "number", "unit": "°C", "min_value": 5, "max_value": 9}]})
    assert ok.status_code == 200
    assert client.post(f"/api/forms/{fid}/publish", headers=h, json={"note": "v1"}).get_json()["version_no"] == 1
    r = client.post(f"/forms/{fid}/schedules", data={"freq_type": "shift", "times": "08:00,20:00", "window_min": 120, "csrf_token": tok})
    assert r.status_code == 302
    assert db.execute("SELECT COUNT(*) FROM cs_schedules WHERE form_id=?", (fid,)).fetchone()[0] == 1
    # เปิดหน้า builder ไม่สร้างร่าง
    client.get(f"/forms/{fid}/builder")
    assert db.execute("SELECT COUNT(*) FROM cs_form_versions WHERE form_id=? AND status='draft'", (fid,)).fetchone()[0] == 0


def test_form_location_validation(db, app):
    other_area = M.save_area(db, {"factory_id": app.config["F2"], "name": "Chiller Plant"}, None)
    with pytest.raises(S.ValidationError):
        S.create_form(db, {"name": "x", "factory_id": app.config["F1"], "area_id": other_area}, None)


def test_equipment_crud_and_csv(client, db, app):
    tok = login(client, "t_admin")
    r = client.post("/equipment/new", data={"csrf_token": tok, "code": "PAC 102", "name": "แอร์ห้องชั่ง", "factory_id": app.config["F1"], "active": "1"})
    assert r.status_code == 302
    csv = "code,name,eq_type,factory,area,location\nCH-201,Chiller 201,Chiller,F2,Chiller Plant,\nPAC 102,แอร์ห้องชั่ง (แก้),AC,Factory 1,,\nBAD<,x,,F1,,\nX9,y,,F9,,\n"
    r = client.post("/equipment/import", data={"csrf_token": tok, "text": csv})
    assert r.status_code == 200
    assert db.execute("SELECT name FROM equipment WHERE code='PAC 102'").fetchone()[0] == "แอร์ห้องชั่ง (แก้)"
    assert db.execute("SELECT a.name FROM equipment e JOIN areas a ON a.id=e.area_id WHERE e.code='CH-201'").fetchone()[0] == "Chiller Plant"
    assert "ไม่พบโรงงาน".encode() in r.data and "บรรทัด 4".encode() in r.data
    eid = db.execute("SELECT id FROM equipment WHERE code='CH-201'").fetchone()[0]
    assert client.get(f"/equipment/{eid}").status_code == 200
    labels = client.get("/equipment/qr-labels?factory=%d" % app.config["F2"])
    assert b"<svg" in labels.data and b"CH-201" in labels.data
    old = db.execute("SELECT qr_token FROM equipment WHERE id=?", (eid,)).fetchone()[0]
    client.post(f"/equipment/{eid}/regenerate-qr", data={"csrf_token": tok})
    assert db.execute("SELECT qr_token FROM equipment WHERE id=?", (eid,)).fetchone()[0] != old


def test_last_admin_cannot_be_disabled(db):
    admin = uid(db, "t_admin")
    with pytest.raises(S.ValidationError):
        M.save_user(db, {"username": "t_admin", "name": "x", "role": "technician", "active": 1}, admin, admin)


def test_user_admin_pages(client, db):
    tok = login(client, "t_admin")
    r = client.post("/admin/users/new", data={"csrf_token": tok, "username": "tech9", "name": "ช่าง 9", "role": "technician",
                                              "password": "Tech#9999", "active": "1"})
    assert r.status_code == 302
    row = db.execute("SELECT must_change_pw, password FROM users WHERE username='tech9'").fetchone()
    assert row[0] == 1 and row[1].startswith("pbkdf2:")
    r = client.post("/admin/locations", data={"csrf_token": tok, "kind": "factory", "code": "F4", "name": "Factory 4"})
    assert db.execute("SELECT COUNT(*) FROM factories WHERE code='F4'").fetchone()[0] == 1


def test_rounds_page_and_api(client):
    login(client, "t_view")
    assert client.get("/rounds?date=2026-09-23").status_code == 200
    assert client.get("/api/rounds?date=bad").status_code == 400
