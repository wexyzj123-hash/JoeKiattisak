"""v0.9: จุดตรวจ (กลุ่มหัวข้อ + ตำแหน่ง) · ความถี่รายหัวข้อในแบบฟอร์มเดียว · ต้องแนบรูปหลักฐาน"""
import io
from datetime import datetime as D
from datetime import timedelta

import pytest
from conftest import login, payload, png_bytes, uid
from werkzeug.datastructures import FileStorage

from ecs import itemfreq as F
from ecs import masterdata as M
from ecs import services as S
from ecs import submissions as SUB

CAL = F.DEFAULT_CALENDAR


# ───────── ตรรกะความถี่ ─────────

def test_slot_and_due_rules():
    assert F.slot_start("shift", "", D(2026, 9, 24, 7, 0), CAL) == D(2026, 9, 23, 20, 0)
    assert F.slot_start("day", "", D(2026, 9, 24, 9, 0), CAL) == D(2026, 9, 24, 8, 0)
    assert F.slot_start("week", "", D(2026, 9, 24, 9, 0), CAL) == D(2026, 9, 21, 8, 0)
    assert F.slot_start("month", "", D(2026, 9, 1, 7, 0), CAL) == D(2026, 8, 1, 8, 0)
    # กะละครั้ง: ตรวจ 08:10 → รอบ 14:00 ไม่ขึ้น, รอบ 20:00 ขึ้น
    assert not F.is_due("shift", "", D(2026, 9, 24, 8, 10), D(2026, 9, 24, 14, 0), CAL)
    assert F.is_due("shift", "", D(2026, 9, 24, 8, 10), D(2026, 9, 24, 20, 0), CAL)
    # ตรวจก่อนเวลาเล็กน้อย (19:50) นับเป็นของกะ 20:00
    assert not F.is_due("shift", "", D(2026, 9, 24, 19, 50), D(2026, 9, 24, 20, 5), CAL)
    # ตามเวลา 08:00,14:00
    assert F.is_due("times", "08:00,14:00", D(2026, 9, 24, 8, 10), D(2026, 9, 24, 14, 1), CAL)
    assert not F.is_due("times", "08:00,14:00", D(2026, 9, 24, 8, 10), D(2026, 9, 24, 12, 0), CAL)
    assert F.is_due("", "", D(2026, 9, 24, 8, 10), D(2026, 9, 24, 8, 11), CAL)      # ทุกรอบ
    assert F.is_due("day", "", None, D(2026, 9, 24, 2, 0), CAL)
    assert F.grace("times", "08:00,09:00", CAL) == timedelta(minutes=15)
    assert F.next_slot("shift", "", D(2026, 9, 24, 21, 0), CAL) == D(2026, 9, 25, 8, 0)
    assert F.normalize("times", "8:00 20.00") == ("times", "08:00, 20:00")
    with pytest.raises(F.FreqError):
        F.normalize("times", "25:00")
    with pytest.raises(F.FreqError):
        F.normalize("hourly", "")


# ───────── Builder: บันทึก/คัดลอกเวอร์ชัน ─────────

def _form(app, db, items, hints=None):
    admin = uid(db, "t_admin")
    eq = M.save_equipment(db, {"code": "WWT-01", "name": "Wastewater", "factory_id": app.config["F1"]}, admin)
    fid = S.create_form(db, {"name": "Daily WWT", "equipment_id": eq}, admin)
    d = S.get_or_create_draft(db, fid, admin)
    S.save_draft_items(db, d["id"], items, admin)
    S.save_sections(db, d["id"], hints or [])
    S.publish_version(db, d["id"], admin)
    db.commit()
    return {"form_id": fid, "version_id": d["id"], "equipment_id": eq}


ITEMS = [
    {"item_key": "tank", "section": "DISCHARGE TANK", "name": "ถังไม่รั่ว", "item_type": "ok_ng"},
    {"item_key": "ph", "section": "DISCHARGE TANK", "name": "pH", "item_type": "number", "min_value": 6.2, "max_value": 8.5,
     "check_freq": "shift"},
    {"item_key": "clean", "section": "EVAPORATOR", "name": "ทำความสะอาดไส้กรอง", "item_type": "ok_ng", "check_freq": "day",
     "photo_required": 1},
]


def test_save_items_sections_and_copy(app, db):
    f = _form(app, db, ITEMS, [{"name": "DISCHARGE TANK", "hint": "ชั้น 2 หลังถัง"}])
    items = S.get_items(db, f["version_id"])
    assert [i["check_freq"] for i in items] == ["", "shift", "day"]
    assert items[2]["photo_required"] == 1
    secs = S.get_sections(db, f["version_id"])
    assert [(s["no"], s["name"], s["count"], s["hint"]) for s in secs] == [
        (1, "DISCHARGE TANK", 2, "ชั้น 2 หลังถัง"), (2, "EVAPORATOR", 1, "")]
    draft = S.get_or_create_draft(db, f["form_id"], uid(db, "t_admin"))       # ฉบับร่างใหม่คัดลอกครบ
    copied = S.get_items(db, draft["id"])
    assert [(i["check_freq"], i["photo_required"]) for i in copied] == [("", 0), ("shift", 0), ("day", 1)]
    assert S.get_sections(db, draft["id"])[0]["hint"] == "ชั้น 2 หลังถัง"
    with pytest.raises(S.ValidationError):
        S.save_draft_items(db, draft["id"], [dict(ITEMS[0], check_freq="times", check_times="")], None)


def test_draft_api_roundtrip(app, db):
    f = _form(app, db, ITEMS)
    client = app.test_client()
    tok = login(client, "t_sup")
    d = client.get(f"/api/forms/{f['form_id']}/draft").get_json()
    assert d["calendar"]["shift_times"] and d["sections"][0]["name"] == "DISCHARGE TANK"
    items = d["items"]
    items[0]["check_freq"], items[0]["check_times"] = "times", "08:00, 20:00"
    r = client.put(f"/api/forms/{f['form_id']}/draft", json={"items": items, "sections": [{"name": "EVAPORATOR", "hint": "หน้าเครื่อง"}]},
                   headers={"X-CSRF-Token": tok})
    assert r.status_code == 200, r.get_json()
    vid = r.get_json()["version_id"]
    assert S.get_items(db, vid)[0]["check_times"] == "08:00, 20:00"
    assert S.get_sections(db, vid)[1]["hint"] == "หน้าเครื่อง"
    assert client.get(f"/forms/{f['form_id']}/builder").status_code == 200


# ───────── การกรอก: ข้ามหัวข้อที่ยังไม่ถึงเวลา ─────────

def _submit(app, db, f, answers, files=None, when=None):
    p = payload(f, answers)
    if when:
        p["scanned_at"] = p["finished_at"] = when.strftime("%Y-%m-%d %H:%M:%S")
    return SUB.create_submission(db, p, files or {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"],
                                 now=when or S.now_dt())


def _photo():
    return {"p1": FileStorage(io.BytesIO(png_bytes()), filename="p.png", content_type="image/png")}


def test_not_due_items_skipped_and_photo_required(app, db):
    f = _form(app, db, ITEMS)
    t1 = D(2026, 9, 24, 8, 30)
    full = {"tank": {"value": "OK"}, "ph": {"value": "7"}, "clean": {"value": "OK"}}
    # ต้องมีรูปหลักฐาน
    with pytest.raises(S.ValidationError) as exc:
        _submit(app, db, f, full, when=t1)
    assert any("รูปหลักฐาน" in e for e in exc.value.errors)
    _submit(app, db, f, {**full, "clean": {"value": "OK", "photos": ["p1"]}}, _photo(), when=t1)
    db.commit()
    # 14:00 กะเดียวกัน วันเดียวกัน → ส่งเฉพาะ "ทุกรอบ" ได้
    res = _submit(app, db, f, {"tank": {"value": "OK"}}, when=D(2026, 9, 24, 14, 0))
    db.commit()
    assert db.execute("SELECT COUNT(*) FROM cs_answers WHERE submission_id=?", (res["id"],)).fetchone()[0] == 1
    # 20:00 กะใหม่ → pH ต้องกรอก, ไส้กรองยังไม่ต้อง (วันทำงานเดียวกัน)
    with pytest.raises(S.ValidationError) as exc:
        _submit(app, db, f, {"tank": {"value": "OK"}}, when=D(2026, 9, 24, 20, 5))
    assert any("pH" in e for e in exc.value.errors) and not any("ไส้กรอง" in e for e in exc.value.errors)
    # วันถัดไป 08:05 → ไส้กรองถึงเวลาอีกครั้ง
    with pytest.raises(S.ValidationError) as exc:
        _submit(app, db, f, {"tank": {"value": "OK"}, "ph": {"value": "7"}}, when=D(2026, 9, 25, 8, 5))
    assert any("ไส้กรอง" in e for e in exc.value.errors)


def test_package_has_freq_sections_calendar(app, db):
    f = _form(app, db, ITEMS, [{"name": "EVAPORATOR", "hint": "หน้าเครื่อง"}])
    pkg = SUB.form_package(db, f["form_id"])
    assert pkg["calendar"]["day_start"]
    assert {i["item_key"]: i["check_freq"] for i in pkg["items"]}["ph"] == "shift"
    assert pkg["items"][2]["photo_required"] == 1
    assert pkg["sections"][1] == {"name": "EVAPORATOR", "hint": "หน้าเครื่อง", "count": 1, "no": 2}


def test_work_calendar_admin(app, db):
    client = app.test_client()
    tok = login(client, "t_admin")
    assert client.get("/admin/work-calendar").status_code == 200
    client.post("/admin/work-calendar", data={"shift_times": "06:00,14:00,22:00", "day_start": "06:00", "csrf_token": tok})
    assert F.get_calendar(db)["shift_times"] == "06:00, 14:00, 22:00"
    client.post("/admin/work-calendar", data={"shift_times": "99:00", "day_start": "06:00", "csrf_token": tok})
    assert F.get_calendar(db)["shift_times"] == "06:00, 14:00, 22:00"
    c2 = app.test_client()
    login(c2, "t_sup")
    assert c2.get("/admin/work-calendar").status_code in (302, 403)


def test_detail_and_sheet_show_points_and_freq(app, db):
    f = _form(app, db, ITEMS, [{"name": "DISCHARGE TANK", "hint": "ชั้น 2 หลังถัง"}])
    client = app.test_client()
    login(client, "t_sup")
    body = client.get(f"/forms/{f['form_id']}").get_data(as_text=True)
    assert "ชั้น 2 หลังถัง" in body and "กะละ 1 ครั้ง" in body and "ต้องมีรูปหลักฐาน" in body
    body = client.get(f"/reports/sheets?form={f['form_id']}").get_data(as_text=True)
    assert "วันละ 1 ครั้ง" in body
