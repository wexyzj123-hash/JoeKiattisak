"""v0.34: รอบตรวจทุก N วัน/สัปดาห์/เดือน (ความถี่ที่ผู้ดูแลระบบเพิ่มเอง + 'เดือนละ 2 ครั้ง (ทุก 2 สัปดาห์)')"""
from datetime import date, datetime

from conftest import login, uid

from ecs import services as S


def test_interval_schedule_occurrences():
    base = {"skip_holidays": 0, "times": "08:00", "weekdays": "", "month_day": None}
    s = S.normalize_schedule({"freq_type": "w:2", "weekdays": ["0"], "times": "08:00", "anchor_date": "2026-09-28"})
    assert s["freq_type"] == "w:2" and s["weekdays"] == "0" and s["anchor_date"] == "2026-09-28"
    occ = [d.date() for d in S.occurrences({**base, **s}, date(2026, 9, 1), date(2026, 11, 30))]
    assert occ == [date(2026, 9, 28), date(2026, 10, 12), date(2026, 10, 26), date(2026, 11, 9), date(2026, 11, 23)]
    d3 = {**base, "freq_type": "d:3", "anchor_date": "2026-10-01"}
    assert [d.day for d in S.occurrences(d3, date(2026, 10, 1), date(2026, 10, 10))] == [1, 4, 7, 10]
    m3 = {**base, "freq_type": "m:3", "month_day": 5, "anchor_date": "2026-10-01"}
    assert [(d.month, d.day) for d in S.occurrences(m3, date(2026, 10, 1), date(2027, 4, 30))] == [(10, 5), (1, 5), (4, 5)]
    assert "ทุก 2 สัปดาห์ (จ.) 08:00 · นับรอบจาก 28/9/2569" in S.describe_schedule({**s, "window_min": 240})
    for bad in ({"freq_type": "w:2", "weekdays": []}, {"freq_type": "m:3", "month_day": 0}, {"freq_type": "x:3"}):
        try:
            S.normalize_schedule({"times": "08:00", **bad})
            raise AssertionError(bad)
        except S.ValidationError:
            pass


def test_interval_schedule_ui_and_rounds(app, db, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_admin")
    c.post("/admin/work-calendar", data={"csrf_token": tok, "action": "freqs", "f_label": ["ทุก 3 วัน"], "f_n": ["3"], "f_unit": ["d"]})
    page = c.get(f"/forms/{fid}").get_data(as_text=True)
    assert 'value="w:2"' in page and 'value="d:3"' in page and 'name="anchor_date"' in page and "+ เพิ่มความถี่" in page
    from datetime import timedelta
    today = S.now_dt().date() + timedelta(days=1)            # รอบแรกพรุ่งนี้ (รอบย้อนหลังก่อนเริ่มระบบไม่ถูกสร้าง)
    c.post(f"/forms/{fid}/schedules", data={"csrf_token": tok, "freq_type": "d:3", "times": "08:00", "window_min": "240",
                                            "anchor_date": today.isoformat()})
    row = db.execute("SELECT freq_type, anchor_date FROM cs_schedules WHERE form_id=?", (fid,)).fetchone()
    assert tuple(row) == ("d:3", today.isoformat())
    assert "ทุก 3 วัน" in c.get(f"/forms/{fid}").get_data(as_text=True)
    n = db.execute("SELECT COUNT(*) FROM cs_rounds WHERE form_id=?", (fid,)).fetchone()[0]
    assert n >= 1
    days = {r[0][:10] for r in db.execute("SELECT due_at FROM cs_rounds WHERE form_id=?", (fid,))}
    assert all((date.fromisoformat(d) - today).days % 3 == 0 for d in days)
