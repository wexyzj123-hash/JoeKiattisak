"""v0.27: ค้นหาใบบันทึกตามวันที่ตรวจ/พื้นที่ · วันที่ของเอกสารในหน้าลงนาม · หมวดรออนุมัติ 3 แท็บ"""
from datetime import date, datetime, timedelta

from conftest import GOOD, login, payload, uid

from ecs import services as S
from ecs import signoffs as SO
from ecs import submissions as SUB


def _sub(app, db, fid, day):
    pm = (date.today().replace(day=1) - timedelta(days=1)).replace(day=1)
    f = S.get_form(db, fid)
    SUB.create_submission(db, payload({"form_id": fid, "version_id": f["current_version_id"]}, GOOD), {}, uid(db, "t_tech"),
                          app.config["UPLOAD_FOLDER"], now=datetime(pm.year, pm.month, day, 9, 0))
    db.commit()
    return pm


def test_days_text():
    assert SO.days_text(date(2026, 9, 1), [5, 3, 4, 10, 12, 13]) == "3–5, 10, 12, 13 ก.ย."
    assert SO.days_text(date(2026, 9, 1), []) == ""


def test_report_index_search(app, db, published_form):
    fid = published_form["form_id"]
    pm = _sub(app, db, fid, 3)
    _sub(app, db, fid, 4)
    c = app.test_client()
    login(c, "t_sup")
    html = c.get(f"/reports?month={pm:%Y-%m}").get_data(as_text=True)
    assert 'id="sfFrom"' in html and 'data-days="3,4"' in html and "3, 4 " in html and "ทุกพื้นที่" in html
    assert "เลือกทั้งพื้นที่" not in html
    assert c.get("/reports?month=2099-01").status_code == 200          # เดือนอนาคต → เดือนปัจจุบัน


def test_signoff_dates_and_tabs(app, db, published_form):
    fid = published_form["form_id"]
    pm = _sub(app, db, fid, 9)
    SO.save_positions(db, {uid(db, "t_sup"): "srtech"}, None)
    db.commit()
    c = app.test_client()
    login(c, "t_sup")
    html = c.get(f"/signoffs?month={pm:%Y-%m}&mine=0").get_data(as_text=True)
    assert "ตรวจวันที่ 9 " in html and "appr-tabs" in html and "ผลตรวจรายครั้ง" in html and "อนุมัติรายสัปดาห์" in html
    ap = c.get("/approvals").get_data(as_text=True)
    assert "appr-tabs" in ap and "ลงนามใบบันทึก" in ap
    nav = c.get("/dashboard").get_data(as_text=True)
    assert nav.count(">ลงนามใบบันทึก<") == 0 or "appr-tabs" not in nav                  # ไม่มีเมนูแยกบนแถบบนแล้ว
