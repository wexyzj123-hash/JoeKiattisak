"""v0.80: ปุ่มตัวคูณ/ช่วงค่าที่เป็นไปได้รายแถว · คำแนะนำไม่มั่นใจไม่ดึง Tag เครื่องอื่นเข้ากลุ่ม"""
import sqlite3

from conftest import login

from ecs import connectors as CN
from ecs import services as S
from ecs import tagmatch as TM
from ecs.services import ts


def test_low_score_suggestion_not_grouped_and_range_button(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    path = str(tmp_path / "s.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    con.executemany("INSERT INTO h VALUES (?,?,?)", [(t, ts(S.now_dt()), 1) for t in ("d.SLT0008.TEMP1", "d.SLT0008.TEMP2")])
    con.commit()
    con.close()
    sid = CN.save_source(db, {"name": "S", "kind": "sqlite", "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ?"}}, None)
    CN.preview(db, sid)
    CN.save_mapping(db, sid, [{"tag": "d.SLT0008.TEMP1", "target": "", "scale": 1, "add_offset": 0, "valid_min": 0, "valid_max": 50}], None)
    db.commit()
    sug = {"d.SLT0008.TEMP1": {"target": f"{fid}:oil", "score": 45, "label": "x", "why": ""},
           "d.SLT0008.TEMP2": {"target": f"{fid}:oil", "score": 80, "label": "x", "why": ""}}
    g = TM.group_tags(db, sid, CN.list_tags(db, sid), sug)
    where = {r["tag"]: x["form_id"] for x in g["groups"] for r in x["tags"]}
    assert where["d.SLT0008.TEMP1"] is None and where["d.SLT0008.TEMP2"] == fid
    c = app.test_client()
    login(c, "t_admin")
    html = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert "tm-advbtn" in html and "ช่วง 0–50" in html and "ช่วงค่าที่เป็นไปได้" in html
