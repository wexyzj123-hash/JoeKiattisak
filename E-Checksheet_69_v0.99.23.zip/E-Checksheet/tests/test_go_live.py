"""tools/go_live.py — แก้ database.py ของ UT-CMMS แบบเฉพาะจุด และเติม .env โดยไม่ทับค่าเดิม"""
import os
import sqlite3

from tools import go_live as G


def _fake_cmms(tmp_path):
    d = tmp_path / "UT-CMMS"
    d.mkdir()
    src = "import sqlite3\ndef init_db(db):\n" + G.OLD_MIGRATION + "    x = '''\n" + G.OLD_COLS + "\n'''\n"
    (d / "database.py").write_text(src, encoding="utf-8")
    (d / "app.py").write_text("app = None\n", encoding="utf-8")
    con = sqlite3.connect(d / "utility_cmms.db")
    con.execute("CREATE TABLE t (x)")
    con.commit()
    con.close()
    return d


def test_patch_is_targeted_and_idempotent(tmp_path):
    d = _fake_cmms(tmp_path)
    assert G.patch_database_py(str(d)) == "patched"
    text = (d / "database.py").read_text(encoding="utf-8")
    assert G.PATCH_MARK in text and "__test__" not in text and "work_days TEXT" in text
    assert G.patch_database_py(str(d)) == "already"
    (d / "database.py").write_text("print('other version')\n", encoding="utf-8")
    assert G.patch_database_py(str(d)) == "not-found"


def test_backup_and_find(tmp_path, monkeypatch):
    d = _fake_cmms(tmp_path)
    assert G.find_cmms(str(d)) == str(d)
    monkeypatch.setattr(G, "ROOT", str(tmp_path / "E-Checksheet"))
    dest = G.backup(str(d))
    assert os.path.exists(os.path.join(dest, "utility_cmms.db")) and os.path.exists(os.path.join(dest, "database.py"))


def test_env_does_not_overwrite(tmp_path, monkeypatch):
    root = tmp_path / "E-Checksheet"
    root.mkdir()
    (root / ".env").write_text("PORTAL_PORT=5200\nCMMS_SECRET_KEY=keep-me\n", encoding="utf-8")
    monkeypatch.setattr(G, "ROOT", str(root))
    added = G.ensure_env(r"D:\sharing SCADA\Eweb\UT-CMMS", 5000)
    env = G.read_env(str(root / ".env"))
    assert env["PORTAL_PORT"] == "5200" and env["CMMS_SECRET_KEY"] == "keep-me"
    assert env["CMMS_DIR"] == r"D:\sharing SCADA\Eweb\UT-CMMS" and "CMMS_DIR" in added
    assert G.ensure_env("x", 5000) == []


def test_parse_netstat_listening_pids():
    from tools.stop_old import parse_listening_pids
    sample = """
Active Connections

  Proto  Local Address          Foreign Address        State           PID
  TCP    0.0.0.0:135            0.0.0.0:0              LISTENING       1016
  TCP    0.0.0.0:5000           0.0.0.0:0              LISTENING       4820
  TCP    0.0.0.0:50001          0.0.0.0:0              LISTENING       777
  TCP    192.168.1.5:5000       192.168.1.20:51234     ESTABLISHED     4820
  TCP    [::]:5000              [::]:0                 LISTENING       4820
  TCP    0.0.0.0:5100           0.0.0.0:0              LISTENING       5100
"""
    assert parse_listening_pids(sample, 5000) == [4820]
    assert parse_listening_pids(sample, 5100) == [5100]
    assert parse_listening_pids(sample, 8080) == []
