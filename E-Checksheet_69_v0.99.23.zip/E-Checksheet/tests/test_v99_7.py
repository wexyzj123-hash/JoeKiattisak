"""v0.99.7: การเคลื่อนไหวทั้งระบบ — แคปซูลเมนูเลื่อนแบบยืดหยุ่น (ชั้นตัวอักษรตัดตามแคปซูล) · เมนูซ้ายไหลตามเมาส์ · การ์ด 3 มิติ"""
from conftest import login


def test_motion_script_loaded_on_every_page(client):
    login(client, "t_sup")
    for path in ("/dashboard", "/rounds", "/alerts", "/forms"):
        html = client.get(path).get_data(as_text=True)
        assert "js/motion.js" in html, path
    js = client.get("/static/js/motion.js").get_data(as_text=True)
    assert "clipPath" in js and "prefers-reduced-motion" in js and "(hover: hover) and (pointer: fine)" in js
    assert "360" in js and "550" in js                                   # ขอบนำเร็วกว่า ขอบตามช้ากว่า
    assert "innerHTML" not in js                                        # สร้างองค์ประกอบด้วย DOM เท่านั้น


def test_motion_css_layers_and_reduced_motion(client):
    css = client.get("/static/css/app.css").get_data(as_text=True)
    blk = css[css.index("v0.99.7 การเคลื่อนไหวทั้งระบบ"):]
    for sel in (".gl-ink", ".gl-inv", ".gl-pill > .gl", ".tilt3d", ".sidenav.gl-hover", ".gl-rel"):
        assert sel in blk, sel
    assert "prefers-reduced-motion: reduce" in blk and "@media print" in blk
    assert ".gl-on { isolation: isolate; }" in blk and "position: relative; isolation" not in blk   # ไม่ทับ position:fixed ของเมนูซ้าย
