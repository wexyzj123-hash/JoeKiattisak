"""v0.8: ใบบันทึกผลทางการ (รายเดือน/รายครั้ง) · รูปทุกรูปแบบ+ลดขนาด · Import หัวข้อจาก PDF/Excel ·
ลบเครื่องจักร · ค้นหา/กรองแบบฟอร์ม (ผูกเครื่องแล้ว/ยังไม่ผูก)"""
import io
from datetime import date

import pytest
from conftest import GOOD, login, payload, png_bytes, uid
from werkzeug.datastructures import FileStorage

from ecs import imaging
from ecs import item_import as II
from ecs import masterdata as M
from ecs import services as S
from ecs import submissions as SUB

PIL = pytest.importorskip("PIL.Image")


def _img(fmt, size=(3000, 2000), mode="RGB"):
    buf = io.BytesIO()
    PIL.new(mode, size, (200, 30, 30) if mode == "RGB" else (200, 30, 30, 128)).save(buf, fmt)
    return buf.getvalue()


def _submit(app, db, form, ans=None, photo=None):
    ans = dict(ans or GOOD)
    files = {}
    if photo is not None:
        ans["noise"] = {"value": "NG", "remark": "เสียงดัง", "photos": ["p1"]}
        files = {"p1": FileStorage(io.BytesIO(photo), filename="IMG_0001.HEIC", content_type="application/octet-stream")}
    res = SUB.create_submission(db, payload(form, ans), files, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    return res


# ───────── รูปภาพ ─────────

@pytest.mark.parametrize("fmt", ["PNG", "BMP", "TIFF", "GIF", "WEBP", "JPEG"])
def test_process_any_format_shrinks_to_jpeg(fmt):
    data = _img(fmt, mode="RGB" if fmt != "GIF" else "RGB")
    assert imaging.sniff(data[:16]) is not None
    out, ext = imaging.process(data)
    assert ext == "jpg" and out[:3] == b"\xff\xd8\xff"
    im = PIL.open(io.BytesIO(out))
    assert max(im.size) == 1600 and im.size == (1600, 1067)


def test_process_transparent_png_and_keep_png():
    data = _img("PNG", (500, 400), "RGBA")
    out, ext = imaging.process(data)
    assert ext == "jpg" and PIL.open(io.BytesIO(out)).mode == "RGB"
    out, ext = imaging.process(data, keep_png=True)
    assert ext == "png"


def test_process_heic_when_available():
    if not imaging.HAS_HEIF:
        pytest.skip("pillow-heif not installed")
    buf = io.BytesIO()
    PIL.new("RGB", (4032, 3024), (10, 120, 200)).save(buf, "HEIF")
    data = buf.getvalue()
    assert imaging.sniff(data[:16]) == "heic"
    out, ext = imaging.process(data)
    assert ext == "jpg" and PIL.open(io.BytesIO(out)).size == (1600, 1200)


def test_process_rejects_non_image():
    with pytest.raises(imaging.ImageError):
        imaging.process(b"%PDF-1.4 not an image")
    with pytest.raises(imaging.ImageError):
        imaging.process(b"\x89PNG\r\n\x1a\n" + b"broken" * 10)


def test_big_photo_upload_is_reduced(app, db, published_form):
    big = _img("PNG", (4000, 3000))
    res = _submit(app, db, published_form, photo=big)
    path = db.execute("SELECT file_path FROM cs_photos WHERE submission_id=?", (res["id"],)).fetchone()[0]
    assert path.endswith(".jpg")
    import os
    full = os.path.join(app.config["UPLOAD_FOLDER"], path)
    assert os.path.getsize(full) < len(big)
    assert max(PIL.open(full).size) == 1600


# ───────── Import หัวข้อ ─────────

def test_parse_spec_variants():
    assert II.parse_spec("1.7-2.5 bar")[:3] == ("bar", "1.7", "2.5")
    assert II.parse_spec("≤ 80 °C")[1:3] == ("", "80")
    assert II.parse_spec("ไม่น้อยกว่า 5 kg/cm2")[1:3] == ("5", "")


def test_extract_text_csv_xlsx():
    txt = "No. Item Standard\n1. Oil Pressure 1.7-2.5 bar\nระบบไฟฟ้า:\n2. Voltage 380-420 V\nผู้ตรวจ ______\n"
    r = II.extract("list.txt", txt.encode())
    assert r["count"] == 2
    assert "Oil Pressure | bar | 1.7 | 2.5" in r["text"]
    assert "Voltage | V | 380 | 420" in r["text"]

    csv = "หัวข้อ,หน่วย,Min,Max\nแรงดันลม,bar,6,8\nอุณหภูมิ,°C,,45\n"
    r = II.extract("items.csv", csv.encode("utf-8-sig"))
    assert r["count"] == 2 and "แรงดันลม | bar | 6 | 8" in r["text"]

    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["No", "Check item", "Unit", "Min", "Max"])
    ws.append([1, "Water level", "%", 40, 90])
    ws.append([2, "Pump noise", None, None, None])
    buf = io.BytesIO()
    wb.save(buf)
    r = II.extract("items.xlsx", buf.getvalue())
    assert r["count"] == 2 and "Water level | % | 40 | 90" in r["text"]


def test_extract_pdf_and_api(app, db, published_form):
    from ecs.pdf import find_browser, html_to_pdf
    if not find_browser():
        pytest.skip("no browser for PDF")
    html = "<html><body><h3>Daily check</h3><p>1. Oil Pressure 1.7-2.5 bar</p><p>2. Motor temp ไม่เกิน 80 °C</p></body></html>"
    pdf = html_to_pdf(html)
    r = II.extract("sheet.pdf", pdf)
    assert r["count"] >= 2 and "Oil Pressure" in r["text"]
    client = app.test_client()
    tok = login(client, "t_sup")
    fid = published_form["form_id"]
    resp = client.post(f"/api/forms/{fid}/import-items", data={"file": (io.BytesIO(pdf), "sheet.pdf")},
                       headers={"X-CSRF-Token": tok}, content_type="multipart/form-data")
    assert resp.status_code == 200 and resp.get_json()["count"] >= 2
    bad = client.post(f"/api/forms/{fid}/import-items", data={"file": (io.BytesIO(b"xx"), "a.exe")},
                      headers={"X-CSRF-Token": tok}, content_type="multipart/form-data")
    assert bad.status_code == 400


# ───────── ลบเครื่องจักร ─────────

def test_delete_equipment_keep_forms(app, db, published_form):
    res = _submit(app, db, published_form)
    eq, fid = published_form["equipment_id"], published_form["form_id"]
    client = app.test_client()
    tok = login(client, "t_admin")
    chk = client.get(f"/api/equipment/delete-check?ids={eq}").get_json()
    assert chk
    r = client.post("/equipment/delete", data={"ids": eq, "forms": "keep", "csrf_token": tok})
    assert r.status_code == 302
    assert M.get_equipment(db, eq) is None
    f = S.get_form(db, fid)
    assert f is not None and f["equipment_id"] is None
    assert db.execute("SELECT equipment_id FROM cs_submissions WHERE id=?", (res["id"],)).fetchone()[0] is None
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE action='delete' AND entity='equipment'").fetchone()[0] == 1


def test_delete_equipment_with_forms_and_permissions(app, db, published_form):
    eq, fid = published_form["equipment_id"], published_form["form_id"]
    c2 = app.test_client()
    tok2 = login(c2, "t_sup")
    c2.post("/equipment/delete", data={"ids": eq, "forms": "delete", "csrf_token": tok2})
    assert M.get_equipment(db, eq) is not None          # หัวหน้างานลบไม่ได้
    client = app.test_client()
    tok = login(client, "t_admin")
    client.post("/equipment/delete", data={"ids": eq, "forms": "delete", "csrf_token": tok})
    assert M.get_equipment(db, eq) is None
    assert db.execute("SELECT COUNT(*) FROM cs_forms WHERE id=?", (fid,)).fetchone()[0] == 0


def test_equipment_list_filters(app, db, published_form):
    M.save_equipment(db, {"code": "PMP-01", "name": "Pump", "factory_id": app.config["F1"], "eq_type": "Pump"},
                     uid(db, "t_admin"))
    db.commit()
    client = app.test_client()
    login(client, "t_admin")
    body = client.get("/equipment?forms=no").get_data(as_text=True)
    assert "PMP-01" in body and "SCT0002" not in body
    body = client.get("/equipment?forms=yes").get_data(as_text=True)
    assert "SCT0002" in body and "PMP-01" not in body


# ───────── ค้นหา/กรองแบบฟอร์ม ─────────

def test_forms_filter_bind_and_bind_action(app, db, published_form):
    admin = uid(db, "t_admin")
    loose = S.create_form(db, {"name": "Loose form"}, admin)
    db.commit()
    client = app.test_client()
    tok = login(client, "t_sup")
    body = client.get("/forms?bind=no").get_data(as_text=True)
    assert "Loose form" in body and "Daily AC" not in body
    body = client.get("/forms?bind=yes").get_data(as_text=True)
    assert "Daily AC" in body and "Loose form" not in body
    assert "Daily AC" in client.get("/forms?q=Air+Compressor").get_data(as_text=True)
    assert "Loose form" in client.get("/forms?status=draft").get_data(as_text=True)
    r = client.post(f"/forms/{loose}/bind", data={"equipment": "SCT0002 — Air Compressor", "csrf_token": tok})
    assert r.status_code == 302
    assert S.get_form(db, loose)["equipment_id"] == published_form["equipment_id"]


# ───────── ใบบันทึกผลทางการ ─────────

def test_month_sheet_html_xlsx(app, db, published_form):
    _submit(app, db, published_form)
    fid = published_form["form_id"]
    month = date.today().strftime("%Y-%m")
    client = app.test_client()
    login(client, "t_sup")
    r = client.get(f"/reports/sheets?form={fid}&month={month}")
    body = r.get_data(as_text=True)
    assert r.status_code == 200
    assert "Oil Pressure" in body and "1.7" in body and "2.1" in body
    assert f"{S.get_form(db, fid)['code']}-{month.replace('-', '')}" in body
    r = client.get(f"/reports/sheets?form={fid}&month={month}&format=xlsx")
    assert r.status_code == 200 and r.data[:2] == b"PK"
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(r.data))
    assert len(wb.sheetnames) == 1
    r = client.get(f"/reports/sheets?all=1&month={month}")
    assert r.status_code == 200 and "Oil Pressure" in r.get_data(as_text=True)
    assert client.get("/reports/sheets").status_code == 302


def test_record_and_verify_code_stable(app, db, published_form):
    res = _submit(app, db, published_form, photo=png_bytes())
    client = app.test_client()
    login(client, "t_sup")
    a = client.get(f"/submissions/{res['id']}/record").get_data(as_text=True)
    assert "R%06d" % res["id"] in a and "เสียงดัง" in a
    from ecs import sheet_report as SR
    d1 = SR.build_record(db, res["id"], "k", "x")
    d2 = SR.build_record(db, res["id"], "k", "y")
    assert d1["verify"] == d2["verify"] and SR.build_record(db, res["id"], "other", "x")["verify"] != d1["verify"]
    assert client.get("/submissions/999999/record").status_code == 404
    # ปุ่มพิมพ์บนหน้ารายละเอียด
    assert f"/submissions/{res['id']}/record" in client.get(f"/submissions/{res['id']}").get_data(as_text=True)


def test_month_sheet_pdf(app, db, published_form):
    from ecs.pdf import find_browser
    if not find_browser():
        pytest.skip("no browser for PDF")
    _submit(app, db, published_form)
    client = app.test_client()
    login(client, "t_sup")
    r = client.get(f"/reports/sheets?form={published_form['form_id']}&format=pdf")
    assert r.status_code == 200 and r.data[:4] == b"%PDF"


def test_fix_thai_pdf_glyphs_and_numbering():
    assert II.fix_thai("ไมเกิน") == "ไม่เกิน"
    assert II.fix_thai("ผูตรวจ") == "ผู้ตรวจ"
    assert II.parse_line("3เสียงผิดปกติ") == ("item", "เสียงผิดปกติ")
