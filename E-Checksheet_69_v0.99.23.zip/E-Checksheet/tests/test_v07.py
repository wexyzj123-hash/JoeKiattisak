"""v0.7: ลบแบบฟอร์ม · ตำแหน่งแบบฟอร์มตามเครื่องจักร (ผังพื้นที่) · QR ตาม IP ที่เปิด · ธีมสี · หน้าจัดการพื้นที่"""
import os

from conftest import GOOD, PASSWORD, login, payload, png_bytes, uid

from ecs import masterdata as M
from ecs import services as S
from ecs import submissions as SUB


def _submit_ng(app, db, form):
    ans = dict(GOOD)
    ans["noise"] = {"value": "NG", "remark": "เสียงดัง", "photos": ["p1"]}
    import io

    from werkzeug.datastructures import FileStorage
    photo = FileStorage(io.BytesIO(png_bytes()), filename="p1.png", content_type="image/png")
    res = SUB.create_submission(db, payload(form, ans), {"p1": photo}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    return res


# ───────── ลบแบบฟอร์ม ─────────

def test_delete_form_removes_everything_and_files(app, db, published_form):
    res = _submit_ng(app, db, published_form)
    fid = published_form["form_id"]
    photo = db.execute("SELECT file_path FROM cs_photos WHERE submission_id=?", (res["id"],)).fetchone()[0]
    assert os.path.exists(os.path.join(app.config["UPLOAD_FOLDER"], photo))
    # CAPA จากแบบฟอร์มนี้ต้องยังอยู่หลังลบ
    from ecs import capa
    alert = db.execute("SELECT id FROM cs_alerts WHERE form_id=?", (fid,)).fetchone()
    if alert:
        action_id = capa.create_from_alert(db, alert[0], uid(db, "t_admin"))
        db.commit()
    impact = S.form_delete_impact(db, [fid])[0]
    assert impact["submissions"] == 1
    client = app.test_client()
    tok = login(client, "t_admin")
    r = client.get(f"/api/forms/delete-check?ids={fid}")
    assert r.get_json()["forms"][0]["allowed"] is True
    # มีผลตรวจ → ต้องยืนยัน
    r = client.post("/forms/delete", data={"ids": fid, "csrf_token": tok})
    assert db.execute("SELECT COUNT(*) FROM cs_forms WHERE id=?", (fid,)).fetchone()[0] == 1
    r = client.post("/forms/delete", data={"ids": fid, "confirm_history": "1", "csrf_token": tok})
    assert r.status_code == 302
    for table in ("cs_forms", "cs_form_versions", "cs_schedules", "cs_rounds", "cs_submissions", "cs_alerts"):
        col = "id" if table == "cs_forms" else "form_id"
        assert db.execute(f"SELECT COUNT(*) FROM {table} WHERE {col}=?", (fid,)).fetchone()[0] == 0, table
    assert db.execute("SELECT COUNT(*) FROM cs_answers").fetchone()[0] == 0
    assert not os.path.exists(os.path.join(app.config["UPLOAD_FOLDER"], photo))
    if alert:
        row = db.execute("SELECT alert_id, form_id FROM cs_actions WHERE id=?", (action_id,)).fetchone()
        assert row is not None and row[0] is None and row[1] is None       # CAPA ยังอยู่ ตัดลิงก์ออก
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE action='delete' AND entity='cs_forms'").fetchone()[0] == 1


def test_supervisor_cannot_delete_form_with_history(app, db, published_form):
    _submit_ng(app, db, published_form)
    fid = published_form["form_id"]
    client = app.test_client()
    tok = login(client, "t_sup")
    assert client.get(f"/api/forms/delete-check?ids={fid}").get_json()["forms"][0]["allowed"] is False
    client.post("/forms/delete", data={"ids": fid, "confirm_history": "1", "csrf_token": tok})
    assert db.execute("SELECT COUNT(*) FROM cs_forms WHERE id=?", (fid,)).fetchone()[0] == 1
    # แบบฟอร์มใหม่ที่ยังไม่มีผลตรวจ หัวหน้างานลบได้
    new_id = S.create_form(db, {"name": "ทดลอง"}, uid(db, "t_sup"))
    db.commit()
    client.post("/forms/delete", data={"ids": new_id, "csrf_token": tok})
    assert db.execute("SELECT COUNT(*) FROM cs_forms WHERE id=?", (new_id,)).fetchone()[0] == 0
    # ช่างลบไม่ได้
    c2 = app.test_client()
    tok2 = login(c2, "t_tech")
    assert c2.post("/forms/delete", data={"ids": fid, "csrf_token": tok2}).status_code in (302, 403)
    assert db.execute("SELECT COUNT(*) FROM cs_forms WHERE id=?", (fid,)).fetchone()[0] == 1


def test_bulk_delete_several_forms(app, db):
    admin = uid(db, "t_admin")
    ids = [S.create_form(db, {"name": f"F{i}"}, admin) for i in range(3)]
    db.commit()
    client = app.test_client()
    tok = login(client, "t_admin")
    r = client.post("/forms/delete", data={"ids": [str(i) for i in ids[:2]], "csrf_token": tok}, follow_redirects=True)
    assert "ลบแบบฟอร์มแล้ว 2 รายการ" in r.get_data(as_text=True)
    assert [r[0] for r in db.execute("SELECT id FROM cs_forms")] == [ids[2]]


# ───────── ตำแหน่งแบบฟอร์ม = ตำแหน่งเครื่องจักร ─────────

def _areas(db, app):
    a1 = M.save_area(db, {"factory_id": app.config["F1"], "name": "Compressor Room"}, None)
    a2 = M.save_area(db, {"factory_id": app.config["F1"], "name": "Boiler Room"}, None)
    b1 = M.save_area(db, {"factory_id": app.config["F2"], "name": "F2 Room"}, None)
    db.commit()
    return a1, a2, b1


def test_moving_equipment_moves_its_forms_and_map_status(app, db, published_form):
    a1, a2, _ = _areas(db, app)
    eq, fid = published_form["equipment_id"], published_form["form_id"]
    e = M.get_equipment(db, eq)
    M.save_equipment(db, {**e, "area_id": a1}, uid(db, "t_admin"), eq)
    db.commit()
    assert db.execute("SELECT area_id FROM cs_forms WHERE id=?", (fid,)).fetchone()[0] == a1
    from datetime import date

    from ecs.analytics import area_status
    st = {a["id"]: a for a in area_status(db, date.today(), app.config["F1"])}
    assert st[a1]["eq_count"] == 1 and st[a1]["status"] != "none"
    # เลือกพื้นที่ในหน้าแบบฟอร์ม = ย้ายเครื่องด้วย
    S.update_form_meta(db, fid, {"area_id": a2}, uid(db, "t_admin"))
    db.commit()
    assert M.get_equipment(db, eq)["area_id"] == a2
    assert db.execute("SELECT area_id FROM cs_forms WHERE id=?", (fid,)).fetchone()[0] == a2


def test_startup_sync_fixes_inconsistent_locations(app, db, published_form):
    a1, a2, _ = _areas(db, app)
    eq, fid = published_form["equipment_id"], published_form["form_id"]
    # ข้อมูลเก่า: แบบฟอร์มมีพื้นที่ แต่เครื่องไม่มี
    db.execute("UPDATE equipment SET area_id=NULL WHERE id=?", (eq,))
    db.execute("UPDATE cs_forms SET area_id=? WHERE id=?", (a1, fid))
    db.commit()
    from ecs.schema import ensure_schema
    ensure_schema(db)
    assert M.get_equipment(db, eq)["area_id"] == a1
    # ข้อมูลเก่า: เครื่องย้ายแล้ว แต่แบบฟอร์มค้างพื้นที่เดิม → ตามเครื่อง
    db.execute("UPDATE equipment SET area_id=? WHERE id=?", (a2, eq))
    db.commit()
    ensure_schema(db)
    assert db.execute("SELECT area_id FROM cs_forms WHERE id=?", (fid,)).fetchone()[0] == a2


def test_area_page_assigns_existing_equipment(app, db, published_form):
    a1, _, b1 = _areas(db, app)
    admin = uid(db, "t_admin")
    other = M.save_equipment(db, {"code": "P-01", "name": "Pump", "factory_id": app.config["F2"], "area_id": b1}, admin)
    db.commit()
    client = app.test_client()
    tok = login(client, "t_sup")
    html = client.get(f"/admin/areas/{a1}").get_data(as_text=True)
    assert "SCT0002" in html and "P-01" in html
    client.post(f"/admin/areas/{a1}", data={"action": "add_eq", "ids": [str(published_form["equipment_id"]), str(other)],
                                            "csrf_token": tok})
    rows = {r["code"]: r for r in M.list_equipment(db)}
    assert rows["SCT0002"]["area_id"] == a1 and rows["P-01"]["area_id"] == a1
    assert rows["P-01"]["factory_id"] == app.config["F1"]           # ย้ายข้ามโรงงานตามพื้นที่
    assert db.execute("SELECT area_id FROM cs_forms WHERE id=?", (published_form["form_id"],)).fetchone()[0] == a1
    client.post(f"/admin/areas/{a1}", data={"action": "remove_eq", "ids": str(other), "csrf_token": tok})
    assert M.get_equipment(db, other)["area_id"] is None
    # แดชบอร์ด: พื้นที่ที่ยังไม่วางหมุด (มีรูปผังแล้ว) ต้องยังเห็นเป็นกล่องสถานะ
    db.execute("UPDATE factories SET layout_image='layouts/x.png' WHERE id=?", (app.config["F1"],))
    db.commit()
    dash = client.get("/dashboard").get_data(as_text=True)
    assert "ab-tile" in dash and "Compressor Room" in dash          # v0.99.3 ทุกพื้นที่อยู่ในการ์ดสถานะรายพื้นที่ (เดิมเป็นแผ่น pm-unplaced ใต้ผัง)


def test_area_moved_to_other_factory_moves_equipment(app, db, published_form):
    a1, _, _ = _areas(db, app)
    eq = published_form["equipment_id"]
    e = M.get_equipment(db, eq)
    M.save_equipment(db, {**e, "area_id": a1}, None, eq)
    M.save_area(db, {"factory_id": app.config["F2"], "name": "Compressor Room"}, None, a1)
    db.commit()
    assert M.get_equipment(db, eq)["factory_id"] == app.config["F2"]
    assert db.execute("SELECT factory_id FROM cs_forms WHERE id=?", (published_form["form_id"],)).fetchone()[0] == app.config["F2"]


# ───────── QR ตาม IP ที่เปิดอยู่ ─────────

def test_qr_uses_host_being_used(app, db, published_form):
    from ecs.views.admin import qr_bases, qr_url
    token = M.get_equipment(db, published_form["equipment_id"])["qr_token"]
    for host in ("192.168.133.129:5000", "10.10.1.5:5000"):
        with app.test_request_context("/equipment/1", base_url=f"http://{host}"):
            assert qr_url(token) == f"http://{host}/e/{token}"        # IP ที่กำลังเปิดอยู่ ไม่ล็อค IP
    # ระบบรวม (/echeck) — ต้องมี prefix ใน QR
    with app.test_request_context("/equipment/1", base_url="http://10.10.1.5:5000/echeck"):
        assert qr_url(token) == f"http://10.10.1.5:5000/echeck/e/{token}"
        bases = qr_bases()
        assert bases[0] == "http://10.10.1.5:5000/echeck"
    # เลือก IP อื่นจากรายการได้ด้วย ?base= (ค่าที่ไม่อยู่ในรายการไม่รับ)
    with app.test_request_context("/equipment/1?base=http://evil.example", base_url="http://10.10.1.5:5000"):
        assert qr_url(token).startswith("http://10.10.1.5:5000/")
    app.config["QR_BASE_URL"] = "http://utility-server:5000"            # บังคับค่าคงที่ (เช่น ชื่อเครื่องใน DNS)
    with app.test_request_context("/equipment/1", base_url="http://10.10.1.5:5000"):
        assert qr_url(token) == f"http://utility-server:5000/e/{token}"
    app.config["QR_BASE_URL"] = ""
    client = app.test_client()
    login(client, "t_admin")
    html = client.get("/equipment/qr-labels?id=%d" % published_form["equipment_id"]).get_data(as_text=True)
    assert "<svg" in html and "SCT0002" in html


def test_scan_lookup_accepts_qr_from_any_ip(app, db, published_form):
    client = app.test_client()
    login(client, "t_tech")
    token = M.get_equipment(db, published_form["equipment_id"])["qr_token"]
    d = client.get(f"/api/m/lookup?q=http://10.99.0.1:5000/echeck/e/{token}").get_json()
    assert d["equipment"]["code"] == "SCT0002" and d["forms"]


# ───────── ธีม + โลโก้ ─────────

def test_theme_saved_and_rendered(app, db):
    client = app.test_client()
    login(client, "t_view")
    assert 'data-theme="auto"' in client.get("/dashboard").get_data(as_text=True)
    with client.session_transaction() as s:
        tok = s["_csrf"]
    r = client.post("/api/account/theme", json={"theme": "emerald"}, headers={"X-CSRF-Token": tok})
    assert r.get_json()["ok"] is True
    html = client.get("/dashboard").get_data(as_text=True)
    assert 'data-theme="emerald"' in html and "img/aisin-logo.png" in html
    assert client.post("/api/account/theme", json={"theme": "hacker"}, headers={"X-CSRF-Token": tok}).status_code == 400
    assert client.get("/static/img/aisin-logo.png").status_code == 200
