"""v0.39: ประวัติเครื่องเมื่อสแกน · แผนงาน 7/30 วัน · สถิติของฉัน (มือถือ)"""
from datetime import timedelta

from conftest import GOOD, login, payload, uid

from ecs import fieldinfo as FI
from ecs import services as S
from ecs import submissions as SUB

NG = dict(GOOD, oil={"value": "3.1", "remark": "แรงดันสูง ตรวจวาล์ว", "photos": ["p1"]})


def _submit(app, db, form, answers, user="t_tech"):
    import io

    from conftest import png_bytes
    from werkzeug.datastructures import FileStorage
    photos = {"p1": FileStorage(io.BytesIO(png_bytes()), filename="p.png")}
    SUB.create_submission(db, payload(form, answers), photos, uid(db, user), app.config["UPLOAD_FOLDER"])
    db.commit()
    return db.execute("SELECT MAX(id) FROM cs_submissions").fetchone()[0]


def test_machine_history_in_package(app, db, published_form):
    fid = published_form["form_id"]
    _submit(app, db, published_form, NG)
    _submit(app, db, published_form, NG)
    h = FI.machine_history(db, fid, app.config)
    assert h["last"]["inspector"] and h["ngs"][0]["item"] == "Oil Pressure" and h["ngs"][0]["value"] == "3.1"
    assert h["repeat"].get("oil") == 2                                   # NG ซ้ำใน 30 วัน
    from ecs import downtime as DT
    DT.set_down(db, published_form["equipment_id"], uid(db, "t_sup"), "เปลี่ยนไส้กรอง", "pm")
    DT.set_running(db, published_form["equipment_id"], uid(db, "t_sup"), "เสร็จ")
    db.commit()
    c = app.test_client()
    login(c, "t_tech")
    pkg = c.get(f"/api/m/forms/{fid}/package").get_json()
    m = pkg["machine"]
    assert m["repeat"]["oil"] == 2 and len(m["ngs"]) == 2 and m["down"]["cat"].startswith("PM") and m["down"]["end"]
    assert "histHtml" in c.get("/static/m/fill.js").get_data(as_text=True)


def test_plan_week_and_month(app, db, published_form):
    fid = published_form["form_id"]
    admin = uid(db, "t_admin")
    S.create_schedule(db, fid, {"freq_type": "weekly", "times": "09:00", "weekdays": "0,3", "window_min": 480}, admin)
    S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00", "window_min": 240}, admin)
    db.commit()
    p7 = FI.plan(db, uid(db, "t_tech"), 7)
    assert len(p7["days"]) == 7
    weekly = [x for d in p7["days"] for x in d["items"] if not x["daily"]]
    assert len(weekly) == 2 and all(x["freq_th"] == "รายสัปดาห์" for x in weekly)
    assert sum(1 for d in p7["days"] for x in d["items"] if x["daily"]) == 7
    assert p7["counts"] == {"rounds": 9, "long": 2, "pm": 0}
    p30 = FI.plan(db, uid(db, "t_tech"), 30)
    assert 8 <= p30["counts"]["long"] <= 10
    assert FI.plan(db, uid(db, "t_tech2"), 7)["counts"]["rounds"] == 0     # อีกโรงงาน ไม่เห็น
    c = app.test_client()
    login(c, "t_tech")
    html = c.get("/m/plan").get_data(as_text=True)
    assert "แผนงานตรวจ" in html and "รายสัปดาห์" in html and "showDaily" in html
    assert c.get("/m/plan?days=30").status_code == 200
    assert "แผนงาน 7/30 วัน" in c.get("/m/").get_data(as_text=True)


def test_my_stats(app, db, published_form):
    _submit(app, db, published_form, GOOD)
    sid = _submit(app, db, published_form, NG)
    _submit(app, db, published_form, GOOD, user="t_sup")
    st = FI.my_stats(db, uid(db, "t_tech"))
    assert st["cur"]["n"] == 2 and st["cur"]["ng_subs"] == 1 and st["cur"]["machines"] == 1 and st["streak"] >= 1
    assert len(st["trend"]) == 6 and st["trend"][-1]["n"] == 2 and st["trend"][-1]["label"]
    assert st["team_avg_n"] == 1.5
    c = app.test_client()
    login(c, "t_tech")
    html = c.get("/m/me").get_data(as_text=True)
    assert "สถิติของฉัน" in html and "ขอบคุณที่ช่วยจับปัญหา" in html and "m-trendbars" in html
    assert sid
    db.execute("UPDATE cs_submissions SET finished_at=? WHERE id=?", (S.ts(S.now_dt() - timedelta(days=40)), sid))
    db.commit()
    assert FI.my_stats(db, uid(db, "t_tech"))["cur"]["n"] == 1
