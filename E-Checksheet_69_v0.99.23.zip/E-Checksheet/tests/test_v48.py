"""v0.48: หน้า "งานของฉัน" ตามรอบตรวจปัจจุบัน — ปิดรอบตรวจ/เครื่องหยุดไม่ขึ้นเป็นงาน · เครื่องละ 1 การ์ด · เวลาเหลือ/เลยมา · อัปเดตเอง"""
from datetime import timedelta

from conftest import login, uid

from ecs import services as S
from ecs import submissions as SUB


def _setup(db, fid, times="00:05,06:00,12:00,18:00", window=1439):
    sid = S.create_schedule(db, fid, {"freq_type": "shift", "times": times, "window_min": window}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (S.ts(S.now_dt() - timedelta(days=2)),))
    S.generate_rounds(db)
    db.commit()
    return sid


def _todo_forms(t):
    return [r["form_id"] for k in ("returned", "overdue", "due", "upcoming") for r in t["groups"][k]]


def test_one_card_per_machine_and_closed_schedule_hidden(app, db, published_form):
    fid = published_form["form_id"]
    sid = _setup(db, fid)
    t = SUB.my_tasks(db, uid(db, "t_tech"))
    assert _todo_forms(t).count(fid) == 1                         # รอบซ้อนหลายรอบ → การ์ดเดียว
    card = next(r for k in ("overdue", "due", "upcoming") for r in t["groups"][k] if r["form_id"] == fid)
    assert card.get("more", 0) >= 1
    db.execute("UPDATE cs_schedules SET active=0 WHERE id=?", (sid,))   # ปิดรอบตรวจ (ยังไม่ได้ลบรอบเดิม)
    db.commit()
    t = SUB.my_tasks(db, uid(db, "t_tech"))
    assert fid not in _todo_forms(t) and t["todo"] == 0


def test_down_machine_rounds_go_to_skipped(app, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    _setup(db, fid)
    db.execute("UPDATE equipment SET run_status='down', down_reason='PM: เปลี่ยนไส้กรอง' WHERE id=?", (eq,))
    db.commit()
    t = SUB.my_tasks(db, uid(db, "t_tech"))
    assert fid not in _todo_forms(t)
    sk = [r for r in t["groups"]["skipped"] if r["form_id"] == fid]
    assert len(sk) == 1 and sk[0]["status"] == "skipped"


def test_status_recomputed_by_time(app, db, published_form):
    fid = published_form["form_id"]
    _setup(db, fid, times="12:00", window=60)
    now = S.now_dt()
    rid = db.execute("SELECT id FROM cs_rounds WHERE form_id=? ORDER BY due_at DESC LIMIT 1", (fid,)).fetchone()[0]
    db.execute("""UPDATE cs_rounds SET status='pending', due_at=?, deadline_at=?, close_at=? WHERE id=?""",
               (S.ts(now - timedelta(hours=2)), S.ts(now - timedelta(hours=1)), S.ts(now + timedelta(hours=3)), rid))
    db.commit()                                              # สถานะยังไม่ถูกปรับโดยงานเบื้องหลัง
    t = SUB.my_tasks(db, uid(db, "t_tech"))
    assert any(r["form_id"] == fid for r in t["groups"]["overdue"]) and not any(r["id"] == rid for r in t["groups"]["due"])


def test_home_js_live(app):
    c = app.test_client()
    login(c, "t_tech")
    js = c.get("/static/m/home.js").get_data(as_text=True)
    assert "retime" in js and "leftChip" in js and "setInterval" in js and "รอบซ้อน" in js
    assert c.get("/api/m/tasks").status_code == 200
