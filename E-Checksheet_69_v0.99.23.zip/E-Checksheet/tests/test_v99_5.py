"""v0.99.5: ปรับหัวข้อเฉพาะเครื่องที่ใช้แม่แบบ — ไม่ใช้บางหัวข้อ / เพิ่มหัวข้อเอง โดยแม่แบบและเครื่องอื่นไม่เปลี่ยน"""
import pytest
from conftest import login, uid
from test_v10 import _eq

from ecs import formtpl as T
from ecs import services as S

ITEMS = [
    {"item_key": "t1", "section": "TANK", "name": "ถังไม่รั่ว", "item_type": "ok_ng"},
    {"item_key": "p_in", "section": "PUMP", "name": "P in", "item_type": "number", "unit": "bar", "min_value": 3, "max_value": 5},
    {"item_key": "p_out", "section": "PUMP", "name": "P out", "item_type": "number", "unit": "bar", "min_value": 1, "max_value": 4},
    {"item_key": "dp", "section": "PUMP", "name": "ΔP", "item_type": "calc", "unit": "bar", "formula": "{p_in} - {p_out}", "max_value": 3},
    {"item_key": "v1", "section": "MOTOR", "name": "สั่น", "item_type": "number", "unit": "mm/s", "max_value": 7},
]


def _setup(app, db):
    """แม่แบบ 5 หัวข้อ + 2 เครื่อง"""
    admin = uid(db, "t_admin")
    tpl = T.new_template(db, {"name": "Pump daily"}, admin)
    d = S.get_draft(db, tpl)
    S.save_draft_items(db, d["id"], ITEMS, admin)
    S.publish_version(db, d["id"], admin)
    T.apply_to_equipment(db, tpl, [_eq(app, db, "PU-01"), _eq(app, db, "PU-02")], admin)
    db.commit()
    a, b = [c["id"] for c in T.children(db, tpl)]
    return tpl, a, b, admin


def _keys(db, fid):
    f = S.get_form(db, fid)
    return [i["item_key"] for i in S.get_items(db, f["current_version_id"])]


def test_exclude_only_this_machine_and_survives_template_publish(app, db):
    tpl, a, b, admin = _setup(app, db)
    tv_before = S.get_form(db, tpl)["current_version_id"]
    T.set_excluded(db, a, {"v1"}, admin)
    db.commit()
    assert _keys(db, a) == ["t1", "p_in", "p_out", "dp"]                 # เครื่องนี้ 4 หัวข้อ
    assert _keys(db, b) == ["t1", "p_in", "p_out", "dp", "v1"]           # เครื่องอื่นครบ 5
    assert S.get_form(db, tpl)["current_version_id"] == tv_before        # แม่แบบไม่ออกเวอร์ชันใหม่
    assert [i["item_key"] for i in S.get_items(db, tv_before)] == [i["item_key"] for i in ITEMS]
    # แม่แบบเพิ่มหัวข้อใหม่ → เครื่องนี้ได้หัวข้อใหม่ แต่ยังไม่มีหัวข้อที่เอาออก
    d = S.get_or_create_draft(db, tpl, admin)
    S.save_draft_items(db, d["id"], ITEMS + [{"item_key": "n1", "section": "MOTOR", "name": "อุณหภูมิมอเตอร์", "item_type": "number", "max_value": 80}], admin)
    S.publish_version(db, d["id"], admin)
    T.sync_all(db, tpl, admin)
    db.commit()
    assert _keys(db, a) == ["t1", "p_in", "p_out", "dp", "n1"]
    assert _keys(db, b) == ["t1", "p_in", "p_out", "dp", "v1", "n1"]
    # นำกลับมาใช้ → รหัสหัวข้อเดิม (ประวัติต่อเนื่อง)
    T.set_excluded(db, a, set(), admin)
    assert "v1" in _keys(db, a)


def test_exclude_guards(app, db):
    tpl, a, b, admin = _setup(app, db)
    with pytest.raises(S.ValidationError) as e:                          # สูตร ΔP อ้าง P in
        T.set_excluded(db, a, {"p_in"}, admin)
    assert "ΔP" in str(e.value.errors)
    T.set_excluded(db, a, {"p_in", "dp"}, admin)                          # เอาออกทั้งคู่ได้
    assert _keys(db, a) == ["t1", "p_out", "v1"]
    with pytest.raises(S.ValidationError):                               # ต้องเหลืออย่างน้อย 1 หัวข้อ
        T.set_excluded(db, a, {i["item_key"] for i in ITEMS}, admin)
    assert T.set_excluded(db, a, {"p_in", "dp", "zzz"}, admin)["changed"] is False   # รหัสที่ไม่มีในแม่แบบไม่สนใจ


def test_local_items_add_edit_delete(app, db):
    tpl, a, b, admin = _setup(app, db)
    k = T.save_local_item(db, a, {"section": "PUMP", "name": "เสียงผิดปกติ", "item_type": "choice",
                                  "options": [{"label": "ปกติ", "ng": 0}, {"label": "ดัง", "ng": 1}]}, admin)
    k2 = T.save_local_item(db, a, {"section": "ใหม่", "name": "แรงดันน้ำมัน", "item_type": "number", "unit": "bar", "min_value": 1, "max_value": 2}, admin)
    db.commit()
    assert _keys(db, a) == ["t1", "p_in", "p_out", "dp", k, "v1", k2]    # ต่อท้ายหมวดเดียวกัน · หมวดใหม่ท้ายสุด
    assert k not in _keys(db, b) and len(_keys(db, b)) == 5
    items = {i["item_key"]: i for i in S.get_items(db, S.get_form(db, a)["current_version_id"])}
    assert items[k2]["max_value"] == 2 and items[k]["options"][1]["ng"] == 1
    assert [i["order_no"] for i in items.values()] == sorted(i["order_no"] for i in items.values())
    # แก้ → รหัสเดิม
    T.save_local_item(db, a, {"section": "ใหม่", "name": "แรงดันน้ำมัน", "item_type": "number", "unit": "bar", "max_value": 3}, admin, k2)
    it = {i["item_key"]: i for i in S.get_items(db, S.get_form(db, a)["current_version_id"])}[k2]
    assert it["max_value"] == 3 and it["min_value"] is None
    # ชื่อซ้ำกับแม่แบบ/หัวข้อเอง · ประเภทคำนวณไม่รับ · ค่าไม่ถูก
    for bad in ({"name": "P  in", "item_type": "number"}, {"name": "เสียงผิดปกติ", "item_type": "ok_ng"},
                {"name": "x", "item_type": "calc", "formula": "{p_in}"}, {"name": "y", "item_type": "number", "min_value": 5, "max_value": 1}):
        with pytest.raises(S.ValidationError):
            T.save_local_item(db, a, bad, admin)
    # แม่แบบออกเวอร์ชันใหม่ → หัวข้อเฉพาะเครื่องยังอยู่
    T.sync_child(db, a, admin)
    assert k in _keys(db, a) and k2 in _keys(db, a)
    T.delete_local_item(db, a, k, admin)
    assert k not in _keys(db, a)
    with pytest.raises(S.ValidationError):
        T.delete_local_item(db, a, "nope", admin)
    # เอาหัวข้อแม่แบบออกทั้งหมดได้ถ้ายังมีหัวข้อของเครื่องเอง
    T.set_excluded(db, a, {i["item_key"] for i in ITEMS}, admin)
    assert _keys(db, a) == [k2]
    with pytest.raises(S.ValidationError):                               # หัวข้อสุดท้ายลบไม่ได้
        T.delete_local_item(db, a, k2, admin)
    kid = {c["id"]: c for c in T.children(db, tpl)}
    assert kid[a]["excluded_count"] == 5 and kid[a]["local_count"] == 1 and kid[b]["local_count"] == 0


def test_submission_on_local_item_and_detach(app, db):
    from conftest import payload
    from ecs import submissions as SUB
    tpl, a, b, admin = _setup(app, db)
    T.set_excluded(db, a, {"v1"}, admin)
    k = T.save_local_item(db, a, {"name": "ระดับน้ำมัน", "item_type": "ok_ng"}, admin)
    db.commit()
    f = S.get_form(db, a)
    ans = {"t1": {"value": "OK"}, "p_in": {"value": "4"}, "p_out": {"value": "2"}, k: {"value": "OK"}}
    res = SUB.create_submission(db, payload({"form_id": a, "version_id": f["current_version_id"]}, ans), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    row = db.execute("SELECT * FROM cs_answers WHERE submission_id=? AND item_key=?", (res["id"], k)).fetchone()
    assert row is not None and row["judgement"] == "ok"
    assert not db.execute("SELECT 1 FROM cs_answers WHERE submission_id=? AND item_key='v1'", (res["id"],)).fetchone()
    # แยกจากแม่แบบ: หัวข้อปัจจุบันคงอยู่ · ตารางปรับเฉพาะเครื่องถูกล้าง
    T.detach(db, a, admin)
    assert k in _keys(db, a) and "v1" not in _keys(db, a)
    assert not T.local_items(db, a) and not db.execute("SELECT 1 FROM cs_template_overrides WHERE form_id=?", (a,)).fetchone()


def test_routes_ui_and_permissions(app, db):
    tpl, a, b, admin = _setup(app, db)
    c = app.test_client()
    tok = login(c, "t_admin")
    html = c.get(f"/forms/{a}").get_data(as_text=True)
    assert "เลือกหัวข้อที่ใช้ (5/5)" in html and "เพิ่มหัวข้อเฉพาะเครื่อง" in html and 'id="dlgUse"' in html and 'id="dlgLocal"' in html
    # เลือกใช้ 4 หัวข้อ
    r = c.post(f"/forms/{a}/local/exclude", data={"csrf_token": tok, "use": ["t1", "p_in", "p_out", "dp"]})
    assert r.status_code == 302 and r.headers["Location"].endswith("#items")
    html = c.get(f"/forms/{a}").get_data(as_text=True)
    assert "เลือกหัวข้อที่ใช้ (4/5)" in html and "ไม่ใช้ 1 หัวข้อของแม่แบบ" in html and "<s>สั่น</s>" in html
    # เพิ่มหัวข้อ (ช่องติ๊กไม่ส่ง = ปิด) + ตัวเลือก NG
    c.post(f"/forms/{a}/local/items", data={"csrf_token": tok, "name": "เสียง", "item_type": "choice", "section": "MOTOR",
                                            "options": "ปกติ\nดังผิดปกติ (NG)", "photo_on_ng": "1"})
    li = T.local_items(db, a)
    assert len(li) == 1 and li[0]["required"] == 0 and li[0]["photo_on_ng"] == 1 and '"ng": 1' in li[0]["options_json"]
    html = c.get(f"/forms/{a}").get_data(as_text=True)
    assert 'class="badge b-local">เฉพาะเครื่องนี้' in html and f'data-local-edit="{li[0]["item_key"]}"' in html and "เพิ่มเอง 1 หัวข้อ" in html
    # นำกลับมาใช้ 1 หัวข้อ
    c.post(f"/forms/{a}/local/exclude", data={"csrf_token": tok, "restore": "v1"})
    assert "v1" in _keys(db, a)
    # ลบหัวข้อเฉพาะเครื่อง
    c.post(f"/forms/{a}/local/items", data={"csrf_token": tok, "item_key": li[0]["item_key"], "action": "delete"})
    assert not T.local_items(db, a)
    # แบบฟอร์มที่ไม่ใช้แม่แบบ / ข้อผิดพลาด → แจ้งเตือน ไม่ล่ม
    r = c.post(f"/forms/{tpl}/local/exclude", data={"csrf_token": tok, "use": []}, follow_redirects=True)
    assert r.status_code == 200 and "ไม่ได้ใช้แม่แบบ" in r.get_data(as_text=True)
    r = c.post(f"/forms/{a}/local/items", data={"csrf_token": tok, "name": "", "item_type": "number"}, follow_redirects=True)
    assert r.status_code == 200 and "กรุณาระบุชื่อหัวข้อ" in r.get_data(as_text=True)
    # ไม่มี CSRF / ช่าง → ไม่ได้
    assert c.post(f"/forms/{a}/local/exclude", data={"use": ["t1"]}).status_code in (400, 403)
    t = app.test_client(); tt = login(t, "t_tech")
    assert t.post(f"/forms/{a}/local/exclude", data={"csrf_token": tt, "use": ["t1"]}).status_code == 403
    assert t.post(f"/forms/{a}/local/items", data={"csrf_token": tt, "name": "x", "item_type": "ok_ng"}).status_code == 403
    assert "data-local-new" not in t.get(f"/forms/{a}").get_data(as_text=True)
    # หน้าแม่แบบ: คอลัมน์หัวข้อเฉพาะเครื่อง
    T.set_excluded(db, b, {"v1"}, admin); db.commit()
    html = c.get(f"/forms/{tpl}").get_data(as_text=True)
    assert "หัวข้อเฉพาะเครื่อง" in html and "ไม่ใช้ 1" in html and "ตามแม่แบบ" in html
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE entity='cs_forms' AND entity_id=? AND action LIKE 'local_%'", (a,)).fetchone()[0] >= 4
