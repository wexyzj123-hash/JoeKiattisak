"""v0.44: ค่าจาก SCADA ลงตรงช่องเวลาในใบตรวจ — ลงตามเวลารอบตรวจ / เวลาที่กำหนด · เลื่อนเวลา UTC · ตรวจสอบรายวัน · ลงค่าใหม่"""
import sqlite3
from datetime import datetime, time, timedelta

from conftest import login, uid

from ecs import connectors as CN
from ecs import services as S
from ecs import sheet_report as SR
from ecs import srcmap as SM
from ecs.services import ts


def _scada(tmp_path, rows):
    path = str(tmp_path / "scada.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE IF NOT EXISTS h (tag TEXT, ts TEXT, value REAL)")
    con.execute("DELETE FROM h")
    con.executemany("INSERT INTO h VALUES (?,?,?)", rows)
    con.commit()
    con.close()
    return path


def _day():
    return (S.now_dt() - timedelta(days=1)).date()


def _readings(day, shift_h=0):
    rows = []
    for m in range(6 * 60, 23 * 60, 10):                 # 06:00–22:50 ทุก 10 นาที · ค่า = ชั่วโมง.นาที
        t = datetime.combine(day, time(m // 60, m % 60)) - timedelta(hours=shift_h)
        rows.append(("OIL", ts(t), round(m // 60 + (m % 60) / 100, 2)))      # 08:30 → 8.3
    return rows


def _setup(app, db, form, tmp_path, rows, shift=0):
    fid = form["form_id"]
    S.create_schedule(db, fid, {"freq_type": "shift", "times": "08:30,20:30", "window_min": 240}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (ts(S.now_dt() - timedelta(days=3)),))
    S.generate_rounds(db)
    path = _scada(tmp_path, rows)
    sid = CN.save_source(db, {"name": "SCADA", "kind": "sqlite", "bucket_min": 60, "agg": "last", "ts_shift_min": shift, "prefill": "0",
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                         "backfill_days": 3}}, None)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil"}], None)
    db.commit()
    return sid


def _auto(db):
    return db.execute("""SELECT s.finished_at, s.round_id, a.value_num, r.status FROM cs_submissions s
                         JOIN cs_answers a ON a.submission_id=s.id LEFT JOIN cs_rounds r ON r.id=s.round_id
                         WHERE s.source='auto' ORDER BY s.finished_at""").fetchall()


def test_round_mode_lands_on_round_time(app, db, published_form, tmp_path):
    day = _day()
    sid = _setup(app, db, published_form, tmp_path, _readings(day))
    cfg = SM.form_cfgs(db, sid)[0]
    assert cfg["mode"] == "auto" and cfg["effective"] == "round"
    res = CN.run_source(db, sid)
    db.commit()
    got = [r for r in _auto(db) if r["finished_at"][:10] == day.isoformat()]
    assert [r["finished_at"] for r in got] == [f"{day} 08:30:00", f"{day} 20:30:00"]
    assert [r["value_num"] for r in got] == [8.3, 20.3]          # ค่าที่ใกล้ 08:30 / 20:30 ที่สุด
    assert all(r["round_id"] and r["status"] == "done_on_time" for r in got)
    assert res["submissions"] >= 2
    assert CN.run_source(db, sid)["submissions"] == 0            # ดึงซ้ำไม่สร้างซ้ำ
    # ใบบันทึกรายเดือน: ค่าอยู่ช่อง 08:30 / 20:30 ของวันนั้น
    doc = SR.build_month_sheet(db, published_form["form_id"], day.replace(day=1), "s", "x")
    row = next(r for r in doc["rows"] if r["it"]["item_key"] == "oil")
    if row["kind"] == "slots":
        lines = {ln["label"]: ln["cells"][day.day - 1] for ln in row["lines"]}
        assert lines["08:30"]["value_num"] == 8.3 and lines["20:30"]["value_num"] == 20.3


def test_utc_shift_and_times_mode_before(app, db, published_form, tmp_path):
    day = _day()
    sid = _setup(app, db, published_form, tmp_path, _readings(day, shift_h=7), shift=420)   # แหล่งข้อมูลเก็บ UTC
    fid = published_form["form_id"]
    SM.save_form_cfgs(db, sid, [{"form_id": fid, "mode": "times", "times": "07:05", "pick": "before", "window_min": 30}], None)
    db.commit()
    CN.run_source(db, sid)
    got = [r for r in _auto(db) if r["finished_at"][:10] == day.isoformat()]
    assert [(r["finished_at"], r["value_num"]) for r in got] == [(f"{day} 07:05:00", 7.0)]   # ค่าล่าสุดก่อน 07:05 = 07:00
    assert got[0]["round_id"] is None                            # ไม่ตรงเวลารอบ → ไม่ผูกรอบ
    try:
        SM.save_form_cfgs(db, sid, [{"form_id": fid, "mode": "times", "times": ""}], None)
        raise AssertionError("ต้องระบุเวลา")
    except S.ValidationError:
        pass


def test_bucket_mode_keeps_old_behaviour(app, db, published_form, tmp_path):
    day = _day()
    sid = _setup(app, db, published_form, tmp_path, _readings(day))
    SM.save_form_cfgs(db, sid, [{"form_id": published_form["form_id"], "mode": "bucket"}], None)
    db.commit()
    CN.run_source(db, sid)
    got = [r for r in _auto(db) if r["finished_at"][:10] == day.isoformat()]
    assert len(got) == 17 and got[0]["finished_at"].endswith("06:59:59")


def test_relay_and_admin_pages(app, db, published_form, tmp_path):
    day = _day()
    sid = _setup(app, db, published_form, tmp_path, _readings(day))
    fid = published_form["form_id"]
    SM.save_form_cfgs(db, sid, [{"form_id": fid, "mode": "bucket"}], None)     # ลงผิดแบบเดิมก่อน
    db.commit()
    CN.run_source(db, sid)
    db.commit()
    assert len([r for r in _auto(db) if r["finished_at"][:10] == day.isoformat()]) == 17
    c = app.test_client()
    tok = login(c, "t_admin")
    page = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert "การลงค่าในใบตรวจ" in page and "ลงค่าใหม่ย้อนหลัง" in page and 'name="ts_shift_min"' in page
    r = c.post(f"/admin/sources/{sid}/forms", data={"csrf_token": tok, "form_id": str(fid), f"mode.{fid}": "round",
                                                    f"pick.{fid}": "max", f"win.{fid}": "30", f"times.{fid}": ""})
    assert r.status_code == 302
    pv = c.get(f"/admin/sources/{sid}?pday={day.isoformat()}").get_data(as_text=True)
    assert "08:30" in pv and "20:30" in pv and "ตรวจสอบค่าที่จะลงรายวัน" in pv
    r = c.post(f"/admin/sources/{sid}/relay", data={"csrf_token": tok, "day_from": day.isoformat(), "day_to": day.isoformat()})
    assert r.status_code == 302
    got = [r for r in _auto(db) if r["finished_at"][:10] == day.isoformat()]
    assert [(r["finished_at"][11:16], r["value_num"]) for r in got] == [("08:30", 9.0), ("20:30", 21.0)]   # สูงสุดใน ±30 นาที
    assert all(r["status"] == "done_on_time" for r in got)
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE action='relay'").fetchone()[0] == 2   # v0.76 เปลี่ยนวิธีลงค่า → ลงใหม่ให้เอง + กดเอง


def test_item_level_frequency(app, db, published_form, tmp_path):
    """หัวข้อวันละครั้ง → ลงเฉพาะรอบแรกของวัน · หัวข้อตามเวลาของตัวเอง → ลงเวลาของหัวข้อ"""
    day = _day()
    fid = published_form["form_id"]
    ver = S.get_form(db, fid)["current_version_id"]
    db.execute("UPDATE cs_form_items SET check_freq='day' WHERE version_id=? AND item_key='hour'", (ver,))
    db.execute("UPDATE cs_form_items SET check_freq='times', check_times='14:00' WHERE version_id=? AND item_key='oil'", (ver,))
    rows = _readings(day) + [("HR", r[1], 1000 + i) for i, r in enumerate(_readings(day))]
    sid = _setup(app, db, published_form, tmp_path, rows)
    CN.save_mapping(db, sid, [{"tag": "HR", "target": f"{fid}:hour"}], None)
    db.commit()
    CN.run_source(db, sid)
    got = db.execute("""SELECT s.finished_at, a.item_key, a.value_num FROM cs_submissions s JOIN cs_answers a ON a.submission_id=s.id
                        WHERE s.source='auto' AND substr(s.finished_at,1,10)=? ORDER BY s.finished_at, a.item_key""",
                     (day.isoformat(),)).fetchall()
    assert [(r[0][11:16], r[1]) for r in got] == [("08:30", "hour"), ("14:00", "oil")]
    assert got[1][2] == 14.0
