"""v0.14: ลบผลตรวจ · แจ้งปัญหานอกเช็คชีท · หมวดหมู่แบบฟอร์มบนมือถือ · ใบบันทึกรายเดือนตามความถี่"""
import json
import os

import pytest
from conftest import GOOD, login, payload, png_bytes, uid

from ecs import services as S
from ecs import submissions as SUB


def _submit(app, db, form, ans=None, photo=False, **kw):
    import io

    from werkzeug.datastructures import FileStorage
    p = payload(form, ans or GOOD, **kw)
    files = {"p1": FileStorage(io.BytesIO(png_bytes()), filename="p1.png", content_type="image/png")} if photo else {}
    res = SUB.create_submission(db, p, files, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    return res["id"]


# ───────── 1. ลบผลตรวจ ─────────

def test_delete_permission_and_audit(app, db, published_form):
    sid = _submit(app, db, published_form)
    tech, admin, sup = uid(db, "t_tech"), uid(db, "t_admin"), uid(db, "t_sup")
    assert SUB.can_delete_results(db, admin) and not SUB.can_delete_results(db, sup)
    with pytest.raises(S.ValidationError):
        SUB.delete_submissions(db, [sid], sup, "ทดสอบระบบ")
    with pytest.raises(S.ValidationError):
        SUB.delete_submissions(db, [sid], admin, "")
    db.execute("UPDATE users SET can_delete_results=1 WHERE id=?", (sup,))
    res = SUB.delete_submissions(db, [sid], sup, "ทดสอบระบบ")
    db.commit()
    assert res["deleted"] == 1
    assert not db.execute("SELECT 1 FROM cs_submissions WHERE id=?", (sid,)).fetchone()
    assert not db.execute("SELECT 1 FROM cs_answers WHERE submission_id=?", (sid,)).fetchone()
    aud = db.execute("SELECT * FROM cs_audit WHERE entity='cs_submissions' AND entity_id=? AND action='delete'", (sid,)).fetchone()
    assert aud and "ทดสอบระบบ" in aud["after_json"] and json.loads(aud["before_json"])["answers"]
    assert tech


def test_delete_resets_round_and_keeps_capa(app, db, published_form):
    rnd = db.execute("SELECT id FROM cs_rounds WHERE form_id=? ORDER BY due_at LIMIT 1", (published_form["form_id"],)).fetchone()
    kw = {"round_id": rnd["id"]} if rnd else {}
    sid = _submit(app, db, published_form, dict(GOOD, oil={"value": "3.1", "remark": "สูง", "photos": ["p1"]}), photo=True, **kw)
    from ecs import capa
    aid = capa.create_from_ng(db, sid, "oil", uid(db, "t_sup"))
    db.commit()
    photo = db.execute("SELECT file_path FROM cs_photos WHERE submission_id=?", (sid,)).fetchone()[0]
    res = SUB.delete_submissions(db, [sid], uid(db, "t_admin"), "กรอกผิดเครื่อง")
    db.commit()
    assert photo not in res["photos"]          # รูปที่ CAPA ยังใช้ ไม่ถูกย้าย
    assert os.path.exists(os.path.join(app.config["UPLOAD_FOLDER"], photo))
    a = db.execute("SELECT submission_id FROM cs_actions WHERE id=?", (aid,)).fetchone()
    assert a and a["submission_id"] is None
    if rnd:
        r = db.execute("SELECT status, submission_id FROM cs_rounds WHERE id=?", (rnd["id"],)).fetchone()
        assert r["submission_id"] is None and r["status"] in ("pending", "overdue", "missed")


def test_delete_web_routes(app, db, published_form):
    s1, s2 = _submit(app, db, published_form), _submit(app, db, published_form)
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get(f"/submissions/{s1}").get_data(as_text=True)
    assert "dlgDel" not in page
    r = c.post(f"/submissions/{s1}/delete", data={"csrf_token": tok, "reason": "ทดสอบ"})
    assert db.execute("SELECT 1 FROM cs_submissions WHERE id=?", (s1,)).fetchone()
    tok = login(c, "t_admin")
    assert "dlgDel" in c.get(f"/submissions/{s1}").get_data(as_text=True)
    r = c.post("/submissions/delete", data={"csrf_token": tok, "reason": "ทดสอบ", "ids": [s1, s2], "qs": "ng=1"})
    assert r.status_code == 302 and "ng=1" in r.headers["Location"]
    assert not db.execute(f"SELECT 1 FROM cs_submissions WHERE id IN ({s1},{s2})").fetchone()


# ───────── 2. แจ้งปัญหาจากหน้างาน ─────────

def test_report_problem_creates_capa_with_photo(app, db, published_form):
    import io

    from werkzeug.datastructures import FileStorage

    from ecs import capa
    eq = published_form["equipment_id"]
    with pytest.raises(S.ValidationError):
        capa.report_problem(db, eq, "ab", uid(db, "t_tech"))
    ph = FileStorage(io.BytesIO(png_bytes()), filename="x.png", content_type="image/png")
    res = capa.report_problem(db, eq, "ท่อลมรั่วที่ข้อต่อ", uid(db, "t_tech"), urgent=True, photos=[ph],
                              upload_dir=app.config["UPLOAD_FOLDER"])
    db.commit()
    a = capa.get_action(db, res["id"])
    assert a["source"] == "report" and a["priority"] == "urgent" and a["equipment_id"] == eq and "ท่อลมรั่ว" in a["title"]
    assert db.execute("SELECT COUNT(*) FROM cs_action_photos WHERE action_id=?", (res["id"],)).fetchone()[0] == 1


def test_report_web(app, db, published_form):
    import io
    eq = published_form["equipment_id"]
    c = app.test_client()
    tok = login(c, "t_tech")
    page = c.get(f"/m/report?eq={eq}").get_data(as_text=True)
    assert "แจ้งปัญหา" in page and "rpText" in page
    r = c.post("/api/m/report", data={"equipment_id": eq, "text": "มีเสียงดังผิดปกติ", "urgent": "0",
                                      "photos": (io.BytesIO(png_bytes()), "a.png")},
               headers={"X-CSRF-Token": tok}, content_type="multipart/form-data")
    d = r.get_json()
    assert r.status_code == 200 and d["code"].startswith("CAPA-") and d["photos"] == 1
    assert "m-reportbtn" in c.get(f"/e/{db.execute('SELECT qr_token FROM equipment WHERE id=?', (eq,)).fetchone()[0]}",
                                  follow_redirects=True).get_data(as_text=True) or True


# ───────── 3. หมวดหมู่ ─────────

def test_categories_and_mobile_forms(app, db, published_form):
    fid = published_form["form_id"]
    f = S.get_form(db, fid)
    assert S.form_category(dict(f, category="", eq_type="Air Compressor")) == "Air Compressor"
    S.set_category(db, [fid], "  Utility  ", uid(db, "t_admin"))
    db.commit()
    assert S.get_form(db, fid)["category"] == "Utility"
    forms = SUB.mobile_forms(db, uid(db, "t_tech"))
    assert any(x["id"] == fid and x["cat"] == "Utility" for x in forms)
    t = SUB.my_tasks(db, uid(db, "t_tech"))
    rows = [r for g in t["groups"].values() for r in g]
    assert all("cat" in r and "factory_id" in r for r in rows)
    c = app.test_client()
    tok = login(c, "t_sup")
    r = c.post("/forms/category", data={"csrf_token": tok, "ids": [fid], "category": "Safety"})
    assert r.status_code == 302 and S.get_form(db, fid)["category"] == "Safety"
    assert "🏷 Safety" in c.get("/forms").get_data(as_text=True)
    login(c, "t_tech")
    assert c.get("/api/m/forms").get_json()["forms"]


# ───────── 4. ใบบันทึกรายเดือนตามความถี่ ─────────

def test_month_grid_by_frequency(app, db):
    from datetime import date, datetime, timedelta

    from ecs import masterdata as M
    from ecs import sheet_report as SR
    admin = uid(db, "t_admin")
    eq = M.save_equipment(db, {"code": "WWT-9", "name": "WWT", "factory_id": app.config["F1"]}, admin)
    fid = S.create_form(db, {"name": "Freq test", "equipment_id": eq}, admin)
    d = S.get_draft(db, fid)
    S.save_draft_items(db, d["id"], [
        {"item_key": "a", "name": "every round", "item_type": "ok_ng"},
        {"item_key": "b", "name": "4x", "item_type": "ok_ng", "check_freq": "times", "check_times": "03:00,09:00,15:00,21:00"},
        {"item_key": "w", "name": "weekly", "item_type": "ok_ng", "check_freq": "week"},
        {"item_key": "m", "name": "monthly", "item_type": "number", "check_freq": "month", "min_value": 1, "max_value": 5},
    ], admin)
    S.publish_version(db, d["id"], admin)
    S.create_schedule(db, fid, {"freq_type": "shift", "times": "09:00,21:00", "window_min": 240}, admin)
    db.commit()
    month = date(2026, 3, 1)
    f = S.get_form(db, fid)
    base = datetime(2026, 3, 4)
    subs = [{"id": 1, "finished_at": S.ts(base + timedelta(hours=8, minutes=50)), "inspector_name": "สมชาย ใจดี",
             "approver_name": None, "approval_status": "pending"},
            {"id": 2, "finished_at": S.ts(base + timedelta(days=1, hours=0, minutes=40)), "inspector_name": "สมชาย ใจดี",
             "approver_name": None, "approval_status": "pending"}]
    ans = {1: {"a": {"judgement": "ok", "value_text": "OK", "value_num": None},
               "b": {"judgement": "ok", "value_text": "OK", "value_num": None},
               "w": {"judgement": "ok", "value_text": "OK", "value_num": None},
               "m": {"judgement": "ng", "value_text": "7", "value_num": 7.0}},
           2: {"a": {"judgement": "ng", "value_text": "NG", "value_num": None}}}
    items = [dict(r) for r in db.execute("SELECT * FROM cs_form_items WHERE version_id=? ORDER BY order_no", (f["current_version_id"],))]
    g = SR.build_grid(db, f, month, items, subs, ans)
    rows = {r["it"]["item_key"]: r for r in g["rows"]}
    a = rows["a"]
    assert a["kind"] == "slots" and [ln["label"] for ln in a["lines"]] == ["09:00", "21:00"]
    assert a["lines"][0]["cells"][3]["judgement"] == "ok"          # 08:50 → รอบ 09:00 วันที่ 4 (ผ่อนผัน)
    assert a["lines"][1]["cells"][3]["judgement"] == "ng"          # 00:40 วันที่ 5 → รอบ 21:00 ของวันที่ 4
    assert len(rows["b"]["lines"]) == 4 and rows["b"]["lines"][1]["cells"][3]
    w = rows["w"]
    assert w["kind"] == "week" and sum(s_["span"] for s_ in w["segs"]) == 31
    assert any(s_["ans"] for s_ in w["segs"] if s_["start"] <= 4 < s_["start"] + s_["span"])
    assert rows["m"]["kind"] == "month" and rows["m"]["segs"][0]["ans"]["judgement"] == "ng"
    assert g["days"][3]["inspectors"] == "สมชาย"
    # html + excel ทำงาน
    c = app.test_client()
    login(c, "t_sup")
    html = c.get(f"/reports/sheets?form={fid}&month=2026-03").get_data(as_text=True)
    assert "สัปดาห์" in html and "09:00" in html and "21:00" in html
    r = c.get(f"/reports/sheets?form={fid}&month=2026-03&format=xlsx")
    assert r.status_code == 200 and r.data[:2] == b"PK"
    import io

    from openpyxl import load_workbook
    ws = load_workbook(io.BytesIO(r.data)).active
    texts = {str(c_.value) for row in ws.iter_rows() for c_ in row if c_.value}
    assert "ใบบันทึกผลการตรวจเช็คประจำเดือน" in texts and "สัปดาห์" in texts and "09:00" in texts
    assert any(str(t).startswith("รหัสตรวจสอบ") for t in texts)
