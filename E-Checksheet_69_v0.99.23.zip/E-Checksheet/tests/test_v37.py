"""v0.37: ความยาวช่องเซ็น "ผู้ตรวจ (Tech)" / "หัวหน้างาน (Sr.Tech)" ในใบบันทึกรายเดือน — อัตโนมัติตามรอบตรวจ หรือผู้ดูแลระบบตั้งเอง"""
import io
from datetime import date

from conftest import GOOD, login, payload, uid

from ecs import services as S
from ecs import sheet_report as SR
from ecs import sign_blocks as SB
from ecs import signoffs as SO
from ecs import submissions as SUB


def _month():
    return S.now_dt().date().replace(day=1)


def test_segments_shapes(db):
    m = date(2026, 9, 1)                                    # ก.ย. 2569 เริ่มวันอังคาร · 30 วัน
    assert len(SB.segments(db, m, 30, "day")) == 30
    assert [s["start"] for s in SB.segments(db, m, 30, "week")] == [1, 7, 14, 21, 28]
    assert [(s["start"], s["span"]) for s in SB.segments(db, m, 30, "half")] == [(1, 15), (16, 15)]
    assert SB.segments(db, m, 30, "month") == [{"start": 1, "span": 30, "label": ""}]
    w2 = SB.segments(db, m, 30, "w:2")                      # นับจาก 1 ม.ค. 2024 (จันทร์) ทุก 2 สัปดาห์
    assert sum(s["span"] for s in w2) == 30 and all(s["span"] <= 14 for s in w2) and len(w2) in (3, 4)
    assert SB.span_th("w:2") == "1 ครั้ง/2 สัปดาห์" and SB.span_th("week") == "1 ครั้ง/สัปดาห์"


def test_auto_from_schedule(app, db, published_form):
    fid = published_form["form_id"]
    form = S.get_form(db, fid)
    assert SB.resolve_spans(db, form) == ("day", "week")                  # ไม่มีรอบ / รายวัน → ผู้ตรวจรายวัน
    S.create_schedule(db, fid, {"freq_type": "weekly", "times": "09:00", "weekdays": "0"}, uid(db, "t_admin"))
    db.commit()
    assert SB.resolve_spans(db, form) == ("week", "week")
    db.execute("UPDATE cs_schedules SET freq_type='monthly' WHERE form_id=?", (fid,))
    assert SB.resolve_spans(db, form) == ("month", "month")
    db.execute("UPDATE cs_schedules SET freq_type='w:2' WHERE form_id=?", (fid,))
    assert SB.resolve_spans(db, form) == ("w:2", "w:2")


def test_admin_setting_sheet_and_excel(app, db, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_admin")
    page = c.get(f"/forms/{fid}").get_data(as_text=True)
    assert 'name="insp_span"' in page and 'name="sup_span"' in page and "ใช้อยู่ตอนนี้" in page
    SUB.create_submission(db, payload(published_form, GOOD), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    # ตั้ง: ผู้ตรวจรายสัปดาห์ · หัวหน้างานเดือนละครั้ง
    c.post(f"/forms/{fid}/sign-config", data={"csrf_token": tok, "sb_dept": "", "insp_span": "week", "sup_span": "month"})
    form = S.get_form(db, fid)
    assert SB.own(db, fid)["insp_span"] == "week" and SB.resolve_spans(db, form) == ("week", "month")
    doc = SR.build_month_sheet(db, fid, _month(), "s", "x")
    ins = doc["signs"]["insp"]
    assert ins["code"] == "week" and ins["segs"] and any(sg["people"] for sg in ins["segs"])
    sup = doc["signs"]["rows"][0]
    assert sup["freq"] == "month" and len(sup["segs"]) == 1 and sup["freq_th"] == "1 ครั้ง/เดือน"
    html = c.get(f"/reports/sheets?form={fid}&month={_month():%Y-%m}").get_data(as_text=True)
    assert 'class="sgr ins"' in html
    ws = __import__("openpyxl").load_workbook(io.BytesIO(SR.to_excel([doc]))).active
    vals = [cc.value for row in ws.iter_rows() for cc in row if cc.value]
    assert "1 ครั้ง/สัปดาห์" in vals and "1 ครั้ง/เดือน" in vals
    # อนุมัติครบทั้งเดือน → ช่องหัวหน้างานช่องเดียวเติมลายเซ็นอัตโนมัติ
    sid = db.execute("SELECT MAX(id) FROM cs_submissions").fetchone()[0]
    SUB.approve(db, sid, uid(db, "t_sup"), "ok")
    db.commit()
    assert SO.records(db, fid, _month()).get("row:sup:1")
    # กลับเป็นอัตโนมัติ (รายวัน / รายสัปดาห์) → ลายเซ็นย้ายไปช่องสัปดาห์ของวันที่ตรวจ
    c.post(f"/forms/{fid}/sign-config", data={"csrf_token": tok, "sb_dept": "", "insp_span": "auto", "sup_span": "auto"})
    assert "insp_span" not in SB.own(db, fid)
    doc = SR.build_month_sheet(db, fid, _month(), "s", "x")
    assert doc["signs"]["insp"]["code"] == "day" and 'class="who"' in c.get(f"/reports/sheets?form={fid}&month={_month():%Y-%m}").get_data(as_text=True)
    wk = SO.seg_of(db, fid, _month(), S.now_dt().day)
    recs = SO.records(db, fid, _month())
    assert recs.get(f"row:sup:{wk['start']}") and (wk["start"] == 1 or "row:sup:1" not in recs)


def test_template_inherit_and_bulk(app, db, published_form):
    fid = published_form["form_id"]
    admin = uid(db, "t_admin")
    tid = S.create_form(db, {"name": "TPL", "code": "TPL-1", "is_template": 1}, admin)
    db.execute("UPDATE cs_forms SET template_id=? WHERE id=?", (tid, fid))
    SB.save(db, [tid], {"boxes": ["env"]}, admin)
    SB.save_spans(db, [tid], "month", "month", admin)
    db.commit()
    form = S.get_form(db, fid)
    eff = SB.effective(db, form)
    assert eff["boxes"] == ["env"] and eff["insp_span"] == "month"            # แถว/กล่อง + ความยาวช่อง จากแม่แบบ
    SB.save(db, [fid], {"boxes": ["safety"]}, admin)                         # ตั้งของตัวเอง → span ยังตามแม่แบบ
    assert SB.effective(db, S.get_form(db, fid))["insp_span"] == "month"
    db.commit()
    c = app.test_client()
    tok = login(c, "t_admin")
    c.post("/forms/sign-config", data={"csrf_token": tok, "ids": [str(fid)], "sb_dept": "safety", "insp_span": "keep", "sup_span": "w:2"})
    own = SB.own(db, fid)
    assert own.get("sup_span") == "w:2" and "insp_span" not in own
    assert SB.resolve_spans(db, S.get_form(db, fid)) == ("month", "w:2")
