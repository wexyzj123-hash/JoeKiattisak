"""v0.42: แถวผู้ตรวจ (Tech) ในใบบันทึกรายเดือน แยกกะกลางวัน / กะกลางคืน ตามเวลารอบตรวจ"""
import io
from datetime import datetime, time, timedelta

from conftest import GOOD, login, payload, uid

from ecs import services as S
from ecs import sheet_report as SR
from ecs import sign_blocks as SB
from ecs import submissions as SUB


def _sub(app, db, form, user, when, round_id=None):
    SUB.create_submission(db, payload(form, GOOD), {}, uid(db, user), app.config["UPLOAD_FOLDER"])
    sid = db.execute("SELECT MAX(id) FROM cs_submissions").fetchone()[0]
    db.execute("UPDATE cs_rounds SET submission_id=NULL, status='pending' WHERE submission_id=?", (sid,))
    db.execute("UPDATE cs_submissions SET finished_at=?, scanned_at=?, round_id=? WHERE id=?",
               (S.ts(when), S.ts(when), round_id, sid))
    if round_id:
        db.execute("UPDATE cs_rounds SET submission_id=?, status='done_on_time' WHERE id=?", (sid, round_id))
    db.commit()
    return sid


def _setup(db, fid, times="08:30,20:30"):
    S.create_schedule(db, fid, {"freq_type": "shift", "times": times, "window_min": 240}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (S.ts(S.now_dt() - timedelta(days=3)),))
    S.generate_rounds(db)
    db.commit()


def test_shift_of_and_auto(app, db, published_form):
    cal = {"shift_times": "08:00,20:00", "day_start": "08:00"}
    assert SB.shift_of(8 * 60 + 30, cal) == "day" and SB.shift_of(7 * 60 + 40, cal) == "day"
    assert SB.shift_of(20 * 60 + 30, cal) == "night" and SB.shift_of(2 * 60, cal) == "night"
    assert SB.shift_of(14 * 60, {"shift_times": "08:00"}) == "day" and SB.shift_of(22 * 60, {"shift_times": ""}) == "night"
    fid = published_form["form_id"]
    form = S.get_form(db, fid)
    S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:30"}, uid(db, "t_admin"))
    db.commit()
    assert SB.resolve_spans(db, form) == ("day", "week")                    # รอบกลางวันอย่างเดียว → แถวเดียว
    S.create_schedule(db, fid, {"freq_type": "daily", "times": "20:30"}, uid(db, "t_admin"))
    db.commit()
    assert SB.resolve_spans(db, form) == ("shift", "week")
    assert [(r["label"], r["times"]) for r in SB.shift_rows(db, fid)] == [("กะกลางวัน", "08:30"), ("กะกลางคืน", "20:30")]


def test_month_sheet_two_inspector_rows(app, db, published_form):
    fid = published_form["form_id"]
    _setup(db, fid)
    today = S.now_dt().date()
    r_day = db.execute("SELECT id FROM cs_rounds WHERE form_id=? AND due_at=?",
                       (fid, S.ts(datetime.combine(today, time(8, 30))))).fetchone()[0]
    r_night = db.execute("SELECT id FROM cs_rounds WHERE form_id=? AND due_at=?",
                         (fid, S.ts(datetime.combine(today, time(20, 30))))).fetchone()[0]
    _sub(app, db, published_form, "t_tech", datetime.combine(today, time(9, 0)), r_day)
    _sub(app, db, published_form, "t_sup", datetime.combine(today, time(22, 0)), r_night)
    doc = SR.build_month_sheet(db, fid, today.replace(day=1), "s", "x")
    ins = doc["signs"]["insp"]
    assert ins["code"] == "shift" and [x["key"] for x in ins["shifts"]] == ["day", "night"]
    day_cell, night_cell = ins["shifts"][0]["cells"][today.day - 1], ins["shifts"][1]["cells"][today.day - 1]
    assert [n for _u, n in day_cell] and [n for _u, n in night_cell]
    assert day_cell[0][0] == uid(db, "t_tech") and night_cell[0][0] == uid(db, "t_sup")
    c = app.test_client()
    login(c, "t_admin")
    html = c.get(f"/reports/sheets?form={fid}&month={today:%Y-%m}").get_data(as_text=True)
    assert html.count('class="who shf"') == 2 and "กะกลางวัน" in html and "กะกลางคืน" in html
    ws = __import__("openpyxl").load_workbook(io.BytesIO(SR.to_excel([doc]))).active
    vals = [str(cc.value) for row in ws.iter_rows() for cc in row if cc.value]
    assert any("กะกลางวัน" in v for v in vals) and any("กะกลางคืน" in v for v in vals) and "20:30" in vals
    # ตั้งเป็น "ทุกวัน" แถวเดียวได้
    tok = login(c, "t_admin")
    c.post(f"/forms/{fid}/sign-config", data={"csrf_token": tok, "sb_dept": "", "insp_span": "day", "sup_span": "auto"})
    doc = SR.build_month_sheet(db, fid, today.replace(day=1), "s", "x")
    assert doc["signs"]["insp"]["code"] == "day" and not doc["signs"]["insp"]["shifts"]


def test_unlinked_night_after_midnight_counts_previous_day(app, db, published_form):
    fid = published_form["form_id"]
    _setup(db, fid)
    today = S.now_dt().date()
    if today.day == 1:                                     # ต้องมีวันก่อนหน้าในเดือนเดียวกัน
        return
    _sub(app, db, published_form, "t_sup", datetime.combine(today, time(2, 0)))          # ไม่ผูกรอบ · 02:00
    import calendar
    sp = SR.shift_people(db, fid, today.replace(day=1), calendar.monthrange(today.year, today.month)[1])
    assert sp["night"][today.day - 2] and not sp["night"][today.day - 1] and not sp["day"][today.day - 1]
