"""v0.35: รอบตรวจ 'เดือนละ 2 ครั้ง' แบ่งครึ่งเดือน 1–15 / 16–สิ้นเดือน"""
from datetime import date, datetime

from conftest import GOOD, login, payload, uid

from ecs import services as S


def test_semimonthly_occurrences_and_deadline():
    s = S.normalize_schedule({"freq_type": "semimonthly", "times": "08:00"})
    s = {**s, "skip_holidays": 1}
    occ = S.occurrences(s, date(2026, 10, 1), date(2026, 12, 31), holidays={date(2026, 11, 16)})
    assert [(d.month, d.day) for d in occ] == [(10, 1), (10, 16), (11, 1), (11, 16), (12, 1), (12, 16)]   # วันหยุดไม่ทำให้ข้ามครึ่งเดือน
    assert S.half_month_end(datetime(2026, 10, 1, 8)) == datetime(2026, 10, 15, 23, 59, 59)
    assert S.half_month_end(datetime(2026, 10, 16, 8)) == datetime(2026, 10, 31, 23, 59, 59)
    assert S.half_month_end(datetime(2027, 2, 16, 8)) == datetime(2027, 2, 28, 23, 59, 59)
    assert "ครึ่งแรก 1–15" in S.describe_schedule({**s, "window_min": 240})


def test_semimonthly_rounds_and_sheet(app, db, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_admin")
    page = c.get(f"/forms/{fid}").get_data(as_text=True)
    assert 'value="semimonthly"' in page and "ครึ่งแรก วันที่ 1–15" in page
    c.post(f"/forms/{fid}/schedules", data={"csrf_token": tok, "freq_type": "semimonthly", "times": "08:00", "window_min": "240"})
    assert db.execute("SELECT freq_type FROM cs_schedules WHERE form_id=?", (fid,)).fetchone()[0] == "semimonthly"
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', '2026-01-01 00:00:00')")
    S.generate_rounds(db, now=datetime(2026, 10, 16, 9, 0))
    r = db.execute("SELECT due_at, deadline_at FROM cs_rounds WHERE form_id=? AND due_at LIKE '2026-10-16%'", (fid,)).fetchone()
    assert r and r["deadline_at"] == "2026-10-31 23:59:59"
    from ecs import sheet_report as SR
    from ecs import submissions as SUB
    SUB.create_submission(db, payload(published_form, GOOD), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    today = S.now_dt().date()
    doc = SR.build_month_sheet(db, fid, today.replace(day=1), "s", "x")
    row = next(x for x in doc["grid"]["rows"] if x["it"]["item_key"] == "oil")
    assert row["kind"] == "half" and [s["start"] for s in row["segs"]] == [1, 16] and row["tm"] == "ครึ่งเดือน"
    assert any(s["ans"] for s in row["segs"])


def test_semimonthly_excel(app, db, published_form):
    fid = published_form["form_id"]
    S.create_schedule(db, fid, {"freq_type": "semimonthly", "times": "08:00"}, uid(db, "t_admin"))
    db.commit()
    from ecs import sheet_report as SR
    doc = SR.build_month_sheet(db, fid, S.now_dt().date().replace(day=1), "s", "x")
    data = SR.to_excel([doc])
    import io

    from openpyxl import load_workbook
    ws = load_workbook(io.BytesIO(data)).active
    assert any(c.value == "ครึ่งเดือน" for row in ws.iter_rows() for c in row)
