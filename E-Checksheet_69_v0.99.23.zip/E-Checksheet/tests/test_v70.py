"""v0.70: โครงสร้าง Project › Section › Line · รายงานรายวัน · ตัวกรองร่วมทุกหน้า"""
from datetime import date, timedelta

import pytest
from conftest import login, uid

from ecs import energy as EN
from ecs import energy_struct as ST
from ecs.services import ValidationError

Y = 2025


def _m(db, fid, code, grp, line="", start=1000, per=100, kind="elec", project_id=None, main=0):
    mid = EN.save_meter(db, None, {"factory_id": fid, "kind": kind, "code": code, "name": code, "grp": grp, "line": line,
                                   "project_id": project_id or "", "is_main": main}, None)
    d = date(Y, 3, 1) - timedelta(days=1)
    v = start
    while d <= date(Y, 3, 20):
        EN.set_reading(db, mid, d.isoformat(), v, None)
        d += timedelta(days=1)
        v += per
    return mid


def test_struct_crud(app, db):
    f1 = app.config["F1"]
    adm = uid(db, "t_admin")
    names = {p["name"] for p in ST.projects(db)}
    assert {"Kubota", "AR5"} <= names                                              # seed
    pid = ST.save_project(db, {"name": "Toyota", "color": "#ef4444"}, adm)
    with pytest.raises(ValidationError):
        ST.save_project(db, {"name": "Toyota"}, adm)                               # ชื่อซ้ำ
    ST.add_section(db, f1, "MFG.9", adm)
    with pytest.raises(ValidationError):
        ST.add_section(db, f1, "MFG.9", adm)
    ST.add_line(db, f1, "MFG.9", "Line 01", adm)
    a = _m(db, f1, "A", "MFG.9", "Line 01", project_id=pid)
    b = _m(db, f1, "B", "MFG.9", "Line 02", project_id=pid)                         # Line ใหม่จากฟอร์มมิเตอร์ → เข้ารายการเอง
    assert {x["name"] for x in ST.lines(db, f1, "MFG.9")} == {"Line 01", "Line 02"}
    assert EN.meter(db, a)["project_name"] == "Toyota"
    with pytest.raises(ValidationError):
        ST.delete_section(db, f1, "MFG.9", adm)                                    # ยังมีมิเตอร์
    ST.rename_line(db, f1, "MFG.9", "Line 02", "Line 01", adm)                      # รวม Line
    assert EN.meter(db, b)["line"] == "Line 01" and len(ST.lines(db, f1, "MFG.9")) == 1
    ST.rename_section(db, f1, "MFG.9", "MFG.10", adm)
    assert EN.meter(db, a)["grp"] == "MFG.10" and ST.lines(db, f1, "MFG.10")
    assert ST.bulk_assign(db, [a, b], adm, line="Line X", grp="MFG.11") == 2
    assert {x["name"] for x in ST.lines(db, f1, "MFG.11")} == {"Line X"}
    ST.bulk_assign(db, [a], adm, project_id=None, set_project=True)
    assert EN.meter(db, a)["project_id"] is None
    assert ST.delete_project(db, pid, adm) == 1                                    # b ยังผูกอยู่ → ปลดให้


def test_filters_and_daily(app, db):
    f1 = app.config["F1"]
    kb = next(p["id"] for p in ST.projects(db) if p["name"] == "Kubota")
    ar = next(p["id"] for p in ST.projects(db) if p["name"] == "AR5")
    _m(db, f1, "M1", "MFG.1", "Line 01", per=100, project_id=kb)
    _m(db, f1, "M2", "MFG.1", "Line 02", per=50, project_id=kb)
    _m(db, f1, "M3", "MFG.2", "Line 03", per=10, project_id=ar)
    assert len(EN.meters(db, f1, "elec", True, kb)) == 2 and len(EN.meters(db, f1, "elec", True, None, "MFG.2")) == 1
    assert len(EN.meters(db, f1, "elec", True, None, "MFG.1", "Line 02")) == 1
    day = date(Y, 3, 20)
    rep = ST.daily_report(db, day, f1, "elec")
    assert rep["total"]["u"] == 160 and rep["total"]["n"] == 3 and rep["total"]["n_read"] == 3
    assert [g["name"] for g in rep["groups"]] == ["AR5", "Kubota"]
    kub = next(g for g in rep["groups"] if g["name"] == "Kubota")
    assert kub["sub"]["u"] == 150 and kub["sections"][0]["name"] == "MFG.1" and len(kub["sections"][0]["lines"]) == 2
    rep2 = ST.daily_report(db, day, f1, "elec", kb, "MFG.1", "Line 01")
    assert rep2["total"]["u"] == 100 and rep2["total"]["n"] == 1
    assert rep2["rows"][0]["mtd"] == 2000 and rep2["rows"][0]["avg7"] == 100
    assert ST.daily_xlsx(db, day, f1, "elec")[:2] == b"PK"
    sh = EN.month_sheet(db, f1, "elec", date(Y, 3, 1), kb)
    assert len(sh["meters"]) == 2
    d = EN.dashboard(db, date(Y, 3, 1), f1, None, date(Y, 3, 21), None, kb, None)
    assert d["kinds"][0]["n_meters"] == 2


def test_struct_pages(app, client, db):
    f1 = app.config["F1"]
    _m(db, f1, "M1", "MFG.1", "Line 01")
    db.commit()
    tok = login(client, "t_admin")
    for u in (f"/energy/daily?factory={f1}&day={Y}-03-20", f"/energy/daily?factory={f1}&day={Y}-03-20&grp=MFG.1&line=Line%2001",
              f"/energy/daily.xlsx?factory={f1}&day={Y}-03-20", f"/energy/meters?factory={f1}&grp=MFG.1", f"/energy/sheet?factory={f1}&month={Y}-03&grp=MFG.1",
              f"/energy/?month={Y}-03&factory={f1}&grp=MFG.1", "/energy/categories?tab=projects", "/energy/categories?tab=sections", "/energy/categories?tab=lines",
              "/energy/meters/new?kind=elec"):
        r = client.get(u)
        assert r.status_code == 200, u
    r = client.post("/energy/categories", data={"csrf_token": tok, "act": "project", "name": "Honda", "color": "#10b981", "tab": "projects"})
    assert r.status_code == 302 and any(p["name"] == "Honda" for p in ST.projects(db))
    r = client.post("/energy/categories", data={"csrf_token": tok, "act": "section_add", "factory_id": f1, "name": "MFG.8", "tab": "sections"})
    assert r.status_code == 302 and any(x["name"] == "MFG.8" for x in ST.sections(db, f1))
    mid = db.execute("SELECT id FROM en_meters WHERE code='M1'").fetchone()[0]
    r = client.post("/energy/meters/bulk", data={"csrf_token": tok, "act": "line", "ids": [mid], "line": "Line 77"})
    assert r.status_code == 302 and EN.meter(db, mid)["line"] == "Line 77"
    assert b"MFG.1" in client.get(f"/energy/daily?factory={f1}&day={Y}-03-20").data


def test_registry_roundtrip_project_line(app, db):
    import io
    from openpyxl import load_workbook
    from ecs import energy_registry as RG
    f1 = app.config["F1"]
    m = _m(db, f1, "R1", "MFG.1")
    pj = ST.projects(db)[0]
    wb = load_workbook(io.BytesIO(RG.export_xlsx(db, f1)))
    ws = wb.worksheets[0]
    hdr = [c.value for c in ws[1]]
    assert "Line" in hdr and "Project" in hdr
    i = [r[0].value for r in ws.iter_rows(min_row=2)].index(m) + 2
    ws.cell(row=i, column=hdr.index("Line") + 1, value="LINE-X")
    ws.cell(row=i, column=hdr.index("Project") + 1, value=pj["name"])
    buf = io.BytesIO()
    wb.save(buf)
    RG.apply(db, RG.parse(buf.getvalue()), None)
    after = EN.meter(db, m)
    assert after["line"] == "LINE-X" and after["project_id"] == pj["id"]
    assert any(l["name"] == "LINE-X" for l in ST.lines(db, f1, "MFG.1"))


def test_v701_report_cost_map_project(app, client, db):
    from ecs import energy_ops as OPS
    f1 = app.config["F1"]
    pj = ST.projects(db)[0]
    a = _m(db, f1, "P1", "MFG.1", "Line A")
    _m(db, f1, "P2", "MFG.2", "Line B")
    assert ST.set_section_project(db, f1, "MFG.1", pj["id"], None) == 1
    assert EN.meter(db, a)["project_id"] == pj["id"]
    db.commit()
    r_all = OPS.section_report(db, f1, "elec", Y)
    r_f = OPS.section_report(db, f1, "elec", Y, project_id=pj["id"])
    assert len(r_f["rows"]) == 1 and r_f["rows"][0]["grp"] == "MFG.1" and r_f["filtered"]
    assert len(r_all["rows"]) >= 2
    r_l = OPS.section_report(db, f1, "elec", Y, grp="MFG.1", by="line")
    assert r_l["rows"][0]["grp"] == "MFG.1 › Line A"
    assert OPS.section_xlsx(db, f1, "elec", Y, project_id=pj["id"], by="line")[:2] == b"PK"
    tok = login(client, "t_admin")
    for u in (f"/energy/report?factory={f1}&year={Y}&project={pj['id']}", f"/energy/report?factory={f1}&grp=MFG.1&by=line",
              f"/energy/report/sections.xlsx?factory={f1}&kind=elec&grp=MFG.1",
              f"/energy/cost/?tab=alloc&factory={f1}&grp=MFG.1", f"/energy/cost/?tab=daily&factory={f1}&project={pj['id']}",
              f"/energy/cost/?tab=meters&factory={f1}&grp=MFG.1&line=Line%20A", f"/energy/?factory={f1}&loc=MFG.1",
              f"/energy/categories?tab=sections&factory={f1}"):
        assert client.get(u).status_code == 200, u
    r = client.post("/energy/categories", data={"csrf_token": tok, "act": "section_project", "tab": "sections", "factory_id": f1,
                                                "old": "MFG.2", "project_id": pj["id"]})
    assert r.status_code in (302, 303)
