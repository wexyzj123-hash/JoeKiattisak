"""v0.53: ล้างรอบ/แจ้งเตือนของรอบตรวจที่ปิดแล้ว · แจ้งหยุดเครื่องได้ทุกคน + หยุดย้อนหลัง (ตัดกะ) · สถานะการจับรอบหลังสแกน · ประวัติผู้กดหยุด/เดิน"""
from datetime import timedelta

from conftest import GOOD, login, payload, uid

from ecs import anomaly as A
from ecs import masterdata as M
from ecs import services as S
from ecs import submissions as SUB


def _sched(db, fid):
    return S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00"}, uid(db, "t_admin"))


def _round(db, sid, fid, due, mins=120, status="pending"):
    rid = db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                        VALUES (?,?,?,?,?,?,?)""", (sid, fid, S.ts(due), S.ts(due + timedelta(minutes=mins)),
                                                     S.ts(due + timedelta(minutes=mins * 2)), status, S.ts(due))).lastrowid
    db.commit()
    return rid


def test_closed_schedule_clears_rounds_and_alerts(app, db, published_form):
    fid = published_form["form_id"]
    sid = _sched(db, fid)
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    now = S.now_dt()
    stale = _round(db, sid, fid, now - timedelta(hours=3), mins=60, status="overdue")
    gone = _round(db, sid, fid, now - timedelta(days=2), mins=60, status="missed")
    form = S.get_form(db, fid)
    A.raise_alert(db, alert_type="missed", form=form, severity="warning", round_id=gone, title="ขาดตรวจ", detail="x")
    db.commit()
    S.delete_schedule(db, sid, uid(db, "t_admin"))
    db.commit()
    assert not db.execute("SELECT 1 FROM cs_rounds WHERE id=?", (stale,)).fetchone()
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (gone,)).fetchone()[0] == "missed"      # ประวัติยังอยู่
    assert db.execute("SELECT status FROM cs_alerts WHERE round_id=?", (gone,)).fetchone()[0] == "closed"


def test_orphans_cleaned_by_job_and_not_alerted(app, db, published_form):
    fid = published_form["form_id"]
    sid = _sched(db, fid)
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    now = S.now_dt()
    rid = _round(db, sid, fid, now - timedelta(hours=5), mins=60, status="overdue")
    db.execute("UPDATE cs_schedules SET active=0 WHERE id=?", (sid,))      # ปิดแบบไม่ผ่านหน้าเว็บ (ข้อมูลเก่า)
    db.commit()
    assert not SUB.open_round_for_form(db, fid)
    res = S.refresh_round_statuses(db)
    db.commit()
    assert res["cleaned"] == 1 and not db.execute("SELECT 1 FROM cs_rounds WHERE id=?", (rid,)).fetchone()
    assert A.check_missed(db) == 0


def test_open_round_prefers_current(app, db, published_form):
    fid = published_form["form_id"]
    sid = _sched(db, fid)
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    now = S.now_dt()
    _round(db, sid, fid, now - timedelta(hours=10), mins=300, status="overdue")    # ค้างตั้งแต่เช้า (ยังไม่ตัดรอบ)
    cur = _round(db, sid, fid, now - timedelta(minutes=10), mins=120)
    assert SUB.open_round_for_form(db, fid)["id"] == cur
    pkg = SUB.form_package(db, fid)
    assert pkg["round"]["id"] == cur and pkg["current_round"] is None
    nxt = _round(db, sid, fid, now + timedelta(hours=8), mins=60)
    assert SUB.form_package(db, fid)["next_round"]["id"] == nxt
    res = SUB.create_submission(db, payload(published_form, GOOD), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    assert res["round_status"] == "done_on_time" and res["round_due"] == S.ts(now - timedelta(minutes=10))


def test_anyone_can_stop_machine_and_backdate(app, client, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    sid = _sched(db, fid)
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    now = S.now_dt()
    missed = _round(db, sid, fid, now - timedelta(hours=6), mins=60, status="missed")
    A.raise_alert(db, alert_type="missed", form=S.get_form(db, fid), severity="warning", round_id=missed, title="ขาดตรวจ", detail="x")
    db.commit()
    tok = login(client, "t_tech2")                                          # ช่างโรงงาน 2 แจ้งหยุดเครื่องโรงงาน 1 ได้
    far = (now - timedelta(hours=30)).strftime("%Y-%m-%dT%H:%M")
    assert client.post(f"/api/m/equipment/{eq}/down", json={"category": "pm", "since": far},
                       headers={"X-CSRF-Token": tok}).status_code == 422
    since = (now - timedelta(hours=7)).strftime("%Y-%m-%dT%H:%M")
    r = client.post(f"/api/m/equipment/{eq}/down", json={"category": "pm", "since": since}, headers={"X-CSRF-Token": tok})
    assert r.status_code == 200, r.get_json()
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (missed,)).fetchone()[0] == "skipped"
    assert db.execute("SELECT status FROM cs_alerts WHERE round_id=?", (missed,)).fetchone()[0] == "closed"
    tok = login(client, "t_view")                                           # ผู้ดูก็กดเดินเครื่องได้
    assert client.post(f"/api/m/equipment/{eq}/running", json={}, headers={"X-CSRF-Token": tok}).status_code == 200
    dt = db.execute("SELECT started_by, ended_by FROM cs_downtime WHERE equipment_id=?", (eq,)).fetchone()
    assert dt[0] == uid(db, "t_tech2") and dt[1] == uid(db, "t_view")
    login(client, "t_admin")
    html = client.get(f"/equipment/{eq}").get_data(as_text=True)
    assert "กดหยุดโดย" in html and "กดเดินเครื่องโดย" in html and "ทดสอบ t_view" in html


def test_fill_js_round_card(app, client):
    js = client.get("/static/m/fill.js").get_data(as_text=True)
    assert "roundCard" in js and "จับรอบแล้ว" in js and "ตรวจนอกรอบ — ไม่นับเป็นรอบตรวจ" in js and "round_due" in js
    dj = client.get("/static/m/down.js").get_data(as_text=True)
    assert "dnSince" in dj
