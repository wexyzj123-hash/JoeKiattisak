"""v0.61: หน้าติดตามรอบตรวจ — สีสถานะ · การ์ดกรอง · ลิงก์สถานะเครื่อง"""
from datetime import timedelta

from conftest import login, uid

from ecs import downtime as DT
from ecs import services as S


def test_rounds_page_colors_and_equipment_links(app, client, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    sid = S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00"}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    due = S.now_dt().replace(hour=0, minute=30, second=0, microsecond=0)
    db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                  VALUES (?,?,?,?,?,'pending',?)""", (sid, fid, S.ts(due), S.ts(due + timedelta(hours=20)), S.ts(due + timedelta(hours=23)), S.ts(due)))
    db.commit()
    DT.set_down(db, eq, uid(db, "t_tech"), "PM ประจำปี", "pm", start_at=S.now_dt() - timedelta(days=1))
    db.commit()
    login(client, "t_sup")
    html = client.get("/rounds").get_data(as_text=True)
    assert 'class="stbar rt-bar"' in html and "rt-card act" in html and 'data-fgrp="down"' in html
    assert f'/equipment/{eq}' in html and "rt-eqcode down" in html and "PM ประจำปี" in html
    assert "st-pill sb-down" in html and "⛔ เครื่องหยุด" in html
    ov = S.rounds_overview(db, S.now_dt().date())
    assert ov["items"] and ov["items"][0]["run_status"] == "down" and ov["items"][0]["equipment_id"] == eq
