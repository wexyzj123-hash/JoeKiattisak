"""v0.20: แจ้งเตือนถึงเวลาตรวจเข้ากลุ่ม (แยกประจำวัน/สัปดาห์/เดือน) · ลบแจ้งเตือนขาดตรวจ"""
from datetime import datetime, timedelta

from conftest import login, uid

from ecs import anomaly as A
from ecs import notify as N
from ecs import services as S


def _channels(db, **rs):
    cfg = {"telegram": {"enabled": "1", "bot_token": "123:ABC", "default_target": "-1001"},
           "teams": {"enabled": "1", "default_target": "https://example.logic.azure.com/wf"},
           "round_start": {"enabled": True, "freqs": ["daily", "weekly"], "channels": ["telegram", "teams"],
                           "use_l1_groups": True, **rs}}
    N.save_settings(db, cfg, uid(db, "t_admin"))
    db.commit()


def _rounds(db, fid, freq="daily"):
    data = {"freq_type": freq, "times": "08:00", "window_min": 240}
    if freq == "weekly":
        data["weekdays"] = ",".join(str(i) for i in range(7))
    if freq == "monthly":
        data["month_day"] = datetime.now().day if datetime.now().day <= 28 else 1
    S.create_schedule(db, fid, data, None)
    today8 = datetime.now().replace(hour=8, minute=0, second=0, microsecond=0)
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('rounds_start', ?)", ((today8 - timedelta(days=2)).strftime("%Y-%m-%d"),))
    S.generate_rounds(db, today8)
    db.commit()
    return today8


def _outbox(db):
    return [dict(r) for r in db.execute("SELECT * FROM cs_msg_outbox WHERE ref_key LIKE 'round_start:%' ORDER BY id")]


def test_round_start_to_groups(app, db, published_form):
    _channels(db)
    t8 = _rounds(db, published_form["form_id"])
    res = N.round_start_reminders(db, t8 + timedelta(minutes=2))
    db.commit()
    msgs = _outbox(db)
    assert res["started"] == 1 and {m["channel"] for m in msgs} == {"telegram", "teams"}
    m = msgs[0]
    assert m["subject"].startswith("📅 ถึงเวลาตรวจประจำวัน") and "(1 รายการ)" in m["subject"]
    assert "SCT0002 · Daily AC — ภายใน 12:00" in m["body"] and "ประเภท: ตรวจประจำวัน" in m["body"]
    assert N.round_start_reminders(db, t8 + timedelta(minutes=3))["started"] == 0          # ไม่ส่งซ้ำ
    assert len(_outbox(db)) == 2


def test_round_start_filters_and_l1_groups(app, db, published_form):
    _channels(db, freqs=["weekly"], channels=["telegram"])
    t8 = _rounds(db, published_form["form_id"], "daily")
    assert N.round_start_reminders(db, t8 + timedelta(minutes=1))["started"] == 0      # รายวันไม่ได้เลือก
    fid2 = S.create_form(db, {"name": "Weekly AC", "equipment_id": published_form["equipment_id"]}, uid(db, "t_admin"))
    d = S.get_draft(db, fid2)
    S.save_draft_items(db, d["id"], [{"item_key": "a", "name": "A", "item_type": "ok_ng"}], uid(db, "t_admin"))
    S.publish_version(db, d["id"], uid(db, "t_admin"))
    fac = app.config["F1"]
    N.save_levels(db, fac, [{"level": 1, "after_min": 0, "min_severity": "warning", "active": True, "recipients": [
        {"kind": "group", "channel": "telegram", "target": "-100999", "label": "กลุ่ม F1"}]}], uid(db, "t_admin"))
    db.commit()
    _rounds(db, fid2, "weekly")
    res = N.round_start_reminders(db, t8 + timedelta(minutes=5))
    db.commit()
    msgs = _outbox(db)
    assert res["started"] == 1 and len(msgs) == 1
    assert msgs[0]["target"] == "-100999" and msgs[0]["subject"].startswith("🗓 ถึงเวลาตรวจประจำสัปดาห์")
    # เกินช่วงย้อนหลัง 60 นาที → ไม่ส่ง (เปิดใช้ครั้งแรกไม่ท่วมกลุ่ม)
    db.execute("UPDATE cs_rounds SET start_notified_at=NULL")
    db.execute("DELETE FROM cs_msg_outbox")
    assert N.round_start_reminders(db, t8 + timedelta(hours=3))["started"] == 0


def test_round_start_settings_page(app, db):
    c = app.test_client()
    tok = login(c, "t_admin")
    assert "แจ้งเตือนถึงเวลาตรวจ" in c.get("/admin/notify").get_data(as_text=True)
    c.post("/admin/notify", data={"csrf_token": tok, "rs.enabled": "1", "rs.freqs": ["daily", "monthly"],
                                  "rs.channels": ["teams"], "round_due_before_min": "30", "summary.time": "17:00"})
    rs = N.get_settings(db)["round_start"]
    assert rs == {"enabled": True, "freqs": ["daily", "monthly"], "channels": ["teams"], "use_l1_groups": False}


def test_delete_missed_alerts(app, db, published_form):
    form = S.get_form(db, published_form["form_id"])
    ids = []
    for i in range(3):
        aid, _ = A.raise_alert(db, alert_type="missed", form=dict(form, id=form["id"]), title=f"ขาดตรวจ {i}", detail="x",
                               severity="warning", item_key=f"k{i}")
        ids.append(aid)
    ng, _ = A.raise_alert(db, alert_type="ng", form=form, title="NG", detail="x", severity="warning", item_key="oil")
    db.execute("UPDATE cs_alerts SET status='acknowledged' WHERE id=?", (ids[0],))
    db.commit()
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get("/alerts").get_data(as_text=True)
    assert "ลบขาดตรวจทั้งหมด (3)" in page and f'value="{ids[0]}"' in page       # รับทราบแล้วก็เลือกได้
    r = c.post(f"/alerts/{ids[0]}/delete", data={"csrf_token": tok, "next": "/alerts?status=open"})
    assert r.status_code == 302 and not db.execute("SELECT 1 FROM cs_alerts WHERE id=?", (ids[0],)).fetchone()
    c.post(f"/alerts/{ng}/delete", data={"csrf_token": tok})
    assert db.execute("SELECT 1 FROM cs_alerts WHERE id=?", (ng,)).fetchone()           # ประเภทอื่นลบไม่ได้
    c.post("/alerts/bulk", data={"csrf_token": tok, "action": "delete", "ids": [str(ids[1]), str(ng)]})
    assert not db.execute("SELECT 1 FROM cs_alerts WHERE id=?", (ids[1],)).fetchone()
    c.post("/alerts/bulk", data={"csrf_token": tok, "action": "delete_all", "status": "open"})
    assert db.execute("SELECT COUNT(*) FROM cs_alerts WHERE alert_type='missed'").fetchone()[0] == 0
    assert db.execute("SELECT COUNT(*) FROM cs_alerts WHERE alert_type='ng'").fetchone()[0] == 1
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE entity='cs_alerts' AND action='delete'").fetchone()[0] == 3
    login(c, "t_tech")
    assert c.post("/alerts/bulk", data={"csrf_token": tok, "action": "delete_all"}).status_code in (302, 400, 403)
