"""Phase 4: ขั้นตอนแจ้งเตือน, ส่งต่อ L1–L3, ช่องทางส่ง/คิว, ช่วงเงียบ, เตือนรอบตรวจ, CAPA"""
import io
import json
from datetime import datetime, timedelta

import pytest

from ecs import anomaly as A
from ecs import capa as C
from ecs import notify as N
from ecs import submissions as SUB
from ecs.services import ValidationError, ts

from conftest import GOOD, login, payload, png_bytes, uid

T0 = datetime(2026, 9, 1, 8, 0, 0)


def photo():
    from werkzeug.datastructures import FileStorage
    return FileStorage(io.BytesIO(png_bytes()), filename="p.png")


def make_alert(db, form, severity="warning", created=T0, item_key="oil", alert_type="ng"):
    f = {"id": form["form_id"], "equipment_id": form["equipment_id"]}
    aid, _ = A.raise_alert(db, alert_type=alert_type, form=f, title=f"{alert_type} test", detail="รายละเอียด",
                           severity=severity, item_key=item_key, now=created)
    db.commit()
    return aid


def notes(db, username):
    return db.execute("SELECT * FROM cs_notifications WHERE user_id=? ORDER BY id", (uid(db, username),)).fetchall()


@pytest.fixture()
def sent(monkeypatch):
    """แทนตัวส่งจริงด้วยตัวบันทึก"""
    log = []

    def fake(ch):
        def _send(cfg, target, subject, body, url):
            if target == "fail":
                raise N.SendError("boom")
            log.append((ch, target, subject))
        return _send
    for ch in N.CHANNELS:
        monkeypatch.setitem(N.SENDERS, ch, fake(ch))
    return log


def enable(db, **targets):
    cfg = {ch: {"enabled": True, "default_target": targets.get(ch, "")} for ch in N.CHANNELS}
    cfg["telegram"]["bot_token"] = "123:SECRETTOKEN"
    cfg["line"]["access_token"] = "LINETOKEN"
    cfg["email"].update(host="smtp.local", sender="ecs@local", port=25, security="none")
    if targets.get("teams"):
        cfg["teams"]["default_target"] = targets["teams"]
    N.save_settings(db, cfg, None)
    db.commit()


# ───────────────────────── ขั้นตอนแจ้งเตือน ─────────────────────────

def test_alert_workflow(db, published_form):
    aid = make_alert(db, published_form)
    admin = uid(db, "t_admin")
    with pytest.raises(ValidationError):
        A.set_alert_status(db, aid, "close", admin)                       # ต้องแก้ไขก่อน
    assert A.set_alert_status(db, aid, "ack", admin)["status"] == "acknowledged"
    a = A.set_alert_status(db, aid, "start", admin, assign_to=uid(db, "t_tech"))
    assert a["status"] == "in_progress" and a["assigned_name"] == "ทดสอบ t_tech"
    with pytest.raises(ValidationError) as e:
        A.set_alert_status(db, aid, "resolve", admin, action_taken="แก้แล้ว")
    assert "สาเหตุ" in e.value.errors[0]
    a = A.set_alert_status(db, aid, "resolve", admin, root_cause="สายพานหลวม", action_taken="ปรับตั้งสายพาน")
    assert a["status"] == "resolved" and a["resolved_at"]
    with pytest.raises(ValidationError):
        A.set_alert_status(db, aid, "reopen", admin)                      # ต้องมีเหตุผล
    a = A.set_alert_status(db, aid, "close", admin, "ค่าปกติ 3 รอบ")
    assert a["status"] == "closed" and a["close_note"] == "ค่าปกติ 3 รอบ"
    a = A.set_alert_status(db, aid, "reopen", admin, "กลับมาเสียอีก")
    assert a["status"] == "in_progress" and not a["closed_at"]
    events = [e["event"] for e in a["events"]]
    assert events[:5] == ["reopen", "close", "resolve", "start", "ack"]


# ───────────────────────── escalation ─────────────────────────

def test_default_escalation_l1_then_l2(db, published_form):
    aid = make_alert(db, published_form)
    N.escalate(db, T0 + timedelta(minutes=1))
    assert len(notes(db, "t_sup")) == 1 and not notes(db, "t_sup2")        # หัวหน้าโรงงานอื่นไม่ได้รับ
    assert not notes(db, "t_admin")
    N.escalate(db, T0 + timedelta(minutes=5))                            # ไม่ส่งซ้ำ
    assert len(notes(db, "t_sup")) == 1
    N.escalate(db, T0 + timedelta(minutes=31))
    assert len(notes(db, "t_admin")) == 1
    a = A.get_alert(db, aid)
    assert a["notified_level"] == 2 and {"notify", "escalate"} <= {e["event"] for e in a["events"]}


def test_ack_stops_escalation_and_info_is_quiet(db, published_form):
    aid = make_alert(db, published_form)
    N.escalate(db, T0)
    A.set_alert_status(db, aid, "ack", uid(db, "t_sup"), now=T0 + timedelta(minutes=10))
    N.escalate(db, T0 + timedelta(minutes=45))
    assert not notes(db, "t_admin")
    make_alert(db, published_form, severity="info", item_key="x", alert_type="warn")
    N.escalate(db, T0 + timedelta(minutes=50))
    assert len(notes(db, "t_sup")) == 1


def test_sla_reminder_after_ack(db, published_form):
    aid = make_alert(db, published_form, severity="critical")
    N.escalate(db, T0)
    A.set_alert_status(db, aid, "ack", uid(db, "t_sup"), now=T0 + timedelta(minutes=5))
    N.escalate(db, T0 + timedelta(hours=7))
    assert not notes(db, "t_admin")
    N.escalate(db, T0 + timedelta(hours=8, minutes=1))                    # SLA วิกฤต 8 ชม.
    assert len(notes(db, "t_admin")) == 1 and "ยังไม่แก้ไข" in notes(db, "t_admin")[0]["title"]
    N.escalate(db, T0 + timedelta(hours=9))                               # ไม่ซ้ำในรอบ SLA เดียวกัน
    assert len(notes(db, "t_admin")) == 1


def test_factory_levels_users_groups_and_outbox(db, published_form, app, sent):
    enable(db, telegram="-100999")
    db.execute("UPDATE users SET telegram_chat_id='555', line_user_id=? WHERE username='t_sup'", ("U" + "a" * 32,))
    db.commit()
    N.save_levels(db, app.config["F1"], [
        {"level": 1, "active": True, "after_min": 0, "min_severity": "info",
         "recipients": [{"kind": "user", "user_id": uid(db, "t_sup")}, {"kind": "group", "channel": "telegram", "target": "default"},
                        {"kind": "group", "channel": "teams", "target": "https://example.com/hook"}]},
        {"level": 2, "active": False, "after_min": 10, "min_severity": "warning", "recipients": []}], None)
    db.commit()
    make_alert(db, published_form, severity="info")
    N.escalate(db, T0)
    db.commit()
    rows = db.execute("SELECT channel, target FROM cs_msg_outbox ORDER BY id").fetchall()
    assert sorted(tuple(r) for r in rows) == sorted([("telegram", "555"), ("line", "U" + "a" * 32),
                                                      ("telegram", "-100999"), ("teams", "https://example.com/hook")])
    res = N.process_outbox(db, T0)
    assert res["sent"] == 4 and len(sent) == 4
    N.reset_factory_levels(db, app.config["F1"], None)
    assert N.get_levels(db, app.config["F1"])[0]["factory_id"] is None   # กลับไปใช้ค่ารวม


def test_save_levels_validation(db):
    with pytest.raises(ValidationError):
        N.save_levels(db, None, [{"level": 1, "active": True, "after_min": 0, "min_severity": "warning",
                                  "recipients": [{"kind": "group", "channel": "teams", "target": "not-a-url"}]}], None)
    with pytest.raises(ValidationError):
        N.save_levels(db, None, [{"level": 1, "active": True, "after_min": 30, "recipients": []},
                                 {"level": 2, "active": True, "after_min": 10, "recipients": []}], None)


def test_outbox_retry_backoff_and_fail(db, published_form, sent):
    enable(db)
    cfg = N.get_settings(db)
    mid = N.enqueue(db, cfg, "telegram", "fail", "s", "b", now=T0)
    assert N.enqueue(db, cfg, "telegram", "fail", "s", "b", ref_key="k", now=T0)
    assert N.enqueue(db, cfg, "telegram", "fail", "s", "b", ref_key="k", now=T0) is None      # กันซ้ำ
    db.commit()
    now = T0
    for i in range(N.MAX_ATTEMPTS):
        N.process_outbox(db, now)
        now += timedelta(hours=4)
    row = db.execute("SELECT * FROM cs_msg_outbox WHERE id=?", (mid,)).fetchone()
    assert row["status"] == "failed" and row["attempts"] == N.MAX_ATTEMPTS and "boom" in row["last_error"]
    N.retry_message(db, mid)
    assert db.execute("SELECT status, attempts FROM cs_msg_outbox WHERE id=?", (mid,)).fetchone()[:] == ("pending", 0)
    assert N.enqueue(db, cfg, "telegram", "", "s", "b") is None


def test_secret_not_logged(db, monkeypatch):
    enable(db)
    def leak(cfg, target, subject, body, url):
        raise N.SendError("bad token 123:SECRETTOKEN")
    monkeypatch.setitem(N.SENDERS, "telegram", leak)
    N.enqueue(db, N.get_settings(db), "telegram", "1", "s", "b", now=T0)
    db.commit()
    N.process_outbox(db, T0)
    err = db.execute("SELECT last_error FROM cs_msg_outbox").fetchone()[0]
    assert "SECRETTOKEN" not in err and "***" in err


def test_silence_blocks_notify(db, published_form):
    admin = uid(db, "t_admin")
    with pytest.raises(ValidationError):
        N.save_silence(db, {"starts_at": ts(T0), "ends_at": ts(T0 + timedelta(hours=1)), "reason": "x"}, admin)
    with pytest.raises(ValidationError):
        N.save_silence(db, {"equipment_id": published_form["equipment_id"], "starts_at": ts(T0), "ends_at": ts(T0),
                            "reason": "x"}, admin)
    sid = N.save_silence(db, {"equipment_id": published_form["equipment_id"], "starts_at": ts(T0 - timedelta(hours=1)),
                              "ends_at": ts(T0 + timedelta(hours=2)), "reason": "PM"}, admin)
    aid = make_alert(db, published_form)
    N.escalate(db, T0 + timedelta(minutes=40))
    N.escalate(db, T0 + timedelta(minutes=50))
    assert not notes(db, "t_sup") and not notes(db, "t_admin")
    ev = [e for e in A.get_alert(db, aid)["events"] if e["event"] == "silenced"]
    assert len(ev) == 1 and "PM" in ev[0]["detail"]
    N.escalate(db, T0 + timedelta(hours=3))                                   # หมดช่วงเงียบ → ส่ง L1+L2
    assert notes(db, "t_sup") and notes(db, "t_admin")
    N.cancel_silence(db, sid, admin)
    assert N.list_silences(db) == []


def test_round_reminders(db, published_form):
    fid = published_form["form_id"]
    sid = db.execute("""INSERT INTO cs_schedules(form_id, freq_type, times, assignee_role, created_at, updated_at)
                        VALUES (?, 'daily', '08:00', 'technician', ?, ?)""", (fid, ts(T0), ts(T0))).lastrowid
    db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                  VALUES (?,?,?,?,?, 'pending', ?)""", (sid, fid, ts(T0), ts(T0 + timedelta(minutes=20)),
                                                        ts(T0 + timedelta(hours=4)), ts(T0)))
    db.commit()
    res = N.round_reminders(db, T0 + timedelta(minutes=1))
    assert res["due"] == 1 and len(notes(db, "t_tech")) == 1 and not notes(db, "t_tech2")
    assert N.round_reminders(db, T0 + timedelta(minutes=2))["due"] == 0
    db.execute("UPDATE cs_rounds SET status='overdue'")
    res = N.round_reminders(db, T0 + timedelta(minutes=30))
    assert res["overdue"] == 1 and "เลยกำหนด" in notes(db, "t_tech")[-1]["title"]


def test_daily_summary(db, sent):
    enable(db, telegram="-1", email="team@x.co")
    s = N.get_settings(db)
    s["daily_summary"] = {"enabled": True, "time": "17:00"}
    N.save_settings(db, {**s, "sla_hours": s["sla_hours"], "daily_summary": s["daily_summary"],
                         "round_due_before_min": 30}, None)
    assert not N.daily_summary(db, T0.replace(hour=16))
    assert N.daily_summary(db, T0.replace(hour=17, minute=5))
    assert not N.daily_summary(db, T0.replace(hour=18))                   # วันละครั้ง
    targets = {r[0] for r in db.execute("SELECT target FROM cs_msg_outbox")}
    assert targets == {"-1", "team@x.co"}


def test_settings_secrets(db, monkeypatch):
    enable(db)
    masked = N.get_settings(db, with_secrets=False)
    assert masked["telegram"]["bot_token"].endswith("OKEN") and "SECRET" not in masked["telegram"]["bot_token"]
    N.save_settings(db, {"telegram": {"enabled": "1", "bot_token": ""}}, None)          # ว่าง = ใช้ค่าเดิม
    assert N.get_settings(db)["telegram"]["bot_token"] == "123:SECRETTOKEN"
    N.save_settings(db, {"telegram": {"enabled": "1", "bot_token": "", "clear_bot_token": "1"}}, None)
    assert N.get_settings(db)["telegram"]["bot_token"] == ""
    with pytest.raises(ValidationError):
        N.save_settings(db, {"teams": {"enabled": "1", "default_target": "http://x"}}, None)
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "999:ENV")
    assert N.get_settings(db)["telegram"]["bot_token"] == "999:ENV"


def test_sender_payloads(monkeypatch):
    calls = []
    monkeypatch.setattr(N, "_http_json", lambda url, payload, headers=None, timeout=12: calls.append((url, payload, headers)) or '{"ok":true}')
    cfg = {"telegram": {"bot_token": "T"}, "line": {"access_token": "L"}}
    N.send_telegram(cfg, "-1", "หัวข้อ <b>", "เนื้อหา & ", "http://x/alerts/1")
    assert calls[-1][0].endswith("/botT/sendMessage") and "&lt;b&gt;" in calls[-1][1]["text"] and calls[-1][1]["parse_mode"] == "HTML"
    N.send_line(cfg, "U1", "s", "b", "")
    assert calls[-1][2]["Authorization"] == "Bearer L" and calls[-1][1]["messages"][0]["text"] == "s\nb"
    N.send_teams(cfg, "https://prod.azure.com/workflows/x", "s", "b", "http://u")
    assert calls[-1][1]["attachments"][0]["content"]["type"] == "AdaptiveCard"
    N.send_teams(cfg, "https://abc.webhook.office.com/x", "s", "b", "")
    assert "text" in calls[-1][1]
    with pytest.raises(N.SendError):
        N.send_telegram({"telegram": {}}, "1", "s", "b", "")


# ───────────────────────── CAPA ─────────────────────────

def test_capa_from_alert_full_cycle(app, db, published_form):
    sup, tech = uid(db, "t_sup"), uid(db, "t_tech")
    aid = make_alert(db, published_form, severity="critical", created=datetime.now())
    cid = C.create_from_alert(db, aid, sup)
    assert C.create_from_alert(db, aid, sup) == cid                      # ไม่สร้างซ้ำ
    c = C.get_action(db, cid)
    assert c["code"].startswith("CAPA-") and c["priority"] == "urgent" and c["owner_id"] == sup
    assert A.get_alert(db, aid)["status"] == "in_progress"
    C.update_action(db, cid, {"owner_id": tech}, sup)
    assert notes(db, "t_tech") and "มอบหมาย" in notes(db, "t_tech")[-1]["title"]
    C.transition(db, cid, "start", tech)
    with pytest.raises(ValidationError):
        C.transition(db, cid, "done", tech, action_taken="เปลี่ยนแล้ว")      # ต้องมีสาเหตุ
    C.add_photo(db, cid, "after", photo(), app.config["UPLOAD_FOLDER"], 8 * 1024 * 1024, tech)
    C.transition(db, cid, "done", tech, root_cause="ไส้กรองตัน", action_taken="เปลี่ยนไส้กรอง")
    assert any("รอตรวจรับ" in n["title"] for n in notes(db, "t_sup"))
    with pytest.raises(ValidationError):
        C.transition(db, cid, "reject", sup)                                # ต้องมีเหตุผล
    C.transition(db, cid, "verify", sup, note="ตรวจแล้ว")
    c = C.get_action(db, cid)
    assert c["status"] == "closed" and len([p for p in c["photos"] if p["kind"] == "after"]) == 1
    a = A.get_alert(db, aid)
    assert a["status"] == "resolved" and a["root_cause"] == "ไส้กรองตัน"
    with pytest.raises(ValidationError):
        C.add_photo(db, cid, "after", photo(), app.config["UPLOAD_FOLDER"], 8 * 1024 * 1024, tech)   # ปิดแล้ว


def test_capa_from_ng_copies_photos(app, db, published_form):
    ng = {**GOOD, "noise": {"value": "NG", "remark": "ดังผิดปกติ", "photos": ["p1"]}}
    res = SUB.create_submission(db, payload(published_form, ng), {"p1": photo()}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    # ผลตรวจ NG สร้างแจ้งเตือนแล้ว → ใช้แจ้งเตือนเดิมเป็นต้นทาง
    cid = C.create_from_ng(db, res["id"], "noise", uid(db, "t_sup"))
    c = C.get_action(db, cid)
    assert c["alert_id"] and [p["kind"] for p in c["photos"]] == ["before"]
    with pytest.raises(ValidationError):
        C.create_from_ng(db, res["id"], "nope", uid(db, "t_sup"))


def test_capa_reminders_and_counts(db, published_form):
    sup, tech = uid(db, "t_sup"), uid(db, "t_tech")
    today = datetime.now()
    c1 = C.create_action(db, {"title": "เลยกำหนด", "owner_id": tech, "due_date": (today.date() - timedelta(days=2)).isoformat(),
                              "form_id": published_form["form_id"]}, sup)
    C.create_action(db, {"title": "พรุ่งนี้", "owner_id": tech, "due_date": (today.date() + timedelta(days=1)).isoformat()}, sup)
    C.create_action(db, {"title": "อีกนาน", "owner_id": tech, "due_date": (today.date() + timedelta(days=20)).isoformat()}, sup)
    res = C.capa_reminders(db, today)
    assert res == {"capa_due": 1, "capa_overdue": 1}
    assert C.capa_reminders(db, today) == {"capa_due": 0, "capa_overdue": 0}         # วันละครั้ง
    assert any("เลยกำหนด" in n["title"] for n in notes(db, "t_sup"))               # หัวหน้าได้รับเมื่อเลยกำหนด
    counts = C.action_counts(db)
    assert counts["active"] == 3 and counts["overdue"] == 1
    assert [r["id"] for r in C.list_actions(db, overdue=True)] == [c1]
    with pytest.raises(ValidationError):
        C.create_action(db, {"title": ""}, sup)


# ───────────────────────── web ─────────────────────────

def test_bell_api(client, db, published_form):
    make_alert(db, published_form, created=datetime.now())
    N.escalate(db)
    db.commit()
    tok = login(client, "t_sup")
    d = client.get("/api/notifications").get_json()
    assert d["unread"] == 1 and d["items"][0]["url"].startswith("/alerts/")
    nid = d["items"][0]["id"]
    assert client.get(f"/n/{nid}").headers["Location"].startswith("/alerts/")
    assert client.get("/api/notifications").get_json()["unread"] == 0
    r = client.post("/api/notifications/read", json={}, headers={"X-CSRF-Token": tok, "Accept": "application/json"})
    assert r.get_json()["ok"]
    assert "การแจ้งเตือนของฉัน" in client.get("/notifications").get_data(as_text=True)
    db.execute("UPDATE cs_notifications SET url='//evil.com'")
    db.commit()
    assert client.get(f"/n/{nid}").headers["Location"] in ("/", "http://localhost/")          # กัน open redirect


def test_capa_web_permissions(client, db, published_form):
    sup, tech = uid(db, "t_sup"), uid(db, "t_tech")
    mine = C.create_action(db, {"title": "งานของช่าง", "owner_id": tech}, sup)
    other = C.create_action(db, {"title": "งานคนอื่น", "owner_id": sup}, sup)
    db.commit()
    tok = login(client, "t_tech")
    body = client.get("/actions").get_data(as_text=True)
    assert "งานของช่าง" in body and "งานคนอื่น" not in body
    assert client.get(f"/actions/{other}").status_code == 404
    assert client.post(f"/actions/{mine}/start", data={"csrf_token": tok}).status_code == 302
    r = client.post(f"/actions/{mine}/done", data={"csrf_token": tok, "root_cause": "ก", "action_taken": "ข"})
    assert r.status_code == 302 and C.get_action(db, mine)["status"] == "done"
    assert client.post(f"/actions/{mine}/verify", data={"csrf_token": tok}).status_code == 403
    assert client.get("/actions/new").status_code == 403
    client.post("/logout", data={"csrf_token": tok})
    tok = login(client, "t_sup")
    assert client.post(f"/actions/{mine}/verify", data={"csrf_token": tok}).status_code == 302
    assert C.get_action(db, mine)["status"] == "closed"
    r = client.post("/actions/new", data={"csrf_token": tok, "title": "ใหม่", "owner_id": tech, "due_date": "2026-12-01"})
    assert r.status_code == 302 and "/actions/" in r.headers["Location"]


def test_alert_web_actions(client, db, published_form):
    aid = make_alert(db, published_form, created=datetime.now())
    tok = login(client, "t_view")
    assert client.post(f"/alerts/{aid}/ack", data={"csrf_token": tok}).status_code == 403
    client.post("/logout", data={"csrf_token": tok})
    tok = login(client, "t_sup")
    assert client.post(f"/alerts/{aid}/assign", data={"csrf_token": tok, "assign_to": uid(db, "t_tech")}).status_code == 302
    r = client.post(f"/alerts/{aid}/capa", data={"csrf_token": tok})
    assert r.status_code == 302 and "/actions/" in r.headers["Location"]
    assert A.get_alert(db, aid)["status"] == "in_progress"
    aid2 = make_alert(db, published_form, item_key="noise", created=datetime.now())
    assert client.post("/alerts/bulk", data={"csrf_token": tok, "action": "ack", "ids": [str(aid2)]}).status_code == 302
    assert A.get_alert(db, aid2)["status"] == "acknowledged"
    client.post("/logout", data={"csrf_token": tok})
    tok = login(client, "t_tech")                                   # ช่างที่ได้รับมอบหมายบันทึกการแก้ไขได้
    r = client.post(f"/alerts/{aid}/resolve", data={"csrf_token": tok, "root_cause": "a", "action_taken": "b"})
    assert r.status_code == 302 and A.get_alert(db, aid)["status"] == "resolved"
    assert client.post(f"/alerts/{aid}/close", data={"csrf_token": tok}).status_code == 403


def test_admin_pages_and_escalation_form(client, db):
    tok = login(client, "t_admin")
    for p in ("/admin/notify", "/admin/escalation", "/admin/outbox", "/admin/silences", "/account/notify", "/actions",
              "/admin/escalation?factory=1"):
        assert client.get(p).status_code == 200, p
    payload_ = [{"level": 1, "active": True, "after_min": 0, "min_severity": "warning",
                 "recipients": [{"kind": "user", "user_id": uid(db, "t_sup2")}]},
                {"level": 2, "active": True, "after_min": 15, "min_severity": "critical", "recipients": []},
                {"level": 3, "active": False, "after_min": 60, "min_severity": "critical", "recipients": []}]
    r = client.post("/admin/escalation", data={"csrf_token": tok, "factory": "", "payload": json.dumps(payload_)})
    assert r.status_code == 302
    lv = N.get_levels(db, None)
    assert [x["after_min"] for x in lv] == [0, 15, 60] and lv[0]["recipients"][0]["user_id"] == uid(db, "t_sup2")
    r = client.post("/admin/notify", data={"csrf_token": tok, "telegram.enabled": "1", "telegram.bot_token": "1:X",
                                           "sla.critical": "4", "sla.warning": "12", "sla.info": "0",
                                           "round_due_before_min": "15", "summary.time": "16:30"})
    assert r.status_code == 302 and N.get_settings(db)["sla_hours"]["critical"] == 4
    r = client.post("/admin/notify/test", json={"channel": "line"}, headers={"X-CSRF-Token": tok, "Accept": "application/json"})
    assert r.status_code == 400
    r = client.post("/admin/silences", data={"csrf_token": tok, "factory_id": "1", "starts_at": "2026-09-01T08:00",
                                             "ends_at": "2026-09-01T12:00", "reason": "PM"})
    assert r.status_code == 302


def test_supervisor_cannot_open_admin_notify(client):
    login(client, "t_sup")
    assert client.get("/admin/notify").status_code == 403
    assert client.get("/admin/escalation").status_code == 403
    assert client.get("/admin/silences").status_code == 200


def test_my_notify(client, db):
    tok = login(client, "t_tech")
    r = client.post("/account/notify", data={"csrf_token": tok, "telegram_chat_id": "abc", "channels": ["telegram"]})
    assert "ต้องเป็นตัวเลข" in r.get_data(as_text=True)
    r = client.post("/account/notify", data={"csrf_token": tok, "telegram_chat_id": "12345", "email": "t@x.co",
                                             "channels": ["telegram"]})
    assert r.status_code == 302
    u = db.execute("SELECT * FROM users WHERE username='t_tech'").fetchone()
    assert u["telegram_chat_id"] == "12345" and u["notify_channels"] == "app,telegram"
    assert client.post("/account/notify/test", data={"csrf_token": tok}).status_code == 302
    assert notes(db, "t_tech")


def test_tick_end_to_end(app, db, published_form, sent):
    enable(db, telegram="-100")
    N.save_levels(db, None, [{"level": 1, "active": True, "after_min": 0, "min_severity": "warning",
                              "recipients": [{"kind": "group", "channel": "telegram", "target": "default"}]}], None)
    db.commit()
    make_alert(db, published_form, created=datetime.now())
    res = N.tick(app.config["DATABASE"], "http://ecs.local:5100")
    assert res["notified"] == 1 and res["sent"] == 1 and sent[0][:2] == ("telegram", "-100")
    row = db.execute("SELECT url FROM cs_msg_outbox").fetchone()
    assert row["url"].startswith("http://ecs.local:5100/alerts/")
