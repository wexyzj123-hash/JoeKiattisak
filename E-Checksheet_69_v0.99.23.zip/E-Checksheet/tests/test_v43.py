"""v0.43: Dashboard — ค่าที่ตรวจย้อนหลัง รายเครื่องจักร (ทุกหัวข้อ ทุกค่า) แทนค่าเฉลี่ยรายวัน"""
import io
import json
from datetime import timedelta

from conftest import GOOD, login, payload, png_bytes, uid
from werkzeug.datastructures import FileStorage

from ecs import analytics as AN
from ecs import services as S
from ecs import submissions as SUB

NG = dict(GOOD, oil={"value": "3.1", "remark": "แรงดันสูง", "photos": ["p1"]})


def _sub(app, db, form, answers, ago_h=0):
    photos = {"p1": FileStorage(io.BytesIO(png_bytes()), filename="p.png")}
    SUB.create_submission(db, payload(form, answers), photos, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    sid = db.execute("SELECT MAX(id) FROM cs_submissions").fetchone()[0]
    if ago_h:
        db.execute("UPDATE cs_submissions SET finished_at=? WHERE id=?", (S.ts(S.now_dt() - timedelta(hours=ago_h)), sid))
    db.commit()
    return sid


def test_machine_values_all_readings(app, db, published_form):
    fid = published_form["form_id"]
    _sub(app, db, published_form, GOOD, ago_h=50)
    _sub(app, db, published_form, NG, ago_h=5)
    _sub(app, db, published_form, GOOD)
    mv = AN.machine_values(db, fid, 7)
    keys = [i["key"] for i in mv["items"]]
    assert keys == ["oil", "noise", "hour", "filter"]                       # ทุกหัวข้อ (ยกเว้นข้อความ) ตามลำดับ
    oil = mv["items"][0]
    assert oil["type"] == "num" and oil["n"] == 3 and oil["ng"] == 1 and oil["hi"] == 3.1 and oil["min"] == 1.7
    assert [p[3] for p in oil["pts"]] == ["ok", "ng", "ok"] and mv["eq_code"] == "SCT0002"
    assert mv["items"][1]["type"] == "cat" and mv["items"][1]["n"] == 3
    assert any(m["form_id"] == fid for m in AN.machine_list(db))
    db.execute("UPDATE cs_submissions SET finished_at=? WHERE id=(SELECT MIN(id) FROM cs_submissions)",
               (S.ts(S.now_dt() - timedelta(days=20)),))
    db.commit()
    assert AN.machine_values(db, fid, 7)["items"][0]["n"] == 2 and AN.machine_values(db, fid, 30)["items"][0]["n"] == 3


def test_dashboard_card_and_api(app, db, published_form):
    fid = published_form["form_id"]
    _sub(app, db, published_form, GOOD)
    c = app.test_client()
    login(c, "t_sup")
    html = c.get("/dashboard").get_data(as_text=True)
    assert "ค่าที่ตรวจย้อนหลัง รายเครื่อง" in html and 'id="mv-sel"' in html and "machvals.js" in html
    assert "เฉลี่ยรายวัน 7 วัน" not in html
    start = html.index('id="mv-data">') + len('id="mv-data">')
    data = json.loads(html[start:html.index("</script>", start)])
    assert data["form_id"] == fid and data["items"]
    r = c.get(f"/api/machine-values?form={fid}&days=30").get_json()
    assert r["days"] == 30 and r["items"][0]["n"] == 1
    assert c.get("/api/machine-values?form=99999").status_code == 404
    assert c.get(f"/dashboard?mv={fid}&mvd=30").status_code == 200
    assert "pointermove" in c.get("/static/js/machvals.js").get_data(as_text=True)
