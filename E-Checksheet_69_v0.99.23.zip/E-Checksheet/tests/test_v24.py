"""v0.24: ลายเซ็นประจำตัว · ENVIRONMENT/SAFETY ยืนยันในระบบ · เลขที่เอกสารมุมซ้ายล่าง"""
import base64
import io
from datetime import date, timedelta

from conftest import GOOD, login, payload, uid
from openpyxl import load_workbook
from PIL import Image, ImageDraw

from ecs import services as S
from ecs import sheet_report as SR
from ecs import sign_blocks as SB
from ecs import signoffs as SO
from ecs import submissions as SUB


def _sig_png(bg=(255, 255, 255, 255)):
    im = Image.new("RGBA", (400, 150), bg)
    ImageDraw.Draw(im).line([(30, 100), (120, 40), (220, 110), (360, 50)], fill=(0, 0, 0, 255), width=6)
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return buf.getvalue()


def test_process_signature():
    png = SO.process_signature(_sig_png())
    im = Image.open(io.BytesIO(png))
    assert im.mode == "RGBA" and im.getpixel((0, 0))[3] == 0 and im.width <= 600 and im.height <= 200
    assert im.width < 400                                        # ตัดขอบว่าง
    try:
        SO.process_signature(_sig_png()[:0] or Image.new("RGB", (50, 50), "white").tobytes())
        raise AssertionError
    except SO.SignError:
        pass
    blank = io.BytesIO()
    Image.new("RGB", (50, 50), "white").save(blank, "PNG")
    try:
        SO.process_signature(blank.getvalue())
        raise AssertionError
    except SO.SignError as e:
        assert "ไม่พบเส้น" in str(e)


def test_my_signature_page(app, db):
    c = app.test_client()
    tok = login(c, "t_tech")
    assert "เซ็นบนจอ" in c.get("/account/signature").get_data(as_text=True)
    drawn = "data:image/png;base64," + base64.b64encode(_sig_png((0, 0, 0, 0))).decode()
    r = c.post("/account/signature", data={"csrf_token": tok, "drawn": drawn})
    assert r.status_code == 302 and SO.signature_png(db, uid(db, "t_tech"))
    assert c.get("/account/signature.png").status_code == 200
    c.post("/account/signature", data={"csrf_token": tok, "action": "delete"})
    assert SO.signature_png(db, uid(db, "t_tech")) is None


def _sub(app, db, fid, who, when=None):
    from datetime import datetime
    f = S.get_form(db, fid)
    res = SUB.create_submission(db, payload({"form_id": fid, "version_id": f["current_version_id"]}, GOOD), {}, who,
                                app.config["UPLOAD_FOLDER"], now=when)
    db.commit()
    return res["id"] if isinstance(res, dict) else res


def test_signoff_flow_and_documents(app, db, published_form):
    from datetime import datetime
    fid = published_form["form_id"]
    admin, sup, view, tech = (uid(db, u) for u in ("t_admin", "t_sup", "t_view", "t_tech"))
    SB.save(db, [fid], {"rows": ["env_week"], "boxes": ["env"]}, admin)
    SO.save_roles(db, {"env_sv": [view], "env_mgr": [sup]}, admin)
    for u in (view, tech, sup):
        SO.save_signature(db, u, _sig_png())
    db.commit()
    # ผลตรวจวันนี้ (ผู้ตรวจ t_tech) → แถวผู้ตรวจใช้รูปลายเซ็น
    SUB.approve(db, _sub(app, db, fid, tech), sup)
    db.commit()
    # เดือนก่อน (มีผลตรวจวันที่ 15): กล่อง ENVIRONMENT ต้อง SSV/SV ก่อน MANAGER
    pm = (date.today().replace(day=1) - timedelta(days=1)).replace(day=1)
    _sub(app, db, fid, tech, datetime(pm.year, pm.month, 15, 9, 0))
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get(f"/signoffs?month={pm:%Y-%m}").get_data(as_text=True)
    assert "รอ SSV/SV ลงนามก่อน" in page
    r = c.post("/signoffs/sign", data={"csrf_token": tok, "month": f"{pm:%Y-%m}", "slot": [f"{fid}|box:env:0"]})
    assert r.status_code == 302 and not SO.records(db, fid, pm)
    seg15 = next(sg["start"] for sg in SB.week_segments(pm, 31 if pm.month in (1, 3, 5, 7, 8, 10, 12) else 30)
                 if sg["start"] <= 15 < sg["start"] + sg["span"])
    cv = app.test_client()
    tv = login(cv, "t_view")
    cv.post("/signoffs/sign", data={"csrf_token": tv, "month": f"{pm:%Y-%m}",
                                    "slot": [f"{fid}|box:env:1", f"{fid}|row:env_week:{seg15}", f"{fid}|row:env_week:1" if seg15 != 1 else ""]})
    c.post("/signoffs/sign", data={"csrf_token": tok, "month": f"{pm:%Y-%m}", "slot": [f"{fid}|box:env:0"]})
    recs = SO.records(db, fid, pm)
    assert set(recs) == {"box:env:1", f"row:env_week:{seg15}", "box:env:0"} and recs["box:env:0"]["user_id"] == sup   # สัปดาห์ไม่มีผลตรวจ = ไม่ต้องลงนาม
    cv.post("/signoffs/cancel", data={"csrf_token": tv, "month": f"{pm:%Y-%m}", "cancel": f"{fid}|box:env:1"})
    assert "box:env:1" in SO.records(db, fid, pm)
    html = c.get(f"/reports/sheets?form={fid}&month={pm:%Y-%m}").get_data(as_text=True).split("</style>")[1]
    hd = html[html.index('<table class="hd">'):]
    hd = hd[:hd.index("</tr></table>")]
    assert "data:image/png;base64" in hd and 'class="meta"' not in hd
    foot = html[html.index('<div class="foot">'):]
    assert 'class="metab"' in foot and "เลขที่เอกสาร" in foot
    sheet = SR.build_month_sheet(db, fid, pm, "s")
    before = sheet["verify"]
    ws = load_workbook(io.BytesIO(SR.to_excel([sheet]))).worksheets[0]
    assert len(ws._images) >= 3
    c.post("/signoffs/cancel", data={"csrf_token": tok, "month": f"{pm:%Y-%m}", "cancel": f"{fid}|box:env:0"})
    assert "box:env:0" not in SO.records(db, fid, pm)
    assert SR.build_month_sheet(db, fid, pm, "s")["verify"] != before
    m0 = date.today().replace(day=1)
    html = c.get(f"/reports/sheets?form={fid}&month={m0:%Y-%m}").get_data(as_text=True).split("</style>")[1]
    assert html.count('<td class="sig">') == 1                    # แถวผู้ตรวจ (Tech)
    ws = load_workbook(io.BytesIO(SR.to_excel([SR.build_month_sheet(db, fid, m0, "s")]))).worksheets[0]
    assert len(ws._images) >= 1


def test_nav_and_roles_admin(app, db, published_form):
    c = app.test_client()
    tok = login(c, "t_admin")
    view = uid(db, "t_view")
    r = c.post("/signoffs/roles", data={"csrf_token": tok, "safety_sf": [str(view)]})
    assert r.status_code == 302 and SO.get_roles(db)["safety_sf"] == [view]
    assert "ตำแหน่ง / ผู้มีสิทธิ์ลงนาม" in c.get("/signoffs?mine=0").get_data(as_text=True)
    cv = app.test_client()
    login(cv, "t_view")
    home = cv.get("/reports").get_data(as_text=True)
    assert "รออนุมัติ" in home and "ลายเซ็นของฉัน" in home          # v0.27 ลงนามใบบันทึกอยู่ในหมวดรออนุมัติ
