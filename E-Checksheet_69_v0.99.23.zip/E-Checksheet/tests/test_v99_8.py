"""v0.99.8: รอบที่เครื่องหยุด (รวมสำรอง/ไม่ได้เดิน) ต้องนับเป็น "เครื่องหยุด" ไม่ใช่ "ขาดตรวจ" — เกณฑ์เดียวทุกเส้นทาง
เกณฑ์: เครื่องหยุดก่อนเวลาปิดรอบ และยังหยุดอยู่ ณ เวลาปิดรอบ"""
from datetime import date, datetime, timedelta

from conftest import uid

from ecs import anomaly as AL
from ecs import downtime as DT
from ecs import masterdata as M
from ecs import services as S
from ecs import statfix as SF


def _eq_form(app, db, code="SB-01", with_schedule=True):
    admin = uid(db, "t_admin")
    eq = M.save_equipment(db, {"code": code, "name": "Air Compressor", "factory_id": app.config["F1"]}, admin)
    fid = S.create_form(db, {"name": f"Daily {code}", "equipment_id": eq}, admin)
    d = S.get_draft(db, fid)
    S.save_draft_items(db, d["id"], [{"item_key": "a", "name": "ปกติ", "item_type": "ok_ng"}], admin)
    S.publish_version(db, d["id"], admin)
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('rounds_start', ?)",
               ((datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S"),))
    if with_schedule:
        S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00", "window_min": 240}, admin)
    db.commit()
    return eq, fid, admin


def _rounds(db, fid):
    return {r["due_at"][:10]: dict(r) for r in db.execute("SELECT * FROM cs_rounds WHERE form_id=? ORDER BY due_at", (fid,))}


def _gen(db):
    S.generate_rounds(db, now=datetime.now() - timedelta(days=1))     # ให้มีรอบที่ปิดไปแล้วแน่นอน (2 วันก่อน)
    S.generate_rounds(db)


def _closed(db, fid):
    """รอบล่าสุดที่ปิดไปแล้ว"""
    now_s = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return dict(db.execute("SELECT * FROM cs_rounds WHERE form_id=? AND close_at<=? ORDER BY close_at DESC LIMIT 1", (fid, now_s)).fetchone())


def _st(db, rid):
    return db.execute("SELECT status FROM cs_rounds WHERE id=?", (rid,)).fetchone()[0]


def test_rounds_created_after_close_on_standby_machine_are_skipped(app, db):
    """เครื่องสำรองมาตั้งแต่ 2 วันก่อน แล้วเพิ่งตั้ง/แก้รอบตรวจ → รอบเมื่อวาน (ปิดไปแล้ว) ต้องเป็นเครื่องหยุด ไม่ใช่ขาดตรวจ"""
    eq, fid, admin = _eq_form(app, db, with_schedule=False)
    DT.set_down(db, eq, admin, "สำรอง", "standby", start_at=datetime.now() - timedelta(days=2))
    S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00", "window_min": 240}, admin)
    _gen(db)
    S.refresh_round_statuses(db)
    db.commit()
    r = _closed(db, fid)
    assert r["status"] == "skipped", r["status"]
    assert not db.execute("SELECT 1 FROM cs_rounds WHERE form_id=? AND status='missed'", (fid,)).fetchone()


def test_relink_counts_machine_stopped_after_due_before_close(app, db):
    """หยุดหลังเวลาเริ่มรอบแต่ก่อนปิดรอบ (เช่น SCT0025 หยุด 08:33 รอบ 08:00) → คำนวณรอบใหม่แล้วต้องเป็นเครื่องหยุด"""
    eq, fid, admin = _eq_form(app, db)
    _gen(db)
    y = _closed(db, fid)
    stop = datetime.fromisoformat(y["due_at"]) + timedelta(minutes=33)
    db.execute("INSERT INTO cs_downtime(equipment_id, start_at, reason, category, started_by) VALUES (?,?,?,?,?)",
               (eq, stop.strftime("%Y-%m-%d %H:%M:%S"), "สำรอง", "standby", admin))
    db.execute("UPDATE equipment SET run_status='down', down_since=? WHERE id=?", (stop.strftime("%Y-%m-%d %H:%M:%S"), eq))
    db.execute("UPDATE cs_rounds SET status='missed' WHERE id=?", (y["id"],))
    d0 = datetime.fromisoformat(y["due_at"]).date()
    SF.relink_forms(db, [fid], day_from=d0, day_to=d0, actor_id=admin)
    assert _closed(db, fid)["status"] == "skipped"


def test_job_repairs_existing_missed_rounds_and_closes_alerts(app, db):
    """ข้อมูลเดิมที่นับขาดตรวจผิดไปแล้ว → งานเบื้องหลังรอบถัดไปแก้เป็นเครื่องหยุด + ปิดแจ้งเตือนขาดตรวจ"""
    eq, fid, admin = _eq_form(app, db)
    _gen(db)
    y = _closed(db, fid)
    db.execute("UPDATE cs_rounds SET status='missed' WHERE id=?", (y["id"],))
    db.execute("""INSERT INTO cs_alerts(alert_type, severity, dedup_key, form_id, equipment_id, round_id, title, status, created_at,
                  updated_at) VALUES ('missed','warning','m1',?,?,?, 'ขาดตรวจ', 'open', ?, ?)""",
               (fid, eq, y["id"], y["close_at"], y["close_at"]))
    since = datetime.fromisoformat(y["due_at"]) - timedelta(hours=10)
    db.execute("INSERT INTO cs_downtime(equipment_id, start_at, reason, category, started_by) VALUES (?,?,?,?,?)",
               (eq, since.strftime("%Y-%m-%d %H:%M:%S"), "สำรอง", "standby", admin))
    db.execute("UPDATE equipment SET run_status='down', down_since=? WHERE id=?", (since.strftime("%Y-%m-%d %H:%M:%S"), eq))
    res = S.refresh_round_statuses(db)
    assert res["down_skipped"] >= 1
    assert _st(db, y["id"]) == "skipped"
    a = db.execute("SELECT status FROM cs_alerts WHERE round_id=?", (y["id"],)).fetchone()
    assert a["status"] == "closed"
    assert AL is not None


def test_legacy_down_without_downtime_row_counts_as_stopped(app, db):
    """เครื่องที่สถานะหยุดอยู่แต่ไม่มีช่วงหยุดในตาราง (ข้อมูลเก่า) → ใช้ down_since"""
    eq, fid, admin = _eq_form(app, db)
    _gen(db)
    since = (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S")
    db.execute("UPDATE equipment SET run_status='down', down_since=? WHERE id=?", (since, eq))
    S.refresh_round_statuses(db)
    assert _closed(db, fid)["status"] == "skipped"


def test_resume_restores_future_rounds_and_keeps_past_skipped(app, db):
    """เดินเครื่องแล้ว: รอบที่ยังไม่ปิดกลับมาให้ตรวจ (ไม่ถูกนับเป็นเครื่องหยุดซ้ำ) · รอบที่ปิดไประหว่างหยุดยังเป็นเครื่องหยุด"""
    eq, fid, admin = _eq_form(app, db)
    DT.set_down(db, eq, admin, "สำรอง", "standby", start_at=datetime.now() - timedelta(days=3))
    _gen(db)
    S.refresh_round_statuses(db)
    past = _closed(db, fid)
    assert past["status"] == "skipped"
    DT.set_running(db, eq, admin, "เดินเครื่อง")
    S.refresh_round_statuses(db)
    assert _st(db, past["id"]) == "skipped"
    rs = _rounds(db, fid)
    fut = [r for r in rs.values() if r["close_at"] > datetime.now().strftime("%Y-%m-%d %H:%M:%S")]
    assert fut and all(r["status"] in ("pending", "overdue", "in_progress") for r in fut), [r["status"] for r in fut]


def test_machine_resumed_before_close_is_not_skipped(app, db):
    """เครื่องเดินก่อนปิดรอบ → รอบนั้นต้องตรวจตามปกติ (ไม่ตรวจ = ขาดตรวจ)"""
    eq, fid, admin = _eq_form(app, db)
    _gen(db)
    y = _closed(db, fid)
    close = datetime.fromisoformat(y["close_at"])
    db.execute("INSERT INTO cs_downtime(equipment_id, start_at, end_at, reason, category, started_by) VALUES (?,?,?,?,?,?)",
               (eq, (close - timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S"), (close - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S"),
                "สำรอง", "standby", admin))
    S.refresh_round_statuses(db)
    assert _st(db, y["id"]) == "missed"
