"""v0.95: หน้างานเห็นสถานะการส่ง (ถึงระบบแล้ว/รอส่ง/กรอกค้าง) · หัวข้อคำนวณ (calc) · ประวัติเครื่องหน้าเดียว"""
from datetime import datetime, timedelta

import pytest

from conftest import GOOD, login, payload, uid
from ecs import formula as FM
from ecs import machine360 as M3
from ecs import services as S
from ecs import submissions as SUB
from ecs.services import ts

TODAY = S.now_dt().date()


def _calc_form(app, db, formula="{p_in} - {p_out}"):
    from ecs import masterdata as M
    admin = uid(db, "t_admin")
    eq = M.save_equipment(db, {"code": "FLT01", "name": "Filter", "factory_id": app.config["F1"]}, admin)
    fid = S.create_form(db, {"name": "Filter DP", "equipment_id": eq}, admin)
    d = S.get_draft(db, fid)
    S.save_draft_items(db, d["id"], [
        {"item_key": "p_in", "name": "ความดันขาเข้า", "item_type": "number", "unit": "bar"},
        {"item_key": "p_out", "name": "ความดันขาออก", "item_type": "number", "unit": "bar"},
        {"item_key": "dp", "name": "ΔP ไส้กรอง", "item_type": "calc", "unit": "bar", "formula": formula, "max_value": 0.5,
         "warn_high": 0.4, "photo_on_ng": 0},
    ], admin)
    S.publish_version(db, d["id"], admin)
    db.commit()
    return {"form_id": fid, "equipment_id": eq, "version_id": d["id"]}


def test_formula_engine():
    assert FM.compute("({a} - {b}) * 1.8 + max({a}, {b}) / 2", {"a": 10, "b": 4}) == 15.8
    assert FM.compute("{a} / {b}", {"a": 1, "b": 0}) is None and FM.compute("{a} - {x}", {"a": 1}) is None
    for bad in ("{a} +", "__import__('os')", "{a} ** 2", "open(1)"):
        with pytest.raises(FM.FormulaError):
            FM.parse(bad)
    items = [{"item_key": "a", "item_type": "number", "name": "A"}, {"item_key": "t", "item_type": "text", "name": "T"},
             {"item_key": "c", "item_type": "calc", "formula": "{d}+1", "name": "C"}]
    assert FM.check("{c} * 2", "d", items) == ["สูตรวนกลับมาอ้างตัวเอง"] and FM.check("{x}", "x", items + [{"item_key": "x", "item_type": "calc", "name": "X"}])
    assert "ไม่ใช่หัวข้อตัวเลข" in FM.check("{t}", "x", items)[0] and not FM.check("{a} * 2", "x", items)
    assert FM.rename_refs("{a}+{b}", {"a": "k1"}) == "{k1}+{b}"


def test_calc_item_server_computes(app, db):
    f = _calc_form(app, db)
    it = {i["item_key"]: i for i in S.get_items(db, f["version_id"])}
    assert it["dp"]["formula"] == "{p_in} - {p_out}" and it["dp"]["required"] == 0
    tech = uid(db, "t_tech")
    # ค่าจากเครื่องถูกละเลย — เซิร์ฟเวอร์คำนวณเอง 6.3 − 6.1 = 0.2 → ปกติ
    r = SUB.create_submission(db, payload(f, {"p_in": {"value": "6.3"}, "p_out": {"value": "6.1"}, "dp": {"value": "99"}}), {}, tech,
                              app.config["UPLOAD_FOLDER"])
    db.commit()
    a = {x["item_key"]: x for x in SUB.get_submission(db, r["id"])["answers"]}
    assert a["dp"]["value_num"] == pytest.approx(0.2) and a["dp"]["judgement"] == "ok" and r["ng_count"] == 0
    # ΔP 0.7 > Max 0.5 → NG ต้องใส่หมายเหตุ
    with pytest.raises(S.ValidationError) as e:
        SUB.create_submission(db, payload(f, {"p_in": {"value": "6.8"}, "p_out": {"value": "6.1"}}), {}, tech, app.config["UPLOAD_FOLDER"])
    assert "ΔP ไส้กรอง: ผล NG ต้องใส่หมายเหตุ" in " ".join(e.value.errors)
    r = SUB.create_submission(db, payload(f, {"p_in": {"value": "6.8"}, "p_out": {"value": "6.1"}, "dp": {"remark": "ไส้กรองตัน"}}), {}, tech,
                              app.config["UPLOAD_FOLDER"])
    assert r["ng_count"] == 1
    # สูตรผิด / วนซ้ำ บันทึกไม่ได้
    d = S.get_or_create_draft(db, f["form_id"], uid(db, "t_admin"))
    with pytest.raises(S.ValidationError) as e:
        S.save_draft_items(db, d["id"], [{"item_key": "x", "name": "X", "item_type": "calc", "formula": "{x} + 1"}], None)
    assert "ตัวเอง" in " ".join(e.value.errors)
    with pytest.raises(S.ValidationError):
        S.save_draft_items(db, d["id"], [{"item_key": "x", "name": "X", "item_type": "calc", "formula": ""}], None)


def test_tasks_api_sent_today_and_home(client, db, published_form, app):
    tech = uid(db, "t_tech")
    r = SUB.create_submission(db, payload(published_form, GOOD), {}, tech, app.config["UPLOAD_FOLDER"])
    db.commit()
    login(client, "t_tech")
    d = client.get("/api/m/tasks").get_json()
    assert d["sent"] and d["sent"][0]["id"] == r["id"] and d["sent"][0]["approval_status"] == "pending"
    assert d["sent"][0]["late_sync"] is False
    page = client.get("/m/").get_data(as_text=True)
    assert 'id="syncBox"' in page and "/machines" in page
    js = client.get("/static/m/home.js").get_data(as_text=True)
    assert "ถึงระบบแล้ววันนี้" in js and "กรอกค้างไว้" in js and "withLocal" in js
    fj = client.get("/static/m/fill.js").get_data(as_text=True)
    assert "goResume" in fj and "syncCalcs" in fj


def test_machine360(app, db, client, published_form):
    eq = published_form["equipment_id"]
    tech = uid(db, "t_tech")
    now = S.now_dt().replace(microsecond=0)
    at = ts(now - timedelta(hours=1))
    sid = db.execute("""INSERT INTO cs_submissions(client_uuid, form_id, form_version_id, equipment_id, inspector_id, finished_at,
                        received_at, status, ng_count) VALUES ('u95',?,?,?,?,?,?,'submitted',1)""",
                     (published_form["form_id"], published_form["version_id"], eq, tech, at, at)).lastrowid
    item = db.execute("SELECT id FROM cs_form_items WHERE version_id=? AND item_key='oil'", (published_form["version_id"],)).fetchone()[0]
    db.execute("INSERT INTO cs_answers(submission_id, item_id, item_key, value_num, value_text, judgement, remark) VALUES (?,?,?,?,?,?,?)",
               (sid, item, "oil", 2.9, "2.9", "ng", "รั่ว"))
    for k, (start, hours, cat) in enumerate([(5, 4, "repair"), (3, 2, "repair"), (2, 10, "pm")]):
        a = now - timedelta(days=start)
        db.execute("INSERT INTO cs_downtime(equipment_id, start_at, end_at, category, reason) VALUES (?,?,?,?,?)",
                   (eq, ts(a), ts(a + timedelta(hours=hours)), cat, f"เหตุ {k}"))
    db.commit()
    M = M3.build(db, eq, TODAY - timedelta(days=29), TODAY)
    k = M["kpi"]
    assert k["failures"] == 2 and k["mttr"] == 3.0 and k["repair_h"] == 6.0 and k["other_h"] == 10.0
    assert abs(k["mtbf"] - (k["period_h"] - 16) / 2) <= 0.11 and k["subs"] == 1 and k["ng"] == 1
    assert M["pareto"][0]["item_key"] == "oil" and M["counts"]["down"] == 3 and M["counts"]["up"] == 3 and M["counts"]["ng"] == 1
    assert M["quality"]["machines"][0]["form_id"] == published_form["form_id"]
    login(client, "t_admin")
    page = client.get(f"/machines/{eq}").get_data(as_text=True)
    assert "MTBF" in page and "ไทม์ไลน์" in page and "Oil Pressure" in page
    assert client.get(f"/machines/{eq}", query_string={"ev": "down", "days": 30}).status_code == 200
    assert "SCT0002" in client.get("/machines").get_data(as_text=True)
    assert client.get("/machines/99999").status_code == 404
