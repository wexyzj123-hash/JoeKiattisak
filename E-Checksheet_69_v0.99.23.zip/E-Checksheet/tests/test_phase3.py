"""Phase 3: ตรวจจับความผิดปกติ, ข้อมูล Dashboard/กราฟ, หน้าเว็บและสิทธิ์"""
from datetime import date, datetime, timedelta

import pytest

from ecs import analytics as AN
from ecs import anomaly as A
from ecs import submissions as SUB
from ecs.services import ts

from conftest import GOOD, login, payload, png_bytes, uid

RULES = A.DEFAULT_RULES


def photo():
    import io
    from werkzeug.datastructures import FileStorage
    return FileStorage(io.BytesIO(png_bytes()), filename="p.png")
ITEM = {"item_type": "number", "unit": "bar", "min_value": 0.0, "max_value": 100.0}
T0 = datetime(2026, 9, 1, 8, 0)


def hist(values, step_h=24, start=T0):
    return [{"v": v, "t": start + timedelta(hours=i * step_h)} for i, v in enumerate(values)]


def types(values, x, item=ITEM, rules=None, t=None):
    h = hist(values)
    point = {"v": x, "t": t or (h[-1]["t"] + timedelta(hours=24) if h else T0)}
    return {typ for typ, _ in A.check_numeric(item, h, point, rules or RULES)}


def rules(**over):
    import copy
    r = copy.deepcopy(RULES)
    for k, v in over.items():
        r[k].update(v)
    return r


# ───────────────────────── pure rules ─────────────────────────

NOISY = [50, 51, 49, 50, 52, 48, 50, 51, 49, 50, 51, 49]     # ค่าเฉลี่ย 50 ขึ้นลงสลับ


def test_quiet_series_has_no_flags():
    assert types(NOISY, 50.5, rules=rules(baseline={"enabled": False})) == set()


def test_spc_sigma_and_roc():
    got = types(NOISY, 60, rules=rules(baseline={"enabled": False}))
    assert "spc_sigma" in got
    assert "roc" not in got                           # เปลี่ยน 10 จากช่วง 100 = 10% < 50%
    assert "roc" in types([50], 110, rules=rules(roc={"pct": 50}))


def test_spc_sigma_needs_min_points():
    assert "spc_sigma" not in types(NOISY[:5], 90, rules=rules(roc={"enabled": False}))


def test_run_trend_stuck():
    r = rules(baseline={"enabled": False}, spc_sigma={"enabled": False}, roc={"enabled": False})
    assert "spc_run" in types(NOISY + [53, 53.5, 52.5, 53.2, 52.8, 53.1], 53.3, rules=r)
    assert "spc_trend" in types([1, 2, 3, 4, 5], 6, rules=r)
    assert "spc_trend" not in types([1, 2, 3, 2, 5], 6, rules=r)
    assert "stuck" in types([7, 7, 7, 7], 7, rules=r)
    assert "stuck" not in types([7, 7, 7], 7, rules=r)


def test_counter_only_checks_stuck():
    counter = {**ITEM, "item_type": "counter"}
    assert types([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 500, item=counter) == set()
    assert types([9, 9, 9, 9], 9, item=counter) == {"stuck"}


def test_baseline_same_hour_of_day():
    vals = [50, 51, 49, 50, 52, 48, 50, 51, 49, 50, 51, 49]
    r = rules(spc_sigma={"enabled": False}, roc={"enabled": False}, spc_run={"enabled": False},
              spc_trend={"enabled": False})
    h = hist(vals)
    t = h[-1]["t"] + timedelta(hours=24)
    assert ("baseline" in {x for x, _ in A.check_numeric(ITEM, h, {"v": 70, "t": t}, r)})
    # คนละช่วงเวลาของวัน (ต่าง 10 ชม.) → ไม่มีฐานเปรียบเทียบ
    assert ("baseline" not in {x for x, _ in A.check_numeric(ITEM, h, {"v": 70, "t": t + timedelta(hours=10)}, r)})


def test_disabled_rules():
    off = rules(**{k: {"enabled": False} for k in RULES})
    assert types(NOISY, 99, rules=off) == set()


def test_control_limits():
    lim = A.control_limits([1, 2, 3, 4, 5], 3)
    assert lim["mean"] == 3 and lim["ucl"] > 5 and lim["lcl"] < 1
    assert A.control_limits([1], 3) is None


# ───────────────────────── rule settings ─────────────────────────

def test_save_rules_validation(db):
    with pytest.raises(Exception) as e:
        A.save_rules(db, {"spc_sigma": {"k": "99"}}, None)
    assert "ต้องอยู่ระหว่าง" in str(e.value.errors)
    with pytest.raises(Exception):
        A.save_rules(db, {"roc": {"pct": "abc"}}, None)
    A.save_rules(db, {"roc": {"pct": "30", "enabled": "0"}, "unknown": {"x": 1}, "stuck": {"bogus": 5}}, None)
    db.commit()
    r = A.get_rules(db)
    assert r["roc"] == {"enabled": False, "pct": 30} and "bogus" not in r["stuck"]
    assert r["spc_sigma"]["k"] == RULES["spc_sigma"]["k"]


# ───────────────────────── submissions → alerts ─────────────────────────

def submit(app, db, form, answers, photos=None, **kw):
    res = SUB.create_submission(db, payload(form, answers, **kw), photos or {}, uid(db, "t_tech"),
                                app.config["UPLOAD_FOLDER"])
    db.commit()
    return res


def with_oil(v, hour, ng=False):
    oil = {"value": str(v), "remark": "สูง", "photos": ["p1"]} if ng else {"value": str(v)}
    return {**GOOD, "oil": oil, "hour": {"value": str(hour)}}


def test_ng_creates_alert_and_dedups(app, db, published_form):
    ng = {**GOOD, "noise": {"value": "NG", "remark": "เสียงดัง", "photos": ["p1"]}}
    r1 = submit(app, db, published_form, ng, photos={"p1": photo()})
    assert [a["type"] for a in r1["anomalies"]] == ["ng"] and r1["anomalies"][0]["new"]
    r2 = submit(app, db, published_form, {**ng, "hour": {"value": "1001"}}, photos={"p1": photo()})
    assert not r2["anomalies"][0]["new"]
    row = db.execute("SELECT * FROM cs_alerts WHERE alert_type='ng'").fetchall()
    assert len(row) == 1 and row[0]["occurrences"] == 2 and row[0]["status"] == "open"
    assert db.execute("SELECT COUNT(*) FROM cs_alert_events WHERE alert_id=?", (row[0]["id"],)).fetchone()[0] == 2


def test_warn_band_alert(app, db, published_form):
    r = submit(app, db, published_form, with_oil(2.45, 1000))
    assert "warn" in [a["type"] for a in r["anomalies"]]
    A.save_rules(db, {"threshold": {"warn_band": False}}, None)
    r = submit(app, db, published_form, with_oil(2.45, 1001))
    assert "warn" not in [a["type"] for a in r["anomalies"]]


def test_ng_value_suppresses_statistical_alerts(app, db, published_form):
    for i, v in enumerate([2.0, 2.1, 1.9, 2.0, 2.1, 1.9, 2.0, 2.1, 1.9, 2.0, 2.05]):
        submit(app, db, published_form, with_oil(v, 1000 + i))
    r = submit(app, db, published_form, with_oil(3.5, 2000, ng=True), photos={"p1": photo()})        # NG + หลุด 3σ + เปลี่ยนเร็ว
    kinds = [a["type"] for a in r["anomalies"]]
    assert "ng" in kinds and "spc_sigma" not in kinds and "roc" not in kinds


def test_statistical_alert_on_in_spec_value(app, db, published_form):
    for i, v in enumerate([2.0, 2.02, 1.98, 2.0, 2.01, 1.99, 2.0, 2.02, 1.98, 2.0, 2.01]):
        submit(app, db, published_form, with_oil(v, 1000 + i))
    r = submit(app, db, published_form, with_oil(2.3, 2000))        # ยังอยู่ในเกณฑ์ แต่ผิดปกติทางสถิติ
    kinds = [a["type"] for a in r["anomalies"]]
    assert "spc_sigma" in kinds and "ng" not in kinds


def test_check_missed(db, published_form):
    fid = published_form["form_id"]
    sid = db.execute("INSERT INTO cs_schedules(form_id, freq_type, times, created_at, updated_at) VALUES (?, 'daily', '08:00', ?, ?)", (fid, ts(datetime.now()), ts(datetime.now()))).lastrowid
    now = datetime.now().replace(microsecond=0)
    past = now - timedelta(days=1)
    db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                  VALUES (?,?,?,?,?,'missed',?)""", (sid, fid, ts(past), ts(past), ts(past), ts(now - timedelta(minutes=1))))
    assert A.check_missed(db, now) == 1
    assert A.check_missed(db, now + timedelta(minutes=5)) == 0          # ไม่แจ้งซ้ำ
    assert db.execute("SELECT COUNT(*) FROM cs_alerts WHERE alert_type='missed'").fetchone()[0] == 1


def test_alert_ack_resolve(db, published_form):
    form = {"id": published_form["form_id"], "equipment_id": published_form["equipment_id"]}
    aid, _ = A.raise_alert(db, alert_type="ng", form=form, title="t", detail="d", severity="warning", item_key="oil")
    admin = uid(db, "t_admin")
    with pytest.raises(Exception):
        A.set_alert_status(db, aid, "resolve", admin, "")          # ต้องระบุการแก้ไข
    assert A.set_alert_status(db, aid, "ack", admin)["status"] == "acknowledged"
    with pytest.raises(Exception):
        A.set_alert_status(db, aid, "ack", admin)
    a = A.set_alert_status(db, aid, "resolve", admin, root_cause="ไส้กรองตัน", action_taken="เปลี่ยนไส้กรองแล้ว")
    assert a["status"] == "resolved" and a["resolved_at"] and a["action_taken"] == "เปลี่ยนไส้กรองแล้ว"
    # ปิดแล้ว → เกิดใหม่ต้องเป็นรายการใหม่
    aid2, new = A.raise_alert(db, alert_type="ng", form=form, title="t", detail="d", severity="warning", item_key="oil")
    assert new and aid2 != aid
    assert A.open_alert_counts(db)["total"] == 1


# ───────────────────────── analytics ─────────────────────────

def _round(db, fid, sid, due, status):
    db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                  VALUES (?,?,?,?,?,?,?)""", (sid, fid, ts(due), ts(due), ts(due), status, ts(due)))


def test_daily_stats_overview_heatmap(app, db, published_form):
    fid = published_form["form_id"]
    sid = db.execute("INSERT INTO cs_schedules(form_id, freq_type, times, created_at, updated_at) VALUES (?, 'daily', '08:00', ?, ?)", (fid, ts(datetime.now()), ts(datetime.now()))).lastrowid
    d = date.today() - timedelta(days=3)
    base = datetime.combine(d, datetime.min.time())
    for h, st in ((8, "done_on_time"), (9, "done_on_time"), (10, "done_late"), (11, "missed")):
        _round(db, fid, sid, base + timedelta(hours=h), st)
    db.commit()
    ov = AN.overview(db, d, d)
    assert (ov["due"], ov["on_time"], ov["late"], ov["missed"]) == (4, 2, 1, 1)
    assert ov["rate"] == 50.0 and ov["rate_status"] == "critical"
    f1 = next(f for f in ov["factories"] if f["id"] == app.config["F1"])
    assert f1["rate"] == 50.0
    assert AN.overview(db, d, d, app.config["F2"])["due"] == 0
    hm = AN.heatmap(db, d, d)
    assert len(hm["rows"]) == 1 and hm["cells"][0]["status"] == "critical" and hm["cells"][0]["missed"] == 1
    tr = AN.compliance_trend(db, d - timedelta(days=1), d)
    s1 = next(s for s in tr["series"] if s["id"] == app.config["F1"])
    assert s1["data"] == [None, 50.0]
    # คำนวณซ้ำได้ ไม่เพิ่มแถวซ้ำ
    AN.refresh_daily_stats(db, d, d)
    AN.refresh_daily_stats(db, d, d)
    assert db.execute("SELECT COUNT(*) FROM cs_daily_stats WHERE stat_date=?", (d.isoformat(),)).fetchone()[0] == 1


def test_rate_status_bins():
    assert [AN.rate_status(x) for x in (None, 100, 95, 94.9, 80, 79.9)] == \
        ["none", "good", "good", "warning", "warning", "critical"]


def test_pareto_and_item_series(app, db, published_form):
    ng = {**GOOD, "noise": {"value": "NG", "remark": "ดัง", "photos": ["p1"]}}
    for i in range(3):
        submit(app, db, published_form, {**ng, "hour": {"value": str(1000 + i)}}, photos={"p1": photo()})
    submit(app, db, published_form, with_oil(2.7, 2000, ng=True), photos={"p1": photo()})
    today = date.today()
    p = AN.ng_pareto(db, today, today)
    assert p["total"] == 4 and p["items"][0]["item_key"] == "noise" and p["items"][0]["ng"] == 3
    assert p["items"][-1]["cum_pct"] == 100.0
    s = AN.item_series(db, published_form["form_id"], "oil", today, today)
    assert s["stats"]["n"] == 4 and s["stats"]["ng"] == 1 and s["stats"]["max"] == 2.7
    assert s["item"]["max_value"] == 2.5 and s["points"][-1]["judgement"] == "ng"
    with pytest.raises(Exception):
        AN.item_series(db, published_form["form_id"], "noise", today, today)   # ไม่ใช่หัวข้อตัวเลข
    summ = AN.equipment_summary(db, published_form["equipment_id"])
    assert {x["item_key"] for x in summ} == {"oil", "hour"}


def test_parse_range():
    f, t, n = AN.parse_range({"days": "7"})
    assert n == 7 and t == date.today()
    f, t, n = AN.parse_range({"from": "2026-01-10", "to": "2026-01-01"})
    assert (f, t) == (date(2026, 1, 1), date(2026, 1, 10))
    assert AN.parse_range({"days": "9999"})[2] == 366
    assert AN.parse_range({"days": "x", "from": "bad"})[2] >= 1


# ───────────────────────── web ─────────────────────────

@pytest.mark.parametrize("user,path,code", [
    ("t_view", "/dashboard", 200), ("t_view", "/tv", 200), ("t_view", "/trends", 200), ("t_view", "/alerts", 200),
    ("t_view", "/api/dashboard?days=7", 200), ("t_tech", "/dashboard", 200),
    ("t_view", "/admin/anomaly-rules", 403), ("t_sup", "/admin/anomaly-rules", 403),
    ("t_admin", "/admin/anomaly-rules", 200),
])
def test_phase3_pages(client, published_form, user, path, code):
    login(client, user)
    assert client.get(path).status_code == code


def test_index_goes_to_dashboard(client):
    login(client, "t_sup")
    assert client.get("/").headers["Location"].endswith("/dashboard")
    client.post("/logout", data={"csrf_token": ""})


def test_trend_pages_and_api(app, client, db, published_form):
    submit(app, db, published_form, with_oil(2.2, 1000))
    submit(app, db, published_form, with_oil(2.3, 1001))
    login(client, "t_view")
    fid = published_form["form_id"]
    body = client.get(f"/trends?form={fid}&item=oil&mode=spc").get_data(as_text=True)
    assert "Oil Pressure" in body and "c-trend" in body
    j = client.get(f"/api/trend?form={fid}&item=oil&days=7").get_json()
    assert len(j["points"]) == 2 and j["limits"]["n"] == 2
    assert {i["item_key"] for i in client.get(f"/api/trend?form={fid}").get_json()["items"]} == {"oil", "hour"}
    assert client.get(f"/api/trend?form={fid}&item=noise").status_code == 404
    assert client.get("/api/trend").status_code == 400
    assert "Oil Pressure" in client.get(f"/equipment/{published_form['equipment_id']}").get_data(as_text=True)


def test_alert_actions_permissions(app, client, db, published_form):
    ng = {**GOOD, "noise": {"value": "NG", "remark": "ดัง", "photos": ["p1"]}}
    submit(app, db, published_form, ng, photos={"p1": photo()})
    aid = db.execute("SELECT id FROM cs_alerts").fetchone()[0]
    tok = login(client, "t_view")
    assert client.get(f"/alerts/{aid}").status_code == 200
    assert client.post(f"/alerts/{aid}/ack", data={"csrf_token": tok}).status_code == 403
    client.post("/logout", data={"csrf_token": tok})
    tok = login(client, "t_sup")
    assert client.post(f"/alerts/{aid}/ack", data={"csrf_token": ""}).status_code == 400       # CSRF
    assert client.post(f"/alerts/{aid}/ack", data={"csrf_token": tok}).status_code == 302
    r = client.post(f"/alerts/{aid}/resolve", json={"note": ""}, headers={"X-CSRF-Token": tok, "Accept": "application/json"})
    assert r.status_code == 400
    r = client.post(f"/alerts/{aid}/resolve", json={"root_cause": "สายพานหลวม", "action_taken": "แก้แล้ว"}, headers={"X-CSRF-Token": tok, "Accept": "application/json"})
    assert r.get_json()["status"] == "resolved"
    db.execute("UPDATE cs_alerts SET status='closed' WHERE alert_type='approval'")   # v0.19: รออนุมัติของผลตรวจ
    db.commit()
    assert "ไม่มีรายการแจ้งเตือนค้าง" in client.get("/alerts").get_data(as_text=True)
    assert "แก้แล้ว" in client.get("/alerts?status=all").get_data(as_text=True)


def test_rules_form_post(client, db):
    tok = login(client, "t_admin")
    form = {"csrf_token": tok}
    for rule, params in __import__("ecs.views.dash", fromlist=["RULE_PARAMS"]).RULE_PARAMS.items():
        form[f"{rule}.enabled"] = "1"
        for key, _l, kind in params:
            form[f"{rule}.{key}"] = "1" if kind == "bool" else str(RULES[rule][key])
    form["roc.pct"] = "25"
    del form["stuck.enabled"]
    assert client.post("/admin/anomaly-rules", data=form).status_code == 302
    r = A.get_rules(db)
    assert r["roc"]["pct"] == 25 and r["stuck"]["enabled"] is False
    form["spc_sigma.k"] = "50"
    body = client.post("/admin/anomaly-rules", data=form).get_data(as_text=True)
    assert "ต้องอยู่ระหว่าง" in body
