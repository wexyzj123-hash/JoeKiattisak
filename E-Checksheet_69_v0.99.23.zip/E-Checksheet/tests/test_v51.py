"""v0.51: แจ้งเตือนตามตารางกะ · ส่งกะ/รับกะ · หัวฟอร์มเด่น + เตือนเปิดผิดรอบ/ผิดเครื่อง · ผลงานรายคน · รูปแบบหมุนกะ"""
from datetime import date, datetime, timedelta

from conftest import login, uid

from ecs import handover as HO
from ecs import notify as N
from ecs import roster as RO
from ecs import scorecard as SC
from ecs import services as S
from ecs import submissions as SUB


def _monday() -> date:
    d = S.now_dt().date() + timedelta(days=7)
    return d - timedelta(days=d.weekday())


def _sched(db, fid):
    r = db.execute("SELECT id FROM cs_schedules WHERE form_id=? LIMIT 1", (fid,)).fetchone()
    return r[0] if r else S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00"}, uid(db, "t_admin"))


def _round(db, fid, due: datetime, mins=120, status="pending"):
    rid = db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                        VALUES (?,?,?,?,?,?,?)""", (_sched(db, fid), fid, S.ts(due), S.ts(due + timedelta(minutes=mins)),
                                                     S.ts(due + timedelta(minutes=mins * 2)), status, S.ts(due))).lastrowid
    db.commit()
    return rid


def _two(app, db):
    a, b = uid(db, "t_tech"), uid(db, "t_tech2")
    RO.set_factories(db, b, [app.config["F1"]], uid(db, "t_admin"))
    db.commit()
    return a, b


def test_round_reminders_follow_roster(app, db, published_form):
    fid = published_form["form_id"]
    a, b = _two(app, db)
    mon = _monday()
    now = datetime.combine(mon, datetime.min.time()) + timedelta(hours=10)
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    _round(db, fid, now - timedelta(minutes=30), mins=40)                     # ใกล้ครบกำหนด
    RO.set_plans(db, [{"user_id": a, "date": mon.isoformat(), "shift_type": "day_off"}], uid(db, "t_admin"))
    db.commit()
    N.round_reminders(db, now)
    got = {r[0] for r in db.execute("SELECT user_id FROM cs_notifications WHERE kind='round_due'")}
    assert b in got and a not in got                                            # คนลาหยุดไม่ได้รับ
    # ไม่มีใครอยู่กะ → ส่งทุกคนของโรงงาน (งานไม่ตกหล่น)
    RO.set_plans(db, [{"user_id": b, "date": mon.isoformat(), "shift_type": "sick"}], uid(db, "t_admin"))
    db.commit()
    who = {u["id"] for u in N._round_assignees(db, {}, app.config["F1"], now, now + timedelta(hours=1))}
    assert {a, b} <= who


def test_handover_generate_ack_and_note(app, db, published_form):
    fid = published_form["form_id"]
    a, b = _two(app, db)
    mon = _monday()
    point = datetime.combine(mon, datetime.min.time()) + timedelta(hours=17)
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    carry = _round(db, fid, point - timedelta(hours=1), mins=180)              # 16:00 ยังไม่ส่ง ปิดรอบหลังเปลี่ยนกะ
    _round(db, fid, point - timedelta(hours=8), mins=60, status="missed")
    _round(db, fid, point - timedelta(hours=6), mins=60, status="done_on_time")
    RO.set_plans(db, [{"user_id": b, "date": mon.isoformat(), "shift_type": "night_shift"}], uid(db, "t_admin"))
    db.commit()
    n = HO.generate(db, point + timedelta(minutes=1))
    db.commit()
    assert n >= 1 and HO.generate(db, point + timedelta(minutes=2)) == 0         # ไม่สร้างซ้ำ
    hid = db.execute("SELECT id FROM cs_handovers WHERE factory_id=?", (app.config["F1"],)).fetchone()[0]
    h = HO.get(db, hid)
    d = h["data"]
    assert d["done"] == 1 and d["missed"] == 1 and d["carry_n"] == 1 and d["carry"][0]["id"] == carry
    assert any("t_tech2" in x for x in d["incoming"])
    note = db.execute("SELECT user_id FROM cs_notifications WHERE kind='handover'").fetchall()
    assert b in {r[0] for r in note}                                            # แจ้งคนเข้ากะดึก
    pend = HO.pending_for(db, b, point + timedelta(minutes=5))
    assert pend and pend[0]["id"] == hid and pend[0]["carry_n"] == 1
    HO.add_note(db, hid, a, "ปั๊ม P-02 เสียงดัง เฝ้าดูต่อ")
    HO.acknowledge(db, hid, b, "รับทราบ")
    db.commit()
    assert HO.get(db, hid)["ack_by"] == b and not HO.pending_for(db, b, point + timedelta(minutes=5))


def test_handover_pages(app, client, db, published_form):
    fid = published_form["form_id"]
    now = S.now_dt()
    _round(db, fid, now - timedelta(hours=2), mins=600)
    pt, _prev = HO.last_point(HO.get_settings(db), now)
    HO.generate(db, pt + timedelta(minutes=1))
    db.commit()
    hid = db.execute("SELECT id FROM cs_handovers LIMIT 1").fetchone()[0]
    tok = login(client, "t_tech")
    html = client.get(f"/m/handover/{hid}").get_data(as_text=True)
    assert "รับกะ" in html and "งานค้าง" in html
    client.post(f"/m/handover/{hid}/ack", data={"csrf_token": tok, "note": "ok"})
    assert db.execute("SELECT ack_by FROM cs_handovers WHERE id=?", (hid,)).fetchone()[0] == uid(db, "t_tech")
    login(client, "t_sup")
    assert "ส่งกะ / รับกะ" in client.get("/handover").get_data(as_text=True)


def test_fill_package_round_warnings_and_qr_flag(app, client, db, published_form):
    fid = published_form["form_id"]
    now = S.now_dt()
    future = _round(db, fid, now + timedelta(hours=6), mins=60)
    cur = _round(db, fid, now - timedelta(minutes=10), mins=120)
    pkg = SUB.form_package(db, fid, future)
    assert pkg["round"]["id"] == future and pkg["current_round"]["id"] == cur and pkg["eq_qr"]
    assert SUB.form_package(db, fid, cur)["current_round"] is None
    login(client, "t_tech")
    res = client.get("/e/" + pkg["eq_qr"])
    assert res.status_code == 302 and res.headers["Location"].endswith("&qr=1")
    js = client.get("/static/m/fill.js").get_data(as_text=True)
    assert "data-eqscan" in js and "roundWarn" in js and "ส่งผลแล้ว" in js


def test_scorecard_week(app, client, db, published_form):
    fid = published_form["form_id"]
    a, b = _two(app, db)
    mon = _monday()
    base = datetime.combine(mon, datetime.min.time())
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    RO.set_plans(db, [{"user_id": b, "date": mon.isoformat(), "shift_type": "night_shift"}], uid(db, "t_admin"))
    _round(db, fid, base + timedelta(hours=10), status="missed")               # กะเช้า (a)
    _round(db, fid, base + timedelta(hours=22), status="done_on_time")         # กะดึก (b)
    sc = SC.build(db, mon)
    by = {r["id"]: r for r in sc["rows"]}
    assert by[a]["missed"] == 1 and by[a]["resp"] == 1 and by[b]["missed"] == 0 and by[b]["cover_pct"] == 100
    assert sc["rounds"] == 2 and sc["missed"] == 1
    subj, body = SC.text(sc)
    assert "ผลงานช่าง" in subj and "ทดสอบ t_tech" in body
    login(client, "t_sup")
    assert "ผลงานรายคน" in client.get(f"/team/scorecard?week={mon.isoformat()}").get_data(as_text=True)
    x = client.get(f"/team/scorecard.xlsx?week={mon.isoformat()}")
    assert x.status_code == 200 and x.data[:2] == b"PK"
    assert SC.weekly_send(db, force=True)
    assert db.execute("SELECT COUNT(*) FROM cs_notifications WHERE kind='summary'").fetchone()[0] >= 1


def test_rotation_patterns(app, client, db):
    a, b = uid(db, "t_tech"), uid(db, "t_tech2")
    pats = RO.patterns(db)
    assert {p["weeks"] for p in pats} == {2, 4}
    p2 = next(p for p in pats if p["weeks"] == 2)
    mon = _monday()
    RO.set_plans(db, [{"user_id": a, "date": (mon + timedelta(days=8)).isoformat(), "shift_type": "day_off"}], uid(db, "t_admin"))
    n = RO.apply_pattern(db, p2["id"], [{"user_id": a, "start_week": 1}, {"user_id": b, "start_week": 2}],
                         mon, mon + timedelta(days=13), uid(db, "t_admin"))
    db.commit()
    assert n > 0
    R = RO.load(db, mon, mon + timedelta(days=13))
    assert RO.shift_key(R, a, mon) == "day" and RO.shift_key(R, b, mon) == "night_shift"              # สัปดาห์ 1
    assert RO.shift_key(R, a, mon + timedelta(days=7)) == "night_shift" and RO.shift_key(R, b, mon + timedelta(days=7)) == "day"
    assert RO.shift_key(R, a, mon + timedelta(days=8)) == "day_off"                                    # วันลาเดิมยังอยู่
    # สร้างรูปแบบ 4 สัปดาห์ผ่านหน้าเว็บ แล้วลงตาราง
    tok = login(client, "t_sup")
    cells = [""] * 7 + ["ot"] * 7 + ["night_shift"] * 7 + [""] * 7
    j = client.post("/admin/roster/pattern/save", json={"name": "ทดสอบ 4", "weeks": 4, "cells": cells},
                    headers={"X-CSRF-Token": tok}).get_json()
    pid = j["pattern"]["id"]
    bad = client.post("/admin/roster/pattern/save", json={"name": "x", "weeks": 3, "cells": []}, headers={"X-CSRF-Token": tok})
    assert bad.status_code == 400
    r = client.post("/admin/roster/pattern/apply", json={"id": pid, "people": [{"user_id": b, "start_week": 3}],
                    "from": mon.isoformat(), "to": (mon + timedelta(days=27)).isoformat()}, headers={"X-CSRF-Token": tok})
    assert r.get_json()["ok"]
    R = RO.load(db, mon, mon + timedelta(days=27))
    assert RO.shift_key(R, b, mon) == "night_shift" and RO.shift_key(R, b, mon + timedelta(days=7)) == "day"
    assert RO.shift_key(R, b, mon + timedelta(days=21)) == "ot"
    assert "รูปแบบหมุนกะ" in client.get("/admin/roster").get_data(as_text=True)
