"""v0.81: ดึงค่าย้อนหลังเกินเพดาน 50,000 แถว (หลาย Tag × หลายวัน) ต้องได้ครบทุกวัน · กำหนดช่วงวันที่ดึงย้อนหลังเองได้"""
from datetime import datetime, time, timedelta

from conftest import login, uid
from test_v73 import _hist

from ecs import connectors as CN
from ecs import services as S
from ecs import srcmap as SM
from ecs.services import ts


def _many(days, val, tags=("OIL", "N1", "N2")):
    today = S.now_dt().date()
    out = []
    for d in range(days, -1, -1):
        day = today - timedelta(days=d)
        for m in range(0, 24 * 60, 10):
            t = ts(datetime.combine(day, time(m // 60, m % 60)))
            out += [(tg, t, val) for tg in tags]
    return out


def _setup(db, form, path, days):
    fid = form["form_id"]
    S.create_schedule(db, fid, {"freq_type": "shift", "times": "08:30,20:30", "window_min": 240}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (ts(S.now_dt() - timedelta(days=days)),))
    S.generate_rounds(db)
    sid = CN.save_source(db, {"name": "SCADA", "kind": "sqlite", "bucket_min": 60, "agg": "last", "prefill": "0",
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                         "backfill_days": 1}}, None)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil"}], None)
    db.commit()
    return sid


def _val(db, sid, t):
    r = db.execute("""SELECT a.value_num FROM cs_submissions s JOIN cs_answers a ON a.submission_id=s.id
                      WHERE s.client_uuid LIKE ? AND s.finished_at=? AND a.item_key='oil'""", (f"src{sid}:%", ts(t))).fetchone()
    return r[0] if r else None


def test_reapply_beyond_row_cap_gets_every_day(app, db, published_form, tmp_path, monkeypatch):
    monkeypatch.setattr(CN, "MAX_ROWS", 500)                   # เพดานเล็ก ให้เห็นปัญหาเดิมด้วยข้อมูลน้อย
    path = str(tmp_path / "h.db")
    _hist(path, _many(14, 1.0))
    sid = _setup(db, published_form, path, 14)
    admin = uid(db, "t_admin")
    today = S.now_dt().date()
    old, recent = today - timedelta(days=12), today - timedelta(days=2)
    r = SM.reapply(db, sid, 14, admin)
    assert r["incomplete"] == 0 and not r["no_data"][:-1]
    assert _val(db, sid, datetime.combine(old, time(8, 30))) == 1.0
    assert _val(db, sid, datetime.combine(recent, time(20, 30))) == 1.0
    _hist(path, _many(14, 2.0), reset=True)                       # ค่าใน SCADA เปลี่ยน → ลงค่าใหม่ต้องได้ค่าใหม่ทุกวัน
    SM.reapply(db, sid, 14, admin)
    assert _val(db, sid, datetime.combine(old, time(8, 30))) == 2.0
    assert _val(db, sid, datetime.combine(recent, time(20, 30))) == 2.0


def test_custom_range_page_modes(app, db, published_form, tmp_path):
    path = str(tmp_path / "h.db")
    _hist(path, _many(20, 3.0))
    sid = _setup(db, published_form, path, 20)
    c = app.test_client()
    tok = login(c, "t_admin")
    html = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert 'id="backfill"' in html and "เติมเฉพาะช่องที่ขาด" in html
    today = S.now_dt().date()
    d1, d2 = today - timedelta(days=18), today - timedelta(days=15)
    r = c.post(f"/admin/sources/{sid}/relay", data={"csrf_token": tok, "day_from": d1.isoformat(), "day_to": d2.isoformat(),
                                                   "mode": "fill"}, follow_redirects=True)
    assert "เติมช่องที่ขาด" in r.get_data(as_text=True)
    assert _val(db, sid, datetime.combine(d1, time(8, 30))) == 3.0
    r = c.post(f"/admin/sources/{sid}/relay", data={"csrf_token": tok, "day_from": (today - timedelta(days=70)).isoformat(),
                                                   "day_to": today.isoformat(), "mode": "replace"}, follow_redirects=True)
    assert "ไม่เกิน 62 วัน" in r.get_data(as_text=True)
