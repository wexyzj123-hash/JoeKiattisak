"""v0.88: แยกรายวัน (ไม่รวมก้อน) · ค่าเพี้ยนไม่นับ · Target รายหน่วยงาน · รายงานสรุปแยก Project/Section/Line (เว็บ/PDF HTML/Excel)"""
from datetime import date, timedelta

from conftest import login

from ecs import energy as EN
from ecs import energy_summary as SM
from ecs import services as S
from ecs.services import ts


def test_usage_split_and_bad():
    rows = [("2026-10-01", 100.0, None), ("2026-10-02", 110.0, None), ("2026-10-05", 140.0, None),
            ("2026-10-06", 2157641728.0, None), ("2026-10-07", 2157641728.0, None), ("2026-10-08", 160.0, None)]
    u = EN.usage(rows, 1, date(2026, 10, 1), date(2026, 10, 8), split=True)
    assert [round(u[d]["u"], 2) for d in ("2026-10-03", "2026-10-04", "2026-10-05")] == [10.0, 10.0, 10.0]
    assert u["2026-10-03"]["flag"] == "split"
    assert u["2026-10-06"]["flag"] == "bad" and u["2026-10-06"]["u"] is None
    assert u["2026-10-08"]["flag"] == "reset"
    u2 = EN.usage(rows, 1, date(2026, 10, 1), date(2026, 10, 8))
    assert u2["2026-10-05"]["u"] == 30 and "2026-10-03" not in u2      # ค่าเดิม (ไม่ split) ยังเหมือนเดิม


def _seed(app, db):
    f1 = app.config["F1"]
    from ecs import energy_struct as ST
    p1 = ST.save_project(db, {"name": "Utility", "color": "#2a78d6"}, None)
    ms = []
    for code, grp, line, rate in (("A", "PM", "L1", 100), ("B", "PM", "L2", 50), ("C", "MFG", "L3", 20)):
        mid = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": code, "name": code, "grp": grp, "line": line,
                                       "project_id": str(p1)}, None)
        ms.append(mid)
        today = S.now_dt().date()
        for i in range(70, -1, -1):
            d = today - timedelta(days=i)
            if code == "C" and i in (5, 6):                       # ขาดค่าอ่าน 2 วัน
                continue
            db.execute("INSERT INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,?,?)",
                       (mid, d.isoformat(), 1000 + rate * (70 - i), "web", ts()))
    db.commit()
    return f1, p1, ms


def test_summary_targets_reports(app, db, client):
    f1, p1, ms = _seed(app, db)
    today = S.now_dt().date()
    d1, d2 = today - timedelta(days=13), today
    rep = SM.summary(db, "elec", "grp", d1, d2, f1)
    by = {u["name"]: u for u in rep["units"]}
    assert set(by) == {"PM", "MFG"}
    assert by["PM"]["total"] == 150 * 14 and by["MFG"]["total"] == 20 * 14       # วันที่ขาดถูกเฉลี่ยลงรายวัน ยอดรวมครบ
    assert by["MFG"]["n_split"] == 3
    assert by["PM"]["target"]["src"] == "auto" and abs(by["PM"]["target"]["daily"] - 150 * 0.95) < 1e-6
    SM.save_target(db, "elec", f1, "grp", "PM", "140", "เป้า", None)
    rep = SM.summary(db, "elec", "grp", d1, d2, f1)
    pm = [u for u in rep["units"] if u["name"] == "PM"][0]
    assert pm["target"]["src"] == "manual" and pm["days_over"] == 14 and pm["pct_target"] > 100
    assert SM.summary(db, "elec", "line", d1, d2, f1)["units"][0]["name"].startswith("L1")
    x = SM.to_xlsx(rep, "t")
    assert x[:2] == b"PK"
    tok = login(client, "t_admin")
    page = client.get("/energy/summary", query_string={"kind": "elec", "level": "project", "factory": f1}).get_data(as_text=True)
    assert "รายงานสรุป" in page and "Utility" in page and "esvg" in page
    assert client.get("/energy/summary", query_string={"level": "grp", "format": "xlsx", "from": d1.isoformat(), "to": d2.isoformat()}).status_code == 200
    tp = client.get("/energy/targets", query_string={"kind": "elec", "level": "grp", "factory": f1}).get_data(as_text=True)
    assert "Target การใช้ไฟฟ้า" in tp and "PM" in tp
    r = client.post("/energy/targets", data={"csrf_token": tok, "kind": "elec", "level": "line", "factory": f1, "key": ["PM|L1"],
                                             "old.0": "", "oldnote.0": "", "daily.0": "90", "note.0": ""})
    assert r.status_code == 302 and SM.manual_targets(db, "elec")[(f1, "line", "PM|L1")]["daily"] == 90
    r = client.post(f"/energy/meters/{ms[0]}/target", data={"csrf_token": tok, "daily": "95"})
    assert r.status_code == 302 and SM.manual_targets(db, "elec")[(f1, "meter", str(ms[0]))]["daily"] == 95


def test_interval_import_and_meter_page(app, db, client):
    import io

    from openpyxl import Workbook
    f1, p1, ms = _seed(app, db)
    db.execute("UPDATE en_meters SET scada_tag='TAG_A' WHERE id=?", (ms[0],))
    db.commit()
    wb = Workbook()
    ws = wb.active
    ws.append(["มิเตอร์", "เวลา", "ค่า"])
    from datetime import datetime, time
    yd = S.now_dt().date() - timedelta(days=1)
    for i in range(96):
        t = datetime.combine(yd, time(0, 0)) + timedelta(minutes=15 * i)
        ws.append(["TAG_A", t, 2.5])
        ws.append(["B", t, 1.0])
    ws.append(["UNKNOWN", datetime.combine(yd, time(1, 0)), 3])
    ws.append(["B", datetime.combine(yd, time(2, 7)), 2157641728])
    bio = io.BytesIO()
    wb.save(bio)
    tok = login(client, "t_admin")
    page = client.post("/energy/import/intervals", data={"csrf_token": tok, "file": (io.BytesIO(bio.getvalue()), "iv.xlsx"),
                                                         "factory": str(f1), "kind": "elec", "shift": "0"},
                       content_type="multipart/form-data").get_data(as_text=True)
    assert "ตรวจก่อนบันทึก" in page and "UNKNOWN" in page and "มีค่าจดเอง" in page
    import re
    token = re.search(r'name="token" value="([0-9a-f]{24})"', page).group(1)
    r = client.post("/energy/import/intervals/confirm", data={"csrf_token": tok, "token": token, "factory": str(f1), "kind": "elec",
                                                             "shift": "0", "sel": [str(ms[0]), str(ms[1])], "rebuild": "1"}, follow_redirects=True)
    assert "นำเข้าค่าต่อช่วงแล้ว" in r.get_data(as_text=True)
    assert tuple(db.execute("SELECT COUNT(*), SUM(value) FROM en_intervals WHERE meter_id=?", (ms[0],)).fetchone()) == (96, 240.0)
    assert db.execute("SELECT MAX(value) FROM en_intervals WHERE meter_id=?", (ms[1],)).fetchone()[0] == 1.0
    assert db.execute("SELECT COUNT(*) FROM en_readings WHERE meter_id=? AND src<>'web'", (ms[0],)).fetchone()[0] == 0   # มีค่าจดเอง → ไม่แทน
    pj = client.get(f"/energy/meters/{ms[0]}/profile.json", query_string={"day": yd.isoformat()}).get_json()
    assert pj["sum"] == 240 and pj["peak"] == 10 and pj["res"] == 15
    mp = client.get(f"/energy/meters/{ms[0]}").get_data(as_text=True)
    assert "ch-meter2" in mp and "รายช่วงเวลา (ทุก 15 นาที)" in mp and "Target/วัน" in mp
    mp3 = client.get(f"/energy/meters/{ms[2]}").get_data(as_text=True)
    assert "วันที่ต้องตรวจ" in mp3 and "ขาดค่าอ่าน" in mp3
    rep = SM.summary(db, "elec", "meter", yd, yd, f1)
    a = [u for u in rep["units"] if u["key"] == str(ms[0])][0]
    assert a["hourly"] and abs(sum(a["hourly"]) - 240) < 1e-6
    iid = db.execute("SELECT MAX(id) FROM en_interval_imports").fetchone()[0]
    client.post(f"/energy/import/intervals/{iid}/undo", data={"csrf_token": tok})
    assert db.execute("SELECT COUNT(*) FROM en_intervals WHERE meter_id=?", (ms[0],)).fetchone()[0] == 0
    assert client.get("/energy/import/intervals-sample.xlsx").status_code == 200
    assert "ค่าทุก 15 นาที / รายชั่วโมง" in client.get("/energy/import").get_data(as_text=True)
