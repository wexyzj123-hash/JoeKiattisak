"""v0.69: Dashboard ห้องควบคุม (Control Room)"""
from datetime import date, timedelta

from conftest import login, uid

from ecs import energy as EN
from ecs import energy_dash as DASH

Y = 2025


def _meter(db, fid, code, kind, grp, start, per_day, main=0):
    mid = EN.save_meter(db, None, {"factory_id": fid, "kind": kind, "code": code, "name": code, "grp": grp, "is_main": main}, None)
    d = date(Y, 3, 1) - timedelta(days=1)
    v = start
    while d <= date(Y, 3, 20):
        EN.set_reading(db, mid, d.isoformat(), v, None)
        d += timedelta(days=1)
        v += per_day
    return mid


def test_control_data(app, db):
    f1 = app.config["F1"]
    _meter(db, f1, "E1", "elec", "MFG.1", 1000, 100)
    _meter(db, f1, "E2", "elec", "MFG.2", 500, 50)
    _meter(db, f1, "W1", "water", "MFG.1", 10, 5)
    c = DASH.control(db, date(Y, 3, 1), None, today=date(Y, 3, 21))
    assert c["kp"]["elec"]["ref_u"] == 150 and c["ref_day"] == "2025-03-20"
    assert c["kp"]["elec"]["total"] == 150 * 20 and c["kp"]["water"]["ref_u"] == 5
    assert c["kp"]["elec"]["target"] is None and c["money"]["ref"] >= 0      # ไม่มีข้อมูลเดือนก่อน → ไม่มีเส้นเป้า
    assert {s["name"] for s in c["sec_cards"]} == {"MFG.1", "MFG.2"}
    assert c["fstat"] and c["table"] and c["donut"]
    c2 = DASH.control(db, date(Y, 3, 1), f1, "MFG.1", today=date(Y, 3, 21))
    assert c2["kp"]["elec"]["ref_u"] == 100 and all(r["grp"] == "MFG.1" for r in c2["table"])
    t = DASH.trend_months(db, f1, "elec", date(Y, 3, 1), 3)
    assert len(t["months"]) == 3 and t["values"][-1] == 3000


def test_control_pages(app, client, db):
    f1 = app.config["F1"]
    _meter(db, f1, "E1", "elec", "MFG.1", 1000, 100)
    db.commit()
    login(client, "t_tech")
    r = client.get(f"/energy/?month={Y}-03&factory={f1}")
    assert r.status_code == 200 and b"Energy &amp; Utility Monitoring" in r.data and b"crTrend" in r.data
    assert client.get(f"/energy/?month={Y}-03&loc=MFG.1").status_code == 200
    assert client.get("/energy/?month=2031-01").status_code == 200                 # เดือนอนาคต/ไม่มีข้อมูล
    assert client.get(f"/energy/classic?month={Y}-03").status_code == 200
    r = client.get(f"/energy/api/trend?kind=elec&factory={f1}&month={Y}-03")
    assert r.status_code == 200 and len(r.get_json()["months"]) == 6
    assert client.get("/energy/api/trend?kind=zzz").status_code == 400
