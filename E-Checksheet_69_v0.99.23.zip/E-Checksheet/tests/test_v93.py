"""v0.93: Dashboard E-Check — ค่ากำลังเข้าใกล้เกณฑ์ · ตรงเวลารายพื้นที่×กะ + รายผู้ตรวจ · สถานะเครื่องจักร · เอกสารพร้อมรับตรวจ"""
import uuid
from datetime import date, datetime, timedelta

from conftest import login, uid
from ecs import insights as IN
from ecs import services as S
from ecs.services import ts

TODAY = S.now_dt().date()


def _sub(db, form, at: datetime, oil: float, insp, judgement="ok", status="submitted", dur=90):
    item = db.execute("SELECT id FROM cs_form_items WHERE version_id=? AND item_key='oil'", (form["version_id"],)).fetchone()[0]
    sid = db.execute("""INSERT INTO cs_submissions(client_uuid, form_id, form_version_id, equipment_id, inspector_id, finished_at,
                        received_at, duration_sec, status, approval_status) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                     (str(uuid.uuid4()), form["form_id"], form["version_id"], form["equipment_id"], insp, ts(at), ts(at), dur,
                      status, "pending")).lastrowid
    db.execute("INSERT INTO cs_answers(submission_id, item_id, item_key, value_num, judgement) VALUES (?,?,?,?,?)",
               (sid, item, "oil", oil, judgement))
    return sid


def _round(db, form, sched, due: datetime, status, sub=None):
    db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, submission_id, updated_at)
                  VALUES (?,?,?,?,?,?,?,?)""", (sched, form["form_id"], ts(due), ts(due + timedelta(hours=2)), ts(due + timedelta(hours=4)),
                                                status, sub, ts(due)))


def test_trending(app, db, published_form):
    insp = uid(db, "t_tech")
    for i in range(10):                                 # 2.00 → 2.45 ไล่ขึ้นเข้าหา Max 2.5
        _sub(db, published_form, datetime.combine(TODAY - timedelta(days=9 - i), datetime.min.time()).replace(hour=9), 2.0 + 0.05 * i,
             insp, "warn" if 2.0 + 0.05 * i >= 2.4 else "ok")
    db.commit()
    t = IN.trending(db, TODAY)
    assert t and t[0]["item_key"] == "oil" and t[0]["side"] == "max"
    assert "near" in t[0]["rules"] and "slope" in t[0]["rules"] and t[0]["eta"] is not None and t[0]["eta"] <= 2
    # ค่าล่าสุด NG แล้ว → ไม่อยู่ในรายการ (อยู่ในแจ้งเตือนแล้ว)
    _sub(db, published_form, datetime.combine(TODAY, datetime.min.time()).replace(hour=12), 2.6, insp, "ng")
    db.commit()
    assert not IN.trending(db, TODAY)


def test_shift_rate_and_people(app, db, published_form):
    insp = uid(db, "t_tech")
    sch = db.execute("""INSERT INTO cs_schedules(form_id, freq_type, times, created_at, updated_at) VALUES (?,?,?,?,?)""",
                     (published_form["form_id"], "shift", "08:00,22:00", "x", "x")).lastrowid
    d = TODAY - timedelta(days=2)
    for k, (h, st) in enumerate([(8, "done_on_time"), (22, "missed"), (8, "done_late"), (22, "done_on_time"), (8, "skipped")]):
        due = datetime.combine(d + timedelta(days=k // 2), datetime.min.time()).replace(hour=h)
        sub = _sub(db, published_form, due + timedelta(minutes=10), 2.1, insp, dur=20) if st.startswith("done") else None
        _round(db, published_form, sch, due, st, sub)
    db.commit()
    r = IN.shift_rate(db, d, TODAY)
    assert r["tot"]["day"]["n"] == 2 and r["tot"]["day"]["ok"] == 1 and r["tot"]["night"]["miss"] == 1   # รอบที่ข้าม (skipped) ไม่นับ
    p = r["people"][0]
    assert p["n"] == 3 and p["late"] == 1 and p["fast"] == 3 and p["night"] == 1


def test_machines_and_docs(app, db, published_form):
    from ecs import downtime as DT
    admin = uid(db, "t_admin")
    DT.set_down(db, published_form["equipment_id"], admin, "ไม่ได้ใช้งาน", "standby")
    last_m = (TODAY.replace(day=1) - timedelta(days=1)).replace(day=10)
    _sub(db, published_form, datetime.combine(last_m, datetime.min.time()).replace(hour=9), 2.1, uid(db, "t_tech"))
    db.commit()
    m = IN.machines(db, TODAY)
    assert m["count"]["standby"] == 1 and m["n_down"] == 1 and m["down"][0]["cat"] == "standby"
    dc = IN.doc_ready(db, TODAY)
    prev = dc["months"][1]
    assert prev["n"] == 1 and prev["ok"] == 0 and prev["pending"] == 1 and prev["forms"][0]["status"] in ("crit", "warn")


def test_dashboard_page(app, db, client, published_form):
    _sub(db, published_form, S.now_dt() - timedelta(hours=1), 2.45, uid(db, "t_tech"), "warn")
    db.commit()
    login(client, "t_admin")
    page = client.get("/dashboard").get_data(as_text=True)
    for s in ("เจาะลึกการตรวจ", "ค่ากำลังเข้าใกล้เกณฑ์", "แยกพื้นที่ × กะ", "สถานะเครื่องจักร", "เอกสารพร้อมรับตรวจ"):
        assert s in page, s
