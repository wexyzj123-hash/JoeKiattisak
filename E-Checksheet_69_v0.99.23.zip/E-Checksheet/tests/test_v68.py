"""v0.68: นำเข้าไฟล์เดิม — ELECTRICITY cost (ชื่อชีตไม่บอกโรงงาน), ไฟล์ประจำวันส่งต่อตัวนำเข้าประจำวัน"""
import io
from datetime import date

from conftest import login
from openpyxl import Workbook

from ecs import energy_cost as C

Y = 2025


def _cost_book(sheet="คำนวน") -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = sheet
    ws["A2"], ws["B2"], ws["D2"] = "SECTION", "MOUNT", "NO"
    ws["E2"], ws["F2"] = date(Y, 1, 1), date(Y, 2, 1)
    ws.append(["", "Total (Kwh)", "", "", 1000, 1100])
    ws.append(["", "Bath (฿)", "", "", 4000, 4400])
    ws.append(["LINE", "M1", "N1", "", 10, 11])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def test_factory_from_filename():
    p = C.parse_em(_cost_book(), Y, "ELECTRICITY cost 2026 ไอชิน 1.xlsx")
    assert p["sheets"] and p["sheets"][0]["idx"] == 1
    p = C.parse_em(_cost_book(), Y, "ELECTRICITY cost 2024 ไอชิน 3.xlsx")
    assert p["sheets"][0]["idx"] == 3


def test_daily_file_forwarded(app, client):
    wb = Workbook()
    ws = wb.active
    ws.title = "1"
    ws.append(["Meter", "No.", 1, 2, 3])
    ws.append(["A", "A1", 100, 110, 120])
    buf = io.BytesIO()
    wb.save(buf)
    tok = login(client, "t_admin")
    r = client.post("/energy/cost/import", data={"csrf_token": tok, "year": Y, "file": (io.BytesIO(buf.getvalue()), "Electric used ไอชิน 2.xlsx")},
                    content_type="multipart/form-data")
    assert r.status_code == 200
    r = client.post("/energy/cost/import", data={"csrf_token": tok, "year": Y, "file": (io.BytesIO(b"x"), "a.txt")},
                    content_type="multipart/form-data")
    assert r.status_code == 200 and "รองรับไฟล์ Excel".encode() in r.data
