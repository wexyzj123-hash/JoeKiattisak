"""v0.77: ช่วงค่าที่เป็นไปได้ต่อ Tag — ค่านอกช่วงไม่ลงรายงาน · แจ้งผู้ดูแล · หน้าตรวจย้อนหลังแสดง ⚠ · ไม่ดึงซ้ำวนไป"""
import io
import json
from datetime import datetime, time

from conftest import login, uid
from test_v73 import _at, _day, _hist, _rows, _setup

from ecs import connectors as CN
from ecs import srcmap as SM
from ecs import tagmatch as TM
from ecs.services import ts


def _val(db, t):
    r = db.execute("""SELECT a.value_num FROM cs_submissions s JOIN cs_answers a ON a.submission_id=s.id
                      WHERE s.source='auto' AND s.finished_at=? AND a.item_key='oil'""", (ts(t),)).fetchone()
    return r[0] if r else None


def test_out_of_range_values_skipped_alerted_and_audited(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    rows = _rows(day)
    rows = [(t, x, 999.0 if x[11:13] == "20" else v) for t, x, v in rows]         # 20:xx ค่าผิด (Sensor เพี้ยน)
    _hist(path, rows)
    sid = _setup(db, published_form, path)
    fid = published_form["form_id"]
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil", "valid_min": "0", "valid_max": "50"}], None)
    CN.run_source(db, sid, now=_at(day, 23))
    assert _val(db, _at(day, 8, 30)) == 8.3
    v = _val(db, _at(day, 20, 30))
    assert v is None or v < 50                                                     # 999 ไม่ลงรายงาน
    assert any("นอกช่วง" in r[0] for r in db.execute("SELECT title FROM cs_notifications WHERE kind='source_watch'"))
    # หน้าต่างเลือกค่า 20:00–21:00 มีค่าดีที่ 21:00 → ใช้ค่านั้น
    assert v == 21.0
    # ทั้งช่วงเป็นค่าผิด → ⚠ นอกช่วง (ไม่ใช่ ขาด) และไม่ถูกนับเป็นช่องที่ต้องดึงซ้ำ
    db.execute("UPDATE cs_source_values SET value=999 WHERE source_id=? AND ts BETWEEN ? AND ?", (sid, f"{day} 08:00", f"{day} 09:00"))
    from ecs import submissions as SUB
    sub = db.execute("SELECT id FROM cs_submissions WHERE finished_at=? AND source='auto'", (ts(_at(day, 8, 30)),)).fetchone()[0]
    SUB.delete_submissions(db, [sub], uid(db, "t_admin"), "ทดสอบ")
    st = SM.slot_status(db, sid, day, now=_at(day, 23, 30))
    assert [x["state"] for f in st for x in f["slots"] if x["t"] == "08:30"] == ["invalid"]
    assert all(g["at"] != _at(day, 8, 30) for g in SM.health(db, sid, _at(day, 23, 30))["missing"])
    rep = SM.audit(db, sid, day, day, now=_at(day, 23, 30))
    cell = [r for r in rep["forms"][0]["rows"] if r["hm"] == "08:30"][0]["cells"]["oil"]
    assert cell["state"] == "invalid" and cell["raw"] == 999
    assert any("ค่านอกช่วงที่เป็นไปได้" in i["text"] for i in rep["issues"])
    # แก้ช่วง → ลงค่าใหม่ย้อนหลังเอง (snapshot เปลี่ยน)
    before = SM.mapping_snapshot(db)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil", "valid_min": "", "valid_max": ""}], None)
    assert SM.changed_forms(before, SM.mapping_snapshot(db)) == {sid: {fid}}


def test_range_validation_and_excel(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    fid = published_form["form_id"]
    import pytest
    from ecs.services import ValidationError
    with pytest.raises(ValidationError):
        CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil", "valid_min": "10", "valid_max": "1"}], None)
    with pytest.raises(ValidationError):
        CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil", "valid_min": "abc"}], None)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil", "valid_min": "1", "valid_max": "30"}], None)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil"}], None)        # ฟอร์มที่ไม่มีช่องช่วง → ไม่ล้างค่าเดิม
    assert db.execute("SELECT valid_min, valid_max FROM cs_source_tags WHERE source_id=? AND tag='OIL'", (sid,)).fetchone()[:] == (1, 30)
    from openpyxl import load_workbook
    raw = TM.export_xlsx(db, sid)
    wb = load_workbook(io.BytesIO(raw))
    ws = wb["จับคู่ Tag"]
    head = [c.value for c in ws[1]]
    assert "ค่าต่ำสุดที่เป็นไปได้" in head
    for r in ws.iter_rows(min_row=2):
        if r[0].value == "OIL":
            r[head.index("ค่าสูงสุดที่เป็นไปได้")].value = 25
    bio = io.BytesIO()
    wb.save(bio)
    TM.import_xlsx(db, sid, bio.getvalue(), None)
    assert db.execute("SELECT valid_max FROM cs_source_tags WHERE source_id=? AND tag='OIL'", (sid,)).fetchone()[0] == 25
    db.commit()
    c = app.test_client()
    tok = login(c, "t_admin")
    page = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert 'name="vmin.0"' in page and "ช่วงที่เป็นไปได้" in page
    r = c.post(f"/admin/sources/{sid}/tags", data={"csrf_token": tok, "tag": ["OIL"], "target.0": f"{fid}:oil", "scale.0": "1",
                                                  "offset.0": "0", "vmin.0": "2", "vmax.0": "40", "reapply_days": "0"})
    assert r.status_code in (302, 303)
    assert db.execute("SELECT valid_min, valid_max FROM cs_source_tags WHERE source_id=? AND tag='OIL'", (sid,)).fetchone()[:] == (2, 40)
    assert "⚠" in c.get(f"/admin/sources/{sid}/audit").get_data(as_text=True)


def test_energy_range(app, db, client, tmp_path):
    from ecs import energy as EN
    from ecs import energy_src as ES
    f1 = app.config["F1"]
    day = _day()
    path = str(tmp_path / "e.db")
    _hist(path, [("KWH1", ts(datetime.combine(day, time(8, 0))), 0.0), ("KWH1", ts(datetime.combine(day, time(8, 40))), 5000.0)])
    sid = ES.save_source(db, {"name": "E", "kind": "sqlite", "active": "1",
                              "config": json.dumps({"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                                    "backfill_days": 2})}, None)
    mid = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "K1", "name": "K1", "scada_source_id": str(sid),
                                   "scada_tag": "KWH1"}, None)
    ES.save_mapping(db, sid, [{"tag": "KWH1", "meter": str(mid), "vmin": "1"}], None)
    ES.run_source(db, sid, now=_at(day, 12))
    v = db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
    assert v and v[0] == 5000                                                        # ค่า 0 ตอน 08:00 ถูกตัด ใช้ 08:40 แทน
    assert any("นอกช่วง" in r[0] for r in db.execute("SELECT title FROM cs_notifications WHERE kind='source_watch'"))
    db.commit()
    login(client, "t_admin")
    assert 'name="vmin.0"' in client.get(f"/energy/sources/{sid}").get_data(as_text=True)
    assert ES.export_xlsx(db, sid)[:2] == b"PK"
