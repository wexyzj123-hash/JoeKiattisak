"""v0.56: เครื่องแจ้งหยุดอยู่ + ช่างส่งผลตรวจ → ปลดเป็นเดินเครื่องอัตโนมัติ (ผู้ตรวจ · เวลาตามกะ)"""
from datetime import datetime, timedelta

from conftest import GOOD, login, payload, uid

from ecs import downtime as DT
from ecs import services as S
from ecs import submissions as SUB


def _setup(db, fid, now):
    sid = S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00"}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    return sid


def _round(db, sid, fid, due, hours=4):
    return db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                         VALUES (?,?,?,?,?,'pending',?)""", (sid, fid, S.ts(due), S.ts(due + timedelta(hours=hours)),
                                                             S.ts(due + timedelta(hours=hours * 2)), S.ts(due))).lastrowid


def test_check_releases_downtime_by_shift(app, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    day = S.now_dt().date() - timedelta(days=1)
    base = datetime.combine(day, datetime.min.time())
    sid = _setup(db, fid, base)
    early = _round(db, sid, fid, base + timedelta(hours=8), hours=0.25)      # 08:00 ปิด 08:30 (ก่อนช่างมา)
    cur = _round(db, sid, fid, base + timedelta(hours=9))                    # 09:00 ปิด 17:00
    db.commit()
    DT.set_down(db, eq, uid(db, "t_tech2"), "หยุดตามแผน", "stop", start_at=base - timedelta(hours=3))   # 21:00 เมื่อวาน
    db.commit()
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (cur,)).fetchone()[0] == "skipped"
    now = base + timedelta(hours=9, minutes=5)
    p = payload(published_form, GOOD, scanned_at=(now - timedelta(minutes=4)).isoformat(), finished_at=now.isoformat())
    res = SUB.create_submission(db, p, {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"], now=now)
    db.commit()
    assert res["auto_running"] and res["round_status"] == "done_on_time" and res["round_due"] == S.ts(base + timedelta(hours=9))
    e = db.execute("SELECT run_status FROM equipment WHERE id=?", (eq,)).fetchone()[0]
    assert e == "running"
    d = db.execute("SELECT end_at, ended_by, end_note FROM cs_downtime WHERE equipment_id=?", (eq,)).fetchone()
    assert d["ended_by"] == uid(db, "t_tech") and "ปลดอัตโนมัติ" in d["end_note"]
    # เดินตั้งแต่เริ่มกะ แต่เลื่อนไปหลังรอบ 08:00 ที่ปิดไปแล้ว → รอบนั้นยังเป็นงดตรวจ
    assert S.ts(base + timedelta(hours=8)) <= d["end_at"] <= S.ts(base + timedelta(hours=8, minutes=30))
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (early,)).fetchone()[0] == "skipped"
    assert DT.fix_stale_skipped(db, now) == 0


def test_check_before_stop_does_not_release(app, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    now = S.now_dt()
    DT.set_down(db, eq, uid(db, "t_tech2"), "ซ่อม", "repair", start_at=now - timedelta(minutes=30))
    db.commit()
    t = now - timedelta(hours=2)                                         # ผลออฟไลน์ที่ทำก่อนกดหยุด
    p = payload(published_form, GOOD, scanned_at=t.isoformat(), finished_at=(t + timedelta(minutes=3)).isoformat())
    res = SUB.create_submission(db, p, {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"], now=now)
    assert not res["auto_running"]
    assert db.execute("SELECT run_status FROM equipment WHERE id=?", (eq,)).fetchone()[0] == "down"


def test_shift_start():
    cal = {"shift_times": "08:00,20:00"}
    assert DT.shift_start_of(datetime(2026, 10, 4, 9, 1), cal) == datetime(2026, 10, 4, 8, 0)
    assert DT.shift_start_of(datetime(2026, 10, 4, 3, 0), cal) == datetime(2026, 10, 3, 20, 0)
    assert DT.shift_start_of(datetime(2026, 10, 4, 21, 0), cal) == datetime(2026, 10, 4, 20, 0)


def test_fill_status_bar_and_qr_gate(app, client, db, published_form):
    login(client, "t_tech")
    js = client.get("/static/m/fill.js").get_data(as_text=True)
    assert "eqStatusBar" in js and "statusGate" in js and "เครื่องเดินอยู่ — เริ่มตรวจ" in js and "auto_running" in js
    css = client.get("/static/css/m.css").get_data(as_text=True)
    assert ".m-eqbar" in css and "overflow-x: clip" in css
    pkg = client.get(f"/api/m/forms/{published_form['form_id']}/package").get_json()
    assert pkg["down"] is None
    DT.set_down(db, published_form["equipment_id"], uid(db, "t_tech2"), "ซ่อม", "repair")
    db.commit()
    d = client.get(f"/api/m/forms/{published_form['form_id']}/package").get_json()["down"]
    assert d["down_by_name"] == "ทดสอบ t_tech2"
