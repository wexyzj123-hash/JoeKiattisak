"""v0.26.2: บันทึกข้อผิดพลาดจากเบราว์เซอร์ (iPhone) · ตัวบันทึกฝังในทุกหน้า · กราฟมีทางสำรอง"""
from conftest import login


def test_client_log(app, caplog):
    c = app.test_client()
    tok = login(c, "t_tech")
    page = c.get("/m/").get_data(as_text=True)
    assert "window.ECSLog" in page and "/api/client-log" in page
    with caplog.at_level("WARNING", logger="ecs.client"):
        r = c.post("/api/client-log", json={"msg": "TypeError: x is undefined", "url": "/dashboard", "w": 390, "dpr": 3},
                   headers={"X-CSRF-Token": tok, "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)"})
    assert r.status_code == 200 and any("iPhone" in m and "x is undefined" in m for m in caplog.messages)
    assert c.post("/api/client-log", json={"msg": "no csrf"}).status_code == 400
    anon = app.test_client()
    assert anon.post("/api/client-log", json={"msg": "x"}).status_code in (400, 401, 302)


def test_dashboard_has_chart_fallback(app):
    c = app.test_client()
    login(c, "t_admin")
    html = c.get("/dashboard").get_data(as_text=True)
    assert "const safe = (fn)" in html and "window.ECSLog" in html
