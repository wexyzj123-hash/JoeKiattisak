"""v0.40: เลื่อนข้อถัดไปอัตโนมัติ (หน้ากรอก) · เตรียมออฟไลน์ทั้งกะ + โหมดออฟไลน์"""
from datetime import timedelta

from conftest import login, uid

from ecs import services as S
from ecs import walkroutes as R


def _setup(app, db, form):
    fid = form["form_id"]
    admin = uid(db, "t_admin")
    S.create_schedule(db, fid, {"freq_type": "daily", "times": "00:00", "window_min": 1439}, admin)
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (S.ts(S.now_dt() - timedelta(days=2)),))
    # แบบฟอร์มที่ 2 (ไม่มีรอบ) อยู่ในเส้นทางของช่าง
    fid2 = S.create_form(db, {"name": "Weekly Pump", "code": "PM-02", "factory_id": app.config["F1"]}, admin)
    d = S.get_draft(db, fid2)
    S.save_draft_items(db, d["id"], [{"item_key": "a", "name": "ตรวจ", "item_type": "ok_ng"}], admin)
    S.publish_version(db, d["id"], admin)
    # แบบฟอร์มที่ 3 ไม่อยู่ในงานวันนี้/เส้นทาง
    fid3 = S.create_form(db, {"name": "Other", "code": "OT-03", "factory_id": app.config["F1"]}, admin)
    d3 = S.get_draft(db, fid3)
    S.save_draft_items(db, d3["id"], [{"item_key": "a", "name": "ตรวจ", "item_type": "ok_ng"}], admin)
    S.publish_version(db, d3["id"], admin)
    R.save_route(db, {"name": "รอบเช้า", "factory_id": app.config["F1"]}, [fid2], admin)
    db.commit()
    return fid, fid2, fid3


def test_offline_pack_and_packages(app, db, published_form):
    fid, fid2, fid3 = _setup(app, db, published_form)
    c = app.test_client()
    login(c, "t_tech")
    d = c.get("/api/m/offline-pack").get_json()
    assert fid in d["form_ids"] and fid2 in d["form_ids"] and fid3 not in d["form_ids"]      # งานวันนี้ + เส้นทาง
    assert d["tasks"]["groups"] and d["routes"] and d["route_details"]
    assert any(fid in ids for ids in d["tokens"].values())                                  # QR เครื่อง → แบบฟอร์ม
    tok = db.execute("SELECT qr_token FROM equipment WHERE id=?", (published_form["equipment_id"],)).fetchone()[0]
    assert d["tokens"][tok] == [fid]
    d_all = c.get("/api/m/offline-pack?all=1").get_json()
    assert fid3 in d_all["form_ids"]
    p = c.get(f"/api/m/packages?ids={fid},{fid2},99999").get_json()["packages"]
    assert p[str(fid)]["form"]["id"] == fid and "machine" in p[str(fid)] and p[str(fid)]["items"]
    assert p[str(fid2)]["form"]["name"] == "Weekly Pump"
    assert "error" in p["99999"]
    login(c, "t_tech2")                                                                    # อีกโรงงาน → ไม่มีสิทธิ์
    assert "error" in c.get(f"/api/m/packages?ids={fid}").get_json()["packages"][str(fid)]


def test_pages_include_offline_and_autoadvance(app, db, published_form):
    c = app.test_client()
    login(c, "t_tech")
    home = c.get("/m/").get_data(as_text=True)
    assert 'id="offBox"' in home and "m/offline.js" in home
    fill = c.get("/m/fill").get_data(as_text=True)
    assert "m/jsqr.js" in fill and "m/offline.js" in fill
    js = c.get("/static/m/fill.js").get_data(as_text=True)
    assert "function advance" in js and "enterkeyhint" in js and "renderPicker" in js
    assert "location.reload());" not in js.split("hashchange")[1][:80]                     # เปลี่ยนแบบฟอร์มในหน้าเดิม
