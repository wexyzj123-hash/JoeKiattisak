"""v0.29: จำกัดการดูเช็คชีท — ผู้ใช้หน่วยงาน ENVIRONMENT / SAFETY เห็นเฉพาะเช็คชีทที่มีสิทธิ์อนุมัติ"""
from conftest import emo, GOOD, login, payload, uid

from ecs import masterdata as M
from ecs import services as S
from ecs import sign_blocks as SB
from ecs import signoffs as SO
from ecs import view_scope as VS


def _forms(app, db):
    admin = uid(db, "t_admin")
    out = {}
    for code, dept in (("ENV-01", "env"), ("SAF-01", "safety"), ("UT-01", "")):
        fid = S.create_form(db, {"name": f"Form {code}", "code": code, "factory_id": app.config["F1"]}, admin)
        d = S.get_draft(db, fid)
        S.save_draft_items(db, d["id"], [{"item_key": "a", "name": "ตรวจ", "item_type": "ok_ng"}], admin)
        S.publish_version(db, d["id"], admin)
        if dept:
            SB.save(db, [fid], {"boxes": [dept]}, admin)
        out[dept or "ut"] = fid
    db.commit()
    return out


def test_restrict_view(app, db, published_form):
    f = _forms(app, db)
    view = uid(db, "t_view")
    SO.save_roles(db, {"env_sv": [view]}, None)
    db.commit()
    c = app.test_client()
    login(c, "t_view")
    # ยังไม่จำกัด → เห็นทุกแบบฟอร์ม
    assert c.get("/dashboard").status_code == 200
    assert "UT-01" in c.get("/forms").get_data(as_text=True)
    # ผู้ดูแลระบบติ๊กจำกัดการดู (หน้าตำแหน่งผู้ลงนาม)
    ca = app.test_client()
    ta = login(ca, "t_admin")
    ids = [u["id"] for u in M.list_users(db, include_inactive=False)]
    data = {"csrf_token": ta, **{f"pos_{i}": "" for i in ids}, f"rv_{view}": "1", "env_sv": [str(view)]}
    ca.post("/signoffs/roles", data=data)
    assert VS.is_restricted(db, view)
    assert "🔒" in emo(ca.get("/admin/users").get_data(as_text=True))
    assert VS.allowed_form_ids(db, view) == {f["env"]}
    # เห็นเฉพาะแบบฟอร์ม ENVIRONMENT
    html = c.get("/forms").get_data(as_text=True)
    assert "ENV-01" in html and "SAF-01" not in html and "UT-01" not in html
    rep = c.get("/reports").get_data(as_text=True)
    assert "ENV-01" in rep and "SAF-01" not in rep
    assert c.get(f"/forms/{f['env']}").status_code == 200
    assert c.get(f"/forms/{f['safety']}").status_code == 403
    assert c.get(f"/reports/sheets?form={f['ut']}").status_code == 403
    assert c.get(f"/reports/sheets?form={f['env']}").status_code == 200
    # หน้ารวมทุกแบบฟอร์มถูกปิด · เมนูซ่อน
    r = c.get("/dashboard")
    assert r.status_code == 302 and "/reports" in r.headers["Location"]
    assert c.get("/api/trend").status_code == 403
    assert c.get("/").headers["Location"].endswith("/reports")
    page = c.get("/reports").get_data(as_text=True)
    assert 'href="/dashboard"' not in page and 'href="/trends"' not in page
    # ผลตรวจของแบบฟอร์มอื่นไม่แสดง / เปิดตรงไม่ได้
    from ecs import submissions as SUB
    SUB.create_submission(db, payload(published_form, GOOD), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    sid = db.execute("SELECT MAX(id) FROM cs_submissions").fetchone()[0]
    assert c.get(f"/submissions/{sid}").status_code == 403
    assert "Daily AC" not in c.get("/submissions").get_data(as_text=True)
    # ผู้ดูแลระบบไม่ถูกจำกัด
    M.set_restrict_view(db, uid(db, "t_admin"), 1, None)
    db.commit()
    assert ca.get("/dashboard").status_code == 200
    # ยกเลิกจำกัด → กลับมาเห็นทั้งหมด
    ca.post(f"/admin/users/{view}", data={"csrf_token": ta, "username": "t_view", "name": "t_view", "role": "viewer", "active": "1"})
    assert not VS.is_restricted(db, view)
    assert c.get("/dashboard").status_code == 200


def test_restrict_safety_dm(app, db):
    f = _forms(app, db)
    sup = uid(db, "t_sup")
    SO.save_positions(db, {sup: "dm"}, None)
    M.set_restrict_view(db, sup, 1, None)
    db.commit()
    assert VS.allowed_form_ids(db, sup) == {f["safety"]}
    c = app.test_client()
    login(c, "t_sup")
    assert c.get(f"/forms/{f['safety']}").status_code == 200
    assert c.get(f"/forms/{f['env']}").status_code == 403
    assert c.get("/approvals").status_code == 302
    assert c.get("/approvals/group").status_code == 200
    # ไม่มีกลุ่มหน่วยงาน → ไม่เห็นแบบฟอร์มใดเลย
    SO.save_positions(db, {sup: "sv"}, None)
    db.commit()
    assert VS.allowed_form_ids(db, sup) == set()
