"""v0.86: Energy — ดึงค่าย้อนหลังตามช่วงที่กำหนด (≤ 62 วัน) · เลือกมิเตอร์ซ้ำไม่ทำให้ที่เลือกไว้หาย · ค้นหา Tag"""
import json
from datetime import datetime, time, timedelta

from conftest import login
from test_v73 import _hist

from ecs import energy as EN
from ecs import energy_src as ES
from ecs import services as S
from ecs.services import ts


def _src(app, db, tmp_path, days=45):
    today = S.now_dt().date()
    path = str(tmp_path / "e.db")
    rows = []
    for i in range(days, 0, -1):
        d = today - timedelta(days=i)
        rows += [("KWH1", ts(datetime.combine(d, time(8, 0))), 1000.0 + i * -10 + 1000), ("KWH2", ts(datetime.combine(d, time(8, 0))), 50.0 + days - i)]
    _hist(path, rows)
    sid = ES.save_source(db, {"name": "E", "kind": "sqlite", "active": "1",
                              "config": json.dumps({"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                                    "backfill_days": 1})}, None)
    f1 = app.config["F1"]
    m1 = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "K1", "name": "K1", "grp": "PM",
                                  "scada_source_id": str(sid), "scada_tag": "KWH1"}, None)
    m2 = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "K2", "name": "K2", "grp": "MFG",
                                  "scada_source_id": str(sid), "scada_tag": "KWH2"}, None)
    db.commit()
    return sid, m1, m2, today


def _n(db, mid):
    return db.execute("SELECT COUNT(*) FROM en_readings WHERE meter_id=?", (mid,)).fetchone()[0]


def test_backfill_custom_range(app, db, tmp_path):
    sid, m1, m2, today = _src(app, db, tmp_path)
    r = ES.backfill(db, sid, today - timedelta(days=40), today - timedelta(days=1), "fill", None)   # > 31 วัน (เดิมล้ม)
    db.commit()
    assert r["readings"] == 80 and _n(db, m1) == 40 and _n(db, m2) == 40
    db.execute("UPDATE en_readings SET value=1 WHERE meter_id=?", (m1,))
    r = ES.backfill(db, sid, today - timedelta(days=10), today - timedelta(days=1), "fill", None)
    assert r["readings"] == 0                                                   # เติมเฉพาะที่ขาด → ไม่ทับ
    r = ES.backfill(db, sid, today - timedelta(days=10), today - timedelta(days=1), "replace", None, grp="PM")
    db.commit()
    assert r["removed"] == 10 and r["readings"] == 10
    assert db.execute("SELECT COUNT(*) FROM en_readings WHERE meter_id=? AND value=1", (m1,)).fetchone()[0] == 30
    try:
        ES.backfill(db, sid, today - timedelta(days=70), today, "fill", None)
        assert False
    except S.ValidationError as exc:
        assert "62" in exc.errors[0]


def test_backfill_route_and_page(app, db, client, tmp_path):
    sid, m1, m2, today = _src(app, db, tmp_path)
    tok = login(client, "t_admin")
    page = client.get(f"/energy/sources/{sid}").get_data(as_text=True)
    assert "ดึงค่าย้อนหลัง (กำหนดช่วงเอง)" in page and 'data-bf="62"' in page
    r = client.post(f"/energy/sources/{sid}/backfill", data={"csrf_token": tok, "from": (today - timedelta(days=44)).isoformat(),
                                                              "to": today.isoformat(), "mode": "fill"}, follow_redirects=True)
    assert "ดึงค่าย้อนหลัง" in r.get_data(as_text=True)
    assert _n(db, m1) == 44
    assert "ลงค่าใหม่ทั้งช่วงนี้" in client.get(f"/energy/sources/{sid}/audit").get_data(as_text=True)


def test_duplicate_meter_keeps_other_rows(app, db, client, tmp_path):
    sid, m1, m2, today = _src(app, db, tmp_path)
    db.execute("INSERT INTO en_source_tags(source_id, tag) VALUES (?, 'KWH3'), (?, 'KWH4')", (sid, sid))
    db.commit()
    tok = login(client, "t_admin")
    # KWH3 เลือก m2 (ซ้ำกับ KWH2) + KWH4 เลือกมิเตอร์ผิด → KWH1 ตัวคูณใหม่ยังบันทึกได้ · m2 ย้ายไป KWH3
    rows = ES.tag_rows(db, sid)
    tags = [r["tag"] for r in rows]
    data = {"csrf_token": tok, "tag": tags, "reapply_days": "0"}
    for i, t in enumerate(tags):
        data[f"meter.{i}"] = {"KWH1": f"#{m1}", "KWH2": f"#{m2}", "KWH3": f"#{m2}", "KWH4": "ไม่มีมิเตอร์นี้"}[t]
        data[f"scale.{i}"] = "3" if t == "KWH1" else "1"
        data[f"offset.{i}"] = "0"
    r = client.post(f"/energy/sources/{sid}/tags", data=data, follow_redirects=True)
    html = r.get_data(as_text=True)
    assert "ย้าย" in html and "KWH4" in html
    assert EN.meter(db, m2)["scada_tag"] == "KWH3" and EN.meter(db, m1)["scada_tag"] == "KWH1"
    assert db.execute("SELECT scale FROM en_source_tags WHERE source_id=? AND tag='KWH1'", (sid,)).fetchone()[0] == 3
    # เลือกมิเตอร์เดียวกันพร้อมกัน 2 แถวใหม่ → คงค่าเดิม
    r = ES.save_mapping(db, sid, [{"tag": "KWH1", "meter": str(m1)}, {"tag": "KWH2", "meter": str(m1)}, {"tag": "KWH4", "meter": str(m1)}], None)
    assert any("ซ้ำ" in w for w in r["warnings"]) and EN.meter(db, m1)["scada_tag"] == "KWH1"
    # ค้นหา Tag ทุกตัว
    page = client.get(f"/energy/sources/{sid}", query_string={"q": "kwh3"}).get_data(as_text=True)
    assert "ผลค้นหา" in page and 'value="KWH3"' in page and 'value="KWH1"' not in page
