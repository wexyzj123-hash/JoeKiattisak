"""v0.74: ค่า SCADA ลงรายงานทันที (แม้รอยืนยัน) + แจ้งเตือน + ยกเลิก/แก้ค่า (คงอยู่เมื่อดึงซ้ำ) + ตรวจสอบย้อนหลัง"""
from datetime import timedelta

from conftest import login, uid
from test_v73 import _at, _day, _hist, _rows, _setup, _slots

from ecs import connectors as CN
from ecs import services as S
from ecs import srcmap as SM
from ecs.services import ts


def _sheet_vals(db, fid, day):
    from ecs import sheet_report as SR
    sh = SR.build_month_sheet(db, fid, day.replace(day=1), "x")
    out = {}
    for row in sh["rows"]:
        if row["it"]["item_key"] == "oil":
            for ln in row.get("lines", []):
                c = ln["cells"][day.day - 1]
                out[ln["label"]] = c["value_num"] if c else None
    return out


def _run(db, sid, day, m=0):
    CN.run_source(db, sid, now=_at(day, 23, m))
    db.commit()


def test_pending_values_in_report_and_alert(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    sup = uid(db, "t_sup") if db.execute("SELECT 1 FROM users WHERE username='t_sup'").fetchone() else None
    _run(db, sid, day)
    fid = published_form["form_id"]
    assert db.execute("SELECT COUNT(*) FROM cs_submissions WHERE source='auto' AND approval_status='pending'").fetchone()[0] == 2
    vals = _sheet_vals(db, fid, day)
    assert vals.get("08:30") is not None and vals.get("20:30") is not None        # ลงรายงานแล้วแม้ยังรอยืนยัน
    n = db.execute("SELECT COUNT(*) FROM cs_notifications WHERE kind='auto_pending'").fetchone()[0]
    assert n >= 1                                                                    # แจ้งผู้อนุมัติ/ผู้ดูแล
    _run(db, sid, day, 5)
    assert db.execute("SELECT COUNT(*) FROM cs_notifications WHERE kind='auto_pending'").fetchone()[0] == n   # ไม่แจ้งซ้ำในวันเดียวกัน


def test_void_and_fix_survive_refetch_and_relay(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    _run(db, sid, day)
    fid = published_form["form_id"]
    admin = uid(db, "t_admin")
    t1, t2 = _at(day, 8, 30), _at(day, 20, 30)
    SM.set_fix(db, sid, fid, t1, "", "void", None, "เครื่องหยุดซ่อม", admin)
    SM.set_fix(db, sid, fid, t2, "oil", "value", "2.55", "อ่านหน้าปัดจริง", admin)
    db.commit()
    assert _slots(db, day) == [f"{day} 20:30:00"]
    assert _sheet_vals(db, fid, day) == {"08:30": None, "20:30": 2.55}
    a = db.execute("""SELECT a.value_src FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
                      WHERE s.finished_at=? AND a.item_key='oil'""", (ts(t2),)).fetchone()
    assert a[0] == "fixed"
    _run(db, sid, day, 20)                                                         # ดึงซ้ำ / เติมช่องที่ขาด
    SM.relay(db, sid, day, day, admin)                                             # ลงค่าใหม่ทั้งวัน
    db.commit()
    assert _slots(db, day) == [f"{day} 20:30:00"]
    assert _sheet_vals(db, fid, day)["20:30"] == 2.55
    SM.clear_fix(db, sid, fid, t1, "*", admin)                                     # คืนค่า
    SM.clear_fix(db, sid, fid, t2, "oil", admin)
    db.commit()
    v = _sheet_vals(db, fid, day)
    assert v["08:30"] is not None and v["20:30"] != 2.55
    s = db.execute("SELECT id FROM cs_submissions WHERE finished_at=? AND source='auto'", (ts(t1),)).fetchone()[0]
    SM.void_submission(db, s, "ค่าผิด", admin)                                    # ยกเลิกจากหน้ารออนุมัติ
    db.commit()
    assert _sheet_vals(db, fid, day)["08:30"] is None
    try:
        SM.set_fix(db, sid, fid, t2, "oil", "void", None, "", admin)
        assert False
    except S.ValidationError:
        pass


def test_audit_states_issues_and_fill_range(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day, skip=(19 * 60 + 40, 21 * 60 + 20)))
    sid = _setup(db, published_form, path)
    _run(db, sid, day)
    fid = published_form["form_id"]
    rep = SM.audit(db, sid, day - timedelta(days=1), day, now=_at(day, 23, 5))
    f = rep["forms"][0]
    st = {(r["t"].strftime("%Y-%m-%d %H:%M")): r["cells"]["oil"]["state"] for r in f["rows"]}
    assert st[f"{day} 08:30"] == "pending" and st[f"{day} 20:30"] == "missing"
    assert any("ขาดค่า" in i["text"] for i in rep["issues"]) and rep["count"]["missing"] >= 1
    # ค่าดิบเปลี่ยนหลังลงค่า (เช่น แก้ตัวคูณ) → ไม่ตรง
    db.execute("UPDATE cs_source_tags SET scale=10 WHERE source_id=? AND tag='OIL'", (sid,))
    rep = SM.audit(db, sid, day, day, now=_at(day, 23, 5))
    assert rep["forms"][0]["rows"][0]["cells"]["oil"]["state"] == "diff"
    db.execute("UPDATE cs_source_tags SET scale=1 WHERE source_id=? AND tag='OIL'", (sid,))
    # ค่าที่มาช้า → ดึงช่องที่ขาดในช่วง (ไม่ลบค่าเดิม)
    _hist(path, [r for r in _rows(day) if r[1][11:13] in ("19", "20", "21")])
    r = SM.fill_range(db, CN.get_source(db, sid), day, day, now=_at(day, 23, 6))
    db.commit()
    assert r["created"] >= 1 and f"{day} 20:30:00" in _slots(db, day)
    assert SM.audit_xlsx(db, sid, day, day)[:2] == b"PK"


def test_pages_and_actions(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid)
    db.commit()
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_admin")
    q = {"from": day.isoformat(), "to": day.isoformat()}
    page = c.get(f"/admin/sources/{sid}/audit", query_string=q).get_data(as_text=True)
    assert "ตรวจสอบ / แก้ไขค่าจาก SCADA" in page and "data-fix" in page
    assert c.get("/sources/audit").status_code in (302, 303)
    assert c.get(f"/admin/sources/{sid}/audit.xlsx", query_string=q).status_code == 200
    r = c.post(f"/admin/sources/{sid}/fix", data={"csrf_token": tok, "form_id": fid, "at": f"{day} 20:30:00", "item_key": "oil",
                                                 "act": "value", "value": "3.1", "reason": "ทดสอบแก้", **q})
    assert r.status_code in (302, 303)
    assert SM.fixes_at(db, sid, fid, _at(day, 20, 30))["value"] == {"oil": 3.1}
    assert c.post(f"/admin/sources/{sid}/fix", data={"csrf_token": tok, "form_id": fid, "at": f"{day} 20:30:00", "item_key": "oil",
                                                    "act": "clear", **q}).status_code in (302, 303)
    assert c.post(f"/admin/sources/{sid}/fill-range", data={"csrf_token": tok, **q}).status_code in (302, 303)
    sub = db.execute("SELECT id FROM cs_submissions WHERE source='auto' ORDER BY id DESC LIMIT 1").fetchone()[0]
    det = c.get(f"/submissions/{sub}").get_data(as_text=True)
    assert "ค่าอัตโนมัติจาก SCADA" in det and "ยกเลิกค่า" in det
    assert "ยกเลิกค่า" in c.get("/approvals?src=auto").get_data(as_text=True)
    r = c.post("/approvals/auto-void", data={"csrf_token": tok, "sub_id": sub, "reason": "ทดสอบยกเลิก"})
    assert r.status_code in (302, 303)
    assert not db.execute("SELECT 1 FROM cs_submissions WHERE id=?", (sub,)).fetchone()


def test_energy_audit_void_fix(app, db, client, tmp_path):
    import json
    from datetime import datetime, time

    from ecs import energy as EN
    from ecs import energy_src as ES
    f1 = app.config["F1"]
    day = _day()
    path = str(tmp_path / "e.db")
    rows = [("KWH1", ts(datetime.combine(day - timedelta(days=d), time(h, m))), 1000 + d + h) for d in range(3) for h in (7, 8, 9) for m in (0, 30)]
    _hist(path, rows)
    sid = ES.save_source(db, {"name": "E", "kind": "sqlite", "active": "1",
                              "config": json.dumps({"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                                    "backfill_days": 1})}, None)
    mid = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "K1", "name": "K1", "scada_source_id": str(sid),
                                   "scada_tag": "KWH1"}, None)
    ES.run_source(db, sid, now=_at(day, 23))
    assert db.execute("SELECT COUNT(*) FROM en_readings WHERE meter_id=?", (mid,)).fetchone()[0] == 3     # วันก่อนหน้าเติมเอง
    db.execute("DELETE FROM en_readings WHERE meter_id=? AND day<?", (mid, day.isoformat()))
    rep = ES.audit(db, sid, day - timedelta(days=2), day, now=_at(day, 23))
    assert rep["count"]["missing"] == 2 and rep["issues"]
    assert ES.fill_range(db, ES.get_source(db, sid), day - timedelta(days=2), day, now=_at(day, 23))["readings"] == 2
    admin = uid(db, "t_admin")
    ES.void_day(db, mid, day, "SCADA ค้าง", admin)
    ES.run_source(db, sid, now=_at(day, 23, 20))
    assert not db.execute("SELECT 1 FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
    assert ES.audit(db, sid, day, day, now=_at(day, 23, 20))["count"]["void"] == 1
    assert ES.restore_day(db, ES.get_source(db, sid), mid, day, admin) == 1
    db.commit()
    tok = login(client, "t_admin")
    q = {"from": (day - timedelta(days=2)).isoformat(), "to": day.isoformat()}
    assert "ตรวจสอบ / แก้ไขค่าอ่านจาก SCADA" in client.get(f"/energy/sources/{sid}/audit", query_string=q).get_data(as_text=True)
    assert client.get(f"/energy/sources/{sid}/audit.xlsx", query_string=q).status_code == 200
    r = client.post(f"/energy/sources/{sid}/fix", data={"csrf_token": tok, "meter_id": mid, "day": day.isoformat(), "act": "value",
                                                       "value": "1500", "reason": "อ่านหน้าปัดจริง", **q})
    assert r.status_code in (302, 303)
    assert db.execute("SELECT value, src FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()[1] == "fix"
    assert client.post(f"/energy/sources/{sid}/fill-range", data={"csrf_token": tok, **q}).status_code in (302, 303)
