"""ทดสอบกฎธุรกิจ: การตัดสินผล, การตรวจหัวข้อ, เวอร์ชัน, รอบตรวจ"""
from datetime import date, datetime, timedelta

import pytest

from ecs import services as S
from ecs.schema import ensure_schema


@pytest.fixture()
def cdb(db):
    ensure_schema(db)
    return db


def _num_item(**kw):
    base = {"name": "Oil Pressure", "item_type": "number", "unit": "bar", "min_value": 1.7, "max_value": 2.5,
            "warn_low": None, "warn_high": None, "counter_max_step": None, "options_json": ""}
    base.update(kw)
    return base


# ── evaluate ──
@pytest.mark.parametrize("value,expected", [("2.0", "ok"), ("1.6", "ng"), ("2.6", "ng"), ("1.7", "ok"), ("2.5", "ok"), ("", "na")])
def test_number_limits(value, expected):
    assert S.evaluate(_num_item(), value)["judgement"] == expected


def test_number_warn_band():
    item = _num_item(warn_low=1.8, warn_high=2.4)
    assert S.evaluate(item, "1.75")["judgement"] == "warn"
    assert S.evaluate(item, "2.45")["judgement"] == "warn"
    assert S.evaluate(item, "2.0")["judgement"] == "ok"


def test_number_rejects_text():
    with pytest.raises(S.ValidationError):
        S.evaluate(_num_item(), "abc")


def test_counter_rules():
    item = _num_item(item_type="counter", min_value=None, max_value=None, counter_max_step=24)
    assert S.evaluate(item, "1000", prev_value=990)["judgement"] == "ok"
    assert S.evaluate(item, "980", prev_value=990)["judgement"] == "ng"      # มิเตอร์ถอยหลัง
    assert S.evaluate(item, "1030", prev_value=990)["judgement"] == "warn"   # เพิ่มเกิน 24
    assert S.evaluate(item, "5", prev_value=None)["judgement"] == "ok"       # ครั้งแรก


def test_ok_ng_and_legacy_ox():
    item = {"name": "เสียงผิดปกติ", "item_type": "ok_ng"}
    assert S.evaluate(item, "O")["judgement"] == "ok"
    assert S.evaluate(item, "X")["judgement"] == "ng"
    assert S.evaluate(item, "NG")["value_text"] == "NG"
    with pytest.raises(S.ValidationError):
        S.evaluate(item, "maybe")


def test_choice():
    item = S.normalize_item({"name": "สีน้ำ", "item_type": "choice",
                             "options": [{"label": "ใส", "ng": 0}, {"label": "ขุ่น", "ng": 1}]})
    assert S.evaluate(item, "ใส")["judgement"] == "ok"
    assert S.evaluate(item, "ขุ่น")["judgement"] == "ng"
    with pytest.raises(S.ValidationError):
        S.evaluate(item, "ไม่มี")


# ── normalize_item ──
def test_normalize_rejects_bad_ranges():
    with pytest.raises(S.ValidationError) as e:
        S.normalize_item({"name": "x", "item_type": "number", "min_value": 5, "max_value": 1})
    assert "Min ต้องไม่มากกว่า Max" in str(e.value)
    with pytest.raises(S.ValidationError):
        S.normalize_item({"name": "x", "item_type": "number", "min_value": 1, "max_value": 5, "warn_high": 6})
    with pytest.raises(S.ValidationError):
        S.normalize_item({"name": "", "item_type": "ok_ng"})
    with pytest.raises(S.ValidationError):
        S.normalize_item({"name": "x", "item_type": "choice", "options": [{"label": "a"}]})
    with pytest.raises(S.ValidationError):
        S.normalize_item({"name": "x", "item_type": "number", "min_value": "abc"})


def test_normalize_clears_limits_for_ok_ng():
    it = S.normalize_item({"name": "x", "item_type": "ok_ng", "min_value": 1, "unit": "bar"})
    assert it["min_value"] is None and it["unit"] == ""
    assert it["item_key"].startswith("k")


# ── versions ──
def _make_published(cdb, items):
    fid = S.create_form(cdb, {"name": "ทดสอบ", "factory_id": 1}, None)
    draft = S.get_draft(cdb, fid)
    S.save_draft_items(cdb, draft["id"], items, None)
    S.publish_version(cdb, draft["id"], None, "v1")
    cdb.commit()
    return fid, draft["id"]


def test_versioning_keeps_old_version_intact(cdb):
    fid, v1 = _make_published(cdb, [_num_item(), {"name": "เสียง", "item_type": "ok_ng"}])
    v1_items = S.get_items(cdb, v1)
    draft = S.get_or_create_draft(cdb, fid, None)
    assert draft["version_no"] == 2
    items = S.get_items(cdb, draft["id"])
    assert [i["item_key"] for i in items] == [i["item_key"] for i in v1_items]  # คัดลอก key เดิม
    items[0]["max_value"] = 3.0
    S.save_draft_items(cdb, draft["id"], items + [{"name": "ใหม่", "item_type": "ok_ng"}], None)
    S.publish_version(cdb, draft["id"], None, "ปรับเกณฑ์")
    cdb.commit()
    assert S.get_version(cdb, v1)["status"] == "retired"
    assert S.get_form(cdb, fid)["current_version_id"] == draft["id"]
    assert S.get_items(cdb, v1)[0]["max_value"] == 2.5          # เวอร์ชันเก่าไม่เปลี่ยน
    assert len(S.get_items(cdb, draft["id"])) == 3
    with pytest.raises(S.ValidationError):                         # แก้เวอร์ชันที่ Publish แล้วไม่ได้
        S.save_draft_items(cdb, v1, [_num_item()], None)


def test_publish_requires_items(cdb):
    fid = S.create_form(cdb, {"name": "ว่าง"}, None)
    with pytest.raises(S.ValidationError):
        S.publish_version(cdb, S.get_draft(cdb, fid)["id"], None)


def test_discard_draft(cdb):
    fid, v1 = _make_published(cdb, [_num_item()])
    S.get_or_create_draft(cdb, fid, None)
    S.discard_draft(cdb, fid, None)
    assert S.get_draft(cdb, fid) is None
    assert S.get_form(cdb, fid)["current_version_id"] == v1


def test_duplicate_item_keys_rejected(cdb):
    fid = S.create_form(cdb, {"name": "x"}, None)
    with pytest.raises(S.ValidationError):
        S.save_draft_items(cdb, S.get_draft(cdb, fid)["id"],
                           [{"name": "a", "item_key": "k1"}, {"name": "b", "item_key": "k1"}], None)


# ── schedules & rounds ──
def test_occurrences():
    base = {"skip_holidays": 0, "weekdays": "", "month_day": None}
    wed = date(2026, 9, 23)
    assert len(S.occurrences({**base, "freq_type": "daily", "times": "08:00"}, wed, wed + timedelta(days=6))) == 7
    assert len(S.occurrences({**base, "freq_type": "shift", "times": "08:00,20:00"}, wed, wed)) == 2
    weekly = S.occurrences({**base, "freq_type": "weekly", "times": "08:00", "weekdays": "0,3"}, wed, wed + timedelta(days=13))
    assert [d.weekday() for d in weekly] == [3, 0, 3, 0]
    monthly = S.occurrences({**base, "freq_type": "monthly", "times": "08:00", "month_day": 1}, date(2026, 9, 1), date(2026, 11, 30))
    assert [d.month for d in monthly] == [9, 10, 11]
    hol = S.occurrences({**base, "freq_type": "daily", "times": "08:00", "skip_holidays": 1}, wed, wed, {wed})
    assert hol == []


def test_schedule_validation():
    with pytest.raises(S.ValidationError):
        S.normalize_schedule({"freq_type": "daily", "times": "25:00"})
    with pytest.raises(S.ValidationError):
        S.normalize_schedule({"freq_type": "weekly", "times": "08:00", "weekdays": ""})
    with pytest.raises(S.ValidationError):
        S.normalize_schedule({"freq_type": "monthly", "times": "08:00", "month_day": 31})
    s = S.normalize_schedule({"freq_type": "shift", "times": "20:00, 08:00"})
    assert s["times"] == "08:00,20:00"


def test_round_lifecycle(cdb):
    fid, _ = _make_published(cdb, [_num_item()])
    S.create_schedule(cdb, fid, {"freq_type": "daily", "times": "08:00", "window_min": 120}, None)
    t0 = datetime(2026, 9, 23, 6, 0)
    cdb.execute("INSERT OR REPLACE INTO cs_meta(key,value) VALUES('rounds_start', ?)", (S.ts(t0),))
    created = S.generate_rounds(cdb, now=t0, horizon_days=1)
    assert created == 2                                   # วันนี้ + พรุ่งนี้ (เมื่อวานอยู่ก่อน rounds_start)
    assert S.generate_rounds(cdb, now=t0, horizon_days=1) == 0   # ไม่สร้างซ้ำ
    r = cdb.execute("SELECT * FROM cs_rounds WHERE form_id=? ORDER BY due_at", (fid,)).fetchone()
    assert r["deadline_at"] == "2026-09-23 10:00:00" and r["close_at"] == "2026-09-24 08:00:00"
    S.refresh_round_statuses(cdb, now=datetime(2026, 9, 23, 9, 0))
    assert cdb.execute("SELECT status FROM cs_rounds WHERE id=?", (r["id"],)).fetchone()[0] == "pending"
    S.refresh_round_statuses(cdb, now=datetime(2026, 9, 23, 10, 30))
    assert cdb.execute("SELECT status FROM cs_rounds WHERE id=?", (r["id"],)).fetchone()[0] == "overdue"
    S.refresh_round_statuses(cdb, now=datetime(2026, 9, 24, 8, 0))
    assert cdb.execute("SELECT status FROM cs_rounds WHERE id=?", (r["id"],)).fetchone()[0] == "missed"
    assert S.round_status_for_submission(dict(r), datetime(2026, 9, 23, 9, 59)) == "done_on_time"
    assert S.round_status_for_submission(dict(r), datetime(2026, 9, 23, 10, 1)) == "done_late"


def test_schedule_change_rebuilds_future_rounds(cdb):
    fid, _ = _make_published(cdb, [_num_item()])
    sid = S.create_schedule(cdb, fid, {"freq_type": "daily", "times": "08:00"}, None)
    cdb.execute("INSERT OR REPLACE INTO cs_meta(key,value) VALUES('rounds_start', ?)", (S.ts(datetime.now()),))
    S.generate_rounds(cdb, horizon_days=2)
    S.update_schedule(cdb, sid, {"times": "09:30"}, None)
    S.generate_rounds(cdb, horizon_days=2)
    future = cdb.execute("SELECT due_at FROM cs_rounds WHERE schedule_id=? AND due_at > ?",
                         (sid, S.ts())).fetchall()
    assert future and all(r[0].endswith("09:30:00") for r in future)


def test_inactive_form_gets_no_rounds(cdb):
    fid, _ = _make_published(cdb, [_num_item()])
    S.create_schedule(cdb, fid, {"freq_type": "daily", "times": "08:00"}, None)
    S.update_form_meta(cdb, fid, {"active": 0}, None)
    cdb.execute("INSERT OR REPLACE INTO cs_meta(key,value) VALUES('rounds_start', ?)", (S.ts(datetime.now()),))
    S.generate_rounds(cdb, horizon_days=2)
    assert cdb.execute("SELECT COUNT(*) FROM cs_rounds WHERE form_id=?", (fid,)).fetchone()[0] == 0
