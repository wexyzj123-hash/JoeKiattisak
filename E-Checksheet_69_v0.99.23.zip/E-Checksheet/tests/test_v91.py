"""v0.91: ไฟฟ้า — TOU · Peak Demand · นอกเวลาผลิต · kWh/หน่วยผลิตรายไลน์ · บิล vs มิเตอร์ · PF จาก SCADA · โครงสร้าง/CT"""
import json
from datetime import date, datetime, time, timedelta

import pytest

from conftest import login
from ecs import energy as EN
from ecs import energy_interval as EI
from ecs import energy_power as PW
from ecs import energy_src as ES
from ecs import services as S
from ecs.services import ts

ACTUAL_DAY = True
SPLIT_GAP = True
M0 = date(2026, 9, 1)            # อังคาร


def _mk(db, fid, code, grp="", role=0, line="", mult="1"):
    return EN.save_meter(db, None, {"factory_id": fid, "kind": "elec", "code": code, "name": f"M {code}", "grp": grp, "line": line,
                                    "is_main": str(role), "multiplier": mult}, None)


def _load(db, mid, kw_fn, days=30):
    """ค่าต่อช่วง 15 นาที (ts = เวลาสิ้นสุดช่วง) + ค่าอ่านรายวันจากผลสะสม"""
    EI.ensure(db)
    run = 0.0
    EN.set_reading(db, mid, M0.isoformat(), 0.0, None, src="scada")
    for i in range(days * 96):
        st = datetime.combine(M0, time(0, 0)) + timedelta(minutes=15 * i)
        v = kw_fn(st) / 4
        db.execute("INSERT OR REPLACE INTO en_intervals(meter_id, ts, value) VALUES (?,?,?)", (mid, ts(st + timedelta(minutes=15)), v))
        run += v
        if (st + timedelta(minutes=15)).time() == time(0, 0):
            EN.set_reading(db, mid, (st + timedelta(minutes=15)).date().isoformat(), run, None, src="scada")


def _kw_a(t):          # ไลน์ผลิต: 100 kW ช่วง 08–17 วันทำงาน (จ–ส) · นอกเวลา 10 kW · พีค 300 kW 10:00–10:15 วันที่ 15
    if t.date() == date(2026, 9, 15) and t.hour == 10 and t.minute == 0:
        return 300.0
    work = t.weekday() < 6 and 8 <= t.hour < 17
    return 100.0 if work else 10.0


def _kw_b(t):          # ปั๊ม: 20 kW ตลอดเวลา
    return 20.0


def test_tou_demand_offhours(app, db):
    f1 = app.config["F1"]
    a = _mk(db, f1, "A", "Press", line="L1")
    b = _mk(db, f1, "B", "Utility")
    _load(db, a, _kw_a)
    _load(db, b, _kw_b)
    db.commit()
    PW.save_tariff(db, f1, {"demand_target": "250", "ft": "0.2"}, None)
    t = PW.tou(db, f1, M0, today=date(2026, 10, 5))
    assert t["n_int"] == 2 and t["cover"] == 100.0
    total = t["on"] + t["off"]
    assert abs(total - t["daily_kwh"]) <= 2
    assert t["peak_on"] == pytest.approx(300 + 20) and t["peak_on_at"] == datetime(2026, 9, 15, 10, 0)
    assert t["over"] and t["top"][0]["on"]
    # On-Peak: จ–ศ 09–22 · ไลน์ A ทำงาน 08–17 → 09–17 = 8 ชม. × 100 + 17–22 = 5 ชม. × 10 · ปั๊ม 13 ชม. × 20 · 22 วันทำงาน (ก.ย. 2569)
    wd = sum(1 for i in range(30) if (M0 + timedelta(days=i)).weekday() < 5)
    assert t["on"] == pytest.approx(wd * (8 * 100 + 5 * 10 + 13 * 20) + 300 / 4 - 100 / 4, abs=1)
    e = t["est"]
    assert e["demand"] == round(320 * 132.93) and e["total"] > e["pre_vat"] and t["shift"][0]["baht"] > 0
    assert t["profile"]["wd"][10] == pytest.approx(120, abs=15) and t["profile"]["we"][3] == pytest.approx(30, abs=1)
    o = PW.offhours(db, f1, M0, today=date(2026, 10, 5))
    sec = {r["grp"]: r for r in o["secs"]}
    assert sec["Utility"]["pct"] == pytest.approx(100 * (1 - 26 * 9 / 720), abs=0.2) and sec["Press"]["pct"] < 40 and sec["Utility"]["base_kw"] == pytest.approx(20, abs=0.5)
    assert any(r["line"] == "L1" for r in o["lines"]) and sec["Press"]["src"] == "15 นาที"
    al = PW.demand_alerts(db, today=date(2026, 9, 30))
    assert al and al[0]["over"]


def test_intensity_bill_structure(app, db):
    f1 = app.config["F1"]
    main = _mk(db, f1, "MAIN", "Press", 1)
    a = _mk(db, f1, "A", "Press", line="L1")
    b = _mk(db, f1, "B", "Press", line="L2")
    for mid, per in ((main, 1000.0), (a, 0.5), (b, 0.5)):           # a,b หน้าปัดเป็น MWh → ย่อยรวม ≈ 1/1000 ของหลัก
        v = 0.0
        for i in range(31):
            EN.set_reading(db, mid, (M0 + timedelta(days=i)).isoformat(), v, None, src="t")
            v += per
    db.commit()
    st = PW.structure(db, f1, "elec", days=60)
    r = {x["m"]["id"]: x for x in st["rows"]}
    assert r[main]["depth"] == 0 and r[a]["depth"] == 1 and "1,000" in (r[main]["sug"] or "")
    form = {f"role_{x}": "0" for x in (a, b)}
    form.update({f"mult_{a}": "1000", f"mult_{b}": "1000", f"parent_{a}": "", f"parent_{b}": "", f"role_{main}": "1", f"mult_{main}": "1",
                 f"parent_{main}": ""})
    assert PW.save_structure(db, f1, form, None) == 2
    with pytest.raises(S.ValidationError):
        PW.save_structure(db, f1, {f"role_{main}": "1", f"mult_{main}": "0", f"parent_{main}": ""}, None)
    # kWh/หน่วยผลิต
    us = {(u["grp"], u["line"]) for u in PW.units_of(db, f1)}
    assert {("Press", ""), ("Press", "L1"), ("Press", "L2")} <= us and not any(u[0] == "" for u in us)
    PW.save_prod_grid(db, f1, 2026, {"q::Press|L1::9": "1000", "unit::Press|L1": "ชิ้น", "q::Press|::9": "2000"}, None)
    li = {(x["grp"], x["line"]): x for x in PW.intensity(db, f1, 2026, today=date(2026, 10, 20))["rows"]}
    assert li[("Press", "L1")]["kwh"][8] == 15000 and li[("Press", "L1")]["ki"][8] == 15.0
    assert li[("Press", "")]["ki"][8] == 15.0                      # ทั้งหน่วยงาน = มิเตอร์หลัก 30,000 / 2,000
    # บิล vs มิเตอร์
    db.execute("""INSERT INTO en_bills(factory_id, month, kwh, amount, ft, demand, vat, updated_at) VALUES (?,?,?,?,?,?,?,?)""",
               (f1, "2026-09", 33000, 120000, 0, 0, 8400, "x"))
    bc = PW.bill_check(db, 2026, today=date(2026, 10, 20))
    mo = next(f for f in bc["factories"] if f["fid"] == f1)["months"][8]
    assert mo["meter"] == 30000 and mo["diff"] == round(100 * (30000 - 33000) / 33000, 1) and mo["flag"]


def test_pf_params_from_scada(app, db, tmp_path):
    from test_v73 import _hist
    f1 = app.config["F1"]
    now = S.now_dt().replace(second=0, microsecond=0)
    rows = []
    for i in range(8):
        t = now - timedelta(hours=8 - i)
        rows += [("KWH1", ts(t), 1000.0 + 50 * i), ("PF1", ts(t), 92.0 if i % 2 else 0.80), ("KW1", ts(t), 120.0 + i)]
    path = str(tmp_path / "s.db")
    _hist(path, rows)
    sid = ES.save_source(db, {"name": "S", "kind": "sqlite", "active": "1",
                              "config": json.dumps({"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 2})}, None)
    m = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "PM1", "name": "PM1", "scada_source_id": str(sid), "scada_tag": "KWH1"}, None)
    PW.save_param_tags(db, m, {"tag_pf": "PF1", "tag_kw": "KW1", "scale_kw": "1", "tag_kvar": ""}, None)
    assert set(ES.mapped_tags(db, sid)) == {"KWH1", "PF1", "KW1"}
    assert ES.run_source(db, sid, manual=True)["ok"]
    db.commit()
    vals = sorted({r[0] for r in db.execute("SELECT value FROM en_params WHERE meter_id=? AND param='pf'", (m,))})
    assert vals == [0.8, 0.92]                                     # 92 (%) → 0.92
    rep = PW.pf_report(db, f1, now.date() - timedelta(days=2), now.date())
    r = rep["rows"][0]
    assert r["st"]["pf"]["min"] == 0.8 and r["st"]["pf"]["low"] == 50.0 and r["st"]["kw"]["max"] == 127.0
    assert PW.pf_daily(db, m)["pf"]


def test_pages(app, db, client):
    f1 = app.config["F1"]
    a = _mk(db, f1, "A", "Press", line="L1")
    _load(db, a, _kw_a, days=5)
    db.commit()
    tok = login(client, "t_admin")
    for tab in ("tou", "demand", "off", "line", "bill", "pf", "rate"):
        r = client.get("/energy/power", query_string={"tab": tab, "factory": f1, "month": "2026-09", "year": 2026})
        assert r.status_code == 200, tab
    assert "On-Peak" in client.get("/energy/power", query_string={"factory": f1, "month": "2026-09"}).get_data(as_text=True)
    r = client.post("/energy/power/save", data={"csrf_token": tok, "act": "rate", "factory": f1, "on_rate": "4.5", "peak_start": "09:00",
                                                 "peak_end": "22:00", "work_days": "1111100", "tou": "1"})
    assert r.status_code == 302 and PW.tariff(db, f1)["on_rate"] == 4.5 and PW.tariff(db, f1)["work_days"] == "1111100"
    r = client.post("/energy/power/save", data={"csrf_token": tok, "act": "rate", "factory": f1, "work_days": "12"})
    assert PW.tariff(db, f1)["work_days"] == "1111100"
    assert client.get("/energy/structure", query_string={"factory": f1}).status_code == 200
    assert client.get("/energy/power.xlsx", query_string={"factory": f1, "month": "2026-09"}).data[:2] == b"PK"
    page = client.get(f"/energy/meters/{a}").get_data(as_text=True)
    assert "ค่าทางไฟฟ้าจาก SCADA" in page
    r = client.post(f"/energy/meters/{a}/params", data={"csrf_token": tok, "tag_pf": "X_PF", "scale_pf": "1"})
    assert r.status_code == 302 and PW.param_tags(db, a)["pf"]["tag"] == "X_PF"
    login(client, "t_view")
    assert client.post("/energy/power/save", data={"csrf_token": "x", "act": "rate"}).status_code in (302, 400, 403)
