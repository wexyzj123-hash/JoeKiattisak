"""v0.99.17: ป้ายลอยข้อมูลเครื่อง — ชี้รหัสเครื่องตรงไหนก็ได้ (ใช้ข้อมูลเดียวกับแผงดูต่อ)"""
from conftest import login


def test_codes_api_and_script(client, published_form):
    login(client, "t_admin")
    r = client.get("/api/equipment/codes")
    assert r.status_code == 200 and "private" in r.headers["Cache-Control"]
    codes = r.get_json()
    assert codes["SCT0002"] == published_form["equipment_id"]
    d = client.get(f"/api/equipment/{codes['SCT0002']}/drill").get_json()
    assert d["machine"]["code"] == "SCT0002" and "m360" in d["links"]
    html = client.get("/rounds").get_data(as_text=True)
    assert "js/peek.js" in html


def test_codes_api_requires_login(app):
    anon = app.test_client()
    assert anon.get("/api/equipment/codes").status_code in (302, 401)
