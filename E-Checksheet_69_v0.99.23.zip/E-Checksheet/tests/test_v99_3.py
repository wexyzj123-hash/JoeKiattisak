"""v0.99.3: หน้าภาพรวมเลิกใช้ผัง → สถานะรายพื้นที่ (การ์ด + รูปไอคอนแนบได้) + แผงเจาะลึก พื้นที่ › เครื่อง › สรุปเครื่อง"""
import os
import re

from conftest import login, png_bytes, uid

from ecs import analytics as AN
from ecs import masterdata as M


def _area_with_machine(app, db, published_form, name="Compressor Room AR5"):
    aid = M.get_or_create_area(db, app.config["F1"], name)
    db.execute("UPDATE equipment SET area_id=? WHERE id=?", (aid, published_form["equipment_id"]))
    db.commit()
    return aid


def _area(i, name, status, **kw):
    d = {"id": i, "name": name, "factory_id": 1, "factory_name": "Factory 1", "eq_count": 3, "rounds": 4, "done": 2, "done_pct": 50,
         "alerts_open": 0, "alerts_attn": 0, "missed": 0, "overdue": 0, "ng": 0, "down_count": 0, "icon_image": "", "icon_key": "area", "status": status,
         "status_th": {"critical": "เร่งแก้ไข", "warning": "ต้องติดตาม", "good": "ปกติ", "none": "ไม่มีรอบตรวจ"}[status], "reason": ""}
    d.update(kw)
    return d


def _render(app, areas, manage=False, facs=None):
    from datetime import date
    from flask import render_template_string
    with app.test_request_context("/dashboard"):
        return render_template_string('{% from "dash/_macros.html" import area_board with context %}{{ area_board(areas, facs, day, manage) }}',
                                      areas=areas, facs=facs or [{"id": 1, "code": "F1", "name": "Factory 1"}], day=date(2026, 10, 23), manage=manage)


def test_tiles_sorted_by_urgency_with_reasons(app):
    html = _render(app, [_area(1, "Z-good", "good"), _area(2, "B-warn", "warning", alerts_open=1, alerts_attn=1, overdue=1),
                         _area(3, "N-none", "none", rounds=0, done=0, done_pct=None), _area(4, "A-crit", "critical", alerts_open=3, alerts_attn=3, missed=1),
                         _area(5, "C-warn", "warning", alerts_open=4, alerts_attn=4, ng=2, down_count=1)])
    names = re.findall(r'class="ab-tile st-\w+"[^>]*?data-name="([^"]+)"', html, re.S)
    assert names == ["A-crit", "C-warn", "B-warn", "Z-good", "N-none"]
    assert "ขาดตรวจ 1" in html and "เลยกำหนด 1" in html and "NG 2" in html and "แจ้งเตือน 4" in html and "เครื่องหยุด 1" in html
    assert "ไม่พบความผิดปกติ" in html and "ยังไม่กำหนดรอบตรวจ" in html
    assert 'href="/areas/4/map"' in html                                     # Ctrl+คลิก/เปิดแท็บใหม่ = หน้าพื้นที่เดิม


def test_info_alerts_only_do_not_show_warning_tag(app):
    html = _render(app, [_area(1, "Quiet", "good", alerts_open=2, alerts_attn=0)])
    assert "แจ้งเตือน 2" not in html and "ไม่พบความผิดปกติ" in html


def test_icon_image_or_default_icon(app):
    html = _render(app, [_area(1, "Has icon", "good", icon_image="icons/area1_x.png"), _area(2, "Boiler House", "good", icon_key="boiler")])
    assert '<img src="/media/icons/area1_x.png"' in html and 'data-hasicon="1"' in html
    assert html.count('<span class="ab-ico"><svg') == 1                                # พื้นที่ที่ไม่มีรูป → ไอคอนเริ่มต้น
    assert 'class="ab-iconform"' not in html                                 # ผู้ใช้ที่จัดการไม่ได้ ไม่เห็นปุ่มแนบรูป
    assert 'class="ab-iconform"' in _render(app, [_area(1, "A", "good")], manage=True)


def test_icon_key_from_name():
    assert AN.area_icon_key("Compressor Room Kubota") == "compressor"
    assert AN.area_icon_key("ห้องคอมเพรสเซอร์ 2") == "compressor"
    assert AN.area_icon_key("Wastewater treatment system") == "water"
    assert AN.area_icon_key("Electrical System AR5") == "power"
    assert AN.area_icon_key("Cooling Kubota") == "cooling"
    assert AN.area_icon_key("Office") == "area"


def test_dashboard_has_area_board_not_map(client):
    login(client, "t_admin")
    html = client.get("/dashboard").get_data(as_text=True)
    assert 'id="areas"' in html and "js/areas.js" in html and len(re.findall(r'class="ab-chip[ "]', html)) == 5
    assert "pm-canvas" not in html and "pm2" not in html and "plantmap.js" not in html
    assert "สถานะรายพื้นที่" in html and html.count("สถานะรายพื้นที่</h2>") <= 1    # ตารางเดิมรวมเข้าการ์ดแล้ว ไม่ซ้ำ
    assert "/equipment" in html                                               # ลิงก์ "เครื่องจักรทั้งหมด" ยังอยู่


def test_api_area_equipment(app, db, client, published_form):
    aid = _area_with_machine(app, db, published_form)
    login(client, "t_view")
    r = client.get(f"/api/areas/{aid}/equipment?date=2026-10-23", headers={"Accept": "application/json"})
    assert r.status_code == 200
    d = r.get_json()
    assert d["area"]["id"] == aid and d["area"]["map"] == f"/areas/{aid}/map" and d["day"] == "2026-10-23"
    m = d["machines"][0]
    assert m["code"] == "SCT0002" and m["status"] in ("good", "pending", "warning", "critical", "none", "down")
    assert m["links"]["m360"] == f"/machines/{published_form['equipment_id']}" and m["links"]["detail"].startswith("/equipment/")
    assert m["forms"] and m["links"]["form"] == f"/forms/{published_form['form_id']}"
    assert client.get("/api/areas/999999/equipment").status_code == 404
    bad = client.get(f"/api/areas/{aid}/equipment?date=not-a-date").get_json()
    assert bad["day"]                                                         # วันที่ผิดรูป → ใช้วันนี้ ไม่ล้ม


def test_api_requires_login(app, db, published_form):
    aid = _area_with_machine(app, db, published_form)
    r = app.test_client().get(f"/api/areas/{aid}/equipment", headers={"Accept": "application/json"})
    assert r.status_code in (302, 401, 403)


def test_icon_upload_replace_remove(app, db, client, published_form):
    aid = _area_with_machine(app, db, published_form)
    tok = login(client, "t_admin")
    import io
    r = client.post(f"/areas/{aid}/icon", data={"icon": (io.BytesIO(png_bytes()), "i.png"), "csrf_token": tok, "next": "/dashboard#area-%d" % aid},
                    content_type="multipart/form-data")
    assert r.status_code == 302 and r.headers["Location"].endswith(f"/dashboard#area-{aid}")
    rel = db.execute("SELECT icon_image FROM areas WHERE id=?", (aid,)).fetchone()[0]
    assert rel.startswith("icons/") and os.path.exists(os.path.join(app.config["UPLOAD_FOLDER"], rel))
    assert f'/media/{rel}' in client.get("/dashboard").get_data(as_text=True)
    assert client.get(f"/media/{rel}").status_code == 200
    # แทนที่ → ไฟล์เก่าถูกลบ
    client.post(f"/areas/{aid}/icon", data={"icon": (io.BytesIO(png_bytes()), "j.png"), "csrf_token": tok}, content_type="multipart/form-data")
    rel2 = db.execute("SELECT icon_image FROM areas WHERE id=?", (aid,)).fetchone()[0]
    assert rel2 != rel and not os.path.exists(os.path.join(app.config["UPLOAD_FOLDER"], rel))
    # ลบ → กลับไปใช้ไอคอนเริ่มต้น
    client.post(f"/areas/{aid}/icon", data={"action": "remove", "csrf_token": tok})
    assert db.execute("SELECT icon_image FROM areas WHERE id=?", (aid,)).fetchone()[0] == ""
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE entity='area_icon' AND entity_id=?", (aid,)).fetchone()[0] == 3   # แนบ · แทนที่ · ลบ


def test_icon_rejects_non_image_and_svg(app, db, client, published_form):
    aid = _area_with_machine(app, db, published_form)
    tok = login(client, "t_admin")
    import io
    for data, name in ((b"<svg onload=alert(1)>", "x.svg"), (b"not an image", "x.png"), (b"", "e.png")):
        client.post(f"/areas/{aid}/icon", data={"icon": (io.BytesIO(data), name), "csrf_token": tok}, content_type="multipart/form-data")
        assert db.execute("SELECT icon_image FROM areas WHERE id=?", (aid,)).fetchone()[0] == ""


def test_icon_upload_permissions_and_safe_redirect(app, db, client, published_form):
    aid = _area_with_machine(app, db, published_form)
    import io
    tok = login(client, "t_tech")
    r = client.post(f"/areas/{aid}/icon", data={"icon": (io.BytesIO(png_bytes()), "i.png"), "csrf_token": tok}, content_type="multipart/form-data")
    assert r.status_code == 403
    c2 = app.test_client()
    tok2 = login(c2, "t_sup")
    r = c2.post(f"/areas/{aid}/icon", data={"icon": (io.BytesIO(png_bytes()), "i.png"), "csrf_token": tok2, "next": "//evil.example/x"},
                content_type="multipart/form-data")
    assert r.status_code == 302 and "evil.example" not in r.headers["Location"]
    r = c2.post(f"/areas/{aid}/icon", data={"action": "remove"})                 # ไม่มี CSRF → ปฏิเสธ
    assert r.status_code in (400, 403)


def test_v99_4_factory_rows_collapsed_with_summary(app):
    """v0.99.4: แสดงเป็นแถวโรงงาน (ยุบไว้) · สรุปสถานะแย่สุด/จำนวนต่อสถานะ/ความคืบหน้ารวม · กดขยายดูพื้นที่"""
    facs = [{"id": 1, "code": "F1", "name": "Factory 1"}, {"id": 2, "code": "F2", "name": "Factory 2"}, {"id": 9, "code": "F9", "name": "Empty"}]
    areas = [_area(1, "A1", "good", rounds=4, done=4), _area(2, "A2", "critical", rounds=6, done=1, missed=2),
             _area(3, "B1", "good", factory_id=2, factory_name="Factory 2", rounds=2, done=1), _area(4, "B2", "none", factory_id=2, factory_name="Factory 2", rounds=0, done=0)]
    html = _render(app, areas, facs=facs)
    groups = re.findall(r'<div class="ab-fac st-(\w+)" data-facgrp="(\d+)">', html)
    assert groups == [("critical", "1"), ("good", "2")]                    # โรงงานที่ไม่มีพื้นที่ไม่แสดง · สีตามสถานะแย่สุด
    assert html.count('aria-expanded="false"') == 2 and html.count('class="ab-fl" id="abf-') == 2
    assert all(' hidden>' in m for m in re.findall(r'<div class="ab-fl" id="abf-\d+"[^>]*>', html))   # ยุบไว้ก่อน
    f1 = html[html.index('data-facgrp="1"'):html.index('data-facgrp="2"')]
    assert "2 พื้นที่" in f1 and "5/10" in f1 and "--w:50%" in f1 and "เร่งแก้ไข" in f1
    assert 'ab-cn st-critical' in f1 and 'ab-cn st-good' in f1 and 'ab-cn st-warning' not in f1
    f2 = html[html.index('data-facgrp="2"'):]
    assert "1/2" in f2.split('class="ab-fl"')[0] and 'ab-cn st-none' in f2
    # ทุกพื้นที่อยู่ใต้โรงงานของตัวเอง
    assert re.search(r'abf-1".*?data-name="A2".*?data-name="A1".*?abf-2".*?data-name="B1".*?data-name="B2"', html, re.S)
