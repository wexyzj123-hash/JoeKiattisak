"""v0.89: นับการใช้ตามวันที่ใช้จริง — การใช้วัน D = ค่าอ่านถัดไป − ค่าอ่านวัน D · ค่าต่อช่วงตัดยอด 00:00"""
from datetime import date, timedelta

from test_v87 import _setup

from ecs import energy as EN
from ecs import energy_interval as EI
from ecs import energy_src as ES
from ecs import services as S

ACTUAL_DAY = True
D = [date(2026, 9, 1) + timedelta(days=i) for i in range(6)]
iso = lambda d: d.isoformat()


def test_usage_actual_vs_old():
    rows = [(iso(D[0]), 100.0), (iso(D[1]), 150.0), (iso(D[2]), 170.0)]
    new = EN.usage(rows, 1, D[0], D[5], actual=True)
    assert new[iso(D[0])]["u"] == 50 and new[iso(D[1])]["u"] == 20 and iso(D[2]) not in new
    assert new[iso(D[0])]["v"] == 100                              # ค่าอ่านต้นวัน
    old = EN.usage(rows, 1, D[0], D[5], actual=False)
    assert old[iso(D[0])]["flag"] == "first" and old[iso(D[1])]["u"] == 50 and old[iso(D[2])]["u"] == 20


def test_usage_actual_split_and_override():
    rows = [(iso(D[0]), 100.0), (iso(D[3]), 190.0), (iso(D[4]), 200.0)]
    sp = EN.usage(rows, 1, D[0], D[5], split=True, actual=True)
    assert [sp[iso(d)]["u"] for d in D[:4]] == [30, 30, 30, 10]
    assert sp[iso(D[1])]["split"] and not sp[iso(D[3])].get("split")
    lump = EN.usage(rows, 1, D[0], D[5], actual=True)
    assert lump[iso(D[0])]["u"] == 90 and lump[iso(D[0])]["gap"] == 3
    fx = EN.usage([(iso(D[0]), 100.0), (iso(D[1]), 150.0, 40.0)], 1, D[0], D[5], actual=True)
    assert fx[iso(D[0])] ["u"] == 40 and fx[iso(D[0])]["flag"] == "fix"


def test_series_lookahead(app, db):
    f1 = app.config["F1"]
    m = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "X", "name": "X"}, None)
    for d, v in ((D[0], 100), (D[1], 130), (D[2], 180)):
        db.execute("INSERT INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,'manual','2026-09-01 08:00:00')", (m, iso(d), v))
    db.commit()
    s = EN.series(db, [{"id": m, "multiplier": 1}], D[0], D[1])[m]
    assert s[iso(D[0])]["u"] == 30 and s[iso(D[1])]["u"] == 50       # วันสุดท้ายของช่วงใช้ค่าอ่านวันถัดไป (นอกช่วง)
    EN.save_settings(db, {"usage_day": "0"}, None)
    s = EN.series(db, [{"id": m, "multiplier": 1}], D[0], D[1])[m]
    assert s[iso(D[1])]["u"] == 30 and s[iso(D[0])]["u"] is None


def test_interval_calendar_day(app, db, tmp_path):
    sid, a, b, _ = _setup(app, db, tmp_path)
    assert ES.run_source(db, sid, manual=True)["ok"]
    db.commit()
    yd = S.now_dt().date() - timedelta(days=1)
    rd = dict(db.execute("SELECT day, value FROM en_readings WHERE meter_id=? ORDER BY day", (b,)).fetchall())
    assert abs(rd[iso(yd + timedelta(days=1))] - rd[iso(yd)] - 200.0) < 1e-6     # 08:00–18:00 × 5 kWh รวมในวันเดียว
    s = EN.series(db, [{"id": a, "multiplier": 1}, {"id": b, "multiplier": 1}], yd, yd)
    assert s[a][iso(yd)]["u"] == 960 and s[b][iso(yd)]["u"] == 200
    assert db.execute("SELECT value FROM cs_meta WHERE key='en_interval_cut'").fetchone()[0] == "00:00"


def test_switch_rebuilds_once(app, db, tmp_path):
    EN.save_settings(db, {"usage_day": "0", "scada_hh": "8", "scada_mm": "0"}, None)
    sid, a, b, _ = _setup(app, db, tmp_path)
    ES.run_source(db, sid, manual=True)
    db.commit()
    assert db.execute("SELECT value FROM cs_meta WHERE key='en_interval_cut'").fetchone()[0] == "08:00"
    yd = S.now_dt().date() - timedelta(days=1)
    old = EN.series(db, [{"id": b, "multiplier": 1}], yd, yd)[b][iso(yd)]["u"]
    assert old == 200                                              # 08:00→08:00 ก็ได้ 200 แต่ลงวันอ่านค่า
    EN.save_settings(db, {"usage_day": "1"}, None)
    assert EI.ensure_cut(db) > 0 and EI.ensure_cut(db) == 0         # สร้างใหม่ครั้งเดียว
    rd = dict(db.execute("SELECT day, value FROM en_readings WHERE meter_id=? ORDER BY day", (a,)).fetchall())
    assert abs(rd[iso(yd + timedelta(days=1))] - rd[iso(yd)] - 960.0) < 1e-6
    s = EN.series(db, [{"id": b, "multiplier": 1}], yd, yd)[b]
    assert s[iso(yd)]["u"] == 200


def test_settings_page(app, db, client):
    from conftest import csrf_of, login
    login(client, "t_admin")
    page = client.get("/energy/settings").get_data(as_text=True)
    assert "usage_day" in page and "วันที่ใช้จริง" in page


def test_pages_render_actual(app, db, client, tmp_path):
    from conftest import login
    sid, a, b, _ = _setup(app, db, tmp_path)
    ES.run_source(db, sid, manual=True)
    db.commit()
    login(client, "t_admin")
    for url in ("/energy/", f"/energy/meters/{a}", "/energy/summary", "/energy/live/", "/energy/targets"):
        r = client.get(url)
        assert r.status_code == 200, url
    assert "วันที่ใช้จริง" in client.get("/energy/summary").get_data(as_text=True)
