"""v0.10: เส้นทางเดินตรวจ · สแกน QR ยืนยันที่จุดตรวจ · แม่แบบใช้กับหลายเครื่อง · ควบคุมเอกสาร ISO"""
from datetime import date

import pytest
from conftest import GOOD, login, payload, uid

from ecs import formtpl as T
from ecs import masterdata as M
from ecs import points as PT
from ecs import services as S
from ecs import submissions as SUB
from ecs import walkroutes as R

ITEMS = [
    {"item_key": "t1", "section": "TANK", "name": "ถังไม่รั่ว", "item_type": "ok_ng"},
    {"item_key": "p1", "section": "PUMP", "name": "Pressure", "item_type": "number", "unit": "bar", "min_value": 3, "max_value": 5},
]


def _eq(app, db, code):
    return M.save_equipment(db, {"code": code, "name": f"Machine {code}", "factory_id": app.config["F1"],
                                 "eq_type": "Compressor"}, uid(db, "t_admin"))


def _form(app, db, code="AC-01", items=ITEMS, **meta):
    admin = uid(db, "t_admin")
    fid = S.create_form(db, {"name": f"Daily {code}", "equipment_id": _eq(app, db, code)}, admin)
    d = S.get_draft(db, fid)
    S.save_draft_items(db, d["id"], items, admin)
    S.publish_version(db, d["id"], admin, **meta)
    db.commit()
    return fid


def _submit(app, db, fid, answers, **kw):
    f = S.get_form(db, fid)
    p = payload({"form_id": fid, "version_id": f["current_version_id"]}, answers, **kw)
    res = SUB.create_submission(db, p, {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    return res


# ───────── ISO ─────────

def test_iso_doc_control(app, db):
    fid = _form(app, db, effective_date="2026-10-01", approved_by_name="ผจก. ทดสอบ")
    S.update_form_meta(db, fid, {"doc_no": "FM-UT-012"}, uid(db, "t_admin"))
    db.commit()
    assert S.rev_label(1) == "Rev.00" and S.rev_label(3) == "Rev.02"
    v = S.list_versions(db, fid)[0]
    assert v["effective_date"] == "2026-10-01" and v["approved_by_name"] == "ผจก. ทดสอบ"
    with pytest.raises(S.ValidationError):
        d = S.get_or_create_draft(db, fid, None)
        S.publish_version(db, d["id"], None, effective_date="01/10/2026")
    db.rollback()
    client = app.test_client()
    login(client, "t_sup")
    body = client.get(f"/forms/{fid}").get_data(as_text=True)
    assert "FM-UT-012" in body and "Rev.00" in body and "ผจก. ทดสอบ" in body
    _submit(app, db, fid, {"t1": {"value": "OK"}, "p1": {"value": "4"}})
    body = client.get(f"/reports/sheets?form={fid}&month={date.today():%Y-%m}").get_data(as_text=True)
    assert "FM-UT-012" in body and "Rev.00" in body and "เลขที่บันทึก" in body


def test_publish_api_takes_effective_date(app, db):
    fid = _form(app, db)
    client = app.test_client()
    tok = login(client, "t_sup")
    d = client.get(f"/api/forms/{fid}/draft").get_json()
    client.put(f"/api/forms/{fid}/draft", json={"items": d["items"]}, headers={"X-CSRF-Token": tok})
    r = client.post(f"/api/forms/{fid}/publish", json={"note": "ปรับเกณฑ์", "effective_date": "2026-11-01",
                                                         "approved_by_name": "หัวหน้า"}, headers={"X-CSRF-Token": tok})
    assert r.status_code == 200
    v = S.list_versions(db, fid)[0]
    assert v["version_no"] == 2 and v["effective_date"] == "2026-11-01" and S.rev_label(v["version_no"]) == "Rev.01"


# ───────── สแกน QR ที่จุดตรวจ ─────────

def test_point_scan_required(app, db):
    fid = _form(app, db)
    S.update_form_meta(db, fid, {"require_point_scan": 1}, uid(db, "t_admin"))
    db.commit()
    with app.test_request_context():
        tank, pump = PT.point_code(fid, "TANK"), PT.point_code(fid, "PUMP")
        pkg = SUB.form_package(db, fid)
    assert len(tank) == 6 and tank != pump
    assert pkg["form"]["require_point_scan"] == 1
    assert pkg["sections"][0]["code_sha"] == PT.code_hash(tank) and "code" not in pkg["sections"][0]
    ans = {"t1": {"value": "OK"}, "p1": {"value": "4"}}
    with app.test_request_context():
        with pytest.raises(S.ValidationError) as exc:
            _submit(app, db, fid, ans, point_scans=[{"section": "TANK", "code": tank}])
        assert any("PUMP" in e for e in exc.value.errors)
        with pytest.raises(S.ValidationError):
            _submit(app, db, fid, ans, point_scans=[{"section": "TANK", "code": tank}, {"section": "PUMP", "code": tank}])
        res = _submit(app, db, fid, ans, point_scans=[{"section": "TANK", "code": tank.lower()},
                                                      {"section": "PUMP", "code": f"http://x/echeck/p/{fid}/{pump}"}])
    row = db.execute("SELECT point_scans FROM cs_submissions WHERE id=?", (res["id"],)).fetchone()[0]
    assert [x["section"] for x in PT.loads(row)] == ["TANK", "PUMP"]
    # รหัสต่างกันระหว่างเครื่อง (แม้ชื่อจุดเหมือนกัน)
    fid2 = _form(app, db, "AC-02")
    with app.test_request_context():
        assert PT.point_code(fid2, "TANK") != tank
    client = app.test_client()
    login(client, "t_sup")
    page = client.get(f"/forms/{fid}/point-labels", follow_redirects=True).get_data(as_text=True)
    assert tank in page and pump in page and f"/p/{fid}/{tank}" in page
    login(c := app.test_client(), "t_tech")
    r = c.get(f"/p/{fid}/{tank}")
    assert r.status_code == 302 and f"#f={fid}&pt={tank}" in r.headers["Location"]
    body = client.get(f"/submissions/{res['id']}/record").get_data(as_text=True)
    assert "ยืนยันที่จุดตรวจ" in body


# ───────── แม่แบบ ─────────

def test_template_apply_sync_overrides(app, db):
    admin = uid(db, "t_admin")
    src = _form(app, db, "AC-01")
    tpl = T.make_template(db, src, admin)
    db.commit()
    t = S.get_form(db, tpl)
    assert t["is_template"] == 1 and t["name"] == "Daily" and S.get_form(db, src)["template_id"] == tpl
    eqs = [_eq(app, db, "AC-02"), _eq(app, db, "AC-03")]
    res = T.apply_to_equipment(db, tpl, eqs + eqs, admin, {"freq_type": "daily", "times": "08:00"})
    db.commit()
    assert res["created"] == ["AC-02", "AC-03"]
    kids = T.children(db, tpl)
    assert len(kids) == 3 and all(k["schedule_count"] for k in kids if k["eq_code"] != "AC-01")
    child = next(k for k in kids if k["eq_code"] == "AC-02")["id"]
    # เกณฑ์เฉพาะเครื่อง
    T.save_overrides(db, child, {"p1": {"use": "1", "min_value": "6", "max_value": "8"}}, admin)
    db.commit()
    it = {i["item_key"]: i for i in S.get_items(db, S.get_form(db, child)["current_version_id"])}
    assert (it["p1"]["min_value"], it["p1"]["max_value"]) == (6, 8)
    with pytest.raises(S.ValidationError):
        T.save_overrides(db, child, {"p1": {"use": "1", "min_value": "9", "max_value": "8"}}, admin)
    db.rollback()
    # แก้แม่แบบ → ทุกเครื่องได้เวอร์ชันใหม่ (เกณฑ์เฉพาะเครื่องยังอยู่)
    client = app.test_client()
    tok = login(client, "t_sup")
    d = client.get(f"/api/forms/{tpl}/draft").get_json()
    items = d["items"] + [{"name": "เสียงผิดปกติ", "item_type": "ok_ng", "section": "PUMP"}]
    assert client.put(f"/api/forms/{tpl}/draft", json={"items": items}, headers={"X-CSRF-Token": tok}).status_code == 200
    r = client.post(f"/api/forms/{tpl}/publish", json={"note": "เพิ่มหัวข้อเสียง"}, headers={"X-CSRF-Token": tok})
    assert r.get_json()["synced"] == 3
    for k in T.children(db, tpl):
        names = [i["name"] for i in S.get_items(db, S.get_form(db, k["id"])["current_version_id"])]
        assert "เสียงผิดปกติ" in names
    it = {i["item_key"]: i for i in S.get_items(db, S.get_form(db, child)["current_version_id"])}
    assert it["p1"]["min_value"] == 6
    # แบบฟอร์มลูกแก้หัวข้อเองไม่ได้
    assert client.get(f"/forms/{child}/builder").status_code == 302
    assert client.put(f"/api/forms/{child}/draft", json={"items": []}, headers={"X-CSRF-Token": tok}).status_code == 409
    # หน้าแม่แบบ/ลูก
    assert "AC-03" in client.get(f"/forms/{tpl}").get_data(as_text=True)
    assert "เกณฑ์เฉพาะเครื่องนี้" in client.get(f"/forms/{child}").get_data(as_text=True)
    assert "แม่แบบ" in client.get("/forms?bind=tpl").get_data(as_text=True)
    # แยกออก
    T.detach(db, child, admin)
    db.commit()
    assert S.get_form(db, child)["template_id"] is None


def test_link_existing_form_keeps_history_keys(app, db):
    admin = uid(db, "t_admin")
    tpl = T.new_template(db, {"name": "Compressor"}, admin)
    d = S.get_draft(db, tpl)
    S.save_draft_items(db, d["id"], [{"item_key": "tk", "name": "Pressure", "item_type": "number", "min_value": 3, "max_value": 5},
                                     {"item_key": "tn", "name": "Noise", "item_type": "ok_ng"}], admin)
    S.publish_version(db, d["id"], admin)
    old = _form(app, db, "AC-09", [{"item_key": "oldkey", "name": "pressure", "item_type": "number", "min_value": 2, "max_value": 4}])
    _submit(app, db, old, {"oldkey": {"value": "3"}})
    T.link_forms(db, tpl, [old], admin)
    db.commit()
    items = {i["name"]: i for i in S.get_items(db, S.get_form(db, old)["current_version_id"])}
    assert items["Pressure"]["item_key"] == "oldkey"                    # ใช้รหัสเดิม → กราฟต่อเนื่อง
    assert (items["Pressure"]["min_value"], items["Pressure"]["max_value"]) == (2, 4)   # เก็บเกณฑ์เดิมของเครื่อง
    assert items["Noise"]["item_key"] == "tn"


# ───────── เส้นทางเดินตรวจ ─────────

def test_routes(app, db):
    a, b = _form(app, db, "R-01"), _form(app, db, "R-02")
    rid = R.save_route(db, {"name": "ห้อง Compressor", "factory_id": app.config["F1"]}, [b, a, b], uid(db, "t_admin"))
    db.commit()
    r = R.get_route(db, rid)
    assert [s["form_id"] for s in r["stops"]] == [b, a]
    st = R.route_status(db, rid)
    assert st["total"] == 2 and st["done"] == 0 and st["next_form_id"] == b
    _submit(app, db, b, {"t1": {"value": "OK"}, "p1": {"value": "4"}}, route_id=rid)
    st = R.route_status(db, rid)
    assert st["done"] == 1 and st["next_form_id"] == a
    assert db.execute("SELECT route_id FROM cs_submissions WHERE form_id=?", (b,)).fetchone()[0] == rid
    client = app.test_client()
    login(client, "t_tech")
    d = client.get("/api/m/routes").get_json()
    assert d["routes"][0]["done"] == 1 and d["routes"][0]["total"] == 2
    assert client.get(f"/api/m/routes/{rid}").get_json()["next_form_id"] == a
    assert client.get("/m/route").status_code == 200
    c2 = app.test_client()
    tok = login(c2, "t_sup")
    assert "ห้อง Compressor" in c2.get("/routes").get_data(as_text=True)
    r = c2.post(f"/routes/{rid}", data={"name": "ห้อง Compressor เช้า", "stops": [a, b], "csrf_token": tok, "active": "1"})
    assert r.status_code == 302
    assert [s["form_id"] for s in R.get_route(db, rid)["stops"]] == [a, b]
    c2.post(f"/routes/{rid}/delete", data={"csrf_token": tok})
    assert R.get_route(db, rid) is None
    with pytest.raises(S.ValidationError):
        R.save_route(db, {"name": "x"}, [], None)
