"""v0.12: กราฟแนวโน้ม 5 ครั้งล่าสุดข้างช่องกรอก (history ในแพ็กเกจมือถือ)"""
from conftest import GOOD, payload, uid

from ecs import submissions as SUB


def _submit(app, db, form, oil, hour, finished):
    ans = dict(GOOD, oil={"value": oil}, hour={"value": str(hour)})
    if oil == "":
        ans.pop("oil")
    p = payload(form, ans, started_at=finished, finished_at=finished)
    SUB.create_submission(db, p, {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()


def test_package_history_last5_oldest_first(app, db, published_form):
    f = published_form
    vals = ["2.3", "2.25", "2.2", "2.1", "2.0", "1.9", "1.85"]
    for i, v in enumerate(vals):
        _submit(app, db, f, v, 1000 + i * 10, f"2026-09-{10 + i:02d} 08:00:00")
    pkg = SUB.form_package(db, f["form_id"])
    h = pkg["history"]["oil"]
    assert [x["v"] for x in h] == [2.2, 2.1, 2.0, 1.9, 1.85]
    assert [x["at"] for x in h] == sorted(x["at"] for x in h)
    assert all(x["j"] in ("ok", "warn", "ng") for x in h)
    # เฉพาะหัวข้อตัวเลข (มิเตอร์สะสม / OK-NG ไม่มีกราฟ)
    assert set(pkg["history"]) == {"oil"}


def test_history_ignores_returned_and_empty(app, db, published_form):
    f = published_form
    _submit(app, db, f, "2.2", 1000, "2026-09-10 08:00:00")
    _submit(app, db, f, "2.1", 1010, "2026-09-11 08:00:00")
    db.execute("UPDATE cs_submissions SET status='returned' WHERE id=(SELECT MAX(id) FROM cs_submissions)")
    db.commit()
    h = SUB.form_package(db, f["form_id"])["history"]["oil"]
    assert [x["v"] for x in h] == [2.2]
    assert SUB.recent_values(db, f["form_id"], []) == {}


def test_fill_js_has_sparkline():
    import pathlib
    js = (pathlib.Path(__file__).parents[1] / "ecs/static/m/fill.js").read_text(encoding="utf-8")
    assert "function sparkSvg" in js and "function trendOf" in js and "pkg.history" in js
