"""v0.52: สิทธิ์แก้ไขแบบฟอร์มที่ผู้ดูแลระบบอนุญาต (สิ่งแวดล้อม / เซฟตี้) · ตารางสิทธิ์ · ดูหน้าจอแทนผู้ใช้ (อ่านอย่างเดียว)"""
from conftest import login, uid

from ecs import perms as PM
from ecs import services as S


def _draft_items(client, fid, tok):
    d = client.get(f"/api/forms/{fid}/draft").get_json()
    items = d["items"]
    items[0]["name"] = items[0]["name"] + " (แก้)"
    return client.put(f"/api/forms/{fid}/draft", json={"items": items, "version_id": d["version_id"]},
                      headers={"X-CSRF-Token": tok})


def test_form_grant_edit_publish_schedule(app, client, db, published_form):
    fid = published_form["form_id"]
    tech, admin = uid(db, "t_tech"), uid(db, "t_admin")
    tok = login(client, "t_tech")
    assert client.get(f"/forms/{fid}/builder").status_code == 403
    PM.add_grant(db, {"user_id": tech, "scope": "form", "form_id": fid}, admin)
    db.commit()
    assert client.get(f"/forms/{fid}/builder").status_code == 200
    assert "ผู้ดูแลระบบเป็นผู้ Publish" in client.get(f"/forms/{fid}/builder").get_data(as_text=True)
    res = _draft_items(client, fid, tok)
    assert res.status_code == 200, res.get_json()
    n = db.execute("SELECT COUNT(*) FROM cs_notifications WHERE user_id=? AND kind='form_draft'", (admin,)).fetchone()[0]
    assert n == 1                                                          # แจ้งผู้ดูแลให้ Publish
    assert client.post(f"/api/forms/{fid}/publish", json={}, headers={"X-CSRF-Token": tok}).status_code == 403
    r = client.post(f"/forms/{fid}/schedules", data={"csrf_token": tok, "freq_type": "daily", "times": "09:00"})
    assert r.status_code == 403
    # ให้สิทธิ์ Publish + รอบตรวจ (ให้ซ้ำ = อัปเดตระดับสิทธิ์)
    PM.add_grant(db, {"user_id": tech, "scope": "form", "form_id": fid, "can_publish": "1", "can_schedule": "1"}, admin)
    db.commit()
    assert len(PM.list_grants(db)) == 1
    pub = client.post(f"/api/forms/{fid}/publish", json={"note": "แก้ชื่อหัวข้อ"}, headers={"X-CSRF-Token": tok})
    assert pub.status_code == 200 and pub.get_json()["success"]
    r = client.post(f"/forms/{fid}/schedules", data={"csrf_token": tok, "freq_type": "daily", "times": "09:00", "window_min": "240"})
    assert r.status_code == 302
    sid = db.execute("SELECT id FROM cs_schedules WHERE form_id=? ORDER BY id DESC", (fid,)).fetchone()[0]
    r = client.post(f"/schedules/{sid}/delete", data={"csrf_token": tok})
    assert r.status_code == 302
    detail = client.get(f"/forms/{fid}").get_data(as_text=True)
    assert "คุณแก้ไขได้" in detail
    # แบบฟอร์มอื่นยังแก้ไม่ได้
    other = S.create_form(db, {"name": "อื่น"}, admin)
    db.commit()
    assert client.get(f"/forms/{other}/builder").status_code == 403
    gid = PM.list_grants(db)[0]["id"]
    PM.remove_grant(db, gid, admin)
    db.commit()
    assert client.get(f"/forms/{fid}/builder").status_code == 403


def test_dept_grant_and_restricted_supervisor(app, db, published_form, monkeypatch):
    fid = published_form["form_id"]
    sup, admin = uid(db, "t_sup"), uid(db, "t_admin")
    assert PM.form_access(db, sup, fid)["publish"]                         # หัวหน้างานปกติ = แก้ได้ทุกแบบฟอร์ม
    db.execute("UPDATE users SET restrict_view=1 WHERE id=?", (sup,))   # บัญชีจำกัดการดู (เช่น ENV)
    db.commit()
    assert not PM.form_access(db, sup, fid)["edit"]
    import ecs.view_scope as VS
    monkeypatch.setattr(VS, "forms_by_dept", lambda _db: {fid: "env"})
    PM.add_grant(db, {"user_id": sup, "scope": "env", "can_publish": "1"}, admin)
    db.commit()
    a = PM.form_access(db, sup, fid)
    assert a["edit"] and a["publish"] and not a["schedule"] and a["via"] == "grant"
    assert PM.editable_form_ids(db, sup) == {fid}
    monkeypatch.setattr(VS, "forms_by_dept", lambda _db: {fid: "safety"})
    assert not PM.form_access(db, sup, fid)["edit"]


def test_permissions_page_and_view_as_readonly(app, client, db):
    tok = login(client, "t_admin")
    html = client.get("/admin/permissions").get_data(as_text=True)
    assert "ตารางสิทธิ์ตามบทบาท" in html and "ดูแทน" in html
    tech = uid(db, "t_tech")
    r = client.post(f"/admin/view-as/{tech}", data={"csrf_token": tok})
    assert r.status_code == 302 and r.headers["Location"].endswith("/m/")
    with client.session_transaction() as s:
        assert s["user_id"] == tech and s["role"] == "technician" and s["view_as"]["orig"]["role"] == "admin"
    page = client.get("/m/").get_data(as_text=True)
    assert "กำลังดูหน้าจอแทน" in page
    blocked = client.post("/admin/roster/save", json={"items": []}, headers={"X-CSRF-Token": tok})
    assert blocked.status_code == 403 and blocked.get_json()["code"] == "view_as"
    assert client.get("/admin/permissions").status_code == 403              # ระหว่างดูแทน = สิทธิ์ของผู้ใช้นั้น
    client.post("/view-as/stop", data={"csrf_token": tok})
    with client.session_transaction() as s:
        assert s["role"] == "admin" and "view_as" not in s
    acts = [r[0] for r in db.execute("SELECT action FROM cs_audit WHERE entity='users' ORDER BY id")]
    assert "view_as" in acts and "view_as_stop" in acts
    # ดูแทนผู้ดูแลระบบด้วยกันไม่ได้
    client.post(f"/admin/view-as/{uid(db, 't_admin')}", data={"csrf_token": tok})
    with client.session_transaction() as s:
        assert "view_as" not in s


def test_grant_validation(app, db, published_form):
    import pytest
    admin = uid(db, "t_admin")
    with pytest.raises(S.ValidationError):
        PM.add_grant(db, {"user_id": admin, "scope": "env"}, admin)
    with pytest.raises(S.ValidationError):
        PM.add_grant(db, {"user_id": uid(db, "t_tech"), "scope": "form"}, admin)
