"""v0.32: ความถี่ 'เดือนละ 2 ครั้ง (ทุก 2 สัปดาห์)' + ผู้ดูแลระบบเพิ่มความถี่เอง (ทุก N วัน/สัปดาห์/เดือน)"""
from datetime import date, datetime

from conftest import GOOD, login, payload, uid

from ecs import itemfreq as IF
from ecs import services as S

CAL = {"shift_times": "08:00,20:00", "day_start": "08:00"}


def test_interval_math():
    r = datetime(2026, 9, 30, 10, 0)
    assert IF.slot_start("w:2", "", r, CAL) == datetime(2026, 9, 21, 8, 0)
    assert IF.next_slot("w:2", "", r, CAL) == datetime(2026, 10, 5, 8, 0)
    assert IF.slot_start("d:3", "", r, CAL) == datetime(2026, 9, 29, 8, 0)
    assert IF.slot_start("m:3", "", r, CAL) == datetime(2026, 7, 1, 8, 0)          # ไตรมาส ก.ค.–ก.ย.
    assert IF.is_due("w:2", "", datetime(2026, 9, 20, 9), r, CAL)                    # ตรวจก่อนช่วงนี้ → ต้องตรวจ
    assert not IF.is_due("w:2", "", datetime(2026, 9, 22, 9), r, CAL)                # ตรวจแล้วในช่วง
    assert IF.normalize("w:2", "") == ("w:2", "")
    assert IF.label("w:2") == "เดือนละ 2 ครั้ง (ทุก 2 สัปดาห์)" and IF.label("d:3") == "ทุก 3 วัน"


def test_admin_custom_freq_and_builder(app, db, published_form):
    c = app.test_client()
    tok = login(c, "t_admin")
    r = c.post("/admin/work-calendar", data={"csrf_token": tok, "action": "freqs",
                                             "f_label": ["รายไตรมาส", "", ""], "f_n": ["3", "10", ""], "f_unit": ["m", "d", ""]})
    assert r.status_code == 302
    assert IF.all_freqs(db)["m:3"] == "รายไตรมาส" and IF.all_freqs(db)["d:10"] == "ทุก 10 วัน"
    page = c.get("/admin/work-calendar").get_data(as_text=True)
    assert "รายไตรมาส" in page and "เดือนละ 2 ครั้ง" in page
    # ซ้ำกับของในระบบ → ไม่ยอม
    c.post("/admin/work-calendar", data={"csrf_token": tok, "action": "freqs", "f_label": ["x"], "f_n": ["2"], "f_unit": ["w"]})
    assert "m:3" in IF.all_freqs(db)
    fid = published_form["form_id"]
    assert "รายไตรมาส" in c.get(f"/forms/{fid}/builder").get_data(as_text=True)
    d = c.get(f"/api/forms/{fid}/draft").get_json()
    assert d["calendar"]["freqs"]["w:2"].startswith("เดือนละ 2 ครั้ง")
    # บันทึกหัวข้อด้วยความถี่ใหม่ได้ · ความถี่แปลกไม่ได้
    admin = uid(db, "t_admin")
    dr = S.get_or_create_draft(db, fid, admin)
    items = [dict(i) for i in S.get_items(db, published_form["version_id"])]
    for i in items:
        i.pop("id", None)
    items[0]["check_freq"] = "w:2"
    items[1]["check_freq"] = "m:3"
    S.save_draft_items(db, dr["id"], items, admin)
    got = {i["item_key"]: i["check_freq"] for i in S.get_items(db, dr["id"])}
    assert got["oil"] == "w:2" and got["noise"] == "m:3"
    items[0]["check_freq"] = "x:9"
    try:
        S.save_draft_items(db, dr["id"], items, admin)
        raise AssertionError("ควรไม่ยอม")
    except S.ValidationError:
        pass
    # ใบบันทึกรายเดือน: ช่องรวมตามช่วง 2 สัปดาห์
    items[0]["check_freq"] = "w:2"
    S.save_draft_items(db, dr["id"], items, admin)
    S.publish_version(db, dr["id"], admin)
    db.commit()
    from ecs import sheet_report as SR
    from ecs import submissions as SUB
    SUB.create_submission(db, payload({**published_form, "version_id": S.get_form(db, fid)["current_version_id"]}, GOOD), {},
                          uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    doc = SR.build_month_sheet(db, fid, date.today().replace(day=1), "s", "x")
    row = next(r for r in doc["grid"]["rows"] if r["it"]["item_key"] == "oil")
    assert row["kind"] == "period" and row["tm"] == "2 สัปดาห์" and 2 <= len(row["segs"]) <= 4
    assert "เดือนละ 2 ครั้ง" in row["freq"]
    fill = open(app.root_path + "/static/m/fill.js", encoding="utf-8").read()
    assert "ivOf" in fill
