"""v0.99.9: ตรวจรอบ "เครื่องหยุด / ขาดตรวจ" กับช่วงหยุดเครื่อง ย้อนหลังทั้งหมด (ไม่จำกัดวัน) ทั้ง 2 ทาง
และตรวจซ้ำทุกครั้งที่เปลี่ยนรอบตรวจ"""
from datetime import datetime, timedelta

from test_v99_8 import _eq_form, _gen, _st

from ecs import services as S
from ecs import statfix as SF

F = "%Y-%m-%d %H:%M:%S"


def _old_round(db, fid, days=100, status="missed"):
    """รอบเก่ามาก (เกิน 40 วัน) — due 08:00 ปิด 12:00"""
    sid = db.execute("SELECT id FROM cs_schedules WHERE form_id=? AND active=1", (fid,)).fetchone()[0]
    due = (datetime.now() - timedelta(days=days)).replace(hour=8, minute=0, second=0, microsecond=0)
    rid = db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                        VALUES (?,?,?,?,?,?,?)""", (sid, fid, due.strftime(F), (due + timedelta(hours=4)).strftime(F),
                                                    (due + timedelta(hours=4)).strftime(F), status, "2000-01-01 00:00:00")).lastrowid
    return rid, due


def _down(db, eq, start, end=None, admin=None):
    db.execute("INSERT INTO cs_downtime(equipment_id, start_at, end_at, reason, category, started_by) VALUES (?,?,?,?,?,?)",
               (eq, start.strftime(F), end.strftime(F) if end else None, "สำรอง", "standby", admin))


def test_old_missed_round_beyond_40_days_is_repaired(app, db):
    eq, fid, admin = _eq_form(app, db)
    rid, due = _old_round(db, fid, days=120)
    _down(db, eq, due - timedelta(days=1), due + timedelta(days=2), admin)
    res = S.refresh_round_statuses(db)
    assert res["down_skipped"] >= 1
    assert _st(db, rid) == "skipped"
    # สถิติรายวันของวันเก่านั้นคำนวณใหม่แล้ว (ไม่มีขาดตรวจ · ไม่นับเป็นรอบที่ต้องตรวจ)
    row = db.execute("SELECT due, missed FROM cs_daily_stats WHERE form_id=? AND stat_date=?", (fid, due.date().isoformat())).fetchone()
    assert row is None or (row["missed"] == 0 and row["due"] == 0), dict(row)


def test_skipped_round_no_longer_covered_is_restored_without_new_alert(app, db):
    """ช่วงหยุดถูกแก้ให้จบก่อนปิดรอบ → รอบที่งดไว้กลับเป็นขาดตรวจ (ไม่แตะ updated_at = ไม่แจ้งเตือนย้อนหลัง)"""
    eq, fid, admin = _eq_form(app, db)
    rid, due = _old_round(db, fid, days=90, status="skipped")
    _down(db, eq, due - timedelta(hours=2), due + timedelta(hours=1), admin)      # เดินเครื่องก่อนปิดรอบ 12:00
    S.refresh_round_statuses(db)
    r = db.execute("SELECT status, updated_at FROM cs_rounds WHERE id=?", (rid,)).fetchone()
    assert r["status"] == "missed" and r["updated_at"] == "2000-01-01 00:00:00"


def test_legacy_skipped_round_without_downtime_history_is_kept(app, db):
    """เครื่องที่ไม่มีช่วงหยุดในตารางเลย (งดตรวจก่อนมีตารางช่วงหยุด · ไม่มีหลักฐานให้ตรวจ) → คงไว้ ไม่กลายเป็นขาดตรวจ"""
    _, fid, _ = _eq_form(app, db)
    rid, _ = _old_round(db, fid, days=200, status="skipped")
    S.refresh_round_statuses(db)
    assert _st(db, rid) == "skipped"


def test_schedule_change_rechecks_downtime_both_ways(app, db):
    """เปลี่ยนรอบตรวจ → เวลาปิดรอบเปลี่ยน → ตรวจกับช่วงหยุดใหม่ ทั้งเป็นเครื่องหยุดและกลับเป็นขาดตรวจ
    (แบบในภาพ: รอบ 08:00 ปิด 20:00 · สำรองตั้งแต่ 21:14 → ขาดตรวจ)"""
    eq, fid, admin = _eq_form(app, db)
    S.generate_rounds(db, now=datetime.now() - timedelta(days=2))
    _gen(db)
    rows = db.execute("SELECT * FROM cs_rounds WHERE form_id=? AND close_at<=? ORDER BY due_at",
                      (fid, (datetime.now() - timedelta(hours=1)).strftime(F))).fetchall()
    y = dict(rows[0])                                    # รอบ 08:00 ปิดรอบ 08:00 วันถัดไป
    due = datetime.fromisoformat(y["due_at"])
    _down(db, eq, due + timedelta(hours=13, minutes=14), due + timedelta(hours=30), admin)   # สำรอง 21:14 – 14:00 วันถัดไป
    S.refresh_round_statuses(db)
    assert _st(db, y["id"]) == "skipped"
    sid = db.execute("SELECT id FROM cs_schedules WHERE form_id=? AND active=1", (fid,)).fetchone()[0]
    S.update_schedule(db, sid, {"freq_type": "daily", "times": "08:00,20:00", "window_min": 240}, admin)
    SF.relink_forms(db, [fid], day_from=due.date(), day_to=due.date(), actor_id=admin)
    r = db.execute("SELECT status, close_at FROM cs_rounds WHERE form_id=? AND due_at=?", (fid, y["due_at"])).fetchone()
    assert r["close_at"] == (due + timedelta(hours=12)).strftime(F)
    assert r["status"] == "missed"                       # ปิดรอบ 20:00 ก่อนสำรอง 21:14 → ขาดตรวจ
    r2 = db.execute("SELECT status FROM cs_rounds WHERE form_id=? AND due_at=?",
                    (fid, (due + timedelta(hours=12)).strftime(F))).fetchone()
    assert r2["status"] == "skipped"                     # รอบ 20:00 ปิด 08:00 ระหว่างสำรอง → เครื่องหยุด
    S.update_schedule(db, sid, {"freq_type": "daily", "times": "08:00", "window_min": 240}, admin)
    SF.relink_forms(db, [fid], day_from=due.date(), day_to=due.date(), actor_id=admin)
    assert db.execute("SELECT status FROM cs_rounds WHERE form_id=? AND due_at=?", (fid, y["due_at"])).fetchone()[0] == "skipped"


def test_relink_reconciles_rounds_outside_relink_range(app, db):
    """แก้รอบตรวจ (คำนวณใหม่ 31 วัน) → รอบเก่ากว่าช่วงนั้นก็ถูกตรวจกับช่วงหยุดด้วย"""
    eq, fid, admin = _eq_form(app, db)
    rid, due = _old_round(db, fid, days=150)
    _down(db, eq, due - timedelta(hours=1), due + timedelta(hours=6), admin)
    st = SF.relink_forms(db, [fid], actor_id=admin)
    assert st["down_skipped"] >= 1
    assert _st(db, rid) == "skipped"


def test_submitted_rounds_are_never_touched(app, db):
    eq, fid, admin = _eq_form(app, db)
    rid, due = _old_round(db, fid, days=60, status="done_late")
    _down(db, eq, due - timedelta(hours=1), None, admin)
    S.refresh_round_statuses(db)
    assert _st(db, rid) == "done_late"
