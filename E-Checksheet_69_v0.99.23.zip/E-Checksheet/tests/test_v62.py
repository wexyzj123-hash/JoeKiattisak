"""v0.62: Energy Data — มิเตอร์ไฟฟ้า/ลม/น้ำ · นำเข้า Excel รูปแบบเดิม · กรอกรายวัน · ตารางรายเดือน · เชื่อม EMS"""
import io
import os
import sqlite3
from datetime import date, timedelta

from conftest import emo, login, uid
from openpyxl import Workbook

from ecs import energy as EN
from ecs import services as S

FIX = os.path.join(os.path.dirname(__file__), "fixtures")


def _water_xlsx(month: int, start: float = 1000.0) -> bytes:
    """ไฟล์จำลองรูปแบบ 'บันทึกการใช้น้ำในโรงงาน' — หัว 3 แถว + วันที่ 1–31 (ค่าสะสม)"""
    wb = Workbook()
    ws = wb.active
    ws.title = str(month)
    ws.append(["ตารางบันทึกการใช้น้ำ"])
    ws.append(["วันที่", "น้ำเข้าจากนิคม", "การใช้น้ำ R.O ฝั่ง VF LINE", None])
    ws.append([None, None, "MH 8220", "MH 8220"])
    ws.append([None, "m3 (10.75 B/m3)", "No.1( m3 )", "No.2( m3 )"])
    for d in range(1, 31):
        ws.append([d, start + d * 100, 50 + d * 2.5, 20 + d * (40 if d == 20 else 1)])
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def test_parse_and_import_water(app, db):
    f1 = app.config["F1"]
    p = EN.parse_file(_water_xlsx(9), "บันทึกการใช้น้ำในโรงงาน โรง1.xlsx", 2026)
    assert len(p["meters"]) == 3 and p["months"][0]["month"] == 9
    keys = {m["key"]: m for m in p["meters"]}
    main = next(m for m in p["meters"] if "นิคม" in m["name"])
    assert main["price"] == 10.75 and EN.auto_main(main["name"])
    sub = [m for m in p["meters"] if m["code"] == "MH8220"]
    assert len(sub) == 2 and {m["name"] for m in sub} == {"No.1", "No.2"} and sub[0]["grp"].startswith("การใช้น้ำ R.O")
    pv = EN.preview(db, p, f1, "water")
    assert pv["n_new_meters"] == 3 and pv["n_new"] == 90
    res = EN.commit(db, p, f1, "water", 2026, "x.xlsx", uid(db, "t_admin"))
    db.commit()
    assert res["new_meters"] == 3 and res["readings"] == 90
    # นำเข้าซ้ำ → ไม่ซ้ำ
    res2 = EN.commit(db, p, f1, "water", 2026, "x.xlsx", uid(db, "t_admin"))
    assert res2["new_meters"] == 0 and res2["readings"] == 0 and len(keys) == 3
    d = EN.dashboard(db, date(2026, 9, 1), f1, today=date(2026, 9, 30))
    w = d["kinds"][0]
    assert w["kind"] == "water" and w["total"] == 2900          # มิเตอร์หลัก (นิคม) 29 วัน × 100 ไม่รวมมิเตอร์ย่อย
    assert w["cost"] == round(2900 * 10.75)
    flagged = [x for x in w["meters"] if x["flags"]]
    assert flagged and flagged[0]["flags"][0][1] == "spike"     # No.2 วันที่ 20 กระโดด


def test_real_xls_hours_file(app, db):
    raw = open(os.path.join(FIX, "aircomp_f3.xls"), "rb").read()
    g = EN.guess("บันทึกการใช้ AIR COMPRESSOR โรง 3.xls", [{"id": 1, "name": "Factory 1", "code": "F1"},
                                                          {"id": 2, "name": "Factory 2", "code": "F2"}, {"id": 3, "name": "Factory 3", "code": "F3"}])
    assert g == {"kind": "hours", "factory_id": 3}
    p = EN.parse_file(raw, "x.xls", 2026)
    codes = {m["code"] for m in p["meters"]}
    assert {"SCT0028", "SCT0031", "SCT0034"} <= codes and {x["month"] for x in p["months"]} >= {9, 10}


def test_entry_sheet_and_pages(app, client, db):
    f1 = app.config["F1"]
    EN.commit(db, EN.parse_file(_water_xlsx(9), "a.xlsx", 2026), f1, "water", 2026, "a.xlsx", uid(db, "t_admin"))
    db.commit()
    mid = db.execute("SELECT id FROM en_meters WHERE name LIKE '%นิคม%'").fetchone()[0]
    tok = login(client, "t_tech")
    html = client.get(f"/energy/entry?factory={f1}&kind=water&day=2026-10-01").get_data(as_text=True)
    assert "บันทึกค่ามิเตอร์รายวัน" in html and "4,000.00" in html
    r = client.post(f"/energy/entry?factory={f1}&kind=water", json={"day": "2026-10-01", "values": {str(mid): "4120"}},
                    headers={"X-CSRF-Token": tok})
    assert r.get_json()["new"] == 1
    assert db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day='2026-10-01'", (mid,)).fetchone()[0] == 4120
    future = (S.now_dt().date() + timedelta(days=2)).isoformat()
    assert client.post(f"/energy/entry?factory={f1}&kind=water", json={"day": future, "values": {str(mid): "1"}},
                       headers={"X-CSRF-Token": tok}).status_code == 422
    assert client.get("/energy/import").status_code == 200                  # v0.65 ช่างนำเข้าได้ (เฉพาะโรงงานตัวเอง)
    for url in ("/energy/", f"/energy/?month=2026-09&factory={f1}&kind=water", "/energy/meters", f"/energy/meters/{mid}",
                f"/energy/sheet?factory={f1}&kind=water&month=2026-09", f"/energy/sheet?factory={f1}&kind=water&month=2026-09&view=v"):
        rr = client.get(url)
        assert rr.status_code == 200, url
    html = client.get(f"/energy/sheet?factory={f1}&kind=water&month=2026-09").get_data(as_text=True)
    assert "en-sheet" in html and "f-spike" in html
    x = client.get(f"/energy/sheet.xlsx?factory={f1}&kind=water&month=2026-09")
    assert x.status_code == 200 and x.data[:2] == b"PK"
    assert "⚡ Energy" in emo(client.get("/dashboard").get_data(as_text=True))    # สลับระบบจาก E-Checksheet


def test_import_page_flow(app, client, db):
    tok = login(client, "t_sup")
    r = client.post("/energy/import", data={"csrf_token": tok, "year": "2026", "kind": "ro", "factory": str(app.config["F1"]),
                                             "file": (io.BytesIO(_water_xlsx(9)), "ro.xlsx")}, content_type="multipart/form-data")
    html = r.get_data(as_text=True)
    assert "ยืนยันนำเข้า" in html and "MH8220" in html
    token = html.split('name="token" value="')[1].split('"')[0]
    r = client.post("/energy/import/confirm", data={"csrf_token": tok, "token": token, "factory": str(app.config["F1"]), "kind": "ro"})
    assert r.status_code == 302
    assert db.execute("SELECT COUNT(*) FROM en_meters WHERE kind='ro'").fetchone()[0] == 3
    assert "ประวัติการนำเข้า" in client.get("/energy/import").get_data(as_text=True)
