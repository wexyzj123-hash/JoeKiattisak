"""v0.36: แจ้งเตือน — เลือกทั้งหมดแล้วลบได้ทุกประเภท (ต้องระบุเหตุผล) · รับทราบแล้วก็เลือกได้"""
from conftest import login

from ecs import anomaly as A
from ecs import services as S


def _mk(db, form, n=3):
    ids = []
    for i, t in enumerate(("ng", "threshold", "missed", "ng")[:n]):
        aid, _ = A.raise_alert(db, alert_type=t, form=form, title=f"A{i}", detail="x", severity="warning", item_key=f"k{i}")
        db.execute("UPDATE cs_alerts SET status='acknowledged' WHERE id=?", (aid,))
        ids.append(aid)
    db.commit()
    return ids


def test_bulk_delete_any_type(app, db, published_form):
    form = S.get_form(db, published_form["form_id"])
    ids = _mk(db, form, 4)
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get("/alerts").get_data(as_text=True)
    for i in ids:                                                     # รับทราบแล้วก็มีช่องเลือก
        assert f'name="ids" value="{i}"' in page
    assert "เลือกทั้งหมด" in page and 'id="del-reason"' in page
    # ไม่ระบุเหตุผล → ลบได้เฉพาะขาดตรวจ
    c.post("/alerts/bulk", data={"csrf_token": tok, "action": "delete", "ids": [str(i) for i in ids]})
    left = {r[0] for r in db.execute("SELECT id FROM cs_alerts")}
    assert ids[2] not in left and {ids[0], ids[1], ids[3]} <= left
    # ระบุเหตุผล → ลบทุกประเภท
    r = c.post("/alerts/bulk", data={"csrf_token": tok, "action": "delete", "reason": "แจ้งเตือนทดสอบ",
                                     "ids": [str(i) for i in ids]}, follow_redirects=True)
    assert "ลบแจ้งเตือนแล้ว 3 รายการ" in r.get_data(as_text=True)
    assert db.execute("SELECT COUNT(*) FROM cs_alerts").fetchone()[0] == 0
    assert db.execute("SELECT COUNT(*) FROM cs_alert_events").fetchone()[0] == 0
    a = db.execute("SELECT after_json FROM cs_audit WHERE entity='cs_alerts' AND action='delete' ORDER BY id DESC").fetchone()
    assert "แจ้งเตือนทดสอบ" in a[0]
    # ไม่ได้เลือก → แจ้งชัดเจน
    r = c.post("/alerts/bulk", data={"csrf_token": tok, "action": "delete", "reason": "x"}, follow_redirects=True)
    assert "ยังไม่ได้เลือกรายการ" in r.get_data(as_text=True)


def test_single_delete_and_ack_feedback(app, db, published_form):
    form = S.get_form(db, published_form["form_id"])
    ids = _mk(db, form, 2)
    c = app.test_client()
    tok = login(c, "t_sup")
    c.post(f"/alerts/{ids[0]}/delete", data={"csrf_token": tok})
    assert db.execute("SELECT 1 FROM cs_alerts WHERE id=?", (ids[0],)).fetchone()          # ประเภท NG ต้องมีเหตุผล
    c.post(f"/alerts/{ids[0]}/delete", data={"csrf_token": tok, "reason": "ซ้ำ"})
    assert not db.execute("SELECT 1 FROM cs_alerts WHERE id=?", (ids[0],)).fetchone()
    r = c.post("/alerts/bulk", data={"csrf_token": tok, "action": "ack", "ids": [str(ids[1])]}, follow_redirects=True)
    assert "รับทราบไปแล้วทั้งหมด" in r.get_data(as_text=True)
    # รออนุมัติที่ยังค้าง ลบไม่ได้
    ap, _ = A.raise_alert(db, alert_type="approval", form=form, title="รออนุมัติ", detail="x", severity="info", item_key="ap")
    db.commit()
    c.post("/alerts/bulk", data={"csrf_token": tok, "action": "delete", "reason": "x", "ids": [str(ap)]})
    assert db.execute("SELECT 1 FROM cs_alerts WHERE id=?", (ap,)).fetchone()
    # ช่างลบไม่ได้
    tok = login(c, "t_tech")
    assert c.post("/alerts/bulk", data={"csrf_token": tok, "action": "delete", "reason": "x", "ids": [str(ids[1])]}).status_code in (302, 403)
    assert db.execute("SELECT 1 FROM cs_alerts WHERE id=?", (ids[1],)).fetchone()
