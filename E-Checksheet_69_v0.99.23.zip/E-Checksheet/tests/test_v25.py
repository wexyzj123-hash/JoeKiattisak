"""v0.25: ตำแหน่ง Tech/Sr.Tech/FM/SV/SSV/DM กำหนดสิทธิ์ลงนาม · หัวหน้างานรายสัปดาห์ (Sr.Tech) · ช่องท้ายเอกสาร Sr.Tech/FM → SV/SSV ·
ตัดแถวสิ่งแวดล้อมรายเดือน · เลือกตรามุมซ้ายบน UTILITY / SE"""
import io
from datetime import date, datetime, timedelta

from conftest import GOOD, login, payload, uid
from openpyxl import load_workbook

from ecs import services as S
from ecs import sheet_report as SR
from ecs import sign_blocks as SB
from ecs import signoffs as SO
from ecs import submissions as SUB


def _prev_month_with_sub(app, db, fid):
    pm = (date.today().replace(day=1) - timedelta(days=1)).replace(day=1)
    f = S.get_form(db, fid)
    SUB.create_submission(db, payload({"form_id": fid, "version_id": f["current_version_id"]}, GOOD), {}, uid(db, "t_tech"),
                          app.config["UPLOAD_FOLDER"], now=datetime(pm.year, pm.month, 3, 9, 0))
    db.commit()
    return pm


def test_positions_and_hierarchy(app, db, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_admin")
    sup, sup2, view, tech = (uid(db, u) for u in ("t_sup", "t_sup2", "t_view", "t_tech"))
    # ตั้งตำแหน่งจากหน้าผู้มีสิทธิ์ลงนาม และจากหน้าแก้ไขผู้ใช้
    c.post("/signoffs/roles", data={"csrf_token": tok, f"pos_{tech}": "tech", f"pos_{sup}": "srtech", f"pos_{view}": "ssv"})
    page = c.get(f"/admin/users/{sup2}").get_data(as_text=True)
    assert 'name="position"' in page
    u = dict(db.execute("SELECT * FROM users WHERE id=?", (sup2,)).fetchone())
    c.post(f"/admin/users/{sup2}", data={"csrf_token": tok, "username": u["username"], "name": u["name"], "role": u["role"],
                                         "factory_id": u["factory_id"] or "", "active": "1", "position": "dm"})
    pos = {r[0]: r[1] for r in db.execute("SELECT id, position FROM users")}
    assert pos[tech] == "tech" and pos[sup] == "srtech" and pos[view] == "ssv" and pos[sup2] == "dm"
    assert "Sr.Tech" in c.get("/admin/users").get_data(as_text=True)
    pm = _prev_month_with_sub(app, db, fid)
    form = S.get_form(db, fid)
    al = SO.slots(db, form, pm)
    wk = [x for x in al if x["slot"].startswith("row:sup:")]
    assert len(wk) >= 4 and sum(1 for x in wk if not x["na"]) == 1          # ต้องลงนามเฉพาะสัปดาห์ที่มีผลตรวจ
    need = next(x for x in wk if not x["na"])
    # Tech ลงนามหัวหน้างานไม่ได้ · SSV ลงแทน Sr.Tech ไม่ได้ · SV/SSV ต้องรอผู้ตรวจรายเดือนก่อน
    me = lambda n: {"id": uid(db, n), "role": "x"}                           # noqa: E731
    for who, slot in (("t_tech", need["slot"]), ("t_view", need["slot"]), ("t_view", "mon:sup")):
        try:
            SO.sign(db, form, pm, slot, me(who))
            raise AssertionError(who + slot)
        except SO.SignError:
            pass
    # v0.26: ช่องรายเดือนต้องรออนุมัติผลตรวจครบ · แถวรายสัปดาห์เติมจากการอนุมัติ
    try:
        SO.sign(db, form, pm, "mon:insp", me("t_sup"))
        raise AssertionError
    except SO.SignError as e:
        assert "รออนุมัติ" in str(e)
    sid = db.execute("SELECT id FROM cs_submissions WHERE form_id=? ORDER BY id DESC LIMIT 1", (fid,)).fetchone()[0]
    SUB.approve(db, sid, sup)
    assert SO.records(db, fid, pm)[need["slot"]]["user_id"] == sup
    SO.sign(db, form, pm, "mon:insp", me("t_sup"))
    SO.sign(db, form, pm, "mon:sup", me("t_view"))
    db.commit()
    sheet = SR.build_month_sheet(db, fid, pm, "s")
    assert sheet["signs"]["rows"][0]["label"] == "หัวหน้างาน (Sr.Tech)"
    assert sheet["signs"]["month"]["insp"]["user_id"] == sup and sheet["signs"]["month"]["sup"]["user_pos"] == "ssv"
    html = c.get(f"/reports/sheets?form={fid}&month={pm:%Y-%m}").get_data(as_text=True).split("</style>")[1]
    assert "ผู้ตรวจ (Sr.Tech/FM)" in html and "หัวหน้างาน (SV/SSV)" in html and "(SSV)" in html
    ws = load_workbook(io.BytesIO(SR.to_excel([sheet]))).worksheets[0]
    vals = {str(ws.cell(r, cc).value) for r in range(1, ws.max_row + 1) for cc in range(1, ws.max_column + 1) if ws.cell(r, cc).value}
    assert {"ผู้ตรวจ (Tech)", "หัวหน้างาน (Sr.Tech)", "ผู้ตรวจ (Sr.Tech/FM)", "หัวหน้างาน (SV/SSV)"} <= vals
    # SAFETY: ช่อง DM = ตำแหน่ง DM
    SB.save(db, [fid], {"rows": ["safety_month"], "boxes": ["safety"]}, None)
    db.commit()
    try:
        SO.sign(db, form, pm, "box:safety:0", me("t_view"))
        raise AssertionError
    except SO.SignError as e:
        assert "DM" in str(e)
    try:
        SO.sign(db, form, pm, "box:safety:0", me("t_sup2"))            # DM ของโรงงานอื่น
        raise AssertionError
    except SO.SignError as e:
        assert "โรงงานอื่น" in str(e)
    SO.save_positions(db, {uid(db, "t_admin"): "dm"}, None)
    SO.sign(db, form, pm, "box:safety:0", me("t_admin"))


def test_env_month_removed_and_stamp(app, db, published_form):
    fid = published_form["form_id"]
    assert "env_month" not in SB.PRESET_ROWS
    c = app.test_client()
    tok = login(c, "t_sup")
    assert "ตรามุมซ้ายบน" in c.get(f"/forms/{fid}").get_data(as_text=True)
    c.post(f"/forms/{fid}/sign-config", data={"csrf_token": tok, "doc_stamp": "se"})
    assert SB.stamp_of(db, S.get_form(db, fid)) == "se"
    month = date.today().replace(day=1)
    html = c.get(f"/reports/sheets?form={fid}&month={month:%Y-%m}").get_data(as_text=True)
    assert "doc-stamp-se.png" in html
    # หลายแบบฟอร์ม: "ไม่เปลี่ยน" คงค่าเดิม · เลือกค่าเริ่มต้น = UTILITY
    c.post("/forms/sign-config", data={"csrf_token": tok, "ids": [str(fid)], "doc_stamp": "keep"})
    assert SB.stamp_own(db, fid) == "se"
    c.post("/forms/sign-config", data={"csrf_token": tok, "ids": [str(fid)], "doc_stamp": ""})
    assert SB.stamp_of(db, S.get_form(db, fid)) == "utility"
    assert "doc-stamp.png" in c.get(f"/reports/sheets?form={fid}&month={month:%Y-%m}").get_data(as_text=True)
    SB.save_stamp(db, [fid], "se", None)
    db.commit()
    sheet = SR.build_month_sheet(db, fid, month, "s")
    from ecs import create_app  # noqa: F401
    import os
    img = os.path.join(os.path.dirname(SR.__file__), "static", "img")
    data = SR.to_excel([sheet], None, os.path.join(img, "doc-stamp.png"),
                       {"utility": os.path.join(img, "doc-stamp.png"), "se": os.path.join(img, "doc-stamp-se.png")})
    ws = load_workbook(io.BytesIO(data)).worksheets[0]
    assert len(ws._images) >= 1
