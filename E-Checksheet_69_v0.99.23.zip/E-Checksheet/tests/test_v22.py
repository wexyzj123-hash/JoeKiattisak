"""v0.22: ช่องลงนามเพิ่มในใบบันทึก (หน่วยงานสิ่งแวดล้อม รายสัปดาห์/เดือน · กล่อง ENVIRONMENT · SAFETY)"""
import io
from datetime import date

from conftest import login, uid
from openpyxl import load_workbook

from ecs import sign_blocks as SB
from ecs import sheet_report as SR


def test_config_parse_and_segments():
    cfg = SB.parse({"rows": ["env_week", "bogus"], "boxes": ["env", "x"], "custom_rows": [{"label": " ซ่อมบำรุง ", "freq": "month"}]})
    assert cfg == {"rows": ["env_week"], "custom_rows": [{"label": "ซ่อมบำรุง", "freq": "month"}], "boxes": ["env"]}
    segs = SB.week_segments(date(2026, 9, 1), 30)          # 1 ก.ย. 2569 = วันอังคาร
    assert segs[0] == {"start": 1, "span": 6, "label": "1–6"} and segs[-1]["start"] + segs[-1]["span"] - 1 == 30
    assert sum(s["span"] for s in segs) == 30


def test_form_page_bulk_and_documents(app, db, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_sup")
    assert "ช่องลงนามเพิ่มในใบบันทึก" in c.get(f"/forms/{fid}").get_data(as_text=True)
    c.post(f"/forms/{fid}/sign-config", data={"csrf_token": tok, "sb_rows": ["env_week", "env_month"], "sb_dept": "env",
                                              "sb_custom": "ฝ่ายซ่อมบำรุง | เดือน"})
    cfg = SB.own(db, fid)
    assert cfg["rows"] == ["env_week"] and cfg["boxes"] == ["env"]          # v0.25 ตัดแถวสิ่งแวดล้อมรายเดือน
    assert cfg["custom_rows"] == [{"label": "ฝ่ายซ่อมบำรุง", "freq": "month"}]
    month = date.today().replace(day=1)
    html = c.get(f"/reports/sheets?form={fid}&month={month:%Y-%m}").get_data(as_text=True)
    assert "หน่วยงานสิ่งแวดล้อม (ตรวจสอบสัปดาห์ละครั้ง)" in html and "ฝ่ายซ่อมบำรุง" in html
    assert "ENVIRONMENT" in html and "MANAGER" in html and "SSV/SV" in html
    sheet = SR.build_month_sheet(db, fid, month, "s")
    assert len(sheet["signs"]["rows"]) == 3 and len(sheet["signs"]["boxes"]) == 1
    data = SR.to_excel([sheet])
    ws = load_workbook(io.BytesIO(data)).worksheets[0]
    vals = {str(ws.cell(r, cc).value) for r in range(1, ws.max_row + 1) for cc in range(1, ws.max_column + 1) if ws.cell(r, cc).value}
    assert {"หน่วยงานสิ่งแวดล้อม (ตรวจสอบสัปดาห์ละครั้ง)", "ENVIRONMENT", "MANAGER", "APPROVED BY", "SSV/SV", "CHECKED BY",
            "1 ครั้ง/สัปดาห์"} <= vals
    # หลายแบบฟอร์มพร้อมกัน · ล้างค่า
    r = c.post("/forms/sign-config", data={"csrf_token": tok, "ids": [str(fid)], "sb_boxes": ["safety"]})
    assert r.status_code == 302 and SB.own(db, fid) == {"rows": [], "custom_rows": [], "boxes": ["safety"]}
    c.post(f"/forms/{fid}/sign-config", data={"csrf_token": tok})
    assert SB.is_empty(SB.own(db, fid))
    assert "xbox" not in c.get(f"/reports/sheets?form={fid}&month={month:%Y-%m}").get_data(as_text=True).split("</style>")[1]


def test_template_inheritance(app, db, published_form):
    from ecs import formtpl as T
    fid = published_form["form_id"]
    tpl = T.make_template(db, fid, uid(db, "t_admin")) if hasattr(T, "make_template") else None
    db.commit()
    if not tpl:
        return
    tpl_id = tpl if isinstance(tpl, int) else tpl["id"]
    SB.save(db, [tpl_id], {"boxes": ["env"]}, None)
    db.commit()
    child = db.execute("SELECT id FROM cs_forms WHERE template_id=? LIMIT 1", (tpl_id,)).fetchone()
    if child:
        from ecs import services as S
        assert SB.effective(db, S.get_form(db, child[0]))["boxes"] == ["env"]
