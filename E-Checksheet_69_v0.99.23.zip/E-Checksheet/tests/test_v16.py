"""v0.16: ส่งออก/นำเข้าแบบฟอร์ม Excel · NG → ใบแจ้งซ่อม UT-CMMS และสถานะย้อนกลับ"""
import io
import sqlite3

import pytest
from conftest import GOOD, login, payload, png_bytes, uid
from openpyxl import load_workbook

from ecs import cmms_wo as W
from ecs import form_xlsx as FX
from ecs import services as S
from ecs import submissions as SUB


# ───────── 1. Excel ─────────

def _wb_bytes(wb):
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


def test_export_import_roundtrip(app, db, published_form):
    fid = published_form["form_id"]
    data, fname = FX.export_form(db, fid)
    assert fname.endswith(".xlsx")
    wb = load_workbook(io.BytesIO(data))
    ws = wb["หัวข้อตรวจ"]
    assert ws.cell(1, 3).value.startswith("ชื่อหัวข้อตรวจ") and ws.cell(2, 3).value == "Oil Pressure"
    assert {"จุดตรวจ", "ข้อมูลแบบฟอร์ม", "วิธีใช้"} <= set(wb.sheetnames)
    oil_key = ws.cell(2, 1).value
    # แก้ใน Excel: เปลี่ยน Max ของ Oil, ลบแถว filter, เพิ่มหัวข้อใหม่ (รหัสว่าง), ตั้งความถี่
    ws.cell(2, 7).value = 2.8
    ws.cell(2, 16).value = "กะละ 1 ครั้ง"
    ws.delete_rows(5)
    n = max(r for r in range(1, 50) if ws.cell(r, 3).value) + 1
    ws.cell(n, 3).value = "อุณหภูมิห้อง"
    ws.cell(n, 4).value = "ตัวเลข"
    ws.cell(n, 5).value = "°C"
    ws.cell(n, 7).value = 40
    res = FX.import_into_form(db, fid, _wb_bytes(wb), uid(db, "t_sup"))
    db.commit()
    assert res == {**res, "items": 5, "kept": 4, "new": 1, "removed": 1}
    items = {i["name"]: i for i in S.get_items(db, res["draft_id"])}
    assert items["Oil Pressure"]["item_key"] == oil_key and items["Oil Pressure"]["max_value"] == 2.8
    assert items["Oil Pressure"]["check_freq"] == "shift"
    assert items["อุณหภูมิห้อง"]["item_type"] == "number" and items["อุณหภูมิห้อง"]["required"] == 1
    assert "ไส้กรอง" not in items


def test_import_rejects_bad_rows_atomically(app, db, published_form):
    fid = published_form["form_id"]
    wb = load_workbook(io.BytesIO(FX.export_form(db, fid)[0]))
    ws = wb["หัวข้อตรวจ"]
    ws.cell(2, 6).value = 5
    ws.cell(2, 7).value = 1          # Min > Max
    ws.cell(3, 4).value = "แบบแปลก"
    with pytest.raises(S.ValidationError) as exc:
        FX.import_into_form(db, fid, _wb_bytes(wb), uid(db, "t_sup"))
    msg = " ".join(exc.value.errors)
    assert "แถว 2" in msg and "แถว 3" in msg
    assert S.get_draft(db, fid) is None
    with pytest.raises(S.ValidationError):
        FX.import_into_form(db, fid, b"not excel", uid(db, "t_sup"))


def test_xlsx_web_and_new_form(app, db, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_sup")
    r = c.get(f"/forms/{fid}/export.xlsx")
    assert r.status_code == 200 and r.data[:2] == b"PK" and "filename*=UTF-8" in r.headers["Content-Disposition"]
    assert "dlgXlsx" in c.get(f"/forms/{fid}").get_data(as_text=True)
    r = c.post(f"/forms/{fid}/import-xlsx", data={"csrf_token": tok, "file": (io.BytesIO(r.data), "f.xlsx")},
               content_type="multipart/form-data")
    assert r.status_code == 302 and "/builder" in r.headers["Location"]
    r = c.post("/forms/import-xlsx", data={"csrf_token": tok, "name": "สำรองกู้คืน",
                                           "file": (io.BytesIO(FX.export_form(db, fid)[0]), "f.xlsx")},
               content_type="multipart/form-data")
    new = db.execute("SELECT id FROM cs_forms WHERE name='สำรองกู้คืน'").fetchone()
    assert r.status_code == 302 and new
    assert len(S.get_items(db, S.get_draft(db, new["id"])["id"])) == 5


# ───────── 2. UT-CMMS ─────────

@pytest.fixture()
def cmms(app, tmp_path):
    path = tmp_path / "cmms.db"
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, name TEXT, role TEXT);
    CREATE TABLE equipment (id INTEGER PRIMARY KEY, code TEXT, name TEXT, location TEXT DEFAULT '', factory TEXT DEFAULT '');
    CREATE TABLE work_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, wo_number TEXT UNIQUE NOT NULL, equipment_id INTEGER,
      title TEXT, description TEXT, priority TEXT, status TEXT DEFAULT 'pending', requested_by INTEGER, assignee_id INTEGER,
      created_at TEXT, completed_at TEXT, due_date TEXT, root_cause TEXT DEFAULT '', action_taken TEXT DEFAULT '',
      notes TEXT DEFAULT '', updated_at TEXT, department TEXT, repair_type TEXT, repair_category TEXT, line_no TEXT,
      mc_no TEXT, data_entry_by TEXT, reporter_name TEXT, factory TEXT, work_window TEXT, repaired_by TEXT DEFAULT '');
    CREATE TABLE wo_attachments (id INTEGER PRIMARY KEY AUTOINCREMENT, wo_id INTEGER, filename TEXT, original_name TEXT,
      file_type TEXT, file_size INTEGER, uploaded_by INTEGER);
    CREATE TABLE activity_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT, target_type TEXT,
      target_id INTEGER, details TEXT);
    INSERT INTO users VALUES (1,'admin','Admin','admin'), (2,'somchai','สมชาย','technician');
    INSERT INTO equipment VALUES (77,'SCT0002','Air Compressor','Comp room','AISIN1');
    """)
    con.commit()
    con.close()
    up = tmp_path / "cmms_uploads"
    app.config.update(CMMS_DATABASE=str(path), CMMS_UPLOAD_FOLDER=str(up))
    yield {"path": str(path), "uploads": up}
    app.config.pop("CMMS_DATABASE", None)
    app.config.pop("CMMS_UPLOAD_FOLDER", None)


def _ng(app, db, form, photo=True):
    from werkzeug.datastructures import FileStorage
    ans = dict(GOOD, oil={"value": "3.1", "remark": "สูงเกิน", "photos": ["p1"]})
    files = {"p1": FileStorage(io.BytesIO(png_bytes()), filename="p1.png", content_type="image/png")}
    res = SUB.create_submission(db, payload(form, ans), files, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    return res["id"]


def test_ng_opens_work_order_and_status_flows_back(app, db, published_form, cmms):
    db.execute("UPDATE equipment SET legacy_id=77 WHERE id=?", (published_form["equipment_id"],))
    W.save_settings(db, {"enabled": "1", "mode": "ng", "department": "UT", "attach_photos": "1"}, uid(db, "t_admin"))
    db.commit()
    sid = _ng(app, db, published_form)
    res = W.after_submit(db, app.config, sid, uid(db, "t_tech"), "http://x/echeck")
    assert res and res["wo_number"].startswith("WO-") and res["photos"] == 1
    con = sqlite3.connect(cmms["path"])
    con.row_factory = sqlite3.Row
    wo = con.execute("SELECT * FROM work_orders").fetchone()
    assert wo["equipment_id"] == 77 and wo["status"] == "pending" and wo["department"] == "UT"
    assert "Oil Pressure" in wo["description"] and f"/submissions/{sid}" in wo["description"] and wo["mc_no"] == "SCT0002"
    assert con.execute("SELECT COUNT(*) FROM wo_attachments").fetchone()[0] == 1 and any(cmms["uploads"].iterdir())
    # NG ซ้ำหัวข้อเดิม → ไม่เปิดใบใหม่ เพิ่มบันทึกในใบเดิม
    sid2 = _ng(app, db, published_form)
    r2 = W.after_submit(db, app.config, sid2, uid(db, "t_tech"))
    assert r2["repeat"] and con.execute("SELECT COUNT(*) FROM work_orders").fetchone()[0] == 1
    assert "NG ซ้ำ" in con.execute("SELECT notes FROM work_orders").fetchone()[0]
    # CAPA จาก NG + แจ้งเตือน → ปิดใบใน UT-CMMS → ย้อนกลับ
    from ecs import capa
    aid = capa.create_from_ng(db, sid, "oil", uid(db, "t_sup"))
    db.execute("""INSERT INTO cs_alerts(alert_type, severity, dedup_key, form_id, item_key, submission_id, title, status,
                  created_at, updated_at) VALUES ('ng','critical','t',?, 'oil', ?, 'NG', 'open', '2026-01-01', '2026-01-01')""",
               (published_form["form_id"], sid))
    db.commit()
    con.execute("UPDATE work_orders SET status='in_progress', assignee_id=2")
    con.commit()
    st = W.sync_status(db, app.config)
    assert st["changed"] >= 1 and W.links_for_submission(db, sid)[0]["status"] == "in_progress"
    con.execute("UPDATE work_orders SET status='completed', root_cause='วาล์วค้าง', action_taken='เปลี่ยนวาล์ว'")
    con.commit()
    st = W.sync_status(db, app.config)
    assert st["closed"] == 2
    al = db.execute("SELECT * FROM cs_alerts WHERE submission_id=? AND alert_type<>'approval'", (sid,)).fetchone()
    assert al["status"] == "resolved" and al["action_taken"] == "เปลี่ยนวาล์ว"
    assert db.execute("SELECT status FROM cs_actions WHERE id=?", (aid,)).fetchone()[0] == "done"
    assert W.sync_status(db, app.config)["closed"] == 0                  # ทำครั้งเดียว
    con.close()


def test_manual_and_disabled_modes(app, db, published_form, cmms):
    db.execute("UPDATE equipment SET legacy_id=77 WHERE id=?", (published_form["equipment_id"],))
    db.commit()
    sid = _ng(app, db, published_form)
    assert W.after_submit(db, app.config, sid, uid(db, "t_tech")) is None          # ปิดไว้ (ค่าเริ่มต้น)
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get(f"/submissions/{sid}").get_data(as_text=True)
    assert "เปิดใบแจ้งซ่อม UT-CMMS" in page
    r = c.post(f"/submissions/{sid}/cmms-wo", data={"csrf_token": tok})
    assert r.status_code == 302 and W.links_for_submission(db, sid)
    assert "WO-" in c.get(f"/submissions/{sid}").get_data(as_text=True)
    login(c, "t_admin")
    assert "ใบแจ้งซ่อม UT-CMMS" in c.get("/admin/cmms-wo").get_data(as_text=True)


def test_no_cmms_is_harmless(app, db, published_form):
    sid = _ng(app, db, published_form)
    assert W.after_submit(db, app.config, sid, uid(db, "t_tech")) is None
    assert not W.available(app.config)
