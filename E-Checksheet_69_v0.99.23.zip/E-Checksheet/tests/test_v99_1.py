"""v0.99.1: ฟอนต์ในเครื่อง · ไอคอนแทนอีโมจิ · แยกไฟล์ views (เส้นทางเดิมครบ) · ตรวจ scheme ของ URL แจ้งเตือน · ป้ายวันที่ไทย"""
import os
import re

import pytest

from conftest import login

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_fonts_are_local_no_cdn(client):
    login(client, "t_admin")
    for path in ("/dashboard", "/m/", "/today", "/tv"):
        html = client.get(path, follow_redirects=True).get_data(as_text=True)
        assert "fonts.googleapis.com" not in html and "fonts.gstatic.com" not in html, path
        assert "css/fonts.css" in html, path
    css = client.get("/static/css/fonts.css").get_data(as_text=True)
    files = re.findall(r"url\(\.\./fonts/([^)]+\.woff2)\)", css)
    assert len(files) >= 8
    for f in files:
        assert os.path.getsize(os.path.join(ROOT, "ecs", "static", "fonts", f)) > 1000


def test_icons_replace_emoji_in_text(client):
    login(client, "t_admin")
    html = client.get("/today").get_data(as_text=True)
    assert 'class="ei ei-okc"' in html and "✅" not in re.sub(r"<script.*?</script>", "", html, flags=re.S)
    assert "css/icons.css" in html
    css = client.get("/static/css/icons.css").get_data(as_text=True)
    assert ".ei-okc" in css and "mask" in css


def test_emoji_kept_in_attributes_and_script(client):
    """ไม่แตะค่าในแอตทริบิวต์ / <script> — ไม่ให้ HTML พังจากการแทนที่"""
    login(client, "t_admin")
    for path in ("/dashboard", "/forms", "/energy/", "/admin/users", "/m/"):
        html = client.get(path, follow_redirects=True).get_data(as_text=True)
        assert 'title="<i' not in html and 'placeholder="<i' not in html and "&lt;i class=" not in html, path


@pytest.mark.parametrize("endpoint,url", [
    ("energy.import_page", "/energy/import"), ("energy.case_detail", "/energy/cases/5"), ("energy.report", "/energy/report"),
    ("energy.form_builder", "/energy/forms/new"), ("forms.schedule_create", "/forms/3/schedules"), ("forms.rounds", "/rounds"),
    ("forms.template_apply", "/forms/3/apply"), ("forms.change_requests", "/forms/change-requests"), ("forms.api_publish", "/api/forms/3/publish"),
    ("admin.health", "/admin/health"), ("admin.cmms_tpm_settings", "/admin/cmms-tpm"), ("admin.area_map", "/areas/3/map"),
    ("admin.layout", "/admin/layout"),
])
def test_split_views_keep_urls(app, endpoint, url):
    from flask import url_for
    kw = {"cid": 5} if endpoint == "energy.case_detail" else ({"area_id": 3} if endpoint == "admin.area_map" else (
        {"form_id": 3} if endpoint.startswith(("forms.schedule_create", "forms.template_apply", "forms.api_publish")) else {}))
    with app.test_request_context():
        got = url_for(endpoint, **kw)
    assert got.split("?")[0].endswith(url.split("?")[0]) or got == url, (endpoint, got, url)


def test_notify_rejects_non_http_url():
    from ecs import notify
    with pytest.raises(notify.SendError):
        notify._http_json("file:///etc/passwd", {"x": 1})
    with pytest.raises(notify.SendError):
        notify._http_json("", {"x": 1})


def test_thai_date_label_script_present(client):
    login(client, "t_sup")
    html = client.get("/dashboard").get_data(as_text=True)
    assert "className = 'thd'" in html and "+ 543" in html
