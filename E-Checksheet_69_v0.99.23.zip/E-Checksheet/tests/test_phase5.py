"""Phase 5: รายงานรายวัน/สัปดาห์/เดือน (เว็บ/PDF/Excel), ตั้งเวลาส่งอีเมล, ดึงข้อมูลจากระบบภายนอก"""
import io
import json
import os
import sqlite3
from datetime import date, datetime, timedelta

import pytest

from ecs import connectors as CN
from ecs import notify as N
from ecs import report_docs as RD
from ecs import schedules as SC
from ecs import submissions as SUB
from ecs.services import ValidationError, ts

from conftest import GOOD, login, payload, uid


def submit(app, db, form, answers):
    SUB.create_submission(db, payload(form, answers), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()


# ───────────────────────── report content ─────────────────────────

def test_build_reports(app, db, published_form):
    submit(app, db, published_form, GOOD)
    submit(app, db, published_form, {**GOOD, "oil": {"value": "2.45"}, "hour": {"value": "1001"}})
    today = date.today()
    d = RD.build(db, "daily", today)
    assert d["kpi"]["subs"] == 2 and d["kpi"]["warn"] == 1 and d["kpi"]["item_count"] == 8
    assert d["title"] == "รายงานการตรวจเช็คประจำวัน" and d["days"] == []
    m = RD.build(db, "monthly", today)
    assert len(m["days"]) >= 28 and m["d_from"].day == 1 and m["period"].startswith("เดือน")
    w = RD.build(db, "weekly", today)
    assert len(w["days"]) == 7 and (w["d_to"] - w["d_from"]).days == 6
    assert RD.build(db, "daily", today, app.config["F2"])["kpi"]["subs"] == 0
    assert "<svg" in RD.svg_daily_bars(m["days"]) and RD.svg_hbars([], "l", "v") == ""
    xl = RD.to_excel(m)
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(xl))
    assert wb.sheetnames[:3] == ["สรุป", "สรุปรายพื้นที่", "รายวัน"] and "งานแก้ไข (CAPA)" in wb.sheetnames
    assert RD.filename(m, "pdf").startswith(f"echecksheet_monthly_{today:%Y-%m}")


def test_report_pages(client, app, db, published_form, monkeypatch):
    submit(app, db, published_form, GOOD)
    login(client, "t_view")
    assert client.get("/reports").status_code == 200
    for kind in ("daily", "weekly", "monthly"):
        body = client.get(f"/reports/{kind}").get_data(as_text=True)
        assert "รายงานการตรวจเช็ค" in body and "ผู้จัดการ (อนุมัติ)" in body and "built-in method" not in body
    r = client.get("/reports/monthly?format=xlsx&month=2026-01")
    assert r.status_code == 200 and "attachment" in r.headers["Content-Disposition"]
    import ecs.pdf as P
    monkeypatch.setattr(P, "html_to_pdf", lambda html, timeout=90: b"%PDF-1.4 test " + html[:20].encode())
    r = client.get(f"/reports/daily?format=pdf&date={date.today().isoformat()}")
    assert r.mimetype == "application/pdf" and r.data.startswith(b"%PDF")
    def boom(html, timeout=90):
        raise P.PdfError("ไม่พบเบราว์เซอร์")
    monkeypatch.setattr(P, "html_to_pdf", boom)
    r = client.get("/reports/daily?format=pdf")
    assert r.status_code == 302                                       # แจ้งเตือนและกลับหน้ารายงาน
    assert client.get("/reports/daily?date=bad").status_code == 200


def test_real_pdf_when_browser_available(client, app, db, published_form):
    from ecs.pdf import find_browser
    if not find_browser():
        pytest.skip("ไม่มีเบราว์เซอร์สำหรับสร้าง PDF")
    submit(app, db, published_form, GOOD)
    login(client, "t_view")
    r = client.get("/reports/daily?format=pdf")
    assert r.status_code == 200 and r.data[:4] == b"%PDF" and len(r.data) > 5000


def test_find_browser_env(monkeypatch, tmp_path):
    from ecs import pdf as P
    fake = tmp_path / "edge.exe"
    fake.write_text("x")
    monkeypatch.setenv("PDF_BROWSER", str(fake))
    assert P.find_browser() == str(fake)
    monkeypatch.setattr(P, "find_browser", lambda: None)
    with pytest.raises(P.PdfError):
        P.html_to_pdf("<p>x</p>")


# ───────────────────────── schedules ─────────────────────────

def test_compute_next_and_ref():
    base = datetime(2026, 9, 23, 8, 0)               # วันพุธ
    assert SC.compute_next({"kind": "daily", "send_time": "07:30"}, base) == datetime(2026, 9, 24, 7, 30)
    assert SC.compute_next({"kind": "daily", "send_time": "17:00"}, base) == datetime(2026, 9, 23, 17, 0)
    assert SC.compute_next({"kind": "weekly", "send_time": "07:30", "weekday": 0}, base) == datetime(2026, 9, 28, 7, 30)
    assert SC.compute_next({"kind": "monthly", "send_time": "07:00", "month_day": 1}, base) == datetime(2026, 10, 1, 7, 0)
    assert SC.compute_next({"kind": "monthly", "send_time": "07:00", "month_day": 1},
                           datetime(2026, 12, 5)) == datetime(2027, 1, 1, 7, 0)
    assert SC.report_ref({"kind": "daily", "daily_scope": "yesterday"}, base) == date(2026, 9, 22)
    assert SC.report_ref({"kind": "daily", "daily_scope": "today"}, base) == date(2026, 9, 23)
    assert SC.report_ref({"kind": "monthly"}, datetime(2026, 10, 1, 7)) == date(2026, 9, 1)


def test_schedule_validation(db):
    with pytest.raises(ValidationError) as e:
        SC.save_schedule(db, {"name": "", "formats": [], "recipients": "bad", "send_time": "25:99"}, None)
    assert len(e.value.errors) >= 4
    sid = SC.save_schedule(db, {"name": "เช้า", "kind": "daily", "formats": ["pdf", "xlsx"],
                                "recipients": "a@x.co; b@x.co", "send_time": "07:30"}, None, now=datetime(2026, 9, 23, 8))
    s = SC.get_schedule(db, sid)
    assert s["recipients"] == "a@x.co, b@x.co" and s["next_run_at"] == "2026-09-24 07:30:00"


def _enable_email(db):
    N.save_settings(db, {"email": {"enabled": "1", "host": "smtp.local", "sender": "ecs@x.co", "port": 25, "security": "none"}}, None)
    db.commit()


def test_run_schedule_sends_attachments(app, db, published_form, monkeypatch):
    submit(app, db, published_form, GOOD)
    import ecs.pdf as P
    monkeypatch.setattr(P, "html_to_pdf", lambda html, timeout=90: b"%PDF-1.4 fake")
    sent = []
    monkeypatch.setitem(N.SENDERS, "email", lambda cfg, target, subject, body, url, attachments=None:
                        sent.append((target, subject, [a[0] for a in attachments or []])))
    sid = SC.save_schedule(db, {"name": "เช้า", "kind": "daily", "formats": ["pdf", "xlsx"], "recipients": "a@x.co",
                                "send_time": "07:30"}, None, now=datetime.now() - timedelta(days=1))
    db.commit()
    with app.test_request_context("/"):
        from ecs.db import get_db
        con = get_db()
        res = SC.run_schedule(con, sid, manual=True)
        assert not res["ok"] and "SMTP" in res["message"]          # ยังไม่ตั้งค่าอีเมล
        _enable_email(con)
        res = SC.run_schedule(con, sid, manual=True)
        con.commit()
    assert res["ok"] and sent[0][0] == "a@x.co" and len(sent[0][2]) == 2
    assert sent[0][2][0].endswith(".pdf") and sent[0][2][1].endswith(".xlsx")
    runs = SC.list_runs(db)
    assert [r["status"] for r in runs] == ["sent", "failed"]


def test_due_schedule_runs_from_job(app, db, monkeypatch):
    _enable_email(db)
    import ecs.pdf as P
    monkeypatch.setattr(P, "html_to_pdf", lambda html, timeout=90: b"%PDF-1.4 fake")
    sent = []
    monkeypatch.setitem(N.SENDERS, "email", lambda *a, **k: sent.append(k.get("attachments")))
    sid = SC.save_schedule(db, {"name": "รายเดือน", "kind": "monthly", "formats": ["xlsx"], "recipients": "m@x.co",
                                "send_time": "07:00", "month_day": 1}, None, now=datetime.now() - timedelta(days=40))
    db.commit()
    from ecs.views.rep import run_due_schedules
    assert run_due_schedules(app) == 1 and len(sent) == 1
    s = SC.get_schedule(db, sid)
    assert s["last_status"] == "sent" and s["next_run_at"] > ts()
    assert run_due_schedules(app) == 0


def test_schedule_pages(client, db):
    tok = login(client, "t_admin")
    assert client.get("/admin/report-schedules").status_code == 200
    r = client.post("/admin/report-schedules", data={"csrf_token": tok, "name": "สรุปเย็น", "kind": "daily",
                                                     "daily_scope": "today", "formats": ["xlsx"], "recipients": "a@x.co",
                                                     "send_time": "17:00", "active": "1"})
    assert r.status_code == 302 and SC.list_schedules(db)[0]["daily_scope"] == "today"
    sid = SC.list_schedules(db)[0]["id"]
    assert client.post(f"/admin/report-schedules/{sid}/run", data={"csrf_token": tok}).status_code == 302
    assert client.post(f"/admin/report-schedules/{sid}/delete", data={"csrf_token": tok}).status_code == 302
    assert SC.list_schedules(db) == []


# ───────────────────────── connectors ─────────────────────────

def test_sql_guard_and_parsing():
    for bad in ("DELETE FROM x", "SELECT 1; DROP TABLE x", "select * into y from x", "exec sp_x"):
        with pytest.raises(CN.SourceError):
            CN._check_select(bad)
    assert CN._check_select("-- c\nWITH a AS (SELECT 1) SELECT * FROM a;").startswith("WITH")
    rows, bad = CN.normalize([("T1", "2026-09-01T08:00:00Z", "1,234.5"), ("T1", "01/09/2026 09:00", 2), ("", "x", 1),
                              ("T2", 1788220800, "abc"), ("T3", datetime(2026, 9, 1, 7), "5")])
    assert bad == 2 and [r[0] for r in rows] == ["T3", "T1", "T1"] and rows[1][2] == 1234.5
    long = CN.parse_csv("tag,timestamp,value\nA,2026-09-01 08:00,1\nB,2026-09-01 08:00,2\n", CN.DEFAULT_CONFIG["csv"])
    assert long == [("A", "2026-09-01 08:00", "1"), ("B", "2026-09-01 08:00", "2")]
    wide = CN.parse_csv("time;A;B\n2026-09-01 08:00;1;2\n", {**CN.DEFAULT_CONFIG["csv"], "layout": "wide", "ts_col": "time", "delimiter": ";"})
    assert sorted(wide) == [("A", "2026-09-01 08:00", "1"), ("B", "2026-09-01 08:00", "2")]
    with pytest.raises(CN.SourceError):
        CN.parse_csv("x,y\n1,2", CN.DEFAULT_CONFIG["csv"])
    assert "PWD=••••" in CN.mask_secret("SERVER=a;PWD=secret;") and "${X}" in CN.mask_secret("PWD=${X}")


def _scada(tmp_path, rows):
    path = str(tmp_path / "scada.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    con.executemany("INSERT INTO h VALUES (?,?,?)", rows)
    con.commit()
    con.close()
    return path


def test_sqlite_source_end_to_end(app, db, published_form, tmp_path):
    now = datetime(2026, 9, 1, 12, 30)
    rows = []
    for i in range(0, 150, 10):                        # 10:00–12:20 ทุก 10 นาที
        t = datetime(2026, 9, 1, 10, 0) + timedelta(minutes=i)
        rows += [("OIL", ts(t), 2.0 + i / 1000), ("RUN_HR", ts(t), 1000 + i / 60), ("UNUSED", ts(t), 5)]
    rows.append(("OIL", ts(datetime(2026, 9, 1, 11, 55)), 3.2))             # ค่า NG ในชั่วโมง 11
    path = _scada(tmp_path, rows)
    sid = CN.save_source(db, {"name": "SCADA", "kind": "sqlite", "bucket_min": 60, "agg": "max", "active": "1",
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                         "backfill_days": 1}}, None, now=now)
    pv = CN.preview(db, sid, now=now)
    assert pv["rows"] == len(rows) and {t["tag"] for t in pv["tags"]} == {"OIL", "RUN_HR", "UNUSED"}
    assert db.execute("SELECT COUNT(*) FROM cs_submissions").fetchone()[0] == 0        # ทดสอบไม่สร้างผลตรวจ
    assert db.execute("SELECT COUNT(*) FROM cs_source_tags").fetchone()[0] == 3        # v0.73 จำรายชื่อ Tag ไว้ให้จับคู่
    res = CN.run_source(db, sid, now=now)
    assert res["ok"] and res["submissions"] == 0 and len(CN.list_tags(db, sid)) == 3  # ยังไม่จับคู่
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{published_form['form_id']}:oil"},
                              {"tag": "RUN_HR", "target": f"{published_form['form_id']}:hour", "scale": 1}], None)
    db.execute("UPDATE cs_sources SET watermark='' WHERE id=?", (sid,))
    res = CN.run_source(db, sid, now=now)
    db.commit()
    assert res["submissions"] == 2                         # ชั่วโมง 10 และ 11 (ชั่วโมง 12 ยังไม่ครบ)
    subs = db.execute("SELECT * FROM cs_submissions WHERE source='auto' ORDER BY finished_at").fetchall()
    assert [s["finished_at"] for s in subs] == ["2026-09-01 10:59:59", "2026-09-01 11:59:59"]
    assert subs[1]["ng_count"] == 1 and subs[0]["approval_status"] == "pending" and subs[0]["round_id"] is None
    assert db.execute("SELECT COUNT(*) FROM cs_alerts WHERE alert_type='ng' AND submission_id=?", (subs[1]["id"],)).fetchone()[0] == 1
    assert CN.get_source(db, sid)["watermark"] == "2026-09-01 11:59:59"
    res = CN.run_source(db, sid, now=now)                  # ดึงซ้ำ: ไม่สร้างซ้ำ
    assert res["submissions"] == 0
    res = CN.run_source(db, sid, now=datetime(2026, 9, 1, 13, 5))
    assert res["submissions"] == 1                         # ชั่วโมง 12 ครบแล้ว
    assert db.execute("SELECT COUNT(*) FROM cs_submissions WHERE source='auto'").fetchone()[0] == 3
    from ecs.analytics import results_of_day
    assert results_of_day(db, date(2026, 9, 1))["submissions"] == 0     # ไม่ปนกับผลตรวจของช่าง


def test_scale_offset_and_avg(app, db, published_form, tmp_path):
    t0 = datetime(2026, 9, 1, 8, 0)
    path = _scada(tmp_path, [("P", ts(t0 + timedelta(minutes=m)), v) for m, v in ((0, 200), (20, 210), (40, 220))])
    sid = CN.save_source(db, {"name": "S", "kind": "sqlite", "bucket_min": 60, "agg": "avg",
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ?"}}, None, now=t0)
    CN.save_mapping(db, sid, [{"tag": "P", "target": f"{published_form['form_id']}:oil", "scale": 0.01, "add_offset": 0}], None)
    CN.run_source(db, sid, now=t0 + timedelta(hours=2))
    v = db.execute("SELECT a.value_num FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id WHERE s.source='auto'").fetchone()[0]
    assert v == pytest.approx(2.1)
    with pytest.raises(ValidationError):
        CN.save_mapping(db, sid, [{"tag": "P", "target": f"{published_form['form_id']}:noise"}], None)   # ไม่ใช่ตัวเลข


def test_csv_folder_source(app, db, published_form, tmp_path):
    folder = tmp_path / "export"
    folder.mkdir()
    (folder / "a.csv").write_text("tag,timestamp,value\nOIL,2026-09-01 08:10,2.2\n", encoding="utf-8")
    (folder / "skip.txt").write_text("x")
    sid = CN.save_source(db, {"name": "CSV", "kind": "csv", "bucket_min": 0,
                              "config": {"folder": str(folder), "pattern": "*.csv"}}, None)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{published_form['form_id']}:oil"}], None)
    assert CN.run_source(db, sid)["submissions"] == 1
    assert CN.run_source(db, sid)["rows"] == 0                           # ไฟล์เดิมไม่อ่านซ้ำ
    (folder / "b.csv").write_text("tag,timestamp,value\nOIL,2026-09-01 09:10,2.3\n", encoding="utf-8")
    assert CN.run_source(db, sid)["submissions"] == 1
    assert os.path.exists(folder / "a.csv")                               # ไม่ย้าย/ลบไฟล์ต้นทาง
    bad = CN.save_source(db, {"name": "X", "kind": "csv", "config": {"folder": str(tmp_path / "none")}}, None)
    res = CN.run_source(db, bad)
    assert not res["ok"] and "ไม่พบโฟลเดอร์" in res["message"]


def test_rest_source(app, db, published_form, monkeypatch):
    payload_ = {"data": {"items": [{"name": "OIL", "time": "2026-09-01T08:00:00", "v": 2.4}]}}

    class Resp(io.BytesIO):
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False
    seen = {}

    def fake_urlopen(req, timeout=20):
        seen["url"], seen["auth"] = req.full_url, req.headers.get("Authorization")
        return Resp(json.dumps(payload_).encode())
    monkeypatch.setattr(CN.urllib.request, "urlopen", fake_urlopen)
    monkeypatch.setenv("API_TOKEN", "abc")
    sid = CN.save_source(db, {"name": "API", "kind": "rest", "bucket_min": 0, "config": {
        "url": "https://api.local/values?from={since}", "headers": {"Authorization": "Bearer ${API_TOKEN}"},
        "items_path": "data.items", "tag_field": "name", "ts_field": "time", "value_field": "v", "backfill_days": 30}},
        None, now=datetime(2026, 9, 2))
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{published_form['form_id']}:oil"}], None)
    res = CN.run_source(db, sid, now=datetime(2026, 9, 2))
    assert res["submissions"] == 1 and seen["auth"] == "Bearer abc" and "from=2026-08-03T00:00:00" in seen["url"]
    with pytest.raises(ValidationError):
        CN.save_source(db, {"name": "bad", "kind": "rest", "config": {"url": "ftp://x"}}, None)


def test_mssql_without_driver(db):
    sid = CN.save_source(db, {"name": "GENESIS64", "kind": "mssql", "config": {}}, None)
    res = CN.run_source(db, sid)
    assert not res["ok"] and ("pyodbc" in res["message"] or "SQL Server" in res["message"])
    with pytest.raises(ValidationError):
        CN.save_source(db, {"name": "x", "kind": "mssql", "config": {"query": "UPDATE t SET a=1"}}, None)


def test_source_pages(client, db, published_form, tmp_path):
    path = _scada(tmp_path, [("OIL", ts(datetime.now() - timedelta(hours=3)), 2.1)])
    tok = login(client, "t_admin")
    assert client.get("/admin/sources").status_code == 200
    r = client.post("/admin/sources", data={"csrf_token": tok, "name": "Demo", "kind": "sqlite", "cfg.path": path,
                                            "cfg.query": "SELECT tag, ts, value FROM h WHERE ts > ?", "cfg.backfill_days": "1",
                                            "interval_min": "15", "bucket_min": "0", "agg": "last", "active": "1"})
    assert r.status_code == 302
    sid = CN.list_sources(db)[0]["id"]
    assert client.get(f"/admin/sources/{sid}").status_code == 200
    d = client.post(f"/admin/sources/{sid}/test", json={}, headers={"X-CSRF-Token": tok, "Accept": "application/json"}).get_json()
    assert d["ok"] and d["rows"] == 1
    assert client.post(f"/admin/sources/{sid}/run", data={"csrf_token": tok}).status_code == 302
    r = client.post(f"/admin/sources/{sid}/tags", data={"csrf_token": tok, "tag": ["OIL"],
                                                       "target.0": f"{published_form['form_id']}:oil", "scale.0": "1", "offset.0": "0"})
    assert r.status_code == 302 and CN.list_tags(db, sid)[0]["item_key"] == "oil"
    csv_bytes = b"tag,timestamp,value\nOIL,2026-09-01 08:00,2.2\nOIL,2026-09-01 09:00,2.3\n"
    r = client.post(f"/admin/sources/{sid}/upload", data={"csrf_token": tok, "file": (io.BytesIO(csv_bytes), "x.csv")},
                    content_type="multipart/form-data")
    assert r.status_code == 302
    assert db.execute("SELECT COUNT(*) FROM cs_submissions WHERE source='auto'").fetchone()[0] == 2
    assert client.post(f"/admin/sources/{sid}/delete", data={"csrf_token": tok}).status_code == 302


def test_source_permissions(client):
    login(client, "t_sup")
    assert client.get("/admin/sources").status_code == 403
    assert client.get("/admin/report-schedules").status_code == 403
    assert client.get("/reports").status_code == 200
