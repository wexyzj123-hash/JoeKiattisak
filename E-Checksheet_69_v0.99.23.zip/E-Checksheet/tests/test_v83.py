"""v0.83: ยืนยันเฉพาะรอบผิดปกติ · หน้ารวมปัญหา SCADA · ตั้งค่าหลายแบบฟอร์ม · ดูตัวอย่าง/เตือนหน่วยในหน้าจับคู่ · ลงค่าใหม่อัปเดตค่า SCADA ในผลของช่าง"""
import sqlite3
from datetime import datetime, time, timedelta

from conftest import GOOD, login, payload, uid
from test_v82 import _round, _setup as _setup82

from ecs import connectors as CN
from ecs import services as S
from ecs import srcmap as SM
from ecs import submissions as SUB
from ecs import tagmatch as TM
from ecs.services import ts


def _src(db, form, path, rows, confirm="2"):
    fid = form["form_id"]
    S.create_schedule(db, fid, {"freq_type": "shift", "times": "08:30,20:30", "window_min": 240}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (ts(S.now_dt() - timedelta(days=2)),))
    S.generate_rounds(db)
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    con.executemany("INSERT INTO h VALUES (?,?,?)", rows)
    con.commit()
    con.close()
    sid = CN.save_source(db, {"name": "SCADA", "kind": "sqlite", "prefill": "0", "confirm_required": confirm,
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 2}}, None)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil"}], None)
    db.commit()
    return sid


def test_confirm_only_abnormal(app, db, published_form, tmp_path):
    day = S.now_dt().date() - timedelta(days=1)
    rows = [("OIL", ts(datetime.combine(day, time(8, 30))), 2.0), ("OIL", ts(datetime.combine(day, time(20, 30))), 3.1)]
    sid = _src(db, published_form, str(tmp_path / "h.db"), rows)
    assert CN.get_source(db, sid)["confirm_required"] == 2
    CN.run_source(db, sid)
    db.commit()
    st = {r[0][11:16]: r[1] for r in db.execute("SELECT finished_at, approval_status FROM cs_submissions WHERE source='auto' ORDER BY finished_at")}
    assert st == {"08:30": "approved", "20:30": "pending"}                       # ค่าปกติอนุมัติเอง · NG รอคนดู
    db.execute("UPDATE cs_sources SET confirm_required=1")
    db.execute("DELETE FROM cs_meta WHERE key='v83_confirm_mode'")
    from ecs.schema import ensure_schema
    ensure_schema(db)
    assert CN.get_source(db, sid)["confirm_required"] == 2                       # แหล่งเดิม "ยืนยันทุกรอบ" → เฉพาะรอบผิดปกติ (ครั้งเดียว)


def test_issues_page_and_bulk_ui(app, db, published_form, tmp_path):
    day = S.now_dt().date() - timedelta(days=1)
    rows = [("OIL", ts(datetime.combine(day, time(20, 30))), 3.1)]
    sid = _src(db, published_form, str(tmp_path / "h.db"), rows)
    CN.run_source(db, sid)
    db.execute("UPDATE cs_source_tags SET last_seen=? WHERE source_id=?", (ts(S.now_dt() - timedelta(hours=10)), sid))
    db.commit()
    from ecs import srcissues as SI
    rep = SI.collect(db)
    it = rep["sources"][0]
    assert rep["n_problem"] == 1 and len(it["stale"]) == 1 and it["pending"] == 1 and it["n_missing"] >= 1
    c = app.test_client()
    login(c, "t_admin")
    html = c.get("/admin/sources/issues").get_data(as_text=True)
    assert "Tag ที่จับคู่แล้วไม่ส่งค่า 1 ตัว" in html and "ค่าจาก SCADA รอยืนยัน 1 รายการ" in html and "ดึงช่องที่ขาด" in html
    assert "ปัญหาที่ต้องจัดการ (1 แหล่ง)" in c.get("/admin/sources").get_data(as_text=True)
    page = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    for x in ('id="fcBulk"', "ใช้กับที่เลือก", "tm-prev", "เฉพาะรอบที่มี NG / เตือน"):
        assert x in page, x
    g = TM.group_tags(db, sid, CN.list_tags(db, sid), {})
    fid = published_form["form_id"]
    assert g["forms"][fid]["lim"]["oil"][:2] == [1.7, 2.5]                       # เกณฑ์สำหรับดูตัวอย่าง/เตือนหน่วย


def test_relay_updates_scada_values_in_human_submission(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    sid = _setup82(db, published_form, str(tmp_path / "h.db"))
    t = datetime.combine(S.now_dt().date() - timedelta(days=1), time(8, 30))
    rnd = _round(db, fid, t)
    admin = uid(db, "t_admin")
    ans = dict(GOOD, oil={"value": "2.2", "src": "scada"})                      # ช่างใช้ค่าจาก SCADA ไม่แก้
    res = SUB.create_submission(db, payload(published_form, ans, round_id=rnd["id"], finished_at=ts(t + timedelta(minutes=20)),
                                            scanned_at=ts(t)), {}, admin, app.config["UPLOAD_FOLDER"])
    db.commit()
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil", "scale": 0.5, "add_offset": 0}], None)
    r = SM.relay(db, sid, t.date(), t.date(), admin, {fid}, check_perm=False)
    db.commit()
    assert r["human_updated"] == 1
    a = db.execute("SELECT value_num, judgement FROM cs_answers WHERE submission_id=? AND item_key='oil'", (res["id"],)).fetchone()
    assert (a[0], a[1]) == (1.1, "ng")                                           # 2.2 × 0.5 = 1.1 < 1.7 → NG
    assert db.execute("SELECT ng_count FROM cs_submissions WHERE id=?", (res["id"],)).fetchone()[0] >= 1
    db.execute("UPDATE cs_answers SET value_src='', value_num=2.0 WHERE submission_id=? AND item_key='oil'", (res["id"],))
    SM.relay(db, sid, t.date(), t.date(), admin, {fid}, check_perm=False)
    assert db.execute("SELECT value_num FROM cs_answers WHERE submission_id=? AND item_key='oil'", (res["id"],)).fetchone()[0] == 2.0
