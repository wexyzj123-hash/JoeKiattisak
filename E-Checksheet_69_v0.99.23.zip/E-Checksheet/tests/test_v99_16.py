"""v0.99.16: ธีมห้องควบคุม · การ์ดสด · TV ห้องควบคุม · ช่องสั่งงาน Ctrl+K · สแกนเลเซอร์ · สรุปเปลี่ยนกะ"""
import json
from datetime import datetime, timedelta

from conftest import GOOD, login, uid
from test_submissions import submit

from ecs import shiftbrief as SB
from ecs.security import THEME_IDS

F = "%Y-%m-%d %H:%M:%S"


def test_control_theme_selectable(client):
    assert "control" in THEME_IDS
    tok = login(client, "t_admin")
    r = client.post("/api/account/theme", data=json.dumps({"theme": "control"}), content_type="application/json",
                    headers={"X-CSRF-Token": tok})
    assert r.status_code == 200
    html = client.get("/dashboard").get_data(as_text=True)
    assert 'data-theme="control"' in html and 'data-theme="control" title=' in html.replace("button type=\"button\" ", "")


def test_live_events_since(client, app, db, published_form):
    login(client, "t_admin")
    since = (datetime.now() - timedelta(seconds=5)).strftime(F)
    submit(app, db, published_form, GOOD)
    eq = published_form["equipment_id"]
    db.execute("INSERT INTO cs_downtime(equipment_id, start_at, reason, category) VALUES (?,?,?,?)", (eq, datetime.now().strftime(F), "x", "repair"))
    db.commit()
    j = client.get("/api/live?since=" + since).get_json()
    kinds = [e["kind"] for e in j["events"]]
    assert "sub" in kinds and "down" in kinds and j["now"]
    sub = next(e for e in j["events"] if e["kind"] == "sub")
    assert "ส่งผลตรวจ" in sub["title"] and sub["href"].startswith("/submissions/")
    assert "events" not in client.get("/api/live").get_json()                  # ไม่ส่ง since = แบบเดิม


def test_palette_search_and_actions(client, published_form):
    login(client, "t_admin")
    j = client.get("/api/palette?q=SCT0002").get_json()
    m = j["machines"][0]
    assert m["title"].startswith("SCT0002") and len(m["acts"]) == 4
    assert any("/equipment/" in a["u"] for a in m["acts"]) and any("/trends" in a["u"] for a in m["acts"])
    assert client.get("/api/palette?q=Daily").get_json()["forms"] and client.get("/api/palette?q=").get_json()["machines"] == []
    assert client.get("/api/palette?q=%25_").status_code == 200                # อักขระพิเศษไม่ทำให้ค้นผิด
    html = client.get("/dashboard").get_data(as_text=True)
    assert "js/palette.js" in html and "data-palette-open" in html and 'id="snFind"' in html   # ช่องค้นหาเมนูเดิมยังอยู่


def test_shift_window_and_brief(client, app, db, published_form):
    cal = {"shift_times": "08:00,20:00"}
    p, c, n = SB.shift_window(cal, datetime(2026, 10, 24, 9, 30))
    assert (p, c, n) == (datetime(2026, 10, 23, 20, 0), datetime(2026, 10, 24, 8, 0), datetime(2026, 10, 24, 20, 0))
    p, c, n = SB.shift_window(cal, datetime(2026, 10, 24, 3, 0))
    assert c == datetime(2026, 10, 23, 20, 0) and n == datetime(2026, 10, 24, 8, 0)
    b = SB.brief(db, uid(db, "t_admin"))
    for k in ("prev_sum", "carry", "missed", "down", "trend", "first", "key", "shift", "age_min"):
        assert k in b
    login(client, "t_tech")
    assert client.get("/api/shift-brief").status_code == 200
    assert "data-brief" in client.get("/m/").get_data(as_text=True)


def test_tv_control_room(client):
    login(client, "t_admin")
    html = client.get("/tv").get_data(as_text=True)
    assert html.count('class="tv-lamp') == 4 and "data-hud" in html and "data-rotate" in html and "tvVoice" in html
    assert 'id="c-comp"' in html                                                # ของเดิมยังอยู่
    r = client.get("/tv?rotate=1").get_data(as_text=True)
    assert "หยุดวนแสดง" in r
