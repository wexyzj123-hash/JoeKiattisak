"""v0.65: นำเข้าเฉพาะมิเตอร์ที่เลือก (แก้ชื่อ/Section/บทบาทก่อนนำเข้า · เฉพาะทะเบียน/เฉพาะค่าอ่าน) · ยกเลิกการนำเข้า ·
ทะเบียนมิเตอร์ ส่งออก Excel → แก้ → นำเข้ากลับ"""
import io
from datetime import date

from conftest import login, uid
from openpyxl import Workbook, load_workbook

from ecs import energy as EN
from ecs import energy_registry as REG


def _xlsx(month=9, with_total=True) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = str(month)
    ws.append(["ตารางบันทึก"])
    head = ["วันที่", "น้ำเข้าจากนิคม", "LINE A", "LINE B"] + (["รวมทั้งหมด"] if with_total else [])
    ws.append(head)
    ws.append([None, "m3", "No.1", "No.2"] + ([""] if with_total else []))
    for d in range(1, 21):
        ws.append([d, 1000 + d * 100, 50 + d * 3, 20 + d * 2] + ([3000 + d * 105] if with_total else []))
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


def test_selective_import_modes_and_undo(app, db):
    f1 = app.config["F1"]
    admin = uid(db, "t_admin")
    p = EN.parse_file(_xlsx(), "water.xlsx", 2026)
    pv = EN.preview(db, p, f1, "water")
    names = {m["idx"]: m for m in pv["meters"]}
    tot = next(m for m in pv["meters"] if "รวม" in m["name"] or "รวม" in m["grp"])
    assert tot["suspect"] and not any(m["suspect"] for m in pv["meters"] if m["idx"] != tot["idx"])
    keep = [m["idx"] for m in pv["meters"] if not m["suspect"]]
    first = keep[0]
    # เฉพาะทะเบียนมิเตอร์ + แก้ชื่อ/บทบาท
    r = EN.commit(db, p, f1, "water", 2026, "water.xlsx", admin, select=keep,
                  edits={str(first): {"name": "Raw water IN", "grp": "MAIN", "is_main": "1"}}, mode="meters")
    assert r["new_meters"] == len(keep) and r["readings"] == 0
    ms = EN.meters(db, f1, "water")
    assert len(ms) == len(keep) and not db.execute("SELECT 1 FROM en_readings").fetchone()
    assert any(m["name"] == "Raw water IN" and m["is_main"] == 1 and m["grp"] == "MAIN" for m in ms)
    # เฉพาะค่าอ่าน: แถวรวม (ยังไม่มีในระบบ) ถูกข้าม
    r2 = EN.commit(db, p, f1, "water", 2026, "water.xlsx", admin, select=[m["idx"] for m in pv["meters"]], mode="readings")
    assert r2["skipped_meters"] == 1 and r2["readings"] == 20 * len(keep) and r2["new_meters"] == 0
    # ทับค่า แล้วยกเลิก → คืนค่าเดิม
    some = ms[0]["id"]
    day = "2026-09-05"
    old = db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (some, day)).fetchone()[0]
    db.execute("UPDATE en_readings SET value=value+1 WHERE meter_id=? AND day=?", (some, day))
    r3 = EN.commit(db, p, f1, "water", 2026, "water.xlsx", admin, select=keep, overwrite=True)
    assert r3["changed"] == 1
    u = EN.undo_import(db, r3["import_id"], admin)
    assert u["restored"] == 1 and db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (some, day)).fetchone()[0] == old + 1
    # ยกเลิกการนำเข้าค่าอ่าน: ค่าที่แก้หลังนำเข้าไม่ถูกแตะ
    db.execute("UPDATE en_readings SET value=99999 WHERE meter_id=? AND day='2026-09-10'", (some,))
    u2 = EN.undo_import(db, r2["import_id"], admin)
    assert u2["kept"] == 2 and u2["removed"] == 20 * len(keep) - 2         # 05/09 (ถูกแก้ +1) และ 10/09
    import pytest
    from ecs.services import ValidationError
    with pytest.raises(ValidationError):
        EN.undo_import(db, r2["import_id"], admin)
    # ยกเลิกนำเข้าทะเบียน → ลบมิเตอร์ที่ไม่มีค่าอ่าน (ตัวที่ยังมีค่าที่แก้ไว้คงอยู่)
    u3 = EN.undo_import(db, r["import_id"], admin)
    assert u3["meters_removed"] == len(keep) - 1 and len(EN.meters(db, f1, "water", active_only=False)) == 1
    db.commit()


def test_registry_roundtrip(app, db):
    f1 = app.config["F1"]
    admin = uid(db, "t_admin")
    a = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "A1", "name": "Press", "grp": "LINE"}, admin)
    b = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "B1", "name": "Old", "grp": "LINE"}, admin)
    raw = REG.export_xlsx(db, f1)
    rows = REG.parse(raw)
    assert REG.plan(db, rows, admin)["count"]["same"] == 2
    wb = load_workbook(io.BytesIO(raw))
    ws = wb["ทะเบียนมิเตอร์"]
    for r in ws.iter_rows(min_row=2):
        if r[0].value == a:
            r[4].value = "Press line 1"
            r[10].value = 40
            r[12].value = "หลัก"
        if r[0].value == b:
            r[17].value = 1
    ws.append([None, "Factory 1", "น้ำใช้", "W9", "New water", "Canteen", "", "", "", "m³", 1, None, "ย่อย", 1, 5, "", "", None])
    ws.append([None, "Factory 9", "ไม่มีหมวด", "X", "bad", "", "", "", "abc", None, "?", 1, None, "", "", None])
    bio = io.BytesIO()
    wb.save(bio)
    rows = REG.parse(bio.getvalue())
    pl = REG.plan(db, rows, admin)
    c = pl["count"]
    assert c["update"] == 1 and c["delete"] == 1 and c["new"] == 1 and c["error"] == 1
    upd = next(x for x in pl["items"] if x["act"] == "update")
    assert set(upd["diff"]) == {"name", "multiplier", "is_main"}
    import pytest
    from ecs.services import ValidationError
    with pytest.raises(ValidationError):
        REG.apply(db, rows, admin)
    rows = [r for r in rows if r.get("code") != "X"]
    done = REG.apply(db, rows, admin)
    assert done == {"new": 1, "update": 1, "delete": 1, "deactivate": 0}
    m = EN.meter(db, a)
    assert m["name"] == "Press line 1" and m["multiplier"] == 40 and m["is_main"] == 1 and not EN.meter(db, b)
    w = db.execute("SELECT * FROM en_meters WHERE code='W9'").fetchone()
    assert w["kind"] == "water" and w["digits"] == 5 and w["grp"] == "Canteen"
    # มีค่าอ่านแล้ว → ปิดใช้งานแทนลบ
    EN.set_reading(db, a, date.today().isoformat(), 10, None)
    pl2 = REG.plan(db, [{"_row": 2, "id": a, "delete": 1}], admin)
    assert pl2["items"][0]["act"] == "deactivate"
    db.commit()


def test_pages_and_scope(app, client, db):
    f1, f2 = app.config["F1"], app.config["F2"]
    tok = login(client, "t_tech")
    assert client.get("/energy/import").status_code == 200
    assert client.get("/energy/import?tab=registry").status_code == 200
    r = client.post("/energy/import", data={"csrf_token": tok, "year": "2026", "kind": "water", "factory": str(f2),
                                            "file": (io.BytesIO(_xlsx()), "water.xlsx")}, content_type="multipart/form-data")
    assert r.status_code == 200 and b'name="sel"' in r.data and "เฉพาะทะเบียนมิเตอร์".encode() in r.data
    token = r.data.split(b'name="token" value="')[1].split(b'"')[0].decode()
    r = client.post("/energy/import/confirm", data={"csrf_token": tok, "token": token, "factory": str(f2), "kind": "water",
                                                    "mode": "all", "sel_present": "1", "sel": ["0", "1"], "name_0": "IN main", "main_0": "1", "main0_0": "0"})
    assert r.status_code == 302
    ms = EN.meters(db, None, "water")
    assert len(ms) == 2 and all(m["factory_id"] == f1 for m in ms)      # ช่างถูกบังคับเป็นโรงงานตัวเอง
    assert any(m["name"] == "IN main" and m["is_main"] == 1 for m in ms)
    iid = db.execute("SELECT MAX(id) FROM en_imports").fetchone()[0]
    r = client.get("/energy/import")
    assert "ยกเลิกการนำเข้า".encode() in r.data
    # registry export/upload/confirm
    r = client.get("/energy/meters.xlsx")
    assert r.status_code == 200 and r.data[:2] == b"PK"
    wb = load_workbook(io.BytesIO(r.data))
    ws = wb["ทะเบียนมิเตอร์"]
    ws.cell(row=2, column=6).value = "NEW SECTION"
    bio = io.BytesIO()
    wb.save(bio)
    r = client.post("/energy/import/registry", data={"csrf_token": tok, "file": (io.BytesIO(bio.getvalue()), "reg.xlsx")},
                    content_type="multipart/form-data")
    assert r.status_code == 200 and "แก้ไข".encode() in r.data
    rtoken = r.data.split(b'name="token" value="')[1].split(b'"')[0].decode()
    r = client.post("/energy/import/registry/confirm", data={"csrf_token": tok, "token": rtoken})
    assert r.status_code == 302 and any(m["grp"] == "NEW SECTION" for m in EN.meters(db, None, "water"))
    # ยกเลิกการนำเข้าของตัวเองได้ · ช่างคนอื่นไม่ได้
    tok2 = login(client, "t_tech2")
    client.post(f"/energy/import/{iid}/undo", data={"csrf_token": tok2})
    assert not db.execute("SELECT undone_at FROM en_imports WHERE id=?", (iid,)).fetchone()[0]
    tok = login(client, "t_tech")
    assert client.post(f"/energy/import/{iid}/undo", data={"csrf_token": tok}).status_code == 302
    assert db.execute("SELECT undone_at FROM en_imports WHERE id=?", (iid,)).fetchone()[0]


def test_meters_bulk(app, client, db):
    f1, f2 = app.config["F1"], app.config["F2"]
    ids = [EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": f"K{i}", "name": f"K{i}"}, None) for i in range(3)]
    other = EN.save_meter(db, None, {"factory_id": f2, "kind": "elec", "code": "Z", "name": "Z"}, None)
    EN.set_reading(db, ids[0], date.today().isoformat(), 5, None)
    db.commit()
    tok = login(client, "t_tech")
    client.post("/energy/meters/bulk", data={"csrf_token": tok, "act": "grp", "grp": "PANEL A", "ids": [str(i) for i in ids] + [str(other)]})
    assert {EN.meter(db, i)["grp"] for i in ids} == {"PANEL A"} and EN.meter(db, other)["grp"] == ""
    client.post("/energy/meters/bulk", data={"csrf_token": tok, "act": "delete", "ids": [str(i) for i in ids]})
    assert EN.meter(db, ids[0]) and not EN.meter(db, ids[1]) and not EN.meter(db, ids[2])     # มีค่าอ่าน → ไม่ลบ
    client.post("/energy/meters/bulk", data={"csrf_token": tok, "act": "off", "ids": [str(ids[0])]})
    assert EN.meter(db, ids[0])["active"] == 0
