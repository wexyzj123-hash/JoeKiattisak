"""v0.79: ทดสอบการเชื่อมต่อจำรายชื่อ Tag · ปุ่มค้นหา Tag · การ์ดแยกตามเครื่องที่ยังไม่มีแบบฟอร์ม · สถานะครบ = ทุกหัวข้อมี Tag"""
import sqlite3

from conftest import login

from ecs import connectors as CN
from ecs import services as S
from ecs import tagmatch as TM
from ecs.services import ts


def _src(db, tmp_path, tags):
    path = str(tmp_path / "scada.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    con.executemany("INSERT INTO h VALUES (?,?,?)", [(t, ts(S.now_dt()), 1.5) for t in tags])
    con.commit()
    con.close()
    sid = CN.save_source(db, {"name": "SCADA", "kind": "sqlite", "bucket_min": 60, "agg": "last",
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                         "backfill_days": 1}}, None)
    db.commit()
    return sid


def _n(db, sid):
    return db.execute("SELECT COUNT(*) FROM cs_source_tags WHERE source_id=?", (sid,)).fetchone()[0]


def test_test_connection_and_discover_keep_tags(app, db, tmp_path):
    sid = _src(db, tmp_path, ["data:F2.SCT0018.A", "data:F2.SCT0018.B"])
    c = app.test_client()
    tok = login(c, "t_admin")
    html = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert "ค้นหา Tag จากแหล่งข้อมูล" in html
    r = c.post(f"/admin/sources/{sid}/test", json={}, headers={"X-CSRF-Token": tok})
    assert r.status_code == 200 and len(r.get_json()["tags"]) == 2
    assert _n(db, sid) == 2                                         # ไม่หายหลังทดสอบ
    assert db.execute("SELECT COUNT(*) FROM cs_submissions").fetchone()[0] == 0
    db.execute("DELETE FROM cs_source_tags WHERE source_id=?", (sid,))
    db.commit()
    r = c.post(f"/admin/sources/{sid}/discover", data={"csrf_token": tok})
    assert r.status_code == 302 and _n(db, sid) == 2
    html = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert "SCT0018" in html and "เลือกแบบฟอร์มให้ทั้งการ์ด" in html


def test_unknown_split_by_device_and_status(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    eq = db.execute("SELECT e.code FROM cs_forms f JOIN equipment e ON e.id=f.equipment_id WHERE f.id=?", (fid,)).fetchone()[0]
    keys = [r[0] for r in db.execute("""SELECT i.item_key FROM cs_forms f JOIN cs_form_items i ON i.version_id=f.current_version_id
                                        WHERE f.id=? AND i.item_type IN ('number','counter')""", (fid,))]
    tags = [f"d.{eq}.T{k}" for k in keys] + [f"d.{eq}.EXTRA", "d.ZZ01.A", "d.ZZ01.B", "d.ZZ02.A", "LONE"]
    sid = _src(db, tmp_path, tags)
    CN.preview(db, sid)
    CN.save_mapping(db, sid, [{"tag": f"d.{eq}.T{k}", "target": f"{fid}:{k}"} for k in keys], None)
    db.commit()
    g = TM.group_tags(db, sid, CN.list_tags(db, sid), {})
    by = {x["gid"]: x for x in g["groups"]}
    assert by[f"g{fid}"]["status"] == "ok" and by[f"g{fid}"]["n_unmapped"] == 1    # Tag เหลือไม่ใช้ ยังถือว่าครบ
    unk = [x for x in g["groups"] if not x["form_id"]]
    assert [x["eq_code"] for x in unk] == ["ZZ01", "ZZ02", ""]                     # แยกการ์ดตามเครื่อง · ไม่รู้เครื่องอยู่ท้าย
    assert len(unk[0]["tags"]) == 2
    c = app.test_client()
    login(c, "t_admin")
    html = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    for s in ("ใช้แบบนี้กับเครื่องอื่น", "เลือกแบบฟอร์มให้ทั้งการ์ด", 'data-short="', "ค้นหา Tag ใหม่", "ครบทุกหัวข้อ"):
        assert s in html, s
