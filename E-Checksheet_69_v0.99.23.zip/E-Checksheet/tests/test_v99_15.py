"""v0.99.15: เพิ่มลูกเล่นโลกอนาคต — แผงเวลา HUD · วงแหวนเกจ · คลื่นแสง · ข้อความแจ้งผล (ของเดิมครบ)"""
from datetime import datetime, timedelta

from conftest import login

from ecs.views.dash import _hud


def test_hud_on_today_only(client):
    login(client, "t_admin")
    html = client.get("/dashboard").get_data(as_text=True)
    assert "data-hud" in html and "data-hud-clock" in html and 'data-shifts="' in html
    old = (datetime.now() - timedelta(days=3)).date().isoformat()
    assert "data-hud" not in client.get(f"/dashboard?date={old}").get_data(as_text=True)


def test_hud_next_deadline_picks_earliest_open_round(app, db):
    now = datetime.now()
    f = lambda m: (now + timedelta(minutes=m)).strftime("%Y-%m-%d %H:%M:%S")
    rows = [{"status": "pending", "deadline_at": f(90)}, {"status": "in_progress", "deadline_at": f(30)},
            {"status": "pending", "deadline_at": f(30)}, {"status": "overdue", "deadline_at": f(-10)},
            {"status": "done_on_time", "deadline_at": f(5)}, {"status": "pending", "deadline_at": f(-5)}]
    h = _hud(db, rows)
    assert h["next"] == f(30) and h["next_n"] == 2
    assert h["shifts"] and all(x.isdigit() for x in h["shifts"].split(","))
    assert _hud(db, [{"status": "done_late", "deadline_at": f(10)}])["next"] == ""


def test_rings_only_with_values(client):
    login(client, "t_admin")
    html = client.get("/dashboard").get_data(as_text=True)
    assert html.count('class="kx-ring') <= 2
    assert "kx-v" in html and "data-count" in html                 # ตัวเลขเดิมยังอยู่
