"""v0.66: ออกแบบแบบฟอร์มการจดเอง — เลือกมิเตอร์ · เรียงลำดับ · หัวข้อคั่น · บังคับรูป/คำแนะนำ — ใช้ในมือถือและตารางบันทึกค่า"""
import io
import json
from datetime import date, timedelta

import pytest
from conftest import login, uid

from ecs import energy as EN
from ecs import energy_field as EF
from ecs import energy_forms as FM
from ecs.services import ValidationError

TODAY = date.today()


def _mk(db, fid, code, kind="elec", grp="G"):
    mid = EN.save_meter(db, None, {"factory_id": fid, "kind": kind, "code": code, "name": code, "grp": grp}, None)
    for i in range(6, 0, -1):
        EN.set_reading(db, mid, (TODAY - timedelta(days=i)).isoformat(), 1000 + (6 - i) * 10, None)
    return mid


def test_form_crud_and_order(app, db):
    f1, f2 = app.config["F1"], app.config["F2"]
    a, b, c = _mk(db, f1, "A"), _mk(db, f1, "B", "water", "W"), _mk(db, f1, "C")
    x = _mk(db, f2, "X")
    tech = uid(db, "t_tech")
    items = [{"type": "header", "title": "ห้อง MDB"}, {"type": "meter", "meter_id": c, "hint": "อ่านจอบน"},
             {"type": "meter", "meter_id": a, "photo": 1}, {"type": "header", "title": "บ่อน้ำ"}, {"type": "meter", "meter_id": b},
             {"type": "meter", "meter_id": a}]                  # ซ้ำ → ตัดทิ้ง
    fid = FM.save(db, None, {"name": "รอบเช้า", "factory_id": f2, "items": items}, tech)
    f = FM.form(db, fid)
    assert f["factory_id"] == f1                                 # ช่างถูกบังคับโรงงานตัวเอง
    assert [(i["type"], i["meter_id"] or i["title"]) for i in f["items"]] == [("header", "ห้อง MDB"), ("meter", c), ("meter", a),
                                                                              ("header", "บ่อน้ำ"), ("meter", b)]
    assert FM.meter_ids(db, fid) == [c, a, b]
    with pytest.raises(ValidationError):
        FM.save(db, None, {"name": "x", "items": [{"type": "meter", "meter_id": x}]}, tech)     # มิเตอร์ต่างโรงงาน
    with pytest.raises(ValidationError):
        FM.save(db, None, {"name": "ว่าง", "items": [{"type": "header", "title": "h"}]}, tech)
    # เรียงใหม่
    FM.save(db, fid, {"name": "รอบเช้า", "items": [{"type": "meter", "meter_id": b}, {"type": "meter", "meter_id": a}]}, tech)
    assert FM.meter_ids(db, fid) == [b, a]
    cp = FM.copy(db, fid, tech)
    assert FM.form(db, cp)["name"].endswith("(สำเนา)") and FM.meter_ids(db, cp) == [b, a]
    # ช่างโรงงาน 2 แก้ไม่ได้
    with pytest.raises(ValidationError):
        FM.save(db, fid, {"name": "hack", "items": [{"type": "meter", "meter_id": x}]}, uid(db, "t_tech2"))
    draft = FM.from_sections(db, f1)
    assert draft[0]["type"] == "header" and sum(1 for d in draft if d["type"] == "meter") == 3
    FM.delete(db, cp, tech)
    assert FM.form(db, cp) is None
    # มือถือ: แพ็กมีแบบฟอร์ม · รูปบังคับตามแบบฟอร์ม
    FM.save(db, fid, {"name": "รอบเช้า", "items": [{"type": "meter", "meter_id": a, "photo": 1, "hint": "h"}]}, tech)
    pk = EF.pack(db, tech, f1)
    assert pk["forms"][0]["items"][0] == {"type": "meter", "meter_id": a, "title": "", "photo": 1, "hint": "h"}
    with pytest.raises(ValidationError) as e:
        EF.submit(db, {"meter_id": a, "day": TODAY.isoformat(), "value": 1060, "form_id": fid}, {}, tech, "/tmp/up")
    assert "รูป" in e.value.errors[0]
    assert EF.submit(db, {"meter_id": a, "day": TODAY.isoformat(), "value": 1060}, {}, tech, "/tmp/up")["level"] == "ok"
    db.commit()


def test_pages(app, client, db):
    f1 = app.config["F1"]
    a, b = _mk(db, f1, "A"), _mk(db, f1, "B", "water")
    db.commit()
    tok = login(client, "t_tech")
    assert client.get("/energy/forms").status_code == 200
    r = client.get("/energy/forms/new?draft=1")
    assert r.status_code == 200 and b"fbData" in r.data
    r = client.post("/energy/forms/save", json={"name": "รอบบ่าย", "items": [{"type": "header", "title": "จุด 1"},
                                                                            {"type": "meter", "meter_id": b, "hint": "ดูหน้าปัดซ้าย"},
                                                                            {"type": "meter", "meter_id": a}]},
                    headers={"X-CSRF-Token": tok})
    assert r.status_code == 200 and r.get_json()["ok"]
    fid = r.get_json()["id"]
    assert client.get(f"/energy/forms/{fid}").status_code == 200
    r = client.get(f"/energy/entry?form={fid}&factory={f1}")
    html = r.get_data(as_text=True)
    assert r.status_code == 200 and "จุด 1" in html and "ดูหน้าปัดซ้าย" in html and html.index('data-id="%d"' % b) < html.index('data-id="%d"' % a)
    # บันทึกข้ามหมวดในแบบฟอร์มเดียว
    r = client.post(f"/energy/entry?form={fid}&factory={f1}", json={"day": TODAY.isoformat(), "values": {str(a): "1060", str(b): "1065"}},
                    headers={"X-CSRF-Token": tok})
    assert r.status_code == 200 and r.get_json()["new"] == 2
    r = client.post(f"/energy/forms/{fid}/act", data={"csrf_token": tok, "act": "copy"})
    assert r.status_code == 302
    assert len(FM.forms(db)) == 2
    r = client.get("/api/m/energy/pack").get_json()
    assert {f["name"] for f in r["forms"]} >= {"รอบบ่าย"}
    r = client.post("/energy/forms/save", json={"name": "", "items": []}, headers={"X-CSRF-Token": tok})
    assert r.status_code == 422
