"""v0.31: QR จุดตรวจ — ไม่หลุดแบบฟอร์มหลัง login ใหม่ · ถ่ายรูป QR อ่านในหน้าเว็บ (ไม่ต้องใช้แอปกล้องนอกเว็บ)"""
from conftest import login


def test_point_qr_login_keeps_form(app, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    r = c.get(f"/p/{fid}/afdr2m")
    assert r.status_code == 302 and "/login" in r.headers["Location"] and f"next=/p/{fid}/afdr2m" in r.headers["Location"]
    page = c.get(r.headers["Location"]).get_data(as_text=True)
    assert "location.hash" in page                                   # เก็บ #… ไว้ใน next
    login(c, "t_tech")
    r = c.get(f"/p/{fid}/afdr2m")
    assert r.headers["Location"].endswith(f"/m/fill#f={fid}&pt=AFDR2M")


def test_photo_qr_assets(app):
    c = app.test_client()
    login(c, "t_tech")
    assert "photoBtn" in c.get("/m/scan").get_data(as_text=True)
    js = c.get("/static/m/jsqr.js")
    assert js.status_code == 200 and b"jsQR" in js.data
    core = open(app.root_path + "/static/m/core.js", encoding="utf-8").read()
    assert "photoQR" in core and "capture" in core
    fill = open(app.root_path + "/static/m/fill.js", encoding="utf-8").read()
    assert "ECS.photoQR()" in fill
