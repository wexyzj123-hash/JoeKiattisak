"""v0.99.11 เอกสารรายงานรายเดือน · รายการผิดปกติและการแก้ไข
- NG / ช่วงเตือนที่ลบออกจากรายการแจ้งเตือนแล้ว (พร้อมเหตุผล) → ไม่อยู่ในรายการผิดปกติ และไม่นับในสรุป
- ช่วงเครื่องสำรอง / ไม่ได้เดิน → ไม่ใช่ความผิดปกติ (ซ่อม / PM ยังแสดง)"""
import json
from datetime import date, datetime, timedelta

from conftest import GOOD, uid
from test_submissions import submit

from ecs import anomaly as A
from ecs import sheet_report as SR

NG = dict(GOOD, oil={"value": "2.45", "remark": "สูง"})     # Oil Pressure ช่วงเตือน (2.4–2.5) — ไม่ต้องแนบรูป
F = "%Y-%m-%d %H:%M:%S"


def _sheet(db, form):
    return SR.build_month_sheet(db, form["form_id"], date.today().replace(day=1), "s")


def _ng_rows(sheet):
    return [n for n in sheet["ng_list"] if n["judgement"] in ("ng", "warn")]


def test_deleted_ng_alert_is_not_in_report(app, db, published_form):
    res, _ = submit(app, db, published_form, NG)
    sh = _sheet(db, published_form)
    assert [n["item"] for n in _ng_rows(sh)] == ["Oil Pressure"] and sh["summary"]["warn"] == 1
    code0 = sh.get("doc_no"), json.dumps(sh.get("verify") or "", default=str)
    al = db.execute("SELECT id FROM cs_alerts WHERE alert_type='warn' AND submission_id=?", (res["id"],)).fetchone()
    assert al, "ต้องมีแจ้งเตือน NG"
    assert A.delete_alerts(db, [al["id"]], uid(db, "t_admin"), "ค่ามิเตอร์อ่านผิด ตรวจซ้ำแล้วปกติ", any_type=True) == 1
    db.commit()
    sh = _sheet(db, published_form)
    assert _ng_rows(sh) == [] and sh["summary"]["warn"] == 0
    # ค่าที่บันทึกยังอยู่ครบ (เอกสารยังแสดงค่าในตาราง)
    assert db.execute("SELECT judgement FROM cs_answers WHERE submission_id=? AND item_key='oil'", (res["id"],)).fetchone()[0] == "warn"
    assert code0 is not None


def test_repeat_occurrences_in_same_alert_are_all_dismissed_but_later_ng_shows(app, db, published_form):
    submit(app, db, published_form, NG)
    submit(app, db, published_form, dict(NG, hour={"value": "1010"}))
    al = db.execute("SELECT id, occurrences FROM cs_alerts WHERE alert_type='warn'").fetchone()
    assert al["occurrences"] == 2
    A.delete_alerts(db, [al["id"]], uid(db, "t_admin"), "เซนเซอร์เสีย", any_type=True)
    db.commit()
    assert _ng_rows(_sheet(db, published_form)) == []
    submit(app, db, published_form, dict(NG, hour={"value": "1020"}))       # NG ใหม่หลังลบ → ต้องแสดง
    assert len(_ng_rows(_sheet(db, published_form))) == 1


def test_alerts_deleted_before_upgrade_are_backfilled_from_audit(app, db, published_form):
    res, _ = submit(app, db, published_form, NG)
    al = dict(db.execute("SELECT * FROM cs_alerts WHERE alert_type='warn'").fetchone())
    # เวอร์ชันเก่า: ลบแจ้งเตือน = บันทึก Audit + ลบแถว (ไม่มีตาราง dismiss)
    db.execute("""INSERT INTO cs_audit(actor_id, action, entity, entity_id, before_json, after_json, created_at)
                  VALUES (?, 'delete', 'cs_alerts', ?, ?, ?, ?)""",
               (uid(db, "t_admin"), al["id"], json.dumps(al), json.dumps({"reason": "ค่าผิด"}), datetime.now().strftime(F)))
    db.execute("DELETE FROM cs_alert_events WHERE alert_id=?", (al["id"],))
    db.execute("DELETE FROM cs_alerts WHERE id=?", (al["id"],))
    db.execute("DELETE FROM cs_meta WHERE key='ng_dismiss_backfill'")
    db.commit()
    assert _ng_rows(_sheet(db, published_form)) == []
    assert db.execute("SELECT reason FROM cs_ng_dismiss WHERE submission_id=?", (res["id"],)).fetchone()[0] == "ค่าผิด"


def test_closed_alert_still_listed(app, db, published_form):
    """ปิดแจ้งเตือน (แก้ไขปัญหาแล้ว) ≠ ลบ → ยังเป็นรายการผิดปกติที่มีการแก้ไข"""
    submit(app, db, published_form, NG)
    db.execute("UPDATE cs_alerts SET status='closed' WHERE alert_type='warn'")
    db.commit()
    assert len(_ng_rows(_sheet(db, published_form))) == 1


def test_no_downtime_rows_in_abnormal_list(app, db, published_form):
    """v0.99.12 ช่วงเครื่องหยุดทุกประเภท (สำรอง · ซ่อม · PM · หยุดตามแผน · อื่น ๆ) ไม่อยู่ในรายการผิดปกติ"""
    eq = published_form["equipment_id"]
    now = datetime.now()
    base = now.replace(day=1, hour=0, minute=30, second=0, microsecond=0)
    if now - base < timedelta(hours=12):
        base = now - timedelta(hours=12)
    for i, cat in enumerate(("standby", "repair", "pm", "stop", "other")):
        st = base + timedelta(hours=2 * i)
        db.execute("INSERT INTO cs_downtime(equipment_id, start_at, end_at, reason, category) VALUES (?,?,?,?,?)",
                   (eq, st.strftime(F), (st + timedelta(hours=1)).strftime(F), "x", cat))
    db.commit()
    sh = _sheet(db, published_form)
    assert not [n for n in sh["ng_list"] if n["judgement"] == "down"]
    assert len(sh["grid"]["downtime"]) == 5                 # ตารางยังแสดงช่องเครื่องหยุดครบ


def test_scada_values_not_in_abnormal_list(app, db, published_form):
    """v0.99.12 ค่าจาก SCADA (ผลตรวจอัตโนมัติ / ค่าที่เติมจาก SCADA / ค่าที่ผู้ดูแลแก้) ไม่อยู่ในรายการผิดปกติ — ค่าที่ช่างกรอกเองยังอยู่"""
    r_auto, _ = submit(app, db, published_form, NG)
    db.execute("UPDATE cs_submissions SET source='auto' WHERE id=?", (r_auto["id"],))
    r_fill, _ = submit(app, db, published_form, dict(NG, hour={"value": "1010"}))
    db.execute("UPDATE cs_answers SET value_src='scada' WHERE submission_id=? AND item_key='oil'", (r_fill["id"],))
    r_fix, _ = submit(app, db, published_form, dict(NG, hour={"value": "1020"}))
    db.execute("UPDATE cs_answers SET value_src='fixed' WHERE submission_id=? AND item_key='oil'", (r_fix["id"],))
    db.commit()
    sh = _sheet(db, published_form)
    assert _ng_rows(sh) == [] and sh["summary"]["warn"] == 0
    submit(app, db, published_form, dict(NG, hour={"value": "1030"}))      # ช่างกรอกเอง → แสดง
    sh = _sheet(db, published_form)
    assert len(_ng_rows(sh)) == 1 and sh["summary"]["warn"] == 1
