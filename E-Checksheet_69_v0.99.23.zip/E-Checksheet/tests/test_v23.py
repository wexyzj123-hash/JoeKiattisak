"""v0.23: หัวหน้างานช่องเดียว (ดึงจากการอนุมัติในระบบ) · กล่องหน่วยงานมุมขวาบน · ENVIRONMENT / SAFETY แยกเอกสาร"""
import io
from datetime import date

from conftest import login
from openpyxl import load_workbook

from ecs import sign_blocks as SB
from ecs import sheet_report as SR


def test_one_department_per_document():
    # รูปแบบเดิม (เลือกทั้ง 2 กล่อง + แถวปน) → เหลือหน่วยงานเดียว
    cfg = SB.parse({"rows": ["env_week", "safety_month", "sup_week"], "boxes": ["safety", "env"]})
    assert cfg["boxes"] == ["safety"] and cfg["rows"] == ["safety_month"]
    cfg = SB.parse({"rows": ["env_week", "safety_month"]})              # ไม่มีกล่อง → ใช้หน่วยงานของแถวแรก
    assert cfg["boxes"] == [] and cfg["rows"] == ["env_week"]
    assert "sup_week" not in SB.PRESET_ROWS
    from werkzeug.datastructures import MultiDict
    cfg = SB.from_form(MultiDict([("sb_dept", "env"), ("sb_rows", "env_week"), ("sb_rows", "safety_month")]))
    assert cfg == {"rows": ["env_week"], "custom_rows": [], "boxes": ["env"]} and SB.dept(cfg) == "env"
    assert SB.from_form(MultiDict([("sb_dept", "")]))["boxes"] == []


def test_supervisor_row_and_box_top_right(app, db, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get(f"/forms/{fid}").get_data(as_text=True)
    assert 'type="radio" name="sb_dept"' in page
    c.post(f"/forms/{fid}/sign-config", data={"csrf_token": tok, "sb_dept": "safety", "sb_rows": ["safety_month"]})
    month = date.today().replace(day=1)
    html = c.get(f"/reports/sheets?form={fid}&month={month:%Y-%m}").get_data(as_text=True).split("</style>")[1]
    assert "ผู้อนุมัติ (หัวหน้างาน)" not in html and "หัวหน้างาน (Sr.Tech)" in html
    assert "Approved by)</div>" not in html.replace("Checked &amp; Approved by)", "")
    hd = html[html.index('<table class="hd">'):]
    hd = hd[:hd.index("</tr></table>")]
    assert 'class="xside"' in hd and "SAFETY" in hd and "MANAGER" not in html
    sheet = SR.build_month_sheet(db, fid, month, "s")
    ws = load_workbook(io.BytesIO(SR.to_excel([sheet]))).worksheets[0]
    top = {str(ws.cell(r, cc).value) for r in range(1, 8) for cc in range(1, ws.max_column + 1) if ws.cell(r, cc).value}
    assert {"DM", "SAFETY", "ตรวจสอบและอนุมัติเอกสารหลังใช้งาน"} <= top
    allv = {str(ws.cell(r, cc).value) for r in range(1, ws.max_row + 1) for cc in range(1, ws.max_column + 1) if ws.cell(r, cc).value}
    assert "หัวหน้างาน (Sr.Tech)" in allv and "หัวหน้างาน (SV/SSV)" in allv and "ผู้อนุมัติ (Approved by)" not in allv
