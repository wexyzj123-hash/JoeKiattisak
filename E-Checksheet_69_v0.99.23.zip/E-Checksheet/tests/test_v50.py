"""v0.50: ภาษากลางของสถานะ · ตารางกะ (เชื่อม UT-CMMS) + มอบหมายโรงงาน · หน้าต้องจัดการวันนี้ · NG ที่ฉันแจ้ง"""
import sqlite3
from datetime import date, datetime, timedelta

import pytest
from conftest import login, uid

from ecs import anomaly as A
from ecs import roster as RO
from ecs import services as S
from ecs import submissions as SUB
from ecs import terms as TR
from ecs import today as TD


def _monday() -> date:
    d = S.now_dt().date() + timedelta(days=7)
    return d - timedelta(days=d.weekday())


def _round(db, fid, due: datetime, mins=120, status="pending"):
    sid = db.execute("SELECT id FROM cs_schedules WHERE form_id=? LIMIT 1", (fid,)).fetchone()
    sid = sid[0] if sid else S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00"}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    rid = db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                        VALUES (?,?,?,?,?,?,?)""", (sid, fid, S.ts(due), S.ts(due + timedelta(minutes=mins)),
                                                     S.ts(due + timedelta(minutes=mins * 2)), status, S.ts(due))).lastrowid
    db.commit()
    return rid


def _ids(t, *keys):
    return [r["id"] for k in keys for r in t["groups"][k]]


def test_terms_single_source():
    from ecs import reports
    from ecs.views import forms
    assert forms.ROUND_STATUS_TH["missed"] == TR.label("ROUND", "missed") == "ขาดตรวจ"
    assert reports.STATUS_TH["acknowledged"] == "รับทราบแล้ว"
    js = TR.js()
    assert js["SHIFT"]["night_shift"][0] == "กะดึก" and set(js) >= {"ROUND", "ALERT", "SHIFT", "JUDGE"}


def test_status_help_page_and_mobile_terms(app, client, db):
    login(client, "t_tech")
    html = client.get("/help/status").get_data(as_text=True)
    assert "ขาดตรวจ" in html and "กะดึก" in html and "window.print" in html
    m = client.get("/m/").get_data(as_text=True)
    assert "window.ECS_T=" in m


def test_assign_factories_limits_my_tasks(app, db, published_form):
    fid = published_form["form_id"]
    rid = _round(db, fid, S.now_dt() - timedelta(minutes=10), mins=600)
    tech = uid(db, "t_tech")
    assert rid in _ids(SUB.my_tasks(db, tech), "due", "overdue")
    RO.set_factories(db, tech, [app.config["F2"]], uid(db, "t_admin"))       # ย้ายไปรับผิดชอบโรงงาน 2
    db.commit()
    assert rid not in _ids(SUB.my_tasks(db, tech), "due", "overdue", "upcoming", "other")
    RO.set_factories(db, tech, [app.config["F1"], app.config["F2"]], uid(db, "t_admin"))   # 2 โรงงาน
    db.commit()
    assert rid in _ids(SUB.my_tasks(db, tech), "due", "overdue")
    assert RO.factories_of(db, tech) == sorted([app.config["F1"], app.config["F2"]])


def _two_techs(app, db):
    a, b = uid(db, "t_tech"), uid(db, "t_tech2")
    RO.set_factories(db, b, [app.config["F1"]], uid(db, "t_admin"))           # ช่าง 2 คนในโรงงาน 1
    db.commit()
    return a, b


def test_roster_moves_other_shift_rounds(app, db, published_form):
    fid = published_form["form_id"]
    a, b = _two_techs(app, db)
    mon = _monday()
    now = datetime.combine(mon, datetime.min.time()) + timedelta(hours=9)
    rid = _round(db, fid, now + timedelta(hours=1))                           # รอบ 10:00–12:00 (กลางวัน)
    RO.set_plans(db, [{"user_id": a, "date": mon.isoformat(), "shift_type": "night_shift"}], uid(db, "t_admin"))
    db.commit()
    ta = SUB.my_tasks(db, a, now)
    assert rid in _ids(ta, "other") and rid not in _ids(ta, "due", "upcoming")
    other = next(r for r in ta["groups"]["other"] if r["id"] == rid)
    assert "t_tech2" in other["owners"] and "กะเช้า" in other["owners"]
    assert ta["duty"]["key"] == "night_shift" and ta["duty"]["window"] == "17:00–08:00"
    tb = SUB.my_tasks(db, b, now)
    assert rid in _ids(tb, "due", "upcoming")
    # รอบกลางคืน 22:00 → ของช่างกะดึก
    rid2 = _round(db, fid, now + timedelta(hours=13), mins=60)
    assert rid2 in _ids(SUB.my_tasks(db, a, now), "upcoming", "due")
    assert rid2 in _ids(SUB.my_tasks(db, b, now), "other")
    # ปิดการกรอง → เห็นทุกกะ
    RO.save_settings(db, {"filter": ""}, uid(db, "t_admin"))
    db.commit()
    assert rid2 in _ids(SUB.my_tasks(db, b, now), "upcoming", "due")


def test_uncovered_round_shown_to_everyone(app, db, published_form):
    fid = published_form["form_id"]
    a, b = _two_techs(app, db)
    mon = _monday()
    now = datetime.combine(mon, datetime.min.time()) + timedelta(hours=9)
    rid = _round(db, fid, now + timedelta(hours=1))
    RO.set_plans(db, [{"user_id": a, "date": mon.isoformat(), "shift_type": "day_off"},
                      {"user_id": b, "date": mon.isoformat(), "shift_type": "sick"}], uid(db, "t_admin"))
    db.commit()
    t = SUB.my_tasks(db, a, now)
    row = next(r for k in ("due", "upcoming") for r in t["groups"][k] if r["id"] == rid)
    assert row.get("uncovered") is True
    assert t["duty"]["key"] == "day_off" and not t["duty"]["on_now"]


def test_carry_over_from_previous_shift(app, db, published_form):
    fid = published_form["form_id"]
    a, b = _two_techs(app, db)
    mon = _monday()
    now = datetime.combine(mon, datetime.min.time()) + timedelta(hours=9)
    RO.set_plans(db, [{"user_id": b, "date": (mon - timedelta(days=1)).isoformat(), "shift_type": "night_shift"}], uid(db, "t_admin"))
    db.commit()
    rid = _round(db, fid, now - timedelta(hours=4), mins=180)                # 05:00–08:00 (กะดึก) ยังไม่ส่ง
    t = SUB.my_tasks(db, a, now)                                               # กะเช้าเห็นเป็นงานค้างจากกะก่อน
    row = next(r for r in t["groups"]["overdue"] if r["id"] == rid)
    assert row.get("carry") is True


def test_roster_routes_and_assign_page(app, client, db):
    tok = login(client, "t_sup")
    a = uid(db, "t_tech")
    res = client.post("/admin/roster/save", json={"items": [{"user_id": a, "date": "2026-11-02", "shift_type": "ot"}]},
                      headers={"X-CSRF-Token": tok})
    assert res.get_json() == {"ok": True, "saved": 1}
    assert db.execute("SELECT shift_type FROM cs_shift_plan WHERE user_id=?", (a,)).fetchone()[0] == "ot"
    bad = client.post("/admin/roster/save", json={"items": [{"user_id": a, "date": "2026-11-02", "shift_type": "xx"}]},
                      headers={"X-CSRF-Token": tok})
    assert bad.status_code == 400
    html = client.get("/admin/roster?month=2026-11").get_data(as_text=True)
    assert "ตารางกะช่าง" in html and "t-ot" in html
    client.post("/admin/roster/save", json={"items": [{"user_id": a, "date": "2026-11-02", "shift_type": ""}]},
                headers={"X-CSRF-Token": tok})
    assert db.execute("SELECT COUNT(*) FROM cs_shift_plan WHERE user_id=?", (a,)).fetchone()[0] == 0
    page = client.get("/admin/assign").get_data(as_text=True)
    assert "มอบหมายโรงงาน" in page
    client.post("/admin/assign", data={"csrf_token": tok, f"seen.{a}": "1", f"fac.{a}": [str(app.config["F1"]), str(app.config["F2"])]})
    assert len(RO.factories_of(db, a)) == 2
    login(client, "t_tech")
    assert client.get("/admin/roster").status_code == 403


@pytest.fixture()
def cmms(app, tmp_path):
    path = tmp_path / "cmms.db"
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, name TEXT, role TEXT);
    CREATE TABLE tech_shift_plan (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, plan_date TEXT NOT NULL,
      shift_type TEXT NOT NULL DEFAULT 'ot', notes TEXT DEFAULT '', set_by INTEGER, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, plan_date));
    CREATE TABLE holidays (id INTEGER PRIMARY KEY AUTOINCREMENT, holiday_date TEXT UNIQUE, name TEXT);
    CREATE TABLE working_saturdays (id INTEGER PRIMARY KEY AUTOINCREMENT, work_date TEXT UNIQUE);
    INSERT INTO users VALUES (1,'admin','Admin','admin'), (2,'somchai','สมชาย','technician');
    """)
    con.commit()
    con.close()
    app.config.update(CMMS_DATABASE=str(path))
    RO.invalidate()
    yield str(path)
    app.config.pop("CMMS_DATABASE", None)
    RO.invalidate()


def test_cmms_shift_plan_two_way(app, db, cmms):
    db.execute("UPDATE users SET legacy_id=2 WHERE username='t_tech'")
    db.commit()
    a = uid(db, "t_tech")
    mon = _monday()
    with app.app_context():
        RO.set_plans(db, [{"user_id": a, "date": mon.isoformat(), "shift_type": "night_shift"}], uid(db, "t_admin"))
        db.commit()
    con = sqlite3.connect(cmms)
    assert con.execute("SELECT shift_type FROM tech_shift_plan WHERE user_id=2 AND plan_date=?", (mon.isoformat(),)).fetchone()[0] == "night_shift"
    assert db.execute("SELECT COUNT(*) FROM cs_shift_plan").fetchone()[0] == 0        # เขียนที่ UT-CMMS ไม่ซ้ำในระบบนี้
    # แก้ที่ UT-CMMS → เห็นในระบบนี้ · วันหยุดจาก UT-CMMS
    tue = mon + timedelta(days=1)
    con.execute("INSERT INTO tech_shift_plan(user_id, plan_date, shift_type) VALUES (2, ?, 'sick')", (tue.isoformat(),))
    con.execute("INSERT INTO holidays(holiday_date, name) VALUES (?, 'วันปิยมหาราช')", ((mon + timedelta(days=2)).isoformat(),))
    con.commit()
    con.close()
    RO.invalidate()
    with app.app_context():
        R = RO.load(db, mon, mon + timedelta(days=6))
        g = RO.month_grid(db, mon.replace(day=1))
    assert R["source"] == "cmms"
    assert RO.shift_key(R, a, tue) == "sick" and RO.shift_key(R, a, mon) == "night_shift"
    assert RO.shift_key(R, a, mon + timedelta(days=2)) == "holiday"
    assert RO.shift_key(R, a, mon + timedelta(days=5)) == "holiday"                    # เสาร์ (ไม่ใช่เสาร์ทำงาน)
    assert g["source"] == "cmms" and any(p["linked"] for p in g["people"])


def test_today_page_and_bulk_approve(app, client, db, published_form):
    from conftest import GOOD, payload
    fid = published_form["form_id"]
    tech = uid(db, "t_tech")
    form = S.get_form(db, fid)
    SUB.create_submission(db, payload(published_form, GOOD), {}, tech, app.config["UPLOAD_FOLDER"])
    db.commit()
    tok = login(client, "t_sup")
    html = client.get("/today").get_data(as_text=True)
    assert "ต้องจัดการวันนี้" in html and "อนุมัติใบปกติทั้งหมด (1)" in html and "ใครอยู่กะตอนนี้" in html
    client.post("/today/approve", data={"csrf_token": tok})
    assert db.execute("SELECT approval_status FROM cs_submissions WHERE form_id=?", (fid,)).fetchone()[0] == "approved"
    assert form


def test_ng_loop_reporter_sees_status(app, db, published_form):
    import io

    from werkzeug.datastructures import FileStorage

    from conftest import GOOD, payload, png_bytes
    tech = uid(db, "t_tech")
    ng = payload(published_form, dict(GOOD, noise={"value": "NG", "remark": "เสียงดัง", "photos": ["p1"]}))
    SUB.create_submission(db, ng, {"p1": FileStorage(io.BytesIO(png_bytes()), filename="p.png")}, tech, app.config["UPLOAD_FOLDER"])
    db.commit()
    mine = SUB.my_ng(db, tech)
    assert mine and mine[0]["status"] == "open"
    aid = mine[0]["id"]
    A.set_alert_status(db, aid, "ack", uid(db, "t_sup"))
    db.commit()
    mine = SUB.my_ng(db, tech)
    assert mine[0]["status"] == "acknowledged" and mine[0]["ack_name"] == "ทดสอบ t_sup"
    n = db.execute("SELECT title FROM cs_notifications WHERE user_id=? AND kind='ng_update'", (tech,)).fetchall()
    assert n and "รับทราบแล้ว" in n[0][0]
    assert SUB.my_tasks(db, tech)["my_ng"][0]["id"] == aid


def test_today_build_groups_missed_by_owner(app, db, published_form):
    fid = published_form["form_id"]
    rid = _round(db, fid, S.now_dt() - timedelta(hours=5), mins=60, status="missed")
    t = TD.build(db, uid(db, "t_admin"))
    assert t["late"]["missed"] >= 1 and any(r["id"] == rid for g in t["late"]["people"] for r in g["rows"])
