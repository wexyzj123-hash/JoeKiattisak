"""v0.75: ค่าคุณภาพ (quality) · DATETIMEOFFSET · เฝ้าแหล่งข้อมูล (ขัดข้อง / ข้อมูลหยุด / กลับมาปกติ + ดึงช่วงที่ขาด) · หัวข้อที่หายจากแบบฟอร์ม"""
import json
import sqlite3
import struct
from datetime import datetime, timedelta

import pytest
from conftest import uid
from test_v73 import _at, _day, _hist, _rows, _setup, _slots

from ecs import connectors as CN
from ecs import services as S
from ecs import srcmap as SM
from ecs import srcwatch as W
from ecs.services import ts


def test_quality_filter_and_parse(app, db, published_form, tmp_path):
    day = _day()
    p = str(tmp_path / "q.db")
    con = sqlite3.connect(p)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL, st INTEGER)")
    for tag, t, v in _rows(day):
        con.execute("INSERT INTO h VALUES (?,?,?,?)", (tag, t, v, 0 if t.endswith(":10:00") else 192))
    con.commit()
    con.close()
    sid = _setup(db, published_form, p)
    src = CN.get_source(db, sid)
    src["config"].update(query="SELECT tag, ts, value, st AS quality FROM h WHERE ts > ? ORDER BY ts", good_quality="192")
    rows, _k, _b = CN.fetch(db, src, _at(day, 23), tags=["OIL"])
    assert rows and all(not ts(r[1]).endswith(":10:00") for r in rows) and src["_bad_quality"] > 0
    assert CN.parse_quality("0, 192-255") == [(0, 0), (192, 255)] and CN.parse_quality("") is None
    with pytest.raises(CN.SourceError):
        CN.parse_quality("good")
    with pytest.raises(S.ValidationError):
        CN.save_source(db, {"name": "x", "kind": "sqlite", "config": {"path": p, "query": "SELECT tag, ts, value FROM h WHERE ts > ?",
                                                                    "good_quality": "ok"}}, None)


def test_datetimeoffset_converter():
    raw = struct.pack("<6hI2h", 2026, 10, 8, 14, 30, 5, 123000000, 7, 0)
    assert CN._dto(raw) == datetime(2026, 10, 8, 14, 30, 5, 123000)


def _notes(db, kind="source_watch"):
    return [r[0] for r in db.execute("SELECT title FROM cs_notifications WHERE kind=? ORDER BY id", (kind,))]


def test_watch_fail_recover_and_backfill(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    good = CN.get_source(db, sid)["config"]
    cfg = {**good, "path": str(tmp_path / "missing.db")}
    db.execute("UPDATE cs_sources SET config_json=? WHERE id=?", (json.dumps(cfg), sid))
    for i in range(3):
        CN.run_source(db, sid, now=_at(day, 23, i))
    s = CN.get_source(db, sid)
    assert s["alert_state"] == "fail" and any("ดึงข้อมูลไม่สำเร็จ" in t for t in _notes(db))
    CN.run_source(db, sid, now=_at(day, 23, 5))
    assert len(_notes(db)) == 1                                            # แจ้งครั้งเดียวต่อเหตุการณ์
    db.execute("UPDATE cs_sources SET config_json=? WHERE id=?", (json.dumps(good), sid))
    CN.run_source(db, sid, now=_at(day, 23, 30))
    db.commit()
    assert CN.get_source(db, sid)["alert_state"] == ""
    assert any("กลับมาปกติ" in t for t in _notes(db))
    assert _slots(db, day) == [f"{day} 08:30:00", f"{day} 20:30:00"]


def test_watch_stale(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day, end=12 * 60))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 12, 5))
    assert CN.get_source(db, sid)["alert_state"] == ""
    CN.run_source(db, sid, now=_at(day, 16, 0))                              # ไม่มีข้อมูลใหม่ 4 ชม.
    assert CN.get_source(db, sid)["alert_state"] == "stale" and any("ไม่มีข้อมูลใหม่" in t for t in _notes(db))
    _hist(path, [r for r in _rows(day) if r[1][11:13] >= "12"])
    CN.run_source(db, sid, now=_at(day, 23, 0))
    db.commit()
    assert CN.get_source(db, sid)["alert_state"] == "" and f"{day} 20:30:00" in _slots(db, day)


def test_audit_flags_removed_item(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    db.execute("UPDATE cs_source_tags SET item_key='gone' WHERE source_id=? AND tag='OIL'", (sid,))
    rep = SM.audit(db, sid, day, day, now=_at(day, 23))
    assert any("ไม่มีในแบบฟอร์มฉบับปัจจุบัน" in i["text"] and i["level"] == "ng" for i in rep["issues"])


def test_energy_watch_and_quality(app, db, tmp_path):
    from ecs import energy as EN
    from ecs import energy_src as ES
    f1 = app.config["F1"]
    sid = ES.save_source(db, {"name": "E", "kind": "sqlite", "active": "1",
                              "config": json.dumps({"path": str(tmp_path / "none.db"), "query": "SELECT tag, ts, value FROM h WHERE ts > ?",
                                                    "good_quality": "192"})}, None)
    EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "K1", "name": "K1", "scada_source_id": str(sid), "scada_tag": "K"}, None)
    now = S.now_dt()
    for i in range(3):
        ES.run_source(db, sid, now=now + timedelta(minutes=i))
    assert ES.get_source(db, sid)["alert_state"] == "fail"
    assert any("Energy Data" in t for t in _notes(db))
    with pytest.raises(S.ValidationError):
        ES.save_source(db, {"name": "x", "kind": "sqlite", "config": json.dumps({"path": "a", "query": "SELECT tag, ts, value FROM h",
                                                                                "good_quality": "bad"})}, None)


def test_pages_show_alert(app, db, published_form, tmp_path):
    from conftest import login
    day = _day()
    sid = _setup(db, published_form, str(tmp_path / "missing.db"))
    for i in range(3):
        CN.run_source(db, sid, now=_at(day, 23, i))
    db.commit()
    c = app.test_client()
    login(c, "t_admin")
    assert "ดึงไม่สำเร็จ" in c.get("/admin/sources").get_data(as_text=True)
    page = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert "ดึงไม่สำเร็จ" in page and "good_quality" in page
