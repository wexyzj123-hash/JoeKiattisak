"""v0.30: ใบบันทึกผลการตรวจรายครั้ง — ช่องผู้ตรวจ / หัวหน้างาน ใส่ลายเซ็นที่ตั้งไว้ (หรือชื่อ) อัตโนมัติ"""
from conftest import GOOD, login, payload, png_bytes, uid

from ecs import signoffs as SO
from ecs import submissions as SUB


def _sub(app, db, form):
    SUB.create_submission(db, payload(form, GOOD), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    return db.execute("SELECT MAX(id) FROM cs_submissions").fetchone()[0]


def test_record_signatures(app, db, published_form):
    sid = _sub(app, db, published_form)
    c = app.test_client()
    login(c, "t_sup")
    h = c.get(f"/submissions/{sid}/record").get_data(as_text=True)
    part = h[h.index("Inspected by"):]
    assert 'class="rs-n"' in part and "รออนุมัติ" in part and "data:image/png" not in part     # ยังไม่มีลายเซ็น → ชื่อ
    # ตั้งลายเซ็น → รูปลายเซ็นขึ้นในช่องผู้ตรวจทันที
    SO.save_signature(db, uid(db, "t_tech"), png_bytes())
    SO.save_signature(db, uid(db, "t_sup"), png_bytes())
    db.commit()
    part = c.get(f"/submissions/{sid}/record").get_data(as_text=True).split("Inspected by", 1)[1]
    assert part.count("data:image/png") == 1                                                    # ผู้อนุมัติยังไม่อนุมัติ
    SUB.approve(db, sid, uid(db, "t_sup"), "")
    db.commit()
    part = c.get(f"/submissions/{sid}/record").get_data(as_text=True).split("Inspected by", 1)[1]
    assert part.count("data:image/png") == 2 and "อนุมัติในระบบ" in part


def test_tech_personal_route(app, db, published_form):
    fid = published_form["form_id"]
    ct = app.test_client()
    tok = login(ct, "t_tech")
    assert "/m/route/edit" in open(app.root_path + "/static/m/home.js", encoding="utf-8").read()
    assert ct.get("/m/route/edit").status_code == 200
    cat = ct.get("/api/m/route-forms").get_json()
    assert any(f["id"] == fid for f in cat["forms"]) and cat["categories"]
    H = {"X-CSRF-Token": tok}
    assert ct.post("/api/m/routes/save", json={"name": "", "stops": [fid]}, headers=H).status_code == 400
    r = ct.post("/api/m/routes/save", json={"name": "ห้อง Compressor ของฉัน", "stops": [fid]}, headers=H)
    rid = r.get_json()["id"]
    row = db.execute("SELECT owner_id, factory_id FROM cs_routes WHERE id=?", (rid,)).fetchone()
    assert row[0] == uid(db, "t_tech") and row[1] == app.config["F1"]
    mine = ct.get("/api/m/routes").get_json()["routes"]
    assert any(x["id"] == rid and x["mine"] and x["can_edit"] for x in mine)
    assert ct.get(f"/api/m/routes/{rid}").get_json()["can_edit"]
    assert ct.get(f"/api/m/routes/{rid}/edit").get_json()["stops"] == [fid]
    # ช่างคนอื่นไม่เห็น / แก้ไม่ได้
    c2 = app.test_client()
    t2 = login(c2, "t_tech2")
    assert all(x["id"] != rid for x in c2.get("/api/m/routes").get_json()["routes"])
    assert c2.get(f"/api/m/routes/{rid}/edit").status_code == 403
    assert c2.post("/api/m/routes/save", json={"id": rid, "name": "x", "stops": [fid]}, headers={"X-CSRF-Token": t2}).status_code == 403
    assert c2.post(f"/api/m/routes/{rid}/delete", headers={"X-CSRF-Token": t2}).status_code == 403
    # ช่างแก้เส้นทางใช้ร่วมกัน (หัวหน้างานสร้าง) ไม่ได้
    from ecs import walkroutes as R
    shared = R.save_route(db, {"name": "ร่วม"}, [fid], uid(db, "t_sup"))
    db.commit()
    assert ct.get(f"/api/m/routes/{shared}/edit").status_code == 403
    # หัวหน้างานเห็นในหน้าจัดการพร้อมป้ายส่วนตัว
    cs = app.test_client()
    login(cs, "t_sup")
    assert "ส่วนตัว" in cs.get("/routes").get_data(as_text=True)
    # เจ้าของลบได้
    assert ct.post(f"/api/m/routes/{rid}/delete", headers=H).get_json()["ok"]
    assert not db.execute("SELECT 1 FROM cs_routes WHERE id=?", (rid,)).fetchone()
