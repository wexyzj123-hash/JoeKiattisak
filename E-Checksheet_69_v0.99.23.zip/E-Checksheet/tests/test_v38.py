"""v0.38: ช่างแจ้งเครื่องหยุดเดิน/PM จากมือถือ · ผู้อนุมัติตามตำแหน่ง (Sr.Tech/FM/SV) เห็นรายการอนุมัติ · เตือนอนุมัติรายสัปดาห์"""
from datetime import date, datetime, timedelta

from conftest import GOOD, login, payload, uid

from ecs import notify as N
from ecs import services as S
from ecs import submissions as SUB


def _pos(db, username, pos):
    db.execute("UPDATE users SET position=? WHERE username=?", (pos, username))
    db.commit()


def test_mobile_equipment_down_and_running(app, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    S.create_schedule(db, fid, {"freq_type": "daily", "times": "00:00", "window_min": 1439}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (S.ts(S.now_dt() - timedelta(days=2)),))
    S.generate_rounds(db)
    db.commit()
    c = app.test_client()
    tok = login(c, "t_tech")
    home = c.get("/m/").get_data(as_text=True)
    assert "m/down.js" in home and "m-appr" not in home                  # ช่างทั่วไปไม่มีทางลัดอนุมัติ
    forms = c.get("/api/m/forms").get_json()["forms"]
    f = next(x for x in forms if x["id"] == fid)
    assert f["equipment_id"] == eq and f["run_status"] == "running"
    h = {"X-CSRF-Token": tok}
    r = c.post(f"/api/m/equipment/{eq}/down", json={"category": "pm"}, headers=h)
    assert r.status_code == 200 and r.get_json()["code"] == "SCT0002"
    row = db.execute("SELECT run_status, down_reason FROM equipment WHERE id=?", (eq,)).fetchone()
    assert row["run_status"] == "down" and "PM" in row["down_reason"]
    t = c.get("/api/m/tasks").get_json()
    assert [d["code"] for d in t["down"]] == ["SCT0002"]
    assert all(x["status"] == "skipped" for x in t["groups"]["skipped"]) and t["groups"]["skipped"]
    assert not t["groups"]["due"] and not t["groups"]["overdue"]
    assert c.get("/api/m/forms").get_json()["forms"][0]["run_status"] == "down"
    # หัวหน้างานได้รับแจ้งในกระดิ่ง
    assert db.execute("SELECT COUNT(*) FROM cs_notifications WHERE user_id=? AND kind='equipment_down'",
                      (uid(db, "t_sup"),)).fetchone()[0] == 1
    assert c.post(f"/api/m/equipment/{eq}/down", json={"category": "pm"}, headers=h).status_code == 422   # แจ้งซ้ำไม่ได้
    r = c.post(f"/api/m/equipment/{eq}/running", json={"note": "PM เสร็จ"}, headers=h)
    assert r.status_code == 200 and r.get_json()["restored"] >= 1
    assert c.get("/api/m/tasks").get_json()["down"] == []
    assert c.post("/api/m/equipment/99999/down", json={}, headers=h).status_code == 404
    page = c.get(f"/m/fill").get_data(as_text=True)
    assert "m/down.js" in page


def test_position_approvers_mobile_and_approve(app, db, published_form):
    SUB.create_submission(db, payload(published_form, GOOD), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    sid = db.execute("SELECT MAX(id) FROM cs_submissions").fetchone()[0]
    c = app.test_client()
    login(c, "t_view")                                                   # ผู้ใช้ทั่วไป ไม่มีสิทธิ์
    assert c.get("/approvals").status_code == 403
    # ช่างที่ตั้งตำแหน่ง Sr.Tech → อนุมัติได้ เห็นทางลัดบนมือถือ
    _pos(db, "t_tech", "srtech")
    assert SUB.can_approve(db, uid(db, "t_tech"))
    tok = login(c, "t_tech")
    home = c.get("/m/").get_data(as_text=True)
    assert "m-appr" in home and "อนุมัติรายสัปดาห์" in home and "รออนุมัติ" in home
    assert c.get("/approvals").status_code == 200
    assert c.get("/approvals/group").status_code == 200
    assert "submission_approve" not in c.get(f"/submissions/{sid}").get_data(as_text=True)
    assert f"/submissions/{sid}/approve" in c.get(f"/submissions/{sid}").get_data(as_text=True)
    r = c.post(f"/submissions/{sid}/approve", data={"csrf_token": tok, "note": "ok"})
    assert r.status_code == 302
    assert db.execute("SELECT approval_status FROM cs_submissions WHERE id=?", (sid,)).fetchone()[0] == "approved"
    for p in ("fm", "sv"):
        _pos(db, "t_tech", p)
        assert SUB.can_approve(db, uid(db, "t_tech"))
    _pos(db, "t_tech", "tech")
    assert not SUB.can_approve(db, uid(db, "t_tech"))


def test_weekly_approval_reminder(app, db, published_form):
    SUB.create_submission(db, payload(published_form, GOOD), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    sid = db.execute("SELECT MAX(id) FROM cs_submissions").fetchone()[0]
    now = S.now_dt()
    monday = (now - timedelta(days=now.weekday())).replace(hour=9, minute=0, second=0, microsecond=0)
    db.execute("UPDATE cs_submissions SET finished_at=? WHERE id=?", (S.ts(monday - timedelta(days=3)), sid))
    _pos(db, "t_tech", "fm")
    ids = {u["id"] for u in N.approvers(db)}
    assert uid(db, "t_tech") in ids and uid(db, "t_sup") in ids and uid(db, "t_admin") not in ids
    assert N.weekly_approval_reminders(db, monday - timedelta(hours=2))["wk_appr"] == 0      # ยังไม่ถึงเวลา
    res = N.weekly_approval_reminders(db, monday)
    assert res["wk_appr"] >= 2
    n = db.execute("SELECT title, url FROM cs_notifications WHERE user_id=? AND kind='approval_week'", (uid(db, "t_tech"),)).fetchone()
    assert n and "รออนุมัติรายสัปดาห์" in n["title"] and "/approvals/group" in n["url"]
    assert N.weekly_approval_reminders(db, monday + timedelta(hours=1))["wk_appr"] == 0      # สัปดาห์ละครั้ง
    # ตั้งค่าได้จากหน้าแจ้งเตือน
    db.commit()
    c = app.test_client()
    tok = login(c, "t_admin")
    assert "เตือนผู้อนุมัติ" in c.get("/admin/notify").get_data(as_text=True)
    c.post("/admin/notify", data={"csrf_token": tok, "wa.enabled": "1", "wa.weekday": "4", "wa.time": "16:00"})
    assert N.get_settings(db)["weekly_approval"] == {"enabled": True, "weekday": 4, "time": "16:00"}


def test_every_two_weeks_first_round_and_group():
    # เริ่มนับวันพุธ แต่ตรวจวันจันทร์ → รอบแรกคือจันทร์ถัดไป (เดิมเลื่อนไป 2 สัปดาห์)
    s = {"freq_type": "w:2", "weekdays": "0", "anchor_date": "2026-09-30", "times": "08:00", "skip_holidays": 0}
    occ = S.occurrences(s, date(2026, 9, 28), date(2026, 11, 1))
    assert [d.date() for d in occ] == [date(2026, 10, 5), date(2026, 10, 19)]
    assert S.week_base(date(2026, 9, 28), "0") == date(2026, 9, 28)             # เริ่มวันจันทร์ = สัปดาห์เดิม
    assert N._freq_group("w:2") == "weekly" and N._freq_group("weekly") == "weekly" and N._freq_group("d:3") == "daily"
    assert datetime(2026, 10, 5).weekday() == 0
