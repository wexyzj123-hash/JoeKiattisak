"""v0.46: จับคู่ค่าจาก SQL / SCADA จากฝั่งแบบฟอร์ม — เลือกต่อหัวข้อ · คำแนะนำ · ความครอบคลุม · รูปแบบ Tag ของแม่แบบ"""
import sqlite3
from datetime import timedelta

from conftest import emo, login, uid

from ecs import connectors as CN
from ecs import formmap as FM
from ecs import services as S
from ecs.services import ts


def _src(db, tmp_path, tags):
    path = str(tmp_path / "scada.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    now = S.now_dt()
    con.executemany("INSERT INTO h VALUES (?,?,?)", [(t, ts(now - timedelta(minutes=5)), v) for t, v in tags])
    con.commit()
    con.close()
    sid = CN.save_source(db, {"name": "GENESIS64", "kind": "sqlite", "config": {"path": path,
                              "query": "SELECT tag, ts, value FROM h WHERE ts > ?", "backfill_days": 1}}, None)
    CN.run_source(db, sid)
    db.commit()
    return sid


def test_form_view_coverage_and_suggestions(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    sid = _src(db, tmp_path, [("SCT0002_OIL_PRESS", 2.1), ("SCT0002_RUN_HR", 1500), ("OTHER", 1)])
    v = FM.form_view(db, fid)
    assert v["cover"] == {"items": 5, "numeric": 2, "scada": 0, "manual": 5, "receiving": 0, "pct": 0}
    rows = {r["key"]: r for r in v["rows"]}
    assert rows["oil"]["sug"]["tag"] == "SCT0002_OIL_PRESS" and rows["hour"]["sug"]["tag"] == "SCT0002_RUN_HR"
    assert not rows["noise"]["numeric"]
    FM.save_form_map(db, fid, [{"item_key": "oil", "source_id": sid, "tag": "SCT0002_OIL_PRESS", "scale": 1},
                               {"item_key": "hour", "source_id": "", "tag": ""}], None)
    db.commit()
    v = FM.form_view(db, fid)
    assert v["cover"]["scada"] == 1 and v["cover"]["receiving"] == 1
    FM.save_form_map(db, fid, [{"item_key": "oil", "source_id": sid, "tag": "SCT0002_OIL_PRESS", "scale": 100}], None)
    assert "ตัวคูณ 0.01" in {r["key"]: r for r in FM.form_view(db, fid)["rows"]}["oil"]["hint"]   # หน่วยต่างกัน
    # เปลี่ยน Tag ของหัวข้อ → Tag เดิมกลับเป็นไม่ใช้ · เว้นว่าง = ช่างกรอก
    FM.save_form_map(db, fid, [{"item_key": "oil", "source_id": sid, "tag": "OTHER"}], None)
    m = {t["tag"]: t for t in CN.list_tags(db, sid)}
    assert m["OTHER"]["item_key"] == "oil" and not m["SCT0002_OIL_PRESS"]["form_id"]
    FM.save_form_map(db, fid, [{"item_key": "oil", "source_id": "", "tag": ""}], None)
    assert FM.form_view(db, fid)["cover"]["scada"] == 0


def test_form_scada_page(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    sid = _src(db, tmp_path, [("SCT0002_OIL_PRESS", 2.1)])
    c = app.test_client()
    tok = login(c, "t_admin")
    assert "📡 ค่าจาก SCADA (0/2)" in emo(c.get(f"/forms/{fid}").get_data(as_text=True))
    html = c.get(f"/forms/{fid}/scada").get_data(as_text=True)
    assert "ค่าจาก SQL / SCADA" in html and "💡" in emo(html) and "ช่างตรวจหน้างาน" in html and f'id="dl-{sid}"' in html
    r = c.post(f"/forms/{fid}/scada", data={"csrf_token": tok, "item_key": ["oil", "hour"], f"src.oil": str(sid),
                                             "tag.oil": "SCT0002_OIL_PRESS", "scale.oil": "1", "off.oil": "0",
                                             "src.hour": "", "tag.hour": ""})
    assert r.status_code == 302
    assert "📡 ค่าจาก SCADA (1/2)" in emo(c.get(f"/forms/{fid}").get_data(as_text=True))
    cov = c.get("/admin/sources/coverage").get_data(as_text=True)
    assert "Daily AC" in cov and "เลือกหัวข้อที่ใช้ค่าจากระบบ" in c.get("/admin/sources").get_data(as_text=True)
    r = c.post(f"/forms/{fid}/scada", data={"csrf_token": tok, "item_key": "oil", "src.oil": "", "tag.oil": "X1"})
    assert "กรุณาเลือกแหล่งข้อมูล" in r.get_data(as_text=True)
    login(c, "t_sup")
    assert c.get(f"/forms/{fid}/scada").status_code in (302, 403)


def test_template_patterns(app, db, published_form, tmp_path):
    from ecs import formtpl as T
    from ecs import masterdata as M
    admin = uid(db, "t_admin")
    eq2 = M.save_equipment(db, {"code": "SCT0005", "name": "AC 5", "factory_id": app.config["F1"]}, admin)
    tpl = T.make_template(db, published_form["form_id"], admin)
    T.apply_to_equipment(db, tpl, [eq2], admin)
    db.commit()
    sid = _src(db, tmp_path, [("SCT0005_OIL_PRESS", 2.0)])
    res = FM.apply_patterns(db, tpl, [{"item_key": "oil", "source_id": sid, "pattern": "{EQ}_OIL_PRESS"}], admin)
    db.commit()
    assert res["forms"] >= 1 and res["mapped"] >= 1 and res["seen"] >= 1
    m = {t["tag"]: t for t in CN.list_tags(db, sid)}
    assert m["SCT0005_OIL_PRESS"]["item_key"] == "oil"
    assert FM.tpl_patterns(db, tpl)["oil"]["pattern"] == "{EQ}_OIL_PRESS"
    try:
        FM.apply_patterns(db, tpl, [{"item_key": "oil", "source_id": sid, "pattern": "NO_EQ"}], admin)
        raise AssertionError
    except S.ValidationError:
        pass
