"""v0.26: แถวหัวหน้างานรายสัปดาห์เติมจากการอนุมัติ · อนุมัติแบบกลุ่ม (ผู้ได้รับสิทธิ์) · กล่อง Utility มุมขวาบน ·
หน้าตั้งค่ารูปแบบใบบันทึก · ทดสอบการเชื่อมโยงตั้งแต่ส่งผลตรวจ → อนุมัติ → ลงนามรายเดือน → เอกสาร"""
import io
from datetime import date, datetime, timedelta

from conftest import GOOD, login, payload, png_bytes, uid
from openpyxl import load_workbook

from ecs import services as S
from ecs import sheet_report as SR
from ecs import sign_blocks as SB
from ecs import signoffs as SO
from ecs import submissions as SUB

PM = (date.today().replace(day=1) - timedelta(days=1)).replace(day=1)


def _sub(app, db, fid, day, who="t_tech", answers=None):
    f = S.get_form(db, fid)
    res = SUB.create_submission(db, payload({"form_id": fid, "version_id": f["current_version_id"]}, answers or GOOD),
                                {}, uid(db, who), app.config["UPLOAD_FOLDER"], now=datetime(PM.year, PM.month, day, 9, 0))
    db.commit()
    return res["id"]


def _wk(day):
    return f"row:sup:{SO.week_of(PM, day)['start']}"


def test_weekly_row_follows_approvals(app, db, published_form):
    fid = published_form["form_id"]
    sup = uid(db, "t_sup")
    d1 = SO.week_of(PM, 10)["start"]                                  # 2 ผลตรวจในสัปดาห์เดียวกัน
    a, b = _sub(app, db, fid, d1), _sub(app, db, fid, min(d1 + 1, 28))
    SUB.approve(db, a, sup)
    assert _wk(d1) not in SO.records(db, fid, PM)                     # ยังไม่ครบ
    SUB.approve(db, b, sup)
    rec = SO.records(db, fid, PM)[_wk(d1)]
    assert rec["user_id"] == sup and rec["auto"] == 1
    c = _sub(app, db, fid, d1)                                        # ผลตรวจใหม่ในสัปดาห์เดิม → ว่างจนกว่าจะอนุมัติ
    assert _wk(d1) not in SO.records(db, fid, PM)
    SUB.return_submission(db, c, sup, "แก้ค่าใหม่")
    assert _wk(d1) not in SO.records(db, fid, PM)                     # ตีกลับรอแก้ = ยังไม่ครบ
    db.execute("UPDATE users SET can_delete_results=1 WHERE id=?", (sup,))
    SUB.delete_submissions(db, [c], sup, "ทดสอบลบ")
    assert SO.records(db, fid, PM)[_wk(d1)]["user_id"] == sup         # ลบฉบับที่ค้าง → ครบอีกครั้ง
    # ช่องรายสัปดาห์ลงนามเองไม่ได้ (มาจากการอนุมัติเท่านั้น)
    SO.save_positions(db, {sup: "srtech"}, None)
    form = S.get_form(db, fid)
    try:
        SO.sign(db, form, PM, f"row:sup:{SO.week_of(PM, 3)['start']}", {"id": sup, "role": "supervisor"})
        raise AssertionError
    except SO.SignError:
        pass


def test_group_approval_permission_and_ng(app, db, published_form):
    fid = published_form["form_id"]
    tech = uid(db, "t_tech")
    ok1, ok2 = _sub(app, db, fid, 3), _sub(app, db, fid, 4)
    ng = _sub(app, db, fid, 5)
    db.execute("UPDATE cs_submissions SET ng_count=1 WHERE id=?", (ng,))                # จำลองผลตรวจที่มี NG
    db.commit()
    ct = app.test_client()
    tt = login(ct, "t_tech")
    assert ct.get(f"/approvals/group?month={PM:%Y-%m}").status_code == 403
    ca = app.test_client()
    ta = login(ca, "t_admin")
    u = dict(db.execute("SELECT * FROM users WHERE id=?", (tech,)).fetchone())
    ca.post(f"/admin/users/{tech}", data={"csrf_token": ta, "username": u["username"], "name": u["name"], "role": u["role"],
                                          "factory_id": u["factory_id"] or "", "active": "1", "can_approve": "1"})
    assert SUB.can_approve(db, tech)
    page = ct.get(f"/approvals/group?month={PM:%Y-%m}").get_data(as_text=True)
    assert "อนุมัติแบบกลุ่ม" in page and "ลงนามใบบันทึก" in page
    groups = {f"{fid}|{SO.week_of(PM, d)['start']}" for d in (3, 4, 5)}
    ct.post("/approvals/group", data={"csrf_token": tt, "month": f"{PM:%Y-%m}", "grp": list(groups)})
    st = {r[0]: r[1] for r in db.execute("SELECT id, approval_status FROM cs_submissions")}
    assert st[ok1] == st[ok2] == "approved" and st[ng] == "pending"   # NG ข้ามถ้าไม่ติ๊ก "รวม NG"
    ct.post("/approvals/group", data={"csrf_token": tt, "month": f"{PM:%Y-%m}", "grp": list(groups), "with_ng": "1"})
    assert db.execute("SELECT approval_status, approved_by FROM cs_submissions WHERE id=?", (ng,)).fetchone()[:] == ("approved", tech)
    assert SO.records(db, fid, PM)[_wk(5)]["user_id"] == tech
    # สิทธิ์ตามโรงงาน: ผู้อนุมัติโรงงาน 2 อนุมัติแบบฟอร์มโรงงาน 1 ไม่ได้
    t2 = uid(db, "t_tech2")
    db.execute("UPDATE users SET can_approve=1 WHERE id=?", (t2,))
    db.commit()
    x = _sub(app, db, fid, 20)
    try:
        SUB.approve(db, x, t2)
        raise AssertionError
    except S.ValidationError:
        pass


def test_full_chain_util_box(app, db, published_form):
    """ส่งผลตรวจ 2 สัปดาห์ → อนุมัติแบบกลุ่มทั้งหมด → แถวสัปดาห์เติมครบ → กล่อง Utility: SV/SSV → Manager (DM) → PDF/Excel"""
    fid = published_form["form_id"]
    sup, view, admin = uid(db, "t_sup"), uid(db, "t_view"), uid(db, "t_admin")
    c = app.test_client()
    tok = login(c, "t_sup")
    c.post(f"/forms/{fid}/sign-config", data={"csrf_token": tok, "sb_util": "1", "sb_dept": ""})
    assert SB.own(db, fid).get("util") is True
    for u, pos in ((view, "ssv"), (admin, "dm")):
        SO.save_positions(db, {u: pos}, None)
    db.commit()
    days = [3, 17]
    for d in days:
        _sub(app, db, fid, d)
    form = S.get_form(db, fid)
    al = {x["slot"]: x for x in SO.slots(db, form, PM)}
    assert "mon:insp" not in al and "box:util:1" in al and al["box:util:0"]["after"] == "box:util:1"
    try:
        SO.sign(db, form, PM, "box:util:1", {"id": view, "role": "viewer"})
        raise AssertionError
    except SO.SignError as e:
        assert "รออนุมัติ" in str(e)
    grp = [f"{fid}|{SO.week_of(PM, d)['start']}" for d in days]
    c.post("/approvals/group", data={"csrf_token": tok, "month": f"{PM:%Y-%m}", "grp": grp})
    recs = SO.records(db, fid, PM)
    assert all(recs[_wk(d)]["user_id"] == sup for d in days)
    try:
        SO.sign(db, form, PM, "box:util:0", {"id": admin, "role": "admin"})     # Manager ก่อน SV/SSV ไม่ได้
        raise AssertionError
    except SO.SignError as e:
        assert "SV/SSV" in str(e)
    SO.sign(db, form, PM, "box:util:1", {"id": view, "role": "viewer"})
    SO.sign(db, form, PM, "box:util:0", {"id": admin, "role": "admin"})
    db.commit()
    html = c.get(f"/reports/sheets?form={fid}&month={PM:%Y-%m}").get_data(as_text=True).split("</style>")[1]
    hd = html[html.index('<table class="hd">'):]
    hd = hd[:hd.index("</tr></table>")]
    assert "xutil" in hd and "Manager" in hd and "SV/SSV" in hd
    assert '<div class="sign c2">' not in html                       # ช่องท้ายเอกสารหายไป
    sheet = SR.build_month_sheet(db, fid, PM, "s")
    assert sheet["signs"]["util"] and all(c_["so"] for c_ in sheet["signs"]["boxes"][0]["cells"])
    ws = load_workbook(io.BytesIO(SR.to_excel([sheet]))).worksheets[0]
    top = {str(ws.cell(r, cc).value) for r in range(1, 6) for cc in range(1, ws.max_column + 1) if ws.cell(r, cc).value}
    assert {"Utility", "Manager", "SV/SSV"} <= top
    allv = {str(ws.cell(r, cc).value) for r in range(1, ws.max_row + 1) for cc in range(1, ws.max_column + 1) if ws.cell(r, cc).value}
    assert "ผู้ตรวจ (Sr.Tech/FM)" not in allv
    # ยกเลิกอนุมัติ (ตีกลับ) ไม่ได้หลังอนุมัติแล้ว — แต่ลบผลตรวจ → แถวสัปดาห์คำนวณใหม่
    sid = db.execute("SELECT id FROM cs_submissions WHERE form_id=? ORDER BY id LIMIT 1", (fid,)).fetchone()[0]
    SUB.delete_submissions(db, [sid], admin, "ทดสอบการเชื่อมโยง")
    assert _wk(days[0]) not in SO.records(db, fid, PM)               # สัปดาห์นั้นไม่มีผลตรวจแล้ว


def test_layout_settings(app, db, published_form):
    fid = published_form["form_id"]
    c = app.test_client()
    tok = login(c, "t_admin")
    assert "รูปแบบใบบันทึก" in c.get("/reports/layout").get_data(as_text=True)
    c.post("/reports/layout", data={"csrf_token": tok, "action": "save", "title_th": "ใบตรวจเช็คเครื่องจักรประจำเดือน",
                                    "row_insp": "พนักงานตรวจ", "show_legend": "1", "show_qr": "1", "show_logo": "1",
                                    "img_aisin-logo_png": (io.BytesIO(png_bytes()), "logo.png")},
           content_type="multipart/form-data")
    m = date.today().replace(day=1)
    html = c.get(f"/reports/sheets?form={fid}&month={m:%Y-%m}").get_data(as_text=True)
    assert "ใบตรวจเช็คเครื่องจักรประจำเดือน" in html and "พนักงานตรวจ" in html and "สรุปผลประจำเดือน" not in html
    assert c.get("/reports/doc-image/aisin-logo.png").status_code == 200
    ws = load_workbook(io.BytesIO(SR.to_excel([SR.build_month_sheet(db, fid, m, "s")]))).worksheets[0]
    vals = {str(ws.cell(r, cc).value) for r in range(1, ws.max_row + 1) for cc in range(1, ws.max_column + 1) if ws.cell(r, cc).value}
    assert "ใบตรวจเช็คเครื่องจักรประจำเดือน" in vals and "สรุปผลประจำเดือน" not in vals
    c.post("/reports/layout", data={"csrf_token": tok, "action": "delimg:aisin-logo.png"})
    c.post("/reports/layout", data={"csrf_token": tok, "action": "reset"})
    assert "ใบบันทึกผลการตรวจเช็คประจำเดือน" in c.get(f"/reports/sheets?form={fid}&month={m:%Y-%m}").get_data(as_text=True)
    assert c.get("/reports/doc-image/evil.png").status_code == 404
    cv = app.test_client()
    login(cv, "t_sup")
    assert cv.get("/reports/layout").status_code == 403
