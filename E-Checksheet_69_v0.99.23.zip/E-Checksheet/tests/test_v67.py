"""v0.67: ต้นทุนพลังงาน — ประจำวัน → พื้นที่ → ปันส่วนให้เท่ากับบิล → Energy management (ผลิต/ขาย) + นำเข้าย้อนหลัง"""
import io
from datetime import date, timedelta

import pytest
from conftest import login, uid
from openpyxl import Workbook

from ecs import energy as EN
from ecs import energy_cost as C
from ecs import energy_ops as OPS
from ecs.services import ValidationError

Y = 2025


def test_allocate_exact():
    kw, rest = C.allocate([100.0, 200.0, 0.0], 330.0, "prop", None)
    assert kw == [110.0, 220.0, 0.0] and rest == 0
    kw, rest = C.allocate([1 / 3, 1 / 3, 1 / 3], 100.0, "prop", None)
    assert round(sum(kw), 2) == 100.0 and max(kw) - min(kw) <= 0.011
    kw, rest = C.allocate([100.0, 200.0, 0.0], 330.0, "residual", 2)
    assert kw == [100.0, 200.0, 30.0]
    kw, rest = C.allocate([100.0, 200.0], 330.0, "residual", None)
    assert kw == [100.0, 200.0] and rest == 30.0
    kw, _ = C.allocate([300.0, 300.0, 0.0], 330.0, "residual", 2)          # มิเตอร์เกินบิล → ปรับลงตามสัดส่วน ไม่เกินบิล
    assert kw == [165.0, 165.0, 0.0]
    kw, rest = C.allocate([0, 0], 50.0, "prop", None)
    assert kw == [0.0, 0.0] and rest == 50.0
    vals = C._round_to([33.333, 33.333, 33.334], 100.0)
    assert round(sum(vals), 2) == 100.0


def _meter(db, fid, code, grp, start, per_day, mult=1):
    mid = EN.save_meter(db, None, {"factory_id": fid, "kind": "elec", "code": code, "name": code, "grp": grp, "multiplier": mult}, None)
    d = date(Y, 1, 1) - timedelta(days=1)
    v = start
    while d <= date(Y, 2, 28):
        EN.set_reading(db, mid, d.isoformat(), v, None)
        d += timedelta(days=1)
        v += per_day
    return mid


def test_reconcile_flow(app, db):
    f1 = app.config["F1"]
    adm = uid(db, "t_admin")
    a = _meter(db, f1, "A", "LINE", 1000, 100)          # ม.ค. 3100
    b = _meter(db, f1, "B", "LINE", 5000, 50)           # 1550
    c = _meter(db, f1, "C", "OFFICE", 0, 10)            # 310
    it = C.save_item(db, f1, {"name": "AR-5", "unit": "Unit", "weight": 1}, adm)
    pcs = C.save_item(db, f1, {"name": "SKT", "unit": "Pcs", "weight": 0.05}, adm)
    ar = C.save_area(db, f1, {"name": "Line", "grp": "MFG", "driver": "item", "item_id": it, "target_a": "0", "target_b": "40"}, adm)
    of = C.save_area(db, f1, {"name": "Office", "grp": "OFFICE", "driver": "days"}, adm)
    ot = C.save_area(db, f1, {"name": "Other", "grp": "OTHER", "driver": "none", "is_residual": "1"}, adm)
    C.save_links(db, ar, [{"meter_id": a, "factor": 1}, {"meter_id": b, "factor": "0.5"}], adm)
    C.save_links(db, of, [{"meter_id": c, "factor": 1}, {"meter_id": b, "factor": 0.5}], adm)
    with pytest.raises(ValidationError):
        C.save_area(db, f1, {"name": "Line"}, adm)                                    # ชื่อซ้ำ
    with pytest.raises(ValidationError):
        C.save_area(db, f1, {"name": "X", "driver": "item"}, adm)                     # ตัวหารรายการต้องเลือก
    OPS.save_bill(db, {"factory_id": f1, "month": f"{Y}-01", "kwh": 5000, "amount": 20000.01, "vat": 1400}, adm)
    C.save_month_grid(db, f1, Y, {f"q_{it}_1": "100", f"q_{pcs}_1": "2000", "wd_1": "22", "sales_1": "1000000"}, adm)
    rc = C.reconcile(db, f1, Y, today=date(Y, 2, 28))
    m1 = rc["months"][0]
    assert m1["meas"] == pytest.approx(3100 + 1550 + 310) and m1["bill_kwh"] == 5000
    rows = {r["area"]["name"]: r for r in rc["rows"]}
    assert sum(r["kwh"][0] for r in rc["rows"]) == pytest.approx(5000, abs=1e-9)
    assert sum(r["baht"][0] for r in rc["rows"]) == pytest.approx(20000.01, abs=1e-9)          # ฐานก่อน VAT
    assert rows["Other"]["kwh"][0] == 0                                                          # prop: ไม่มีส่วนต่าง
    assert rc["prod"]["total"][0] == pytest.approx(100 + 2000 * 0.05)
    assert rows["Line"]["x"][0] == 100 and rows["Office"]["x"][0] == 22
    per = rows["Line"]["per"][0]
    assert per == pytest.approx(rows["Line"]["kwh"][0] / 100, rel=1e-3)
    assert rows["Line"]["status"][0] == ("ok" if per <= 40 else "warn" if per <= 44 else "bad")
    # วิธีส่วนต่าง + ฐานรวม VAT
    C.save_config(db, f1, {"method": "residual", "basis": "total"}, adm)
    rc = C.reconcile(db, f1, Y, today=date(Y, 2, 28))
    rows = {r["area"]["name"]: r for r in rc["rows"]}
    assert rows["Line"]["kwh"][0] == pytest.approx(3100 + 775) and rows["Other"]["kwh"][0] == pytest.approx(5000 - 4960)
    assert sum(r["baht"][0] for r in rc["rows"]) == pytest.approx(21400.01, abs=1e-9)
    assert rc["totals"]["pct_sales"] == pytest.approx(100 * 21400.01 / 1e6, rel=1e-3)
    # กรอกหน่วยรายเดือนเองทับประจำวัน
    C.set_month_usage(db, c, f"{Y}-01", "1000", adm, "มิเตอร์เสีย")
    mm = C.meter_months(db, f1, Y, today=date(Y, 2, 28))
    assert mm[c]["kwh"][0] == 1000 and mm[c]["src"][0] == "manual" and mm[a]["src"][0] == "daily"
    C.set_month_usage(db, c, f"{Y}-01", "", adm)
    assert C.meter_months(db, f1, Y, today=date(Y, 2, 28))[c]["src"][0] == "daily"
    # ประจำวัน → พื้นที่
    dl = C.daily_areas(db, f1, date(Y, 1, 1))
    assert len(dl["days"]) == 31 and dl["rows"][0]["vals"][0] == pytest.approx(100 + 25)
    assert dl["rate"] == pytest.approx(21400.01 / 5000, rel=1e-4)
    # ไฟล์ Excel
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(C.cost_xlsx(db, f1, Y)))
    assert wb.sheetnames == ["สรุปบิล", "kWh พื้นที่", "บาท พื้นที่", "kWh มิเตอร์ (ก่อนปรับ)", "มิเตอร์รายเดือน", "สูตรเชื่อมโยง"]
    wb = load_workbook(io.BytesIO(C.em_xlsx(db, Y)))
    assert wb.sheetnames[0] == "ภาพรวม" and len(wb.sheetnames) >= 3
    ov = C.overview(db, Y)
    assert ov["g"]["bill_kwh"] == 5000 and ov["g"]["tco2"] > 0
    # ลบ
    with pytest.raises(ValidationError):
        C.delete_item(db, it, adm)                                                               # ถูกใช้เป็นตัวหาร
    C.delete_area(db, ar, adm)
    assert not C.links(db, ar)


def _em_book() -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Aisin1"
    ws["A2"], ws["B2"], ws["D2"] = "SLIP", "MOUNT", "Location"
    ws["E2"], ws["F2"] = date(Y, 1, 1), date(Y, 2, 1)
    rows = [("", "Total (Kwh)", "", "", 1000, 1100), ("", "Bath (฿)", "", "", 4000, 4400), ("", "FT", "", "", 10, 11),
            ("", "DEMAND", "", "", 300, 300), ("", "VAT 7% (฿)", "", "", 280, 308), ("", "Bath / Kwh", "", "", "=E4/E3", "=F4/F3"),
            ("LINE A", "METER MAIN", "", "Main", 990, 1090), ("", "MH9120", 30, "", 300, 320), ("", "", 31, "", 100, 110),
            ("", "GR9230", 45, "", 200, 210), ("OFFICE MR", "OFFICE", 87, "", 50, 55), ("", "CANTEEN", 88, "", 40, 45)]
    for i, r in enumerate(rows, start=3):
        for j, v in enumerate(r, start=1):
            if v != "":
                ws.cell(i, j, v)
    ws["A16"], ws["B16"], ws["C16"], ws["E16"], ws["F16"] = "ELECTRIC", "MFG Line", "Kwh", "=SUM(E10:E12)", "=SUM(F10:F12)"
    ws["B17"], ws["C17"], ws["E17"], ws["F17"] = "Office.", "Kwh", "=E13+E14", "=F13+F14"
    ws["B18"], ws["C18"], ws["E18"], ws["F18"] = "Other", "Kwh", "=E3-SUM(E16:E17)", "=F3-SUM(F16:F17)"
    ws["B19"], ws["E19"], ws["F19"] = "Heat split", "=E10*0.5", "=F10*0.5"
    ws["B21"], ws["E21"] = "PRODUCTION", "=E2"
    ws["B22"], ws["C22"], ws["E22"], ws["F22"] = "AR-5", "Unit", 100, 110
    ws["B23"], ws["C23"], ws["E23"], ws["F23"] = "SKT", "Pcs", 2000, 2100
    ws["B24"], ws["C24"], ws["E24"] = "TOTAL", "Unit", "=E22+E23/20"
    ws["B25"], ws["C25"], ws["E25"], ws["F25"] = "Working Day", "Day", 22, 20
    s = wb.create_sheet("Sale Amou")
    s["D2"], s["E2"] = date(Y, 1, 1), date(Y, 2, 1)
    s["B3"], s["D3"], s["E3"] = "FAC1", 5000, 5200
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def test_em_import(app, db):
    f1 = app.config["F1"]
    adm = uid(db, "t_admin")
    p = C.parse_em(_em_book(), Y)
    sh = p["sheets"][0]
    assert sh["idx"] == 1 and sh["months"] == [1, 2] and sh["bill"]["kwh"] == {1: 1000, 2: 1100}
    assert [m["name"] for m in sh["meters"]] == ["METER MAIN", "MH9120", "MH9120", "GR9230", "OFFICE", "CANTEEN"]
    assert [a["name"] for a in sh["areas"]] == ["MFG Line", "Office", "Other"] and sh["areas"][2]["residual"]
    assert "Heat split" in sh["skipped_areas"]
    assert [i["name"] for i in sh["items"]] == ["AR-5", "SKT"] and sh["work_days"][1] == 22
    assert sh["sales"] == {1: 5000, 2: 5200}
    # มิเตอร์จากไฟล์ประจำวันที่มีอยู่แล้ว (เลข No. ต่างกัน) → จับคู่ด้วย Section + ชื่อ + ลำดับ
    pre, _ = EN.upsert_meter(db, f1, "elec", C.meter_key("LINE A", "MH9120", 78), "78", "MH9120", "LINE A", "kWh", None, 1)
    res = C.em_commit(db, p, {1: f1}, {"bills": 1, "meters": 1, "areas": 1, "prod": 1}, adm)
    assert res["bills"] == 2 and res["meters_new"] == 5 and res.get("meters_match") == 1 and res["areas"] == 3
    assert db.execute("SELECT kwh FROM en_month_usage WHERE meter_id=? AND month=?", (pre, f"{Y}-01")).fetchone()[0] == 300
    rc = C.reconcile(db, f1, Y, today=date(Y, 3, 1))
    rows = {r["area"]["name"]: r for r in rc["rows"]}
    assert rows["MFG Line"]["meas"][0] == 600 and rows["Office"]["meas"][0] == 90
    assert sum(r["kwh"][0] for r in rc["rows"]) == pytest.approx(1000) and sum(r["baht"][1] for r in rc["rows"]) == pytest.approx(4400)
    assert rc["prod"]["total"][0] == 2100 and rc["prod"]["sales"][1] == 5200            # น้ำหนักเริ่ม 1 (ปรับเองได้)
    # นำเข้าซ้ำ: ไม่สร้างซ้ำ · ค่ากรอกเองไม่ถูกทับ
    C.set_month_usage(db, pre, f"{Y}-01", 333, adm)
    res = C.em_commit(db, C.parse_em(_em_book(), Y), {1: f1}, {"bills": 1, "meters": 1, "areas": 1, "prod": 1}, adm)
    assert res["meters_new"] == 0 and res["areas"] == 0
    assert db.execute("SELECT kwh, src FROM en_month_usage WHERE meter_id=? AND month=?", (pre, f"{Y}-01")).fetchone()[:] == (333, "manual")


def test_daily_parser():
    wb = Workbook()
    ws = wb.active
    ws.title = "1"
    ws["A1"] = "บันทึกการใช้ไฟฟ้าประจำวัน"
    for c, v in enumerate(["Section", "Name Meter", "No.", "Modbus Ad", "ยกมา"], start=1):
        ws.cell(2, c, v)
    for d in range(1, 32):
        ws.cell(3, 5 + d, d)
        ws.cell(3, 37 + d, d)
    ws["A4"], ws["B4"], ws["C4"], ws["E4"] = "LINE A", "MH9120", 30, 1000
    ws["C5"] = 31
    for d in range(1, 11):
        ws.cell(4, 5 + d, 1000 + d * 10)
        ws.cell(5, 5 + d, 500 + d)
        ws.cell(4, 37 + d, f"=IF(F4=0,0,F4-E4)")
    buf = io.BytesIO()
    wb.save(buf)
    p = EN.parse_file(buf.getvalue(), "Daily_Aisin1_2025.xlsx", Y)
    keys = [m["key"] for m in p["meters"]]
    assert keys == ["LINE A | MH9120 | 30", "LINE A | MH9120 | 31"]
    m = p["meters"][0]
    assert m["readings"][f"{Y - 1}-12-31"] == 1000 and m["readings"][f"{Y}-01-10"] == 1100 and len(m["readings"]) == 11


def test_pages(app, client, db):
    f1 = app.config["F1"]
    adm = uid(db, "t_admin")
    a = _meter(db, f1, "A", "LINE", 1000, 100)
    ar = C.save_area(db, f1, {"name": "Line"}, adm)
    C.save_links(db, ar, [{"meter_id": a, "factor": 1}], adm)
    OPS.save_bill(db, {"factory_id": f1, "month": f"{Y}-01", "kwh": 5000, "amount": 20000}, adm)
    db.commit()
    tok = login(client, "t_tech")
    for tab in ("alloc", "daily", "em", "meters", "setup"):
        r = client.get(f"/energy/cost/?tab={tab}&year={Y}&factory={f1}&month={Y}-01")
        assert r.status_code == 200, tab
    assert "= บิล ✓".encode() in client.get(f"/energy/cost/?tab=alloc&year={Y}&factory={f1}").data
    assert client.get(f"/energy/cost/area/{ar}?year={Y}").status_code == 200
    r = client.post(f"/energy/cost/area/{ar}", data={"csrf_token": tok, "name": "hack"})
    assert r.status_code == 302 and C.area(db, ar)["name"] == "Line"                 # ช่างดูได้ แก้สูตรไม่ได้
    assert client.post("/energy/cost/setup", data={"csrf_token": tok, "act": "cfg", "factory": f1}).status_code in (302, 403)
    assert C.fcfg(db, f1)["method"] == "prop"
    r = client.get(f"/energy/cost/alloc.xlsx?factory={f1}&year={Y}")
    assert r.status_code == 200 and r.data[:2] == b"PK"
    assert client.get(f"/energy/cost/em.xlsx?year={Y}").data[:2] == b"PK"
    client.get("/logout")
    tok = login(client, "t_admin")
    r = client.post(f"/energy/cost/area/{ar}", data={"csrf_token": tok, "name": "Line A", "grp": "MFG", "driver": "total",
                                                     "mid": [str(a)], f"on_{a}": "1", f"fx_{a}": "0.8", "year": Y})
    assert r.status_code == 302 and C.links(db, ar)[0]["factor"] == 0.8 and C.area(db, ar)["name"] == "Line A"
    r = client.post("/energy/cost/setup", data={"csrf_token": tok, "act": "item", "factory": f1, "name": "AR-5", "unit": "Unit", "weight": "1"})
    assert r.status_code == 302 and C.items(db, f1)[0]["name"] == "AR-5"
    r = client.post("/energy/cost/month-usage", data={"csrf_token": tok, "factory": f1, "year": Y, "meter_id": a, "m_1": "4000", "o_1": "3100"})
    assert r.status_code == 302 and C.meter_months(db, f1, Y)[a]["kwh"][0] == 4000
    r = client.post("/energy/cost/import", data={"csrf_token": tok, "year": Y, "file": (io.BytesIO(_em_book()), "Energy management.xlsx")},
                    content_type="multipart/form-data")
    assert r.status_code == 200 and "ยืนยันนำเข้า".encode() in r.data
    token = r.data.decode().split('name="token" value="')[1].split('"')[0]
    r = client.post("/energy/cost/import/confirm", data={"csrf_token": tok, "token": token, f"f_1": f1, "bills": "1", "meters": "1",
                                                         "areas": "1", "prod": "1"})
    assert r.status_code == 302
    assert db.execute("SELECT COUNT(*) FROM en_areas WHERE factory_id=?", (f1,)).fetchone()[0] == 4


def test_total_weights():
    items = [{"name": n, "row": r, "weight": 1.0} for n, r in (("AR-5", 187), ("Piece", 188), ("SKT", 189), ("DP02", 190), ("AW", 191))]
    C._weights(items, "=DR187+((DR189+DR190+DR191)/20)")
    assert [i["weight"] for i in items] == [1.0, 0.0, 0.05, 0.05, 0.05]
