"""v0.78: หน้าจับคู่ Tag จัดกลุ่มตามเครื่อง (เครื่อง → หัวข้อ, สถานะต่อเครื่อง, ช่องขั้นสูงซ่อนได้)"""
import sqlite3

from conftest import login

from ecs import connectors as CN
from ecs import services as S
from ecs import tagmatch as TM
from ecs.services import ts


def _src(db, tmp_path, tags):
    path = str(tmp_path / "scada.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    con.executemany("INSERT INTO h VALUES (?,?,?)", [(t, ts(S.now_dt()), 1.5) for t in tags])
    con.commit()
    con.close()
    sid = CN.save_source(db, {"name": "SCADA", "kind": "sqlite", "bucket_min": 60, "agg": "last",
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                         "backfill_days": 1}}, None)
    CN.run_source(db, sid)
    db.commit()
    return sid


def test_short_and_guess():
    s = TM._short(["data:F1 Air.SCT0004.1DIS_PRESS", "data:F1 Air.SCT0004.OIL_TEMP"])
    assert s["data:F1 Air.SCT0004.1DIS_PRESS"] == "1DIS_PRESS" and s["data:F1 Air.SCT0004.OIL_TEMP"] == "OIL_TEMP"
    assert TM._short(["ONLY.ONE"]) == {"ONLY.ONE": "ONE"}
    codes = [("SCT0004", 4), ("SCT000", 9)]
    assert TM._guess("data:F1.SCT0004.PRESS", codes) == 4
    assert TM._guess("data:F1.SCT00041.PRESS", codes) is None       # ต้องเป็นคำเต็ม
    assert TM._guess("RANDOM", codes) is None


def test_group_tags(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    eq = db.execute("SELECT e.code FROM cs_forms f JOIN equipment e ON e.id=f.equipment_id WHERE f.id=?", (fid,)).fetchone()[0]
    tags = [f"data:Air.{eq}.OIL", f"data:Air.{eq}.HOUR", f"data:Air.{eq}.DUP", "XYZ_RANDOM"]
    sid = _src(db, tmp_path, tags)
    CN.save_mapping(db, sid, [{"tag": tags[0], "target": f"{fid}:oil"}, {"tag": tags[2], "target": f"{fid}:oil"}], None)
    db.commit()
    lt = CN.list_tags(db, sid)
    g = TM.group_tags(db, sid, lt, {})
    by = {x["form_id"]: x for x in g["groups"]}
    assert set(by) == {fid, None} and g["groups"][-1]["form_id"] is None       # ไม่รู้เครื่อง อยู่ท้าย
    m = by[fid]
    assert m["status"] == "warn" and m["n_unmapped"] == 1 and m["n_dup"] == 2 and m["eq_code"] == eq
    kinds = {r["short"]: r["kind"] for r in m["tags"]}
    assert kinds == {"OIL": "mapped", "HOUR": "guess", "DUP": "mapped"}
    assert m["tags"][0]["kind"] == "guess"                                      # ยังไม่จับคู่ขึ้นก่อน
    assert all(lt[r["idx"]]["tag"] == r["tag"] for x in g["groups"] for r in x["tags"])
    assert any(k == "oil" for k, _ in g["forms"][fid]["items"])
    assert g["totals"] == {"groups": 1, "tags": 4, "mapped": 2, "todo": 0, "warn": 1, "unknown": 1, "unmapped": 2}
    assert {x["key"] for x in m["missing"]} == {k for k, _ in g["forms"][fid]["items"]} - {"oil"}


def test_page_and_save_by_idx(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    eq = db.execute("SELECT e.code FROM cs_forms f JOIN equipment e ON e.id=f.equipment_id WHERE f.id=?", (fid,)).fetchone()[0]
    tags = [f"A.{eq}.OIL", f"A.{eq}.HOUR", "ZZZ"]
    sid = _src(db, tmp_path, tags)
    c = app.test_client()
    tok = login(c, "t_admin")
    html = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    for s in ("tm-grp", "ไม่รู้ว่าเป็นของเครื่องไหน", "เครื่องที่ยังไม่ครบ", "แสดงตัวคูณ / ค่าบวก / ช่วงค่า", 'name="idx"', "tmForms", "บันทึกการจับคู่"):
        assert s in html, s
    lt = [t["tag"] for t in CN.list_tags(db, sid)]
    i_oil, i_hr = lt.index(tags[0]), lt.index(tags[1])
    # ส่งแถวสลับลำดับ (ตามกลุ่ม) — ต้องจับคู่ตาม idx ไม่ใช่ลำดับแถว
    data = {"csrf_token": tok, "tag": [tags[1], tags[0]], "idx": [str(i_hr), str(i_oil)],
            f"target.{i_oil}": f"{fid}:oil", f"target.{i_hr}": "", f"scale.{i_oil}": "10", f"offset.{i_oil}": "0",
            f"scale.{i_hr}": "1", f"offset.{i_hr}": "0", "reapply_days": "0"}
    r = c.post(f"/admin/sources/{sid}/tags", data=data)
    assert r.status_code == 302
    row = db.execute("SELECT form_id, item_key, scale FROM cs_source_tags WHERE source_id=? AND tag=?", (sid, tags[0])).fetchone()
    assert (row["form_id"], row["item_key"], row["scale"]) == (fid, "oil", 10)
    assert db.execute("SELECT form_id FROM cs_source_tags WHERE source_id=? AND tag=?", (sid, tags[1])).fetchone()[0] is None
    html = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert "×10" in html                                                          # ป้ายค่าขั้นสูงเมื่อซ่อนช่อง
