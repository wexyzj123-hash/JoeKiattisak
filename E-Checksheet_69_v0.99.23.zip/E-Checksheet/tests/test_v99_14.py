"""v0.99.14: ภาพเคลื่อนไหวเปลี่ยนหน้า + แดชบอร์ดโลกอนาคต — ไฟล์/โครงหน้าที่ต้องมี (ทดสอบการทำงานจริงด้วยเบราว์เซอร์แยก)"""
from pathlib import Path

from conftest import login

ROOT = Path(__file__).resolve().parents[1] / "ecs"


def test_base_wires_view_transitions(client):
    login(client, "t_admin")
    html = client.get("/dashboard").get_data(as_text=True)
    assert html.index("static/js/motion.js") < html.index("static/js/fx.js")
    assert 'rel="expect" href="#vt-ready" blocking="render"' in html and 'id="vt-ready"' in html
    assert html.index("addEventListener('pagereveal'") < html.index("<body")            # จับก่อน fx.js โหลด
    assert "viewTransitionName='ecs-active'" in html and html.index("viewTransitionName='ecs-active'") < html.index("<main")
    assert "dash-luxe" in html and "lx-hero" in html


def test_css_and_js_respect_reduced_motion():
    css = (ROOT / "static/css/app.css").read_text(encoding="utf-8")
    assert "@view-transition { navigation: auto; }" in css
    for name in ("ecs-top", "ecs-side", "ecs-page", "ecs-active"):
        assert name in css
    tail = css[css.index("v0.99.14"):]
    assert "prefers-reduced-motion: reduce" in tail and "@media print" in tail
    assert "perspective: 1600px; }" not in tail                     # ไม่ใส่ perspective บนกล่องที่มีแผง fixed
    js = (ROOT / "static/js/fx.js").read_text(encoding="utf-8")
    assert "prefers-reduced-motion" in js and "data-od" in js       # ไม่ขึ้นแถบโหลดเมื่อเปิดแผงดูต่อ


def test_other_pages_still_render(client):
    login(client, "t_admin")
    for url in ("/rounds", "/alerts", "/submissions", "/reports", "/equipment"):
        r = client.get(url)
        assert r.status_code == 200, url
        assert 'id="vt-ready"' in r.get_data(as_text=True)
