"""v0.41: แก้รอบตรวจ → ผูกผลตรวจย้อนหลังใหม่และคำนวณตรงเวลา/ล่าช้าใหม่ · ผู้ดูแลระบบลบ/คืนสถิติ · ไม่นับแบบฟอร์มที่ไม่มีรอบตรวจ"""
from datetime import datetime, time, timedelta

from conftest import GOOD, login, payload, uid

from ecs import analytics as AN
from ecs import anomaly as A
from ecs import services as S
from ecs import statfix as SF
from ecs import submissions as SUB


def _setup(db, fid, times="08:00", window=60):
    admin = uid(db, "t_admin")
    sid = S.create_schedule(db, fid, {"freq_type": "daily", "times": times, "window_min": window}, admin)
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (S.ts(S.now_dt() - timedelta(days=3)),))
    S.generate_rounds(db)
    S.refresh_round_statuses(db)
    db.commit()
    return sid


def _submit_at(app, db, form, when: datetime, link_round=None):
    SUB.create_submission(db, payload(form, GOOD), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    sub = db.execute("SELECT MAX(id) FROM cs_submissions").fetchone()[0]
    db.execute("UPDATE cs_rounds SET submission_id=NULL, status='missed' WHERE submission_id=?", (sub,))
    db.execute("UPDATE cs_submissions SET finished_at=?, scanned_at=?, round_id=? WHERE id=?",
               (S.ts(when), S.ts(when), link_round, sub))
    if link_round:
        r = db.execute("SELECT * FROM cs_rounds WHERE id=?", (link_round,)).fetchone()
        db.execute("UPDATE cs_rounds SET submission_id=?, status=? WHERE id=?",
                   (sub, S.round_status_for_submission(dict(r), when), link_round))
    db.commit()
    return sub


def _yday():
    return (S.now_dt() - timedelta(days=1)).date()


def test_schedule_change_relinks_and_fixes_late(app, db, published_form):
    fid = published_form["form_id"]
    sid = _setup(db, fid, "08:00", 60)
    y = _yday()
    r8 = db.execute("SELECT id FROM cs_rounds WHERE form_id=? AND due_at=?",
                    (fid, S.ts(datetime.combine(y, time(8, 0))))).fetchone()[0]
    sub = _submit_at(app, db, published_form, datetime.combine(y, time(10, 30)), link_round=r8)
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (r8,)).fetchone()[0] == "done_late"
    # แจ้งเตือนขาดตรวจของรอบอื่นที่จะหายไป
    c = app.test_client()
    tok = login(c, "t_admin")
    r = c.post(f"/schedules/{sid}", data={"csrf_token": tok, "freq_type": "daily", "times": "10:00", "window_min": "120"})
    assert r.status_code == 302
    assert db.execute("SELECT COUNT(*) FROM cs_rounds WHERE id=?", (r8,)).fetchone()[0] == 0     # รอบ 08:00 เดิมถูกลบ
    rnd = db.execute("SELECT * FROM cs_rounds WHERE form_id=? AND due_at=?",
                     (fid, S.ts(datetime.combine(y, time(10, 0))))).fetchone()
    assert rnd["submission_id"] == sub and rnd["status"] == "done_on_time"
    assert db.execute("SELECT round_id FROM cs_submissions WHERE id=?", (sub,)).fetchone()[0] == rnd["id"]
    st = db.execute("SELECT * FROM cs_daily_stats WHERE form_id=? AND stat_date=?", (fid, y.isoformat())).fetchone()
    assert st["done_on_time"] == 1 and st["done_late"] == 0
    flashes = c.get(f"/forms/{fid}").get_data(as_text=True)
    assert "คำนวณรอบตรวจย้อนหลังใหม่" in flashes
    assert db.execute("SELECT COUNT(*) FROM cs_audit WHERE action='relink'").fetchone()[0] == 1


def test_relink_closes_missed_alert_and_no_new_missed_alert(app, db, published_form, monkeypatch):
    # รอบเมื่อวาน 08:00 จะ "ปิด" (ขาดตรวจ) ก็ต่อเมื่อเลยรอบถัดไป (วันนี้ 08:00) แล้วเท่านั้น
    # เดิมเทสต์นี้ล้มถ้ารันก่อน 08:00 → ตรึงเวลาของระบบไว้ที่ 12:00 เพื่อให้ผลไม่ขึ้นกับเวลาที่รัน
    real = S.now_dt()
    fixed = real if real.hour >= 12 else datetime.combine(real.date(), time(12, 0))
    monkeypatch.setattr(S, "now_dt", lambda: fixed)
    fid = published_form["form_id"]
    _setup(db, fid, "08:00", 60)
    y = _yday()
    r8 = db.execute("SELECT * FROM cs_rounds WHERE form_id=? AND due_at=?",
                    (fid, S.ts(datetime.combine(y, time(8, 0))))).fetchone()
    assert r8["status"] == "missed"
    A.check_missed(db)
    db.commit()
    assert db.execute("SELECT COUNT(*) FROM cs_alerts WHERE alert_type='missed' AND status='open'").fetchone()[0] >= 1
    # ช่างตรวจจริงตอน 09:30 แต่ระบบไม่ได้ผูกรอบ (นอกรอบ) → ขยายเวลาเป็น 3 ชม. แล้วคำนวณใหม่
    sub = _submit_at(app, db, published_form, datetime.combine(y, time(9, 30)))
    S.update_schedule(db, db.execute("SELECT id FROM cs_schedules WHERE form_id=?", (fid,)).fetchone()[0],
                      {"window_min": 180}, uid(db, "t_admin"))
    st = SF.relink_forms(db, [fid], actor_id=uid(db, "t_admin"))
    db.commit()
    assert st["relinked"] >= 1
    r = db.execute("SELECT status, submission_id FROM cs_rounds WHERE id=?", (r8["id"],)).fetchone()
    assert r["status"] == "done_on_time" and r["submission_id"] == sub
    a = db.execute("SELECT status FROM cs_alerts WHERE alert_type='missed' AND round_id=?", (r8["id"],)).fetchone()
    assert a["status"] == "closed"
    before = db.execute("SELECT COUNT(*) FROM cs_alerts WHERE alert_type='missed'").fetchone()[0]
    A.check_missed(db)
    assert db.execute("SELECT COUNT(*) FROM cs_alerts WHERE alert_type='missed'").fetchone()[0] == before


def test_unscheduled_form_not_in_stats(app, db, published_form):
    fid = published_form["form_id"]
    sid = _setup(db, fid, "08:00", 60)
    y = _yday()
    AN.ensure_stats(db, y, y)
    assert AN.heatmap(db, y, y)["rows"]
    db.commit()
    c = app.test_client()
    tok = login(c, "t_admin")
    c.post(f"/schedules/{sid}/delete", data={"csrf_token": tok})
    assert db.execute("SELECT COUNT(*) FROM cs_daily_stats WHERE form_id=?", (fid,)).fetchone()[0] == 0
    assert not AN.heatmap(db, y, y)["rows"]
    assert all(v is None for sr in AN.compliance_trend(db, y, y)["series"] for v in sr["data"])
    assert any(f["id"] == fid for f in SF.unscheduled_forms(db))
    html = c.get("/admin/round-stats").get_data(as_text=True)
    assert "แบบฟอร์มที่ยังไม่กำหนดรอบตรวจ (1)" in html and "Daily AC" in html


def test_admin_exclude_and_restore_stats(app, db, published_form):
    fid = published_form["form_id"]
    _setup(db, fid, "08:00", 60)
    y = _yday()
    r8 = db.execute("SELECT id FROM cs_rounds WHERE form_id=? AND due_at=?",
                    (fid, S.ts(datetime.combine(y, time(8, 0))))).fetchone()[0]
    sub = _submit_at(app, db, published_form, datetime.combine(y, time(10, 30)), link_round=r8)
    c = app.test_client()
    tok = login(c, "t_admin")
    data = {"csrf_token": tok, "day_from": y.isoformat(), "day_to": y.isoformat(), "factory_id": str(app.config["F1"])}
    html = c.post("/admin/round-stats", data={**data, "action": "preview"}).get_data(as_text=True)
    assert "จะลบ" in html and "ยืนยันลบสถิติ" in html
    # ต้องมีเหตุผล · ลบวันนี้ไม่ได้
    c.post("/admin/round-stats", data={**data, "action": "exclude"})
    assert db.execute("SELECT COUNT(*) FROM cs_stat_excl").fetchone()[0] == 0
    today = S.now_dt().date().isoformat()
    c.post("/admin/round-stats", data={**data, "day_to": today, "action": "exclude", "reason": "ทดลองระบบ"})
    assert db.execute("SELECT COUNT(*) FROM cs_stat_excl").fetchone()[0] == 0
    r = c.post("/admin/round-stats", data={**data, "action": "exclude", "reason": "ช่วงทดลองตั้งรอบผิด"})
    assert r.status_code == 302
    assert db.execute("SELECT COUNT(*) FROM cs_rounds WHERE form_id=? AND substr(due_at,1,10)=?",
                      (fid, y.isoformat())).fetchone()[0] == 0
    assert db.execute("SELECT round_id FROM cs_submissions WHERE id=?", (sub,)).fetchone()[0] is None   # ผลตรวจยังอยู่
    S.generate_rounds(db)                                                                           # ไม่สร้างซ้ำ
    db.commit()
    assert db.execute("SELECT COUNT(*) FROM cs_rounds WHERE form_id=? AND substr(due_at,1,10)=?",
                      (fid, y.isoformat())).fetchone()[0] == 0
    assert not AN.heatmap(db, y, y)["rows"]
    db.commit()
    page = c.get("/admin/round-stats").get_data(as_text=True)
    assert "ช่วงทดลองตั้งรอบผิด" in page and "ยกเลิก (คืนสถิติ)" in page
    xid = db.execute("SELECT id FROM cs_stat_excl").fetchone()[0]
    c.post("/admin/round-stats", data={"csrf_token": tok, "action": "restore", "excl_id": str(xid)})
    rnd = db.execute("SELECT * FROM cs_rounds WHERE form_id=? AND due_at=?",
                     (fid, S.ts(datetime.combine(y, time(8, 0))))).fetchone()
    assert rnd and rnd["submission_id"] == sub and rnd["status"] == "done_late"
    assert db.execute("SELECT COUNT(*) FROM cs_stat_excl").fetchone()[0] == 0


def test_admin_only_and_dashboard_link(app, db, published_form):
    c = app.test_client()
    login(c, "t_sup")
    assert c.get("/admin/round-stats").status_code in (302, 403)
    assert "จัดการสถิติ" not in c.get("/dashboard").get_data(as_text=True)
    c2 = app.test_client()
    login(c2, "t_admin")
    assert "จัดการสถิติ" in c2.get("/dashboard").get_data(as_text=True)


def test_relink_keeps_offline_link_after_close(app, db, published_form):
    """ผลตรวจที่ผูกรอบไว้แล้วแต่ส่งหลังปิดรอบ (ออฟไลน์) ต้องไม่หลุดจากรอบเมื่อคำนวณใหม่"""
    fid = published_form["form_id"]
    _setup(db, fid, "08:00", 60)
    y = _yday()
    r8 = db.execute("SELECT id FROM cs_rounds WHERE form_id=? AND due_at=?",
                    (fid, S.ts(datetime.combine(y, time(8, 0))))).fetchone()[0]
    sub = _submit_at(app, db, published_form, datetime.combine(y + timedelta(days=1), time(9, 0)), link_round=r8)
    SF.relink_forms(db, [fid])
    db.commit()
    assert db.execute("SELECT submission_id FROM cs_rounds WHERE id=?", (r8,)).fetchone()[0] == sub


def test_close_schedule_removes_today_rounds_and_live_stamp(app, db, published_form):
    """ปิดรอบตรวจ → รอบวันนี้/พรุ่งนี้ที่ยังไม่ตรวจหายไปทันที · แจ้งเตือนของรอบนั้นปิดอัตโนมัติ · หน้าจอที่เปิดค้างรู้ว่าข้อมูลเปลี่ยน"""
    fid = published_form["form_id"]
    sid = _setup(db, fid, "00:00", 30)
    today = S.now_dt().date()
    r_today = db.execute("SELECT id FROM cs_rounds WHERE form_id=? AND substr(due_at,1,10)=?", (fid, today.isoformat())).fetchone()[0]
    A.check_missed(db)
    db.commit()
    c = app.test_client()
    tok = login(c, "t_admin")
    s1 = c.get("/api/live").get_json()
    assert s1["stamp"] and c.get("/api/live").get_json()["stamp"] == s1["stamp"]
    assert "data-live" in c.get("/rounds").get_data(as_text=True) and "js/live.js" in c.get("/dashboard").get_data(as_text=True)
    c.post(f"/schedules/{sid}/delete", data={"csrf_token": tok})
    assert db.execute("SELECT COUNT(*) FROM cs_rounds WHERE id=?", (r_today,)).fetchone()[0] == 0
    assert db.execute("SELECT COUNT(*) FROM cs_rounds WHERE form_id=? AND submission_id IS NULL", (fid,)).fetchone()[0] == 0
    assert db.execute("""SELECT COUNT(*) FROM cs_alerts WHERE alert_type='missed' AND form_id=?
                         AND status IN ('open','acknowledged','in_progress')""", (fid,)).fetchone()[0] == 0
    assert c.get("/api/live").get_json()["stamp"] != s1["stamp"]
    assert "Daily AC" not in c.get("/rounds").get_data(as_text=True)
    assert "live-new" in c.get("/static/js/live.js").get_data(as_text=True)
