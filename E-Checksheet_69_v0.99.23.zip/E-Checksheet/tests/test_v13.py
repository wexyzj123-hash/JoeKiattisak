"""v0.13: ป็อปอัปสแกน QR ที่จุดตรวจ · พิมพ์ป้ายจุดตรวจรวมกับป้ายเครื่องจักร (แยกหมวด)"""
import pathlib

from conftest import login, uid
from test_v10 import _form

from ecs import points as PT
from ecs import services as S


def _scan_form(app, db, code="AC-01"):
    fid = _form(app, db, code)
    S.update_form_meta(db, fid, {"require_point_scan": 1}, uid(db, "t_admin"))
    db.commit()
    return fid, S.get_form(db, fid)["equipment_id"]


def test_equipment_labels_have_both_categories(app, db):
    fid, eq = _scan_form(app, db)
    c = app.test_client(); login(c, "t_sup")
    with app.test_request_context():
        tank, pump = PT.point_code(fid, "TANK"), PT.point_code(fid, "PUMP")
    html = c.get(f"/equipment/qr-labels?id={eq}").get_data(as_text=True)
    assert "ก. ป้ายเครื่องจักร" in html and "ข. ป้ายจุดตรวจ" in html
    assert tank in html and pump in html and html.index("ก. ป้ายเครื่องจักร") < html.index(tank)
    # พิมพ์เฉพาะหมวด
    only_pts = c.get(f"/equipment/qr-labels?id={eq}&kind=points").get_data(as_text=True)
    assert 'id="catM"' in only_pts and 'class="cat hide" id="catM"' in only_pts and tank in only_pts
    # หน้าเครื่องจักรแสดงหมวดจุดตรวจ + ปุ่มพิมพ์ทั้งหมด
    page = c.get(f"/equipment/{eq}").get_data(as_text=True)
    assert "ป้ายจุดตรวจ" in page and "พิมพ์ป้ายทั้งหมด (3)" in page and "kind=points" in page


def test_form_point_labels_redirect_to_equipment_page(app, db):
    fid, eq = _scan_form(app, db, "AC-07")
    c = app.test_client(); login(c, "t_sup")
    r = c.get(f"/forms/{fid}/point-labels")
    assert r.status_code == 302 and "/equipment/qr-labels" in r.headers["Location"] and "kind=points" in r.headers["Location"]


def test_forms_without_point_scan_not_listed(app, db):
    fid = _form(app, db, "AC-09")
    eq = S.get_form(db, fid)["equipment_id"]
    assert PT.scan_forms(db, [eq]) == []
    c = app.test_client(); login(c, "t_sup")
    html = c.get(f"/equipment/qr-labels?id={eq}").get_data(as_text=True)
    assert "ต้องสแกน QR ที่จุดตรวจก่อนกรอก" in html


def test_fill_js_has_scan_popup():
    js = (pathlib.Path(__file__).parents[1] / "ecs/static/m/fill.js").read_text(encoding="utf-8")
    assert "function scanPopup" in js and "pendingPoints()" in js and "data-openscan" in js
