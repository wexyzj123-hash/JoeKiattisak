"""v0.84: เครื่องหยุด / สำรอง → ไม่ลงค่าจาก SCADA (รายงานยึดสถานะเครื่องจักร)"""
from conftest import emo, login, uid
from test_v73 import _at, _day, _hist, _rows, _setup, _slots

from ecs import connectors as CN
from ecs import downtime as DT
from ecs import srcmap as SM
from ecs.services import ts


def _states(db, sid, day, now):
    return [x["state"] for f in SM.slot_status(db, sid, day, now=now) for x in f["slots"]]


def test_no_scada_while_down(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 12))                        # รอบ 08:30 ลงค่าแล้ว (เครื่องเดินอยู่)
    DT.record_down(db, published_form["equipment_id"], uid(db, "t_admin"), "ไม่ได้เดิน", "standby", _at(day, 19))
    db.commit()
    CN.run_source(db, sid, now=_at(day, 23))
    db.commit()
    assert _slots(db, day) == [f"{day} 08:30:00"]                     # 20:30 เครื่องสำรอง → ไม่ลง
    assert _states(db, sid, day, _at(day, 23)) == ["done", "down"]
    assert SM.health(db, sid, now=_at(day, 23), days=0)["count"]["missing"] == 0
    assert SM.prefill_slot(db, published_form["form_id"], _at(day, 20, 30)) == {}
    src = CN.get_source(db, sid)
    assert CN.create_auto_submission(db, src, published_form["form_id"], _at(day, 21), {"oil": 2.0}) is None
    rep = SM.audit(db, sid, day, day, now=_at(day, 23))
    row = [r for r in rep["forms"][0]["rows"] if r["hm"] == "20:30"][0]
    assert row["down"] and row["cells"]["oil"]["state"] == "down" and not row["problem"]


def test_down_later_removes_existing_values(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 23))
    db.commit()
    assert _slots(db, day) == [f"{day} 08:30:00", f"{day} 20:30:00"]
    eq = published_form["equipment_id"]
    DT.record_down(db, eq, uid(db, "t_admin"), "สำรอง", "standby", _at(day, 19))   # แจ้งหยุดย้อนหลัง
    db.commit()
    assert _slots(db, day) == [f"{day} 08:30:00"]
    st = db.execute("SELECT status FROM cs_rounds WHERE form_id=? AND due_at=?", (published_form["form_id"], ts(_at(day, 20, 30)))).fetchone()
    assert st[0] == "skipped"
    # รายงานประจำเดือน: ช่อง 20:30 ไม่มีค่า (แสดง "หยุด")
    from ecs import sheet_report as SR
    sh = SR.build_month_sheet(db, published_form["form_id"], day.replace(day=1), "x")
    oil = [r for r in sh["rows"] if r["it"]["item_key"] == "oil"][0]
    ln = [x for x in oil["lines"] if x["label"] == "20:30"][0]
    assert ln["cells"][day.day - 1] is None and ln["down"][day.day - 1]
    # ช่วงหยุดถูกแก้ให้สั้นลง (เดินเครื่องก่อน 20:30) → ลงค่ากลับจากค่าดิบที่เก็บไว้
    db.execute("UPDATE cs_downtime SET end_at=? WHERE equipment_id=?", (ts(_at(day, 20)), eq))
    db.execute("UPDATE equipment SET run_status='running', down_since=NULL WHERE id=?", (eq,))
    db.execute("UPDATE cs_rounds SET status='pending' WHERE form_id=? AND due_at=?", (published_form["form_id"], ts(_at(day, 20, 30))))
    r = SM.on_downtime_change(db, eq, _at(day, 19), None, None)
    db.commit()
    assert r["created"] >= 1 and f"{day} 20:30:00" in _slots(db, day)


def test_purge_all_and_audit_page(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 23))
    eq = published_form["equipment_id"]
    db.execute("""INSERT INTO cs_downtime(equipment_id, start_at, reason, category) VALUES (?,?,?,?)""",
               (eq, ts(_at(day, 6)), "สำรอง", "standby"))         # ข้อมูลเดิมก่อนอัปเดต (ค่าลงไว้แล้วระหว่างหยุด)
    db.commit()
    assert len(_slots(db, day)) == 2
    assert SM.purge_down_all(db, 62) == 2
    db.commit()
    assert _slots(db, day) == []
    c = app.test_client()
    login(c, "t_admin")
    page = c.get(f"/admin/sources/{sid}/audit", query_string={"from": day.isoformat(), "to": day.isoformat()}).get_data(as_text=True)
    assert "⛔ หยุด" in emo(page) and "s-down" in page


def test_old_downtime_report_and_sweep(app, db, published_form, tmp_path):
    """v0.84.1 ช่วงหยุดที่บันทึกก่อนอัปเดต (ค่าจาก SCADA ลงไว้แล้ว) → ใบบันทึกไม่แสดงทันที + งานเบื้องหลัง/ปุ่มเอาค่าออก"""
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 23))
    eq, fid = published_form["equipment_id"], published_form["form_id"]
    db.execute("INSERT INTO cs_downtime(equipment_id, start_at, reason, category) VALUES (?,?,?,?)",
               (eq, ts(_at(day, 19)), "สำรอง", "standby"))            # ยังหยุดอยู่
    db.commit()
    assert len(_slots(db, day)) == 2
    from ecs import sheet_report as SR
    sh = SR.build_month_sheet(db, fid, day.replace(day=1), "x")
    oil = [r for r in sh["rows"] if r["it"]["item_key"] == "oil"][0]
    by = {ln["label"]: ln for ln in oil["lines"]}
    assert by["20:30"]["cells"][day.day - 1] is None and by["20:30"]["down"][day.day - 1]
    assert by["08:30"]["cells"][day.day - 1] is not None
    assert SM.count_down(db) == 1
    c = app.test_client()
    tok = login(c, "t_admin")
    assert "ค่าจาก SCADA ค้างอยู่ในช่วงเครื่องหยุด" in c.get("/admin/sources/issues").get_data(as_text=True)
    assert SM.sweep_down(db) == 1
    db.commit()
    assert _slots(db, day) == [f"{day} 08:30:00"]
    assert SM.sweep_down(db) is None                                  # ทุกชั่วโมง
    db.execute("INSERT INTO cs_downtime(equipment_id, start_at, end_at, reason, category) VALUES (?,?,?,?,?)",
               (eq, ts(_at(day, 6)), ts(_at(day, 9)), "PM", "pm"))
    db.commit()
    r = c.post("/admin/sources/purge-down", data={"csrf_token": tok})
    assert r.status_code in (302, 303) and _slots(db, day) == []
