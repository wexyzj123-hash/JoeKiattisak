"""v0.59: บันทึกหยุดย้อนหลังทับช่วงเดิม (ช่วงใหม่แทนส่วนที่ซ้อน) · ตั้งแต่เวลาหยุด = งดตรวจ ไม่ขาดตรวจ"""
from datetime import datetime, timedelta

from conftest import uid

from ecs import downtime as DT
from ecs import services as S


def _sched(db, fid):
    sid = S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00"}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (fid,))
    return sid


def _round(db, sid, fid, due, hours=2, status="missed"):
    return db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                         VALUES (?,?,?,?,?,?,?)""", (sid, fid, S.ts(due), S.ts(due + timedelta(hours=hours)),
                                                     S.ts(due + timedelta(hours=hours * 2)), status, S.ts(due))).lastrowid


def _periods(db, eq):
    return [(r[0], r[1]) for r in db.execute("SELECT start_at, end_at FROM cs_downtime WHERE equipment_id=? ORDER BY start_at", (eq,))]


def test_override_open_downtime_with_earlier_start(app, db, published_form):
    """เครื่องค้างหยุดตั้งแต่ 12:36 → บันทึกย้อนหลังว่าหยุดตั้งแต่เมื่อวาน 20:00 (ยังหยุดอยู่) → ช่วงใหม่แทนช่วงเดิม"""
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    sid = _sched(db, fid)
    now = S.now_dt().replace(second=0, microsecond=0)
    DT.set_down(db, eq, uid(db, "t_tech"), "สำรอง", "standby", start_at=now - timedelta(hours=2))
    missed = _round(db, sid, fid, now - timedelta(hours=10))                     # ขาดตรวจไปแล้ว (ก่อนกดหยุดเดิม)
    db.commit()
    res = DT.record_down(db, eq, uid(db, "t_sup"), "หยุดตามแผน", "stop", now - timedelta(hours=16))
    db.commit()
    assert res["replaced"] == 1
    assert _periods(db, eq) == [(S.ts(now - timedelta(hours=16)), None)]
    e = db.execute("SELECT run_status, down_since FROM equipment WHERE id=?", (eq,)).fetchone()
    assert e["run_status"] == "down" and e["down_since"] == S.ts(now - timedelta(hours=16))
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (missed,)).fetchone()[0] == "skipped"


def test_override_splits_and_trims_closed_periods(app, db, published_form):
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    sid = _sched(db, fid)
    base = datetime.combine(S.now_dt().date() - timedelta(days=4), datetime.min.time())
    DT.record_down(db, eq, uid(db, "t_sup"), "เดิม", "repair", base + timedelta(hours=6), base + timedelta(hours=18))
    db.commit()
    later = _round(db, sid, fid, base + timedelta(hours=13), hours=1, status="pending")   # ปิด 15:00 (ในช่วงเดิม)
    db.execute("UPDATE cs_rounds SET status='skipped' WHERE id=?", (later,))
    # ใหม่ 10:00–12:00 อยู่กลางช่วงเดิม → แยกเป็น 06–10 + 12–18
    res = DT.record_down(db, eq, uid(db, "t_sup"), "ใหม่", "pm", base + timedelta(hours=10), base + timedelta(hours=12))
    assert res["replaced"] == 1
    assert _periods(db, eq) == [(S.ts(base + timedelta(hours=6)), S.ts(base + timedelta(hours=10))),
                                (S.ts(base + timedelta(hours=10)), S.ts(base + timedelta(hours=12))),
                                (S.ts(base + timedelta(hours=12)), S.ts(base + timedelta(hours=18)))]
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (later,)).fetchone()[0] == "skipped"   # ยังอยู่ในช่วง 12–18
    # ใหม่ 05:00–14:00 ครอบ 06–10, 10–12 และตัดหัว 12–18 → 14–18 · รอบ 15:00 ยังงดตรวจ
    DT.record_down(db, eq, uid(db, "t_sup"), "ใหม่2", "pm", base + timedelta(hours=5), base + timedelta(hours=14))
    assert _periods(db, eq) == [(S.ts(base + timedelta(hours=5)), S.ts(base + timedelta(hours=14))),
                                (S.ts(base + timedelta(hours=14)), S.ts(base + timedelta(hours=18)))]
    # ใหม่ทับทั้งหมดแต่จบ 13:00 → รอบปิด 15:00 ไม่อยู่ในช่วงหยุดแล้ว → คืนเป็นขาดตรวจ
    DT.record_down(db, eq, uid(db, "t_sup"), "ใหม่3", "pm", base + timedelta(hours=4), base + timedelta(hours=13))
    db.execute("DELETE FROM cs_downtime WHERE equipment_id=? AND start_at=?", (eq, S.ts(base + timedelta(hours=14))))
    DT.fix_stale_skipped(db)
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (later,)).fetchone()[0] == "missed"


def test_set_down_now_skips_missed_round_still_open(app, db, published_form):
    """กดหยุด (ย้อนเวลา) → รอบที่ขาดตรวจแต่ปิดรอบหลังเวลาหยุด → งดตรวจ"""
    fid, eq = published_form["form_id"], published_form["equipment_id"]
    sid = _sched(db, fid)
    now = S.now_dt().replace(second=0, microsecond=0)
    r = _round(db, sid, fid, now - timedelta(hours=8), hours=2)                     # due -8h ปิด -4h
    db.commit()
    DT.set_down(db, eq, uid(db, "t_tech"), "ซ่อม", "repair", start_at=now - timedelta(hours=6))
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (r,)).fetchone()[0] == "skipped"
