"""v0.76: แบบทุกช่วงเวลา (bucket) ใช้กลไกช่องเวลา · แก้เลื่อนเวลา/จับคู่/วิธีลงค่า → ลงค่าใหม่ย้อนหลังเอง · ย่อค่าดิบ"""
import json
from datetime import timedelta

from conftest import login, uid
from test_v73 import _at, _day, _hist, _rows, _setup

from ecs import connectors as CN
from ecs import services as S
from ecs import srcmap as SM
from ecs.services import ts


def _bucket_subs(db, sid, day):
    return {r[0][-6:]: r[1] for r in db.execute("""SELECT s.client_uuid, a.value_num FROM cs_submissions s JOIN cs_answers a ON a.submission_id=s.id
                                                    WHERE s.client_uuid LIKE ? AND s.finished_at LIKE ? AND a.item_key='oil'""",
                                                 (f"src{sid}:%", f"{day}%"))}


def _val(db, t):
    r = db.execute("""SELECT a.value_num FROM cs_submissions s JOIN cs_answers a ON a.submission_id=s.id
                      WHERE s.source='auto' AND s.finished_at=? AND a.item_key='oil'""", (ts(t),)).fetchone()
    return r[0] if r else None


def test_bucket_uses_slots_late_data_and_fix(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day, start=6 * 60, end=12 * 60, skip=(9 * 60, 10 * 60)))
    sid = _setup(db, published_form, path)
    fid = published_form["form_id"]
    SM.save_form_cfgs(db, sid, [{"form_id": fid, "mode": "bucket"}], None)
    CN.run_source(db, sid, now=_at(day, 12, 5))
    b = _bucket_subs(db, sid, day)
    assert "085959" in b and "095959" not in b and "105959" in b
    assert b["085959"] == 8.5                                            # ค่าล่าสุดของช่วง 08:00–08:59
    _hist(path, [r for r in _rows(day, start=9 * 60, end=10 * 60)])      # ค่าช่วง 09:00 มาช้า
    CN.run_source(db, sid, now=_at(day, 12, 25))
    assert "095959" in _bucket_subs(db, sid, day)
    admin = uid(db, "t_admin")
    SM.set_fix(db, sid, fid, _at(day, 10, 59).replace(second=59), "oil", "value", "7.77", "แก้ทดสอบ", admin)
    SM.relay(db, sid, day, day, admin, {fid})
    assert _bucket_subs(db, sid, day)["105959"] == 7.77
    rep = SM.audit(db, sid, day, day, now=_at(day, 12, 30))
    assert rep["forms"] and any(r["hm"] == "10:59" and r["cells"]["oil"]["state"] == "fixed" for r in rep["forms"][0]["rows"])
    sub = db.execute("SELECT id FROM cs_submissions WHERE client_uuid LIKE ? AND finished_at=?", (f"src{sid}:%", f"{day} 08:59:59")).fetchone()[0]
    SM.void_submission(db, sub, "ทดสอบยกเลิก", admin)
    CN.run_source(db, sid, now=_at(day, 12, 50))
    assert "085959" not in _bucket_subs(db, sid, day)


def test_shift_change_reapplies(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day, start=0))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 23))
    assert _val(db, _at(day, 8, 30)) == 8.3
    wm = CN.get_source(db, sid)["watermark"]
    src = CN.get_source(db, sid)
    CN.save_source(db, {**{k: src[k] for k in ("name", "kind", "interval_min", "bucket_min", "agg", "keep_days", "late_min")},
                        "ts_shift_min": 420, "config": src["config"], "active": "1", "prefill": "0"}, None, sid)
    assert CN.get_source(db, sid)["watermark"] == ts(S.parse_ts(wm) + timedelta(minutes=420))
    SM.reapply(db, sid, 3, uid(db, "t_admin"), shift=True, now=_at(day, 23, 5))
    assert _val(db, _at(day, 8, 30)) == 1.3                              # ค่า 01:30 (UTC) = 08:30 เวลาไทย


def test_mapping_and_mode_change_reapply_via_pages(app, db, published_form, tmp_path):
    day = S.now_dt().date() - timedelta(days=1)
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    fid = published_form["form_id"]
    CN.run_source(db, sid)
    db.commit()
    v0 = _val(db, _at(day, 8, 30))
    c = app.test_client()
    tok = login(c, "t_admin")
    r = c.post(f"/admin/sources/{sid}/tags", data={"csrf_token": tok, "tag": ["OIL"], "target.0": f"{fid}:oil", "scale.0": "10",
                                                  "offset.0": "0", "reapply_days": "3"}, follow_redirects=True)
    assert "ลงค่าใหม่ย้อนหลัง" in r.get_data(as_text=True)
    assert abs(_val(db, _at(day, 8, 30)) - v0 * 10) < 1e-6
    r = c.post(f"/admin/sources/{sid}/forms", data={"csrf_token": tok, "form_id": str(fid), f"mode.{fid}": "round", f"pick.{fid}": "max",
                                                   f"win.{fid}": "30", f"times.{fid}": "", "reapply_days": "3"}, follow_redirects=True)
    assert "ลงค่าใหม่ย้อนหลัง" in r.get_data(as_text=True)
    assert abs(_val(db, _at(day, 8, 30)) - 9.0 * 10) < 1e-6              # ค่าสูงสุด 08:00–09:00 = 09:00 → 9.0
    page = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert "reapply_days" in page and "ค่าดิบที่เก็บไว้" in page


def test_compaction_keeps_slot_windows(app, db, published_form, tmp_path):
    old = S.now_dt().date() - timedelta(days=6)
    path = str(tmp_path / "h.db")
    _hist(path, _rows(old, start=0, end=24 * 60, step=1))
    sid = _setup(db, published_form, path)
    src = CN.get_source(db, sid)
    rows, _k, _b = CN.fetch(db, src, tags=["OIL"], since=_at(old, 0) - timedelta(minutes=1), until=_at(old, 23, 59))
    SM.store_values(db, src, rows, prune=False)
    SM.fill_slots(db, src, d_from=old, d_to=old)
    before = db.execute("SELECT COUNT(*) FROM cs_source_values WHERE source_id=?", (sid,)).fetchone()[0]
    assert before >= 1400
    n = SM.compact(db, CN.get_source(db, sid), max_days=10)
    after = db.execute("SELECT COUNT(*) FROM cs_source_values WHERE source_id=?", (sid,)).fetchone()[0]
    assert n > 1200 and after <= 2 * 61 + 2
    assert CN.get_source(db, sid)["compacted_until"] >= old.isoformat()
    rep = SM.audit(db, sid, old, old)
    assert all(r["cells"]["oil"]["state"] in ("pending", "ok") for r in rep["forms"][0]["rows"])   # ยังตรวจเทียบได้ ไม่ขึ้น ≠
    assert SM.raw_stats(db, sid)["rows"] == after


def test_energy_mapping_change_reapply(app, db, client, tmp_path):
    from datetime import datetime, time

    from ecs import energy as EN
    from ecs import energy_src as ES
    f1 = app.config["F1"]
    day = _day()
    path = str(tmp_path / "e.db")
    _hist(path, [("KWH1", ts(datetime.combine(day, time(8, 0))), 1000.0)])
    sid = ES.save_source(db, {"name": "E", "kind": "sqlite", "active": "1",
                              "config": json.dumps({"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                                    "backfill_days": 2})}, None)
    mid = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "K1", "name": "K1", "scada_source_id": str(sid),
                                   "scada_tag": "KWH1"}, None)
    ES.run_source(db, sid)
    db.commit()
    assert db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()[0] == 1000
    tok = login(client, "t_admin")
    r = client.post(f"/energy/sources/{sid}/tags", data={"csrf_token": tok, "tag": ["KWH1"], "meter.0": f"#{mid}", "scale.0": "2",
                                                         "offset.0": "0", "reapply_days": "3"}, follow_redirects=True)
    assert "ลงค่าอ่านใหม่ย้อนหลัง" in r.get_data(as_text=True)
    assert db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()[0] == 2000
