"""v0.63: Energy Data ระบบมิเตอร์ไฟฟ้าในตัว (ไม่ผูก EMS) — แก้ค่า+ประวัติ · วันหยุด · บิลค่าไฟ/ผลผลิต ·
ตรวจความผิดปกติ 7 กฎ + เคสติดตาม · รายงานตาม Section"""
from datetime import date, timedelta

from conftest import login, uid

from ecs import energy as EN
from ecs import energy_ops as OPS

D0, D1 = date(2026, 8, 1), date(2026, 9, 30)


def _mk(db, fid, code, grp, is_main=0, kind="elec"):
    return EN.save_meter(db, None, {"factory_id": fid, "kind": kind, "code": code, "name": f"Meter {code}", "grp": grp,
                                    "is_main": str(is_main), "multiplier": "1"}, None)


def _feed(db, mid, fn, until=D1):
    v = 10000.0
    d = D0
    EN.set_reading(db, mid, (D0 - timedelta(days=1)).isoformat(), v, None, src="t")
    while d <= until:
        v += fn(d)
        EN.set_reading(db, mid, d.isoformat(), v, None, src="t")
        d += timedelta(days=1)


def _sun(d):
    return d.weekday() == 6


def _seed(db, fid):
    m = _mk(db, fid, "M1", "MAIN", 1)
    a = _mk(db, fid, "A1", "Press")
    b = _mk(db, fid, "B1", "Machining")
    c = _mk(db, fid, "C1", "UT")
    dd = _mk(db, fid, "D1", "Light")
    e = _mk(db, fid, "E1", "Compressor")
    f = _mk(db, fid, "F1", "Pump")
    _feed(db, m, lambda d: 300 if _sun(d) else 1000)
    _feed(db, a, lambda d: (590 if d == date(2026, 9, 13) else 100) if _sun(d) else (100 if d == date(2026, 9, 10) else 600))
    _feed(db, b, lambda d: 100 if _sun(d) else (900 if d == date(2026, 9, 15) else 300))
    _feed(db, dd, lambda d: 5 if _sun(d) else (0 if date(2026, 9, 22) <= d <= date(2026, 9, 25) else 50))
    _feed(db, e, lambda d: (60 if _sun(d) else 200) if d >= date(2026, 9, 17) else (20 if _sun(d) else 100))
    _feed(db, f, lambda d: 5 if _sun(d) else 40, until=date(2026, 9, 20))
    _feed(db, c, lambda d: 10 if _sun(d) else 80)
    # วันที่ 20/09 มิเตอร์ C ถูกเปลี่ยน → เลขลดลง
    old = db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day='2026-09-20'", (c,)).fetchone()[0]
    EN.set_reading(db, c, "2026-09-20", 50, None, src="t")
    db.commit()
    return {"m": m, "a": a, "b": b, "c": c, "d": dd, "e": e, "f": f, "c_old": old}


def test_no_ems_link(app):
    assert "EMS_DB" not in app.config and "EMS_URL" not in app.config
    assert not hasattr(EN, "ems_sync")


def test_scan_rules_and_cases(app, db):
    f1 = app.config["F1"]
    ids = _seed(db, f1)
    res = OPS.scan(db, f1, "elec", 30, today=D1)
    rules = {x["rule"] for x in res["items"]}
    assert rules == set(OPS.RULES), rules
    by = lambda r, mid=None: [x for x in res["items"] if x["rule"] == r and (mid is None or x["meter_id"] == mid)]
    assert by("negative", ids["c"])[0]["day"] == "2026-09-20"
    sp = by("spike", ids["b"])
    assert sp and sp[0]["day"] == "2026-09-15" and sp[0]["impact"] == 600 and sp[0]["baht"] == round(600 * 4.2)
    assert by("stuck", ids["d"])[0]["day"] == "2026-09-25"
    assert by("missing", ids["f"])[0]["detail"].startswith("ค่าล่าสุด 20/09/2026")
    assert [x["day"] for x in by("holiday_load", ids["a"])] == ["2026-09-13"]
    assert not by("holiday_load", ids["m"])                    # วันอาทิตย์ปกติ 30% ไม่เตือน
    assert by("baseload_up", ids["e"])
    assert "2026-09-10" in [x["day"] for x in by("balance")]
    assert all(x["hints"] for x in res["items"])
    assert by("baseload_up", ids["e"])[0]["hints"][0].startswith("ลมอัดรั่ว")   # ชื่อ Compressor → คำแนะนำเฉพาะ

    # วันหยุดที่บันทึกในปฏิทิน → วันที่ 10/09 กลายเป็นวันหยุด กฎ holiday ตรวจวันนั้นด้วย
    OPS.add_holiday(db, f1, "2026-09-16", "หยุดซ่อมบำรุง", "shutdown", None)
    assert "2026-09-16" in OPS.off_days(db, f1, date(2026, 9, 1), D1, EN.settings(db))
    res2 = OPS.scan(db, f1, "elec", 30, today=D1)
    assert any(x["rule"] == "holiday_load" and x["day"] == "2026-09-16" for x in res2["items"])

    # เปิดเคส → ซ้ำได้ id เดิม → สถานะผูกกับผลตรวจ
    x = sp[0]
    cid = OPS.open_case(db, {k: x[k] for k in ("rule", "severity", "title", "detail", "meter_id", "factory_id", "kind", "grp", "day",
                                               "impact", "baht")}, uid(db, "t_admin"))
    assert OPS.open_case(db, {**x, "hints": None}, None) == cid
    res3 = OPS.scan(db, f1, "elec", 30, today=D1)
    assert next(y for y in res3["items"] if y["rule"] == "spike" and y["meter_id"] == ids["b"])["case_id"] == cid
    import pytest
    from ecs.services import ValidationError
    with pytest.raises(ValidationError):
        OPS.update_case(db, cid, {"status": "fixed", "cause": "เดินเครื่องเพิ่ม/เพิ่มกะ"}, None)    # ต้องมีวิธีแก้
    OPS.update_case(db, cid, {"status": "fixed", "cause": "อุปกรณ์เปิดค้าง", "action": "ปิดฮีตเตอร์", "saved": "1200"}, None)
    c = OPS.case(db, cid)
    assert c["status"] == "fixed" and c["closed_at"] and c["saved"] == 1200
    summ = OPS.case_summary(db, f1)
    assert summ["status"]["fixed"] == 1 and summ["saved"]["elec"]["units"] == 1200
    OPS.update_case(db, cid, {"status": "checking"}, None)
    assert OPS.case(db, cid)["closed_at"] is None and OPS.case(db, cid)["saved"] == 0
    db.commit()


def test_correction_bill_section_report(app, db):
    f1 = app.config["F1"]
    ids = _seed(db, f1)
    c = ids["c"]
    import pytest
    from ecs.services import ValidationError
    with pytest.raises(ValidationError):
        OPS.correct(db, c, "2026-09-20", "", "80", "", None)        # ต้องมีเหตุผล
    OPS.correct(db, c, "2026-09-20", "", "80", "เปลี่ยนมิเตอร์ใหม่", uid(db, "t_admin"))
    s = EN.series(db, [EN.meter(db, c)], date(2026, 9, 19), date(2026, 9, 22))[c]
    assert s["2026-09-20"]["u"] == 80 and s["2026-09-20"]["flag"] == "fix"
    log = OPS.fix_log(db, c)
    assert log[0]["field"] == "u_override" and log[0]["new_value"] == 80 and log[0]["reason"] == "เปลี่ยนมิเตอร์ใหม่"
    assert not any(x["rule"] == "negative" for x in OPS.scan(db, f1, "elec", 30, today=D1)["items"])
    OPS.correct(db, c, "2026-09-20", "", "", "ยกเลิกการแก้", None)          # ล้างหน่วยที่แก้ → กลับใช้ผลต่าง
    assert EN.series(db, [EN.meter(db, c)], date(2026, 9, 20), date(2026, 9, 20))[c]["2026-09-20"]["flag"] == "reset"

    # บิลค่าไฟ → อัตราจริง → ภาพรวมคิดเงินตามบิล
    OPS.save_bill(db, {"factory_id": f1, "month": "2026-09", "kwh": "30000", "amount": "120000", "ft": "", "demand": "", "vat": ""}, None)
    assert round(OPS.bill_rate(db, f1, "2026-09"), 4) == round(128400 / 30000, 4)
    OPS.save_production(db, {"factory_id": f1, "month": "2026-09", "qty": "15000", "unit": "ชิ้น"}, None)
    cr = OPS.cost_report(db, 2026, f1)
    sep = cr["factories"][0]["rows"][8]
    assert sep["meter_kwh"] == 26 * 1000 + 4 * 300
    assert sep["rate"] == round(128400 / 30000, 4) and sep["kwh_unit"] == 2.0 and sep["diff_pct"] is not None
    assert cr["chart"]
    d = EN.dashboard(db, date(2026, 9, 1), f1, "elec", today=D1)
    k = d["kinds"][0]
    assert abs(k["cost"] - round(k["total"] * 128400 / 30000)) <= 1
    # รายงานตาม Section
    rep = OPS.section_report(db, f1, "elec", 2026)
    g = {r["grp"]: r for r in rep["rows"]}
    assert {"Press", "Machining", "UT", "Light", "Compressor", "Pump"} <= set(g) and "MAIN" not in g
    assert rep["has_main"] and rep["unmetered"] is not None
    i8 = rep["months"].index(8)
    assert rep["total"][i8] == 26 * 1000 + 5 * 300
    assert abs(rep["total"][i8] - rep["sub_total"][i8] - rep["unmetered"][i8]) < 0.01
    assert OPS.section_xlsx(db, f1, "elec", 2026)[:2] == b"PK"
    db.commit()


def test_pages(app, client, db):
    f1 = app.config["F1"]
    ids = _seed(db, f1)
    tok = login(client, "t_admin")
    P = lambda url, data: client.post(url, data={**data, "csrf_token": tok})
    for u in ("/energy/anomalies", f"/energy/anomalies?factory={f1}&kind=elec&days=60", "/energy/anomalies?tab=cases&status=all",
              "/energy/report", f"/energy/report?tab=sections&factory={f1}&kind=elec&year=2026", "/energy/report?tab=cost&year=2026",
              "/energy/settings", f"/energy/meters/{ids['c']}", "/energy/", "/energy/meters?kind=elec"):
        r = client.get(u)
        assert r.status_code == 200, u
        assert b"EMS" not in r.data, u
    r = client.get(f"/energy/report/sections.xlsx?factory={f1}&kind=elec&year=2026")
    assert r.status_code == 200 and r.data[:2] == b"PK"
    # แก้ค่าผ่านหน้าเว็บ
    r = P(f"/energy/meters/{ids['c']}/fix", {"day": "2026-09-20", "value": "", "u_fix": "80", "reason": "เปลี่ยนมิเตอร์"})
    assert r.status_code == 302
    assert OPS.fix_log(db, ids["c"])
    # เปิดเคสจากหน้าเว็บ → หน้าเคส → ปิด
    r = P("/energy/cases/open", {"rule": "spike", "severity": "high", "title": "t", "detail": "d", "meter_id": ids["b"],
                                                 "factory_id": f1, "kind": "elec", "grp": "Machining", "day": "2026-09-15",
                                                 "impact": "600", "baht": "2520"})
    assert r.status_code == 302 and "/energy/cases/" in r.headers["Location"]
    cid = int(r.headers["Location"].rstrip("/").split("/")[-1])
    r = client.get(f"/energy/cases/{cid}")
    assert r.status_code == 200 and "ควรตรวจอะไร".encode() in r.data and b"ch-case" in r.data
    r = P(f"/energy/cases/{cid}", {"status": "fixed", "cause": "อุปกรณ์เปิดค้าง", "action": "ตั้งเวลาปิด", "saved": "500",
                                                 "assignee_id": str(uid(db, "t_admin"))})
    assert r.status_code == 302 and OPS.case(db, cid)["status"] == "fixed"
    # บิล + ยอดผลิต + วันหยุด + เกณฑ์
    assert P("/energy/report/cost", {"act": "bill", "factory_id": f1, "month": "2026-09", "kwh": "30000", "amount": "120000",
                                                    "year": "2026"}).status_code == 302
    assert P("/energy/report/cost", {"act": "prod", "factory_id": f1, "month": "2026-09", "qty": "1000", "year": "2026"}).status_code == 302
    r = client.get("/energy/report?tab=cost&year=2026")
    assert "4.2800".encode() in r.data and b"en-cost" in r.data
    assert P("/energy/settings", {"act": "holiday", "day": "2026-10-13", "name": "วันหยุดทดสอบ", "factory_id": "",
                                                 "kind": "holiday"}).status_code == 302
    assert any(h["name"] == "วันหยุดทดสอบ" for h in OPS.holidays(db, 2026))
    assert P("/energy/settings", {"act": "cfg", "z_high": "3.5", "sunday_off": "0"}).status_code == 302
    cfg = EN.settings(db)
    assert cfg["z_high"] == 3.5 and cfg["sunday_off"] == 0
    P("/energy/cases/open", {"rule": "stuck", "severity": "warn", "meter_id": ids["d"], "factory_id": f1, "kind": "elec",
                              "day": "2026-09-25"})
    r = client.get("/energy/classic?month=2026-09")
    assert "เคสความผิดปกติที่ยังไม่ปิด 1 เคส".encode() in r.data


def test_permissions(app, client, db):
    f1 = app.config["F1"]
    ids = _seed(db, f1)
    tok = login(client, "t_tech")
    P = lambda url, data: client.post(url, data={**data, "csrf_token": tok})
    assert client.get("/energy/anomalies").status_code == 200
    # v0.64: ช่างแก้ค่าย้อนหลังของโรงงานตัวเองได้ (มีเหตุผล + ประวัติ)
    assert P(f"/energy/meters/{ids['c']}/fix", {"day": "2026-09-20", "u_fix": "1", "reason": "xxx"}).status_code == 302
    assert OPS.fix_log(db, ids["c"])
    assert P("/energy/report/cost", {"act": "bill", "factory_id": f1, "month": "2026-09", "kwh": "1"}).status_code in (302, 403)
    assert not db.execute("SELECT 1 FROM en_bills").fetchone()
    assert client.get("/energy/settings").status_code in (302, 403)


def test_big_readings_not_rounded(app, client, db):
    """เลขหน้าปัดไฟฟ้าหลักล้าน ต้องแสดง/ส่งกลับครบทุกหลัก (เดิม %g ปัดเป็น 1.1136e+07)"""
    f1 = app.config["F1"]
    mid = _mk(db, f1, "BIG", "MAIN", 1)
    day = date.today() - timedelta(days=1)
    EN.set_reading(db, mid, day.isoformat(), 11135969.9, None)
    db.commit()
    login(client, "t_admin")
    r = client.get(f"/energy/entry?factory={f1}&kind=elec&day={day.isoformat()}")
    assert b"11135969.9" in r.data and b"e+07" not in r.data
    r = client.get(f"/energy/meters/{mid}")
    assert b'data-v="11135969.9"' in r.data
