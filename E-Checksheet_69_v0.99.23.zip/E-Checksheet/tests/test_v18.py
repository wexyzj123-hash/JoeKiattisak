"""v0.18: เชื่อมสถานะช่าง UT-CMMS — เปิดหน้ากรอก = ตรวจเช็ค · ส่งผล = ปิดสถานะ + นับเวลา"""
import json
import sqlite3
from datetime import datetime, timedelta

import pytest
from conftest import GOOD, login, payload, uid

from ecs import cmms_status as ST
from ecs import submissions as SUB

NOW = datetime.now().replace(microsecond=0)


@pytest.fixture()
def cmms(app, tmp_path):
    path = tmp_path / "cmms.db"
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, name TEXT, role TEXT);
    CREATE TABLE tech_custom_status (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER UNIQUE, status_text TEXT,
      status_type TEXT, set_by INTEGER, set_at TEXT);
    CREATE TABLE tech_status_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, status_type TEXT, status_text TEXT,
      start_at TEXT, end_at TEXT, duration_minutes REAL, set_by INTEGER);
    INSERT INTO users VALUES (1,'admin','Admin','admin'), (2,'somchai','สมชาย','technician');
    """)
    con.commit()
    con.close()
    app.config.update(CMMS_DATABASE=str(path))
    yield {"path": str(path)}
    app.config.pop("CMMS_DATABASE", None)


def _q(cmms, sql, *a):
    con = sqlite3.connect(cmms["path"])
    con.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in con.execute(sql, a).fetchall()]
    finally:
        con.close()


def _exec(cmms, sql, *a):
    con = sqlite3.connect(cmms["path"])
    con.execute(sql, a)
    con.commit()
    con.close()


def _setup(db, after="clear"):
    db.execute("UPDATE users SET legacy_id=2 WHERE username='t_tech'")
    ST.save_settings(db, {"enabled": "1", "after_done": after, "stale_minutes": "60"}, uid(db, "t_admin"))
    db.commit()


def _sub(app, db, form, start, end):
    p = payload(form, GOOD, scanned_at=start.strftime("%Y-%m-%d %H:%M:%S"), finished_at=end.strftime("%Y-%m-%d %H:%M:%S"))
    res = SUB.create_submission(db, p, {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"], now=end)
    db.commit()
    return res["id"]


def test_http_start_submit_closes_status(app, db, published_form, cmms):
    _setup(db)
    # ช่างตั้งสถานะเองไว้ก่อน (UT-CMMS) → เปิดหน้ากรอกแล้วถูกปิดด้วยกฎของ UT-CMMS
    _exec(cmms, "INSERT INTO tech_custom_status(user_id,status_text,status_type,set_by,set_at) VALUES (2,'งานปรับปรุง','improvement',2,?)",
          (NOW - timedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S"))
    _exec(cmms, "INSERT INTO tech_status_log(user_id,status_type,status_text,start_at) VALUES (2,'improvement','งานปรับปรุง',?)",
          (NOW - timedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S"))
    c = app.test_client()
    tok = login(c, "t_tech")
    fid = published_form["form_id"]
    r = c.post("/api/m/status/start", json={"form_id": fid}, headers={"X-CSRF-Token": tok})
    assert r.status_code == 200 and r.get_json()["status"] == "Daily AC (SCT0002)"
    cs = _q(cmms, "SELECT * FROM tech_custom_status WHERE user_id=2")[0]
    assert cs["status_type"] == "inspection" and "Daily AC" in cs["status_text"]
    logs = _q(cmms, "SELECT * FROM tech_status_log ORDER BY id")
    assert logs[0]["end_at"] and logs[0]["duration_minutes"] is not None           # สถานะเดิมถูกปิด
    assert logs[1]["status_type"] == "inspection" and logs[1]["end_at"] is None
    # เปิดซ้ำ (รีโหลดหน้า) → ไม่สร้างรายการใหม่
    c.post("/api/m/status/start", json={"form_id": fid}, headers={"X-CSRF-Token": tok})
    assert len(_q(cmms, "SELECT * FROM tech_status_log")) == 2
    p = payload(published_form, GOOD)
    body = c.post("/api/m/submissions", headers={"X-CSRF-Token": tok}, data={"payload": json.dumps(p)},
                  content_type="multipart/form-data").get_json()
    assert body["status_minutes"] >= 0
    assert _q(cmms, "SELECT * FROM tech_custom_status") == []                         # ปิดสถานะ
    lg = _q(cmms, "SELECT * FROM tech_status_log ORDER BY id")[1]
    assert lg["end_at"] and lg["duration_minutes"] is not None
    assert db.execute("SELECT state FROM cs_status_sync").fetchone()[0] == "done"
    login(c, "t_admin")
    assert "ตรวจเช็คชีท → สถานะช่าง UT-CMMS" in c.get("/admin/cmms-status").get_data(as_text=True)


def test_minutes_restore_and_route_chain(app, db, published_form, cmms):
    _setup(db, after="restore")
    _exec(cmms, "INSERT INTO tech_custom_status(user_id,status_text,status_type,set_by,set_at) VALUES (2,'งานปรับปรุง','improvement',2,?)",
          NOW.strftime("%Y-%m-%d %H:%M:%S"))
    fid, tech = published_form["form_id"], uid(db, "t_tech")
    t0 = NOW - timedelta(minutes=20)
    assert ST.start(db, app.config, tech, fid, now=t0)["status"]
    sid = _sub(app, db, published_form, t0, t0 + timedelta(minutes=7))
    assert ST.finish(db, app.config, sid, now=t0 + timedelta(minutes=8)) == {"minutes": 7.0}
    cs = _q(cmms, "SELECT * FROM tech_custom_status")[0]
    assert cs["status_text"] == "งานปรับปรุง" and cs["status_type"] == "improvement"         # กลับไปสถานะเดิม
    assert _q(cmms, "SELECT * FROM tech_status_log ORDER BY id DESC")[0]["status_text"] == "งานปรับปรุง"
    assert ST.finish(db, app.config, sid) == {}                                          # ทำครั้งเดียว
    # เดินตรวจ: เปิดเครื่อง A แล้วไปเปิดเครื่อง B → A ถูกปิด · สถานะเดิมยังจำไว้คืนตอนจบ
    ST.start(db, app.config, tech, fid, now=t0 + timedelta(minutes=10))
    from ecs import services as S
    fid2 = S.create_form(db, {"name": "Form B"}, uid(db, "t_admin"))
    db.commit()
    ST.start(db, app.config, tech, fid2, now=t0 + timedelta(minutes=13))
    rows = [dict(r) for r in db.execute("SELECT * FROM cs_status_sync ORDER BY id")]
    assert rows[1]["state"] == "stale" and rows[2]["state"] == "open" and rows[2]["prev_text"] == "งานปรับปรุง"
    assert _q(cmms, "SELECT duration_minutes FROM tech_status_log WHERE id=?", rows[1]["log_id"])[0]["duration_minutes"] == 3.0


def test_pause_resume_expire_and_offline(app, db, published_form, cmms):
    _setup(db)
    fid, tech = published_form["form_id"], uid(db, "t_tech")
    t0 = NOW - timedelta(hours=3)
    ST.start(db, app.config, tech, fid, now=t0)
    assert ST.stop(db, app.config, tech, fid, now=t0 + timedelta(minutes=4)) == 1
    assert _q(cmms, "SELECT * FROM tech_custom_status") == []
    ST.start(db, app.config, tech, fid, now=t0 + timedelta(minutes=10))                  # กลับมาภายใน 15 นาที → นับต่อ
    assert len(_q(cmms, "SELECT * FROM tech_status_log")) == 1
    assert _q(cmms, "SELECT end_at FROM tech_status_log")[0]["end_at"] is None
    sid = _sub(app, db, published_form, t0, t0 + timedelta(minutes=12))
    assert ST.finish(db, app.config, sid, now=t0 + timedelta(minutes=12))["minutes"] == 12.0
    # เปิดค้าง → ปิดอัตโนมัติ นับ 60 นาที · ส่งทีหลัง → ขยายถึงเวลาส่งจริง
    t1 = t0 + timedelta(minutes=30)
    ST.start(db, app.config, tech, fid, now=t1)
    assert ST.expire(db, app.config, now=t1 + timedelta(minutes=61)) == 1
    lg = _q(cmms, "SELECT * FROM tech_status_log ORDER BY id DESC")[0]
    assert lg["duration_minutes"] == 60.0 and "ไม่ได้ส่งผล" in lg["status_text"]
    assert _q(cmms, "SELECT * FROM tech_custom_status") == []
    sid2 = _sub(app, db, published_form, t1, t1 + timedelta(minutes=75))
    assert ST.finish(db, app.config, sid2, now=t1 + timedelta(minutes=76))["minutes"] == 75.0
    assert "ไม่ได้ส่งผล" not in _q(cmms, "SELECT * FROM tech_status_log ORDER BY id DESC")[0]["status_text"]
    # ส่งตอนออฟไลน์ (ไม่ได้เปิดสถานะ) → ลงเวลาย้อนหลัง
    t2 = NOW - timedelta(minutes=40)
    sid3 = _sub(app, db, published_form, t2, t2 + timedelta(minutes=5))
    assert ST.finish(db, app.config, sid3, now=NOW)["minutes"] == 5.0
    lg = _q(cmms, "SELECT * FROM tech_status_log ORDER BY id DESC")[0]
    assert lg["end_at"] and "ออฟไลน์" in lg["status_text"] and lg["user_id"] == 2


def test_disabled_unlinked_and_tpm_time_not_double(app, db, published_form, cmms):
    fid, tech = published_form["form_id"], uid(db, "t_tech")
    assert ST.start(db, app.config, tech, fid) == {}                                    # ปิดไว้
    ST.save_settings(db, {"enabled": "1"}, uid(db, "t_admin"))
    db.commit()
    assert ST.start(db, app.config, tech, fid) == {}                                    # ยังไม่ผูกบัญชี
    assert _q(cmms, "SELECT * FROM tech_status_log") == []
    c = app.test_client()
    tok = login(c, "t_tech")
    assert c.post("/api/m/status/start", json={"form_id": 99999}, headers={"X-CSRF-Token": tok}).status_code == 404
    app.config.pop("CMMS_DATABASE")
    assert c.post("/api/m/status/start", json={"form_id": fid}, headers={"X-CSRF-Token": tok}).get_json() == {}
    assert c.post("/api/m/status/stop", json={}, headers={"X-CSRF-Token": tok}).get_json() == {"stopped": 0}
