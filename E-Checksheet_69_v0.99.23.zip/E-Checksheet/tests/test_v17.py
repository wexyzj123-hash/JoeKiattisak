"""v0.17: เชื่อมแผน TPM ของ UT-CMMS — สแกนตรวจ/ส่งผล → บันทึกทำงาน · อนุมัติ → ยืนยัน · ตีกลับ/ลบ → ย้อนสถานะ"""
import io
import json
import sqlite3
from datetime import date, timedelta

import pytest
from conftest import GOOD, login, payload, png_bytes, uid

from ecs import cmms_tpm as TPM
from ecs import services as S

TODAY = date.today()


@pytest.fixture()
def cmms(app, tmp_path):
    path = tmp_path / "cmms.db"
    con = sqlite3.connect(path)
    con.executescript(f"""
    CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, name TEXT, role TEXT);
    CREATE TABLE equipment (id INTEGER PRIMARY KEY, code TEXT, name TEXT);
    CREATE TABLE tpm_plans (id INTEGER PRIMARY KEY AUTOINCREMENT, equipment_id INTEGER, task TEXT, description TEXT,
      frequency TEXT, assignee_id INTEGER, last_done DATE, next_due DATE, status TEXT DEFAULT 'scheduled',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      frequency_value INTEGER, frequency_unit TEXT, frequency_display TEXT, plan_ahead_months INTEGER,
      work_days TEXT, skip_holidays INTEGER);
    CREATE TABLE tpm_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, tpm_plan_id INTEGER, done_by INTEGER, done_date DATE,
      result TEXT, notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, action_taken TEXT, approved_by INTEGER,
      approved_at TIMESTAMP, actual_date DATE, time_spent REAL, performed_by TEXT, was_overdue INTEGER,
      scheduled_due_date DATE);
    CREATE TABLE tpm_attachments (id INTEGER PRIMARY KEY AUTOINCREMENT, tpm_id INTEGER, filename TEXT, original_name TEXT,
      file_type TEXT, file_size INTEGER, uploaded_by INTEGER, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      tpm_log_id INTEGER);
    CREATE TABLE activity_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT, target_type TEXT,
      target_id INTEGER, details TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    INSERT INTO users VALUES (1,'admin','Admin','admin'), (2,'somchai','สมชาย','technician');
    INSERT INTO equipment VALUES (77,'SCT0002','Air Compressor'), (88,'SCT0099','Other');
    INSERT INTO tpm_plans (id, equipment_id, task, frequency, frequency_display, last_done, next_due, assignee_id) VALUES
      (1, 77, 'Oil Pressure check', 'monthly', '1/M', '{TODAY - timedelta(days=28)}', '{TODAY + timedelta(days=2)}', 2),
      (2, 77, 'Overhaul', 'monthly', '1/Y', NULL, '{TODAY + timedelta(days=90)}', NULL),
      (3, 77, 'Drain', 'monthly', '1/W', '{TODAY - timedelta(days=10)}', '{TODAY - timedelta(days=3)}', NULL),
      (4, 88, 'Other machine', 'monthly', '1/M', NULL, '{TODAY}', NULL);
    """)
    con.commit()
    con.close()
    up = tmp_path / "cmms_uploads"
    app.config.update(CMMS_DATABASE=str(path), CMMS_UPLOAD_FOLDER=str(up))
    yield {"path": str(path), "uploads": up}
    app.config.pop("CMMS_DATABASE", None)
    app.config.pop("CMMS_UPLOAD_FOLDER", None)


def _q(cmms, sql, *a):
    con = sqlite3.connect(cmms["path"])
    con.row_factory = sqlite3.Row
    try:
        return con.execute(sql, a).fetchall()
    finally:
        con.close()


def _setup(app, db, form, links=None, **cfg):
    db.execute("UPDATE equipment SET legacy_id=77 WHERE id=?", (form["equipment_id"],))
    TPM.save_settings(db, {"enabled": "1", "lead_days": "5", "approve_with_submission": "1", "attach_photos": "1", **cfg},
                      uid(db, "t_admin"))
    TPM.save_links(db, app.config, form["form_id"], links if links is not None else {1: [], 2: [], 3: []},
                   uid(db, "t_admin"))
    db.commit()


def _submit(client, tok, form, answers=None, photo=False):
    ans = dict(answers or GOOD)
    data = {}
    if photo:
        ans["noise"] = {"value": "NG", "remark": "มีเสียง", "photos": ["pa"]}
        data["pa"] = (io.BytesIO(png_bytes()), "pa.png")
    data["payload"] = json.dumps(payload(form, ans))
    r = client.post("/api/m/submissions", headers={"X-CSRF-Token": tok}, data=data, content_type="multipart/form-data")
    assert r.status_code == 200, r.get_json()
    return r.get_json()


def test_freq_and_window_rules():
    assert TPM.calc_next_due(date(2026, 1, 31), "1/M") == date(2026, 2, 28)
    assert TPM.calc_next_due(date(2026, 9, 1), "2/M") == date(2026, 9, 16)
    assert TPM.calc_next_due(date(2026, 9, 1), "4/Y") == date(2026, 12, 1)
    assert TPM.freq_display({"frequency": "quarterly", "frequency_display": ""}) == "4/Y"
    cfg = {"lead_days": 5}
    assert TPM.lead_days({"frequency_display": "1/W"}, cfg) == 1
    assert TPM.lead_days({"frequency_display": "1/Y"}, cfg) == 5
    assert TPM.plan_state({"status": "scheduled", "next_due": str(TODAY - timedelta(days=1))}) == "overdue"
    assert TPM.plan_state({"status": "scheduled", "next_due": str(TODAY + timedelta(days=5))}) == "soon"
    assert TPM.plan_state({"status": "awaiting_approval", "next_due": str(TODAY)}) == "awaiting"


def test_scan_submit_records_tpm_and_approve_confirms(app, db, published_form, cmms):
    _setup(app, db, published_form)
    c = app.test_client()
    tok = login(c, "t_tech")
    # หน้างานของฉัน / แพ็กเกจแบบฟอร์ม เห็นแผนที่ถึงช่วงทำ (แผน 1 ใกล้แผน · แผน 3 เกินกำหนด · แผน 2 ยังไม่ถึง)
    tasks = c.get("/api/m/tasks").get_json()
    assert {t["plan_id"] for t in tasks["tpm"]} == {1, 3}
    pkg = c.get(f"/api/m/forms/{published_form['form_id']}/package").get_json()
    assert {t["task"] for t in pkg["tpm"]} == {"Oil Pressure check", "Drain"}
    body = _submit(c, tok, published_form, photo=True)
    assert sorted(body["tpm"]) == ["Drain", "Oil Pressure check"]
    sid = body["id"]
    p1, p2, p3 = [dict(r) for r in _q(cmms, "SELECT * FROM tpm_plans ORDER BY id")[:3]]
    assert p1["status"] == p3["status"] == "awaiting_approval" and p2["status"] == "scheduled"
    assert p1["last_done"] == TODAY.isoformat()
    lg = dict(_q(cmms, "SELECT * FROM tpm_logs WHERE tpm_plan_id=1")[0])
    assert lg["result"] == "issue_found" and lg["done_by"] == 1 and lg["scheduled_due_date"] == p1["next_due"]
    assert "Oil Pressure: 2.1 bar" in lg["notes"] and f"/submissions/{sid}/record" in lg["notes"]
    assert lg["performed_by"] == "ทดสอบ t_tech" and "NG 1" in lg["action_taken"]
    assert len(_q(cmms, "SELECT * FROM tpm_attachments WHERE tpm_log_id=?", lg["id"])) == 1
    assert any(cmms["uploads"].iterdir())
    assert _q(cmms, "SELECT action FROM activity_log")[0][0] == "submit_tpm"
    # ส่งซ้ำระหว่างรอยืนยัน → ไม่บันทึกซ้ำ
    assert "tpm" not in _submit(c, tok, published_form)
    assert len(_q(cmms, "SELECT * FROM tpm_logs")) == 2
    # หัวหน้าเห็นในหน้าผลตรวจ → อนุมัติ = ยืนยันแผน
    tok = login(c, "t_sup")
    page = c.get(f"/submissions/{sid}").get_data(as_text=True)
    assert "แผน TPM (UT-CMMS)" in page and "รอยืนยัน" in page
    r = c.post(f"/submissions/{sid}/approve", data={"csrf_token": tok}, follow_redirects=True)
    assert "ยืนยันแผน TPM ใน UT-CMMS 2 แผน" in r.get_data(as_text=True)
    p1, _, p3 = [dict(r) for r in _q(cmms, "SELECT * FROM tpm_plans ORDER BY id")[:3]]
    assert p1["status"] == "scheduled" and p1["next_due"] == TPM.calc_next_due(TODAY, "1/M").isoformat()
    assert p3["next_due"] == (TODAY + timedelta(days=7)).isoformat()
    lg1 = dict(_q(cmms, "SELECT * FROM tpm_logs WHERE tpm_plan_id=1")[0])
    lg3 = dict(_q(cmms, "SELECT * FROM tpm_logs WHERE tpm_plan_id=3")[0])
    assert lg1["approved_at"] and lg1["was_overdue"] == 0 and lg3["was_overdue"] == 1
    assert {s["state"] for s in TPM.sync_for_submission(db, sid)} == {"approved"}
    assert "ยืนยันแล้ว" in c.get(f"/submissions/{sid}").get_data(as_text=True)


def test_return_and_delete_roll_back(app, db, published_form, cmms):
    _setup(app, db, published_form, links={1: []})
    c = app.test_client()
    tok = login(c, "t_tech")
    sid = _submit(c, tok, published_form)["id"]
    before = dict(_q(cmms, "SELECT * FROM tpm_plans WHERE id=1")[0])
    tok = login(c, "t_sup")
    c.post(f"/submissions/{sid}/return", data={"csrf_token": tok, "note": "ค่าไม่ครบ"})
    p = dict(_q(cmms, "SELECT * FROM tpm_plans WHERE id=1")[0])
    assert p["status"] == "scheduled" and p["next_due"] == before["next_due"]
    assert "[ไม่อนุมัติ: ค่าไม่ครบ" in _q(cmms, "SELECT notes FROM tpm_logs")[0][0]
    assert TPM.sync_for_submission(db, sid)[0]["state"] == "rejected"
    # ส่งใหม่ → บันทึกใหม่ · ลบผลตรวจ → ลบบันทึกทำงานและคืน last_done
    tok = login(c, "t_tech")
    sid2 = _submit(c, tok, published_form)["id"]
    assert dict(_q(cmms, "SELECT * FROM tpm_plans WHERE id=1")[0])["status"] == "awaiting_approval"
    assert len(_q(cmms, "SELECT * FROM tpm_logs")) == 2
    db.execute("UPDATE users SET can_delete_results=1 WHERE username='t_admin'")
    db.commit()
    tok = login(c, "t_admin")
    r = c.post(f"/submissions/{sid2}/delete", data={"csrf_token": tok, "reason": "ส่งผิดเครื่อง"})
    assert r.status_code == 302
    p = dict(_q(cmms, "SELECT * FROM tpm_plans WHERE id=1")[0])
    assert p["status"] == "scheduled" and p["last_done"] == TODAY.isoformat()     # last_done ของครั้งที่ถูกตีกลับ
    assert len(_q(cmms, "SELECT * FROM tpm_logs")) == 1
    assert db.execute("SELECT state FROM cs_tpm_sync WHERE submission_id=?", (sid2,)).fetchone()[0] == "cancelled"


def test_item_scope_window_and_cmms_side_approval(app, db, published_form, cmms):
    # แผน 1 นับเมื่อตรวจ oil + note ครบ (note ไม่ได้กรอก → ไม่นับ) · แผน 2 ยังไม่ถึงช่วง
    _setup(app, db, published_form, links={1: ["oil", "note"], 2: []})
    c = app.test_client()
    tok = login(c, "t_tech")
    assert "tpm" not in _submit(c, tok, published_form)
    body = _submit(c, tok, published_form, answers=dict(GOOD, note={"value": "ปกติ"}))
    assert body["tpm"] == ["Oil Pressure check"]
    lg = dict(_q(cmms, "SELECT * FROM tpm_logs")[0])
    assert lg["result"] == "ok" and "หมายเหตุอื่น: ปกติ" in lg["notes"] and "Running hour" not in lg["notes"]
    # หัวหน้ายืนยันใน UT-CMMS เอง → สถานะกลับมาที่ E-Checksheet (งานเบื้องหลัง)
    con = sqlite3.connect(cmms["path"])
    con.execute("UPDATE tpm_logs SET approved_at='2026-01-01 08:00:00', approved_by=1")
    con.execute("UPDATE tpm_plans SET status='scheduled', next_due='2099-01-01' WHERE id=1")
    con.commit()
    con.close()
    from ecs.jobs import sync_cmms
    sync_cmms(app)
    row = TPM.sync_for_submission(db, body["id"])[0]
    assert row["state"] == "approved" and row["next_due"] == "2099-01-01"
    # อนุมัติใน E-Checksheet ภายหลัง → ไม่คำนวณซ้ำ
    assert TPM.on_approve(db, app.config, [body["id"]], uid(db, "t_sup")) == 0


def test_link_ui_validation_admin_and_autolink(app, db, published_form, cmms):
    db.execute("UPDATE equipment SET legacy_id=77 WHERE id=?", (published_form["equipment_id"],))
    db.commit()
    fid = published_form["form_id"]
    with pytest.raises(S.ValidationError):
        TPM.save_links(db, app.config, fid, {4: []}, uid(db, "t_admin"))          # แผนของเครื่องอื่น
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get(f"/forms/{fid}").get_data(as_text=True)
    assert 'data-tab="tpm"' in page and "Oil Pressure check" in page and "ชื่อตรงกับหัวข้อ" in page
    r = c.post(f"/forms/{fid}/tpm-links", data={"csrf_token": tok, "plan": ["1", "3"], "scope_1": "items",
                                                  "items_1": ["oil", "bogus"], "scope_3": "all", "items_3": ["oil"]})
    assert r.status_code == 302 and r.headers["Location"].endswith("#tpm")
    links = {lk["plan_id"]: lk["items"] for lk in TPM.form_links(db, fid)}
    assert links == {1: ["oil"], 3: []}
    c.post(f"/forms/{fid}/tpm-links", data={"csrf_token": tok})
    assert TPM.form_links(db, fid) == []
    tok = login(c, "t_admin")
    page = c.get("/admin/cmms-tpm").get_data(as_text=True)
    assert "สแกนตรวจ → แผน TPM" in page and "Daily AC" in page
    r = c.post("/admin/cmms-tpm", data={"csrf_token": tok, "action": "auto_link"}, follow_redirects=True)
    assert "เชื่อมอัตโนมัติแล้ว 1 แผน" in r.get_data(as_text=True)
    assert {lk["plan_id"]: lk["items"] for lk in TPM.form_links(db, fid)} == {1: ["oil"]}
    c.post("/admin/cmms-tpm", data={"csrf_token": tok, "enabled": "1", "lead_days": "99"})
    assert TPM.get_settings(db) == {**TPM.DEFAULTS, "enabled": True, "lead_days": 30,
                                    "approve_with_submission": False, "attach_photos": False}


def test_disabled_or_no_cmms_is_harmless(app, db, published_form, cmms):
    _setup(app, db, published_form, enabled="")
    c = app.test_client()
    tok = login(c, "t_tech")
    assert "tpm" not in _submit(c, tok, published_form)
    assert c.get("/api/m/tasks").get_json()["tpm"] == []
    assert _q(cmms, "SELECT COUNT(*) FROM tpm_logs")[0][0] == 0
    app.config.pop("CMMS_DATABASE")
    assert "tpm" not in _submit(c, tok, published_form)
    assert 'data-tab="tpm"' not in c.get(f"/forms/{published_form['form_id']}").get_data(as_text=True)
