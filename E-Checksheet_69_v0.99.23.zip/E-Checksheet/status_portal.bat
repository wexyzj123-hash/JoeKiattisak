@echo off
REM Show whether the server is running and the addresses to open.
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul || set "PY=py"
%PY% tools\portal_ctl.py status
pause
