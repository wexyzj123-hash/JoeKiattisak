@echo off
REM Stop the background UT-CMMS + E-Checksheet server.
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul || set "PY=py"
%PY% tools\portal_ctl.py stop
timeout /t 8
