#!/usr/bin/env python3
"""tools/stop_old.py — หยุด UT-CMMS เดิมที่รันอยู่เบื้องหลัง (ไม่มีหน้าต่างให้ปิด) เพื่อเปิดระบบรวมที่พอร์ต 5000

ทำอะไร:
 1. หาโปรแกรมที่ใช้พอร์ต 5000 อยู่ แสดงว่าเป็นโปรแกรมอะไร (คำสั่งที่ใช้เปิด + โปรแกรมแม่ที่เปิดมัน)
 2. ถามยืนยัน แล้วหยุดโปรแกรมนั้น
 3. รอ 10 วินาที ตรวจว่ามีอะไรเปิด UT-CMMS กลับขึ้นมาเองหรือไม่
 4. หา Task Scheduler / โฟลเดอร์ Startup ที่ตั้งให้ UT-CMMS เปิดเองตอนเปิดเครื่อง แล้วถามว่าจะปิดไหม
    (ไม่ลบ แค่ Disable — เปิดกลับได้ถ้าต้องการถอยกลับ)

ใช้งาน: คลิกขวา stop_old_cmms.bat > Run as administrator
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import time

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

KEYWORDS = re.compile(r"UT-CMMS|utility_cmms|\\start\.bat|Re-start\.bat", re.I)


def run(cmd: list[str], timeout: int = 60) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return ""
    for enc in ("utf-8", "mbcs", "cp874"):
        try:
            return (r.stdout or b"").decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return (r.stdout or b"").decode("utf-8", "replace")


def ps(script: str) -> str:
    return run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script]).strip()


def parse_listening_pids(netstat_text: str, port: int) -> list[int]:
    """แยก PID ที่ LISTEN อยู่บนพอร์ตจากผลของ `netstat -ano`"""
    pids = []
    for line in netstat_text.splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[0].upper() == "TCP" and parts[3].upper() == "LISTENING":
            local = parts[1]
            if local.rsplit(":", 1)[-1] == str(port):
                try:
                    pid = int(parts[4])
                except ValueError:
                    continue
                if pid > 0 and pid not in pids:
                    pids.append(pid)
    return pids


def listening_pids(port: int) -> list[int]:
    return parse_listening_pids(run(["netstat", "-ano", "-p", "TCP"]), port)


def proc_info(pid: int) -> dict:
    out = ps(f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}'; "
             f"if($p){{ $q=Get-CimInstance Win32_Process -Filter ('ProcessId='+$p.ParentProcessId); "
             f"Write-Output ('NAME='+$p.Name); Write-Output ('CMD='+$p.CommandLine); "
             f"Write-Output ('PPID='+$p.ParentProcessId); "
             f"if($q){{ Write-Output ('PNAME='+$q.Name); Write-Output ('PCMD='+$q.CommandLine) }} }}")
    info = {}
    for line in out.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            info[k.strip()] = v.strip()
    return info


def ask(q: str) -> bool:
    try:
        return input(f"{q} [y/N]: ").strip().lower() in ("y", "yes", "ใช่")
    except EOFError:
        return False


def autostart_items() -> tuple[list[str], list[str]]:
    tasks = []
    out = ps("Get-ScheduledTask | ForEach-Object { $a = ($_.Actions | ForEach-Object { $_.Execute + ' ' + $_.Arguments + ' ' + $_.WorkingDirectory }) -join ' ; '; "
             "Write-Output ($_.TaskPath + $_.TaskName + '|' + $_.State + '|' + $a) }")
    for line in out.splitlines():
        parts = line.split("|", 2)
        if len(parts) == 3 and KEYWORDS.search(parts[2]) and "UT-Portal" not in parts[0]:
            tasks.append(f"{parts[0]}|{parts[1]}")
    startup = []
    for folder in (os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), r"Microsoft\Windows\Start Menu\Programs\StartUp"),
                   os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup")):
        if os.path.isdir(folder):
            for name in os.listdir(folder):
                path = os.path.join(folder, name)
                text = name
                if name.lower().endswith((".bat", ".cmd", ".vbs", ".ps1")):
                    try:
                        with open(path, encoding="utf-8", errors="ignore") as fh:
                            text += fh.read(4000)
                    except OSError:
                        pass
                elif name.lower().endswith(".lnk"):
                    text += ps(f"(New-Object -ComObject WScript.Shell).CreateShortcut('{path}').TargetPath + ' ' + "
                               f"(New-Object -ComObject WScript.Shell).CreateShortcut('{path}').Arguments")
                if KEYWORDS.search(text):
                    startup.append(path)
    return tasks, startup


def main() -> int:
    if not sys.platform.startswith("win"):
        print("ใช้บน Windows เท่านั้น")
        return 1
    port = 5000
    for a in sys.argv[1:]:
        if a.isdigit():
            port = int(a)

    print("=" * 66)
    print(f"  หยุด UT-CMMS เดิมที่รันอยู่เบื้องหลัง (พอร์ต {port})")
    print("=" * 66)

    pids = listening_pids(port)
    if not pids:
        print(f"\n✓ ไม่มีโปรแกรมใช้พอร์ต {port} อยู่แล้ว — ดับเบิลคลิก start_portal.bat ได้เลย")
    for pid in pids:
        info = proc_info(pid)
        print(f"\nโปรแกรมที่ใช้พอร์ต {port}: PID {pid}  {info.get('NAME', '')}")
        print(f"  คำสั่ง      : {info.get('CMD', '(อ่านไม่ได้ — ลองรันแบบ Run as administrator)')}")
        if info.get("PNAME"):
            print(f"  เปิดโดย     : PID {info.get('PPID')}  {info.get('PNAME')}  {info.get('PCMD', '')}")
        if "portal.py" in info.get("CMD", ""):
            print("  → นี่คือระบบรวม (portal.py) ที่เปิดอยู่แล้ว ไม่ต้องหยุด")
            continue
        if not ask("หยุดโปรแกรมนี้?"):
            print("  ข้าม")
            continue
        # ถ้าโปรแกรมแม่เป็นหน้าต่าง cmd ที่รัน start.bat / Re-start.bat (วนเปิดใหม่) → หยุดทั้งชุด
        parent_is_launcher = KEYWORDS.search(info.get("PCMD", "")) and info.get("PNAME", "").lower() in ("cmd.exe", "powershell.exe", "wscript.exe", "cscript.exe")
        target = int(info["PPID"]) if parent_is_launcher and info.get("PPID", "").isdigit() else pid
        out = run(["taskkill", "/PID", str(target), "/T", "/F"])
        print("  " + (out.strip() or "สั่งหยุดแล้ว"))

    if pids:
        print("\nรอ 10 วินาที ตรวจว่ามีอะไรเปิดกลับขึ้นมาเองไหม…")
        time.sleep(10)
        again = [p for p in listening_pids(port) if "portal.py" not in proc_info(p).get("CMD", "")]
        if again:
            print(f"! พอร์ต {port} ถูกใช้อีกครั้ง (PID {', '.join(map(str, again))}) — มีตัวเปิดซ้ำอัตโนมัติ ดูรายการด้านล่าง")
        else:
            print(f"✓ พอร์ต {port} ว่างแล้ว")

    print("\nตรวจการตั้งให้ UT-CMMS เปิดเองตอนเปิดเครื่อง…")
    tasks, startup = autostart_items()
    if not tasks and not startup:
        print("✓ ไม่พบ (UT-CMMS ไม่ได้ตั้งให้เปิดเอง หรือตั้งไว้ด้วยวิธีอื่น)")
    for t in tasks:
        name, state = t.split("|", 1)
        print(f"- Task Scheduler: {name}  (สถานะ {state})")
        if state.lower() != "disabled" and ask("  ปิด (Disable) งานนี้? — เปิดกลับได้ภายหลัง"):
            print("  " + (run(["schtasks", "/Change", "/TN", name, "/DISABLE"]).strip() or "ปิดแล้ว"))
    for path in startup:
        print(f"- โฟลเดอร์ Startup: {path}")
        if ask("  ย้ายออกจาก Startup (เก็บไว้ในโฟลเดอร์ backup ของ E-Checksheet)?"):
            dest_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backup", "startup-disabled")
            os.makedirs(dest_dir, exist_ok=True)
            try:
                os.replace(path, os.path.join(dest_dir, os.path.basename(path)))
                print(f"  ย้ายไปที่ {dest_dir} แล้ว")
            except OSError as exc:
                print(f"  ย้ายไม่ได้: {exc} (ลองรันแบบ Run as administrator)")

    print("\nขั้นต่อไป: ดับเบิลคลิก start_portal.bat · ตั้งให้เปิดเองตอนเปิดเครื่อง: install_autostart.bat (Run as administrator)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
