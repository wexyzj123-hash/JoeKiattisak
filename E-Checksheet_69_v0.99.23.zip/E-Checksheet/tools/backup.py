#!/usr/bin/env python3
"""tools/backup.py — แบ็กอัปฐานข้อมูล + รูป (ทำได้ขณะระบบเปิดอยู่)

    python tools\\backup.py E:\\Backup\\E-Checksheet          เก็บ 30 ชุดล่าสุด
    python tools\\backup.py E:\\Backup\\E-Checksheet --keep 60
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

for _stream in (sys.stdout, sys.stderr):      # Windows service / cmd ที่ไม่รองรับภาษาไทย → ไม่ล้ม
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
from ecs.settings import load_config  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("dest")
    ap.add_argument("--keep", type=int, default=30)
    args = ap.parse_args()
    from ecs.backup import run_backup
    cfg = load_config()
    res = run_backup(cfg["DATABASE"], cfg["UPLOAD_FOLDER"], args.dest, args.keep)
    print(f"แบ็กอัป {res['file']} ({res['size'] // 1024} KB, ตรวจไฟล์ {'ผ่าน' if res['ok'] else 'ไม่ผ่าน'}) · รูปใหม่ {res['photos']} ไฟล์")
    return 0 if res["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
