"""tools/seed_demo.py — ข้อมูลตัวอย่าง 3 โรงงาน (ใช้ทดลอง/สาธิต ไม่ใช่ข้อมูลจริง)

python run.py --demo           ใส่ข้อมูลเมื่อยังไม่มีเครื่องจักรในระบบ
python run.py --demo --force   ใส่เพิ่มแม้มีข้อมูลแล้ว (ไม่แนะนำกับระบบจริง)

ผู้ใช้ตัวอย่างทุกคนรหัสผ่าน Demo#1234
"""
from __future__ import annotations

import io
import os
import random
import struct
import uuid
import zlib
from datetime import datetime, time, timedelta

from werkzeug.datastructures import FileStorage

from ecs import masterdata as M
from ecs import services as S
from ecs import submissions as SUB
from ecs.db import connect

DEMO_PASSWORD = "Demo#1234"

AREAS = {
    "F1": ["Compressor Room", "Boiler House", "Wastewater Treatment"],
    "F2": ["Compressor Room", "Chiller Plant"],
    "F3": ["Compressor Room", "Cooling Tower Yard", "Fire Pump Room"],
}
EQUIPMENT = [
    # code, name, type, factory, area
    ("SCT0002", "Air Compressor SCT0002 (75 kW)", "Air Compressor", "F1", "Compressor Room"),
    ("SCT0003", "Air Compressor SCT0003 (75 kW)", "Air Compressor", "F1", "Compressor Room"),
    ("SCT0010", "Air Dryer SCT0010", "Air Dryer", "F1", "Compressor Room"),
    ("STT0005", "Boiler STT0005 (2 t/h)", "Boiler", "F1", "Boiler House"),
    ("WT-F1", "Wastewater Treatment F1", "Wastewater Treatment", "F1", "Wastewater Treatment"),
    ("SCT0019", "Air Compressor SCT0019 (55 kW)", "Air Compressor", "F2", "Compressor Room"),
    ("SCT0020", "Air Compressor SCT0020 (55 kW)", "Air Compressor", "F2", "Compressor Room"),
    ("CH-201", "Chiller CH-201 (300 RT)", "Chiller", "F2", "Chiller Plant"),
    ("SCT0028", "Air Compressor SCT0028 (90 kW)", "Air Compressor", "F3", "Compressor Room"),
    ("SLT0001", "Cooling Tower SLT0001", "Cooling Tower", "F3", "Cooling Tower Yard"),
    ("FP-301", "Fire Pump FP-301 (Diesel)", "Fire Pump", "F3", "Fire Pump Room"),
]
TEMPLATES = {
    "Air Compressor": [
        ("ค่าที่วัด", "Oil Pressure", "number", "kgf/cm2", 1.7, 2.5, 1.8, 2.4, 2.1, 0.12),
        ("ค่าที่วัด", "Discharge Pressure", "number", "bar", 6.0, 7.5, 6.2, 7.3, 6.8, 0.2),
        ("ค่าที่วัด", "Discharge Temp", "number", "°C", 0, 95, None, 90, 82, 3.5),
        ("ค่าที่วัด", "Motor Current", "number", "A", 0, 140, None, 130, 118, 6),
        ("ค่าที่วัด", "Total Running Hour", "counter", "hr", None, None, None, None, None, None),
        ("ตรวจสภาพ", "เสียง/การสั่นสะเทือนผิดปกติ", "ok_ng"),
        ("ตรวจสภาพ", "รอยรั่วน้ำมัน/ลม", "ok_ng"),
        ("ตรวจสภาพ", "ระบายน้ำ Auto Drain ทำงาน", "ok_ng"),
        ("ตรวจสภาพ", "ไส้กรองอากาศ", "choice", [("สะอาด", 0), ("เริ่มสกปรก", 0), ("ต้องเปลี่ยน", 1)]),
    ],
    "Air Dryer": [
        ("ค่าที่วัด", "Dew Point", "number", "°C", None, 10, None, 7, 4, 1.2),
        ("ค่าที่วัด", "Inlet Pressure", "number", "bar", 6.0, 7.5, None, None, 6.8, 0.2),
        ("ตรวจสภาพ", "Drain ทำงานปกติ", "ok_ng"),
        ("ตรวจสภาพ", "พัดลมคอนเดนเซอร์", "ok_ng"),
    ],
    "Boiler": [
        ("ค่าที่วัด", "Steam Pressure", "number", "bar", 6.0, 9.0, 6.5, 8.5, 7.6, 0.3),
        ("ค่าที่วัด", "Feed Water Temp", "number", "°C", 60, 100, 70, None, 82, 4),
        ("ค่าที่วัด", "มิเตอร์ Gas", "counter", "m3", None, None, None, None, None, None),
        ("ตรวจสภาพ", "ระดับน้ำในหลอดแก้ว", "ok_ng"),
        ("ตรวจสภาพ", "Blow down", "ok_ng"),
        ("ตรวจสภาพ", "Safety valve ไม่รั่ว", "ok_ng"),
    ],
    "Wastewater Treatment": [
        ("คุณภาพน้ำ", "pH น้ำทิ้ง", "number", "", 5.5, 9.0, 6.0, 8.5, 7.3, 0.35),
        ("คุณภาพน้ำ", "DO บ่อเติมอากาศ", "number", "mg/L", 2.0, None, 2.5, None, 3.4, 0.4),
        ("คุณภาพน้ำ", "สีน้ำทิ้ง", "choice", [("ใส", 0), ("ขุ่นเล็กน้อย", 0), ("ขุ่น/มีสี", 1)]),
        ("อุปกรณ์", "Blower ทำงานปกติ", "ok_ng"),
        ("อุปกรณ์", "มิเตอร์น้ำทิ้ง", "counter", "m3", None, None, None, None, None, None),
    ],
    "Chiller": [
        ("ค่าที่วัด", "Chilled Water Supply Temp", "number", "°C", 5, 9, 5.5, 8, 7, 0.4),
        ("ค่าที่วัด", "Chilled Water Return Temp", "number", "°C", 10, 15, None, 14, 12.2, 0.5),
        ("ค่าที่วัด", "Compressor Current", "number", "A", 0, 420, None, 400, 350, 15),
        ("ตรวจสภาพ", "เสียงผิดปกติ", "ok_ng"),
        ("ตรวจสภาพ", "Alarm บนหน้าจอ", "ok_ng"),
    ],
    "Cooling Tower": [
        ("ค่าที่วัด", "Water Inlet Temp", "number", "°C", 0, 40, None, 37, 33, 1.5),
        ("ค่าที่วัด", "Water Outlet Temp", "number", "°C", 0, 35, None, 32, 29, 1.3),
        ("ตรวจสภาพ", "พัดลม/สายพาน", "ok_ng"),
        ("ตรวจสภาพ", "ระดับน้ำในอ่าง", "ok_ng"),
    ],
    "Fire Pump": [
        ("ทดสอบเดินเครื่อง", "Discharge Pressure", "number", "bar", 7, 10, None, None, 8.5, 0.3),
        ("ทดสอบเดินเครื่อง", "ระดับน้ำมันดีเซล", "choice", [("เต็ม", 0), ("มากกว่าครึ่ง", 0), ("น้อยกว่าครึ่ง", 1)]),
        ("ทดสอบเดินเครื่อง", "แบตเตอรี่สตาร์ท", "ok_ng"),
        ("ทดสอบเดินเครื่อง", "Jockey pump ทำงาน", "ok_ng"),
    ],
}


def _png(color=(200, 60, 60), w=96, h=72) -> bytes:
    """สร้างรูป PNG สีพื้นแบบง่าย (ไม่ต้องใช้ Pillow) — ใช้แทนรูปถ่ายในข้อมูลตัวอย่าง"""
    raw = b"".join(b"\x00" + bytes(color) * w for _ in range(h))
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


def _items_for(eq_type):
    out = []
    for t in TEMPLATES[eq_type]:
        sec, name, typ = t[0], t[1], t[2]
        it = {"section": sec, "name": name, "item_type": typ, "photo_on_ng": 1}
        if typ in ("number", "counter"):
            it.update(unit=t[3], min_value=t[4], max_value=t[5], warn_low=t[6], warn_high=t[7])
            if typ == "counter":
                it["counter_max_step"] = 24 if t[3] == "hr" else None
        if typ == "choice":
            it["options"] = [{"label": l, "ng": n} for l, n in t[3]]
        if name.startswith("Oil Pressure"):
            it["guide"] = "อ่านค่าจากเกจหน้าเครื่องขณะเดิน Load"
        out.append(it)
    return out


ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "demo_assets")
# ตำแหน่งหมุดพื้นที่บนผังตัวอย่าง (% ของกว้าง/สูง) — ตรงกับ demo_assets/make_layouts.py
PINS = {"F1": {"Compressor Room": (43.8, 21.0), "Boiler House": (61.2, 21.0), "Wastewater Treatment": (89.6, 66.2)},
        "F2": {"Chiller Plant": (86.2, 49.3), "Compressor Room": (53.3, 19.9)},
        "F3": {"Compressor Room": (35.0, 20.6), "Cooling Tower Yard": (90.0, 49.3), "Fire Pump Room": (90.0, 77.2)}}
FIX_NOTES = [("คอยล์ร้อนสกปรก ระบายความร้อนไม่ดี", "ทำความสะอาดและปรับตั้งแล้ว ค่ากลับมาปกติ"),
             ("อะไหล่เสื่อมตามอายุการใช้งาน", "เปลี่ยนอะไหล่แล้ว ทดสอบเดินเครื่องปกติ"),
             ("ช่างอ่านค่าผิดจากหน้าปัด", "ตรวจซ้ำแล้วค่าปกติ อบรมวิธีอ่านค่าให้ช่าง"),
             ("จุดตั้งค่า (set point) ไม่เหมาะกับโหลด", "ปรับจุดตั้งค่าแล้ว เฝ้าติดตามต่อ")]


def _close_old_alerts(db, sups: dict, now: datetime) -> None:
    """หัวหน้าปิดแจ้งเตือนที่เก่ากว่า 3 วันไปแล้วเกือบทั้งหมด (ให้เห็นภาพการใช้งานจริง)"""
    from ecs import anomaly as A
    rows = db.execute("""SELECT a.id, fa.code FROM cs_alerts a JOIN cs_forms f ON f.id=a.form_id
                          JOIN factories fa ON fa.id=f.factory_id WHERE a.status='open' AND a.updated_at < ?""",
                      (S.ts(now - timedelta(days=3)),)).fetchall()
    for r in rows:
        if random.random() < 0.85:
            cause, fix = random.choice(FIX_NOTES)
            A.set_alert_status(db, r["id"], "resolve", sups[r["code"]], now=now, root_cause=cause, action_taken=fix)
            if random.random() < 0.7:
                A.set_alert_status(db, r["id"], "close", sups[r["code"]], "ตรวจสอบแล้ว ค่ากลับมาปกติ", now=now)
    for r in db.execute("SELECT id, form_id, created_at FROM cs_alerts WHERE status='open' ORDER BY id").fetchall()[::4]:
        code = db.execute("SELECT fa.code FROM cs_forms f JOIN factories fa ON fa.id=f.factory_id WHERE f.id=?",
                          (r["form_id"],)).fetchone()[0]
        A.set_alert_status(db, r["id"], "ack", sups[code], now=min(now, S.parse_ts(r["created_at"]) + timedelta(minutes=20)))


def _phase4(db, fac: dict, uid: dict, sups: dict, now: datetime, upload_dir: str) -> None:
    """ตัวอย่าง Phase 4: ช่วงเงียบ, งานแก้ไข (CAPA) หลายสถานะ, กระดิ่งแจ้งเตือน"""
    from ecs import capa as C
    from ecs import notify as N
    # ช่วงเงียบ: PM ปั๊มดับเพลิง F3 (กำลังเงียบอยู่)
    fp = db.execute("SELECT id FROM equipment WHERE code='FP-301'").fetchone()
    if fp:
        N.save_silence(db, {"equipment_id": fp["id"], "starts_at": S.ts(now - timedelta(hours=2)),
                            "ends_at": S.ts(now + timedelta(hours=20)), "reason": "PM ปั๊มดับเพลิงประจำปี (ผู้รับเหมา)"},
                       sups["F3"])
    # งานแก้ไขจากแจ้งเตือนที่ยังค้าง
    open_alerts = db.execute("""SELECT a.id, fa.code, a.created_at, a.ack_at FROM cs_alerts a JOIN cs_forms f ON f.id=a.form_id
                                JOIN factories fa ON fa.id=f.factory_id
                                WHERE a.status IN ('open','acknowledged') AND a.alert_type IN ('ng','spc_sigma','roc','spc_trend')
                                ORDER BY a.severity='warning' DESC, a.id DESC LIMIT 5""").fetchall()
    techs = {"F1": uid["tech1"], "F2": uid["tech3"], "F3": uid["tech4"]}
    plan = ["done", "in_progress_overdue", "open", "closed", "in_progress"]
    for r, st in zip(open_alerts, plan):
        sup, tech = sups[r["code"]], techs[r["code"]]
        base = S.parse_ts(r["ack_at"] or r["created_at"]) + timedelta(minutes=30)
        created = min(base, now - timedelta(hours=6))
        aid = C.create_from_alert(db, r["id"], sup, now=created)
        C.update_action(db, aid, {"owner_id": tech}, sup, now=created)
        if st == "in_progress_overdue":
            db.execute("UPDATE cs_actions SET due_date=? WHERE id=?", ((now.date() - timedelta(days=2)).isoformat(), aid))
        if st != "open":
            C.transition(db, aid, "start", tech, now=created + timedelta(hours=1))
            C.add_comment(db, aid, tech, "ตรวจหน้างานแล้ว สั่งอะไหล่ รอของเข้า", now=created + timedelta(hours=2))
        if st in ("done", "closed"):
            C.add_photo(db, aid, "after", FileStorage(io.BytesIO(_png((40, 150, 80))), filename="after.png"), upload_dir,
                        8 * 1024 * 1024, tech, now=created + timedelta(hours=4))
            cause, fix = random.choice(FIX_NOTES)
            C.transition(db, aid, "done", tech, root_cause=cause, action_taken=fix, now=created + timedelta(hours=4, minutes=5))
        if st == "closed":
            C.transition(db, aid, "verify", sup, note="ตรวจหน้างานแล้ว ใช้งานได้ปกติ", now=created + timedelta(hours=5))
    # งานป้องกันที่สร้างเอง
    comp = db.execute("SELECT id FROM equipment WHERE code='SCT0002'").fetchone()
    if comp:
        C.create_action(db, {"title": "เพิ่มรอบล้างคอยล์ร้อน Air Compressor SCT0002 เป็นทุก 2 สัปดาห์", "action_type": "preventive",
                             "description": "Discharge Temp มีแนวโน้มสูงขึ้นต่อเนื่องในช่วงหน้าร้อน", "priority": "normal",
                             "owner_id": uid["sup1"], "due_date": (now.date() + timedelta(days=10)).isoformat(),
                             "equipment_id": comp["id"]}, sups["F1"], now=now - timedelta(days=1))
    # ส่งแจ้งเตือนตามระดับ (เข้ากระดิ่งของหัวหน้า/ผู้ดูแล) แล้วอ่านไปบางส่วน
    N.escalate(db, now)
    for u in db.execute("SELECT DISTINCT user_id FROM cs_notifications"):
        ids = [r[0] for r in db.execute("SELECT id FROM cs_notifications WHERE user_id=? ORDER BY id", (u[0],))][:-5]
        if ids:
            N.mark_read(db, u[0], ids)


def _phase5(db, admin: int, now: datetime, db_path: str) -> None:
    """ตัวอย่าง Phase 5: ฐานข้อมูล SCADA จำลอง (SQLite) + แหล่งข้อมูลที่จับคู่ Tag กับ Chiller CH-201 แล้ว"""
    import math
    import sqlite3
    from ecs import connectors as CN
    path = os.path.join(os.path.dirname(os.path.abspath(db_path)), "demo_scada.db")
    if os.path.exists(path):
        os.remove(path)
    scada = sqlite3.connect(path)
    scada.execute("CREATE TABLE History (TagName TEXT, DateTime TEXT, Value REAL)")
    rnd = random.Random(11)
    start = (now - timedelta(days=2)).replace(minute=0, second=0, microsecond=0)
    rows, t = [], start
    while t <= now:
        h = t.hour + t.minute / 60
        load = 0.5 + 0.35 * math.sin((h - 9) / 24 * 2 * math.pi)            # โหลดตามช่วงเวลาของวัน
        chws = 6.7 + rnd.gauss(0, 0.12) + (2.4 if (now - t) < timedelta(hours=5) and t.hour % 24 in (now.hour - 2, now.hour - 3) else 0)
        rows += [("CH201.CHWS_TEMP", t.strftime("%Y-%m-%d %H:%M:%S"), round(chws, 2)),
                 ("CH201.CHWR_TEMP", t.strftime("%Y-%m-%d %H:%M:%S"), round(12.0 + 0.8 * load + rnd.gauss(0, 0.15), 2)),
                 ("CH201.COMP_AMP", t.strftime("%Y-%m-%d %H:%M:%S"), round(260 + 110 * load + rnd.gauss(0, 6), 1)),
                 ("CH201.KW", t.strftime("%Y-%m-%d %H:%M:%S"), round(150 + 70 * load + rnd.gauss(0, 4), 1))]
        t += timedelta(minutes=5)
    scada.executemany("INSERT INTO History VALUES (?,?,?)", rows)
    scada.commit()
    scada.close()
    sid = CN.save_source(db, {"name": "SCADA Historian (ตัวอย่าง) — Chiller CH-201", "kind": "sqlite", "interval_min": 15,
                              "bucket_min": 60, "agg": "avg", "active": "1",
                              "config": {"path": path, "backfill_days": 2,
                                         "query": "SELECT TagName AS tag, DateTime AS ts, Value AS value FROM History WHERE DateTime > ? ORDER BY DateTime"}},
                         admin, now=now)
    ch = db.execute("SELECT id FROM cs_forms WHERE name LIKE '%CH-201%'").fetchone()
    if ch:
        form = S.get_form(db, ch["id"])
        keys = {i["name"]: i["item_key"] for i in S.get_items(db, form["current_version_id"])}
        mapping = [("CH201.CHWS_TEMP", "Chilled Water Supply Temp"), ("CH201.CHWR_TEMP", "Chilled Water Return Temp"),
                   ("CH201.COMP_AMP", "Compressor Current")]
        CN.save_mapping(db, sid, [{"tag": tg, "target": f"{ch['id']}:{keys[n]}"} for tg, n in mapping if n in keys], admin)
    CN.run_source(db, sid, now=now)


def _layouts(db, fac: dict, admin: int, upload_dir: str) -> None:
    for code, pins in PINS.items():
        path = os.path.join(ASSETS, f"layout_{code}.png")
        if code not in fac or not os.path.exists(path):
            continue
        with open(path, "rb") as fh:
            M.set_factory_layout(db, fac[code], fh.read(), upload_dir, admin)
        for name, (x, y) in pins.items():
            M.set_area_pin(db, M.get_or_create_area(db, fac[code], name), x, y, admin)


def seed(app, force: bool = False, days: int = 14, rnd_seed: int = 7) -> str:
    random.seed(rnd_seed)
    db = connect(app.config["DATABASE"])
    try:
        if db.execute("SELECT COUNT(*) FROM equipment").fetchone()[0] and not force:
            return "มีเครื่องจักรในระบบแล้ว — ไม่ใส่ข้อมูลตัวอย่าง (ใช้ --force ถ้าต้องการ)"
        fac = {r["code"]: r["id"] for r in db.execute("SELECT id, code FROM factories")}
        # ผู้ใช้
        users = [("admin", "ผู้ดูแลระบบ (ตัวอย่าง)", "admin", None),
                 ("sup1", "สมชาย หัวหน้า F1", "supervisor", "F1"), ("sup2", "วิภา หัวหน้า F2", "supervisor", "F2"),
                 ("sup3", "ธนา หัวหน้า F3", "supervisor", "F3"),
                 ("tech1", "ประเสริฐ ช่าง F1", "technician", "F1"), ("tech2", "อนุชา ช่าง F1", "technician", "F1"),
                 ("tech3", "กิตติ ช่าง F2", "technician", "F2"), ("tech4", "สุนทร ช่าง F3", "technician", "F3"),
                 ("viewer", "ผู้บริหาร (ดูอย่างเดียว)", "viewer", None)]
        uid = {}
        for username, name, role, f in users:
            row = db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
            uid[username] = row["id"] if row else M.save_user(db, {
                "username": username, "name": name, "role": role, "factory_id": fac.get(f) if f else None,
                "password": DEMO_PASSWORD, "must_change_pw": 0, "active": 1}, None)
        admin = uid["admin"]
        # พื้นที่ + เครื่อง
        for f, names in AREAS.items():
            for n in names:
                M.get_or_create_area(db, fac[f], n)
        eq_ids = {}
        for code, name, typ, f, area in EQUIPMENT:
            row = db.execute("SELECT id FROM equipment WHERE code=?", (code,)).fetchone()
            eq_ids[code] = row["id"] if row else M.save_equipment(db, {
                "code": code, "name": name, "eq_type": typ, "factory_id": fac[f],
                "area_id": M.get_or_create_area(db, fac[f], area)}, admin)
        # แบบฟอร์ม + รอบตรวจ
        forms = []
        for code, name, typ, f, area in EQUIPMENT:
            fid = S.create_form(db, {"name": f"Daily Checksheet {name}" if typ != "Fire Pump" else f"Weekly Fire Pump Test {code}",
                                     "equipment_id": eq_ids[code]}, admin)
            draft = S.get_draft(db, fid)
            S.save_draft_items(db, draft["id"], _items_for(typ), admin)
            S.publish_version(db, draft["id"], admin, "แบบฟอร์มตัวอย่าง")
            if typ == "Fire Pump":
                S.create_schedule(db, fid, {"freq_type": "weekly", "times": "09:00", "weekdays": "0", "window_min": 480}, admin)
            elif typ == "Air Compressor":
                S.create_schedule(db, fid, {"freq_type": "shift", "times": "08:00,20:00", "window_min": 180}, admin)
            else:
                S.create_schedule(db, fid, {"freq_type": "daily", "times": "08:00", "window_min": 240}, admin)
            forms.append((fid, typ, f))
        db.commit()

        # ประวัติย้อนหลัง
        now = S.now_dt()
        start = datetime.combine((now - timedelta(days=days)).date(), time(0, 0))
        db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('rounds_start', ?)", (S.ts(start),))
        for d in range(days, -1, -1):
            S.generate_rounds(db, now=datetime.combine((now - timedelta(days=d)).date(), time(0, 1)), horizon_days=1)
        S.generate_rounds(db, now=now)
        techs = {"F1": [uid["tech1"], uid["tech2"]], "F2": [uid["tech3"]], "F3": [uid["tech4"]]}
        sups = {"F1": uid["sup1"], "F2": uid["sup2"], "F3": uid["sup3"]}
        counters: dict[tuple, float] = {}
        rounds = db.execute("""SELECT r.*, f.factory_id FROM cs_rounds r JOIN cs_forms f ON f.id=r.form_id
                               WHERE r.due_at < ? ORDER BY r.due_at""", (S.ts(now),)).fetchall()
        fac_code = {v: k for k, v in fac.items()}
        made = 0
        for r in rounds:
            if random.random() < 0.06:
                continue    # ขาดตรวจบ้าง
            fcode = fac_code[r["factory_id"]]
            form_typ = next(t for fid, t, _ in forms if fid == r["form_id"])
            due = S.parse_ts(r["due_at"])
            late = random.random() < 0.08
            start_at = due + timedelta(minutes=random.randint(5, 150 if not late else 300))
            if not late:
                start_at = min(start_at, S.parse_ts(r["deadline_at"]) - timedelta(minutes=8))
            finish = start_at + timedelta(seconds=random.randint(70, 260))
            if finish >= now - timedelta(minutes=2):
                continue    # รอบวันนี้ที่ยังไม่ถึงเวลาตรวจเสร็จ (ยังรอตรวจ)
            version = S.get_form(db, r["form_id"])["current_version_id"]
            answers, photos = [], {}
            for it in S.get_items(db, version):
                key, val, remark, pids = it["item_key"], "", "", []
                spec = next(t for t in TEMPLATES[form_typ] if t[1] == it["name"])
                if it["item_type"] == "ok_ng":
                    val = "NG" if random.random() < 0.025 else "OK"
                elif it["item_type"] == "choice":
                    opts = spec[3]
                    val = random.choices([o[0] for o in opts], weights=[80, 17, 3][:len(opts)])[0]
                elif it["item_type"] == "counter":
                    base = counters.get((r["form_id"], key), random.randint(12000, 30000))
                    step = (random.uniform(9, 12) if "hr" in (it["unit"] or "") else random.uniform(120, 260))
                    base = round(base + step, 1)
                    counters[(r["form_id"], key)] = base
                    val = str(base)
                else:
                    mean, sd = spec[8], spec[9]
                    drift = 0.0
                    if it["name"] == "Discharge Temp" and r["form_id"] == forms[0][0]:
                        # SCT0002: อุณหภูมิค่อยๆ สูงขึ้นช่วง 6 วันหลัง (ตัวอย่างสำหรับกราฟแนวโน้ม/SPC)
                        drift = max(0.0, 6 - (now - due).total_seconds() / 86400) * 1.7
                    v = random.gauss(mean + drift, sd)
                    if random.random() < 0.02:
                        v = mean + sd * random.choice([-5, 5])
                    val = f"{v:.2f}".rstrip("0").rstrip(".")
                j = S.evaluate(it, val)["judgement"]
                if j == "ng":
                    remark = random.choice(["แจ้งช่างซ่อมบำรุงแล้ว", "ปรับตั้งแล้ว รอติดตาม", "เปลี่ยนชิ้นส่วนชั่วคราว"])
                    pid = "p" + uuid.uuid4().hex[:10]
                    photos[pid] = FileStorage(io.BytesIO(_png()), filename=f"{pid}.png")
                    pids = [pid]
                answers.append({"item_key": key, "value": val, "remark": remark, "photos": pids})
            payload = {"client_uuid": str(uuid.uuid4()), "form_id": r["form_id"], "form_version_id": version,
                       "round_id": r["id"], "scanned_at": S.ts(start_at), "finished_at": S.ts(finish),
                       "answers": answers, "client_info": "demo seed"}
            try:
                res = SUB.create_submission(db, payload, photos, random.choice(techs[fcode]),
                                            app.config["UPLOAD_FOLDER"], now=finish + timedelta(seconds=5))
            except S.ValidationError:
                continue
            made += 1
            if (now - finish).days >= 1 and random.random() < 0.9:
                if res["ng_count"] and random.random() < 0.15:
                    SUB.return_submission(db, res["id"], sups[fcode], "ค่าที่บันทึกไม่ตรงกับหน้าปัด กรุณาตรวจซ้ำ")
                else:
                    SUB.approve(db, res["id"], sups[fcode], "")
        S.refresh_round_statuses(db, now=now)
        from ecs.anomaly import check_missed
        check_missed(db, now=now)
        _close_old_alerts(db, sups, now)
        _layouts(db, fac, admin, app.config["UPLOAD_FOLDER"])
        _phase4(db, fac, uid, sups, now, app.config["UPLOAD_FOLDER"])
        _phase5(db, admin, now, app.config["DATABASE"])
        db.commit()
        return (f"ใส่ข้อมูลตัวอย่างแล้ว: เครื่องจักร {len(EQUIPMENT)}, แบบฟอร์ม {len(forms)}, ผลตรวจย้อนหลัง {made} ครั้ง\n"
                f"ผู้ใช้: admin / sup1-3 / tech1-4 / viewer  รหัสผ่าน {DEMO_PASSWORD}")
    finally:
        db.close()
