#!/usr/bin/env python3
"""tools/import_legacy.py — นำเข้าข้อมูลจาก UT-CMMS เดิม (ทางเลือก ทำครั้งเดียว)

อ่านฐานข้อมูลเดิมแบบ "อ่านอย่างเดียว" ไม่แก้ไขอะไรในระบบเดิม
E-Checksheet ใช้งานได้ครบโดยไม่ต้องนำเข้า — ใช้เมื่ออยากได้เครื่องจักร/แบบฟอร์มเดิมมาเป็นจุดเริ่มต้น

    python tools/import_legacy.py --source D:\\UT-CMMS\\utility_cmms.db --dry-run
    python tools/import_legacy.py --source D:\\UT-CMMS\\utility_cmms.db
    python tools/import_legacy.py --source ... --users      # นำเข้าผู้ใช้ (admin/supervisor/technician) พร้อมรหัสผ่านเดิม
    python tools/import_legacy.py --source ... --history    # นำเข้าผลตรวจเก่าที่ส่งแล้วด้วย

รันซ้ำได้: รายการที่นำเข้าแล้วจะข้าม (อ้างอิง legacy_id)
"""
from __future__ import annotations

import argparse
import os
import re
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

for _stream in (sys.stdout, sys.stderr):      # Windows service / cmd ที่ไม่รองรับภาษาไทย → ไม่ล้ม
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

from ecs import masterdata as M  # noqa: E402
from ecs import services as S  # noqa: E402
from ecs.db import connect  # noqa: E402
from ecs.schema import ensure_schema  # noqa: E402
from ecs.settings import load_config  # noqa: E402

ROLE_MAP = {"admin": "admin", "supervisor": "supervisor", "technician": "technician"}

# หัวข้อที่เป็นมิเตอร์สะสม: หน่วยเป็นค่าสะสม + ไม่มี Min/Max
_COUNTER_UNITS = {"hr", "hrs", "hour", "kwh", "m3", "m³"}
_COUNTER_WORDS = re.compile(r"(hour|running|runing|accumulat|การใช้|consumption|meter)", re.I)

_NAME_FIXES = [
    (re.compile(r"\bDialy\b", re.I), "Daily"),
    (re.compile(r"\bChechsheet\b", re.I), "Checksheet"),
    (re.compile(r"\bDectector\b", re.I), "Detector"),
    (re.compile(r"\s{2,}"), " "),
]


def clean_name(name: str) -> str:
    out = (name or "").strip()
    for pat, rep in _NAME_FIXES:
        out = pat.sub(rep, out)
    return out


def guess_item_type(item: dict) -> str:
    if item["item_type"] == "ox":
        return "ok_ng"
    unit = (item.get("unit") or "").strip().lower()
    if (item.get("min_value") is None and item.get("max_value") is None
            and unit in _COUNTER_UNITS and _COUNTER_WORDS.search(item.get("name") or "")):
        return "counter"
    return "number"


def guess_schedule(name: str) -> dict | None:
    low = (name or "").lower()
    if "daily" in low or "dialy" in low or "ประจำวัน" in low:
        return {"freq_type": "daily", "times": "08:00", "window_min": 240}
    if "weekly" in low or "ประจำสัปดาห์" in low:
        return {"freq_type": "weekly", "times": "08:00", "weekdays": "0", "window_min": 480}
    if "monthly" in low or "ประจำเดือน" in low:
        return {"freq_type": "monthly", "times": "08:00", "month_day": 1, "window_min": 480}
    return None


def _factory_from_name(name: str) -> str:
    m = re.search(r"fac(?:tory)?\s*(\d)", name or "", re.I)
    return f"Factory {m.group(1)}" if m else ""



def _factory_id(db, name: str, cache: dict) -> int | None:
    name = (name or "").strip()
    if not name:
        return None
    if name in cache:
        return cache[name]
    row = db.execute("SELECT id FROM factories WHERE name=? OR code=?", (name, name)).fetchone()
    if row:
        cache[name] = row["id"]
        return row["id"]
    m = re.search(r"(\d+)", name)
    code = f"F{m.group(1)}" if m else re.sub(r"[^A-Za-z0-9]", "", name)[:10].upper() or "FX"
    while db.execute("SELECT 1 FROM factories WHERE code=?", (code,)).fetchone():
        code += "X"
    fid = M.save_factory(db, {"code": code, "name": name}, None)
    cache[name] = fid
    return fid


def run(source: str, target: str, users: bool, history: bool) -> dict:
    src = sqlite3.connect(f"file:{source}?mode=ro", uri=True)
    src.row_factory = sqlite3.Row
    db = connect(target)
    ensure_schema(db)
    rep = {"factories": 0, "equipment": 0, "equipment_skipped": 0, "users": 0, "users_skipped": 0,
           "forms": 0, "forms_skipped": 0, "items": 0, "counters": [], "schedules": 0, "no_schedule": [],
           "submissions": 0, "abandoned_logs": 0, "unbounded_numbers": 0}
    try:
        tables = {r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        fac_cache: dict = {}
        before_f = db.execute("SELECT COUNT(*) FROM factories").fetchone()[0]
        # ── เครื่องจักร ──
        eq_map: dict[int, int] = {}
        for e in src.execute("SELECT * FROM equipment ORDER BY id"):
            e = dict(e)
            row = db.execute("SELECT id FROM equipment WHERE legacy_id=?", (e["id"],)).fetchone()
            if row:
                eq_map[e["id"]] = row["id"]
                rep["equipment_skipped"] += 1
                continue
            code = re.sub(r"[\\?#%<>\"']", "-", (e.get("code") or "").strip())[:40] or f"EQ{e['id']}"
            if db.execute("SELECT 1 FROM equipment WHERE code=?", (code,)).fetchone():
                code = f"{code[:32]}-L{e['id']}"      # รหัสซ้ำในระบบเดิม → ต่อท้ายด้วยเลขเดิม
            try:
                eq_map[e["id"]] = M.save_equipment(db, {
                    "code": code, "name": e.get("name") or code, "eq_type": e.get("type") or "",
                    "factory_id": _factory_id(db, e.get("factory"), fac_cache), "location": e.get("location") or "",
                    "note": e.get("notes") or "", "active": 0 if (e.get("status") or "") in ("retired", "inactive") else 1,
                    "legacy_id": e["id"]}, None)
                rep["equipment"] += 1
            except S.ValidationError:
                rep["equipment_skipped"] += 1
        rep["factories"] = db.execute("SELECT COUNT(*) FROM factories").fetchone()[0] - before_f
        # ── ผู้ใช้ ──
        user_map: dict[int, int] = {}
        if users:
            for u in src.execute("SELECT * FROM users WHERE active=1"):
                u = dict(u)
                if u["role"] not in ROLE_MAP:
                    continue
                row = db.execute("SELECT id FROM users WHERE legacy_id=? OR username=?", (u["id"], u["username"])).fetchone()
                if row:
                    user_map[u["id"]] = row["id"]
                    rep["users_skipped"] += 1
                    continue
                now = S.ts()
                user_map[u["id"]] = db.execute("""INSERT INTO users(username, password, name, role, email, phone, active,
                    must_change_pw, legacy_id, created_at, updated_at) VALUES (?,?,?,?,?,?,1,0,?,?,?)""",
                    (u["username"], u["password"], u.get("name") or u["username"], ROLE_MAP[u["role"]],
                     u.get("email") or "", u.get("phone") or "", u["id"], now, now)).lastrowid
                rep["users"] += 1
        # ── แบบฟอร์ม ──
        item_map: dict[int, dict] = {}
        form_map: dict[int, int] = {}
        if "checksheet_templates" in tables:
            for t in src.execute("SELECT * FROM checksheet_templates ORDER BY id"):
                t = dict(t)
                ex = db.execute("SELECT id, current_version_id FROM cs_forms WHERE legacy_template_id=?", (t["id"],)).fetchone()
                if ex:
                    form_map[t["id"]] = ex["id"]
                    rep["forms_skipped"] += 1
                    if ex["current_version_id"]:
                        for it in S.get_items(db, ex["current_version_id"]):
                            if it.get("legacy_item_id"):
                                item_map[it["legacy_item_id"]] = it
                    continue
                name = clean_name(t["name"])
                data = {"name": name, "description": t.get("description") or "",
                        "equipment_id": eq_map.get(t["equipment_id"]) if t.get("equipment_id") else None}
                if not data["equipment_id"]:
                    data["factory_id"] = _factory_id(db, _factory_from_name(t["name"]), fac_cache)
                code = f"CS-{t['id']:04d}"
                if db.execute("SELECT 1 FROM cs_forms WHERE code=?", (code,)).fetchone():
                    code = None
                fid = S.create_form(db, data, None, code=code, legacy_template_id=t["id"])
                form_map[t["id"]] = fid
                secs = {s["id"]: s["name"] for s in src.execute("SELECT * FROM checksheet_sections WHERE template_id=?", (t["id"],))}
                payload = []
                for li in src.execute("""SELECT i.*, COALESCE(s.order_no, 9999) AS so FROM checksheet_items i
                                         LEFT JOIN checksheet_sections s ON s.id=i.section_id
                                         WHERE i.template_id=? ORDER BY so, i.order_no, i.id""", (t["id"],)):
                    li = dict(li)
                    typ = guess_item_type(li)
                    if typ == "counter":
                        rep["counters"].append(f"{name} › {li['name']}")
                    elif typ == "number" and li["min_value"] is None and li["max_value"] is None:
                        rep["unbounded_numbers"] += 1
                    payload.append({"item_key": f"L{li['id']}", "section": secs.get(li["section_id"], ""),
                                    "name": li["name"], "item_type": typ, "unit": li.get("unit") or "",
                                    "min_value": li.get("min_value"), "max_value": li.get("max_value"),
                                    "required": li.get("required", 1), "photo_on_ng": 1, "legacy_item_id": li["id"]})
                if payload:
                    draft = S.get_draft(db, fid)
                    S.save_draft_items(db, draft["id"], payload, None)
                    S.publish_version(db, draft["id"], None, "นำเข้าจาก UT-CMMS")
                    for it in S.get_items(db, draft["id"]):
                        item_map[it["legacy_item_id"]] = it
                    rep["items"] += len(payload)
                    sched = guess_schedule(t["name"])
                    if sched:
                        S.create_schedule(db, fid, sched, None)
                        rep["schedules"] += 1
                    else:
                        rep["no_schedule"].append(name)
                if not t.get("active", 1):
                    db.execute("UPDATE cs_forms SET active=0 WHERE id=?", (fid,))
                rep["forms"] += 1
        # ── ผลตรวจเก่า ──
        if history and "checksheet_logs" in tables:
            for lg in src.execute("SELECT * FROM checksheet_logs ORDER BY id"):
                lg = dict(lg)
                if not lg.get("finish_at"):
                    rep["abandoned_logs"] += 1
                    continue
                if db.execute("SELECT 1 FROM cs_submissions WHERE legacy_log_id=?", (lg["id"],)).fetchone():
                    continue
                fid = form_map.get(lg["template_id"])
                form = S.get_form(db, fid) if fid else None
                if not form or not form["current_version_id"]:
                    continue
                st, fin = S.parse_ts(lg["start_at"]), S.parse_ts(lg["finish_at"])
                appr = lg.get("approval_status") if lg.get("approval_status") in ("pending", "approved", "rejected") else "pending"
                sid = db.execute("""INSERT INTO cs_submissions(client_uuid, form_id, form_version_id, equipment_id,
                    inspector_id, scanned_at, finished_at, received_at, duration_sec, status, approval_status,
                    approval_note, source, legacy_log_id)
                    VALUES (?,?,?,?,?,?,?,?,?,'submitted',?,?,'legacy',?)""",
                    (f"legacy-{lg['id']}", fid, form["current_version_id"], form["equipment_id"],
                     user_map.get(lg["technician_id"]), S.ts(st) if st else None, S.ts(fin), S.ts(fin),
                     int((fin - st).total_seconds()) if st and fin else None, appr, lg.get("approval_note") or "",
                     lg["id"])).lastrowid
                ng = warn = 0
                for a in src.execute("SELECT * FROM checksheet_log_items WHERE log_id=?", (lg["id"],)):
                    it = item_map.get(a["item_id"])
                    if not it:
                        continue
                    try:
                        res = S.evaluate(it, a["result"])
                    except S.ValidationError:
                        res = {"judgement": "na", "value_num": None, "value_text": str(a["result"] or "")}
                    ng += res["judgement"] == "ng"
                    warn += res["judgement"] == "warn"
                    db.execute("""INSERT INTO cs_answers(submission_id, item_id, item_key, value_num, value_text,
                                  judgement, remark) VALUES (?,?,?,?,?,?,?)""",
                               (sid, it["id"], it["item_key"], res["value_num"], res["value_text"], res["judgement"],
                                a["remark"] or ""))
                db.execute("UPDATE cs_submissions SET ng_count=?, warn_count=? WHERE id=?", (ng, warn, sid))
                rep["submissions"] += 1
        db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('legacy_imported_at', ?)", (S.ts(),))
        return rep, db
    except Exception:
        db.rollback()
        db.close()
        raise
    finally:
        src.close()


def main() -> int:
    ap = argparse.ArgumentParser(description="นำเข้าข้อมูลจาก UT-CMMS เดิม (อ่านอย่างเดียว)")
    ap.add_argument("--source", required=True, help="ไฟล์ utility_cmms.db ของระบบเดิม")
    ap.add_argument("--users", action="store_true", help="นำเข้าผู้ใช้ admin/supervisor/technician พร้อมรหัสผ่านเดิม")
    ap.add_argument("--history", action="store_true", help="นำเข้าผลตรวจเก่าที่ส่งแล้ว")
    ap.add_argument("--dry-run", action="store_true", help="ทดลองรันและแสดงผล แต่ไม่บันทึก")
    args = ap.parse_args()
    if not os.path.exists(args.source):
        print(f"ไม่พบไฟล์ {args.source}")
        return 1
    target = load_config()["DATABASE"]
    if os.path.normcase(os.path.abspath(args.source)) == os.path.normcase(target):
        print("ไฟล์ต้นทางต้องไม่ใช่ฐานข้อมูลของ E-Checksheet")
        return 1
    os.makedirs(os.path.dirname(target), exist_ok=True)
    rep, db = run(args.source, target, args.users, args.history)
    if args.dry_run:
        db.rollback()
        print("[ทดลอง] ไม่ได้บันทึกข้อมูล")
    else:
        db.commit()
    db.close()
    print(f"โรงงานใหม่ {rep['factories']} · เครื่องจักร {rep['equipment']} (ข้าม {rep['equipment_skipped']})")
    print(f"ผู้ใช้ {rep['users']} (ข้าม {rep['users_skipped']}) · แบบฟอร์ม {rep['forms']} (ข้าม {rep['forms_skipped']}) · หัวข้อ {rep['items']}")
    print(f"รอบตรวจที่ตั้งให้ {rep['schedules']} · ผลตรวจเก่า {rep['submissions']} · log ที่ไม่ได้ส่ง (ไม่นำเข้า) {rep['abandoned_logs']}")
    print(f"หัวข้อตัวเลขที่ยังไม่มีเกณฑ์ {rep['unbounded_numbers']} · แปลงเป็นมิเตอร์สะสม {len(rep['counters'])}")
    if rep["no_schedule"]:
        print("แบบฟอร์มที่ต้องตั้งรอบตรวจเอง:")
        for n in rep["no_schedule"]:
            print("   -", n)
    return 0


if __name__ == "__main__":
    sys.exit(main())
