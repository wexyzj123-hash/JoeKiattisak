#!/usr/bin/env python3
"""tools/portal_ctl.py — เปิด/ปิด/ดูสถานะ ระบบรวม UT-CMMS + E-Checksheet แบบทำงานเบื้องหลัง (ไม่มีหน้าต่างดำค้าง)

    python tools/portal_ctl.py start     เปิดเบื้องหลัง (pythonw) บันทึก log ที่ data/portal.log
    python tools/portal_ctl.py stop      ปิด
    python tools/portal_ctl.py restart   ปิดแล้วเปิดใหม่ (หลังแก้ไฟล์ / อัปเดตโปรแกรม)
    python tools/portal_ctl.py status    ดูสถานะ + ที่อยู่สำหรับเปิดใช้งาน (ทุก IP ของเครื่อง)

ใช้ผ่าน start_portal.bat / stop_portal.bat / restart_portal.bat / status_portal.bat
"""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

from ecs.settings import env, env_int  # noqa: E402

DATA = os.path.join(ROOT, "data")
PID_FILE = os.path.join(DATA, "portal.pid")
LOG_FILE = os.path.join(DATA, "portal.log")
IS_WIN = sys.platform.startswith("win")


def port() -> int:
    return env_int("PORTAL_PORT", 5000)


def port_open(p: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", p)) == 0


def read_pid() -> int | None:
    try:
        with open(PID_FILE, encoding="utf-8") as fh:
            return int(fh.read().strip() or 0) or None
    except (OSError, ValueError):
        return None


def pid_alive(pid: int | None) -> bool:
    if not pid:
        return False
    if IS_WIN:
        out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True,
                             errors="replace").stdout
        return str(pid) in out
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def pid_cmdline(pid: int) -> str:
    if IS_WIN:
        r = subprocess.run(["powershell", "-NoProfile", "-Command",
                            f"(Get-CimInstance Win32_Process -Filter 'ProcessId={pid}').CommandLine"],
                           capture_output=True, text=True, errors="replace")
        return r.stdout.strip()
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as fh:
            return fh.read().replace(b"\0", b" ").decode("utf-8", "replace")
    except OSError:
        return ""


def ips() -> list[str]:
    out = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and ip not in out:
                out.append(ip)
    except OSError:
        pass
    return out or ["localhost"]


def urls() -> list[str]:
    prefix = "/" + env("PORTAL_PREFIX", "/echeck").strip("/")
    return [f"http://{ip}:{port()}/   (E-Checksheet: http://{ip}:{port()}{prefix}/)" for ip in ips()]


def pythonw() -> str:
    exe = sys.executable
    if IS_WIN:
        cand = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(cand):
            return cand
    return exe


def tail_log(n: int = 15) -> str:
    try:
        with open(LOG_FILE, encoding="utf-8", errors="replace") as fh:
            return "".join(fh.readlines()[-n:])
    except OSError:
        return "(ยังไม่มี log)"


def ensure_packages() -> None:
    """ไลบรารีที่เพิ่มในรุ่นใหม่ (รูป HEIC/ลดขนาดรูป, อ่าน PDF) — ติดตั้งให้อัตโนมัติถ้ายังไม่มี (ไม่มีเน็ตก็เปิดระบบได้ตามเดิม)"""
    import importlib.util
    missing = [m for m in ("PIL", "pillow_heif", "pypdf") if importlib.util.find_spec(m) is None]
    if not missing:
        return
    print("ติดตั้งไลบรารีที่ขาด: " + ", ".join(missing) + " …")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-r", os.path.join(ROOT, "requirements.txt")], cwd=ROOT)
    print("✓ ติดตั้งแล้ว" if r.returncode == 0 else
          "! ติดตั้งไม่สำเร็จ (ระบบยังใช้ได้ แต่รับรูป HEIC/นำเข้า PDF ไม่ได้) — สั่งเอง: python -m pip install -r requirements.txt")


def start() -> int:
    os.makedirs(DATA, exist_ok=True)
    pid = read_pid()
    if pid_alive(pid) and "portal.py" in pid_cmdline(pid):
        print(f"✓ ระบบทำงานอยู่แล้ว (PID {pid})")
        for u in urls():
            print("   " + u)
        return 0
    if port_open(port()):
        print(f"✗ พอร์ต {port()} ถูกโปรแกรมอื่นใช้อยู่ (น่าจะเป็น UT-CMMS เดิม)")
        print("  หยุดได้ด้วย: คลิกขวา stop_old_cmms.bat > Run as administrator แล้วเปิด start_portal.bat อีกครั้ง")
        return 1
    ensure_packages()
    # ตรวจความพร้อมก่อน (เร็ว ไม่เปิดเซิร์ฟเวอร์) — ถ้าไม่ผ่านจะไม่เปิดเบื้องหลังแบบเงียบ ๆ
    chk = subprocess.run([sys.executable, os.path.join(ROOT, "portal.py"), "--check"], cwd=ROOT,
                         capture_output=True, text=True, encoding="utf-8", errors="replace")
    if chk.returncode != 0:
        print(chk.stdout[-2500:] + chk.stderr[-1500:])
        print("✗ ตรวจความพร้อมไม่ผ่าน — ยังไม่เปิดระบบ")
        return 1
    kwargs = {"cwd": ROOT, "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL,
              "close_fds": True}
    if IS_WIN:
        kwargs["creationflags"] = 0x00000008 | 0x00000200 | 0x08000000   # DETACHED | NEW_GROUP | NO_WINDOW
    else:
        kwargs["start_new_session"] = True
    proc = subprocess.Popen([pythonw(), os.path.join(ROOT, "portal.py"), "--log"], **kwargs)
    with open(PID_FILE, "w", encoding="utf-8") as fh:
        fh.write(str(proc.pid))
    print(f"กำลังเปิดระบบเบื้องหลัง (PID {proc.pid}) …")
    for _ in range(60):
        time.sleep(0.5)
        if port_open(port()):
            print("✓ เปิดระบบแล้ว — ปิดหน้าต่างนี้ได้ ระบบยังทำงานต่อ")
            for u in urls():
                print("   " + u)
            print(f"  log: {LOG_FILE}")
            return 0
        if proc.poll() is not None:
            break
    print("✗ เปิดไม่สำเร็จ — ข้อความล่าสุดใน log:")
    print(tail_log())
    return 1


def stop() -> int:
    pid = read_pid()
    targets = []
    if pid_alive(pid) and "portal.py" in pid_cmdline(pid):
        targets.append(pid)
    if not targets and port_open(port()):
        from tools.stop_old import listening_pids
        targets = [p for p in (listening_pids(port()) if IS_WIN else []) if "portal.py" in pid_cmdline(p)]
    if not targets:
        print("ระบบไม่ได้ทำงานอยู่" + (" (แต่พอร์ตถูกโปรแกรมอื่นใช้ — ดู stop_old_cmms.bat)" if port_open(port()) else ""))
        _clear_pid()
        return 0
    for p in targets:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(p), "/T", "/F"], capture_output=True)
        else:
            try:
                os.kill(p, 15)
            except OSError:
                pass
    for _ in range(20):
        if not port_open(port()):
            break
        time.sleep(0.5)
    _clear_pid()
    print("✓ ปิดระบบแล้ว" if not port_open(port()) else "! ส่งคำสั่งปิดแล้ว แต่พอร์ตยังถูกใช้อยู่")
    return 0


def _clear_pid():
    try:
        os.remove(PID_FILE)
    except OSError:
        pass


def status() -> int:
    pid = read_pid()
    if pid_alive(pid) and port_open(port()):
        print(f"✓ ระบบทำงานอยู่ (PID {pid}, พอร์ต {port()})")
        for u in urls():
            print("   " + u)
        return 0
    if port_open(port()):
        print(f"! พอร์ต {port()} ถูกใช้อยู่ แต่ไม่ใช่ระบบที่เปิดด้วย start_portal.bat (อาจเป็น UT-CMMS เดิม หรือเปิดแบบหน้าต่าง)")
        return 1
    print("✗ ระบบไม่ได้ทำงาน — เปิดด้วย start_portal.bat")
    print("ข้อความล่าสุดใน log:\n" + tail_log(8))
    return 1


def main() -> int:
    cmd = (sys.argv[1] if len(sys.argv) > 1 else "status").lower()
    if cmd == "start":
        return start()
    if cmd == "stop":
        return stop()
    if cmd == "restart":
        stop()
        time.sleep(1)
        return start()
    return status()


if __name__ == "__main__":
    sys.exit(main())
