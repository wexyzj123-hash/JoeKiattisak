#!/usr/bin/env python3
"""tools/go_live.py — เตรียมระบบรวม UT-CMMS + E-Checksheet ให้พร้อมใช้งานจริง ในคำสั่งเดียว

ไม่ต้องติดตั้งโปรแกรมเพิ่ม (ไม่ใช้ nssm) ใช้ได้ขณะ UT-CMMS เดิมยังเปิดอยู่ — สคริปต์นี้ไม่ปิด/ไม่ลบอะไร

ทำตามลำดับ:
 1. หาโฟลเดอร์ UT-CMMS (ค่าเริ่มต้น = โฟลเดอร์ UT-CMMS ที่อยู่ข้าง ๆ E-Checksheet หรือระบุ --cmms "D:\\...\\UT-CMMS")
 2. แบ็กอัป utility_cmms.db (แบบปลอดภัยขณะระบบเปิดอยู่) + database.py + ข้อมูล E-Checksheet → โฟลเดอร์ backup\\go-live-<วันเวลา>
 3. แก้บั๊กใน database.py ของ UT-CMMS (ค่าวันทำงาน TPM ถูกล้างทุกครั้งที่รีสตาร์ท) — แก้เฉพาะจุด รันซ้ำได้
 4. สร้าง/เติมไฟล์ .env (CMMS_DIR, พอร์ต 5000, รหัสลับ) — ไม่ทับค่าที่ตั้งไว้แล้ว
 5. ติดตั้งไลบรารีที่ขาด (pip) · ตรวจความพร้อม · แก้ข้อความที่มีแท็ก HTML · ย้ายข้อมูลเช็คชีตเดิมเข้าระบบใหม่

ใช้งาน:  ดับเบิลคลิก go_live.bat   หรือ   python tools\\go_live.py [--cmms "D:\\sharing SCADA\\Eweb\\UT-CMMS"]
"""
from __future__ import annotations

import argparse
import os
import secrets
import shutil
import socket
import sqlite3
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

# ── จุดที่แก้ใน database.py ของ UT-CMMS ──
OLD_MIGRATION = '''    need_migrate = False
    try:
        # Insert a test row then delete it to trigger CHECK
        db.execute("INSERT INTO tpm_plans (equipment_id,task,frequency,next_due,status) VALUES (1,'__test__','monthly','2099-01-01','awaiting_approval')")
        db.execute("DELETE FROM tpm_plans WHERE task='__test__'")
        db.commit()
    except sqlite3.IntegrityError:
        need_migrate = True
        db.rollback()
'''
NEW_MIGRATION = '''    # [แก้ไข go-live] เดิมทดสอบด้วยการ INSERT แถวที่ equipment_id=1 — ถ้าไม่มีเครื่องจักร id 1 (foreign key ไม่ผ่าน)
    # จะสร้างตาราง tpm_plans ใหม่ทุกครั้งที่เปิดระบบ ทำให้ค่า work_days / skip_holidays หาย
    # → ตรวจจากโครงสร้างตารางแทน: ย้ายเฉพาะเมื่อมี CHECK ของ status ที่ยังไม่รู้จัก awaiting_approval
    _tpm_sql = (db.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='tpm_plans'").fetchone() or [''])[0] or ''
    need_migrate = ('CHECK' in _tpm_sql.upper() and 'status' in _tpm_sql and 'awaiting_approval' not in _tpm_sql)
'''
OLD_COLS = '''            plan_ahead_months INTEGER DEFAULT 12,
            FOREIGN KEY (equipment_id) REFERENCES equipment(id),'''
NEW_COLS = '''            plan_ahead_months INTEGER DEFAULT 12,
            work_days TEXT DEFAULT '1,2,3,4,5',
            skip_holidays INTEGER DEFAULT 1,
            FOREIGN KEY (equipment_id) REFERENCES equipment(id),'''
PATCH_MARK = "[แก้ไข go-live]"


def step(n, text):
    print(f"\n[{n}] {text}")


def ok(text):
    print(f"    ✓ {text}")


def warn(text):
    print(f"    ! {text}")


def fail(text):
    print(f"    ✗ {text}")


def find_cmms(arg: str | None) -> str | None:
    cands = [arg] if arg else []
    cands += [os.path.join(os.path.dirname(ROOT), "UT-CMMS"), r"D:\sharing SCADA\Eweb\UT-CMMS", r"D:\UT-CMMS"]
    for c in cands:
        if c and os.path.isfile(os.path.join(c, "app.py")) and os.path.isfile(os.path.join(c, "database.py")):
            return os.path.abspath(c)
    return None


def backup(cmms: str) -> str:
    dest = os.path.join(ROOT, "backup", "go-live-" + time.strftime("%Y%m%d-%H%M%S"))
    os.makedirs(dest, exist_ok=True)
    db = os.path.join(cmms, "utility_cmms.db")
    src = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=30)
    dst = sqlite3.connect(os.path.join(dest, "utility_cmms.db"))
    src.backup(dst)                      # สำเนาที่สมบูรณ์แม้ UT-CMMS กำลังเขียนอยู่ (รวมข้อมูลในไฟล์ -wal)
    dst.close()
    src.close()
    for name in ("database.py", "app.py"):
        shutil.copy2(os.path.join(cmms, name), os.path.join(dest, name))
    ecs_data = os.path.join(ROOT, "data")
    if os.path.isdir(ecs_data):
        edb = os.path.join(ecs_data, "echecksheet.db")
        if os.path.exists(edb):
            s, d = sqlite3.connect(edb), sqlite3.connect(os.path.join(dest, "echecksheet.db"))
            s.backup(d)
            d.close()
            s.close()
    with open(os.path.join(dest, "วิธีกู้คืน.txt"), "w", encoding="utf-8") as fh:
        fh.write("กู้คืน UT-CMMS แบบเดิม:\n"
                 "1. ปิดระบบรวมด้วย stop_portal.bat\n"
                 f"2. คัดลอก utility_cmms.db และ database.py ในโฟลเดอร์นี้ไปทับที่ {cmms}\n"
                 f"   (ลบไฟล์ utility_cmms.db-wal และ utility_cmms.db-shm ใน {cmms} ก่อน)\n"
                 "3. เปิด UT-CMMS ด้วย start.bat ตามเดิม\n")
    return dest


def patch_database_py(cmms: str) -> str:
    path = os.path.join(cmms, "database.py")
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    if PATCH_MARK in text:
        return "already"
    if OLD_MIGRATION not in text:
        return "not-found"
    text = text.replace(OLD_MIGRATION, NEW_MIGRATION, 1)
    if OLD_COLS in text:
        text = text.replace(OLD_COLS, NEW_COLS, 1)
    compile(text, path, "exec")          # ตรวจว่าไฟล์ยังถูกต้องก่อนบันทึก
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)
    return "patched"


def server_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return socket.gethostname()


def read_env(path: str) -> dict:
    vals = {}
    if os.path.exists(path):
        with open(path, encoding="utf-8-sig") as fh:
            for line in fh:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    vals[k.strip()] = v.strip()
    return vals


def ensure_env(cmms: str, port: int) -> list[str]:
    path = os.path.join(ROOT, ".env")
    have = read_env(path)
    want = {
        "CMMS_DIR": cmms,
        "PORTAL_PORT": str(port),
        "BASE_URL": f"http://{server_ip()}:{port}/echeck",
        "CMMS_SECRET_KEY": secrets.token_hex(32),
        "SECRET_KEY": secrets.token_hex(32),
    }
    added = []
    lines = []
    if not os.path.exists(path):
        lines.append("# สร้างโดย tools/go_live.py — ดูค่าอื่น ๆ ได้ใน .env.example")
    for k, v in want.items():
        if not have.get(k):
            lines.append(f"{k}={v}")
            added.append(k)
    if lines:
        with open(path, "a", encoding="utf-8") as fh:
            if os.path.exists(path) and os.path.getsize(path) > 0:
                fh.write("\n")
            fh.write("\n".join(lines) + "\n")
    return added


def ensure_packages() -> bool:
    missing = []
    for mod in ("flask", "waitress", "openpyxl", "qrcode", "PIL", "pillow_heif", "pypdf"):
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)
    if not missing:
        ok("ไลบรารีครบ")
        return True
    warn("ติดตั้งไลบรารีที่ขาด: " + ", ".join(missing))
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-r", os.path.join(ROOT, "requirements.txt")])
    if r.returncode != 0:
        fail("ติดตั้งไม่สำเร็จ — ลองสั่งเอง: python -m pip install -r requirements.txt")
        return False
    ok("ติดตั้งแล้ว")
    return True


def port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", port)) == 0


def run_portal(*args) -> int:
    return subprocess.run([sys.executable, os.path.join(ROOT, "portal.py"), *args], cwd=ROOT).returncode


def main() -> int:
    ap = argparse.ArgumentParser(description="เตรียมระบบรวม UT-CMMS + E-Checksheet ให้พร้อมใช้งานจริง")
    ap.add_argument("--cmms", help="โฟลเดอร์ UT-CMMS (ค่าเริ่มต้น: โฟลเดอร์ UT-CMMS ข้าง ๆ E-Checksheet)")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--no-import", action="store_true", help="ไม่ย้ายข้อมูลเช็คชีตเดิม")
    args = ap.parse_args()

    print("=" * 66)
    print("  เตรียมระบบรวม UT-CMMS + E-Checksheet")
    print("=" * 66)

    step(1, "หาโฟลเดอร์ UT-CMMS")
    cmms = find_cmms(args.cmms)
    if not cmms:
        fail('ไม่พบ UT-CMMS — ระบุเอง เช่น  go_live.bat --cmms "D:\\sharing SCADA\\Eweb\\UT-CMMS"')
        return 1
    ok(cmms)

    step(2, "แบ็กอัป (ทำได้ขณะ UT-CMMS เปิดอยู่)")
    try:
        dest = backup(cmms)
    except (OSError, sqlite3.Error) as exc:
        fail(f"แบ็กอัปไม่สำเร็จ: {exc} — หยุดทำงาน ไม่ได้แก้ไขอะไร")
        return 1
    ok(dest)

    step(3, "แก้บั๊ก database.py ของ UT-CMMS (ค่าวันทำงาน TPM หายทุกครั้งที่รีสตาร์ท)")
    res = patch_database_py(cmms)
    if res == "patched":
        ok("แก้แล้ว (ไฟล์เดิมอยู่ในแบ็กอัป)")
    elif res == "already":
        ok("เคยแก้แล้ว")
    else:
        warn("ไม่พบโค้ดจุดที่ต้องแก้ (ไฟล์อาจเป็นเวอร์ชันอื่น) — ข้ามขั้นนี้ ระบบยังใช้งานได้")

    step(4, "ไฟล์ตั้งค่า .env")
    added = ensure_env(cmms, args.port)
    ok("เพิ่ม: " + ", ".join(added) if added else "มีค่าครบแล้ว (ไม่เปลี่ยน)")

    step(5, "ไลบรารี Python")
    if not ensure_packages():
        return 1

    step(6, "ตรวจความพร้อม")
    if run_portal("--check") != 0:
        fail("ตรวจไม่ผ่าน — ดูข้อความด้านบน")
        return 1

    step(7, "แก้ข้อความที่มีแท็ก HTML ในข้อมูลเดิม (แบ็กอัปให้อัตโนมัติ)")
    run_portal("--fix-html")

    if not args.no_import:
        step(8, "ย้ายเครื่องจักร / แบบฟอร์ม / ผู้ใช้ / ผลตรวจเช็คชีตเดิมเข้าระบบใหม่ (ของที่มีแล้วจะข้าม)")
        if run_portal("--import-legacy", "--history") != 0:
            warn("ย้ายข้อมูลไม่สำเร็จ — รันใหม่ได้ภายหลัง: python portal.py --import-legacy --history")

    print("\n" + "=" * 66)
    print("  พร้อมแล้ว — ขั้นต่อไป:")
    if port_in_use(args.port):
        print(f"  1. หยุด UT-CMMS เดิม (พอร์ต {args.port} ยังถูกใช้อยู่): คลิกขวา stop_old_cmms.bat > Run as administrator")
        print("  2. ดับเบิลคลิก start_portal.bat (ระบบทำงานเบื้องหลัง ไม่มีหน้าต่างค้าง)")
    else:
        print("  ดับเบิลคลิก start_portal.bat (ระบบทำงานเบื้องหลัง ไม่มีหน้าต่างค้าง)")
    print(f"  เปิดใช้งาน: http://{server_ip()}:{args.port}/  (เมนู E-Checksheet อยู่ใน UT-CMMS)")
    print("  ให้เปิดอัตโนมัติเมื่อเครื่องรีสตาร์ท: คลิกขวา install_autostart.bat > Run as administrator")
    print(f"  ถอยกลับ: ดู {os.path.join(dest, 'วิธีกู้คืน.txt')}")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
