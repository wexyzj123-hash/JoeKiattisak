"""สร้างรูปผังโรงงานตัวอย่าง (ใช้กับ --demo เท่านั้น) — รันครั้งเดียวตอนพัฒนา ต้องมี playwright
python tools/demo_assets/make_layouts.py  → layout_F1.png, layout_F2.png, layout_F3.png
"""
import os
import random

W, H = 1200, 680
HERE = os.path.dirname(os.path.abspath(__file__))

# พื้นที่ utility ของแต่ละโรงงาน: (ชื่อพื้นที่, x, y, w, h, ชนิด) — จุดกึ่งกลางใช้เป็นตำแหน่งหมุดใน seed_demo
LAYOUTS = {
    "F1": {"title": "FACTORY 1", "buildings": [("PRODUCTION HALL A", 90, 250, 520, 250), ("PRODUCTION HALL B", 660, 250, 300, 250),
                                               ("WAREHOUSE", 90, 560, 300, 90), ("OFFICE", 1000, 80, 150, 110)],
           "utility": [("Compressor Room", 440, 95, 170, 95, "bldg"), ("Boiler House", 660, 95, 150, 95, "boiler"),
                       ("Wastewater Treatment", 980, 300, 190, 300, "wwt")]},
    "F2": {"title": "FACTORY 2", "buildings": [("PRODUCTION HALL C", 300, 240, 560, 280), ("MOLDING", 60, 240, 190, 280),
                                               ("OFFICE", 60, 70, 180, 110), ("WAREHOUSE", 300, 570, 420, 80)],
           "utility": [("Chiller Plant", 920, 260, 230, 150, "chiller"), ("Compressor Room", 540, 80, 200, 110, "bldg")]},
    "F3": {"title": "FACTORY 3", "buildings": [("ASSEMBLY HALL", 80, 260, 600, 260), ("PAINT SHOP", 730, 260, 220, 260),
                                               ("OFFICE", 80, 80, 170, 110)],
           "utility": [("Compressor Room", 330, 90, 180, 100, "bldg"), ("Cooling Tower Yard", 990, 250, 180, 170, "ct"),
                       ("Fire Pump Room", 990, 470, 180, 110, "pump")]},
}


def roof(x, y, w, h, fill="#d9dde2", edge="#aab2bb"):
    s = f'<rect x="{x+6}" y="{y+8}" width="{w}" height="{h}" rx="3" fill="#000" opacity=".14"/>'
    s += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3" fill="{fill}" stroke="{edge}" stroke-width="2"/>'
    n = max(2, w // 60)
    for i in range(1, n):
        xx = x + i * w / n
        s += f'<line x1="{xx:.0f}" y1="{y+4}" x2="{xx:.0f}" y2="{y+h-4}" stroke="{edge}" stroke-width="1" opacity=".6"/>'
    return s


def svg(code, spec, seed):
    rnd = random.Random(seed)
    p = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
         '<defs><pattern id="g" width="14" height="14" patternUnits="userSpaceOnUse"><rect width="14" height="14" fill="#cfe0c3"/>'
         '<circle cx="3" cy="4" r="1" fill="#bcd3ae"/><circle cx="10" cy="11" r="1" fill="#bcd3ae"/></pattern>'
         '<radialGradient id="w" cx=".4" cy=".35"><stop offset="0" stop-color="#7fb8cf"/><stop offset="1" stop-color="#3f7f99"/></radialGradient></defs>',
         f'<rect width="{W}" height="{H}" fill="url(#g)"/>']
    # ถนนรอบและถนนกลาง
    road = "#b9bdb5"
    p += [f'<rect x="20" y="205" width="{W-40}" height="30" fill="{road}"/>', f'<rect x="20" y="525" width="{W-40}" height="26" fill="{road}"/>',
          f'<rect x="20" y="20" width="28" height="{H-40}" fill="{road}"/>', f'<rect x="{W-48}" y="20" width="28" height="{H-40}" fill="{road}"/>',
          f'<line x1="20" y1="220" x2="{W-20}" y2="220" stroke="#f2f2ea" stroke-width="2" stroke-dasharray="14 12"/>',
          f'<line x1="20" y1="538" x2="{W-20}" y2="538" stroke="#f2f2ea" stroke-width="2" stroke-dasharray="14 12"/>']
    # ต้นไม้
    for _ in range(70):
        x, y = rnd.randint(30, W - 30), rnd.choice([rnd.randint(25, 60), rnd.randint(620, 665)])
        r = rnd.randint(7, 13)
        if x > W - 460 and y > 600:
            continue          # เว้นที่ชื่อผัง
        p.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="#5e9a58" stroke="#4d8547"/>')
    for name, x, y, w, h in spec["buildings"]:
        p.append(roof(x, y, w, h))
        p.append(f'<text x="{x+w/2}" y="{y+h/2+6}" text-anchor="middle" font-family="Arial, sans-serif" font-size="{16 if w > 200 else 12}" '
                 f'font-weight="700" fill="#7c848d" letter-spacing="2">{name}</text>')
    for name, x, y, w, h, kind in spec["utility"]:
        if kind == "wwt":        # บ่อบำบัด 4 บ่อ
            p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" fill="#c7cbc2" stroke="#9aa093" stroke-width="2"/>')
            for i in range(2):
                for j in range(2):
                    bx, by = x + 12 + i * (w - 24) / 2, y + 12 + j * (h - 24) / 2
                    p.append(f'<rect x="{bx:.0f}" y="{by:.0f}" width="{(w-36)/2:.0f}" height="{(h-36)/2:.0f}" rx="4" fill="url(#w)" stroke="#e6ece8" stroke-width="3"/>')
        elif kind == "ct":       # หอผึ่งเย็น
            p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4" fill="#c9ced2" stroke="#98a1aa" stroke-width="2"/>')
            for i in range(2):
                for j in range(2):
                    cx, cy = x + w * (0.27 + 0.46 * i), y + h * (0.27 + 0.46 * j)
                    p.append(f'<circle cx="{cx:.0f}" cy="{cy:.0f}" r="{min(w, h)*0.19:.0f}" fill="#8fa6b5" stroke="#eef2f4" stroke-width="3"/>')
                    p.append(f'<circle cx="{cx:.0f}" cy="{cy:.0f}" r="5" fill="#556b79"/>')
        elif kind == "chiller":
            p.append(roof(x, y, w, h, "#cdd6de", "#95a3b0"))
            for i in range(4):
                p.append(f'<rect x="{x+14+i*(w-28)/4:.0f}" y="{y+h-46}" width="{(w-28)/4-8:.0f}" height="34" rx="3" fill="#9fb1bf"/>')
        elif kind == "boiler":
            p.append(roof(x, y, w, h, "#d6cfc6", "#a99f93"))
            p.append(f'<circle cx="{x+w-30}" cy="{y+28}" r="14" fill="#8b857d" stroke="#6f6a63" stroke-width="3"/>')
        else:
            p.append(roof(x, y, w, h, "#cdd6de", "#95a3b0"))
    p.append(f'<text x="{W-60}" y="{H-24}" text-anchor="end" font-family="Arial, sans-serif" font-size="14" font-weight="700" fill="#6c7a66" letter-spacing="3">'
             f'{spec["title"]} · SITE LAYOUT (DEMO)</text>')
    p.append("</svg>")
    return "".join(p)


def pins():
    out = {}
    for code, spec in LAYOUTS.items():
        out[code] = {name: (round(100 * (x + w / 2) / W, 1), round(100 * (y + h / 2) / H, 1)) for name, x, y, w, h, _k in spec["utility"]}
    return out


if __name__ == "__main__":
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        pg = br.new_page(viewport={"width": W, "height": H})
        for i, (code, spec) in enumerate(LAYOUTS.items()):
            pg.set_content(f'<html><body style="margin:0">{svg(code, spec, i + 3)}</body></html>')
            pg.screenshot(path=os.path.join(HERE, f"layout_{code}.png"), type="png")
            print("wrote", code)
        br.close()
    print(pins())
