@echo off
REM Stop the old UT-CMMS running in the background (port 5000) and its auto-start entries.
REM Right-click > Run as administrator.
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul || set "PY=py"
%PY% tools\stop_old.py %*
echo.
pause
