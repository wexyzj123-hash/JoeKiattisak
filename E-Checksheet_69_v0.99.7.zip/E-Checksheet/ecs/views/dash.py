"""ecs/views/dash.py — Phase 3: Dashboard, โหมด TV, กราฟแนวโน้ม, รายการแจ้งเตือน, ตั้งค่ากฎตรวจจับ"""
from __future__ import annotations

from datetime import datetime

from flask import Blueprint, abort, current_app, flash, jsonify, redirect, render_template, request, session, url_for

from .. import analytics as AN
from .. import anomaly as A
from .. import masterdata as M
from .. import services as S
from ..db import get_db
from ..security import ALL_ROLES, MANAGE_ROLES, current_user_id, require_role, safe_next, wants_json

bp = Blueprint("dash", __name__)

from .. import terms as _TR   # v0.50 ภาษากลาง
SEV_TH = _TR.th("SEVERITY")
ALERT_STATUS_TH = _TR.th("ALERT")


@bp.app_context_processor
def _inject():
    out = {"nav_alerts": 0, "SEV_TH": SEV_TH, "ALERT_STATUS_TH": ALERT_STATUS_TH, "ALERT_TYPE_TH": A.TYPE_TH}
    if "user_id" in session and session.get("role") != "technician":
        try:
            c = A.open_alert_counts(get_db())
            out["nav_alerts"] = c["critical"] + c["warning"]
        except Exception:  # noqa: BLE001 — badge ต้องไม่ทำให้หน้าเว็บล่ม
            pass
    return out


def _int_arg(name) -> int | None:
    try:
        return int(request.args.get(name) or 0) or None
    except ValueError:
        return None


def _dashboard_data(db, factory_id, d_from, d_to) -> dict:
    return {
        "overview": AN.overview(db, d_from, d_to, factory_id),
        "trend": AN.compliance_trend(db, d_from, d_to, factory_id),
        "heatmap": AN.heatmap(db, d_from, d_to, factory_id),
        "pareto": AN.ng_pareto(db, d_from, d_to, factory_id),
    }


def _factory_order(factories) -> list[int]:
    """ลำดับสีของโรงงานคงที่ (สีตามโรงงาน ไม่เปลี่ยนเมื่อกรอง)"""
    return [f["id"] for f in factories if f.get("active", 1)]


# ───────────────────────── dashboard ─────────────────────────

_ROUND_TONE = {"done_on_time": "good", "done_late": "warn", "overdue": "warn", "missed": "crit", "returned": "crit",
               "skipped": "down", "pending": "info", "in_progress": "info"}
_PILL_TONE = {"critical": "crit", "warning": "warn", "good": "good"}


def _machine_row(eq_id, code):
    return [{"title": f"ข้อมูลเครื่อง {code or ''}".strip(), "sub": "ค่าล่าสุดทุกหัวข้อ · รอบตรวจของวัน", "tone": "info", "sym": "⚙",
             "od": {"t": "machine", "id": eq_id}}] if eq_id else []


def _od_round(c, rounds_url):
    """v0.99.6 สเปกแผงดูต่อของรอบตรวจ 1 รอบ (หน้าภาพรวม)"""
    st_th = _TR.th("ROUND")
    url = url_for("review.submission_detail", sub_id=c["submission_id"]) if c.get("submission_id") else f"{rounds_url}#rnd-{c['id']}"
    code, hhmm = c.get("eq_code") or c.get("form_code") or "", (c.get("due_at") or "")[11:16]
    return {"t": "panel", "crumb": f"{code} {hhmm}", "title": f"{code} · รอบ {hhmm}",
            "sub": (c.get("form_name") or "") + (f" · {c['area_name']}" if c.get("area_name") else ""),
            "tone": _ROUND_TONE.get(c["status"], "none"),
            "facts": [["สถานะ", st_th.get(c["status"], c["status"]), _ROUND_TONE.get(c["status"])],
                      ["ผู้ตรวจ", c.get("inspector_name") or "–"],
                      ["ส่งผล", (c.get("finished_at") or "")[11:16] or "–"],
                      ["NG", str(c.get("ng_count") or 0), "crit" if c.get("ng_count") else None]],
            "note": f"เครื่องหยุด: {c.get('down_reason') or ''}" if c["status"] == "skipped" else "",
            "rows": _machine_row(c.get("equipment_id"), c.get("eq_code")),
            "links": [["เปิดผลตรวจ" if c.get("submission_id") else "ไปหน้าติดตามรอบตรวจ", url, True]]}


def _od_alert(a):
    """v0.99.6 สเปกแผงดูต่อของแจ้งเตือน 1 รายการ"""
    links = [["เปิดแจ้งเตือน / สั่งแก้ไข", url_for("dash.alert_detail", alert_id=a["id"]), True]]
    if a.get("submission_id"):
        links.append(["ผลตรวจที่พบ", url_for("review.submission_detail", sub_id=a["submission_id"])])
    return {"t": "panel", "crumb": f"แจ้งเตือน #{a['id']}", "title": a.get("title") or "",
            "sub": " · ".join(x for x in (a.get("eq_code"), a.get("form_name"), a.get("factory_name")) if x),
            "tone": _PILL_TONE.get(a.get("pill"), "info"),
            "facts": [["สถานะ", a.get("pill_th") or "", _PILL_TONE.get(a.get("pill"))], ["พบล่าสุด", (a.get("last_seen") or "")[:16]],
                      ["เกิดซ้ำ", f"{a.get('occurrences') or 1} ครั้ง"], ["ระดับ", SEV_TH.get(a.get("severity"), a.get("severity") or "–")]],
            "note": a.get("detail") or "", "rows": _machine_row(a.get("equipment_id"), a.get("eq_code")), "links": links}


@bp.route("/dashboard")
@require_role(*ALL_ROLES)
def dashboard():
    from datetime import date, timedelta
    db = get_db()
    factory_id = _int_arg("factory")
    day = _day_arg()
    d_from, d_to, days = AN.parse_range(request.args, 30)
    factories = M.list_factories(db)
    rounds = S.rounds_overview(db, day, factory_id)
    order = {"missed": 0, "returned": 1, "overdue": 2, "in_progress": 3, "pending": 4, "done_late": 5, "done_on_time": 6, "skipped": 7}
    checklist = sorted(rounds["items"], key=lambda r: (order.get(r["status"], 9), r["due_at"]))
    ctx = {
        "day": day, "is_today": day == date.today(), "prev_day": day - timedelta(days=1),
        "next_day": day + timedelta(days=1) if day < date.today() else None,
        "factory_id": factory_id, "days": days, "d_from": d_from, "d_to": d_to, "factories": factories,
        "factory_order": _factory_order(factories), "now": datetime.now(),
        "sum": AN.today_summary(db, day, factory_id, days),
        "areas": AN.area_status(db, day, factory_id),
        "layouts": AN.factory_layouts(db, factory_id),
        "checklist": checklist, "rounds": rounds,
        "key_items": AN.key_items(db, day, factory_id),
        "machines": AN.machine_list(db, factory_id),
        "week": AN.seven_day(db, day, factory_id),
        "recent_alerts": A.recent_alerts(db, factory_id, limit=6),
        "data": _dashboard_data(db, factory_id, d_from, d_to),
    }
    from .. import insights as IN                       # v0.93 เจาะลึกการตรวจ
    ctx["ins"] = {"trend": IN.trending(db, day, factory_id), "shift": IN.shift_rate(db, d_from, d_to, factory_id),
                  "mach": IN.machines(db, day, factory_id, days), "docs": IN.doc_ready(db, day, factory_id),
                  "RULE_TH": IN.RULE_TH, "rs": IN.rate_status}
    ctx["qual"] = IN.quality(db, d_from, d_to, factory_id)                       # v0.96 การ์ด % คุณภาพเครื่องจักร
    mv_form = _int_arg("mv")
    ids = [m["form_id"] for m in ctx["machines"]]
    if mv_form not in ids:
        mv_form = next((k["form_id"] for k in ctx["key_items"] if k["form_id"] in ids), ids[0] if ids else None)
    mv_days = 30 if request.args.get("mvd") == "30" else 7
    ctx["mv"] = AN.machine_values(db, mv_form, mv_days, day) if mv_form else None
    ctx["mv_days"] = mv_days
    rounds_url = url_for("forms.rounds", date=day.isoformat(), factory=factory_id or None)
    ctx["odr"] = lambda c: _od_round(c, rounds_url)      # v0.99.6 แผงดูต่อ
    ctx["oda"] = _od_alert
    db.commit()   # ensure_stats อาจเติมตารางสรุป
    return render_template("dash/dashboard.html", **ctx)


@bp.route("/api/areas/<int:area_id>/equipment")
@require_role(*ALL_ROLES)
def api_area_equipment(area_id):
    """v0.99.3 รายการเครื่องในพื้นที่ + สถานะของวัน (การ์ดสถานะรายพื้นที่ในหน้าภาพรวม กดเจาะลึก) — อ่านอย่างเดียว"""
    from datetime import date as _date
    db = get_db()
    a = db.execute("""SELECT ar.id, ar.name, ar.factory_id, fa.name AS factory_name FROM areas ar
                      JOIN factories fa ON fa.id=ar.factory_id WHERE ar.id=? AND ar.active=1""", (area_id,)).fetchone()
    if not a:
        return jsonify({"error": "ไม่พบพื้นที่"}), 404
    try:
        day = _date.fromisoformat(request.args.get("date") or "")
    except ValueError:
        day = datetime.now().date()
    eqs = AN.equipment_status(db, day, area_id)
    latest = {}
    if eqs:
        ids = [e["id"] for e in eqs]
        latest = {r[0]: r[1] for r in db.execute(
            f"SELECT equipment_id, MAX(id) FROM cs_submissions WHERE equipment_id IN ({','.join('?' * len(ids))}) "
            "AND status<>'superseded' GROUP BY equipment_id", ids)}
    rounds_url = url_for("forms.rounds", date=day.isoformat(), factory=a["factory_id"])
    out = []
    for e in eqs:
        f0 = (e.get("forms") or [None])[0]
        sid = latest.get(e["id"])
        out.append({
            "id": e["id"], "code": e["code"], "name": e["name"], "eq_type": e.get("eq_type") or "",
            "status": e["status"], "status_th": e["status_th"], "reason": e["reason"],
            "rounds": e["rounds"], "done": e["done"], "ng": e["ng"], "alerts": e["alerts"],
            "last_at": e["last_at"], "last_by": e["last_by"], "next_deadline": e["next_deadline"],
            "down_since": e.get("down_since"), "forms": [{"id": f["id"], "code": f["code"], "name": f["name"]} for f in e.get("forms") or []],
            "links": {
                "latest": url_for("review.submission_detail", sub_id=sid) if sid else "",
                "m360": url_for("dash.machine360", equipment_id=e["id"]),
                "detail": url_for("admin.equipment_detail", equipment_id=e["id"]),
                "trends": url_for("dash.trends", form=f0["id"]) if f0 else "",
                "form": url_for("forms.form_detail", form_id=f0["id"]) if f0 else "",
                "rounds": rounds_url,
            },
        })
    return jsonify({"area": {"id": a["id"], "name": a["name"], "factory": a["factory_name"],
                             "map": url_for("admin.area_map", area_id=a["id"]),
                             "equipment": url_for("admin.equipment", area=a["id"]), "rounds": rounds_url},
                    "day": day.isoformat(), "machines": out})


@bp.route("/api/machine-values")
@require_role(*ALL_ROLES)
def api_machine_values():
    """v0.43 ทุกค่าที่ตรวจของเครื่องจักร (ทุกหัวข้อ) ย้อนหลัง 7/30 วัน"""
    from datetime import date
    db = get_db()
    days = 30 if request.args.get("days") == "30" else 7
    try:
        day = date.fromisoformat(request.args.get("date") or date.today().isoformat())
    except ValueError:
        day = date.today()
    data = AN.machine_values(db, _int_arg("form") or 0, days, day)
    if data is None:
        return jsonify({"error": "ไม่พบเครื่องจักร"}), 404
    return jsonify(data)


@bp.route("/api/dashboard")
@require_role(*ALL_ROLES)
def api_dashboard():
    db = get_db()
    d_from, d_to, _ = AN.parse_range(request.args, 30)
    data = _dashboard_data(db, _int_arg("factory"), d_from, d_to)
    db.commit()
    return jsonify(data)


@bp.route("/tv")
@require_role(*ALL_ROLES)
def tv():
    """โหมดจอห้องควบคุม: พื้นมืด ตัวใหญ่ รีเฟรชเองทุก 60 วินาที"""
    db = get_db()
    factory_id = _int_arg("factory")
    d_from, d_to, days = AN.parse_range(request.args, 7)
    data = _dashboard_data(db, factory_id, d_from, d_to)
    alerts = A.list_alerts(db, status="open", factory_id=factory_id, limit=10)
    db.commit()
    factories = M.list_factories(db)
    return render_template("dash/tv.html", data=data, alerts=alerts, factory_id=factory_id, days=days,
                           factories=factories, now=datetime.now(), factory_order=_factory_order(factories))


# ───────────────────────── trends ─────────────────────────

def _trend_forms(db) -> list[dict]:
    """แบบฟอร์มที่มีหัวข้อตัวเลข (ใช้ทำกราฟได้)"""
    rows = db.execute("""
        SELECT f.id, f.name, e.code AS eq_code, fa.name AS factory_name
        FROM cs_forms f LEFT JOIN equipment e ON e.id=f.equipment_id LEFT JOIN factories fa ON fa.id=f.factory_id
        WHERE f.active=1 AND f.is_template=0 AND f.current_version_id IS NOT NULL
        ORDER BY COALESCE(fa.sort_no, 99), e.code, f.name""").fetchall()           # v0.33 ทุกแบบฟอร์ม (แดชบอร์ดรายเครื่อง)
    return [dict(r) for r in rows]


@bp.route("/trends")
@require_role(*ALL_ROLES)
def trends():
    db = get_db()
    forms = _trend_forms(db)
    form_id = _int_arg("form")
    item_key = request.args.get("item") or ""
    if not form_id and forms:
        # เปิดหน้ามาครั้งแรก: แสดงหัวข้อที่มีแจ้งเตือนทางสถิติล่าสุด (สิ่งที่ควรดูก่อน) ถ้าไม่มีใช้แบบฟอร์มแรก
        hot = db.execute(f"""SELECT form_id, item_key FROM cs_alerts WHERE item_key IS NOT NULL AND item_key<>''
                              AND alert_type IN ('spc_sigma','spc_run','spc_trend','roc','baseline','stuck')
                              AND status IN ({','.join('?' * len(A.OPEN_STATUSES))})
                              ORDER BY updated_at DESC LIMIT 1""", A.OPEN_STATUSES).fetchone()
        valid = {f["id"] for f in forms}
        form_id, item_key = (hot["form_id"], hot["item_key"]) if hot and hot["form_id"] in valid else (forms[0]["id"], "")
    items = AN.numeric_items(db, form_id) if form_id else []
    item_key = item_key or (items[0]["item_key"] if items else "")
    if items and item_key not in {i["item_key"] for i in items}:
        item_key = items[0]["item_key"]
    d_from, d_to, days = AN.parse_range(request.args, 30)
    series = None
    if form_id and item_key:
        try:
            series = AN.item_series(db, form_id, item_key, d_from, d_to)
        except S.ValidationError:
            series = None
    alerts = A.list_alerts(db, status="", form_id=form_id, limit=50) if form_id else []
    alerts = [a for a in alerts if a["item_key"] in (item_key, None, "")][:10]
    ov = AN.machine_overview(db, form_id, d_from, d_to) if form_id else None      # v0.33 แดชบอร์ดรายเครื่อง
    from .. import insights as IN                                                    # v0.96 % คุณภาพ เฉพาะเครื่องที่เลือก
    qscope = "all" if request.args.get("qscope") == "all" else "num"
    qual = IN.quality(db, d_from, d_to, scope=qscope, form_id=form_id) if form_id else None
    return render_template("dash/trends.html", forms=forms, form_id=form_id, items=items, item_key=item_key,
                           series=series, days=days, d_from=d_from, d_to=d_to, alerts=alerts, ov=ov,
                           mode=request.args.get("mode", "spec"), qual=qual, qscope=qscope)


@bp.route("/quality")
@require_role(*ALL_ROLES)
def quality():
    """v0.96 ภาพรวม % คุณภาพเครื่องจักร (ทุกเครื่อง) — เปิดจากการ์ดในหน้าภาพรวม"""
    from .. import insights as IN
    db = get_db()
    d_from, d_to, days = AN.parse_range(request.args, 30)
    qfac = _int_arg("qfac") or _int_arg("factory")
    qscope = "all" if request.args.get("qscope") == "all" else "num"
    qual = IN.quality(db, d_from, d_to, qfac, qscope)
    qfacs = [dict(r) for r in db.execute("SELECT id, name FROM factories WHERE active=1 ORDER BY COALESCE(sort_no, 99), name").fetchall()]
    return render_template("dash/quality.html", qual=qual, qfac=qfac, qscope=qscope, qfacs=qfacs, days=days)


@bp.route("/machines")
@bp.route("/machines/<int:equipment_id>")
@require_role(*ALL_ROLES)
def machine360(equipment_id=None):
    """v0.95 ประวัติเครื่องหน้าเดียว: ผลตรวจ · NG · CAPA · หยุด/ซ่อม · ชั่วโมงเดินเครื่อง · MTBF/MTTR"""
    from .. import machine360 as M3
    db = get_db()
    if not equipment_id:
        eqs = [dict(r) for r in db.execute("""
            SELECT e.id, e.code, e.name, COALESCE(e.run_status,'running') AS run_status, fa.name AS factory_name, ar.name AS area_name,
                   (SELECT MAX(s.finished_at) FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id WHERE f.equipment_id=e.id) AS last_at
            FROM equipment e LEFT JOIN factories fa ON fa.id=e.factory_id LEFT JOIN areas ar ON ar.id=e.area_id
            WHERE e.active=1 AND EXISTS (SELECT 1 FROM cs_forms f WHERE f.equipment_id=e.id AND f.is_template=0)
            ORDER BY COALESCE(fa.sort_no, 99), e.code""")]
        return render_template("dash/machine_pick.html", eqs=eqs)
    d_from, d_to, days = AN.parse_range(request.args, 90)
    M = M3.build(db, equipment_id, d_from, d_to, current_app.config)
    if not M:
        abort(404)
    kind = request.args.get("ev") or ""
    return render_template("dash/machine360.html", M=M, days=days, kind=kind if kind in M3.EV_TH else "", EV_TH=M3.EV_TH)


@bp.route("/trends/quality.xlsx")
@require_role(*ALL_ROLES)
def quality_xlsx():
    """v0.94 Excel % คุณภาพเครื่องจักร"""
    from .. import insights as IN
    db = get_db()
    d_from, d_to, _ = AN.parse_range(request.args, 30)
    Q = IN.quality(db, d_from, d_to, _int_arg("qfac"), "all" if request.args.get("qscope") == "all" else "num", form_id=_int_arg("form"))
    return current_app.response_class(IN.quality_xlsx(Q), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                      headers={"Content-Disposition": f"attachment; filename=quality_{d_from:%Y%m%d}_{d_to:%Y%m%d}.xlsx"})


@bp.route("/api/trend")
@require_role(*ALL_ROLES)
def api_trend():
    db = get_db()
    form_id = _int_arg("form")
    if not form_id:
        return jsonify({"error": "ต้องระบุแบบฟอร์ม"}), 400
    item_key = request.args.get("item", "")
    if not item_key:
        return jsonify({"items": [{k: i[k] for k in ("item_key", "name", "unit", "item_type")}
                                  for i in AN.numeric_items(db, form_id)]})
    d_from, d_to, _ = AN.parse_range(request.args, 30)
    try:
        return jsonify(AN.item_series(db, form_id, item_key, d_from, d_to))
    except S.ValidationError as exc:
        return jsonify({"error": exc.errors[0]}), 404


@bp.route("/api/equipment/<int:equipment_id>/summary")
@require_role(*ALL_ROLES)
def api_equipment_summary(equipment_id):
    return jsonify({"items": AN.equipment_summary(get_db(), equipment_id)})


@bp.route("/api/equipment/<int:equipment_id>/drill")
@require_role(*ALL_ROLES)
def api_equipment_drill(equipment_id):
    """v0.99.6 แผงดูต่อของหน้าภาพรวม: ข้อมูลเครื่อง + รอบตรวจของวัน + ค่าล่าสุดทุกหัวข้อตัวเลข + ลิงก์ — อ่านอย่างเดียว"""
    from datetime import date as _date
    db = get_db()
    e = db.execute("""SELECT e.id, e.code, e.name, e.eq_type, COALESCE(e.run_status,'running') AS run_status, e.down_reason,
                             e.down_since, e.down_until, fa.name AS factory_name, ar.name AS area_name, e.factory_id
                      FROM equipment e LEFT JOIN factories fa ON fa.id=e.factory_id LEFT JOIN areas ar ON ar.id=e.area_id
                      WHERE e.id=?""", (equipment_id,)).fetchone()
    if not e:
        return jsonify({"error": "ไม่พบเครื่องจักร"}), 404
    try:
        day = _date.fromisoformat(request.args.get("date") or "")
    except ValueError:
        day = datetime.now().date()
    rounds = [r for r in S.rounds_overview(db, day, e["factory_id"])["items"] if r.get("equipment_id") == equipment_id]
    st_th = _TR.th("ROUND")
    forms = [dict(r) for r in db.execute("SELECT id, code, name FROM cs_forms WHERE equipment_id=? AND active=1 "
                                         "AND COALESCE(is_template,0)=0 ORDER BY code", (equipment_id,))]
    sid = db.execute("SELECT MAX(s.id) FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id "
                     "WHERE f.equipment_id=? AND s.status<>'superseded'", (equipment_id,)).fetchone()[0]
    items = AN.equipment_summary(db, equipment_id)
    items.sort(key=lambda i: ({"ng": 0, "warn": 1}.get(i.get("judgement"), 2), i["name"]))
    return jsonify({
        "machine": {k: e[k] for k in ("id", "code", "name", "eq_type", "run_status", "down_reason", "down_since",
                                      "down_until", "factory_name", "area_name")},
        "day": day.isoformat(),
        "rounds": [{"id": r["id"], "due_at": r["due_at"], "status": r["status"], "status_th": st_th.get(r["status"], r["status"]),
                    "inspector": r.get("inspector_name") or "", "finished_at": r.get("finished_at"), "ng": r.get("ng_count") or 0,
                    "form": r.get("form_name") or "",
                    "url": url_for("review.submission_detail", sub_id=r["submission_id"]) if r.get("submission_id")
                    else url_for("forms.rounds", date=day.isoformat(), factory=e["factory_id"]) + f"#rnd-{r['id']}"}
                   for r in sorted(rounds, key=lambda r: r["due_at"])],
        "items": [{k: i[k] for k in ("form_id", "item_key", "name", "unit", "min_value", "max_value", "last", "last_at", "judgement")}
                  | {"values": i["values"][-30:]} for i in items[:12]],
        "links": {"m360": url_for("dash.machine360", equipment_id=equipment_id),
                  "detail": url_for("admin.equipment_detail", equipment_id=equipment_id),
                  "latest": url_for("review.submission_detail", sub_id=sid) if sid else "",
                  "trends": url_for("dash.trends", form=forms[0]["id"]) if forms else "",
                  "rounds": url_for("forms.rounds", date=day.isoformat(), factory=e["factory_id"])},
    })


# ───────────────────────── alerts ─────────────────────────

@bp.route("/alerts")
@require_role(*ALL_ROLES)
def alerts():
    db = get_db()
    status = request.args.get("status", "open")
    if status not in ("open", "new", "acknowledged", "in_progress", "resolved", "closed", "all"):
        status = "open"
    severity = request.args.get("severity", "")
    severity = severity if severity in SEV_TH else ""
    alert_type = request.args.get("type", "")
    alert_type = alert_type if alert_type in A.TYPE_TH else ""
    factory_id = _int_arg("factory")
    rows = A.list_alerts(db, status="" if status == "all" else status, severity=severity, alert_type=alert_type,
                         factory_id=factory_id, limit=300)
    n_missed = len(A.list_alerts(db, status="" if status == "all" else status, alert_type="missed",
                                 factory_id=factory_id, limit=5000)) if alert_type in ("", "missed") else 0
    return render_template("dash/alerts.html", alerts=rows, status=status, severity=severity, alert_type=alert_type, n_missed=n_missed,
                           factory_id=factory_id, factories=M.list_factories(db),
                           counts=A.open_alert_counts(db, factory_id))


@bp.route("/alerts/<int:alert_id>")
@require_role(*ALL_ROLES)
def alert_detail(alert_id):
    db = get_db()
    alert = A.get_alert(db, alert_id)
    if not alert:
        abort(404)
    if alert["alert_type"] == "approval" and alert.get("submission_id"):
        return redirect(url_for("review.submission_detail", sub_id=alert["submission_id"]))   # รออนุมัติ → หน้าอนุมัติ
    fac = alert.get("factory_id")
    assignable = [dict(u) for u in db.execute(
        """SELECT id, name, role FROM users WHERE active=1 AND role IN ('admin','supervisor','technician')
           AND (? IS NULL OR factory_id IS NULL OR factory_id=?) ORDER BY role DESC, name""", (fac, fac))]
    wo = None
    if alert.get("wo_id"):
        from ..cmms_wo import STATUS_CLASS, STATUS_TH, ensure
        ensure(db)
        r = db.execute("SELECT wo_number, status FROM cs_cmms_wo WHERE wo_id=? ORDER BY id LIMIT 1", (alert["wo_id"],)).fetchone()
        if r:
            wo = {"number": r["wo_number"], "status_th": STATUS_TH.get(r["status"], r["status"]),
                  "cls": STATUS_CLASS.get(r["status"], "b-none")}
    return render_template("dash/alert_detail.html", alert=alert, assignable=assignable, wo=wo)


ACTION_DONE_TH = {"ack": "รับทราบแล้ว", "start": "บันทึกว่ากำลังแก้ไข", "resolve": "บันทึกการแก้ไขแล้ว",
                  "close": "ปิดงานแล้ว", "reopen": "เปิดใหม่แล้ว", "assign": "มอบหมายแล้ว"}


def _form_or_json() -> dict:
    return (request.get_json(silent=True) or {}) if request.is_json else request.form.to_dict()


def _scope_alert_ids(db, ids: list[int]) -> list[int]:
    """หัวหน้างานที่ผูกโรงงาน จัดการได้เฉพาะแจ้งเตือนของโรงงานตัวเอง"""
    if session.get("role") == "supervisor" and session.get("factory_id"):
        own = session["factory_id"]
        ids = [i for i in ids if (r := db.execute("""SELECT f.factory_id FROM cs_alerts a LEFT JOIN cs_forms f ON f.id=a.form_id
                                                     WHERE a.id=?""", (i,)).fetchone()) and r[0] in (None, own)]
    return ids


@bp.route("/alerts/<int:alert_id>/delete", methods=["POST"])
@require_role(*MANAGE_ROLES)
def alert_delete(alert_id):
    db = get_db()
    reason = (request.form.get("reason") or "").strip()
    n = A.delete_alerts(db, _scope_alert_ids(db, [alert_id]), current_user_id(), reason or "ลบรายการเดียว",
                        any_type=bool(reason))
    db.commit()
    flash("ลบแจ้งเตือนแล้ว (เก็บประวัติไว้ใน Audit Trail)" if n else
          "ลบไม่ได้ — ต้องระบุเหตุผล (ประเภทอื่นนอกจากขาดตรวจ) · รายการรออนุมัติต้องอนุมัติ/ตีกลับที่ผลตรวจ", "ok" if n else "error")
    return redirect(safe_next(request.form.get("next") or "", url_for("dash.alerts")))


@bp.route("/alerts/<int:alert_id>/<action>", methods=["POST"])
@require_role(*ALL_ROLES)
def alert_action(alert_id, action):
    from .. import notify as N
    db = get_db()
    data = _form_or_json()
    alert = A.get_alert(db, alert_id)
    if not alert:
        abort(404)
    me = current_user_id()
    manager = session.get("role") in MANAGE_ROLES
    # ผู้ที่ได้รับมอบหมาย (เช่น ช่าง) บันทึกเริ่มแก้ไข/แก้ไขแล้วได้เอง; การปิดงาน/มอบหมายเป็นของหัวหน้า
    if not manager and not (action in ("ack", "start", "resolve") and alert["assigned_to"] == me):
        if wants_json():
            return jsonify({"error": "ไม่มีสิทธิ์ทำรายการนี้"}), 403
        return render_template("error.html", code=403, message="ไม่มีสิทธิ์ทำรายการนี้"), 403
    try:
        if action == "capa":
            from .. import capa as C
            aid = C.create_from_alert(db, alert_id, me)
            db.commit()
            N.wake()
            if wants_json():
                return jsonify({"ok": True, "action_id": aid})
            flash("สร้างงานแก้ไข (CAPA) แล้ว — ตรวจสอบผู้รับผิดชอบและกำหนดเสร็จ", "ok")
            return redirect(url_for("work.action_detail", action_id=aid))
        assign = data.get("assign_to")
        alert = A.set_alert_status(db, alert_id, action, me, data.get("note") or "",
                                   root_cause=data.get("root_cause") or "", action_taken=data.get("action_taken") or "",
                                   assign_to=int(assign) if str(assign or "").isdigit() else None)
        if action in ("assign", "start") and alert["assigned_to"] and alert["assigned_to"] != me:
            u = db.execute("SELECT * FROM users WHERE id=?", (alert["assigned_to"],)).fetchone()
            if u:
                N._deliver(db, N.get_settings(db), current_app.config.get("BASE_URL", ""), {"users": [dict(u)], "groups": []},
                           kind="alert", subject=f"🛠 มอบหมายให้แก้ไข: {alert['title']}", body=alert["detail"] or "",
                           path=f"/alerts/{alert_id}", severity=alert["severity"],
                           ref_key=f"assign:{alert_id}:{u['id']}:{alert['updated_at']}")
        db.commit()
        N.wake()
    except (S.ValidationError, ValueError) as exc:
        db.rollback()
        msg = exc.errors[0] if isinstance(exc, S.ValidationError) else "ข้อมูลไม่ถูกต้อง"
        if wants_json():
            return jsonify({"error": msg}), 400
        flash(msg, "error")
        return redirect(url_for("dash.alert_detail", alert_id=alert_id))
    if wants_json():
        return jsonify({"ok": True, "status": alert["status"]})
    flash(ACTION_DONE_TH.get(action, "บันทึกแล้ว"), "ok")
    nxt = data.get("next") or ""
    return redirect(safe_next(nxt, url_for("dash.alert_detail", alert_id=alert_id)))


@bp.route("/alerts/bulk", methods=["POST"])
@require_role(*MANAGE_ROLES)
def alerts_bulk():
    db = get_db()
    ids = [int(x) for x in request.form.getlist("ids") if x.isdigit()][:500]
    action = request.form.get("action")
    done = 0
    if action in ("delete", "delete_all"):
        reason = (request.form.get("reason") or "").strip()
        if action == "delete_all":        # ขาดตรวจทั้งหมดตามตัวกรองปัจจุบัน (สถานะ / โรงงาน)
            st = request.form.get("status") or "open"
            st = st if st in ("open", "new", "acknowledged", "in_progress", "resolved", "closed", "all") else "open"
            fac = request.form.get("factory")
            ids = [a["id"] for a in A.list_alerts(db, status="" if st == "all" else st, alert_type="missed",
                                                  factory_id=int(fac) if (fac or "").isdigit() else None, limit=5000)]
        ids = _scope_alert_ids(db, ids)
        if not ids:
            flash("ยังไม่ได้เลือกรายการ — ติ๊กช่องหน้ารายการ หรือ \"เลือกทั้งหมด\" ก่อน", "error")
            return redirect(safe_next(request.form.get("next") or "", url_for("dash.alerts")))
        done = A.delete_alerts(db, ids, current_user_id(), reason or "ลบจากหน้าแจ้งเตือน", any_type=bool(reason))
        db.commit()
        skipped = len(ids) - done
        if done:
            msg = f"ลบแจ้งเตือนแล้ว {done} รายการ (เก็บประวัติไว้ใน Audit Trail)"
            if skipped:
                msg += f" · ข้าม {skipped} รายการ (รออนุมัติที่ยังค้าง หรือไม่ได้ระบุเหตุผล)"
            flash(msg, "ok")
        else:
            flash("ไม่มีรายการที่ลบได้ — กรุณาระบุเหตุผลการลบ · รายการรออนุมัติต้องอนุมัติ/ตีกลับที่ผลตรวจ", "error")
        return redirect(safe_next(request.form.get("next") or "", url_for("dash.alerts")))
    ids = _scope_alert_ids(db, ids)
    if action == "ack":
        for i in ids:
            try:
                A.set_alert_status(db, i, "ack", current_user_id())
                done += 1
            except S.ValidationError:
                pass
        db.commit()
    if not ids:
        flash("ยังไม่ได้เลือกรายการ", "error")
    else:
        flash(f"รับทราบแล้ว {done} รายการ" + (f" · {len(ids) - done} รายการรับทราบไปแล้ว" if len(ids) > done else "") if done
              else "รายการที่เลือกรับทราบไปแล้วทั้งหมด", "ok" if done else "error")
    nxt = request.form.get("next") or ""
    return redirect(safe_next(nxt, url_for("dash.alerts")))


# ───────────────────────── admin: anomaly rules ─────────────────────────

RULE_PARAMS = {
    "threshold": [("warn_band", "แจ้งเตือนเมื่ออยู่ในช่วงเตือน (ยังไม่ NG)", "bool")],
    "roc": [("pct", "เปลี่ยนจากครั้งก่อนเกิน (%)", "int")],
    "spc_sigma": [("k", "k (จำนวน σ)", "float"), ("window", "ใช้ข้อมูลย้อนหลัง (จุด)", "int"),
                  ("min_points", "เริ่มตรวจเมื่อมีอย่างน้อย (จุด)", "int")],
    "spc_run": [("n", "จำนวนจุดติดกัน", "int"), ("window", "ใช้ข้อมูลย้อนหลัง (จุด)", "int"),
                ("min_points", "เริ่มตรวจเมื่อมีอย่างน้อย (จุด)", "int")],
    "spc_trend": [("n", "จำนวนจุดเพิ่ม/ลดต่อเนื่อง", "int")],
    "stuck": [("n", "ค่าเดิมซ้ำติดกัน (ครั้ง)", "int")],
    "baseline": [("days", "เทียบย้อนหลัง (วัน)", "int"), ("k", "k (จำนวน σ)", "float"),
                 ("min_points", "เริ่มตรวจเมื่อมีอย่างน้อย (จุด)", "int"),
                 ("hour_window", "ช่วงเวลาเดียวกัน ± (ชั่วโมง)", "int")],
    "missed": [],
}
RULE_HELP = {
    "threshold": "ผลตรวจที่ตัดสินเป็น NG ทุกประเภทหัวข้อ (หัวข้อสำคัญ = วิกฤต)",
    "roc": "เช่น ครั้งก่อน 40 ครั้งนี้ 65 = เปลี่ยน 62% — จับการกระโดดของค่าที่ยังไม่เกินเกณฑ์",
    "spc_sigma": "ค่าหลุดจากช่วงปกติทางสถิติของหัวข้อนั้นเอง (Control Chart)",
    "spc_run": "กระบวนการเลื่อนระดับ (Shift) แม้ยังไม่เกินเกณฑ์",
    "spc_trend": "ค่าค่อยๆ ไต่ขึ้นหรือลง — สัญญาณเสื่อมสภาพก่อนเสีย",
    "stuck": "มิเตอร์ค้าง หรือจดลอกค่าเดิม",
    "baseline": "ต่างจากค่าปกติของช่วงเวลาเดียวกันในวันก่อนๆ (เหมาะกับโหลดที่ขึ้นลงตามกะ)",
    "missed": "รอบตรวจที่ปิดไปโดยไม่มีผลตรวจ",
}


@bp.route("/admin/anomaly-rules", methods=["GET", "POST"])
@require_role("admin")
def anomaly_rules():
    db = get_db()
    if request.method == "POST":
        data: dict[str, dict] = {}
        for rule, params in RULE_PARAMS.items():
            data[rule] = {"enabled": request.form.get(f"{rule}.enabled") == "1"}
            for key, _label, kind in params:
                if kind == "bool":
                    data[rule][key] = request.form.get(f"{rule}.{key}") == "1"
                else:
                    data[rule][key] = request.form.get(f"{rule}.{key}", "")
        try:
            A.save_rules(db, data, current_user_id())
            db.commit()
            flash("บันทึกกฎตรวจจับแล้ว — มีผลกับผลตรวจที่ส่งเข้ามาหลังจากนี้", "ok")
            return redirect(url_for("dash.anomaly_rules"))
        except S.ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
    return render_template("admin/anomaly_rules.html", rules=A.get_rules(db), params=RULE_PARAMS,
                           labels=A.RULE_TH, help=RULE_HELP, defaults=A.DEFAULT_RULES)


# ───────────────────────── v0.41 อัปเดตหน้าจอแบบ Real-time ─────────────────────────

def live_stamp(db) -> str:
    """ลายนิ้วมือของข้อมูลที่แสดงบน Dashboard / ติดตามรอบตรวจ / แจ้งเตือน — เปลี่ยนเมื่อรอบตรวจ ตารางรอบตรวจ
    แจ้งเตือน หรือผลตรวจเปลี่ยน (หน้าจอที่เปิดค้างไว้จะรีเฟรชเอง)"""
    import hashlib
    from datetime import date, timedelta
    since = S.ts(datetime.combine(date.today() - timedelta(days=1), datetime.min.time()))
    parts = [
        db.execute("SELECT COUNT(*), MAX(updated_at), SUM(submission_id IS NOT NULL) FROM cs_rounds WHERE due_at>=?",
                   (since,)).fetchone(),
        db.execute("SELECT COUNT(*), SUM(active), MAX(updated_at) FROM cs_schedules").fetchone(),
        db.execute("SELECT COUNT(*), MAX(updated_at), SUM(status IN ('open','acknowledged','in_progress')) FROM cs_alerts").fetchone(),
        db.execute("SELECT MAX(id), SUM(approval_status='pending') FROM cs_submissions").fetchone(),
        db.execute("SELECT COUNT(*), MAX(id) FROM cs_stat_excl").fetchone(),
        db.execute("SELECT COUNT(*), SUM(run_status='down') FROM equipment").fetchone(),
    ]
    raw = "|".join(",".join(str(x) for x in tuple(p)) for p in parts)
    return hashlib.sha1(raw.encode(), usedforsecurity=False).hexdigest()[:16]


@bp.route("/api/live")
@require_role(*ALL_ROLES)
def api_live():
    db = get_db()
    S.refresh_round_statuses(db)                 # เลยกำหนด / ขาดตรวจ เปลี่ยนตามเวลาจริง
    db.commit()
    resp = jsonify({"stamp": live_stamp(db), "at": datetime.now().strftime("%H:%M:%S")})
    resp.headers["Cache-Control"] = "no-store"
    return resp


# ───────────────────────── v0.41 จัดการสถิติรอบตรวจ ─────────────────────────

def _date_field(name, default):
    from datetime import date
    try:
        return date.fromisoformat((request.values.get(name) or "")[:10])
    except ValueError:
        return default


@bp.route("/admin/round-stats", methods=["GET", "POST"])
@require_role("admin")
def round_stats():
    """คำนวณรอบตรวจย้อนหลังใหม่ · ลบสถิติตรวจตรงเวลา/ล่าช้าช่วงวันที่ (ยกเลิกได้) · แบบฟอร์มที่ยังไม่กำหนดรอบตรวจ"""
    from datetime import date, timedelta

    from .. import statfix as SF
    db = get_db()
    today = date.today()
    v = request.values
    sc = {"factory_id": _int_val(v.get("factory_id")), "area_id": _int_val(v.get("area_id")),
          "form_id": _int_val(v.get("form_id"))}
    d_from = _date_field("day_from", today - timedelta(days=7))
    d_to = _date_field("day_to", today - timedelta(days=1))
    if request.method == "GET":                              # ลบสถิติได้ถึงเมื่อวาน
        d_to = min(d_to, today - timedelta(days=1))
        d_from = min(d_from, d_to)
    preview = None
    if request.method == "POST":
        action = v.get("action", "")
        try:
            if action == "relink":
                ids = SF._scope_forms(db, **sc)
                st = SF.relink_forms(db, ids, day_from=d_from, day_to=max(d_to, d_from), actor_id=current_user_id(),
                                     reason="ผู้ดูแลระบบสั่งคำนวณใหม่")
                db.commit()
                flash(f"{len(ids)} แบบฟอร์ม · " + SF.summary_th(st), "ok")
                return redirect(url_for("dash.round_stats"))
            if action == "preview":
                SF._check_range(d_from, d_to, today)
                preview = SF.exclude_impact(db, d_from, d_to, **sc)
            elif action == "exclude":
                r = SF.exclude_stats(db, d_from, d_to, current_user_id(), v.get("reason", ""), **sc)
                db.commit()
                flash(f"ลบสถิติแล้ว {r['rounds']} รอบ ({r['forms']} แบบฟอร์ม) — ผลตรวจที่ส่งแล้วยังอยู่ครบ "
                      f"(แสดงเป็นตรวจนอกรอบ) · ยกเลิกได้จากรายการด้านล่าง", "ok")
                return redirect(url_for("dash.round_stats"))
            elif action == "restore":
                st = SF.restore_stats(db, int(v.get("excl_id") or 0), current_user_id())
                db.commit()
                flash("คืนสถิติแล้ว · " + SF.summary_th(st), "ok")
                return redirect(url_for("dash.round_stats"))
        except S.ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
    return render_template("admin/round_stats.html", factories=M.list_factories(db), areas=M.list_areas(db),
                           forms=S.list_forms(db), sc=sc, d_from=d_from, d_to=d_to, today=today,
                           yesterday=today - timedelta(days=1), preview=preview, reason=v.get("reason", ""),
                           exclusions=SF.list_exclusions(db), unscheduled=SF.unscheduled_forms(db),
                           relink_days=SF.relink_days(db))


def _int_val(x) -> int | None:
    try:
        return int(x or 0) or None
    except (TypeError, ValueError):
        return None


# ───────────────────────── reports (Excel) ─────────────────────────

def _day_arg():
    from datetime import date
    try:
        d = date.fromisoformat(request.args.get("date") or "")
    except ValueError:
        d = date.today()
    return min(d, date.today())


@bp.route("/reports/<kind>.xlsx")
@require_role(*ALL_ROLES)
def report(kind):
    from flask import Response

    from .. import reports as R
    if kind not in R.REPORTS:
        abort(404)
    db = get_db()
    factory_id, day = _int_arg("factory"), _day_arg()
    if kind == "results":
        data = R.results_report(db, day, factory_id)
    elif kind == "rounds":
        data = R.rounds_report(db, day, factory_id)
    elif kind == "alerts":
        data = R.alerts_report(db, factory_id)
    else:
        d_from, d_to, _ = AN.parse_range(request.args, 30)
        data = R.compliance_report(db, d_from, d_to, factory_id)
    db.commit()
    fname = f"{kind}_{day.isoformat()}.xlsx"
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{fname}"', "Cache-Control": "no-store"})


# ───────────────────────── admin: dashboard items ─────────────────────────

@bp.route("/admin/dashboard-items", methods=["GET", "POST"])
@require_role("admin")
def dash_settings():
    db = get_db()
    if request.method == "POST":
        picked = []
        for v in request.form.getlist("item"):
            fid, _, key = v.partition(":")
            picked.append({"form_id": fid, "item_key": key})
        saved = AN.save_dash_items(db, picked, current_user_id())
        db.commit()
        flash(f"บันทึกแล้ว ({len(saved)} หัวข้อ)" if saved else "ใช้การเลือกอัตโนมัติ", "ok")
        return redirect(url_for("dash.dash_settings"))
    chosen = {(x["form_id"], x["item_key"]) for x in AN.get_dash_items(db)}
    return render_template("admin/dash_items.html", items=AN.candidate_items(db), chosen=chosen)


# ───────────────────────── v0.26.2 ข้อผิดพลาดจากเบราว์เซอร์ผู้ใช้ (เช่น Safari บน iPhone) ─────────────────────────

@bp.route("/api/client-log", methods=["POST"])
@require_role(*ALL_ROLES)
def client_log():
    import logging
    d = request.get_json(silent=True) or {}
    logging.getLogger("ecs.client").warning(
        "client error user=%s ua=%s url=%s w=%s dpr=%s msg=%s", session.get("user_id"),
        (request.headers.get("User-Agent") or "")[:160], str(d.get("url") or "")[:120], d.get("w"), d.get("dpr"),
        str(d.get("msg") or "")[:500].replace("\n", " "))
    return jsonify({"ok": True})
