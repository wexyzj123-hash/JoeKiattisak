"""ecs/schema.py — ตารางทั้งหมดของ E-Checksheet (ระบบแยก ไม่ใช้ข้อมูลของ UT-CMMS)

Master data: users, factories, areas, equipment
Check sheet:  cs_* (แบบฟอร์ม, เวอร์ชัน, รอบตรวจ, ผลตรวจ, รูป, แจ้งเตือน, audit)
ออกแบบให้ย้ายไป SQL Server ได้ภายหลัง: ไม่ใช้ฟีเจอร์เฉพาะ SQLite นอกจาก AUTOINCREMENT
เวลาเก็บเป็นข้อความ 'YYYY-MM-DD HH:MM:SS' (เวลาท้องถิ่นของโรงงาน)
"""
from __future__ import annotations

SCHEMA_VERSION = 5

ITEM_TYPES = ("ok_ng", "number", "counter", "choice", "text", "calc")   # v0.95 calc = คำนวณจากหัวข้ออื่น
NUMERIC_TYPES = ("number", "counter", "calc")
FREQ_TYPES = ("shift", "daily", "weekly", "monthly", "semimonthly")   # semimonthly = เดือนละ 2 ครั้ง (1–15 / 16–สิ้นเดือน)
ROUND_STATUSES = ("pending", "in_progress", "overdue", "done_on_time", "done_late", "missed", "returned",
                  "skipped")        # skipped = เครื่องหยุด/ซ่อม ไม่ต้องตรวจ (ไม่นับในอัตราตรวจตรงเวลา)
ROLES = ("admin", "supervisor", "technician", "viewer")

DDL = """
CREATE TABLE IF NOT EXISTS cs_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS factories (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT NOT NULL UNIQUE,
    name       TEXT NOT NULL,
    sort_no    INTEGER NOT NULL DEFAULT 0,
    active     INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS areas (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id INTEGER NOT NULL REFERENCES factories(id),
    name       TEXT NOT NULL,
    active     INTEGER NOT NULL DEFAULT 1,
    UNIQUE (factory_id, name)
);

CREATE TABLE IF NOT EXISTS users (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    username         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password         TEXT NOT NULL,
    name             TEXT NOT NULL,
    role             TEXT NOT NULL DEFAULT 'technician',  -- admin | supervisor | technician | viewer
    factory_id       INTEGER REFERENCES factories(id),    -- ว่าง = ทุกโรงงาน
    email            TEXT DEFAULT '',
    phone            TEXT DEFAULT '',
    telegram_chat_id TEXT DEFAULT '',
    active           INTEGER NOT NULL DEFAULT 1,
    must_change_pw   INTEGER NOT NULL DEFAULT 0,
    last_login_at    TEXT,
    legacy_id        INTEGER,
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS equipment (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    code        TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name        TEXT NOT NULL,
    eq_type     TEXT DEFAULT '',
    factory_id  INTEGER REFERENCES factories(id),
    area_id     INTEGER REFERENCES areas(id),
    location    TEXT DEFAULT '',
    qr_token    TEXT NOT NULL UNIQUE,
    active      INTEGER NOT NULL DEFAULT 1,
    note        TEXT DEFAULT '',
    legacy_id   INTEGER,
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_eq_factory ON equipment(factory_id, active);

CREATE TABLE IF NOT EXISTS cs_forms (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    code               TEXT UNIQUE,
    name               TEXT NOT NULL,
    description        TEXT DEFAULT '',
    equipment_id       INTEGER REFERENCES equipment(id),
    factory_id         INTEGER REFERENCES factories(id),
    area_id            INTEGER REFERENCES areas(id),
    category           TEXT DEFAULT 'utility',
    current_version_id INTEGER,
    active             INTEGER NOT NULL DEFAULT 1,
    legacy_template_id INTEGER UNIQUE,
    created_by         INTEGER REFERENCES users(id),
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_csf_equipment ON cs_forms(equipment_id);
CREATE INDEX IF NOT EXISTS idx_csf_factory   ON cs_forms(factory_id, active);

-- ทุกการ Publish = 1 เวอร์ชัน (ห้ามแก้หลัง Publish), แก้ไขได้เฉพาะเวอร์ชัน draft
CREATE TABLE IF NOT EXISTS cs_form_versions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id       INTEGER NOT NULL REFERENCES cs_forms(id),
    version_no    INTEGER NOT NULL,
    status        TEXT NOT NULL DEFAULT 'draft',   -- draft | published | retired
    change_note   TEXT DEFAULT '',
    created_by    INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL,
    published_by  INTEGER REFERENCES users(id),
    published_at  TEXT,
    UNIQUE (form_id, version_no)
);
CREATE INDEX IF NOT EXISTS idx_csv_form ON cs_form_versions(form_id, status);

CREATE TABLE IF NOT EXISTS cs_form_items (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    version_id       INTEGER NOT NULL REFERENCES cs_form_versions(id),
    item_key         TEXT NOT NULL,            -- คงที่ข้ามเวอร์ชัน ใช้ต่อกราฟแนวโน้ม
    section          TEXT DEFAULT '',
    order_no         INTEGER NOT NULL DEFAULT 0,
    name             TEXT NOT NULL,
    item_type        TEXT NOT NULL DEFAULT 'ok_ng',
    unit             TEXT DEFAULT '',
    min_value        REAL,                      -- นอกช่วง min/max = NG
    max_value        REAL,
    warn_low         REAL,                      -- อยู่ในช่วง warn = เตือน (เหลือง)
    warn_high        REAL,
    counter_max_step REAL,                      -- counter: เพิ่มขึ้นเกินค่านี้ต่อรอบ = เตือน
    options_json     TEXT DEFAULT '',           -- choice: [{"label":"..","ng":0}]
    required         INTEGER NOT NULL DEFAULT 1,
    critical         INTEGER NOT NULL DEFAULT 0, -- NG แล้วเป็นระดับวิกฤต
    photo_on_ng      INTEGER NOT NULL DEFAULT 1, -- NG ต้องแนบรูป
    guide            TEXT DEFAULT '',            -- วิธีตรวจ/ข้อแนะนำ
    legacy_item_id   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_csi_version ON cs_form_items(version_id, order_no);
CREATE INDEX IF NOT EXISTS idx_csi_key     ON cs_form_items(item_key);

CREATE TABLE IF NOT EXISTS cs_schedules (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id       INTEGER NOT NULL REFERENCES cs_forms(id),
    freq_type     TEXT NOT NULL DEFAULT 'daily',  -- shift | daily | weekly | monthly
    times         TEXT NOT NULL DEFAULT '08:00',  -- เวลาเริ่มตรวจ คั่นด้วย , เช่น 08:00,20:00
    weekdays      TEXT DEFAULT '',                -- weekly: 0=จันทร์ ... 6=อาทิตย์ คั่นด้วย ,
    month_day     INTEGER,                        -- monthly: วันที่ 1-28
    window_min    INTEGER NOT NULL DEFAULT 240,   -- ต้องตรวจเสร็จภายในกี่นาทีหลังเวลาเริ่ม
    skip_holidays INTEGER NOT NULL DEFAULT 0,
    assignee_role TEXT DEFAULT 'technician',
    assignee_user_id INTEGER REFERENCES users(id),
    active        INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_css_form ON cs_schedules(form_id, active);

-- งานตรวจแต่ละรอบ ที่ Scheduler สร้างล่วงหน้า
CREATE TABLE IF NOT EXISTS cs_rounds (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    schedule_id    INTEGER NOT NULL REFERENCES cs_schedules(id),
    form_id        INTEGER NOT NULL REFERENCES cs_forms(id),
    due_at         TEXT NOT NULL,   -- เริ่มตรวจได้
    deadline_at    TEXT NOT NULL,   -- เกินนี้ = เลยกำหนด (ยังส่งได้ นับเป็นสาย)
    close_at       TEXT NOT NULL,   -- เกินนี้โดยไม่ส่ง = ขาดตรวจ
    status         TEXT NOT NULL DEFAULT 'pending',
    submission_id  INTEGER,
    updated_at     TEXT NOT NULL,
    UNIQUE (schedule_id, due_at)
);
CREATE INDEX IF NOT EXISTS idx_csr_due    ON cs_rounds(due_at);
CREATE INDEX IF NOT EXISTS idx_csr_status ON cs_rounds(status, deadline_at);
CREATE INDEX IF NOT EXISTS idx_csr_form   ON cs_rounds(form_id, due_at);

CREATE TABLE IF NOT EXISTS cs_submissions (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    client_uuid      TEXT NOT NULL UNIQUE,   -- กันส่งซ้ำตอนสัญญาณกลับมา
    round_id         INTEGER REFERENCES cs_rounds(id),
    form_id          INTEGER NOT NULL REFERENCES cs_forms(id),
    form_version_id  INTEGER NOT NULL REFERENCES cs_form_versions(id),
    equipment_id     INTEGER REFERENCES equipment(id),
    inspector_id     INTEGER REFERENCES users(id),
    scanned_at       TEXT,          -- เวลาสแกน QR / เปิดฟอร์ม (บนเครื่อง)
    finished_at      TEXT,          -- เวลากดส่ง (บนเครื่อง)
    received_at      TEXT NOT NULL, -- เวลาที่เซิร์ฟเวอร์ได้รับ
    duration_sec     INTEGER,
    status           TEXT NOT NULL DEFAULT 'submitted',  -- submitted | returned | superseded
    resubmit_of      INTEGER REFERENCES cs_submissions(id),
    note             TEXT DEFAULT '',                     -- หมายเหตุรวมของการตรวจ
    client_info      TEXT DEFAULT '',                     -- อุปกรณ์/เบราว์เซอร์ + ส่งแบบออฟไลน์หรือไม่
    ng_count         INTEGER NOT NULL DEFAULT 0,
    warn_count       INTEGER NOT NULL DEFAULT 0,
    approval_status  TEXT NOT NULL DEFAULT 'pending',    -- pending | approved | rejected
    approved_by      INTEGER REFERENCES users(id),
    approved_at      TEXT,
    approval_note    TEXT DEFAULT '',
    source           TEXT NOT NULL DEFAULT 'v3',          -- v3 | legacy
    legacy_log_id    INTEGER UNIQUE
);
CREATE INDEX IF NOT EXISTS idx_cssub_form ON cs_submissions(form_id, finished_at);
CREATE INDEX IF NOT EXISTS idx_cssub_eq   ON cs_submissions(equipment_id, finished_at);
CREATE INDEX IF NOT EXISTS idx_cssub_appr ON cs_submissions(approval_status);

CREATE TABLE IF NOT EXISTS cs_answers (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    submission_id  INTEGER NOT NULL REFERENCES cs_submissions(id),
    item_id        INTEGER NOT NULL REFERENCES cs_form_items(id),
    item_key       TEXT NOT NULL,
    value_num      REAL,
    value_text     TEXT DEFAULT '',
    judgement      TEXT NOT NULL DEFAULT 'ok',   -- ok | warn | ng | na
    remark         TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_csa_sub ON cs_answers(submission_id);
CREATE INDEX IF NOT EXISTS idx_csa_key ON cs_answers(item_key, submission_id);
CREATE INDEX IF NOT EXISTS idx_csa_item ON cs_answers(item_id);

CREATE TABLE IF NOT EXISTS cs_photos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    answer_id   INTEGER REFERENCES cs_answers(id),
    submission_id INTEGER REFERENCES cs_submissions(id),
    file_path   TEXT NOT NULL,
    taken_at    TEXT,
    size_kb     INTEGER,
    width       INTEGER,
    height      INTEGER,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_csp_answer ON cs_photos(answer_id);

CREATE TABLE IF NOT EXISTS cs_alerts (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_type    TEXT NOT NULL,       -- ng | warn | trend | overdue | missed
    severity      TEXT NOT NULL,       -- info | warning | critical
    dedup_key     TEXT NOT NULL,
    form_id       INTEGER REFERENCES cs_forms(id),
    equipment_id  INTEGER REFERENCES equipment(id),
    item_key      TEXT,
    submission_id INTEGER REFERENCES cs_submissions(id),
    round_id      INTEGER REFERENCES cs_rounds(id),
    title         TEXT NOT NULL,
    detail        TEXT DEFAULT '',
    level         INTEGER NOT NULL DEFAULT 1,
    status        TEXT NOT NULL DEFAULT 'open',  -- open | acknowledged | in_progress | resolved | closed
    occurrences   INTEGER NOT NULL DEFAULT 1,
    ack_by        INTEGER REFERENCES users(id),
    ack_at        TEXT,
    root_cause    TEXT DEFAULT '',
    action_taken  TEXT DEFAULT '',
    wo_id         INTEGER,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL,
    closed_at     TEXT
);
CREATE INDEX IF NOT EXISTS idx_csal_open ON cs_alerts(status, severity);
CREATE INDEX IF NOT EXISTS idx_csal_dedup ON cs_alerts(dedup_key, status);

CREATE TABLE IF NOT EXISTS cs_alert_events (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id   INTEGER NOT NULL REFERENCES cs_alerts(id),
    event      TEXT NOT NULL,
    actor_id   INTEGER REFERENCES users(id),
    channel    TEXT DEFAULT '',
    detail     TEXT DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_csae_alert ON cs_alert_events(alert_id);

CREATE TABLE IF NOT EXISTS cs_escalation_rules (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    severity         TEXT NOT NULL,
    level            INTEGER NOT NULL,
    after_min        INTEGER NOT NULL,
    factory_id       INTEGER REFERENCES factories(id),
    notify_role      TEXT DEFAULT '',
    notify_user_id   INTEGER REFERENCES users(id),
    telegram_chat_id TEXT DEFAULT '',
    active           INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS cs_daily_stats (
    stat_date     TEXT NOT NULL,
    form_id       INTEGER NOT NULL,
    due           INTEGER NOT NULL DEFAULT 0,
    done_on_time  INTEGER NOT NULL DEFAULT 0,
    done_late     INTEGER NOT NULL DEFAULT 0,
    missed        INTEGER NOT NULL DEFAULT 0,
    ng            INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (stat_date, form_id)
);

-- Audit trail ของโมดูล: ใคร แก้อะไร เมื่อไหร่ ค่าก่อน/หลัง
CREATE TABLE IF NOT EXISTS cs_audit (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id    INTEGER REFERENCES users(id),
    action      TEXT NOT NULL,
    entity      TEXT NOT NULL,
    entity_id   INTEGER,
    before_json TEXT DEFAULT '',
    after_json  TEXT DEFAULT '',
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_csaud_entity ON cs_audit(entity, entity_id);
"""


# ───────── Phase 4: แจ้งเตือน / Escalation / ช่วงเงียบ / CAPA ─────────
DDL_P4 = """
-- ระดับการส่งต่อ (L1–L3) ต่อโรงงาน (factory_id ว่าง = ใช้กับทุกโรงงานที่ไม่ได้ตั้งเอง)
CREATE TABLE IF NOT EXISTS cs_esc_levels (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id    INTEGER REFERENCES factories(id),
    level         INTEGER NOT NULL,              -- 1..3
    after_min     INTEGER NOT NULL DEFAULT 0,    -- ส่งเมื่อยังไม่มีคนรับทราบครบกี่นาทีหลังเกิด
    min_severity  TEXT NOT NULL DEFAULT 'warning',
    active        INTEGER NOT NULL DEFAULT 1,
    UNIQUE (factory_id, level)
);
-- ผู้รับของแต่ละระดับ: รายคน / ตามบทบาท (เฉพาะคนในโรงงานนั้น) / กลุ่มแชท
CREATE TABLE IF NOT EXISTS cs_esc_recipients (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    level_id   INTEGER NOT NULL REFERENCES cs_esc_levels(id) ON DELETE CASCADE,
    kind       TEXT NOT NULL,                    -- user | role | group
    user_id    INTEGER REFERENCES users(id),
    role       TEXT DEFAULT '',
    channel    TEXT DEFAULT '',                  -- group: telegram | line | teams | email
    target     TEXT DEFAULT '',                  -- group: chat id / group id / webhook / อีเมล
    label      TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_cser_level ON cs_esc_recipients(level_id);

-- กระดิ่งในระบบ (ต่อผู้ใช้)
CREATE TABLE IF NOT EXISTS cs_notifications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    kind        TEXT NOT NULL,                   -- alert | escalate | round_due | round_overdue | capa | summary
    severity    TEXT DEFAULT 'info',
    title       TEXT NOT NULL,
    body        TEXT DEFAULT '',
    url         TEXT DEFAULT '',
    ref_key     TEXT DEFAULT '',                 -- กันแจ้งซ้ำเรื่องเดิม
    created_at  TEXT NOT NULL,
    read_at     TEXT
);
CREATE INDEX IF NOT EXISTS idx_csn_user ON cs_notifications(user_id, read_at, id);
CREATE INDEX IF NOT EXISTS idx_csn_ref ON cs_notifications(user_id, ref_key);

-- คิวข้อความส่งออก (ส่งซ้ำอัตโนมัติเมื่อเครือข่ายหลุด)
CREATE TABLE IF NOT EXISTS cs_msg_outbox (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    channel     TEXT NOT NULL,                   -- telegram | line | teams | email
    target      TEXT NOT NULL,
    target_label TEXT DEFAULT '',
    subject     TEXT DEFAULT '',
    body        TEXT NOT NULL,
    url         TEXT DEFAULT '',
    alert_id    INTEGER REFERENCES cs_alerts(id),
    ref_key     TEXT DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'pending',  -- pending | sent | failed | skipped
    attempts    INTEGER NOT NULL DEFAULT 0,
    next_try_at TEXT NOT NULL,
    last_error  TEXT DEFAULT '',
    created_at  TEXT NOT NULL,
    sent_at     TEXT
);
CREATE INDEX IF NOT EXISTS idx_csmo_due ON cs_msg_outbox(status, next_try_at);

-- ช่วงเงียบ (เช่น ระหว่างซ่อมบำรุง): ยังบันทึกแจ้งเตือน แต่ไม่ส่งออกและไม่ส่งต่อ
CREATE TABLE IF NOT EXISTS cs_silences (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id   INTEGER REFERENCES factories(id),
    equipment_id INTEGER REFERENCES equipment(id),
    form_id      INTEGER REFERENCES cs_forms(id),
    starts_at    TEXT NOT NULL,
    ends_at      TEXT NOT NULL,
    reason       TEXT NOT NULL,
    created_by   INTEGER REFERENCES users(id),
    created_at   TEXT NOT NULL,
    cancelled_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_cssil_time ON cs_silences(ends_at, starts_at);

-- CAPA / งานแก้ไข
CREATE TABLE IF NOT EXISTS cs_actions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    code          TEXT UNIQUE,
    source        TEXT NOT NULL DEFAULT 'manual',  -- alert | ng | manual
    alert_id      INTEGER REFERENCES cs_alerts(id),
    submission_id INTEGER REFERENCES cs_submissions(id),
    item_key      TEXT DEFAULT '',
    form_id       INTEGER REFERENCES cs_forms(id),
    equipment_id  INTEGER REFERENCES equipment(id),
    factory_id    INTEGER REFERENCES factories(id),
    title         TEXT NOT NULL,
    description   TEXT DEFAULT '',
    action_type   TEXT NOT NULL DEFAULT 'corrective', -- corrective | preventive
    priority      TEXT NOT NULL DEFAULT 'normal',     -- low | normal | high | urgent
    owner_id      INTEGER REFERENCES users(id),
    due_date      TEXT,
    status        TEXT NOT NULL DEFAULT 'open',       -- open | in_progress | done | closed | cancelled
    root_cause    TEXT DEFAULT '',
    action_taken  TEXT DEFAULT '',
    verify_note   TEXT DEFAULT '',
    created_by    INTEGER REFERENCES users(id),
    done_at       TEXT,
    verified_by   INTEGER REFERENCES users(id),
    closed_at     TEXT,
    reminded_at   TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_csact_status ON cs_actions(status, due_date);
CREATE INDEX IF NOT EXISTS idx_csact_owner ON cs_actions(owner_id, status);
CREATE INDEX IF NOT EXISTS idx_csact_alert ON cs_actions(alert_id);
CREATE TABLE IF NOT EXISTS cs_action_photos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    action_id   INTEGER NOT NULL REFERENCES cs_actions(id),
    kind        TEXT NOT NULL DEFAULT 'before',       -- before | after
    file_path   TEXT NOT NULL,
    size_kb     INTEGER,
    created_by  INTEGER REFERENCES users(id),
    created_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cs_action_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    action_id   INTEGER NOT NULL REFERENCES cs_actions(id),
    event       TEXT NOT NULL,
    actor_id    INTEGER REFERENCES users(id),
    detail      TEXT DEFAULT '',
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_csacte_action ON cs_action_events(action_id);
CREATE INDEX IF NOT EXISTS idx_csal_notify ON cs_alerts(status, notified_level);
"""


# ───────── Phase 5: ตั้งเวลาส่งรายงาน / ดึงข้อมูลจากระบบภายนอก ─────────
DDL_P5 = """
CREATE TABLE IF NOT EXISTS cs_report_schedules (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    kind         TEXT NOT NULL DEFAULT 'daily',     -- daily | weekly | monthly
    daily_scope  TEXT NOT NULL DEFAULT 'yesterday', -- daily: today | yesterday
    factory_id   INTEGER REFERENCES factories(id),
    formats      TEXT NOT NULL DEFAULT 'pdf,xlsx',
    recipients   TEXT NOT NULL,
    send_time    TEXT NOT NULL DEFAULT '07:30',
    weekday      INTEGER NOT NULL DEFAULT 0,        -- weekly: 0=จันทร์
    month_day    INTEGER NOT NULL DEFAULT 1,        -- monthly: วันที่ส่ง (รายงานของเดือนก่อน)
    active       INTEGER NOT NULL DEFAULT 1,
    next_run_at  TEXT,
    last_run_at  TEXT,
    last_status  TEXT DEFAULT '',
    last_message TEXT DEFAULT '',
    created_by   INTEGER REFERENCES users(id),
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cs_report_runs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    schedule_id  INTEGER REFERENCES cs_report_schedules(id) ON DELETE SET NULL,
    name         TEXT DEFAULT '',
    started_at   TEXT NOT NULL,
    finished_at  TEXT,
    status       TEXT NOT NULL,                     -- sent | failed | partial
    message      TEXT DEFAULT '',
    recipients   TEXT DEFAULT '',
    files        TEXT DEFAULT '',
    size_kb      INTEGER DEFAULT 0,
    manual       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_csrr_sched ON cs_report_runs(schedule_id, id);

-- แหล่งข้อมูลภายนอก (SCADA SQL / CSV / REST) → ผลตรวจอัตโนมัติ
CREATE TABLE IF NOT EXISTS cs_sources (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    kind          TEXT NOT NULL,                    -- mssql | sqlite | csv | rest
    config_json   TEXT NOT NULL DEFAULT '{}',
    interval_min  INTEGER NOT NULL DEFAULT 15,
    bucket_min    INTEGER NOT NULL DEFAULT 60,      -- รวมค่าเป็นช่วงละกี่นาที (1 ผลตรวจต่อช่วงต่อแบบฟอร์ม)
    agg           TEXT NOT NULL DEFAULT 'last',     -- last | avg | min | max
    active        INTEGER NOT NULL DEFAULT 1,
    watermark     TEXT DEFAULT '',                  -- เวลาล่าสุดที่ดึงแล้ว
    next_run_at   TEXT,
    last_run_at   TEXT,
    last_status   TEXT DEFAULT '',
    last_message  TEXT DEFAULT '',
    created_by    INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cs_source_tags (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id   INTEGER NOT NULL REFERENCES cs_sources(id) ON DELETE CASCADE,
    tag         TEXT NOT NULL,
    form_id     INTEGER REFERENCES cs_forms(id),
    item_key    TEXT DEFAULT '',
    scale       REAL NOT NULL DEFAULT 1,
    add_offset  REAL NOT NULL DEFAULT 0,
    last_value  REAL,
    last_seen   TEXT,
    UNIQUE (source_id, tag)
);
CREATE TABLE IF NOT EXISTS cs_source_runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id   INTEGER NOT NULL REFERENCES cs_sources(id) ON DELETE CASCADE,
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    status      TEXT NOT NULL,                      -- ok | failed
    rows_read   INTEGER DEFAULT 0,
    submissions INTEGER DEFAULT 0,
    message     TEXT DEFAULT '',
    manual      INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_cssr_src ON cs_source_runs(source_id, id);
-- v0.11 ประวัติเครื่องหยุด/ซ่อม
CREATE TABLE IF NOT EXISTS cs_downtime (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    equipment_id INTEGER NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    start_at     TEXT NOT NULL,
    end_at       TEXT,
    reason       TEXT DEFAULT '',
    category     TEXT DEFAULT 'repair',
    expected_end TEXT,
    started_by   INTEGER,
    ended_by     INTEGER,
    end_note     TEXT DEFAULT '',
    skipped_rounds INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_csdt_eq ON cs_downtime(equipment_id, start_at);
-- v0.10 เส้นทางเดินตรวจ: เครื่อง/แบบฟอร์มหลายรายการเรียงตามทางเดิน
CREATE TABLE IF NOT EXISTS cs_routes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    description TEXT DEFAULT '',
    factory_id  INTEGER REFERENCES factories(id),
    active      INTEGER NOT NULL DEFAULT 1,
    created_by  INTEGER,
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cs_route_stops (
    route_id    INTEGER NOT NULL REFERENCES cs_routes(id) ON DELETE CASCADE,
    form_id     INTEGER NOT NULL REFERENCES cs_forms(id) ON DELETE CASCADE,
    order_no    INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (route_id, form_id)
);
CREATE INDEX IF NOT EXISTS idx_csrs_form ON cs_route_stops(form_id);
-- v0.10 แม่แบบ: เกณฑ์เฉพาะเครื่อง + รหัสหัวข้อเดิมของเครื่อง (ให้กราฟแนวโน้มต่อเนื่อง)
CREATE TABLE IF NOT EXISTS cs_template_overrides (
    form_id      INTEGER NOT NULL REFERENCES cs_forms(id) ON DELETE CASCADE,
    template_key TEXT NOT NULL,
    local_key    TEXT DEFAULT '',
    has_limits   INTEGER NOT NULL DEFAULT 0,
    min_value    REAL, max_value REAL, warn_low REAL, warn_high REAL,
    PRIMARY KEY (form_id, template_key)
);
CREATE TABLE IF NOT EXISTS cs_source_files (
    source_id   INTEGER NOT NULL REFERENCES cs_sources(id) ON DELETE CASCADE,
    file_key    TEXT NOT NULL,                      -- ชื่อไฟล์ + ขนาด + เวลาแก้ไข
    imported_at TEXT NOT NULL,
    PRIMARY KEY (source_id, file_key)
);
-- v0.44 การลงค่าจาก SCADA รายแบบฟอร์ม (ตามเวลารอบตรวจ / เวลาที่กำหนด / ทุกช่วงแบบเดิม)
CREATE TABLE IF NOT EXISTS cs_source_forms (
    source_id   INTEGER NOT NULL REFERENCES cs_sources(id) ON DELETE CASCADE,
    form_id     INTEGER NOT NULL REFERENCES cs_forms(id) ON DELETE CASCADE,
    mode        TEXT NOT NULL DEFAULT 'auto',       -- auto | round | times | bucket
    times       TEXT DEFAULT '',                    -- mode=times: 08:30,20:30
    pick        TEXT NOT NULL DEFAULT 'nearest',    -- nearest | before | after | avg | min | max
    window_min  INTEGER NOT NULL DEFAULT 30,
    updated_at  TEXT,
    PRIMARY KEY (source_id, form_id)
);
-- v0.44 ค่าดิบจาก SCADA ของ Tag ที่จับคู่แล้ว (นาทีละ 1 ค่า) — ใช้เลือกค่าตามเวลารอบตรวจ / ลงค่าใหม่ย้อนหลัง
CREATE TABLE IF NOT EXISTS cs_source_values (
    source_id   INTEGER NOT NULL,
    tag         TEXT NOT NULL,
    ts          TEXT NOT NULL,                      -- YYYY-MM-DD HH:MM (เวลาไทยหลังเลื่อนเวลาแล้ว)
    value       REAL NOT NULL,
    PRIMARY KEY (source_id, tag, ts)
);
-- v0.74 แก้ค่า / ยกเลิกค่าจาก SCADA รายช่องเวลา (มีผลทุกครั้งที่ลงค่า / ลงค่าใหม่ — ไม่หายเมื่อดึงซ้ำ)
CREATE TABLE IF NOT EXISTS cs_source_fixes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id   INTEGER NOT NULL,
    form_id     INTEGER NOT NULL,
    slot_at     TEXT NOT NULL,                      -- เวลาของช่อง YYYY-MM-DD HH:MM:SS
    item_key    TEXT NOT NULL DEFAULT '',           -- '' = ทั้งรอบ
    action      TEXT NOT NULL,                      -- void = ยกเลิกค่า | value = ใช้ค่าที่แก้
    value_num   REAL,
    old_value   REAL,
    reason      TEXT DEFAULT '',
    created_by  INTEGER,
    created_at  TEXT NOT NULL,
    UNIQUE (source_id, form_id, slot_at, item_key)
);
-- v0.41 ช่วงวันที่ที่ผู้ดูแลระบบลบออกจากสถิติตรวจตรงเวลา (ไม่สร้างรอบตรวจซ้ำในช่วงนี้ · ยกเลิกได้)
CREATE TABLE IF NOT EXISTS cs_stat_excl (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    day_from    TEXT NOT NULL,
    day_to      TEXT NOT NULL,
    factory_id  INTEGER,
    area_id     INTEGER,
    form_id     INTEGER,
    reason      TEXT DEFAULT '',
    rounds      INTEGER NOT NULL DEFAULT 0,
    created_by  INTEGER,
    created_at  TEXT NOT NULL
);
"""


DEFAULT_FACTORIES = (("F1", "Factory 1", 1), ("F2", "Factory 2", 2), ("F3", "Factory 3", 3))


# คอลัมน์ที่เพิ่มภายหลัง (ฐานข้อมูลเดิมจะถูกเติมให้อัตโนมัติ ไม่กระทบข้อมูล)
ADDED_COLUMNS = {
    "factories": [("layout_image", "TEXT DEFAULT ''")],
    "cs_routes": [("owner_id", "INTEGER")],                        # v0.30 เส้นทางส่วนตัวของช่าง (NULL = ใช้ร่วมกัน)          # ผังโรงงาน (ไฟล์ใน uploads)
    "areas": [("map_x", "REAL"), ("map_y", "REAL"), ("layout_image", "TEXT DEFAULT ''"), ("icon_image", "TEXT DEFAULT ''")],   # v0.11 ผังย่อยของพื้นที่              # ตำแหน่งหมุดบนผัง (% ของกว้าง/สูง)
    "users": [("restrict_view", "INTEGER DEFAULT 0"), ("line_user_id", "TEXT DEFAULT ''"), ("notify_channels", "TEXT DEFAULT 'app,telegram,line,email'"),
              ("theme", "TEXT DEFAULT ''"),
              ("can_delete_results", "INTEGER NOT NULL DEFAULT 0"),
              ("position", "TEXT DEFAULT ''"),
              ("can_approve", "INTEGER NOT NULL DEFAULT 0")],   # v0.14 สิทธิ์ลบผลตรวจ · v0.25 ตำแหน่ง · v0.26 สิทธิ์อนุมัติแบบกลุ่ม
    "cs_alerts": [("notified_level", "INTEGER NOT NULL DEFAULT 0"), ("last_notified_at", "TEXT"),
                  ("sla_notified_at", "TEXT"), ("assigned_to", "INTEGER"), ("resolved_by", "INTEGER"),
                  ("resolved_at", "TEXT"), ("closed_by", "INTEGER"), ("close_note", "TEXT DEFAULT ''")],
    "cs_rounds": [("due_notified_at", "TEXT"), ("overdue_notified_at", "TEXT"), ("start_notified_at", "TEXT")],
    # v0.9: ความถี่รายหัวข้อ ('' = ทุกรอบ | shift | day | times | week | month) + จุดตรวจ (ชื่อ/ตำแหน่ง/คำแนะนำ)
    "cs_form_items": [("check_freq", "TEXT DEFAULT ''"), ("check_times", "TEXT DEFAULT ''"),
                      ("photo_required", "INTEGER NOT NULL DEFAULT 0"),
                      ("formula", "TEXT DEFAULT ''")],                          # v0.95 สูตรของหัวข้อคำนวณ   # ต้องแนบรูปหลักฐานทุกครั้ง (ไม่ใช่เฉพาะ NG)
    "cs_form_versions": [("sections_json", "TEXT DEFAULT ''"),
                         # v0.10 ควบคุมเอกสาร (ISO): วันที่มีผล · ผู้อนุมัติ · เวอร์ชันแม่แบบที่คัดลอกมา
                         ("effective_date", "TEXT"), ("approved_by_name", "TEXT DEFAULT ''"),
                         ("template_version_id", "INTEGER")],
    # v0.10: เลขที่เอกสาร (FM-xx) · บังคับสแกน QR ที่จุดตรวจ · แม่แบบ (is_template=1) / ใช้แม่แบบ (template_id)
    "cs_forms": [("doc_no", "TEXT DEFAULT ''"), ("require_point_scan", "INTEGER NOT NULL DEFAULT 0"),
                 ("is_template", "INTEGER NOT NULL DEFAULT 0"), ("template_id", "INTEGER"),
                 ("sign_config", "TEXT DEFAULT ''"),              # v0.22 ช่องลงนามเพิ่มในใบบันทึก
                 ("doc_stamp", "TEXT DEFAULT ''")],               # v0.25 ตรามุมซ้ายบน: '' = PROTECTED · UTILITY (ค่าเริ่มต้น) · se
    "cs_submissions": [("point_scans", "TEXT DEFAULT ''"), ("route_id", "INTEGER")],
    "cs_sources": [("ts_shift_min", "INTEGER NOT NULL DEFAULT 0"), ("keep_days", "INTEGER NOT NULL DEFAULT 35"),   # v0.44
                   ("confirm_required", "INTEGER NOT NULL DEFAULT 1"), ("prefill", "INTEGER NOT NULL DEFAULT 1"),   # v0.45
                   ("late_min", "INTEGER NOT NULL DEFAULT 180"), ("catchup", "INTEGER NOT NULL DEFAULT 0"), ("last_heal_at", "TEXT"),   # v0.73
                   ("alert_state", "TEXT NOT NULL DEFAULT ''"), ("alert_since", "TEXT"),   # v0.75 เฝ้าแหล่งข้อมูล
                   ("compacted_until", "TEXT")],                     # v0.76 ย่อค่าดิบแล้วถึงวันที่
    "cs_source_tags": [("valid_min", "REAL"), ("valid_max", "REAL")],     # v0.77 ช่วงค่าที่เป็นไปได้ (หลังคูณ/บวก)
    "cs_answers": [("value_src", "TEXT DEFAULT ''")],     # v0.45 'scada' = ค่าที่เติมจาก SCADA แล้วช่างยืนยันโดยไม่แก้
    # v0.15 รอบตรวจที่สืบทอดจากแม่แบบ (id ของรอบตรวจในแม่แบบ)
    "cs_schedules": [("tpl_schedule_id", "INTEGER"), ("anchor_date", "TEXT DEFAULT ''")],   # v0.34 รอบตรวจทุก N วัน/สัปดาห์/เดือน
    # v0.11 สถานะเครื่องหยุด/ซ่อม (running | down) + ตำแหน่งหมุดบนผังย่อยของพื้นที่
    "equipment": [("run_status", "TEXT NOT NULL DEFAULT 'running'"), ("down_reason", "TEXT DEFAULT ''"),
                  ("down_since", "TEXT"), ("down_until", "TEXT"), ("down_by", "INTEGER"),
                  ("map_x", "REAL"), ("map_y", "REAL")],
}


def _migrate(db) -> None:
    for table, cols in ADDED_COLUMNS.items():
        have = {r[1] for r in db.execute(f"PRAGMA table_info({table})")}
        if not have:                                         # ตารางที่สร้างใน DDL ชุดหลัง — ทำรอบถัดไป
            continue
        for name, decl in cols:
            if name not in have:
                db.execute(f"ALTER TABLE {table} ADD COLUMN {name} {decl}")


def _sync_locations(db) -> None:
    """ตำแหน่งแบบฟอร์ม = ตำแหน่งเครื่องจักร (แหล่งข้อมูลเดียว) — ทำทุกครั้งที่เปิดระบบ รันซ้ำได้

    1) เครื่องที่ยังไม่มีพื้นที่ แต่แบบฟอร์มของเครื่องระบุพื้นที่ไว้ (เช่น ข้อมูลที่นำเข้า) → เครื่องได้พื้นที่นั้น
    2) แบบฟอร์มที่ผูกเครื่องจักร → ใช้โรงงาน/พื้นที่ของเครื่อง (เดิมเก็บแยกกัน ทำให้ย้ายพื้นที่เครื่องแล้วผังไม่เปลี่ยน)
    """
    db.execute("""UPDATE equipment SET
            area_id=(SELECT f.area_id FROM cs_forms f JOIN areas a ON a.id=f.area_id
                     WHERE f.equipment_id=equipment.id AND (equipment.factory_id IS NULL OR a.factory_id=equipment.factory_id)
                     ORDER BY f.updated_at DESC LIMIT 1),
            factory_id=COALESCE(factory_id, (SELECT a.factory_id FROM cs_forms f JOIN areas a ON a.id=f.area_id
                     WHERE f.equipment_id=equipment.id ORDER BY f.updated_at DESC LIMIT 1))
        WHERE area_id IS NULL AND EXISTS (SELECT 1 FROM cs_forms f JOIN areas a ON a.id=f.area_id
                     WHERE f.equipment_id=equipment.id AND (equipment.factory_id IS NULL OR a.factory_id=equipment.factory_id))""")
    db.execute("""UPDATE cs_forms SET
            factory_id=(SELECT e.factory_id FROM equipment e WHERE e.id=cs_forms.equipment_id),
            area_id=(SELECT e.area_id FROM equipment e WHERE e.id=cs_forms.equipment_id)
        WHERE equipment_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM equipment e WHERE e.id=cs_forms.equipment_id AND e.factory_id IS NOT NULL
              AND (IFNULL(cs_forms.factory_id, -1)<>e.factory_id OR IFNULL(cs_forms.area_id, -1)<>IFNULL(e.area_id, -1)))""")


def ensure_schema(db) -> None:
    """สร้างตารางทั้งหมด (เรียกซ้ำได้ ไม่กระทบข้อมูลเดิม) + โรงงานเริ่มต้น 3 แห่งเมื่อฐานข้อมูลว่าง"""
    db.executescript(DDL)
    _migrate(db)
    db.executescript(DDL_P4)
    db.executescript(DDL_P5)
    _migrate(db)                                       # คอลัมน์ของตารางใน DDL_P4/P5 (เช่น cs_routes.owner_id)
    db.execute("INSERT OR IGNORE INTO cs_meta(key, value) VALUES('schema_version', ?)", (str(SCHEMA_VERSION),))
    _sync_locations(db)
    from .cmms_wo import ensure as _ensure_cmms_wo
    _ensure_cmms_wo(db)                                # v0.16 ใบแจ้งซ่อม UT-CMMS จาก NG
    from .cmms_tpm import ensure as _ensure_cmms_tpm
    _ensure_cmms_tpm(db)                               # v0.17 เชื่อมแผน TPM ของ UT-CMMS
    from .cmms_status import ensure as _ensure_cmms_status
    _ensure_cmms_status(db)                            # v0.18 สถานะช่าง UT-CMMS
    from .roster import ensure as _ensure_roster
    _ensure_roster(db)                                 # v0.50 ตารางกะ + มอบหมายโรงงาน
    from .shiftsign import ensure as _ensure_shiftsign
    _ensure_shiftsign(db)                              # v0.54 ลงนามรับทราบ / ย้อนหลังในใบบันทึก
    from .backfill import ensure as _ensure_backfill
    _ensure_backfill(db)                               # v0.55 สิทธิ์ลงข้อมูลย้อนหลัง
    from .energy import ensure as _ensure_energy
    _ensure_energy(db)                                 # v0.62 Energy Data
    from .perms import ensure as _ensure_perms
    _ensure_perms(db)                                  # v0.52 สิทธิ์แก้ไขแบบฟอร์มรายคน
    from .handover import ensure as _ensure_handover
    _ensure_handover(db)                               # v0.51 ส่งกะ / รับกะ
    from .change_requests import ensure as _ensure_chreq
    _ensure_chreq(db)                                  # v0.28 คำขอแก้ไขแบบฟอร์ม · ประเภทหัวข้อที่เพิ่มเอง
    from .signoffs import ensure as _ensure_signoffs
    _ensure_signoffs(db)                               # v0.24 ลายเซ็นประจำตัว + ยืนยันหน่วยงานในระบบ
    if not db.execute("SELECT 1 FROM cs_meta WHERE key='v14_category'").fetchone():
        # v0.14: หมวดหมู่แบบฟอร์ม — ค่าเดิม 'utility' เป็นค่าเริ่มต้นที่ไม่เคยให้เลือก → ว่าง (= ใช้ประเภทเครื่องแทน)
        db.execute("UPDATE cs_forms SET category='' WHERE category='utility'")
        db.execute("INSERT INTO cs_meta(key, value) VALUES('v14_category', '1')")
    if not db.execute("SELECT 1 FROM cs_meta WHERE key='v19_approval_alerts'").fetchone():
        # v0.19: ผลตรวจที่รออนุมัติอยู่แล้ว (60 วันล่าสุด) → รายการ "รออนุมัติ" ในหน้าแจ้งเตือน
        from .anomaly import raise_approval
        for r in db.execute("""SELECT id FROM cs_submissions WHERE status='submitted' AND approval_status='pending'
                               AND finished_at >= datetime('now', '-60 days') ORDER BY id""").fetchall():
            raise_approval(db, r[0])
        db.execute("INSERT INTO cs_meta(key, value) VALUES('v19_approval_alerts', '1')")
    if not db.execute("SELECT 1 FROM cs_meta WHERE key='v83_confirm_mode'").fetchone():
        # v0.83: ค่าจาก SCADA ที่ปกติไม่ต้องรอยืนยัน — แหล่งที่ตั้ง "ยืนยันทุกรอบ" ไว้ → ยืนยันเฉพาะรอบที่มี NG/เตือน
        try:
            db.execute("UPDATE cs_sources SET confirm_required=2 WHERE confirm_required=1")
        except Exception:                               # noqa: BLE001 — ยังไม่มีตารางแหล่งข้อมูล
            pass
        db.execute("INSERT INTO cs_meta(key, value) VALUES('v83_confirm_mode', '1')")
    if db.execute("SELECT COUNT(*) FROM factories").fetchone()[0] == 0:
        db.executemany("INSERT INTO factories(code, name, sort_no) VALUES (?,?,?)", DEFAULT_FACTORIES)
    if db.execute("SELECT COUNT(*) FROM cs_esc_levels").fetchone()[0] == 0:
        # ค่าเริ่มต้น: L1 หัวหน้างานของโรงงานทันที, L2 ผู้ดูแลระบบหลัง 30 นาที, L3 (ว่าง) หลัง 120 นาที — แก้ได้ที่หน้าตั้งค่า
        for level, after, sev, role in ((1, 0, "warning", "supervisor"), (2, 30, "warning", "admin"), (3, 120, "critical", "")):
            lid = db.execute("INSERT INTO cs_esc_levels(factory_id, level, after_min, min_severity) VALUES (NULL,?,?,?)",
                             (level, after, sev)).lastrowid
            if role:
                db.execute("INSERT INTO cs_esc_recipients(level_id, kind, role) VALUES (?, 'role', ?)", (lid, role))
    db.commit()
