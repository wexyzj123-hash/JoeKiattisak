"""v0.99: เมนูซ้ายแบบกลุ่มพับได้ · ภาพรวมมีแถบข้ามส่วน · มือถือมีแถบล่าง
หัวใจของชุดนี้คือ "ลิงก์เมนูเดิมต้องไม่หายแม้แต่ข้อเดียว" — รายการด้านล่างบันทึกจากเมนูเดิม (ก่อน v0.99) ของทุกบทบาท"""
import re

import pytest

from conftest import login

# ลิงก์ในแถบเมนูซ้ายของเวอร์ชันก่อน v0.99 (รวมตัวสลับระบบ "/" "/energy/" และ "/m/")
EXPECTED = {
 "admin_echeck": [
  "/analytics/inspection-time",   # v0.99.32 ทุกบทบาท
  "/",
  "/actions",
  "/admin/anomaly-rules",
  "/admin/assign",
  "/admin/cmms-status",
  "/admin/cmms-tpm",
  "/admin/cmms-wo",
  "/admin/health",
  "/admin/notify",
  "/admin/permissions",
  "/admin/report-schedules",
  "/admin/roster",
  "/admin/silences",
  "/admin/sources",
  "/admin/users",
  "/alerts",
  "/approvals",
  "/backfill/pick",
  "/dashboard",
  "/energy/",
  "/equipment",
  "/equipment/down",
  "/forms",
  "/forms/change-requests",
  "/forms/item-types",
  "/handover",
  "/m/",
  "/machines",
  "/reports",
  "/reports/layout",
  "/rounds",
  "/routes",
  "/signoffs?mine=0",
  "/submissions",
  "/team/backfill",
  "/team/scorecard",
  "/today",
  "/trends"
 ],
 "admin_energy": [
  "/",
  "/energy/",
  "/energy/anomalies",
  "/energy/cost/",
  "/energy/daily",
  "/energy/entry",
  "/energy/import",
  "/energy/live/", "/energy/compare",
  "/energy/manage",
  "/energy/meters",
  "/energy/power",
  "/energy/settings",
  "/energy/sheet",
  "/energy/summary",
  "/m/"
 ],
 "sup_echeck": [
  "/analytics/inspection-time",   # v0.99.32 ทุกบทบาท
  "/",
  "/actions",
  "/admin/assign",
  "/admin/roster",
  "/admin/silences",
  "/alerts",
  "/approvals",
  "/backfill/pick",
  "/dashboard",
  "/energy/",
  "/equipment",
  "/equipment/down",
  "/forms",
  "/forms/change-requests",
  "/forms/item-types",
  "/handover",
  "/m/",
  "/machines",
  "/reports",
  "/rounds",
  "/routes",
  "/submissions",
  "/team/backfill",
  "/team/scorecard",
  "/today",
  "/trends"
 ],
 "sup_energy": [
  "/",
  "/energy/",
  "/energy/anomalies",
  "/energy/cost/",
  "/energy/daily",
  "/energy/entry",
  "/energy/import",
  "/energy/live/", "/energy/compare",
  "/energy/manage",
  "/energy/meters",
  "/energy/power",
  "/energy/settings",
  "/energy/sheet",
  "/energy/summary",
  "/m/"
 ],
 "tech_echeck": [
  "/analytics/inspection-time",   # v0.99.32 ทุกบทบาท
  "/",
  "/actions",
  "/alerts",
  "/backfill/pick",
  "/dashboard",
  "/energy/",
  "/equipment",
  "/equipment/down",
  "/forms",
  "/m/",
  "/machines",
  "/reports",
  "/rounds",
  "/submissions",
  "/trends"
 ],
 "tech_energy": [
  "/",
  "/energy/",
  "/energy/anomalies",
  "/energy/cost/",
  "/energy/daily",
  "/energy/entry",
  "/energy/import",
  "/energy/live/", "/energy/compare",
  "/energy/manage",
  "/energy/meters",
  "/energy/power",
  "/energy/sheet",
  "/energy/summary",
  "/m/"
 ],
 "view_echeck": [
  "/analytics/inspection-time",   # v0.99.32 ทุกบทบาท
  "/",
  "/actions",
  "/alerts",
  "/dashboard",
  "/energy/",
  "/equipment",
  "/equipment/down",
  "/forms",
  "/machines",
  "/reports",
  "/rounds",
  "/submissions",
  "/trends"
 ],
 "view_energy": [
  "/",
  "/energy/",
  "/energy/anomalies",
  "/energy/cost/",
  "/energy/daily",
  "/energy/live/", "/energy/compare",
  "/energy/manage",
  "/energy/meters",
  "/energy/power",
  "/energy/sheet",
  "/energy/summary"
 ]
}


def _aside(html):
    m = re.search(r'<aside class="sidenav".*?</aside>', html, re.S)
    assert m, "ไม่พบแถบเมนูซ้าย"
    return m.group(0)


def _hrefs(aside):
    return set(re.findall(r'<a [^>]*href="([^"]+)"', aside))


@pytest.mark.parametrize("user,key", [("t_admin", "admin"), ("t_sup", "sup"), ("t_tech", "tech"), ("t_view", "view")])
def test_every_old_menu_link_still_exists(client, user, key):
    login(client, user)
    for mode, start in (("echeck", "/dashboard"), ("energy", "/energy/")):
        res = client.get(start, follow_redirects=True)
        assert res.status_code == 200
        got = _hrefs(_aside(res.get_data(as_text=True)))
        want = set(EXPECTED[f"{key}_{mode}"])
        assert want <= got, f"{user}/{mode} เมนูหาย: {sorted(want - got)}"
        extra = got - want
        assert not extra, f"{user}/{mode} มีเมนูเกินสิทธิ์: {sorted(extra)}"


def test_groups_and_pin(client):
    login(client, "t_admin")
    a = _aside(client.get("/dashboard").get_data(as_text=True))
    assert a.count('class="sn-grp"') == 6
    assert a.count("sn-pin") >= 1 and ">ภาพรวม<" in a
    for key in ("daily", "insight", "machine", "forms", "team", "setup"):
        assert f'data-grp="{key}"' in a
    assert 'id="snFind"' in a and "sn-ic" not in a


def test_active_group_opens_itself(client):
    login(client, "t_admin")
    a = _aside(client.get("/admin/users").get_data(as_text=True))
    m = re.search(r'<details class="sn-grp" data-grp="setup"([^>]*)>', a)
    assert m and " open" in m.group(1)
    m = re.search(r'<details class="sn-grp" data-grp="daily"([^>]*)>', a)
    assert m and " open" not in m.group(1)
    assert 'class="sn-link active"' in a and 'aria-current="page"' in a


def test_viewer_sees_no_admin_groups(client):
    login(client, "t_view")
    a = _aside(client.get("/dashboard").get_data(as_text=True))
    assert 'data-grp="setup"' not in a and 'data-grp="team"' not in a
    assert "/backfill/pick" not in a        # เดิมโชว์ทั้งที่เปิดไม่ได้ (403)


def test_overview_tabs_and_period(client):
    login(client, "t_sup")
    html = client.get("/dashboard?days=30").get_data(as_text=True)
    for k in ("ov-today", "ov-deep", "ov-hist", "ov-docs"):
        assert f'id="{k}"' in html and f'href="#{k}"' in html
    assert re.search(r'class="on">30 วัน<', html) and html.count('วิเคราะห์ย้อนหลัง') >= 1


def test_mobile_home_keeps_all_links(client):
    login(client, "t_tech")
    html = client.get("/m/").get_data(as_text=True)
    assert html.count('class="m-bnav"') == 1 and html.count("m-bnav") >= 1
    extra = re.search(r'<details class="m-extra".*?</details>', html, re.S).group(0)
    for path in ("/actions", "/notifications", "/dashboard", "/trends", "/machines", "/reports", "/submissions?mine=1", "/m/plan",
                 "/backfill/pick", "/m/me", "/m/requests", "/account/signature", "/account/notify", "/account/password", "/logout"):
        assert path in extra, path
    assert "/m/scan?report=1" in html and "/m/scan" in html
    assert 'id="tasks"' in html and 'id="todoCount"' in html       # home.js ยังหาองค์ประกอบเจอ


def test_mobile_fill_has_no_bottom_nav(client):
    login(client, "t_tech")
    assert "m-bnav" not in client.get("/m/fill").get_data(as_text=True)
