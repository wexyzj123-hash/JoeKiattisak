"""ecs/energy_src.py — v0.72 แหล่งข้อมูล SCADA ของ Energy Data (แยกจาก E-Check)

แยกชุดตารางเอง: en_sources · en_source_tags · en_source_runs · en_source_files
- ใช้ตัวอ่านข้อมูลชุดเดียวกับ E-Check (SQL Server / SQLite / CSV / REST → tag, เวลา, ค่า) แต่การตั้งค่า การจับคู่ Tag และประวัติแยกกัน
- Tag ↔ มิเตอร์: มิเตอร์เก็บ scada_source_id + scada_tag (จุดเดียวที่ใช้ดึงค่า) · en_source_tags เก็บตัวคูณ/ค่าบวก และค่าล่าสุดที่เห็น
- ดึงข้อมูล → ค่าอ่านรายวัน (en_readings, src='scada') ณ เวลาอ่านที่ตั้งไว้ ± ช่วงที่ยอมให้ · ไม่ทับค่าที่ช่างแก้ไว้
- ทดสอบ = ดึงแล้วไม่บันทึกค่าอ่าน (บันทึกเฉพาะรายชื่อ Tag ที่พบ เพื่อให้จับคู่ได้ทันที) แสดงค่าที่จะลงให้มิเตอร์ที่จับคู่แล้ว
"""
from __future__ import annotations

import difflib
import io
import itertools
import json
import logging
import re
import sqlite3
from collections import defaultdict
from datetime import datetime, timedelta

from . import connectors as CN
from . import services as S
from .services import ValidationError, parse_ts, ts

log = logging.getLogger(__name__)

DDL = """
CREATE TABLE IF NOT EXISTS en_sources (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    kind          TEXT NOT NULL,
    config_json   TEXT NOT NULL DEFAULT '{}',
    interval_min  INTEGER NOT NULL DEFAULT 15,
    ts_shift_min  INTEGER NOT NULL DEFAULT 0,
    active        INTEGER NOT NULL DEFAULT 1,
    watermark     TEXT DEFAULT '',
    next_run_at   TEXT,
    last_run_at   TEXT,
    last_status   TEXT DEFAULT '',
    last_message  TEXT DEFAULT '',
    note          TEXT DEFAULT '',
    created_by    INTEGER,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS en_source_tags (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id   INTEGER NOT NULL,
    tag         TEXT NOT NULL,
    scale       REAL NOT NULL DEFAULT 1,
    add_offset  REAL NOT NULL DEFAULT 0,
    last_value  REAL,
    last_seen   TEXT,
    UNIQUE (source_id, tag)
);
CREATE TABLE IF NOT EXISTS en_source_runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id   INTEGER NOT NULL,
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    status      TEXT NOT NULL DEFAULT 'ok',
    rows_read   INTEGER NOT NULL DEFAULT 0,
    readings    INTEGER NOT NULL DEFAULT 0,
    message     TEXT DEFAULT '',
    manual      INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_en_src_runs ON en_source_runs(source_id, id);
CREATE TABLE IF NOT EXISTS en_sync_tries (
    source_id   INTEGER NOT NULL,
    day         TEXT NOT NULL,
    tried_at    TEXT NOT NULL,
    PRIMARY KEY (source_id, day)
);
CREATE TABLE IF NOT EXISTS en_source_files (
    source_id   INTEGER NOT NULL,
    file_key    TEXT NOT NULL,
    imported_at TEXT NOT NULL,
    PRIMARY KEY (source_id, file_key)
);
"""

KIND_TH = CN.KIND_TH
DEFAULT_CONFIG = CN.DEFAULT_CONFIG
FUTURE_TOL_MIN = 15     # v0.99.40 ข้อมูลที่เวลาเกินปัจจุบันเกินกี่นาที = ผิดปกติ (นาฬิกา SCADA / เลื่อนเวลา) — ไม่ใช้เลื่อนจุดดึง


def param_shift(source: dict) -> timedelta:
    """v0.99.40 ชดเชยเวลาที่ส่งเข้าเงื่อนไข SQL (?) — คอลัมน์ DATETIMEOFFSET / UTC เทียบเวลาเป็น UTC แต่คืนค่าเป็นเวลาท้องถิ่น
    ทำให้ WHERE [DateTime] > ? ได้ข้อมูลช้ากว่าจริง (หรือไม่ได้เลย) · ค่าบวก = ส่งเวลาให้ SQL ย้อนไปเท่านี้นาที (ระบบกรองช่วงเวลาจริงเองอีกชั้น)"""
    try:
        return timedelta(minutes=int(float((source.get("config") or {}).get("param_shift_min") or 0)))
    except (TypeError, ValueError):
        return timedelta(0)


def valid_watermark(source: dict, now: datetime) -> datetime | None:
    """จุดดึงล่าสุด — ถ้าเลยเวลาปัจจุบัน (เคยรับข้อมูลเวลาในอนาคต) ถือว่าใช้ไม่ได้"""
    wm = parse_ts(source.get("watermark")) if source.get("watermark") else None
    return wm if wm and wm <= now + timedelta(minutes=FUTURE_TOL_MIN) else None


def ensure_src(db) -> None:
    """สร้างตาราง · ครั้งแรก: ย้ายแหล่งข้อมูลที่มิเตอร์ Energy เคยอ้างจาก E-Check มาเป็นของ Energy (คง id เดิม มิเตอร์ไม่ต้องผูกใหม่)"""
    fresh = not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='en_sources'").fetchone()
    db.executescript(DDL)
    tcols = {r[1] for r in db.execute("PRAGMA table_info(en_source_tags)")}
    for col in ("valid_min", "valid_max"):                                   # v0.77 ช่วงค่าที่เป็นไปได้
        if col not in tcols:
            db.execute(f"ALTER TABLE en_source_tags ADD COLUMN {col} REAL")
    have = {r[1] for r in db.execute("PRAGMA table_info(en_sources)")}
    for col, typ in (("late_min", f"INTEGER NOT NULL DEFAULT {CN.LATE_MIN_DEFAULT}"), ("catchup", "INTEGER NOT NULL DEFAULT 0"),
                     ("last_heal_at", "TEXT"), ("alert_state", "TEXT NOT NULL DEFAULT ''"), ("alert_since", "TEXT")):   # v0.73/v0.75
        if col not in have:
            db.execute(f"ALTER TABLE en_sources ADD COLUMN {col} {typ}")
    from . import energy_interval as EI                                        # v0.87 ค่าต่อช่วงเวลา
    EI.ensure(db)
    if not fresh:
        return
    try:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='cs_sources'").fetchone():
            return
        ids = [r[0] for r in db.execute("""SELECT DISTINCT scada_source_id FROM en_meters WHERE scada_source_id IS NOT NULL""")]
        for sid in ids:
            r = db.execute("SELECT * FROM cs_sources WHERE id=?", (sid,)).fetchone()
            if not r:
                continue
            db.execute("""INSERT INTO en_sources(id, name, kind, config_json, interval_min, ts_shift_min, active, watermark, next_run_at,
                          created_at, updated_at, note) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                       (r["id"], r["name"], r["kind"], r["config_json"], r["interval_min"], r["ts_shift_min"] or 0, r["active"],
                        r["watermark"] or "", r["next_run_at"], r["created_at"], ts(S.now_dt()), "ย้ายมาจาก E-Check"))
            for t in db.execute("SELECT tag, last_value, last_seen FROM cs_source_tags WHERE source_id=?", (sid,)):
                db.execute("INSERT OR IGNORE INTO en_source_tags(source_id, tag, last_value, last_seen) VALUES (?,?,?,?)",
                           (sid, t[0], t[1], t[2]))
    except sqlite3.Error:
        log.exception("migrate energy sources failed")


# ───────────────────────── แหล่งข้อมูล ─────────────────────────

def get_source(db, sid: int) -> dict | None:
    r = db.execute("SELECT * FROM en_sources WHERE id=?", (sid,)).fetchone()
    if not r:
        return None
    d = dict(r)
    try:
        d["config"] = json.loads(d["config_json"] or "{}")
    except ValueError:
        d["config"] = {}
    return d


def list_sources(db) -> list[dict]:
    rows = db.execute("""SELECT s.*, (SELECT COUNT(*) FROM en_source_tags t WHERE t.source_id=s.id) AS tags,
                                (SELECT COUNT(*) FROM en_meters m WHERE m.scada_source_id=s.id AND m.scada_tag<>'') AS mapped
                         FROM en_sources s ORDER BY s.active DESC, s.name""").fetchall()
    return [dict(r) for r in rows]


def save_source(db, data: dict, actor, sid: int | None = None) -> int:
    errors = []
    name = str(data.get("name") or "").strip()[:120]
    kind = data.get("kind")
    if not name:
        errors.append("กรุณาตั้งชื่อแหล่งข้อมูล")
    if kind not in KIND_TH:
        errors.append("ชนิดแหล่งข้อมูลไม่ถูกต้อง")
        kind = "csv"
    try:
        interval = int(data.get("interval_min") or 15)
        shift = int(float(data.get("ts_shift_min") or 0))
        if not (1 <= interval <= 1440 and -1440 <= shift <= 1440):
            raise ValueError
    except (TypeError, ValueError):
        errors.append("รอบดึงข้อมูล 1–1440 นาที และเลื่อนเวลา −1440 ถึง 1440 นาที")
        interval, shift = 15, 0
    try:
        late = int(float(data.get("late_min") if data.get("late_min") not in (None, "") else CN.LATE_MIN_DEFAULT))
        if not 0 <= late <= 1440:
            raise ValueError
    except (TypeError, ValueError):
        errors.append("ดึงทับย้อนหลัง 0–1440 นาที")
        late = CN.LATE_MIN_DEFAULT
    cfg = dict(DEFAULT_CONFIG[kind])
    raw_cfg = data.get("config")
    if isinstance(raw_cfg, str):
        try:
            raw_cfg = json.loads(raw_cfg or "{}")
        except ValueError:
            errors.append("การตั้งค่าไม่ใช่ JSON ที่ถูกต้อง")
            raw_cfg = {}
    for k, v in (raw_cfg or {}).items():
        if k in cfg:
            cfg[k] = v
    old_src = get_source(db, sid) if sid else None
    ps = data.get("param_shift_min")                    # v0.99.40 ชดเชยเวลาในเงื่อนไข SQL
    if ps in (None, "") and old_src:
        ps = (old_src.get("config") or {}).get("param_shift_min")
    try:
        ps = int(float(ps or 0))
        if not -1440 <= ps <= 1440:
            raise ValueError
    except (TypeError, ValueError):
        errors.append("ชดเชยเวลาในเงื่อนไข SQL −1440 ถึง 1440 นาที")
        ps = 0
    if ps:
        cfg["param_shift_min"] = ps
    if sid and kind == "mssql":                       # ช่องรหัสผ่านที่แสดงแบบซ่อน → คงค่าเดิม
        old = get_source(db, sid)
        if old and "••••" in str(cfg.get("conn", "")):
            cfg["conn"] = old["config"].get("conn", "")
    if kind in ("mssql", "sqlite"):
        try:
            CN._check_select(cfg.get("query", ""))            # noqa: SLF001
            CN.parse_quality(cfg.get("good_quality"))
        except CN.SourceError as exc:
            errors.append(str(exc))
    if kind == "rest" and not re.match(r"^https?://", str(cfg.get("url") or "")):
        errors.append("URL ต้องขึ้นต้นด้วย http:// หรือ https://")
    if kind == "rest" and not isinstance(cfg.get("headers"), dict):
        errors.append("headers ต้องเป็น JSON object")
    if errors:
        raise ValidationError(errors)
    now = S.now_dt()
    from . import energy_interval as EI
    EI.ensure(db)
    vk = data.get("value_kind") if data.get("value_kind") in EI.VALUE_KINDS else None
    row = {"name": name, "kind": kind, "config_json": json.dumps(cfg, ensure_ascii=False), "interval_min": interval, "ts_shift_min": shift, "late_min": late,
           "active": 1 if str(data.get("active", "1")) in ("1", "True", "on") else 0, "note": str(data.get("note") or "")[:300],
           "updated_at": ts(now)}
    if vk:
        row["value_kind"] = vk
    if sid:
        old = get_source(db, sid)
        if old and old.get("watermark") and int(old.get("ts_shift_min") or 0) != shift:   # v0.76 คงจุดที่ดึงถึงตามเวลาของแหล่ง
            row["watermark"] = ts(parse_ts(old["watermark"]) + timedelta(minutes=shift - int(old.get("ts_shift_min") or 0)))
        db.execute(f"UPDATE en_sources SET {', '.join(f'{k}=?' for k in row)} WHERE id=?", (*row.values(), sid))
        S.audit(db, actor, "update", "en_sources", sid, after={**row, "config_json": CN.mask_secret(row["config_json"])})
        return sid
    row.update(created_by=actor, created_at=ts(now), next_run_at=ts(now))
    sid = db.execute(f"INSERT INTO en_sources({', '.join(row)}) VALUES ({', '.join('?' * len(row))})", tuple(row.values())).lastrowid
    S.audit(db, actor, "create", "en_sources", sid, after={"name": name, "kind": kind})
    return sid


def delete_source(db, sid: int, actor) -> int:
    n = db.execute("UPDATE en_meters SET scada_source_id=NULL, scada_tag='' WHERE scada_source_id=?", (sid,)).rowcount
    for t in ("en_source_tags", "en_source_runs", "en_source_files"):
        db.execute(f"DELETE FROM {t} WHERE source_id=?", (sid,))
    db.execute("DELETE FROM en_sources WHERE id=?", (sid,))
    S.audit(db, actor, "delete", "en_sources", sid, after={"unlinked_meters": n})
    return n


# ───────────────────────── ดึงข้อมูล ─────────────────────────

def mapped_tags(db, sid: int) -> list[str]:
    from .energy_power import source_param_tags
    tags = [r[0] for r in db.execute("""SELECT DISTINCT TRIM(scada_tag) FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>''
                                        AND active=1 ORDER BY 1""", (sid,))]
    return sorted(set(tags) | set(source_param_tags(db, sid)))           # v0.91 + Tag PF/kW/kVAR


def fetch(db, source: dict, now: datetime | None = None, force_files: bool = False, tags: list[str] | None = None,
          since: datetime | None = None, until: datetime | None = None):
    """ดึงข้อมูล (แบบเดียวกับ E-Check): ต่อจากจุดเดิม ย้อนทับ late_min นาที · ดึงเฉพาะ Tag ที่จับคู่ · ตั้ง source['_truncated']"""
    now = now or S.now_dt()
    cfg = source["config"]
    if since is None:
        late = timedelta(minutes=int(source.get("late_min") if source.get("late_min") is not None else CN.LATE_MIN_DEFAULT))
        wm = valid_watermark(source, now)
        if wm:
            since = wm if int(source.get("catchup") or 0) else wm - late
        elif source.get("watermark"):                     # v0.99.40 จุดดึงเลยเวลาปัจจุบัน → ดึงช่วงล่าสุดใหม่
            since = now - max(late, timedelta(hours=6))
        else:
            since = now - timedelta(days=float(cfg.get("backfill_days") or 1))
    shift = timedelta(minutes=int(source.get("ts_shift_min") or 0))
    pshift = param_shift(source)
    if source["kind"] != "csv":                           # v0.99.40 ช่วงที่ชุดนี้ครอบคลุม → scada_pick ไม่เลือกค่าจากช่วงที่ดึงมาไม่ครบ
        source["_since"], source["_until"] = since, until
    keys: list[str] = []
    if source["kind"] in ("mssql", "sqlite"):
        # ชดเชยเวลาในเงื่อนไข: ส่งช่วงที่ "กว้างกว่า" ให้ SQL (ครอบทั้งกรณีเทียบเป็นเวลาไทยและเป็น UTC) แล้วกรองช่วงจริงเองด้านล่าง
        z = timedelta(0)
        raw = CN.fetch_sql(source["kind"], cfg, since - shift - max(pshift, z), tags=tags,
                           until=(until - shift - min(pshift, z)) if until else None)
    elif source["kind"] == "csv":
        raw, keys = CN.fetch_csv_folder(db, source["id"], cfg, force=force_files, table="en_source_files")
    else:
        raw = CN.fetch_rest(cfg, since - shift - max(pshift, timedelta(0)))
    source["_truncated"] = bool(getattr(raw, "truncated", False))
    source["_bad_quality"] = int(getattr(raw, "bad_quality", 0) or 0)
    rows, bad = CN.normalize(raw, cfg.get("ts_format", "") if source["kind"] == "csv" else "")
    if shift:
        rows = [(t, d + shift, v) for t, d, v in rows]
    if source["kind"] != "csv":
        rows = [r for r in rows if r[1] > since and (until is None or r[1] <= until)]
    if tags:
        want = set(tags)
        rows = [r for r in rows if r[0] in want]
    return rows, keys, bad


FETCH_ALL_PAGES = 400                 # v0.99.42 ช่วงเวลาเดียวที่แถวเกินเพดาน → อ่านต่อเป็นชุดจนครบ (สูงสุดกี่ชุด)
FETCH_TAG_CHUNK = 200                 # Tag ต่อคำสั่ง SQL (คำสั่งสั้น · แต่ละชุดไม่ติดเพดานเร็ว)


def fetch_all(db, source: dict, now: datetime | None, tags: list[str] | None, since: datetime, until: datetime | None):
    """v0.99.42 ดึงช่วงเวลา [since, until] ให้ครบทุกแถว — ถึงเพดานแถว (MAX_ROWS) → อ่านต่อจากเวลาสุดท้ายที่ได้ (ทับ 1 วินาที กันแถวเวลาเดียวกันหาย)
    แบ่ง Tag เป็นชุด · เดิม: ฟังก์ชันเติมค่ารายวัน / ประมาณค่า / ค่าราย 15 นาที / ค่าต่อช่วง อ่านชุดแรกชุดเดียว แถวที่เกินเพดานหายเงียบ"""
    out: list = []
    bad_all = 0
    chunks = [sorted(tags)[i:i + FETCH_TAG_CHUNK] for i in range(0, len(tags), FETCH_TAG_CHUNK)] if tags else [None]
    for ch in chunks:
        s_ = since
        for _ in range(FETCH_ALL_PAGES):
            fsrc = dict(source)
            rows, _k, bad = fetch(db, fsrc, now, tags=ch, since=s_, until=until)
            out += rows
            bad_all += bad
            if not fsrc.get("_truncated") or not rows:
                break
            last = max(r[1] for r in rows)
            nxt = last - timedelta(seconds=1)
            if nxt <= s_:                                 # แถวเวลาเดียวกันเกินเพดานทั้งชุด → ข้ามไปวินาทีถัดไป (ไม่วนไม่จบ)
                nxt = last
            if until is not None and nxt >= until:
                break
            s_ = nxt
    if source.get("kind") != "csv":
        source["_since"], source["_until"] = since, until
    source["_truncated"] = False
    seen: set = set()
    uniq = []
    for r in out:                                         # ชุดที่ทับกัน 1 วินาที → ตัดแถวซ้ำ
        k = (r[0], r[1])
        if k not in seen:
            seen.add(k)
            uniq.append(r)
    uniq.sort(key=lambda r: r[1])
    return uniq, [], bad_all


def _remember_tags(db, sid: int, rows) -> int:
    last: dict[str, tuple[datetime, float]] = {}
    for tag, dt, val in rows:
        last[tag] = (dt, val)
    for tag, (dt, val) in last.items():
        db.execute("""INSERT INTO en_source_tags(source_id, tag, last_value, last_seen) VALUES (?,?,?,?)
                      ON CONFLICT(source_id, tag) DO UPDATE SET last_value=excluded.last_value, last_seen=excluded.last_seen""",
                   (sid, tag, val, ts(dt)))
    return len(last)


def ingest(db, source: dict, rows, now: datetime | None = None, truncated: bool = False) -> dict:
    from . import energy_interval as EI
    from .energy_field import scada_ingest
    lim = (now or S.now_dt()) + timedelta(minutes=FUTURE_TOL_MIN)     # v0.99.40 ข้อมูลเวลาในอนาคต: ไม่ลงค่า ไม่เลื่อนจุดดึง
    future = [r for r in rows if r[1] > lim]
    if future:
        rows = [r for r in rows if r[1] <= lim]
    tags = _remember_tags(db, source["id"], rows)
    try:                                                  # v0.91 PF / kW / kVAR ของมิเตอร์
        from .energy_power import store_params
        store_params(db, source, rows)
    except Exception:                                     # noqa: BLE001
        log.exception("energy params store failed")
    if EI.is_interval(source):                            # v0.87 ค่าใช้ต่อช่วงเวลา → เก็บรายช่วง + สร้างค่าอ่านรายวันเอง
        n = EI.ingest(db, source, rows, now)
    else:
        try:                                              # v0.99.41 เก็บเลขสะสมทุกค่า (ราย 15 นาที) → วันนี้ / ชั่วโมงนี้ / กราฟรายช่วงเวลา
            from . import energy_profile as PR
            PR.store(db, source, rows, now)
        except Exception:
            log.exception("energy profile store failed")
        try:                                              # v0.77 แจ้งค่านอกช่วงที่เป็นไปได้
            from .srcmap import check_ranges
            check_ranges(db, source, rows, now, kind="energy")
        except Exception:                                 # noqa: BLE001
            log.exception("energy range check failed")
        n = scada_ingest(db, source, rows)
    if rows:
        newest = rows[-1][1]
        old = parse_ts(source["watermark"]) if source.get("watermark") else None
        if old and old > lim:                             # จุดดึงเดิมเลยปัจจุบัน → ลดกลับมาที่ข้อมูลจริงได้
            old = None
        wm = newest
        if truncated:
            wm2 = newest - timedelta(seconds=1)
            wm = wm2 if (not old or wm2 > old) else newest
        if not old or wm > old:
            db.execute("UPDATE en_sources SET watermark=? WHERE id=?", (ts(wm), source["id"]))
    return {"rows": len(rows), "readings": n, "tags_seen": tags, "future": len(future),
            "future_max": max(r[1] for r in future) if future else None}


def run_source(db, sid: int, manual: bool = False, now: datetime | None = None, rows_override=None, label: str = "") -> dict:
    src = get_source(db, sid)
    if not src:
        return {"ok": False, "message": "ไม่พบแหล่งข้อมูล"}
    now = now or S.now_dt()
    started = ts(now)
    bad, keys, truncated, healed = 0, [], False, 0
    fut, fut_max, reset_note = 0, None, ""
    if src.get("watermark") and not valid_watermark(src, now):          # v0.99.40 จุดดึงเลยเวลาปัจจุบัน → รีเซ็ตเอง
        late = int(src.get("late_min") if src.get("late_min") is not None else CN.LATE_MIN_DEFAULT)
        new_wm = now - timedelta(minutes=max(late, 360))
        reset_note = f"รีเซ็ตจุดดึงที่เลยเวลาปัจจุบัน ({src['watermark'][8:10]}/{src['watermark'][5:7]} {src['watermark'][11:16]}) "
        db.execute("UPDATE en_sources SET watermark=? WHERE id=?", (ts(new_wm), sid))
        src = get_source(db, sid)
    try:
        if rows_override is not None:
            rows, bad = CN.normalize(rows_override, src["config"].get("ts_format", ""))
            if int(src.get("ts_shift_min") or 0):
                rows = [(t, d + timedelta(minutes=int(src["ts_shift_min"])), v) for t, d, v in rows]
            res = ingest(db, src, rows, now)
            fut, fut_max = res.get("future", 0), res.get("future_max")
        else:
            tags = mapped_tags(db, sid) or None
            res = {"rows": 0, "readings": 0, "tags_seen": 0}
            for _page in range(CN.MAX_PAGES):
                old_wm = valid_watermark(src, now)
                rows, k, b = fetch(db, src, now, tags=tags)
                keys += k
                bad += b
                truncated = bool(src.get("_truncated"))
                r = ingest(db, src, rows, now, truncated=truncated)
                fut += r.get("future", 0)
                if r.get("future_max") and (not fut_max or r["future_max"] > fut_max):
                    fut_max = r["future_max"]
                res = {"rows": res["rows"] + sum(1 for x in rows if (not old_wm or x[1] > old_wm) and x[1] <= now + timedelta(minutes=FUTURE_TOL_MIN)),
                       "readings": res["readings"] + r["readings"], "tags_seen": max(res["tags_seen"], r["tags_seen"])}
                if not truncated:
                    break
                src = {**get_source(db, sid), "catchup": 1}
            db.execute("UPDATE en_sources SET catchup=? WHERE id=?", (1 if truncated else 0, sid))
            if not truncated and src["kind"] != "csv":
                healed = heal(db, get_source(db, sid), now)
                res["readings"] += healed
            try:                                          # v0.87 ค่าต่อช่วงที่เก่ามาก → เก็บเป็นฐานสะสม
                from . import energy_interval as EI
                EI.prune(db, now)
            except Exception:                             # noqa: BLE001
                log.exception("prune intervals failed")
            if not truncated and src["kind"] != "csv":
                try:                                      # v0.99.41 เติมค่าราย 15 นาทีของวันล่าสุด (วันนี้ · เมื่อวาน · สัปดาห์ก่อน) ที่ยังไม่มี
                    from . import energy_profile as PR
                    PR.auto_fill(db, get_source(db, sid), now)
                    PR.prune(db, now)
                except CN.SourceError as exc:
                    log.warning("energy profile fill %s: %s", sid, exc)
                except Exception:
                    log.exception("energy profile fill failed")
        for k in keys:
            db.execute("INSERT OR IGNORE INTO en_source_files(source_id, file_key, imported_at) VALUES (?,?,?)", (sid, k, started))
        msg = (f"{label + ' · ' if label else ''}{reset_note + '· ' if reset_note else ''}อ่าน {res['rows']} แถว{'ใหม่' if rows_override is None else ''} · Tag {res['tags_seen']}"
               f" · ได้ค่าอ่านรายวัน {res['readings']} ค่า" + (f" (เติมที่ขาด {healed})" if healed else "")
               + (f" · ข้าม {bad} แถวที่อ่านค่าไม่ได้" if bad else "") + (f" · ไฟล์ใหม่ {len(keys)}" if keys else "")
               + (" · ข้อมูลค้างมาก กำลังดึงต่อจนทัน" if truncated else "")
               + (f" · ข้ามข้อมูลเวลาเกินปัจจุบัน {fut} แถว (ถึง {fut_max.strftime('%d/%m %H:%M')}) — ตรวจนาฬิกาเครื่อง SCADA หรือ “เลื่อนเวลา”"
                  if fut else ""))
        status = "ok"
    except (CN.SourceError, ValidationError) as exc:
        res = {"rows": 0, "readings": 0}
        msg = str(exc) if isinstance(exc, CN.SourceError) else "; ".join(exc.errors)
        status = "failed"
    except Exception as exc:  # noqa: BLE001
        log.exception("energy source %s failed", sid)
        res = {"rows": 0, "readings": 0}
        msg, status = f"ผิดพลาด: {CN.mask_secret(str(exc))[:300]}", "failed"
    db.execute("""INSERT INTO en_source_runs(source_id, started_at, finished_at, status, rows_read, readings, message, manual)
                  VALUES (?,?,?,?,?,?,?,?)""", (sid, started, ts(S.now_dt()), status, res["rows"], res["readings"], msg[:500], 1 if manual else 0))
    upd = {"last_run_at": started, "last_status": status, "last_message": msg[:300]}
    if truncated:
        upd["next_run_at"] = started
    elif not manual:
        upd["next_run_at"] = ts(now + timedelta(minutes=int(src["interval_min"] or 15)))
    db.execute(f"UPDATE en_sources SET {', '.join(f'{k}=?' for k in upd)} WHERE id=?", (*upd.values(), sid))
    db.execute("""DELETE FROM en_source_runs WHERE source_id=? AND id NOT IN
                  (SELECT id FROM en_source_runs WHERE source_id=? ORDER BY id DESC LIMIT 200)""", (sid, sid))
    if rows_override is None:                             # v0.75 แจ้งขัดข้อง / กลับมาปกติ (+ ดึงช่วงที่ขาด)
        from .srcwatch import safe_check
        safe_check(db, "energy", sid, now)
    return {"ok": status == "ok", "message": msg, **res}


# ───────────────────────── v0.73 สถานะค่าอ่านรายวัน + เติมที่ขาดเอง ─────────────────────────
LOOKBACK_DAYS = 2
HEAL_EVERY_MIN = 15
STATES = {"scada": "ได้จาก SCADA", "manual": "จด/แก้เอง", "waiting": "ยังไม่ถึงเวลา", "missing": "ขาด — ไม่มีค่าในช่วงเวลาอ่าน",
          "void": "ยกเลิกค่า SCADA แล้ว"}


def _read_cfg(db) -> tuple[int, int, int]:
    from . import energy as EN
    c = EN.settings(db)
    return int(c["scada_hh"]), int(c["scada_mm"]), int(c["scada_window"])


def day_status(db, sid: int, day, now: datetime | None = None) -> dict:
    """ค่าอ่านของวันที่เลือก ต่อมิเตอร์ที่ผูก Tag ของแหล่งนี้: scada / manual / waiting / missing"""
    now = now or S.now_dt()
    hh, mm, win = _read_cfg(db)
    t = datetime.combine(day, datetime.min.time()).replace(hour=hh, minute=mm)
    ready = now >= t + timedelta(minutes=win)
    out = []
    for m in db.execute("""SELECT m.id, m.code, m.name, m.scada_tag, m.grp, f.name AS factory_name FROM en_meters m
                           LEFT JOIN factories f ON f.id=m.factory_id
                           WHERE m.scada_source_id=? AND TRIM(m.scada_tag)<>'' AND m.active=1 ORDER BY f.name, m.grp, m.code""", (sid,)):
        r = db.execute("SELECT value, src, read_at FROM en_readings WHERE meter_id=? AND day=?", (m["id"], day.isoformat())).fetchone()
        st = ("scada" if r["src"] == "scada" else "manual") if r else ("missing" if ready else "waiting")
        if not r and db.execute("SELECT 1 FROM en_skips WHERE meter_id=? AND day=? AND reason='scada_void'",
                                (m["id"], day.isoformat())).fetchone():
            st = "void"
        out.append({**dict(m), "state": st, "value": r["value"] if r else None, "read_at": r["read_at"] if r else None})
    cnt = {k: sum(1 for x in out if x["state"] == k) for k in STATES}
    return {"day": day, "at": t, "meters": out, "count": cnt}


def health(db, sid: int, now: datetime | None = None, days: int = LOOKBACK_DAYS) -> dict:
    now = now or S.now_dt()
    cnt = {k: 0 for k in STATES}
    missing = []
    for i in range(days, -1, -1):
        d = (now - timedelta(days=i)).date()
        st = day_status(db, sid, d, now)
        for k in STATES:
            cnt[k] += st["count"][k]
        if st["count"]["missing"]:
            missing.append({"day": d, "at": st["at"], "n": st["count"]["missing"]})
    due = cnt["scada"] + cnt["manual"] + cnt["missing"]
    return {"count": cnt, "missing": missing, "pct": round(100 * (cnt["scada"] + cnt["manual"]) / due) if due else None}


def heal(db, src: dict, now: datetime | None = None, force: bool = False) -> int:
    """v0.99.37 เติมค่ารายวันที่ขาดเองทุกรอบ — ย้อนหลัง SYNC_DAYS วัน (เดิม 2 วัน) รอบละไม่เกิน SYNC_PER_RUN วัน (วันล่าสุดก่อน)
    วันที่ SQL ยังไม่มีข้อมูล → ลองใหม่ทุก SYNC_RETRY_H ชม. · ใช้ sync_days (ดึงเฉพาะช่วงเวลาอ่าน + Tag ที่ขาด ไม่ติดเพดานจำนวนแถว)"""
    from . import energy_interval as EI
    now = now or S.now_dt()
    if src.get("kind") == "csv":
        return 0
    if EI.is_interval(src):                                # v0.99.42 ค่าต่อช่วง: ช่วงที่ขาด (มาช้าเกินช่วงย้อนทับ / Logger ส่งย้อนหลัง) → ดึงวันนั้นใหม่
        try:
            return _heal_interval(db, src, now)
        except (CN.SourceError, ValidationError) as exc:
            log.warning("energy interval heal %s: %s", src["id"], exc)
            return 0
    last = parse_ts(src["last_heal_at"]) if src.get("last_heal_at") else None
    if not force and last and now - last < timedelta(minutes=HEAL_EVERY_MIN):
        return 0
    db.execute("UPDATE en_sources SET last_heal_at=? WHERE id=?", (ts(now), src["id"]))
    try:
        r = sync_days(db, src, now.date() - timedelta(days=SYNC_DAYS - 1), now.date(), now, max_days=SYNC_PER_RUN, respect_retry=True)
    except ValidationError as exc:
        log.warning("energy heal %s failed: %s", src["id"], exc)
        return 0
    return r["readings"]


def _interval_res(db, ids) -> dict[int, int]:
    """ความละเอียดของค่าต่อช่วงต่อมิเตอร์ (นาที) = ช่วงห่างที่พบบ่อยสุดของ 200 ค่าล่าสุด (ขั้นต่ำ 15)"""
    res: dict[int, int] = {}
    for mid in ids:
        tss = [parse_ts(r[0]) for r in db.execute("SELECT ts FROM en_intervals WHERE meter_id=? ORDER BY ts DESC LIMIT 200", (mid,))]
        gaps_ = [int((a - b).total_seconds() // 60) for a, b in itertools.pairwise(tss) if a > b]
        res[mid] = max(15, max(set(gaps_), key=gaps_.count)) if gaps_ else 15
    return res


def completeness(db, sid: int, days: int = 14, now: datetime | None = None) -> list[dict]:
    """v0.99.42 ความครบถ้วนรายวันของแหล่งข้อมูล: ค่าอ่านรายวัน (มี/ควรมี) + ค่าราย 15 นาที (% ช่วงที่มีค่า) + มิเตอร์ที่ยังขาด"""
    from . import energy_interval as EI
    from . import energy_profile as PR
    now = now or S.now_dt()
    src = get_source(db, sid)
    tagof = _sync_meters(db, sid)
    ids = sorted(tagof)
    if not src or not ids:
        return []
    PR.ensure(db)
    EI.ensure(db)
    hh, mm, win = _read_cfg(db)
    d0 = now.date() - timedelta(days=days - 1)
    ph = ",".join("?" * len(ids))
    rd = defaultdict(set)
    for mid, day in db.execute(f"SELECT meter_id, day FROM en_readings WHERE day>=? AND meter_id IN ({ph})", [d0.isoformat(), *ids]):
        rd[day].add(mid)
    inter = EI.is_interval(src)
    tbl = "en_intervals" if inter else "en_profile"
    cov: dict[tuple[str, int], int] = {}
    for mid, day, n in db.execute(f"""SELECT meter_id, substr(ts, 1, 10), COUNT(DISTINCT substr(ts, 1, 13) || (CAST(substr(ts, 15, 2) AS INTEGER) / 15))
                                      FROM {tbl} WHERE ts>=? AND meter_id IN ({ph}) GROUP BY 1, 2""",
                                  [ts(datetime.combine(d0, datetime.min.time())), *ids]):
        cov[(day, mid)] = n
    res = _interval_res(db, ids) if inter else {}
    out = []
    for k in range(days):
        d = now.date() - timedelta(days=k)
        a = datetime.combine(d, datetime.min.time())
        upto = min(now - timedelta(minutes=30), a + timedelta(days=1))
        due = now >= a.replace(hour=hh, minute=mm) + timedelta(minutes=win)
        have_rd = rd.get(d.isoformat(), set())
        slots_have = slots_want = 0
        gap_ids = []
        if upto > a and src.get("kind") != "csv":
            for mid in ids:
                step = max(1, res.get(mid, 15) // 15)
                want = int((upto - a).total_seconds() // 900) // step
                got = min(cov.get((d.isoformat(), mid), 0), want)
                slots_have += got
                slots_want += want
                if got < want:
                    gap_ids.append(mid)
        miss_rd = [m for m in ids if m not in have_rd] if due else []
        out.append({"day": d, "meters": len(ids), "rd": len(have_rd & set(ids)), "rd_due": due, "rd_miss": miss_rd,
                    "pct": round(100 * slots_have / slots_want, 1) if slots_want else None, "gap_ids": gap_ids})
    return out


def _heal_interval(db, src: dict, now: datetime, days: int = 35, per_run: int = 4) -> int:
    """v0.99.42 แหล่งค่าต่อช่วง: วันล่าสุด {days} วันที่ค่าต่อช่วงของมิเตอร์ยังไม่ครบ → ดึงทั้งวันใหม่เฉพาะมิเตอร์ที่ขาด (วันล่าสุดก่อน)
    ความละเอียดต่อมิเตอร์ดูจากข้อมูลจริง (15 นาที / 30 / 60) · วันนี้/เมื่อวานลองใหม่ทุก 1 ชม. · ก่อนหน้านั้นทุก 6 ชม."""
    ids = [r[0] for r in db.execute("SELECT id FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>'' AND active=1", (src["id"],))]
    if not ids:
        return 0
    res = _interval_res(db, ids)
    key = f"en_interval_try:{src['id']}"
    row = db.execute("SELECT value FROM cs_meta WHERE key=?", (key,)).fetchone()
    tried = json.loads(row[0]) if row and row[0] else {}
    n, done = 0, 0
    for k in range(days):
        if done >= per_run:
            break
        d = now.date() - timedelta(days=k)
        a = datetime.combine(d, datetime.min.time())
        upto = min(now - timedelta(minutes=30), a + timedelta(days=1))
        if upto <= a:
            continue
        got = dict(db.execute(f"""SELECT meter_id, COUNT(*) FROM en_intervals WHERE ts>=? AND ts<? AND meter_id IN ({','.join('?' * len(ids))})
                                  GROUP BY meter_id""", [ts(a), ts(upto), *ids]).fetchall())
        need = {m for m in ids if got.get(m, 0) < int((upto - a).total_seconds() // 60 // res[m])}
        if not need:
            tried.pop(d.isoformat(), None)
            continue
        last = parse_ts(tried.get(d.isoformat())) if tried.get(d.isoformat()) else None
        if last and now - last < timedelta(hours=1 if k <= 1 else (SYNC_RETRY_H if k <= 7 else 24)):
            continue
        n += _fill_interval(db, src, d, d, now, meter_ids=need)["readings"]
        tried[d.isoformat()] = ts(now)
        done += 1
    keep = (now.date() - timedelta(days=days + 1)).isoformat()
    db.execute("INSERT INTO cs_meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (key, json.dumps({d: v for d, v in tried.items() if d >= keep})))
    return n


# ───────────────────────── v0.99.37 ค่ารายวันจาก SQL ครบทุกวัน ─────────────────────────
SYNC_DAYS = 62          # เติมค่าที่ขาดย้อนหลังอัตโนมัติกี่วัน
SYNC_PER_RUN = 10       # รอบละกี่วัน (รอบละ 15 นาที → 62 วันทันในราว 1.5 ชม.)
SYNC_RETRY_H = 6        # วันที่ SQL ยังไม่มีค่า → ลองใหม่ทุกกี่ชั่วโมง
INTERP_MAX_H = 12       # ไม่มีค่าใน ± ช่วงเวลาอ่าน → ประมาณจากค่าก่อน/หลังที่ห่างข้างละไม่เกินกี่ชั่วโมง


def _sync_meters(db, sid: int, meter_ids=None, grp: str | None = None) -> dict[int, str]:
    q = "SELECT id, TRIM(scada_tag) FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>'' AND active=1"
    a: list = [sid]
    if grp:
        q += " AND COALESCE(grp,'')=?"
        a.append(grp)
    out = {r[0]: r[1] for r in db.execute(q, a)}
    return {k: v for k, v in out.items() if meter_ids is None or k in meter_ids}


def missing_days(db, sid: int, d_from, d_to, now: datetime | None = None, meter_ids=None, grp: str | None = None) -> dict:
    """{วัน: {มิเตอร์ที่ยังไม่มีค่าอ่าน}} — เฉพาะวันที่เลยเวลาอ่าน + ช่วงที่ยอมให้แล้ว · ไม่นับวันที่ผู้ดูแลยกเลิกค่า SCADA"""
    now = now or S.now_dt()
    hh, mm, win = _read_cfg(db)
    tagof = _sync_meters(db, sid, meter_ids, grp)
    if not tagof:
        return {}
    ids = sorted(tagof)
    have: set = set()
    for i in range(0, len(ids), 400):
        ch = ids[i:i + 400]
        ph = ",".join("?" * len(ch))
        have |= {(r[0], r[1]) for r in db.execute(f"SELECT meter_id, day FROM en_readings WHERE meter_id IN ({ph}) AND day BETWEEN ? AND ?",
                                                  [*ch, d_from.isoformat(), d_to.isoformat()])}
        have |= {(r[0], r[1]) for r in db.execute(f"""SELECT meter_id, day FROM en_skips WHERE reason='scada_void' AND meter_id IN ({ph})
                                                      AND day BETWEEN ? AND ?""", [*ch, d_from.isoformat(), d_to.isoformat()])}
    out: dict = {}
    d = d_from
    while d <= d_to:
        t = datetime.combine(d, datetime.min.time()).replace(hour=hh, minute=mm)
        if now >= t + timedelta(minutes=win):
            miss = {m for m in ids if (m, d.isoformat()) not in have}
            if miss:
                out[d] = miss
        d += timedelta(days=1)
    return out


def _interp(db, src: dict, rows, t: datetime, mids: set, tagof: dict) -> int:
    """ไม่มีค่าในช่วงเวลาอ่าน: ประมาณค่าตัวนับ ณ เวลาอ่านแบบเส้นตรงจากค่าก่อน/หลัง (ข้างละ ≤ INTERP_MAX_H ชม.) · บันทึกหมายเหตุ ≈ ให้เห็น
    ค่าจริงที่มาทีหลังในช่วงเวลาอ่านจะแทนค่าประมาณอัตโนมัติ"""
    from .energy_field import INTERP_MARK
    sc = {r[0]: (r[1], r[2], r[3], r[4]) for r in db.execute(
        "SELECT tag, scale, add_offset, valid_min, valid_max FROM en_source_tags WHERE source_id=?", (src["id"],))}
    by_tag: dict = defaultdict(list)
    for tag, dt, val in rows:
        if val is not None and val >= 0:
            by_tag[str(tag).strip()].append((dt, float(val)))
    lim = timedelta(hours=INTERP_MAX_H)
    n = 0
    stamp = ts(S.now_dt())
    for mid in sorted(mids):
        pts = sorted(by_tag.get(tagof[mid], []))
        before = [p for p in pts if p[0] <= t]
        after = [p for p in pts if p[0] >= t]
        if not before or not after:
            continue
        (t0, v0), (t1, v1) = before[-1], after[0]
        if t - t0 > lim or t1 - t > lim or v1 < v0:      # ห่างเกิน หรือค่าลดลง (รีเซ็ต) → ไม่เดา
            continue
        raw = v0 if t1 == t0 else v0 + (v1 - v0) * (t - t0).total_seconds() / (t1 - t0).total_seconds()
        k_, o_, lo_, hi_ = sc.get(tagof[mid], (1.0, 0.0, None, None))
        v = raw * (k_ or 1.0) + (o_ or 0.0)
        if (lo_ is not None and v < lo_) or (hi_ is not None and v > hi_):
            continue
        day = t.date().isoformat()
        if db.execute("SELECT 1 FROM en_readings WHERE meter_id=? AND day=?", (mid, day)).fetchone():
            continue
        note = f"{INTERP_MARK} ประมาณจาก SQL: {t0:%d/%m %H:%M} → {t1:%d/%m %H:%M}"
        db.execute("""INSERT INTO en_readings(meter_id, day, value, src, updated_at, read_at, note) VALUES (?,?,?,?,?,?,?)""",
                   (mid, day, round(v, 6), "scada", stamp, ts(t), note))
        db.execute("DELETE FROM en_skips WHERE meter_id=? AND day=? AND reason<>'scada_void'", (mid, day))
        n += 1
    return n


def sync_days(db, src: dict, d_from, d_to, now: datetime | None = None, meter_ids=None, grp: str | None = None,
              max_days: int | None = None, respect_retry: bool = False) -> dict:
    """v0.99.37 ค่ารายวันจาก SQL ให้ครบทุกวัน (ไม่ทับค่าที่จด/แก้เอง และวันที่ยกเลิกไว้)
    ทีละวัน: ① ดึงเฉพาะ Tag ที่ขาด ช่วงเวลาอ่าน ± ช่วงที่ยอมให้ → ค่าที่ใกล้เวลาอ่านที่สุด
             ② ยังขาด → ดึง ± INTERP_MAX_H ชม. เฉพาะ Tag นั้น → ประมาณแบบเส้นตรง (หมายเหตุ ≈)
    ดึงเป็นช่วงสั้น ๆ ต่อวัน → ไม่ติดเพดานจำนวนแถว (เดิมดึงทั้งก้อนแล้วถูกตัดที่ 50,000 แถว ทำให้วันหลัง ๆ หาย)"""
    from .energy_field import scada_ingest
    now = now or S.now_dt()
    if src.get("kind") == "csv":
        raise ValidationError(["แหล่ง CSV ดึงย้อนหลังไม่ได้ — นำเข้าไฟล์ CSV ของช่วงนั้นแทน"])
    hh, mm, win = _read_cfg(db)
    d_to = min(d_to, now.date())
    miss = missing_days(db, src["id"], d_from, d_to, now, meter_ids, grp)
    tagof = _sync_meters(db, src["id"], meter_ids, grp)
    approx: dict = defaultdict(set)                       # วันที่ยังเป็นค่าประมาณ (≈) → ลองหาค่าจริงในช่วงเวลาอ่านอีกครั้ง (ข้อมูลมาช้า)
    if tagof:
        ids = sorted(tagof)
        for i in range(0, len(ids), 400):
            ch = ids[i:i + 400]
            for r in db.execute(f"""SELECT meter_id, day FROM en_readings WHERE src='scada' AND note LIKE '≈%' AND day BETWEEN ? AND ?
                                    AND meter_id IN ({','.join('?' * len(ch))})""", [d_from.isoformat(), d_to.isoformat(), *ch]):
                approx[datetime.strptime(r[1], "%Y-%m-%d").date()].add(r[0])
    days = sorted(set(miss) | set(approx), reverse=True)
    if respect_retry and days:                             # 2 วันล่าสุด (ข้อมูลมาช้าบ่อย) ลองใหม่ทุก HEAL_EVERY_MIN นาที · วันเก่ากว่านั้นทุก SYNC_RETRY_H ชม.
        tried = {r[0]: parse_ts(r[1]) for r in db.execute("SELECT day, tried_at FROM en_sync_tries WHERE source_id=?", (src["id"],))}
        fresh = now.date() - timedelta(days=LOOKBACK_DAYS)

        def due(d):
            t = tried.get(d.isoformat())
            return not t or now - t >= (timedelta(minutes=HEAL_EVERY_MIN) if d >= fresh else timedelta(hours=SYNC_RETRY_H))
        days = [d for d in days if due(d)]
    pending = len(days)
    if max_days:
        days = days[:max_days]
    n = interp = 0
    no_data = []
    for d in days:
        mids = set(miss.get(d, set()))
        both = mids | approx.get(d, set())
        t = datetime.combine(d, datetime.min.time()).replace(hour=hh, minute=mm)
        try:
            fsrc = dict(src)
            rows, _k, _b = fetch_all(db, fsrc, now, tags=sorted({tagof[m] for m in both}), since=t - timedelta(minutes=win + 1),
                                     until=min(t + timedelta(minutes=win + 1), now))
            _remember_tags(db, src["id"], rows)
            n += scada_ingest(db, fsrc, rows, only_meter=both)
            have = {r[0] for r in db.execute(f"""SELECT meter_id FROM en_readings WHERE day=? AND meter_id IN ({','.join('?' * len(both))})
                                                 AND NOT (src='scada' AND COALESCE(note,'') LIKE '≈%')""", [d.isoformat(), *sorted(both)])}
            got_any = {r[0] for r in db.execute(f"""SELECT meter_id FROM en_readings WHERE day=? AND meter_id IN ({','.join('?' * len(both))})""",
                                                [d.isoformat(), *sorted(both)])}
            still = mids - got_any
            if still:
                rows2, _k, _b = fetch_all(db, dict(src), now, tags=sorted({tagof[m] for m in still}),
                                          since=t - timedelta(hours=INTERP_MAX_H), until=min(t + timedelta(hours=INTERP_MAX_H), now))
                k = _interp(db, src, rows2, t, still, tagof)
                interp += k
                n += k
                if k:
                    still -= {r[0] for r in db.execute(f"""SELECT meter_id FROM en_readings WHERE day=? AND meter_id IN ({','.join('?' * len(still))})""",
                                                       [d.isoformat(), *sorted(still)])}
        except CN.SourceError as exc:
            raise ValidationError([f"ดึงข้อมูลจาก SQL ไม่สำเร็จ: {exc}"]) from None
        if still:
            no_data.append(d)
        if still or (both - have):                        # ยังขาด หรือยังเป็นค่าประมาณ → ลองใหม่ตามรอบ SYNC_RETRY_H
            db.execute("""INSERT INTO en_sync_tries(source_id, day, tried_at) VALUES (?,?,?)
                          ON CONFLICT(source_id, day) DO UPDATE SET tried_at=excluded.tried_at""", (src["id"], d.isoformat(), ts(now)))
        else:
            db.execute("DELETE FROM en_sync_tries WHERE source_id=? AND day=?", (src["id"], d.isoformat()))
    return {"days": len(days), "readings": n, "interp": interp, "no_data": sorted(no_data), "pending": max(0, pending - len(days))}


def run_due_sources(app, now: datetime | None = None) -> int:
    con = sqlite3.connect(app.config["DATABASE"], timeout=15)
    con.row_factory = sqlite3.Row
    try:
        con.execute("PRAGMA busy_timeout=15000")
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='en_sources'").fetchone():
            return 0
        now = now or S.now_dt()
        try:
            from . import energy_interval as EI
            EI.ensure_cut(con, now)
            con.commit()
        except Exception:                                   # ไม่ให้การสร้างค่าอ่านใหม่ขวางการดึงค่า — จะลองใหม่รอบหน้า
            con.rollback()
        due = [r[0] for r in con.execute("SELECT id FROM en_sources WHERE active=1 AND (next_run_at IS NULL OR next_run_at <= ?)", (ts(now),))]
        for sid in due:
            run_source(con, sid, now=now)
            con.commit()
        return len(due)
    finally:
        con.close()


def test(db, sid: int, days: float = 2.0, now: datetime | None = None) -> dict:
    """ทดสอบการเชื่อมต่อ + ดูค่าที่จะลงให้มิเตอร์ที่จับคู่แล้ว (ไม่บันทึกค่าอ่าน · บันทึกรายชื่อ Tag ที่พบ)"""
    from .energy_field import scada_pick
    src = get_source(db, sid)
    if not src:
        raise CN.SourceError("ไม่พบแหล่งข้อมูล")
    now = now or S.now_dt()
    src = {**src, "watermark": "", "config": {**src["config"], "backfill_days": days}}
    rows, keys, bad = fetch(db, src, now, force_files=True)
    tags: dict[str, int] = defaultdict(int)
    for t, _, _ in rows:
        tags[t] += 1
    found = _remember_tags(db, sid, rows)
    best = scada_pick(db, src, rows)
    plan = []
    for (mid, day), (dist, dt, val) in sorted(best.items(), key=lambda x: (x[0][0], x[0][1])):
        m = db.execute("SELECT code, name, scada_tag FROM en_meters WHERE id=?", (mid,)).fetchone()
        plan.append({"meter_id": mid, "meter": ((m["code"] or "") + " " + (m["name"] or "")).strip() if m else str(mid), "tag": m["scada_tag"] if m else "",
                     "day": day, "at": ts(dt), "value": round(val, 3), "dist": round(dist)})
    return {"rows": len(rows), "bad": bad, "files": len(keys), "tags": found,
            "sample": [{"tag": t, "ts": ts(d), "value": v} for t, d, v in rows[-15:]],
            "top": sorted(({"tag": k, "count": v} for k, v in tags.items()), key=lambda x: -x["count"])[:50], "plan": plan[:60]}


# ───────────────────────── จับคู่ Tag ↔ มิเตอร์ ─────────────────────────

def meter_choices(db, factory_ids=None) -> list[dict]:
    from . import energy as EN
    out = []
    for m in EN.meters(db, None, None, active_only=True):
        if factory_ids and m["factory_id"] not in factory_ids:
            continue
        out.append({"id": m["id"], "text": meter_text(m), "m": m})
    return out


def meter_text(m: dict) -> str:
    from . import energy as EN
    where = " › ".join(x for x in (m.get("factory_name"), m.get("grp"), m.get("line")) if x)
    return f"#{m['id']} · {EN.label(m)}" + (f" · {where}" if where else "")


def tag_rows(db, sid: int) -> list[dict]:
    """Tag ที่เคยเห็น + Tag ที่มิเตอร์ผูกไว้แต่ยังไม่เคยเห็น พร้อมมิเตอร์ที่จับคู่"""
    from . import energy as EN
    rows = {r["tag"]: dict(r, meter=None, meters=[]) for r in db.execute("SELECT * FROM en_source_tags WHERE source_id=? ORDER BY tag", (sid,))}
    for m in EN.meters(db, None, None, active_only=False):
        if m.get("scada_source_id") == sid and (m.get("scada_tag") or "").strip():
            t = m["scada_tag"].strip()
            r = rows.setdefault(t, {"tag": t, "scale": 1.0, "add_offset": 0.0, "last_value": None, "last_seen": None, "meter": None,
                                    "meters": [], "source_id": sid, "valid_min": None, "valid_max": None})
            r["meters"].append(m)
            r["meter"] = r["meter"] or m
    for r in rows.values():
        r["text"] = meter_text(r["meter"]) if r["meter"] else ""
        r["dup"] = len(r["meters"]) > 1
    return sorted(rows.values(), key=lambda r: (r["meter"] is not None, r["tag"].lower()))


_NOISE = re.compile(r"(kwh|kw|meter|mtr|energy|actual|factory|f[123](?![0-9a-z])|total|no)", re.I)


def _norm(s: str) -> str:
    """ตัดคำทั่วไป (kWh, meter, factory …) ออก เหลือคำที่แยกมิเตอร์ได้"""
    return re.sub(r"[^a-z0-9ก-๙]+", "", _NOISE.sub(" ", (s or "").lower()))


def suggest(db, sid: int, rows: list[dict] | None = None, limit: int = 600) -> dict:
    """แนะนำมิเตอร์ให้ Tag ที่ยังไม่จับคู่ (เทียบชื่อ/รหัส/ตำแหน่งแบบคล้ายกัน) → {tag: {id, text, score, why}}"""
    from . import energy as EN
    rows = rows if rows is not None else tag_rows(db, sid)
    free = [m for m in EN.meters(db, None, None, active_only=True) if not (m.get("scada_source_id") and m.get("scada_tag"))]
    if not free:
        return {}
    cand = [(m, [_norm(m.get("code")), _norm(m.get("name")), _norm((m.get("code") or "") + (m.get("name") or "")), _norm(m.get("location"))])
            for m in free]
    out = {}
    for r in [x for x in rows if not x["meter"]][:limit]:
        tg = _norm(r["tag"])
        if len(tg) < 2:
            continue
        best = (0.0, None, "")
        for m, keys in cand:
            for i, k in enumerate(keys):
                if not k:
                    continue
                sc = difflib.SequenceMatcher(None, tg, k).ratio()
                if len(k) >= 4 and len(tg) >= 4 and (k in tg or tg in k) and min(len(k), len(tg)) / max(len(k), len(tg)) >= 0.5:
                    sc = max(sc, 0.85)
                if sc > best[0]:
                    best = (sc, m, ("รหัส", "ชื่อ", "รหัส+ชื่อ", "ตำแหน่ง")[i])
        if best[1] and best[0] >= 0.6:
            out[r["tag"]] = {"id": best[1]["id"], "text": meter_text(best[1]), "score": round(best[0] * 100), "why": f"คล้าย{best[2]}"}
    return out


def _parse_meter(text: str, by_id: dict) -> int | None:
    t = (text or "").strip()
    if not t:
        return None
    m = re.match(r"^#?(\d+)\b", t)
    if m and int(m.group(1)) in by_id:
        return int(m.group(1))
    raise ValidationError([f"ไม่พบมิเตอร์ “{t[:40]}” — เลือกจากรายการที่แนะนำ"])


def save_mapping(db, sid: int, items: list[dict], actor) -> dict:
    """items: [{tag, meter (ข้อความ '#id · ...' หรือ id), scale, offset}] — ว่าง = ไม่ใช้ (ถอดการผูก)
    v0.86 บันทึกแถวที่ถูกต้องทั้งหมด (แถวที่ผิดข้ามไป + แจ้งเตือน ไม่ทำให้ที่เลือกไว้หายทั้งหน้า) ·
    มิเตอร์ถูกเลือกซ้ำ: แถวที่เพิ่งเปลี่ยนได้มิเตอร์ (ย้ายจาก Tag เดิมให้เอง) · เปลี่ยนพร้อมกันหลายแถว → คงค่าเดิมของแถวเหล่านั้น"""
    from . import energy as EN
    by_id = {m["id"]: m for m in EN.meters(db, None, None, active_only=False)}
    cur = {}                                               # tag → มิเตอร์ที่ผูกอยู่ตอนนี้
    for m in by_id.values():
        if m.get("scada_source_id") == sid and (m.get("scada_tag") or "").strip():
            cur.setdefault(m["scada_tag"].strip(), m["id"])
    warnings, plan = [], []
    for it in items:
        tag = str(it.get("tag") or "").strip()[:120]
        if not tag:
            continue
        try:
            mid = _parse_meter(str(it.get("meter") or ""), by_id)
        except ValidationError as exc:
            warnings += [f"{tag}: {e} (แถวนี้ยังไม่บันทึก)" for e in exc.errors]
            continue
        try:
            sc = float(it.get("scale") if it.get("scale") not in (None, "") else 1)
            off = float(it.get("offset") if it.get("offset") not in (None, "") else 0)
        except (TypeError, ValueError):
            warnings.append(f"{tag}: ตัวคูณ/ค่าบวกต้องเป็นตัวเลข (แถวนี้ยังไม่บันทึก)")
            continue
        if sc == 0:
            warnings.append(f"{tag}: ตัวคูณห้ามเป็น 0 (แถวนี้ยังไม่บันทึก)")
            continue
        rng = None
        if "vmin" in it or "vmax" in it:
            try:
                rng = CN.parse_range(it.get("vmin"), it.get("vmax"))
            except ValidationError as exc:
                warnings.append(f"{tag}: {exc.errors[0]} (แถวนี้ยังไม่บันทึก)")
                continue
        plan.append([tag, mid, sc, off, rng])
    # ── มิเตอร์ที่ถูกเลือกซ้ำ ──
    groups: dict[int, list] = {}
    for p in plan:
        if p[1]:
            groups.setdefault(p[1], []).append(p)
    planned = {p[0] for p in plan}
    moved = 0
    for mid, ps in groups.items():
        other = [t for t, m in cur.items() if m == mid and t not in planned]   # Tag เดิมที่ไม่ได้อยู่ในหน้านี้ (กรองไว้)
        if len(ps) == 1 and not other:
            continue
        changed = [p for p in ps if cur.get(p[0]) != mid]
        name = EN.label(by_id[mid]) if mid in by_id else f"#{mid}"
        if len(changed) == 1:
            for p in ps:
                if p is not changed[0]:
                    p[1] = None                            # ย้ายมิเตอร์ไป Tag ที่เพิ่งเลือก
            moved += 1
            warnings.append(f"ย้าย {name} จาก {', '.join([p[0] for p in ps if p is not changed[0]] + other)} ไป {changed[0][0]}")
        elif len(changed) > 1:
            for p in changed:
                p[1] = cur.get(p[0])                       # เลือกซ้ำพร้อมกัน → คงค่าเดิม
            warnings.append(f"{name} ถูกเลือกซ้ำใน {', '.join(p[0] for p in changed)} — 1 มิเตอร์ใช้ได้ 1 Tag · แถวเหล่านี้คงค่าเดิม เลือกใหม่อีกครั้ง")
    mapped = unmapped = 0
    final = {p[1] for p in plan if p[1]}
    for tag, mid, sc, off, rng in plan:
        db.execute("""INSERT INTO en_source_tags(source_id, tag, scale, add_offset) VALUES (?,?,?,?)
                      ON CONFLICT(source_id, tag) DO UPDATE SET scale=excluded.scale, add_offset=excluded.add_offset""", (sid, tag, sc, off))
        if rng is not None:
            db.execute("UPDATE en_source_tags SET valid_min=?, valid_max=? WHERE source_id=? AND tag=?", (*rng, sid, tag))
        for c in [r[0] for r in db.execute("SELECT id FROM en_meters WHERE scada_source_id=? AND scada_tag=?", (sid, tag))]:
            if c != mid and c not in final:                # มิเตอร์ที่จะย้ายไป Tag อื่นในรอบนี้ ไม่นับเป็นการถอด
                db.execute("UPDATE en_meters SET scada_source_id=NULL, scada_tag='' WHERE id=?", (c,))
                unmapped += 1
    for tag, mid, sc, off, rng in plan:                     # ผูกหลังถอดครบ (ลำดับแถวไม่มีผล)
        if mid:
            m = db.execute("SELECT scada_source_id, scada_tag FROM en_meters WHERE id=?", (mid,)).fetchone()
            if m and (m[0] != sid or (m[1] or "") != tag):
                db.execute("UPDATE en_meters SET scada_source_id=?, scada_tag=? WHERE id=?", (sid, tag, mid))
                mapped += 1
    S.audit(db, actor, "update", "en_source_tags", sid, after={"mapped": mapped, "unmapped": unmapped, "moved": moved,
                                                                "warnings": warnings[:20]})
    return {"mapped": mapped, "unmapped": unmapped, "moved": moved, "warnings": warnings, "saved": len(plan)}


def export_xlsx(db, sid: int) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    src = get_source(db, sid)
    rows = tag_rows(db, sid)
    sug = suggest(db, sid, rows)
    wb = Workbook()
    ws = wb.active
    ws.title = "จับคู่ Tag"
    ws.append(["Tag", "ค่าล่าสุด", "เวลา", "มิเตอร์ ID", "มิเตอร์ (ปัจจุบัน)", "ตัวคูณ", "ค่าบวก", "ค่าต่ำสุดที่เป็นไปได้", "ค่าสูงสุดที่เป็นไปได้",
               "คำแนะนำ (ID)", "คำแนะนำ (ชื่อ)", "ความมั่นใจ %"])
    for c in ws[1]:
        c.font, c.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="1D4ED8")
    for r in rows:
        s = sug.get(r["tag"])
        ws.append([r["tag"], r["last_value"], r["last_seen"] or "", r["meter"]["id"] if r["meter"] else None, r["text"],
                   r["scale"], r["add_offset"], r.get("valid_min"), r.get("valid_max"), s["id"] if s else None, s["text"] if s else "",
                   s["score"] if s else None])
    for i, w in enumerate([30, 12, 18, 11, 48, 9, 9, 12, 12, 12, 48, 12], 1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w
    ws.freeze_panes = "B2"
    ms = wb.create_sheet("มิเตอร์")
    ms.append(["มิเตอร์ ID", "โรงงาน", "หมวดหมู่", "Section", "Line", "รหัส", "ชื่อ", "Tag ที่ผูกอยู่", "แหล่งที่ผูก"])
    from . import energy as EN
    for m in EN.meters(db, None, None, active_only=True):
        ms.append([m["id"], m.get("factory_name") or "", EN.KINDS.get(m["kind"], {}).get("th", m["kind"]), m.get("grp") or "", m.get("line") or "",
                   m.get("code") or "", m.get("name") or "", m.get("scada_tag") or "", m.get("scada_source_id")])
    for c in ms[1]:
        c.font = Font(bold=True)
    h = wb.create_sheet("วิธีใช้")
    for t in (f"แหล่งข้อมูล: {src['name'] if src else ''}",
              "กรอกคอลัมน์ “มิเตอร์ ID” (ดู ID จากชีต มิเตอร์) แล้วนำเข้ากลับ · เว้นว่าง = ไม่ใช้ Tag นี้ / ถอดการผูก",
              "คอลัมน์ “คำแนะนำ (ID)” ใช้คัดลอกไปใส่ “มิเตอร์ ID” ได้ถ้าเห็นว่าถูกต้อง",
              "ตัวคูณ/ค่าบวก: ค่าที่ใช้ = ค่าจาก Tag × ตัวคูณ + ค่าบวก (เว้นว่าง = 1 และ 0)",
              "1 มิเตอร์ใช้ได้ 1 Tag · ระบบแสดงรายการผิดพลาดก่อนบันทึกเสมอ"):
        h.append([t])
    h.column_dimensions["A"].width = 100
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def import_xlsx(db, sid: int, raw: bytes, actor) -> dict:
    from openpyxl import load_workbook
    try:
        wb = load_workbook(io.BytesIO(raw), data_only=True, read_only=True)
    except Exception:                                  # noqa: BLE001
        raise ValidationError(["อ่านไฟล์ Excel ไม่ได้"]) from None
    ws = wb["จับคู่ Tag"] if "จับคู่ Tag" in wb.sheetnames else wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        raise ValidationError(["ไฟล์ว่าง"])
    head = [str(h or "").strip() for h in rows[0]]
    try:
        it, im, isc, iof = head.index("Tag"), head.index("มิเตอร์ ID"), head.index("ตัวคูณ"), head.index("ค่าบวก")
    except ValueError:
        raise ValidationError(["ไม่พบหัวคอลัมน์ Tag / มิเตอร์ ID / ตัวคูณ / ค่าบวก — ใช้ไฟล์ที่ส่งออกจากระบบ"]) from None
    items = []
    for r in rows[1:]:
        if not r or not r[it]:
            continue
        mv = r[im]
        item = {"tag": str(r[it]).strip(), "meter": "" if mv in (None, "") else str(int(mv)) if isinstance(mv, (int, float)) else str(mv),
                "scale": r[isc], "offset": r[iof]}
        if "ค่าต่ำสุดที่เป็นไปได้" in head:
            item.update(vmin=r[head.index("ค่าต่ำสุดที่เป็นไปได้")], vmax=r[head.index("ค่าสูงสุดที่เป็นไปได้")]
                        if "ค่าสูงสุดที่เป็นไปได้" in head else None)
        items.append(item)
    res = save_mapping(db, sid, items, actor)
    res["rows"] = len(items)
    return res


# ───────────────────────── v0.74 ตรวจสอบ / แก้ไข ค่าอ่านจาก SCADA ย้อนหลัง ─────────────────────────
AUDIT_MAX_DAYS = 31


def audit(db, sid: int, d_from, d_to, now: datetime | None = None, grp: str | None = None) -> dict:
    """มิเตอร์ที่ผูก Tag ของแหล่งนี้ × วัน: ค่าอ่าน / ที่มา (SCADA · จดเอง · แก้ไข) / ขาด / ยกเลิก + ปัญหาที่ต้องแก้"""
    from datetime import date as _d
    now = now or S.now_dt()
    if d_from > d_to:
        d_from, d_to = d_to, d_from
    if (d_to - d_from).days >= AUDIT_MAX_DAYS:
        raise ValidationError([f"เลือกช่วงไม่เกิน {AUDIT_MAX_DAYS} วัน"])
    hh, mm, win = _read_cfg(db)
    days = [d_from + timedelta(days=i) for i in range((d_to - d_from).days + 1)]
    meters = [dict(r) for r in db.execute("""SELECT m.id, m.code, m.name, m.scada_tag, m.grp, m.line, m.unit, f.name AS factory_name
                                             FROM en_meters m LEFT JOIN factories f ON f.id=m.factory_id
                                             WHERE m.scada_source_id=? AND TRIM(m.scada_tag)<>'' AND m.active=1
                                             ORDER BY f.name, m.grp, m.code""", (sid,))]
    if grp:
        meters = [m for m in meters if (m["grp"] or "") == grp]
    ids = [m["id"] for m in meters]
    rd, sk = {}, set()
    if ids:
        ph = ",".join("?" * len(ids))
        for r in db.execute(f"""SELECT meter_id, day, value, src, read_at FROM en_readings WHERE meter_id IN ({ph}) AND day BETWEEN ? AND ?""",
                            [*ids, d_from.isoformat(), d_to.isoformat()]):
            rd[(r[0], r[1])] = dict(r)
        sk = {(r[0], r[1]) for r in db.execute(f"""SELECT meter_id, day FROM en_skips WHERE meter_id IN ({ph}) AND day BETWEEN ? AND ?
                                                   AND reason='scada_void'""", [*ids, d_from.isoformat(), d_to.isoformat()])}
    tag_seen = {r[0]: r[1] for r in db.execute("SELECT tag, last_seen FROM en_source_tags WHERE source_id=?", (sid,))}
    cnt = {k: 0 for k in STATES}
    cnt["fix"] = 0
    issues = []
    for m in meters:
        m["cells"], m["n_scada"], m["n_missing"] = [], 0, 0
        for d in days:
            t = datetime.combine(d, datetime.min.time()).replace(hour=hh, minute=mm)
            r = rd.get((m["id"], d.isoformat()))
            if r:
                st = "scada" if r["src"] == "scada" else ("fix" if r["src"] == "fix" else "manual")
            elif (m["id"], d.isoformat()) in sk:
                st = "void"
            elif now < t + timedelta(minutes=win):
                st = "waiting"
            else:
                st = "missing"
            cnt[st] += 1
            m["n_scada"] += st == "scada"
            m["n_missing"] += st == "missing"
            m["cells"].append({"day": d, "state": st, "value": r["value"] if r else None, "read_at": r["read_at"] if r else None,
                               "src": r["src"] if r else None})
        m["last_seen"] = tag_seen.get((m["scada_tag"] or "").strip())
        where = f"{m['code'] or ''} {m['name'] or ''}".strip()
        if m["n_missing"] and not m["n_scada"]:
            issues.append({"level": "ng", "meter_id": m["id"], "where": where,
                           "text": f"Tag {m['scada_tag']} ไม่ได้ค่าเลยในช่วงนี้" + (f" (เห็นล่าสุด {m['last_seen'][:16]})" if m["last_seen"]
                                                                                   else " (ยังไม่เคยได้ค่า — ตรวจชื่อ Tag)")})
        elif m["n_missing"]:
            issues.append({"level": "warn", "meter_id": m["id"], "where": where,
                           "text": f"ขาด {m['n_missing']} วัน — ไม่มีค่าในช่วง {hh:02d}:{mm:02d} ± {win} นาที (กด “ดึงวันที่ขาด” หรือจดเอง)"})
    due = cnt["scada"] + cnt["manual"] + cnt["fix"] + cnt["missing"]
    lvl = {"ng": 0, "warn": 1}
    issues.sort(key=lambda x: lvl[x["level"]])
    return {"from": d_from, "to": d_to, "days": days, "meters": meters, "count": cnt, "issues": issues, "at": f"{hh:02d}:{mm:02d}", "win": win,
            "pct": round(100 * (cnt["scada"] + cnt["manual"] + cnt["fix"]) / due) if due else None}


def _can_fix(db, actor) -> None:
    from . import submissions as SUB
    if not SUB.can_approve(db, actor):
        raise ValidationError(["เฉพาะผู้ดูแลระบบ หัวหน้างาน หรือผู้มีสิทธิ์อนุมัติ"])


def refetch_day(db, src: dict, mid: int, day, now: datetime | None = None) -> int:
    """ดึงค่าเวลาอ่านของวันนั้นจาก SCADA ใหม่ให้มิเตอร์ตัวเดียว"""
    from .energy_field import scada_ingest
    now = now or S.now_dt()
    hh, mm, win = _read_cfg(db)
    t = datetime.combine(day, datetime.min.time()).replace(hour=hh, minute=mm)
    m = db.execute("SELECT scada_tag FROM en_meters WHERE id=?", (mid,)).fetchone()
    fsrc = dict(src)
    rows, _k, _b = fetch_all(db, fsrc, now, tags=[m[0].strip()] if m and m[0] else None, since=t - timedelta(minutes=win + 1),
                             until=min(t + timedelta(minutes=win + 1), now))
    n = scada_ingest(db, fsrc, rows, only_meter=mid)
    if not n and not db.execute("SELECT 1 FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone():
        n = sync_days(db, src, day, day, now, meter_ids={mid})["readings"]       # v0.99.37 ไม่มีค่าในช่วงเวลาอ่าน → ประมาณจากค่าก่อน/หลัง
    return n


def void_day(db, mid: int, day, reason: str, actor) -> None:
    """ยกเลิกค่าอ่านจาก SCADA ของวันนั้น (เอาออกจากรายงาน · ระบบไม่ลงซ้ำ)"""
    _can_fix(db, actor)
    reason = str(reason or "").strip()
    if len(reason) < 3:
        raise ValidationError(["กรุณาระบุเหตุผล (อย่างน้อย 3 ตัวอักษร)"])
    old = db.execute("SELECT value, src FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
    db.execute("DELETE FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat()))
    db.execute("""INSERT INTO en_skips(meter_id, day, reason, note, user_id, created_at) VALUES (?,?,?,?,?,?)
                  ON CONFLICT(meter_id, day) DO UPDATE SET reason=excluded.reason, note=excluded.note, user_id=excluded.user_id,
                  created_at=excluded.created_at""", (mid, day.isoformat(), "scada_void", reason[:300], actor, ts(S.now_dt())))
    S.audit(db, actor, "energy_scada_void", "en_readings", mid, before={"day": day.isoformat(), "value": old[0] if old else None,
                                                                         "src": old[1] if old else None}, after={"reason": reason})


def restore_day(db, src: dict, mid: int, day, actor) -> int:
    """คืนค่าจาก SCADA (ล้างการยกเลิก / การแก้ แล้วดึงค่าวันนั้นใหม่)"""
    _can_fix(db, actor)
    old = db.execute("SELECT value, src FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
    db.execute("DELETE FROM en_skips WHERE meter_id=? AND day=? AND reason='scada_void'", (mid, day.isoformat()))
    if old and old[1] == "fix":
        db.execute("DELETE FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat()))
    n = refetch_day(db, src, mid, day)
    S.audit(db, actor, "energy_scada_restore", "en_readings", mid, before={"day": day.isoformat(), "value": old[0] if old else None},
            after={"readings": n})
    return n


def fill_range(db, src: dict, d_from, d_to, now: datetime | None = None, grp: str | None = None) -> dict:
    """ดึงเฉพาะวันที่ขาดในช่วง (ไม่ทับค่าที่มีแล้ว) — v0.86 ช่วงยาวได้ (แบ่งทีละ 31 วัน) · เลือก Section ได้"""
    from . import energy_interval as EI
    now = now or S.now_dt()
    if EI.is_interval(src):
        return _fill_interval(db, src, d_from, d_to, now, grp)
    r = sync_days(db, src, d_from, d_to, now, grp=grp)                     # v0.99.37 ทีละวัน + ประมาณค่าเมื่อไม่มีค่าในช่วงเวลาอ่าน
    return {"days": r["days"], "readings": r["readings"], "no_data": r["no_data"], "interp": r["interp"]}


def _fill_profile(db, src: dict, d_from, d_to, now: datetime, grp: str | None = None, every: bool = False) -> int:
    """v0.99.42 ดึงค่าย้อนหลัง (แหล่งแบบเลขสะสม) → เติมค่าราย 15 นาทีของช่วงนั้นด้วย (เฉพาะมิเตอร์ที่ยังไม่ครบ · replace = ทุกมิเตอร์)"""
    from . import energy_interval as EI
    from . import energy_profile as PR
    if src.get("kind") == "csv" or EI.is_interval(src):
        return 0
    ids = list(_sync_meters(db, src["id"], None, grp))
    n = 0
    d = d_from
    while d <= d_to:
        need = set(ids) if every else PR.gaps(db, ids, d, now)
        if need:
            n += PR.backfill(db, src, d, d, now, meter_ids=need)["rows"]
        d += timedelta(days=1)
    return n


def _fill_interval(db, src: dict, d_from, d_to, now: datetime, grp: str | None = None, meter_ids=None) -> dict:
    """v0.87 แหล่งค่าต่อช่วง: ดึงทั้งวันของทุกวันในช่วง (ทีละวัน) → เก็บค่าต่อช่วง → สร้างค่าอ่านรายวันใหม่"""
    from . import energy_interval as EI
    q = "SELECT id, scada_tag FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>'' AND active=1" + (" AND COALESCE(grp,'')=?" if grp else "")
    ms = db.execute(q, (src["id"], grp) if grp else (src["id"],)).fetchall()
    if meter_ids is not None:
        ms = [r for r in ms if r[0] in meter_ids]
    tags = sorted({r[1].strip() for r in ms})
    if not tags:
        return {"days": 0, "readings": 0, "no_data": []}
    no_data, got_any = [], set()
    d = d_from
    while d <= d_to:
        a = datetime.combine(d, datetime.min.time())
        b = min(a + timedelta(days=1), now)
        try:
            rows, _k, _b = fetch_all(db, dict(src), now, tags=tags, since=a - timedelta(seconds=1), until=b)
        except CN.SourceError as exc:
            raise ValidationError([f"ดึงข้อมูลจาก SCADA ไม่สำเร็จ: {exc}"]) from None
        _remember_tags(db, src["id"], rows)
        r = EI.store(db, src, rows)
        got_any |= set(r["meters"])
        if not r["stored"]:
            no_data.append(d)
        d += timedelta(days=1)
    n = EI.rebuild_readings(db, [r[0] for r in ms], d_from - timedelta(days=1), now)
    return {"days": (d_to - d_from).days + 1, "readings": n, "no_data": no_data}


BACKFILL_MAX_DAYS = 62


def backfill(db, sid: int, d_from, d_to, mode: str, actor, grp: str | None = None, now: datetime | None = None) -> dict:
    """v0.86 ดึงค่าย้อนหลังตามช่วงที่กำหนดเอง (≤ 62 วัน) — fill = เติมเฉพาะวันที่ขาด · replace = ลงค่าจาก SCADA ใหม่ทั้งช่วง
    (ค่าที่จด/แก้เอง และวันที่ผู้ดูแลยกเลิกไว้ ไม่แตะ)"""
    now = now or S.now_dt()
    src = get_source(db, sid)
    if not src:
        raise ValidationError(["ไม่พบแหล่งข้อมูล"])
    if src["kind"] == "csv":
        raise ValidationError(["แหล่ง CSV ดึงย้อนหลังไม่ได้ — นำเข้าไฟล์ CSV ของช่วงนั้นแทน"])
    if d_from > d_to:
        d_from, d_to = d_to, d_from
    d_to = min(d_to, now.date())
    if (d_to - d_from).days >= BACKFILL_MAX_DAYS:
        raise ValidationError([f"เลือกช่วงไม่เกิน {BACKFILL_MAX_DAYS} วัน"])
    removed = 0
    if mode == "replace":
        q = "SELECT id FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>''" + (" AND COALESCE(grp,'')=?" if grp else "")
        ids = [r[0] for r in db.execute(q, (sid, grp) if grp else (sid,))]
        for i in range(0, len(ids), 500):
            ch = ids[i:i + 500]
            removed += db.execute(f"""DELETE FROM en_readings WHERE src='scada' AND day BETWEEN ? AND ?
                                      AND meter_id IN ({','.join('?' * len(ch))})""", [d_from.isoformat(), d_to.isoformat(), *ch]).rowcount
        from . import energy_interval as EI
        if EI.is_interval(src):
            EI.clear(db, ids, d_from, d_to)
    r = fill_range(db, src, d_from, d_to, now, grp=grp)
    r["profile"] = _fill_profile(db, src, d_from, d_to, now, grp, every=mode == "replace")
    S.audit(db, actor, "energy_backfill", "en_sources", sid,
            after={"from": d_from.isoformat(), "to": d_to.isoformat(), "mode": mode, "grp": grp or "", "removed": removed,
                   "days": r["days"], "readings": r["readings"]})
    return {**r, "removed": removed, "from": d_from, "to": d_to}


def audit_xlsx(db, sid: int, d_from, d_to) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    rep = audit(db, sid, d_from, d_to)
    color = {"scada": "DCFCE7", "manual": "EDE9FE", "fix": "DBEAFE", "void": "E5E7EB", "missing": "FEE2E2", "waiting": "FFFFFF"}
    wb = Workbook()
    ws = wb.active
    ws.title = "ค่าอ่านจาก SCADA"
    ws.append(["มิเตอร์", "Tag", "Section"] + [d.strftime("%d/%m") for d in rep["days"]])
    for c in ws[1]:
        c.font = Font(bold=True)
    for m in rep["meters"]:
        ws.append([f"{m['code'] or ''} {m['name'] or ''}".strip(), m["scada_tag"], m["grp"] or ""] +
                  [c["value"] if c["value"] is not None else ({"void": "ยกเลิก", "missing": "ขาด"}.get(c["state"], "")) for c in m["cells"]])
        for j, c in enumerate(m["cells"]):
            ws.cell(row=ws.max_row, column=4 + j).fill = PatternFill("solid", fgColor=color.get(c["state"], "FFFFFF"))
    ws.column_dimensions["A"].width, ws.column_dimensions["B"].width = 34, 20
    ws.freeze_panes = "D2"
    iss = wb.create_sheet("ปัญหา")
    iss.append(["ระดับ", "มิเตอร์", "ปัญหา"])
    for i in rep["issues"]:
        iss.append(["ต้องแก้" if i["level"] == "ng" else "ตรวจ", i["where"], i["text"]])
    iss.column_dimensions["B"].width, iss.column_dimensions["C"].width = 34, 90
    import io
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


# ───────────────────────── v0.76 แก้การตั้งค่าแล้วลงค่าย้อนหลังให้เอง ─────────────────────────

def meter_snapshot(db, sid: int) -> dict:
    """{meter_id: (Tag, ตัวคูณ, ค่าบวก)} ของมิเตอร์ที่ผูกกับแหล่งนี้"""
    sc = {r[0]: (float(r[1] or 1), float(r[2] or 0), r[3], r[4]) for r in db.execute(
        "SELECT tag, scale, add_offset, valid_min, valid_max FROM en_source_tags WHERE source_id=?", (sid,))}
    out = {}
    for r in db.execute("SELECT id, TRIM(scada_tag) FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>''", (sid,)):
        out[r[0]] = (r[1], *sc.get(r[1], (1.0, 0.0, None, None)))
    return out


def reapply(db, sid: int, days: int, actor, meter_ids: set[int] | None = None, now: datetime | None = None) -> dict | None:
    """ลงค่าอ่านจาก SCADA ใหม่ย้อนหลัง N วัน (เฉพาะค่าที่มาจาก SCADA — ค่าที่จด/แก้เองไม่แตะ) แล้วดึงใหม่"""
    days = int(days or 0)
    src = get_source(db, sid)
    if days <= 0 or not src:
        return None
    now = now or S.now_dt()
    d_from = now.date() - timedelta(days=min(days, 62) - 1)
    ids = list(meter_ids) if meter_ids is not None else list(meter_snapshot(db, sid))
    if not ids:
        return None
    ph = ",".join("?" * len(ids))
    n = db.execute(f"DELETE FROM en_readings WHERE src='scada' AND day>=? AND meter_id IN ({ph})", [d_from.isoformat(), *ids]).rowcount
    r = fill_range(db, src, d_from, now.date(), now)
    S.audit(db, actor, "energy_reapply", "en_sources", sid, after={"from": d_from.isoformat(), "meters": len(ids), "removed": n, **r})
    return {"days": days, "meters": len(ids), "removed": n, "readings": r["readings"]}
