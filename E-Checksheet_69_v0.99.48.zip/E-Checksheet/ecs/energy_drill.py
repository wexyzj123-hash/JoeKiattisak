"""ecs/energy_drill.py — v0.99.45 หน้าภาพรวม: เจาะดูรายวันทุก 15 นาที + ใช้ลด/เพิ่มตรงไหน (เดือนนี้ vs เดือนก่อน)

day_detail()  วันเดียว: โหลดทุก 15 นาที / รายชั่วโมง เทียบเมื่อวานหรือวันเดียวกันสัปดาห์ก่อน · สูงสุด · โหลดพื้นฐานกลางคืน ·
              ในเวลางาน/นอกเวลา · มิเตอร์ที่เปลี่ยนมากที่สุด (ลิงก์ไปกราฟมิเตอร์ + ข้อมูลดิบจาก SQL)
month_shape() เดือน: โปรไฟล์รายชั่วโมงเฉลี่ยต่อวัน เดือนนี้ vs เดือนก่อน + ส่วนต่าง · แยก 4 ช่วงเวลา · Heatmap วัน × ชั่วโมง ·
              มิเตอร์ที่ลด / เพิ่มมากที่สุด (ยอดสะสมช่วงเดียวกัน จากค่าอ่านรายวัน — ใช้ได้แม้ไม่มีค่าราย 15 นาที)
ใช้กติกาเดียวกับทุกหน้า: มีมิเตอร์ย่อย → นับเฉพาะมิเตอร์ย่อย · มิเตอร์ “หักออก” ไม่รวม
"""
from __future__ import annotations

import calendar
from datetime import date, datetime, time, timedelta

from . import energy as EN
from . import energy_live as LV

BANDS = [("night", "กลางคืน", 0, 6), ("morning", "เช้า", 6, 12), ("afternoon", "บ่าย", 12, 18), ("evening", "เย็น–ค่ำ", 18, 24)]
WORK = (8, 17)                                  # ช่วงเวลางานสำหรับแยก “ในเวลางาน / นอกเวลา”
TOP = 10


def _scope(db, kind: str, fid, grp, project_id, line) -> list[dict]:
    ms_all = EN.meters(db, fid, kind, True, project_id, grp or None, line or None)
    return [m for m in EN.counted(ms_all) if m["is_main"] != -1]


def _hsum(arr: list, h: int) -> float | None:
    xs = [v for v in arr[h * 4:(h + 1) * 4] if v is not None]
    return round(sum(xs), 4) if xs else None


def _rng(arr: list, h0: int, h1: int) -> float | None:
    xs = [v for v in arr[h0 * 4:h1 * 4] if v is not None]
    return round(sum(xs), 3) if xs else None


def _pct(a, b):
    return round(100 * (a - b) / b, 1) if a is not None and b else None


def _meter_link(m: dict) -> dict:
    return {"id": m["id"], "name": EN.label(m), "sid": m.get("scada_source_id"), "tag": (m.get("scada_tag") or "").strip()}


def day_detail(db, kind: str, day: date, fid=None, grp=None, project_id=None, line=None, cmp: str = "week") -> dict:
    kind = kind if kind in EN.KINDS else "elec"
    meta = EN.KINDS[kind]
    cday = day - timedelta(days=1 if cmp == "yday" else 7)
    ms = _scope(db, kind, fid, grp, project_id, line)
    ids = [m["id"] for m in ms]
    a, ca = datetime.combine(day, time(0, 0)), datetime.combine(cday, time(0, 0))
    per = LV._sums(db, ids, a, a + timedelta(days=1)) if ids else {}
    per_c = LV._sums(db, ids, ca, ca + timedelta(days=1)) if ids else {}
    tot, tot_c = [None] * LV.NSLOT, [None] * LV.NSLOT
    for r in per.values():
        LV._add(tot, r)
    for r in per_c.values():
        LV._add(tot_c, r)
    has15 = any(v is not None for v in tot)
    res = LV._resolution(tot) if has15 else LV.SLOT_MIN
    rate = 60 / res
    last = max((i for i, v in enumerate(tot) if v is not None), default=None)
    s_cur = sum(v for v in tot if v is not None) if has15 else None
    s_cmp_same = sum(v for i, v in enumerate(tot_c) if v is not None and last is not None and i <= last) if has15 else None
    pk = max(range(LV.NSLOT), key=lambda i: tot[i] if tot[i] is not None else -1) if has15 else None
    # ยอดรายวันจากค่าอ่านมิเตอร์ (ใช้ได้เสมอ) — เทียบกับวันที่เทียบ + มิเตอร์ที่เปลี่ยนมากที่สุด
    ser = EN.series(db, ms, min(day, cday), max(day, cday)) if ms else {}
    rows = []
    for m in ms:
        if m["id"] in per or m["id"] in per_c:
            u = sum(v for v in per.get(m["id"], []) if v is not None) if m["id"] in per else None
            c = sum(v for v in per_c.get(m["id"], []) if v is not None) if m["id"] in per_c else None
            via = "15m"
        else:
            s = ser.get(m["id"]) or {}
            u = (s.get(day.isoformat()) or {}).get("u")
            c = (s.get(cday.isoformat()) or {}).get("u")
            via = "day"
        if u is None and c is None:
            continue
        sg = EN.sign(m)
        u = sg * u if u is not None else None
        c = sg * c if c is not None else None
        rows.append({**_meter_link(m), "u": round(u, 2) if u is not None else None, "c": round(c, 2) if c is not None else None,
                     "diff": round(u - c, 2) if u is not None and c is not None else None, "pct": _pct(u, c), "via": via})
    day_u = sum(r["u"] for r in rows if r["u"] is not None) if rows else None
    day_c = sum(r["c"] for r in rows if r["c"] is not None) if rows else None
    rows.sort(key=lambda r: -abs(r["diff"] or 0))
    out = {"kind": kind, "th": meta["th"], "unit": meta["unit"], "color": meta["color"], "icon": meta["icon"],
           "rate_unit": "kW" if kind == "elec" else f"{meta['unit']}/ชม.", "day": day.isoformat(), "cmp_day": cday.isoformat(), "cmp": cmp,
           "has15": has15, "res": res, "slots": LV.slot_labels(), "v": [round(x, 3) if x is not None else None for x in tot],
           "c": [round(x, 3) if x is not None else None for x in tot_c], "rate": rate,
           "hours": [{"h": f"{h:02d}", "v": _hsum(tot, h), "c": _hsum(tot_c, h)} for h in range(24)],
           "sum": round(s_cur, 2) if s_cur is not None else round(day_u, 2) if day_u is not None else None,
           "cmp_sum": round(s_cmp_same, 2) if s_cmp_same is not None else round(day_c, 2) if day_c is not None else None,
           "upto": (LV.slot_labels() + ["24:00"])[last + 1] if last is not None else None,
           "peak": round(tot[pk] * rate, 1) if pk is not None and tot[pk] is not None else None,
           "peak_at": LV.slot_labels()[pk] if pk is not None and tot[pk] is not None else None,
           "base": round((_rng(tot, 0, 6) or 0) / 6, 1) if has15 and _rng(tot, 0, 6) is not None else None,
           "base_c": round((_rng(tot_c, 0, 6) or 0) / 6, 1) if _rng(tot_c, 0, 6) is not None else None,
           "work": _rng(tot, *WORK), "off": round(s_cur - (_rng(tot, *WORK) or 0), 2) if s_cur is not None else None,
           "work_c": _rng(tot_c, *WORK), "work_lbl": f"{WORK[0]:02d}:00–{WORK[1]:02d}:00",
           "meters": rows[:TOP], "n_meters": len(ms), "n_rows": len(rows)}
    out["pct"] = _pct(out["sum"], out["cmp_sum"])
    out["off_c"] = round(sum(v for v in tot_c if v is not None) - (out["work_c"] or 0), 2) if any(v is not None for v in tot_c) else None
    return out


def _month_matrix(db, ids: list[int], m0: date, upto: date) -> tuple[list[list], int]:
    """[[ชั่วโมง 0..23] ต่อวัน] ของเดือน (ค่ารวมรายชั่วโมง · None = ไม่มีข้อมูล) ถึงวัน upto"""
    days = calendar.monthrange(m0.year, m0.month)[1]
    out, n = [], 0
    if not ids:
        return out, 0
    a = datetime.combine(m0, time(0, 0))
    per = LV._sums_range(db, ids, a, a + timedelta(days=days))
    for d in range(days):
        day = m0 + timedelta(days=d)
        if day > upto:
            break
        row = [None] * 24
        for h in range(24):
            k0 = d * LV.NSLOT + h * 4
            xs = [v for v in per[k0:k0 + 4] if v is not None]
            row[h] = round(sum(xs), 3) if xs else None
        if any(v is not None for v in row):
            n += 1
        out.append(row)
    return out, n


def month_shape(db, kind: str, month: date, fid=None, grp=None, project_id=None, line=None, today: date | None = None) -> dict:
    kind = kind if kind in EN.KINDS else "elec"
    meta = EN.KINDS[kind]
    today = today or EN.S.now_dt().date()
    m0 = month.replace(day=1)
    p0 = (m0 - timedelta(days=1)).replace(day=1)
    m_last = m0.replace(day=calendar.monthrange(m0.year, m0.month)[1])
    upto = min(today - timedelta(days=1), m_last) if today > m0 else min(today, m_last)   # เดือนปัจจุบัน: เทียบเฉพาะวันที่จบแล้ว (ถึงเมื่อวาน)
    n_days = (upto - m0).days + 1
    p_upto = min(p0 + timedelta(days=n_days - 1), m0 - timedelta(days=1))          # ช่วงเดียวกันของเดือนก่อน (วันที่ 1 – วันเดียวกัน)
    ms = _scope(db, kind, fid, grp, project_id, line)
    ids = [m["id"] for m in ms]
    cur, n_cur = _month_matrix(db, ids, m0, upto)
    prv, n_prv = _month_matrix(db, ids, p0, p_upto)

    def avg_profile(mat):
        out = []
        for h in range(24):
            xs = [r[h] for r in mat if r[h] is not None]
            out.append(round(sum(xs) / len(xs), 3) if xs else None)
        return out
    a_cur, a_prv = avg_profile(cur), avg_profile(prv)
    diff = [round(x - y, 3) if x is not None and y is not None else None for x, y in zip(a_cur, a_prv)]
    bands = []
    for key, th, h0, h1 in BANDS:
        x = [a_cur[h] for h in range(h0, h1) if a_cur[h] is not None]
        y = [a_prv[h] for h in range(h0, h1) if a_prv[h] is not None]
        xs, ys = (round(sum(x), 1) if x else None), (round(sum(y), 1) if y else None)
        bands.append({"key": key, "th": th, "lbl": f"{h0:02d}–{h1:02d}", "cur": xs, "prev": ys,
                      "diff": round(xs - ys, 1) if xs is not None and ys is not None else None, "pct": _pct(xs, ys)})
    # มิเตอร์ที่ลด / เพิ่ม: ยอดสะสมช่วงเดียวกัน (จากค่าอ่านรายวัน — ตัวคำนวณเดียวกับทุกหน้า)
    ser_c = EN.series(db, ms, m0, upto) if ms else {}
    ser_p = EN.series(db, ms, p0, p_upto) if ms else {}
    ch = []
    for m in ms:
        u = sum((x.get("u") or 0) for x in (ser_c.get(m["id"]) or {}).values())
        p = sum((x.get("u") or 0) for x in (ser_p.get(m["id"]) or {}).values())
        if not u and not p:
            continue
        sg = EN.sign(m)
        ch.append({**_meter_link(m), "u": round(sg * u, 1), "p": round(sg * p, 1), "diff": round(sg * (u - p), 1), "pct": _pct(u, p)})
    gone = [x for x in ch if x["u"] == 0 and x["p"] != 0]                  # เดือนนี้ไม่มีค่าเลย = ข้อมูลไม่มา ไม่ใช่ “ลดได้”
    real = [x for x in ch if x not in gone]
    downs = sorted([x for x in real if x["diff"] < 0], key=lambda x: x["diff"])[:TOP]
    ups = sorted([x for x in real if x["diff"] > 0], key=lambda x: -x["diff"])[:TOP]
    tot_c, tot_p = sum(x["u"] for x in real), sum(x["p"] for x in real)
    th_m = ("ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.")
    return {"kind": kind, "th": meta["th"], "unit": meta["unit"], "color": meta["color"],
            "month": m0.isoformat(), "m_lbl": f"{th_m[m0.month - 1]} {m0.year + 543}", "p_lbl": f"{th_m[p0.month - 1]} {p0.year + 543}",
            "range": f"1–{upto.day}", "p_range": f"1–{p_upto.day}", "n_cur": n_cur, "n_prv": n_prv,
            "avg_cur": a_cur, "avg_prev": a_prv, "diff": diff, "bands": bands,
            "heat": [[h, d, v] for d, row in enumerate(cur) for h, v in enumerate(row) if v is not None],
            "heat_days": [(m0 + timedelta(days=d)).isoformat() for d in range(len(cur))],
            "downs": downs, "ups": ups, "gone": gone[:TOP], "n_gone": len(gone), "tot_cur": round(tot_c, 1), "tot_prev": round(tot_p, 1), "tot_pct": _pct(tot_c, tot_p)}
