"""ecs/energy_dept.py — v0.99.47 หน่วยงาน (Section): scorecard รายหน่วยงาน · ตารางจัดอันดับ · จัดหมวดมิเตอร์

ranking()   ทุกหน่วยงานของโรงงาน: ยอดเดือนนี้ (ถึงวันที่ปิดยอดล่าสุด) · เทียบเดือนก่อนช่วงเดียวกัน · เทียบเป้า · บาท · tCO₂ · kWh/หน่วยผลิต
scorecard() หน่วยงานเดียว: KPI เดือน + วันนี้ (ราย 15 นาที) · เป้า/คาดการณ์สิ้นเดือน · อันดับ · ไลน์ · มิเตอร์ · ช่วงเวลาที่น่าจะสูญเสีย
assign_rows() / save_assign()  ตารางจัดหมวดมิเตอร์ (Project / Section / Line) ทีละหลายตัว + คำแนะนำจากชื่อมิเตอร์ / Tag
ใช้ตัวคำนวณเดียวกับทุกหน้า (EN.series · EN.counted · เป้า energy_summary.target_for ระดับ Section)
"""
from __future__ import annotations

import calendar
import re
from datetime import date, timedelta

from . import energy as EN
from . import energy_struct as ST
from . import energy_summary as SMY
from . import services as S

NO_SEC = "-"


def _rate(db, fid: int | None, kind: str, month: date) -> float | None:
    """บาท/หน่วย: ไฟฟ้า = อัตราจากบิล (เดือนนั้น/ล่าสุด) หรือค่าตั้งค่า · อื่น ๆ = ราคาที่ตั้งในหมวด"""
    cfg = EN.settings(db)
    k = EN.KINDS.get(kind, {})
    if kind != "elec":
        return k.get("price")
    if fid:
        from . import energy_dash as DASH
        items = DASH.rate_source(db, [fid], month)["items"]
        if items:
            return float(items[0]["rate"])
    return float(cfg.get("price_elec") or 0)


def _ef(db, kind: str) -> float | None:
    k = EN.KINDS.get(kind, {})
    if k.get("ef") is not None:
        return k["ef"]
    return float(EN.settings(db).get("ef_elec") or 0) if kind == "elec" else None


def _period(today: date, month: date) -> tuple[date, date, date, date]:
    """(ต้นเดือน, วันสุดท้ายที่ปิดยอดแล้ว, ต้นเดือนก่อน, วันเดียวกันของเดือนก่อน) — เดือนปัจจุบันนับถึงเมื่อวาน"""
    m0 = month.replace(day=1)
    m_last = m0.replace(day=calendar.monthrange(m0.year, m0.month)[1])
    upto = min(today - timedelta(days=1), m_last) if today > m0 else m0
    p0 = (m0 - timedelta(days=1)).replace(day=1)
    p_upto = min(p0 + timedelta(days=(upto - m0).days), m0 - timedelta(days=1))
    return m0, upto, p0, p_upto


def _sum_days(ser: dict, ms: list[dict]) -> dict[str, float]:
    out: dict[str, float] = {}
    for m in ms:
        for d, x in (ser.get(m["id"]) or {}).items():
            if x.get("u") is not None:
                out[d] = out.get(d, 0.0) + EN.sign(m) * x["u"]
    return out


def _prod(db, fid: int | None, grp: str, month: date) -> float | None:
    """ยอดผลิตของหน่วยงานในเดือน (รวมทุกไลน์ จาก “kWh/หน่วยผลิต” หน้าไฟฟ้า)"""
    if not fid:
        return None
    try:
        r = db.execute("SELECT SUM(qty) FROM en_line_prod WHERE factory_id=? AND grp=? AND month=?",
                       (fid, "" if grp == NO_SEC else grp, month.strftime("%Y-%m"))).fetchone()
    except Exception:                                   # noqa: BLE001 — ตารางยังไม่ถูกสร้าง (ยังไม่เคยกรอกยอดผลิต)
        return None
    return float(r[0]) if r and r[0] else None


def _depts(db, fid: int | None, kind: str) -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    for m in EN.meters(db, fid, kind, True):
        out.setdefault((m["grp"] or "").strip() or NO_SEC, []).append(m)
    return out


def ranking(db, kind: str, fid: int | None, month: date, today: date | None = None) -> dict:
    today = today or S.now_dt().date()
    kind = kind if kind in EN.KINDS else "elec"
    m0, upto, p0, p_upto = _period(today, month)
    ms_all = EN.meters(db, fid, kind, True)
    ser = EN.series(db, ms_all, m0, upto) if ms_all else {}
    ser_p = EN.series(db, ms_all, p0, p_upto) if ms_all else {}
    rate, ef = _rate(db, fid, kind, m0), _ef(db, kind)
    man = SMY.manual_targets(db, kind)
    n_days = (upto - m0).days + 1
    dim = calendar.monthrange(m0.year, m0.month)[1]
    rows = []
    for g, ms in _depts(db, fid, kind).items():
        cm = [m for m in EN.counted(ms) if m["is_main"] != -1]
        if not cm:
            continue
        live = [m for m in cm if any(x.get("u") is not None for x in (ser.get(m["id"]) or {}).values())]
        cur = sum(_sum_days(ser, live).values())
        prev = sum(_sum_days(ser_p, live).values())             # เดือนก่อน: เฉพาะมิเตอร์ที่เดือนนี้ยังส่งข้อมูล (ไม่ให้ตัวที่หยุดส่งกลายเป็น “ลดได้”)
        tg = SMY.target_for(db, kind, "grp", g, fid, cm, m0, man)
        t_mtd = tg["daily"] * n_days if tg["daily"] else None
        prod = _prod(db, fid, g, m0)
        rows.append({"grp": g, "name": "ไม่ระบุหน่วยงาน" if g == NO_SEC else g, "n": len(ms), "n_live": len(live), "n_dead": len(cm) - len(live),
                     "u": round(cur, 1), "prev": round(prev, 1), "chg": round(100 * (cur - prev) / prev, 1) if prev else None,
                     "target_day": tg["daily"], "target_src": tg["src"], "t_mtd": round(t_mtd, 1) if t_mtd else None,
                     "t_pct": round(100 * cur / t_mtd, 1) if t_mtd else None,
                     "forecast": round(cur / n_days * dim, 0) if n_days > 0 and cur else None, "t_month": round(tg["daily"] * dim, 0) if tg["daily"] else None,
                     "baht": round(cur * rate, 0) if rate else None, "co2": round(cur * ef / 1000, 2) if ef else None,
                     "prod": prod, "per_unit": round(cur / prod, 4) if prod and upto >= m0 + timedelta(days=dim - 1) else None})
    total = sum(r["u"] for r in rows)
    for r in rows:
        r["share"] = round(100 * r["u"] / total, 1) if total else None
    rows.sort(key=lambda r: (r["grp"] == NO_SEC, -r["u"]))
    ranked = [r for r in rows if r["grp"] != NO_SEC]
    for i, r in enumerate(sorted(ranked, key=lambda r: (r["chg"] is None, r["chg"] if r["chg"] is not None else 0))):
        r["rank"] = i + 1                                       # อันดับ 1 = ลดได้มากที่สุด (เทียบเดือนก่อน)
    meta = EN.KINDS[kind]
    return {"kind": kind, "th": meta["th"], "unit": meta["unit"], "icon": meta["icon"], "color": meta["color"],
            "m0": m0, "upto": upto, "p0": p0, "p_upto": p_upto, "n_days": n_days, "dim": dim, "rows": rows, "total": round(total, 1),
            "rate": rate, "ef": ef, "n_ranked": len(ranked), "unassigned": next((r for r in rows if r["grp"] == NO_SEC), None)}


def scorecard(db, kind: str, fid: int | None, grp: str, month: date, today: date | None = None) -> dict:
    today = today or S.now_dt().date()
    R = ranking(db, kind, fid, month, today)
    row = next((r for r in R["rows"] if r["grp"] == grp), None)
    m0, upto, p0, p_upto = R["m0"], R["upto"], R["p0"], R["p_upto"]
    ms = [m for m in EN.meters(db, fid, R["kind"], True) if ((m["grp"] or "").strip() or NO_SEC) == grp]
    cm = [m for m in EN.counted(ms) if m["is_main"] != -1]
    ser = EN.series(db, cm, m0, upto) if cm else {}
    ser_p = EN.series(db, cm, p0, p_upto) if cm else {}
    live = {m["id"] for m in cm if any(x.get("u") is not None for x in (ser.get(m["id"]) or {}).values())}
    days = [(m0 + timedelta(days=i)).isoformat() for i in range(R["n_days"])]
    dsum = _sum_days(ser, [m for m in cm if m["id"] in live])
    psum = _sum_days(ser_p, [m for m in cm if m["id"] in live])
    pdays = [(p0 + timedelta(days=i)).isoformat() for i in range((p_upto - p0).days + 1)]
    # ไลน์
    lines: dict[str, list] = {}
    for m in cm:
        lines.setdefault((m.get("line") or "").strip() or "ไม่ระบุ Line", []).append(m)
    lrows = []
    for ln, lst in lines.items():
        lv = [m for m in lst if m["id"] in live]
        u, p = sum(_sum_days(ser, lv).values()), sum(_sum_days(ser_p, lv).values())
        lrows.append({"name": ln, "n": len(lst), "u": round(u, 1), "prev": round(p, 1), "chg": round(100 * (u - p) / p, 1) if p else None})
    tot = sum(r["u"] for r in lrows)
    for r in lrows:
        r["share"] = round(100 * r["u"] / tot, 1) if tot else None
    lrows.sort(key=lambda r: -r["u"])
    # มิเตอร์
    mrows = []
    for m in cm:
        s, sp = ser.get(m["id"]) or {}, ser_p.get(m["id"]) or {}
        u = sum((x.get("u") or 0) for x in s.values()) * EN.sign(m)
        p = sum((x.get("u") or 0) for x in sp.values()) * EN.sign(m) if m["id"] in live else 0.0
        mrows.append({"id": m["id"], "name": EN.label(m), "line": m.get("line") or "", "u": round(u, 1), "prev": round(p, 1),
                      "chg": round(100 * (u - p) / p, 1) if p else None, "dead": m["id"] not in live,
                      "share": round(100 * u / tot, 1) if tot else None})
    mrows.sort(key=lambda r: -r["u"])
    # วันนี้ (ราย 15 นาที) + ช่วงที่น่าจะสูญเสีย (ทั้งเดือนจนถึงเมื่อวาน)
    now_k, waste = None, None
    try:
        from . import energy_dash as DASH
        nl = DASH.now_panel(db, fid, "" if grp == NO_SEC else grp, None, None)
        now_k = next((x for x in nl if x["kind"] == R["kind"]), None)
    except Exception:                                   # noqa: BLE001
        now_k = None
    if live and upto >= m0:
        from . import energy_compare as CMP
        try:
            c = CMP.compare(db, R["kind"], m0, upto, m0, upto, fid, None if grp == NO_SEC else grp, sorted(live))
            if c["a"]["n"]:
                off = sum(b["a"] for b in c["bands"] if not b["work"])
                waste = {"bands": [b for b in c["bands"] if b["flag"]], "losses": c["losses"][:5], "base": c["base_a"],
                         "off": round(off, 1), "off_pct": round(100 * off / c["total"]["a"], 1) if c["total"]["a"] else None,
                         "per_day": c["total"]["a"], "days": c["a"]["n"], "work": c["work"]}
        except Exception:                               # noqa: BLE001 — ส่วนเสริม ไม่ให้หน้าหลักล่ม
            waste = None
    t_day = row["target_day"] if row else None
    return {**{k: R[k] for k in ("kind", "th", "unit", "icon", "color", "m0", "upto", "p0", "p_upto", "n_days", "dim", "rate", "ef")},
            "grp": grp, "name": "ไม่ระบุหน่วยงาน" if grp == NO_SEC else grp, "row": row, "rank_of": R["n_ranked"], "ranking": R["rows"],
            "days": days, "daily": [round(dsum.get(d, 0.0), 2) if d in dsum else None for d in days],
            "prev_daily": [round(psum.get(d, 0.0), 2) if d in psum else None for d in pdays], "target_day": t_day,
            "lines": lrows, "meters": mrows, "now": now_k, "waste": waste,
            "projects": sorted({m.get("project_name") or "ยังไม่กำหนด Project" for m in ms})}


# ───────────────────────── จัดหมวดมิเตอร์ ─────────────────────────

def _norm(s: str) -> str:
    return re.sub(r"[^0-9a-zก-๙]+", "", (s or "").lower())


def assign_rows(db, fid: int | None = None, kind: str | None = None, only_missing: bool = True) -> dict:
    ST.ensure_struct(db)
    ms = EN.meters(db, fid, kind, True)
    secs = [s for s in ST.sections(db, fid) if s["name"]]
    lines_ = [x for x in ST.lines(db, fid) if x["name"]]
    rows = []
    for m in ms:
        missing = not (m["grp"] or "").strip()
        if only_missing and not missing:
            continue
        hay = _norm(" ".join(str(m.get(k) or "") for k in ("code", "name", "scada_tag", "location")))
        sg = next((s["name"] for s in sorted(secs, key=lambda s: -len(s["name"]))
                   if (s["factory_id"] in (None, m["factory_id"])) and len(_norm(s["name"])) >= 3 and _norm(s["name"]) in hay), "")
        lg = next((x for x in sorted(lines_, key=lambda x: -len(x["name"]))
                   if x["factory_id"] in (None, m["factory_id"]) and len(_norm(x["name"])) >= 3 and _norm(x["name"]) in hay), None)
        rows.append({**{k: m.get(k) for k in ("id", "code", "name", "kind", "factory_id", "factory_name", "grp", "line", "project_id", "is_main",
                                              "scada_tag", "location")},
                     "label": EN.label(m), "sug_grp": sg or (lg["section"] if lg else ""), "sug_line": lg["name"] if lg else "", "missing": missing})
    n_all = len(ms)
    n_missing = sum(1 for m in ms if not (m["grp"] or "").strip())
    return {"rows": rows, "n_all": n_all, "n_missing": n_missing, "n_done": n_all - n_missing,
            "sections": sorted({s["name"] for s in secs}), "lines": sorted({x["name"] for x in lines_}), "projects": ST.projects(db, True)}


def save_assign(db, form_rows: list[dict], actor, can_touch) -> dict:
    """[{id, project_id, grp, line}] → บันทึกเฉพาะแถวที่เปลี่ยน · คืน {changed, skipped}"""
    changed = skipped = 0
    for r in form_rows:
        m = EN.meter(db, r["id"])
        if not m or not can_touch(m):
            skipped += 1
            continue
        grp, line = (r.get("grp") or "").strip()[:80], (r.get("line") or "").strip()[:80]
        pid = r.get("project_id")
        same = (grp == (m["grp"] or "")) and (line == (m.get("line") or "")) and ((pid or None) == (m.get("project_id") or None))
        if same:
            continue
        ST.bulk_assign(db, [m["id"]], actor, project_id=pid, set_project=True, grp=grp, line=line)
        changed += 1
    return {"changed": changed, "skipped": skipped}
