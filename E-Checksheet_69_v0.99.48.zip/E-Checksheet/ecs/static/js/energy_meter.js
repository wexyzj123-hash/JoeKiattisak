/* v0.88 หน้ามิเตอร์: การใช้รายวัน (แยกวัน · Target · ค่าเพี้ยน) + รายช่วงเวลา 15 นาทีของวันที่เลือก */
(function () {
  const el = document.getElementById('en-meter2');
  if (!el || !window.echarts) return;
  const D = JSON.parse(el.textContent);
  const css = getComputedStyle(document.documentElement);
  const v = (n, f) => (css.getPropertyValue(n) || '').trim() || f;
  const bg = getComputedStyle(document.body).backgroundColor.match(/\d+/g) || [255, 255, 255];
  const dark = (0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]) < 128;
  const TXT = v('--text', dark ? '#e2e8f0' : '#0f172a'), MUTED = v('--muted', '#64748b'), GRID = v('--border', '#e2e8f0');
  const OVER = '#d03b3b', TG = '#0ca30c', CMP = dark ? '#64748b' : '#94a3b8';
  const fmt = (x) => x == null ? '–' : Number(x).toLocaleString('th-TH', {maximumFractionDigits: Math.abs(x) >= 100 ? 0 : 2});
  const FL = {split: 'เฉลี่ยจากช่วงที่ขาดค่าอ่าน', bad: 'ค่าเพี้ยน — ไม่นับ', reset: 'ค่าลดลง/รีเซ็ต — ไม่นับ', spike: 'ค่ากระโดด', fix: 'แก้หน่วยแล้ว', first: 'ค่าแรก'};
  const charts = [];
  const base = {textStyle: {color: TXT, fontFamily: 'inherit'}, animation: false, grid: {left: 56, right: 16, top: 24, bottom: 36}};

  // การใช้รายวัน
  const n1 = document.getElementById('ch-meter2');
  if (n1) {
    const c = echarts.init(n1); charts.push(c);
    const data = D.u.map((x, i) => {
      const f = D.flags[i];
      if (x == null) return {value: null};
      const over = D.target != null && x > D.target;
      return {value: x, itemStyle: {color: D.color, opacity: f === 'split' ? 0.45 : 1, borderRadius: [3, 3, 0, 0]}};
    });
    const marks = D.u.map((x, i) => (['bad', 'reset'].includes(D.flags[i]) ? {coord: [i, 0], value: '!', itemStyle: {color: OVER}} : null)).filter(Boolean)
      .concat(D.u.map((x, i) => (x != null && D.target != null && x > D.target ? {coord: [i, x], symbol: 'triangle', symbolRotate: 180, symbolSize: 9, symbolOffset: [0, -8], label: {show: false}, itemStyle: {color: OVER}} : null)).filter(Boolean));
    c.setOption(Object.assign({}, base, {
      tooltip: {trigger: 'axis', axisPointer: {type: 'shadow'}, formatter: (ps) => {
        const i = ps[0].dataIndex, d = D.days[i], f = D.flags[i];
        return `<b>${d.slice(8)}/${d.slice(5, 7)}/${d.slice(0, 4)}</b><br>ใช้ <b>${fmt(D.u[i])}</b> ${D.unit}` +
          (D.target != null ? `<br>Target ${fmt(D.target)} ${D.unit}` : '') + (FL[f] ? `<br><i>${FL[f]}</i>` : '');
      }},
      xAxis: {type: 'category', data: D.days.map((d) => d.slice(8) + '/' + d.slice(5, 7)), axisLabel: {color: MUTED}, axisLine: {lineStyle: {color: GRID}}},
      yAxis: {type: 'value', name: D.unit, nameTextStyle: {color: MUTED}, axisLabel: {color: MUTED}, splitLine: {lineStyle: {color: GRID, opacity: .6}}},
      series: [{type: 'bar', data, barMaxWidth: 22,
        markLine: D.target != null ? {silent: true, symbol: 'none', lineStyle: {color: TG, type: 'dashed', width: 2},
          label: {color: TG, position: 'insideEndTop', formatter: 'Target ' + fmt(D.target)}, data: [{yAxis: D.target}]} : undefined,
        markPoint: marks.length ? {symbol: 'pin', symbolSize: 26, label: {color: '#fff'}, data: marks} : undefined}]}));
    c.on('click', (p) => { const pf = document.getElementById('pfDay'); if (pf) { pf.value = D.days[p.dataIndex]; pf.dispatchEvent(new Event('change')); document.getElementById('prof').scrollIntoView({behavior: 'smooth'}); } });
  }

  // รายช่วงเวลา: ทุก 15 นาที / รายชั่วโมง · เทียบเมื่อวาน / สัปดาห์ก่อน · ตารางรายชั่วโมง · CSV (v0.99.41)
  const n2 = document.getElementById('ch-prof'), day = document.getElementById('pfDay'), info = document.getElementById('pfInfo');
  if (n2 && D.has_prof) {
    const c = echarts.init(n2); charts.push(c);
    const cmpSel = document.getElementById('pfCmp'), csv = document.getElementById('pfCsv'), tb = document.querySelector('#pfTbl tbody');
    let res = 15, P = null;
    const dm = (iso) => iso.slice(8) + '/' + iso.slice(5, 7);
    function draw() {
      if (!P) return;
      const hourly = res === 60;
      const x = hourly ? P.hours.map((h) => h.h) : P.slots;
      const cur = hourly ? P.hours.map((h) => h.v) : P.v, prev = hourly ? P.hours.map((h) => h.c) : P.prev;
      const rate = hourly ? 1 : P.rate;
      c.setOption(Object.assign({}, base, {
        legend: {top: 0, right: 8, textStyle: {color: MUTED}},
        tooltip: {trigger: 'axis', valueFormatter: (v) => v == null ? 'ไม่มีค่า' : `${fmt(v)} ${P.unit}` + (P.unit !== P.rate_unit ? ` (${fmt(v * rate)} ${P.rate_unit})` : '')},
        xAxis: {type: 'category', data: x, axisLabel: {color: MUTED, interval: hourly ? 1 : 7}, axisLine: {lineStyle: {color: GRID}}},
        yAxis: {type: 'value', name: P.unit + (hourly ? '/ชม.' : '/15 นาที'), nameTextStyle: {color: MUTED}, axisLabel: {color: MUTED}, splitLine: {lineStyle: {color: GRID, opacity: .6}}},
        series: [{name: dm(P.day), type: 'bar', data: cur, itemStyle: {color: D.color, borderRadius: [2, 2, 0, 0]}},
                 {name: dm(P.cmp_day) + (P.cmp === 'week' ? ' (สัปดาห์ก่อน)' : ' (เมื่อวาน)'), type: 'line', data: prev, showSymbol: hourly,
                  lineStyle: {color: CMP, type: 'dashed', width: 1.5}, itemStyle: {color: CMP}}]}), true);
    }
    function table() {
      document.getElementById('pfH1').textContent = dm(P.day) + ' (' + P.unit + ')';
      document.getElementById('pfH2').textContent = dm(P.cmp_day) + ' (' + P.unit + ')';
      let s1 = 0, s2 = 0;
      tb.innerHTML = P.hours.map((h) => {
        if (h.v == null && h.c == null) return '';
        const d = h.v != null && h.c != null ? h.v - h.c : null, pc = d != null && h.c ? 100 * d / h.c : null;
        if (h.v != null) s1 += h.v; if (h.c != null && h.v != null) s2 += h.c;
        return `<tr><td>${h.h}–${String((+h.h.slice(0, 2) + 1) % 24).padStart(2, '0')}:00${h.n && h.n < 4 ? ' <small class="muted">(' + h.n * 15 + ' นาที)</small>' : ''}</td>` +
          `<td class="num"><b>${fmt(h.v)}</b></td><td class="num muted">${fmt(h.c)}</td>` +
          `<td class="num" style="color:${d == null ? 'inherit' : (d > 0 ? OVER : TG)}">${d == null ? '–' : (d > 0 ? '+' : '') + fmt(d)}</td>` +
          `<td class="num">${pc == null ? '–' : (pc > 0 ? '▲ ' : '▼ ') + Math.abs(pc).toFixed(1)}</td></tr>`;
      }).join('') || '<tr><td colspan="5" class="muted">ไม่มีค่าในวันนี้</td></tr>';
    }
    async function load() {
      info.textContent = 'กำลังโหลด…';
      const q = '?day=' + encodeURIComponent(day.value) + '&cmp=' + cmpSel.value;
      csv.href = D.prof_url + q + '&format=csv';
      try {
        const r = await fetch(D.prof_url + q, {credentials: 'same-origin'});
        P = await r.json();
        info.textContent = P.sum == null ? 'วันนี้ไม่มีค่ารายช่วงเวลา' :
          `รวม ${fmt(P.sum)} ${P.unit}` + (P.last ? ` (ถึง ${P.last})` : '') +
          (P.cmp_same != null ? ` · ${P.cmp === 'week' ? 'สัปดาห์ก่อน' : 'เมื่อวาน'}ช่วงเดียวกัน ${fmt(P.cmp_same)}` + (P.diff_pct != null ? ` (${P.diff_pct > 0 ? '▲' : '▼'} ${Math.abs(P.diff_pct)}%)` : '') : '') +
          ` · สูงสุด ${fmt(P.peak)} ${P.rate_unit} เวลา ${P.peak_at} · ข้อมูลทุก ${P.res} นาที · เส้นประ = วันที่เทียบ`;
        draw(); table();
      } catch (e) { info.textContent = 'โหลดไม่สำเร็จ'; }
    }
    day.addEventListener('change', load);
    cmpSel.addEventListener('change', load);
    document.querySelectorAll('[data-res]').forEach((b) => b.addEventListener('click', () => {
      res = +b.dataset.res;
      document.querySelectorAll('[data-res]').forEach((x) => x.classList.toggle('btn-primary', x === b));
      draw(); }));
    document.querySelectorAll('[data-pd]').forEach((b) => b.addEventListener('click', () => {
      const d = new Date(day.value + 'T00:00:00'); d.setDate(d.getDate() + (+b.dataset.pd));
      const iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      if (day.max && iso > day.max) return; day.value = iso; load(); }));
    document.querySelectorAll('#now .nw-k[data-day="today"]').forEach((a) => a.addEventListener('click', () => {
      if (day.value !== day.max) { day.value = day.max; load(); } }));
    load();
  }

  // “ตอนนี้”: อัปเดตทุก 1 นาที (v0.99.41)
  const nw = document.getElementById('now');
  if (nw && nw.dataset.url && nw.querySelector('.nw-grid')) {
    const put = (k, html) => nw.querySelectorAll(`[data-k="${k}"]`).forEach((e) => { e.innerHTML = html; });
    const pc = (p) => p == null ? '' : `<span class="nw-d ${p > 0 ? 'up' : 'down'}">${p > 0 ? '▲' : '▼'} ${Math.abs(p)}%</span> `;
    setInterval(async () => {
      if (document.hidden) return;
      try {
        const r = await fetch(nw.dataset.url, {credentials: 'same-origin'}); const N = await r.json();
        if (!N.has) return;
        put('today', fmt(N.today)); put('hour', fmt(N.hour)); put('prev_hour', fmt(N.prev_hour)); put('rate', fmt(N.rate));
        put('hour_from', N.hour_from); put('hour_to', N.hour_to); put('prev_hour_lbl', N.prev_hour_lbl); put('yday_full', fmt(N.yday.full));
        put('last', N.last.slice(8, 10) + '/' + N.last.slice(5, 7) + ' ' + N.last.slice(11, 16));
        if (N.reading != null) put('reading', Number(N.reading).toLocaleString('th-TH', {minimumFractionDigits: 1, maximumFractionDigits: 1}));
        put('vs_yday_h', pc(N.vs_yday) + `<small>เมื่อวานช่วงเดียวกัน ${fmt(N.yday.so_far)}</small>`);
        put('hour_vs_h', pc(N.hour_vs_yday) + `<small>เมื่อวานชั่วโมงเดียวกัน ${fmt(N.yday.hour)}</small>`);
      } catch (e) { /* เครือข่ายสะดุด → รอบหน้าลองใหม่ */ }
    }, 60000);
  }
  window.addEventListener('resize', () => charts.forEach((c) => c.resize()));
})();
