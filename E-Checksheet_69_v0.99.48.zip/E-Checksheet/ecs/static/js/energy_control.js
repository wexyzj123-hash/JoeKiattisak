/* energy_control.js — Dashboard ห้องควบคุม: นาฬิกา · กราฟแนวโน้ม (Day/Week/Month + เส้นเป้า) · โดนัท · เทียบโรงงาน · ค้นหาตาราง
 * ใช้ ECharts · แกนเดียวต่อกราฟ · สีตามประเภท (ไฟ=ส้ม น้ำ=น้ำเงิน ลม=ฟ้า) */
(function () {
  'use strict';
  const el = document.getElementById('cr-data');
  const cs = getComputedStyle(document.documentElement);
  const v = (n, d) => (cs.getPropertyValue(n).trim() || d);
  const T = { grid: v('--viz-grid', '#e5e7eb'), axis: v('--viz-axis', '#cbd5e1'), muted: v('--muted', '#64748b'), ink: v('--text', '#0f172a'),
    surface: v('--surface', '#fff'), s: [v('--viz-s1', '#2a78d6'), v('--viz-s2', '#eb6834'), v('--viz-s3', '#1baf7a'), '#8b5cf6', '#ef4444', '#64748b'],
    font: getComputedStyle(document.body).fontFamily };
  const fmt = (x, d) => x == null ? '–' : Number(x).toLocaleString('th-TH', { maximumFractionDigits: d == null ? 0 : d });
  const charts = [];
  const mk = (id) => { const e = document.getElementById(id); if (!e || !window.echarts) return null; const c = echarts.init(e, null, { renderer: 'canvas', devicePixelRatio: Math.min(devicePixelRatio || 1, 2) }); charts.push(c); return c; };
  const base = { backgroundColor: 'transparent', textStyle: { fontFamily: T.font, color: T.ink }, animationDuration: 300 };
  const tip = { backgroundColor: T.surface, borderColor: T.axis, textStyle: { color: T.ink, fontFamily: T.font } };

  // นาฬิกา
  const tm = document.getElementById('crTime'), dt = document.getElementById('crDate');
  if (tm) {
    const tick = () => { const n = new Date(); tm.textContent = n.toLocaleTimeString('th-TH', { hour12: false });
      if (dt) dt.textContent = n.toLocaleDateString('th-TH', { day: 'numeric', month: 'long', year: 'numeric' }); };
    tick(); setInterval(tick, 1000);
  }
  // ค้นหา + แถวคลิกได้
  const qI = document.getElementById('crQ');
  const allC = document.getElementById('crAll');
  const filt = () => { const s = qI ? qI.value.trim().toLowerCase() : '', all = allC && allC.checked;
    document.querySelectorAll('#crTbl tbody tr[data-q]').forEach((r) => { r.hidden = (s && !r.dataset.q.includes(s)) || (!all && r.classList.contains('cr-nodata')); }); };
  if (qI) qI.addEventListener('input', filt); if (allC) allC.addEventListener('change', filt); filt();
  document.querySelectorAll('tr.cr-click').forEach((r) => r.addEventListener('click', () => { location = r.dataset.href; }));
  if (window.ENSpark) window.ENSpark();
  if (!el) return;
  const D = JSON.parse(el.textContent);

  // ── แนวโน้ม ──
  const tr = mk('crTrend');
  let kind = Object.keys(D.kp)[0], range = 'day', monthCache = {};
  const dlab = (d) => d.slice(8, 10) + '/' + d.slice(5, 7);
  function weekly(days, vals) {
    const out = { x: [], y: [] };
    for (let i = 0; i < days.length; i += 7) { out.x.push(dlab(days[i]) + '–' + dlab(days[Math.min(i + 6, days.length - 1)])); out.y.push(Math.round(vals.slice(i, i + 7).reduce((a, b) => a + (b || 0), 0))); }
    return out;
  }
  async function draw() {
    if (!tr || !kind) return;
    const k = D.kp[kind]; let x, y, tgt = null, name = 'Actual', type = 'line';
    if (range === 'day') { x = D.days.map(dlab); y = k.daily; tgt = k.target; }
    else if (range === 'week') { const w = weekly(D.days, k.daily); x = w.x; y = w.y; tgt = k.target != null ? Math.round(k.target * 7) : null; type = 'bar'; }
    else {
      if (!monthCache[kind]) { tr.showLoading({ text: '', maskColor: 'transparent', color: k.color }); try {
        const r = await fetch(`api/trend?kind=${kind}&factory=${D.fid || ''}&month=${D.month}`); monthCache[kind] = await r.json(); } catch (e) { monthCache[kind] = { months: [], values: [] }; } tr.hideLoading(); }
      x = monthCache[kind].months; y = monthCache[kind].values; type = 'bar';
    }
    const series = [{ name, type, data: y, smooth: type === 'line', symbol: 'none', barMaxWidth: 26, lineStyle: { width: 2.5, color: k.color }, itemStyle: { color: k.color, borderRadius: type === 'bar' ? [4, 4, 0, 0] : 0 },
      areaStyle: type === 'line' ? { color: k.color, opacity: 0.1 } : undefined }];
    if (tgt != null) series.push({ name: 'Target', type: 'line', data: x.map(() => tgt), symbol: 'none', lineStyle: { width: 2, type: 'dashed', color: T.s[2] }, itemStyle: { color: T.s[2] } });
    tr.setOption({ ...base, grid: { left: 8, right: 14, top: 30, bottom: 4, containLabel: true },
      legend: { top: 0, right: 0, icon: 'roundRect', itemWidth: 14, itemHeight: 3, textStyle: { color: T.muted } },
      tooltip: { ...tip, trigger: 'axis', formatter: (ps) => `<b>${ps[0].axisValue}</b><br>` + ps.map((p) => `${p.marker} ${p.seriesName}: <b>${fmt(p.value, 1)}</b> ${k.unit}`).join('<br>') },
      xAxis: { type: 'category', data: x, boundaryGap: type === 'bar', axisLine: { lineStyle: { color: T.axis } }, axisTick: { show: false }, axisLabel: { color: T.muted, fontSize: 11 } },
      yAxis: { type: 'value', axisLabel: { color: T.muted, fontSize: 11, formatter: (q) => fmt(q) }, splitLine: { lineStyle: { color: T.grid } } }, series }, true);
  }
  document.querySelectorAll('#crKind button').forEach((b) => b.addEventListener('click', () => {
    document.querySelectorAll('#crKind button').forEach((x) => x.classList.toggle('on', x === b)); kind = b.dataset.k; draw();
    document.dispatchEvent(new CustomEvent('cr:kind', { detail: { kind } })); }));
  document.querySelectorAll('#crRange button').forEach((b) => b.addEventListener('click', () => {
    document.querySelectorAll('#crRange button').forEach((x) => x.classList.toggle('on', x === b)); range = b.dataset.r; draw(); }));
  draw();
  // v0.99.40 กดที่กราฟ → ดูข้อมูลต้นทาง: วัน → รายงานรายวัน (รายมิเตอร์) · สัปดาห์ → วันแรกของสัปดาห์ · เดือน → Dashboard เดือนนั้น
  const qs = (o) => Object.entries(o).filter(([, x]) => x !== '' && x != null).map(([a, b]) => a + '=' + encodeURIComponent(b)).join('&');
  if (tr) tr.getZr().on('click', (e) => {
    const pt = [e.offsetX, e.offsetY];
    if (!tr.containPixel('grid', pt)) return;
    const i = Math.round(tr.convertFromPixel({ seriesIndex: 0 }, pt)[0]);
    if (range === 'month') { const m = ((monthCache[kind] || {}).months || [])[i]; if (m) location = D.url_dash + '?' + qs({ factory: D.fid || '', month: '20' + m.slice(3, 5) + '-' + m.slice(0, 2) }); return; }
    const day = D.days[range === 'week' ? i * 7 : i];
    if (!day) return;
    if (document.getElementById('crDrill')) {                // v0.99.45 เจาะดูวันนั้นทุก 15 นาทีในหน้านี้เลย
      document.dispatchEvent(new CustomEvent('cr:day', { detail: { day, kind } })); return; }
    location = D.url_daily + '?' + qs({ day, factory: D.fid || '', kind });
  });
  if (tr) tr.getZr().on('mousemove', (e) => { tr.getZr().setCursorStyle(tr.containPixel('grid', [e.offsetX, e.offsetY]) ? 'pointer' : 'default'); });

  // ── โดนัท ──
  const dn = mk('crDonut');
  if (dn && D.donut.length) {
    const tot = D.donut.reduce((a, b) => a + b.value, 0);
    dn.setOption({ ...base, tooltip: { ...tip, formatter: (p) => `${p.marker} ${p.name}: <b>${fmt(p.value)}</b> kWh (${p.percent}%)` },
      legend: { orient: 'vertical', right: 0, top: 'middle', icon: 'circle', itemWidth: 9, itemHeight: 9, textStyle: { color: T.ink, fontSize: 12 },
        formatter: (n) => { const it = D.donut.find((x) => x.name === n); return `${n}  ${it ? Math.round(100 * it.value / tot) : 0}%`; } },
      graphic: [{ type: 'text', left: '30%', top: '40%', style: { text: tot >= 1e6 ? (tot / 1e6).toFixed(2) + ' M' : fmt(tot), fill: T.ink, font: `700 18px ${T.font}`, textAlign: 'center' } },
        { type: 'text', left: '30%', top: '54%', style: { text: 'kWh', fill: T.muted, font: `12px ${T.font}`, textAlign: 'center' } }],
      series: [{ type: 'pie', radius: ['52%', '78%'], center: ['30%', '50%'], avoidLabelOverlap: true, label: { show: false },
        itemStyle: { borderColor: T.surface, borderWidth: 2 }, data: D.donut.map((d, i) => ({ ...d, itemStyle: { color: T.s[i % T.s.length] } })) }] });
    dn.on('click', (p) => { if (p.name && p.name !== 'อื่น ๆ') location = D.url_dash + '?' + qs({ factory: D.fid || '', month: D.month, loc: p.name === 'ไม่ระบุพื้นที่' ? '-' : p.name }); });
  }
  // ── เทียบโรงงาน ──
  const cp = mk('crCmp');
  if (cp && D.cmp.length) {
    cp.setOption({ ...base, grid: { left: 8, right: 8, top: 30, bottom: 4, containLabel: true },
      legend: { top: 0, right: 0, icon: 'roundRect', itemWidth: 12, itemHeight: 10, textStyle: { color: T.muted } },
      tooltip: { ...tip, trigger: 'axis', axisPointer: { type: 'shadow' }, formatter: (ps) => `<b>${ps[0].axisValue}</b><br>` + ps.map((p) => `${p.marker} ${p.seriesName}: <b>${fmt(p.value)}</b> kWh`).join('<br>') },
      xAxis: { type: 'category', data: D.cmp.map((x) => x.name), axisLine: { lineStyle: { color: T.axis } }, axisTick: { show: false }, axisLabel: { color: T.muted, fontSize: 11 } },
      yAxis: { type: 'value', axisLabel: { color: T.muted, fontSize: 11, formatter: (q) => fmt(q) }, splitLine: { lineStyle: { color: T.grid } } },
      series: [{ name: 'เดือนนี้', type: 'bar', data: D.cmp.map((x) => x.cur), barMaxWidth: 26, itemStyle: { color: T.s[0], borderRadius: [4, 4, 0, 0] } },
        { name: 'เดือนก่อน', type: 'bar', data: D.cmp.map((x) => x.prev), barMaxWidth: 26, itemStyle: { color: T.axis, borderRadius: [4, 4, 0, 0] } }] });
    cp.on('click', (p) => { const f = D.cmp[p.dataIndex]; if (f && f.id) location = D.url_dash + '?' + qs({ factory: f.id, month: D.month }); });
  }
  window.addEventListener('resize', () => charts.forEach((c) => c.resize()));
})();
