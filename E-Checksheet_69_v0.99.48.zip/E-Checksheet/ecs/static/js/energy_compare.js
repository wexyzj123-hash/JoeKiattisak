/* energy_compare.js — v0.99.45 เปรียบเทียบก่อน–หลัง: กราฟโหลดเฉลี่ยทุก 15 นาที A vs B + แท่งส่วนต่าง + แรเงานอกเวลางาน */
(function () {
  'use strict';
  const el = document.getElementById('cp-data'), box = document.getElementById('cpProf');
  if (!el || !box || !window.echarts) return;
  const D = JSON.parse(el.textContent);
  const cs = getComputedStyle(document.documentElement);
  const v = (n, d) => (cs.getPropertyValue(n).trim() || d);
  const T = { grid: v('--viz-grid', '#e5e7eb'), axis: v('--viz-axis', '#cbd5e1'), muted: v('--muted', '#64748b'), ink: v('--text', '#0f172a'),
    surface: v('--surface', '#fff'), ok: v('--ok', '#0ca30c'), ng: v('--ng', '#d03b3b'), font: getComputedStyle(document.body).fontFamily };
  const fmt = (x) => x == null ? '–' : Number(x).toLocaleString('th-TH', { maximumFractionDigits: 2 });
  const [ws, we] = D.work.split('–');
  const idx = (hm) => { const [h, m] = hm.split(':').map(Number); return Math.min(95, Math.floor((h * 60 + m) / 15)); };
  const offAreas = [];
  if (idx(ws) > 0) offAreas.push([{ xAxis: 0 }, { xAxis: idx(ws) - 1 }]);
  if (idx(we) <= 95 && we !== '24:00') offAreas.push([{ xAxis: idx(we) }, { xAxis: 95 }]);
  const c = echarts.init(box, null, { renderer: 'canvas' });
  const diff = D.b.map((b, i) => Math.round((b - D.a[i]) * 1000) / 1000);
  c.setOption({ backgroundColor: 'transparent', textStyle: { fontFamily: T.font, color: T.ink }, animationDuration: 250,
    grid: { left: 8, right: 14, top: 34, bottom: 4, containLabel: true }, legend: { top: 0, right: 0, textStyle: { color: T.muted } },
    tooltip: { trigger: 'axis', backgroundColor: T.surface, borderColor: T.axis, textStyle: { color: T.ink },
      formatter: (ps) => `<b>${ps[0].axisValue}</b><br>` + ps.map((p) => `${p.marker} ${p.seriesName}: <b>${fmt(p.value && p.value.value != null ? p.value.value : p.value)}</b> ${D.unit}`).join('<br>') },
    xAxis: { type: 'category', data: D.slots, axisLabel: { color: T.muted, interval: 7 }, axisLine: { lineStyle: { color: T.axis } }, axisTick: { show: false } },
    yAxis: { type: 'value', name: D.unit + '/15 นาที', nameTextStyle: { color: T.muted }, axisLabel: { color: T.muted }, splitLine: { lineStyle: { color: T.grid } } },
    series: [
      { name: 'ส่วนต่าง B−A', type: 'bar', barMaxWidth: 8, data: diff.map((d) => ({ value: d, itemStyle: { color: d <= 0 ? T.ok : T.ng, opacity: 0.7 } })), itemStyle: { color: T.ok },
        markArea: { silent: true, itemStyle: { color: 'rgba(100,116,139,0.10)' }, label: { show: false }, data: offAreas } },
      { name: D.la, type: 'line', data: D.a, showSymbol: false, lineStyle: { color: '#94a3b8', width: 1.8, type: 'dashed' }, itemStyle: { color: '#94a3b8' } },
      { name: D.lb, type: 'line', data: D.b, showSymbol: false, lineStyle: { color: D.color, width: 2.6 }, itemStyle: { color: D.color } }] });
  window.addEventListener('resize', () => c.resize());
})();
