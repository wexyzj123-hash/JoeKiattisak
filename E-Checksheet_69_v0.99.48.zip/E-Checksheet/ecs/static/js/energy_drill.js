/* energy_drill.js — v0.99.45 หน้าภาพรวม: เจาะดูรายวันทุก 15 นาที (#crDrill) + ใช้ลด/เพิ่มตรงไหน เดือนนี้ vs เดือนก่อน (#crShape)
 * ข้อมูลจาก /energy/api/drill และ /energy/api/shape · ประเภทตามปุ่มในกราฟแนวโน้ม · กดกราฟแนวโน้ม / Heatmap → เปลี่ยนวันที่เจาะดู */
(function () {
  'use strict';
  const el = document.getElementById('cr-data'), box = document.getElementById('crDrill');
  if (!el || !box || !window.echarts) return;
  const D = JSON.parse(el.textContent);
  const cs = getComputedStyle(document.documentElement);
  const v = (n, d) => (cs.getPropertyValue(n).trim() || d);
  const T = { grid: v('--viz-grid', '#e5e7eb'), axis: v('--viz-axis', '#cbd5e1'), muted: v('--muted', '#64748b'), ink: v('--text', '#0f172a'),
    surface: v('--surface', '#fff'), ok: v('--ok', '#0ca30c'), ng: v('--ng', '#d03b3b'), cmp: '#94a3b8', font: getComputedStyle(document.body).fontFamily };
  const bg = (getComputedStyle(document.body).backgroundColor.match(/\d+/g) || [255, 255, 255]).map(Number);
  const dark = (0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]) < 128;
  const fmt = (x, d) => x == null ? '–' : Number(x).toLocaleString('th-TH', { maximumFractionDigits: d == null ? (Math.abs(x) >= 100 ? 0 : 1) : d });
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const dm = (iso) => iso ? iso.slice(8, 10) + '/' + iso.slice(5, 7) : '–';
  const pct = (p) => p == null ? '' : `<em class="${p > 0 ? 'dd-up' : 'dd-down'}">${p > 0 ? '▲' : '▼'} ${Math.abs(p)}%</em>`;
  const sgn = (x) => x == null ? '–' : `<span class="${x > 0 ? 'dd-up' : (x < 0 ? 'dd-down' : '')}">${x > 0 ? '+' : ''}${fmt(x)}</span>`;
  const base = { backgroundColor: 'transparent', textStyle: { fontFamily: T.font, color: T.ink }, animationDuration: 250 };
  const tip = { backgroundColor: T.surface, borderColor: T.axis, textStyle: { color: T.ink, fontFamily: T.font } };
  const mk = (id) => { const e = document.getElementById(id); return e ? echarts.init(e, null, { renderer: 'canvas' }) : null; };
  const cDay = mk('ddChart'), cProf = mk('shProfile'), cHeat = mk('shHeat');
  const dayI = document.getElementById('ddDay'), cmpS = document.getElementById('ddCmp');
  let kind = Object.keys(D.kp || {})[0] || 'elec', res = 15, P = null;
  const q = (o) => Object.entries(Object.assign({ kind, factory: D.fid || '', loc: D.loc || '', project: D.project || '', line: D.line || '' }, o))
    .filter(([, x]) => x !== '' && x != null).map(([a, b]) => a + '=' + encodeURIComponent(b)).join('&');

  // ── เจาะดูรายวัน ──
  function drawDay() {
    if (!P || !cDay) return;
    const hourly = res === 60 || !P.has15;
    const x = hourly ? P.hours.map((h) => h.h + ':00') : P.slots;
    const cur = hourly ? P.hours.map((h) => h.v) : P.v, prv = hourly ? P.hours.map((h) => h.c) : P.c;
    const r = hourly ? 1 : P.rate;
    cDay.setOption({ ...base, grid: { left: 8, right: 14, top: 30, bottom: 4, containLabel: true },
      legend: { top: 0, right: 0, textStyle: { color: T.muted } },
      tooltip: { ...tip, trigger: 'axis', valueFormatter: (y) => y == null ? 'ไม่มีค่า' : `${fmt(y, 2)} ${P.unit}` + (P.unit !== P.rate_unit ? ` (${fmt(y * r, 1)} ${P.rate_unit})` : '') },
      xAxis: { type: 'category', data: x, axisLabel: { color: T.muted, interval: hourly ? 1 : 7 }, axisLine: { lineStyle: { color: T.axis } }, axisTick: { show: false } },
      yAxis: { type: 'value', name: P.unit + (hourly ? '/ชม.' : '/15 นาที'), nameTextStyle: { color: T.muted }, axisLabel: { color: T.muted }, splitLine: { lineStyle: { color: T.grid } } },
      series: [{ name: dm(P.day), type: 'bar', data: cur, itemStyle: { color: P.color, borderRadius: [2, 2, 0, 0] }, barMaxWidth: 18 },
               { name: dm(P.cmp_day) + (P.cmp === 'yday' ? ' (เมื่อวาน)' : ' (สัปดาห์ก่อน)'), type: 'line', data: prv, showSymbol: hourly, smooth: false,
                 lineStyle: { color: T.cmp, type: 'dashed', width: 1.8 }, itemStyle: { color: T.cmp } }] }, true);
  }
  function kpis() {
    const k = document.getElementById('ddK');
    const cell = (lbl, val, sub) => `<div><span>${lbl}</span><b>${val}</b>${sub ? `<i>${sub}</i>` : ''}</div>`;
    k.innerHTML = cell(`${esc(P.th)} วันที่ ${dm(P.day)}${P.upto && P.upto !== '24:00' ? ' (00:00–' + esc(P.upto) + ')' : ''}`, `${fmt(P.sum)} <small>${esc(P.unit)}</small>`,
        `${pct(P.pct)} ${P.cmp === 'yday' ? 'เมื่อวาน' : 'สัปดาห์ก่อน'} ${fmt(P.cmp_sum)}`) +
      (P.has15 ? cell('สูงสุด', `${fmt(P.peak)} <small>${esc(P.rate_unit)}</small>`, `เวลา ${esc(P.peak_at || '–')}`) +
        cell('โหลดพื้นฐานกลางคืน (00–06)', `${fmt(P.base)} <small>${esc(P.rate_unit)}</small>`, P.base_c != null ? `เทียบ ${fmt(P.base_c)} ${pct(P.base_c ? Math.round(1000 * (P.base - P.base_c) / P.base_c) / 10 : null)}` : '') +
        cell(`ในเวลางาน ${esc(P.work_lbl)}`, `${fmt(P.work)} <small>${esc(P.unit)}</small>`, P.work_c != null ? `เทียบ ${fmt(P.work_c)}` : '') +
        cell('นอกเวลางาน', `${fmt(P.off)} <small>${esc(P.unit)}</small>`, P.off_c != null ? `เทียบ ${fmt(P.off_c)}` : '') : '');
  }
  function table() {
    document.getElementById('ddH1').textContent = dm(P.day);
    document.getElementById('ddH2').textContent = dm(P.cmp_day);
    document.querySelector('#ddTbl tbody').innerHTML = P.meters.map((m) => `<tr><td><a href="${esc(m.url)}">${esc(m.name)}</a>${m.via === 'day' ? ' <small class="muted">(ค่ารายวัน)</small>' : ''}</td>
      <td class="num"><b>${fmt(m.u)}</b></td><td class="num muted">${fmt(m.c)}</td><td class="num">${sgn(m.diff)}</td><td class="num">${pct(m.pct)}</td>
      <td class="small"><a href="${esc(m.url)}">กราฟ 15 นาที</a>${m.raw ? ` · <a href="${esc(m.raw)}">ข้อมูลดิบ SQL</a>` : ''}</td></tr>`).join('') ||
      '<tr><td colspan="6" class="muted">ไม่มีข้อมูลของวันนี้</td></tr>';
  }
  async function loadDay() {
    const note = document.getElementById('ddNote');
    note.textContent = 'กำลังโหลด…';
    try {
      const r = await fetch(D.url_drill + '?' + q({ day: dayI.value, cmp: cmpS.value }), { credentials: 'same-origin' });
      P = await r.json();
      kpis(); drawDay(); table();
      document.getElementById('ddDaily').href = P.url_daily; document.getElementById('ddLive').href = P.url_live;
      const cl = document.getElementById('ddCmpLink');
      if (cl) cl.href = D.url_compare + '?' + q({ a_from: P.cmp_day, a_to: P.cmp_day, b_from: P.day, b_to: P.day }).replace(/(^|&)loc=/, '$1grp=');
      note.textContent = P.has15 ? `ข้อมูลทุก ${P.res} นาทีจาก SCADA · มิเตอร์ที่นับ ${P.n_meters} ตัว (ไม่นับซ้ำมิเตอร์หลัก)` :
        'ยังไม่มีค่าราย 15 นาทีของวันนี้ — แสดงยอดรายวันจากค่าอ่านมิเตอร์แทน (ผูก Tag SCADA ให้มิเตอร์เพื่อดูรายช่วงเวลา)';
    } catch (e) { note.textContent = 'โหลดไม่สำเร็จ — ลองใหม่อีกครั้ง'; }
  }
  dayI.addEventListener('change', loadDay); cmpS.addEventListener('change', loadDay);
  document.querySelectorAll('[data-dd-step]').forEach((b) => b.addEventListener('click', () => {
    const d = new Date(dayI.value + 'T00:00:00'); d.setDate(d.getDate() + (+b.dataset.ddStep));
    const iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    if (dayI.max && iso > dayI.max) return; dayI.value = iso; loadDay(); }));
  document.querySelectorAll('#ddRes button').forEach((b) => b.addEventListener('click', () => {
    document.querySelectorAll('#ddRes button').forEach((x) => x.classList.toggle('on', x === b)); res = +b.dataset.r; drawDay(); }));
  document.addEventListener('cr:day', (e) => { dayI.value = e.detail.day; if (e.detail.kind && e.detail.kind !== kind) { kind = e.detail.kind; loadShape(); }
    loadDay(); box.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
  document.addEventListener('cr:kind', (e) => { kind = e.detail.kind; loadDay(); loadShape(); });

  // ── ใช้ลด / เพิ่มตรงไหน ──
  async function loadShape() {
    const note = document.getElementById('shNote');
    note.textContent = 'กำลังโหลด…';
    let S;
    try { S = await (await fetch(D.url_shape + '?' + q({ month: D.month }), { credentials: 'same-origin' })).json(); }
    catch (e) { note.textContent = 'โหลดไม่สำเร็จ'; return; }
    document.getElementById('shSub').textContent = `${S.th} · ${S.m_lbl} (${S.range}) vs ${S.p_lbl} (${S.p_range}) · รวม ${fmt(S.tot_cur)} vs ${fmt(S.tot_prev)} ${S.unit}`;
    const sl = document.getElementById('shCmpLink');
    if (sl && S.heat_days.length) {
      const p0 = S.month.slice(0, 8), pm = new Date(S.month + 'T00:00:00'); pm.setMonth(pm.getMonth() - 1);
      const pIso = (dd) => pm.getFullYear() + '-' + String(pm.getMonth() + 1).padStart(2, '0') + '-' + String(dd).padStart(2, '0');
      const last = +S.range.split('–')[1];
      sl.href = D.url_compare + '?' + q({ a_from: pIso(1), a_to: pIso(+S.p_range.split('–')[1]), b_from: p0 + '01', b_to: p0 + String(last).padStart(2, '0') }).replace(/(^|&)loc=/, '$1grp=');
    }
    document.getElementById('shBands').innerHTML = S.bands.map((b) => `<div class="${b.diff == null ? '' : (b.diff < 0 ? 'down' : 'up')}">
      <span>${esc(b.th)} ${esc(b.lbl)} น. · เฉลี่ยต่อวัน</span><b>${fmt(b.cur)}</b> <small>${esc(S.unit)}</small>
      <span>เดือนก่อน ${fmt(b.prev)} · ${b.diff == null ? 'ยังเทียบไม่ได้' : sgn(b.diff) + ' ' + pct(b.pct)}</span></div>`).join('');
    const hrs = [...Array(24).keys()].map((h) => String(h).padStart(2, '0'));
    if (cProf) cProf.setOption({ ...base, grid: { left: 8, right: 14, top: 30, bottom: 4, containLabel: true }, legend: { top: 0, right: 0, textStyle: { color: T.muted } },
      tooltip: { ...tip, trigger: 'axis', valueFormatter: (y) => y == null ? '–' : `${fmt(y, 1)} ${S.unit}` },
      xAxis: { type: 'category', data: hrs.map((h) => h + ':00'), axisLabel: { color: T.muted, interval: 2 }, axisLine: { lineStyle: { color: T.axis } }, axisTick: { show: false } },
      yAxis: { type: 'value', axisLabel: { color: T.muted }, splitLine: { lineStyle: { color: T.grid } } },
      series: [{ name: 'ส่วนต่าง (เขียว ลด · แดง เพิ่ม)', type: 'bar', itemStyle: { color: T.ok }, data: S.diff.map((d) => d == null ? null : { value: d, itemStyle: { color: d < 0 ? T.ok : T.ng, opacity: 0.75 } }), barMaxWidth: 14 },
               { name: S.m_lbl, type: 'line', data: S.avg_cur, showSymbol: false, lineStyle: { color: S.color, width: 2.5 }, itemStyle: { color: S.color } },
               { name: S.p_lbl, type: 'line', data: S.avg_prev, showSymbol: false, lineStyle: { color: T.cmp, width: 1.8, type: 'dashed' }, itemStyle: { color: T.cmp } }] }, true);
    if (cHeat) {
      const mx = Math.max(1, ...S.heat.map((x) => x[2]));
      cHeat.setOption({ ...base, grid: { left: 8, right: 14, top: 8, bottom: 40, containLabel: true },
        tooltip: { ...tip, formatter: (p) => `${dm(S.heat_days[p.value[1]])} · ${hrs[p.value[0]]}:00–${String(p.value[0] + 1).padStart(2, '0')}:00<br><b>${fmt(p.value[2], 1)}</b> ${S.unit} — กดเพื่อเจาะดูวันนี้` },
        xAxis: { type: 'category', data: hrs, axisLabel: { color: T.muted, interval: 2 }, splitArea: { show: false } },
        yAxis: { type: 'category', data: S.heat_days.map(dm), inverse: true, axisLabel: { color: T.muted, interval: 1, fontSize: 10 } },
        visualMap: { min: 0, max: mx, calculable: false, orient: 'horizontal', left: 'center', bottom: 0, itemHeight: 120, textStyle: { color: T.muted },
          inRange: { color: [dark ? '#1e293b' : '#eef2f7', S.color] } },
        series: [{ type: 'heatmap', data: S.heat, emphasis: { itemStyle: { borderColor: T.ink, borderWidth: 1 } } }] }, true);
      cHeat.off('click');
      cHeat.on('click', (p) => { const d = S.heat_days[p.value[1]]; if (d) document.dispatchEvent(new CustomEvent('cr:day', { detail: { day: d, kind } })); });
    }
    const rows = (lst) => lst.map((m) => `<tr><td><a href="${esc(m.url)}">${esc(m.name)}</a></td><td class="num">${fmt(m.u)}</td><td class="num muted">${fmt(m.p)}</td>
      <td class="num">${sgn(m.diff)} ${pct(m.pct)}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">ไม่มี</td></tr>';
    document.querySelector('#shDown tbody').innerHTML = rows(S.downs);
    document.querySelector('#shUp tbody').innerHTML = rows(S.ups);
    const gone = document.getElementById('shGone');
    if (gone) gone.innerHTML = S.n_gone ? `<b>⚠ มิเตอร์ที่เดือนนี้ไม่มีค่าเลย ${S.n_gone} ตัว</b> (ไม่นับเป็น “ลดได้” — ตรวจการดึงข้อมูล): ` +
      S.gone.map((m) => `<a href="${esc(m.url)}">${esc(m.name)}</a>`).join(' · ') : '';
    note.textContent = (S.n_cur ? `ค่าราย 15 นาที: เดือนนี้ ${S.n_cur} วัน · เดือนก่อน ${S.n_prv} วัน` : 'ยังไม่มีค่าราย 15 นาที — โปรไฟล์รายชั่วโมง / Heatmap จะขึ้นเมื่อมิเตอร์ผูก Tag SCADA') +
      ' · ตารางมิเตอร์ใช้ยอดจากค่าอ่านรายวัน (ช่วงวันที่เดียวกันของสองเดือน)';
  }
  loadDay(); loadShape();
  window.addEventListener('resize', () => [cDay, cProf, cHeat].forEach((c) => c && c.resize()));
})();
