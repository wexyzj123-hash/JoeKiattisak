"""ecs/views/energy_cost.py — ศูนย์ต้นทุนพลังงาน (v0.67)

/energy/cost/?tab=alloc   ② ปันส่วนค่าไฟตามบิล (พื้นที่ × เดือน = บิลพอดี)
/energy/cost/?tab=daily   ① ประจำวัน → แยกพื้นที่ + ค่าไฟประมาณ
/energy/cost/?tab=em      ③ Energy management — 3 โรงงาน เทียบยอดผลิต/ยอดขาย
/energy/cost/?tab=meters  หน่วยรายเดือนต่อมิเตอร์ (ที่มา: ประจำวัน/นำเข้า/กรอกเอง) — แก้ได้
/energy/cost/?tab=setup   พื้นที่ · สูตรเชื่อมมิเตอร์ (ตัวคูณ) · รายการผลิต · ยอดผลิต/ขาย/วันทำงาน · วิธีปันส่วน
/energy/cost/import       นำเข้าไฟล์ Energy management (ย้อนหลังปี) แบบดูก่อนยืนยัน
"""
from __future__ import annotations

import os

from flask import Blueprint, Response, flash, redirect, render_template, request, url_for

from .. import energy as EN
from .. import energy_cost as C
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import ValidationError, now_dt
from .. import energy_struct as ST
from .energy import _ctx, _is_lead, _load_tmp, _month, _save_tmp, _sf

bp = Blueprint("energy_cost", __name__, url_prefix="/energy/cost")
LEAD = ("admin", "supervisor")
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


@bp.before_request
def _ensure():
    from flask import session
    if "user_id" in session:
        EN.ensure(get_db())


def _fid(db, arg=None) -> int | None:
    facs = M.list_factories(db)
    fid = request.args.get("factory", type=int) if arg is None else arg
    ids = [f["id"] for f in facs]
    if fid in ids:
        return fid
    # v0.99.46 โรงงานที่มีค่าไฟล่าสุด (เดิม: โรงงานแรกเสมอ แม้ไม่มีข้อมูล)
    from .energy import _default_fk
    return _default_fk(db, None, "elec")[0] if ids else None


def _year() -> int:
    y = request.values.get("year", type=int)
    return y if y and 2000 <= y <= 2100 else now_dt().year


@bp.route("/")
@require_role(*ALL_ROLES)
def home():
    db = get_db()
    tab = request.args.get("tab") if request.args.get("tab") in ("alloc", "daily", "em", "meters", "setup") else "alloc"
    year = _year()
    fid = _fid(db)
    ctx = {"tab": tab, "year": year, "fid": fid, "can_edit": _is_lead(), "G": C.GROUPS, "DRV": C.DRIVERS, "MTH": C.METHODS,
           "BASIS": C.BASIS, "TH_M": C.TH_M}
    sf = _sf()
    filt = bool(sf["project_id"] or sf["grp"] or sf["line"])
    fc = {"projects": [], "sections": [], "lines": []}
    ok_areas = None
    if fid and tab in ("alloc", "daily", "meters"):
        ems = C.elec_meters(db, fid)
        fc = ST.facets(ems)
        if sf["grp"]:
            fc["lines"] = [x for x in fc["lines"] if x["section"] == ("" if sf["grp"] == "-" else sf["grp"])]
        if filt:
            ids = {m["id"] for m in ST.apply_filter(ems, **sf)}
            lm0 = C.link_map(db, fid)
            ok_areas = {a for mid, lst in lm0.items() if mid in ids for a, _ in lst}
    ctx.update(sf=sf, fc=fc, filt=filt)
    if tab == "alloc" and fid:
        ctx["rc"] = C.reconcile(db, fid, year)
        if ok_areas is not None:
            ctx["rc"]["rows"] = [r for r in ctx["rc"]["rows"] if r["area"]["id"] in ok_areas]
            ctx["rc"]["has_unalloc"] = False
        ctx["view"] = request.args.get("view") if request.args.get("view") in ("kwh", "baht", "meas", "per") else "kwh"
        stack = {}
        for g, gl in C.GROUPS.items():
            rows = [r for r in ctx["rc"]["rows"] if r["area"]["grp"] == g]
            if rows:
                stack[gl] = [round(sum(r["baht"][i] or 0 for r in rows)) for i in range(12)]
        if ctx["rc"]["has_unalloc"]:
            stack["ส่วนต่าง"] = [round(x or 0) for x in ctx["rc"]["unalloc_baht"]]
        ctx["stack"] = stack
    elif tab == "daily" and fid:
        month = _month(request.args.get("month"))
        ctx["month"] = month
        ctx["dl"] = C.daily_areas(db, fid, month)
        if ok_areas is not None:
            ctx["dl"]["rows"] = [r for r in ctx["dl"]["rows"] if r["area"]["id"] in ok_areas]
            ctx["dl"]["total"] = [round(sum(r["vals"][i] or 0 for r in ctx["dl"]["rows"]), 2) for i in range(len(ctx["dl"]["days"]))]
            ctx["dl"]["grand"] = round(sum(ctx["dl"]["total"]), 2)
    elif tab == "em":
        ctx["ov"] = C.overview(db, year)
        ctx["ov_kwh"], ctx["ov_rate"] = {}, {}
        for F in ctx["ov"]["factories"]:
            k12, r12 = [None] * 12, [None] * 12
            for m in F["rc"]["months"]:
                k12[m["i"]], r12[m["i"]] = m["bill_kwh"], m["rate"]
            ctx["ov_kwh"][F["factory"]["name"]], ctx["ov_rate"][F["factory"]["name"]] = k12, r12
    elif tab == "meters" and fid:
        mm = C.meter_months(db, fid, year)
        lm = C.link_map(db, fid)
        names = {a["id"]: a["name"] for a in C.areas(db, fid)}
        ctx["mm"] = [dict(x, areas=[(names.get(a), f) for a, f in lm.get(mid, [])], mid=mid) for mid, x in mm.items()]
        if filt:
            keep = {m["id"] for m in ST.apply_filter(C.elec_meters(db, fid), **sf)}
            ctx["mm"] = [x for x in ctx["mm"] if x["mid"] in keep]
        ctx["only"] = request.args.get("only", "")
        if ctx["only"] == "unlinked":
            ctx["mm"] = [x for x in ctx["mm"] if not x["areas"] and x["meter"]["is_main"] == 0]
    elif tab == "setup" and fid:
        ctx["areas"] = C.areas(db, fid)
        ctx["items"] = C.items(db, fid)
        ctx["prod"] = C.prod_year(db, fid, year)
        ctx["cfg"] = C.fcfg(db, fid)
    return render_template("energy/cost.html", **_ctx(**ctx))


@bp.route("/area/<int:aid>", methods=["GET", "POST"])
@bp.route("/area/new", methods=["GET", "POST"])
@require_role(*ALL_ROLES)
def area_edit(aid=None):
    db = get_db()
    a = C.area(db, aid) if aid else None
    if aid and not a:
        flash("ไม่พบพื้นที่", "error")
        return redirect(url_for("energy_cost.home", tab="setup"))
    fid = a["factory_id"] if a else _fid(db, request.values.get("factory", type=int))
    year = _year()
    if request.method == "POST":
        if not _is_lead():
            flash("เฉพาะหัวหน้างาน/ผู้ดูแลระบบแก้สูตรได้", "error")
            return redirect(request.url)
        try:
            if request.form.get("act") == "delete" and aid:
                C.delete_area(db, aid, current_user_id())
                db.commit()
                flash("ลบพื้นที่แล้ว", "ok")
                return redirect(url_for("energy_cost.home", tab="setup", factory=fid, year=year))
            aid2 = C.save_area(db, fid, request.form, current_user_id(), aid)
            rows = []
            for mid in request.form.getlist("mid"):
                if request.form.get(f"on_{mid}"):
                    rows.append({"meter_id": mid, "factor": request.form.get(f"fx_{mid}") or "1", "note": request.form.get(f"nt_{mid}", "")})
            n = C.save_links(db, aid2, rows, current_user_id())
            db.commit()
            flash(f"บันทึกพื้นที่และสูตรแล้ว · มิเตอร์ {n} ตัว", "ok")
            return redirect(url_for("energy_cost.area_edit", aid=aid2, year=year))
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
    ms = C.elec_meters(db, fid) if fid else []
    cur = {l["meter_id"]: l for l in C.links(db, aid)} if aid else {}
    lm = C.link_map(db, fid) if fid else {}
    names = {x["id"]: x["name"] for x in C.areas(db, fid)} if fid else {}
    mm = C.meter_months(db, fid, year) if fid else {}
    for m in ms:
        m["link"] = cur.get(m["id"])
        m["other"] = [names.get(x) for x, _ in lm.get(m["id"], []) if x != aid]
        m["year_kwh"] = round(sum(v for v in (mm.get(m["id"]) or {}).get("kwh", []) if v), 1)
    ms.sort(key=lambda m: (0 if m["link"] else 1, m["grp"] or "", m["sort_no"] or 0, m["id"]))
    return render_template("energy/cost_area.html", **_ctx(a=a, fid=fid, year=year, ms=ms, items=C.items(db, fid) if fid else [],
                                                           G=C.GROUPS, DRV=C.DRIVERS, can_edit=_is_lead()))


@bp.route("/setup", methods=["POST"])
@require_role(*LEAD)
def setup_save():
    db = get_db()
    fid = _fid(db, request.form.get("factory", type=int))
    year = _year()
    act = request.form.get("act")
    try:
        if act == "cfg":
            C.save_config(db, fid, request.form, current_user_id())
            msg = "บันทึกวิธีปันส่วนแล้ว"
        elif act == "item":
            C.save_item(db, fid, request.form, current_user_id(), request.form.get("item_id", type=int))
            msg = "บันทึกรายการผลิตแล้ว"
        elif act == "item_del":
            C.delete_item(db, request.form.get("item_id", type=int) or 0, current_user_id())
            msg = "ลบรายการผลิตแล้ว"
        elif act == "grid":
            n = C.save_month_grid(db, fid, year, request.form, current_user_id())
            msg = f"บันทึกยอดผลิต/ยอดขาย/วันทำงานแล้ว ({n} ช่อง)"
        elif act == "sync_sections":                     # v0.90 สร้างพื้นที่จาก Section
            r = C.sync_sections(db, fid, current_user_id(), replace=request.form.get("replace") == "1")
            msg = f"สร้างพื้นที่จาก Section แล้ว: ใหม่ {r['new']} · ปรับสูตร {r['updated']} · คงเดิม {r['kept']}"
        elif act == "order":
            C.reorder_areas(db, fid, [int(x) for x in request.form.get("ids", "").split(",") if x.isdigit()], current_user_id())
            msg = "บันทึกลำดับพื้นที่แล้ว"
        else:
            raise ValidationError("คำสั่งไม่ถูกต้อง")
        db.commit()
        flash(msg, "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy_cost.home", tab="setup", factory=fid, year=year) + (request.form.get("anchor") or ""))


@bp.route("/month-usage", methods=["POST"])
@require_role(*LEAD)
def month_usage():
    db = get_db()
    fid = _fid(db, request.form.get("factory", type=int))
    year = _year()
    mid = request.form.get("meter_id", type=int) or 0
    m = EN.meter(db, mid)
    try:
        if not m or m["factory_id"] != fid:
            raise ValidationError("ไม่พบมิเตอร์")
        n = 0
        for mo in range(1, 13):
            k = f"m_{mo}"
            if k in request.form and request.form.get(f"o_{mo}", "") != request.form.get(k, ""):
                C.set_month_usage(db, mid, f"{year}-{mo:02d}", request.form.get(k), current_user_id(), request.form.get("note", ""))
                n += 1
        db.commit()
        flash(f"บันทึกหน่วยรายเดือน {n} เดือน · {EN.label(m)}" if n else "ไม่มีค่าที่เปลี่ยน", "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy_cost.home", tab="meters", factory=fid, year=year, only=request.form.get("only") or None) + f"#m{mid}")


@bp.route("/alloc.xlsx")
@require_role(*ALL_ROLES)
def alloc_xlsx():
    db = get_db()
    fid = _fid(db)
    year = _year()
    fac = next((f for f in M.list_factories(db) if f["id"] == fid), {"code": fid})
    return Response(C.cost_xlsx(db, fid, year), mimetype=XLSX,
                    headers={"Content-Disposition": f'attachment; filename="Cost_{fac.get("code") or fid}_{year}.xlsx"'})


@bp.route("/em.xlsx")
@require_role(*ALL_ROLES)
def em_xlsx():
    db = get_db()
    year = _year()
    return Response(C.em_xlsx(db, year), mimetype=XLSX,
                    headers={"Content-Disposition": f'attachment; filename="Energy_management_{year}.xlsx"'})


@bp.route("/import", methods=["GET", "POST"])
@require_role(*LEAD)
def import_em():
    db = get_db()
    facs = M.list_factories(db)
    year = _year()
    pv = None
    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename:
            flash("เลือกไฟล์ Excel ที่ต้องการนำเข้า", "error")
        elif not f.filename.lower().endswith((".xlsx", ".xlsm", ".xls")):
            flash("รองรับไฟล์ Excel (.xlsx / .xlsm / .xls)", "error")
        else:
            raw = f.read()
            if len(raw) > 40 * 1024 * 1024:
                flash("ไฟล์ใหญ่เกิน 40 MB", "error")
            else:
                try:
                    parsed = C.parse_em(raw, year, f.filename)
                    fmap = {}
                    for sh in parsed["sheets"]:
                        g = EN.guess(f"aisin{sh['idx']}", facs) if sh["idx"] > 0 else {"factory_id": None}
                        fmap[sh["idx"]] = g["factory_id"]
                    token = _save_tmp({"parsed": parsed, "filename": f.filename})
                    pv = {"token": token, "filename": f.filename, "year": year, "fmap": fmap,
                          "sheets": C.em_preview(db, parsed, fmap)}
                except ValidationError as exc:
                    # ไฟล์ประจำวัน (Daily_* / Electric used) → ส่งต่อไปตัวนำเข้าประจำวัน
                    if "ไม่พบชีตโรงงาน" in exc.errors[0]:
                        try:
                            EN.parse_file(raw, f.filename, year)
                        except Exception:  # noqa: BLE001
                            flash(exc.errors[0], "error")
                        else:
                            from .energy import import_page
                            f.stream.seek(0)
                            flash("ไฟล์นี้เป็นบันทึกประจำวัน — แสดงตัวอย่างในตัวนำเข้าข้อมูลประจำวัน", "ok")
                            return import_page()
                    else:
                        flash(exc.errors[0], "error")
                except Exception as exc:  # noqa: BLE001 — ไฟล์เสีย/xls อ่านไม่ได้
                    flash(f"อ่านไฟล์ไม่ได้: {exc}", "error")
    return render_template("energy/cost_import.html", **_ctx(pv=pv, year=year, TH_M=C.TH_M))


def _norm(parsed: dict) -> dict:
    """JSON ทำให้คีย์เดือนเป็นข้อความ → แปลงกลับเป็นตัวเลข"""
    def fx(d):
        return {int(k): v for k, v in (d or {}).items()}
    for sh in parsed["sheets"]:
        sh["bill"] = {k: fx(v) for k, v in sh["bill"].items()}
        sh["work_days"] = fx(sh.get("work_days"))
        sh["sales"] = fx(sh.get("sales"))
        for m in sh["meters"]:
            m["vals"] = fx(m["vals"])
        for it in sh["items"]:
            it["qty"] = fx(it["qty"])
    return parsed


@bp.route("/import/confirm", methods=["POST"])
@require_role(*LEAD)
def import_em_confirm():
    db = get_db()
    data, path = _load_tmp(request.form.get("token", ""))
    if not data:
        flash("ข้อมูลตัวอย่างหมดอายุ — อัปโหลดไฟล์ใหม่", "error")
        return redirect(url_for("energy_cost.import_em"))
    parsed = _norm(data["parsed"])
    ok = {f["id"] for f in M.list_factories(db)}
    fmap = {}
    for sh in parsed["sheets"]:
        v = request.form.get(f"f_{sh['idx']}", type=int)
        if v in ok:
            fmap[sh["idx"]] = v
    opts = {k: bool(request.form.get(k)) for k in ("bills", "meters", "areas", "prod", "areas_overwrite")}
    try:
        if not fmap:
            raise ValidationError("เลือกโรงงานปลายทางอย่างน้อย 1 ชีต")
        res = C.em_commit(db, parsed, fmap, opts, current_user_id())
        db.commit()
        if path and os.path.exists(path):
            os.remove(path)
        flash(f"นำเข้าแล้ว · บิล {res['bills']} เดือน · มิเตอร์ใหม่ {res['meters_new']} (จับคู่เดิม {res.get('meters_match', 0)}) · "
              f"หน่วยรายเดือน {res['usage']} ค่า · พื้นที่ใหม่ {res['areas']} · ยอดผลิต {res['prod']} ค่า", "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return redirect(url_for("energy_cost.import_em"))
    return redirect(url_for("energy_cost.home", tab="alloc", year=parsed["year"], factory=next(iter(fmap.values()))))

