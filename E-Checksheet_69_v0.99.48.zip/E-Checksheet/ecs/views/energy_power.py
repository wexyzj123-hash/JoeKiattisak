"""ecs/views/energy_power.py — v0.91 บริหารไฟฟ้า + ตรวจโครงสร้างมิเตอร์

/energy/power?tab=tou|demand|off|line|bill|pf|rate&factory=&month=   หน้าไฟฟ้า (TOU · Peak · นอกเวลา · kWh/หน่วยไลน์ · บิล · PF · อัตรา)
/energy/power/save (POST)                                            บันทึกอัตรา/ยอดผลิตรายไลน์
/energy/structure?factory=&kind=                                     ต้นไม้มิเตอร์ + สมดุล + คำแนะนำ CT · แก้หลายตัวพร้อมกัน
/energy/meters/<id>/params (POST)                                    Tag PF / kW / kVAR ของมิเตอร์
"""
from __future__ import annotations

from datetime import timedelta

from flask import Blueprint, Response, flash, redirect, render_template, request, url_for

from .. import energy as EN
from .. import energy_field as EF
from .. import energy_power as PW
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import ValidationError, now_dt
from .energy import LEAD, _ctx, _is_lead, _month

bp = Blueprint("energy_pw", __name__, url_prefix="/energy")
TABS = {"tou": "ค่าไฟ TOU", "demand": "Peak Demand", "off": "นอกเวลาผลิต", "line": "kWh/หน่วยผลิต", "bill": "บิล vs มิเตอร์",
        "pf": "PF / SCADA", "rate": "ตั้งค่าอัตรา"}


def _fid(db) -> int | None:
    """โรงงานที่ดู: ตามสิทธิ์ → ตามที่เลือก → (v0.99.43) โรงงานแรกที่มีข้อมูลไฟฟ้า (เดิม: โรงงานแรกเสมอ แม้ไม่มีข้อมูล → หน้าเป็น 0 ทั้งหมด)"""
    facs = M.list_factories(db)
    sc = EF.user_scope(db, current_user_id())
    fid = sc["factory_id"] or request.values.get("factory", type=int)
    if fid:
        return fid
    from .. import energy_interval as EI
    from .. import energy_profile as PR
    EI.ensure(db)
    PR.ensure(db)
    best, best_t = None, ""
    for f in facs:                                         # โรงงานที่มีข้อมูลไฟฟ้าล่าสุด (ค่าราย 15 นาที / ค่าอ่านรายวัน)
        t = db.execute("""SELECT MAX(x) FROM (
                            SELECT MAX(p.ts) AS x FROM en_profile p JOIN en_meters m ON m.id=p.meter_id WHERE m.factory_id=? AND m.kind='elec' AND m.active=1
                            UNION ALL SELECT MAX(i.ts) FROM en_intervals i JOIN en_meters m ON m.id=i.meter_id WHERE m.factory_id=? AND m.kind='elec' AND m.active=1
                            UNION ALL SELECT MAX(r.day) FROM en_readings r JOIN en_meters m ON m.id=r.meter_id WHERE m.factory_id=? AND m.kind='elec' AND m.active=1 AND r.value>0)""",
                       (f["id"], f["id"], f["id"])).fetchone()[0] or ""
        if t > best_t:
            best, best_t = f["id"], t
    return best or (facs[0]["id"] if facs else None)


def _asof(db, fid: int | None) -> dict:
    """v0.99.43 ข้อมูลของโรงงานนี้ถึงเมื่อไร: ค่าราย 15 นาทีล่าสุด · ค่าอ่านรายวันล่าสุด"""
    if not fid:
        return {}
    ids = [r[0] for r in db.execute("SELECT id FROM en_meters WHERE factory_id=? AND kind='elec' AND active=1", (fid,))]
    if not ids:
        return {}
    q = ",".join(str(i) for i in ids)
    t15 = max(filter(None, [db.execute(f"SELECT MAX(ts) FROM en_profile WHERE meter_id IN ({q})").fetchone()[0],
                            db.execute(f"SELECT MAX(ts) FROM en_intervals WHERE meter_id IN ({q})").fetchone()[0]]), default=None)
    day = db.execute(f"SELECT MAX(day) FROM en_readings WHERE meter_id IN ({q})").fetchone()[0]
    from ..services import parse_ts
    t = parse_ts(t15) if t15 else None
    return {"t15": t, "age": round((now_dt() - t).total_seconds() / 60) if t else None, "day": day}


@bp.route("/power")
@require_role(*ALL_ROLES)
def power():
    db = get_db()
    PW.ensure(db)
    from .. import energy_interval as EI
    from .. import energy_profile as PR
    EI.ensure(db)
    PR.ensure(db)
    tab = request.args.get("tab") if request.args.get("tab") in TABS else "tou"
    fid = _fid(db)
    month = _month(request.args.get("month"))
    year = request.args.get("year", type=int) or month.year
    ctx = {"tab": tab, "fid": fid, "month": month, "year": year, "TABS": TABS, "cfg": PW.tariff(db, fid) if fid else PW.DEFAULT_TARIFF,
           "prev": (month - timedelta(days=1)).replace(day=1), "nxt": (month + timedelta(days=32)).replace(day=1),
           "can_edit": _is_lead(), "alerts": PW.demand_alerts(db), "asof": _asof(db, fid), "today": now_dt().date(), "timedelta": timedelta}
    if tab in ("tou", "demand") and fid:
        ctx["t"] = PW.tou(db, fid, month)
    elif tab == "off" and fid:
        ctx["o"] = PW.offhours(db, fid, month)
    elif tab == "line" and fid:
        ctx["li"] = PW.intensity(db, fid, year)
    elif tab == "bill":
        ctx["bc"] = PW.bill_check(db, year)
    elif tab == "pf":
        d_to = now_dt().date()
        ctx["pf"] = PW.pf_report(db, fid, d_to - timedelta(days=29), d_to)
    return render_template("energy/power.html", **_ctx(**ctx))


@bp.route("/power/save", methods=["POST"])
@require_role(*LEAD)
def power_save():
    db = get_db()
    fid = _fid(db)
    act = request.form.get("act")
    year = request.form.get("year", type=int) or now_dt().year
    try:
        if not fid:
            raise ValidationError("เลือกโรงงาน")
        if act == "rate":
            PW.save_tariff(db, fid, request.form.to_dict(), current_user_id())
            msg, tab = "บันทึกอัตราค่าไฟ/ตั้งค่าแล้ว", "rate"
        elif act == "prod":
            n = PW.save_prod_grid(db, fid, year, request.form, current_user_id())
            msg, tab = f"บันทึกยอดผลิตรายไลน์แล้ว ({n} ช่อง)", "line"
        else:
            raise ValidationError("คำสั่งไม่ถูกต้อง")
        db.commit()
        flash(msg, "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        tab = "rate" if act == "rate" else "line"
    return redirect(url_for("energy_pw.power", tab=tab, factory=fid, year=year, month=request.form.get("month") or ""))


@bp.route("/structure", methods=["GET", "POST"])
@require_role(*ALL_ROLES)
def structure():
    db = get_db()
    fid = _fid(db)
    kind = request.values.get("kind") if request.values.get("kind") in EN.KINDS else "elec"
    days = request.values.get("days", type=int) if request.values.get("days") in ("7", "30", "60", "90") else 30
    if request.method == "POST":
        m0 = {"factory_id": fid}
        if not _is_lead() and not EF.can_touch(db, current_user_id(), m0):
            return render_template("error.html", code=403, message="ไม่มีสิทธิ์แก้ไขมิเตอร์ของโรงงานนี้"), 403
        try:
            n = PW.save_structure(db, fid, request.form, current_user_id())
            db.commit()
            flash(f"บันทึกโครงสร้างแล้ว ({n} มิเตอร์)", "ok")
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
        return redirect(url_for("energy_pw.structure", factory=fid, kind=kind, days=days))
    st = PW.structure(db, fid, kind, days) if fid else {"rows": []}
    opts = [dict(m, label=EN.label(m)) for m in EN.meters(db, fid, kind) if m["is_main"] in (0, 1)] if fid else []
    return render_template("energy/structure.html", **_ctx(st=st, fid=fid, kind=kind, days=days, opts=opts, ROLES=EN.ROLES,
                                                         can_edit=_is_lead() or EF.can_touch(db, current_user_id(), {"factory_id": fid})))


@bp.route("/meters/<int:mid>/params", methods=["POST"])
@require_role(*ALL_ROLES)
def meter_params(mid):
    db = get_db()
    m = EN.meter(db, mid)
    if not m or not EF.can_touch(db, current_user_id(), m):
        return render_template("error.html", code=403, message="ไม่มีสิทธิ์แก้ไขมิเตอร์นี้"), 403
    try:
        PW.save_param_tags(db, mid, request.form.to_dict(), current_user_id())
        db.commit()
        flash("บันทึก Tag PF / kW / kVAR แล้ว — ค่าจะเข้ามารอบดึง SCADA ถัดไป", "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy.meter_detail", mid=mid) + "#params")


@bp.route("/power.xlsx")
@require_role(*ALL_ROLES)
def power_xlsx():
    """สรุปไฟฟ้าของเดือน: TOU รายวัน · ช่วงสูงสุด · นอกเวลาผลิต"""
    import io

    from openpyxl import Workbook
    from openpyxl.styles import Font
    db = get_db()
    fid = _fid(db)
    month = _month(request.args.get("month"))
    t = PW.tou(db, fid, month)
    o = PW.offhours(db, fid, month)
    wb = Workbook()
    ws = wb.active
    ws.title = "TOU รายวัน"
    ws.append(["วันที่", "On-Peak kWh", "Off-Peak kWh", "kW สูงสุด", "เวลา"])
    for c in ws[1]:
        c.font = Font(bold=True)
    for d in t["per_day"]:
        ws.append([d["day"], d["on"], d["off"], d["peak"], d["peak_at"].strftime("%H:%M") if d["peak_at"] else None])
    ws2 = wb.create_sheet("ช่วงสูงสุด")
    ws2.append(["kW", "วันเวลา", "On-Peak"])
    for x in t["top"]:
        ws2.append([x["kw"], x["at"].strftime("%Y-%m-%d %H:%M"), "ใช่" if x["on"] else ""])
    ws3 = wb.create_sheet("นอกเวลาผลิต")
    ws3.append(["หน่วยงาน", "ไลน์", "kWh ทั้งหมด", "kWh นอกเวลา", "%", "โหลดพื้นฐาน kW", "บาท (ประมาณ)", "ข้อมูล"])
    for r in o["rows"]:
        ws3.append([r["grp"], r["line"], r["tot"], r["off"], r["pct"], r["base_kw"], r["baht"], r["src"]])
    bio = io.BytesIO()
    wb.save(bio)
    return Response(bio.getvalue(), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename=power_{fid}_{month:%Y-%m}.xlsx"})
