"""ecs/views/energy_summary.py — v0.88 รายงานสรุปแยก Project / Section / Line (เว็บ · PDF · Excel) + ตั้ง Target"""
from __future__ import annotations

from datetime import date, timedelta

from flask import Blueprint, current_app, flash, jsonify, redirect, render_template, request, url_for

from .. import energy as EN
from .. import energy_struct as ST
from .. import energy_summary as SM
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import ValidationError, now_dt
from .energy import _ctx

bp = Blueprint("energy_sum", __name__, url_prefix="/energy")
KINDS_OK = [k for k in EN.KIND_ORDER if k != "hours"]


def _period():
    today = now_dt().date()
    try:
        d1 = date.fromisoformat(request.args.get("from") or "")
        d2 = date.fromisoformat(request.args.get("to") or "")
        return min(d1, d2), min(max(d1, d2), today), "range"
    except ValueError:
        pass
    try:
        y, m = (int(x) for x in (request.args.get("month") or "").split("-"))
        first = date(y, m, 1)
    except (TypeError, ValueError):
        first = today.replace(day=1)
    last = (first.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
    return first, min(last, today) if first <= today else last, "month"


@bp.route("/summary")
@require_role(*ALL_ROLES)
def summary():
    db = get_db()
    kind = request.args.get("kind") if request.args.get("kind") in KINDS_OK else "elec"
    level = request.args.get("level") if request.args.get("level") in ("factory", "project", "grp", "line", "meter") else "project"
    fid = request.args.get("factory", type=int) or None
    project_id = request.args.get("project", type=int) or None
    grp = (request.args.get("grp") or "")[:80] or None
    fmt = request.args.get("format") if request.args.get("format") in ("pdf", "xlsx") else "html"
    d1, d2, mode = _period()
    try:
        rep = SM.summary(db, kind, level, d1, d2, fid, project_id, grp)
    except ValidationError as exc:
        flash(exc.errors[0], "error")
        return redirect(url_for("energy_sum.summary", kind=kind))
    facs = M.list_factories(db)
    fname = next((f["name"] for f in facs if f["id"] == fid), "ทุกโรงงาน")
    projs = ST.projects(db, True)
    scope = " · ".join(x for x in (fname, next((p["name"] for p in projs if p["id"] == project_id), "") if project_id else "",
                                   (grp if grp != "-" else "ไม่ระบุ Section") if grp else "") if x)
    title = f"รายงานสรุปการใช้{EN.KINDS[kind]['th']} แยก{rep['level_th']} — {scope}"
    tag = f"Energy-{kind}-{rep['level']}-{d1:%Y%m%d}-{d2:%Y%m%d}"
    if fmt == "xlsx":
        from .rep import _send
        return _send(SM.to_xlsx(rep, title), "xlsx", f"{tag}.xlsx")
    q = {k: v for k, v in request.args.items() if k != "format"}
    secs = sorted({m.get("grp") or "" for m in EN.meters(db, fid, kind, True)} - {""})
    html = render_template("energy/summary.html", **_ctx(
        rep=rep, kind=kind, level=level, fid=fid, project_id=project_id, grp=grp, d1=d1, d2=d2, mode=mode, title=title, scope=scope,
        facs=facs, projs=projs, secs=secs, kinds_ok=KINDS_OK, pdf=fmt == "pdf", q=q, printed=now_dt(),
        pdf_url=url_for("energy_sum.summary", format="pdf", **q), xlsx_url=url_for("energy_sum.summary", format="xlsx", **q),
        month_val=d1.strftime("%Y-%m"), actual=EN.actual_day(db)))
    if fmt == "pdf":
        from ..pdf import PdfError, html_to_pdf
        from .rep import _send
        try:
            return _send(html_to_pdf(html, timeout=180), "pdf", f"{tag}.pdf")
        except PdfError as exc:
            current_app.logger.error("PDF energy summary: %s", exc)
            flash(f"{exc} — เปิดฉบับเว็บแล้วกด 'พิมพ์' › 'บันทึกเป็น PDF' แทนได้", "error")
            return redirect(url_for("energy_sum.summary", **q))
    return html


@bp.route("/targets", methods=["GET", "POST"])
@require_role("admin", "supervisor")
def targets():
    db = get_db()
    SM.ensure(db)
    kind = request.values.get("kind") if request.values.get("kind") in KINDS_OK else "elec"
    level = request.values.get("level") if request.values.get("level") in ("factory", "project", "grp", "line") else "project"
    fid = request.values.get("factory", type=int) or None
    if request.method == "POST":
        f = request.form
        n = 0
        try:
            for i, key in enumerate(f.getlist("key")):
                old = f.get(f"old.{i}", "")
                new = (f.get(f"daily.{i}") or "").strip()
                note = f.get(f"note.{i}", "")
                if new == old and note == f.get(f"oldnote.{i}", ""):
                    continue
                SM.save_target(db, kind, fid, level, key, new, note, current_user_id())
                n += 1
            db.commit()
            flash(f"บันทึก Target แล้ว {n} รายการ" if n else "ไม่มีการเปลี่ยนแปลง", "ok")
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
        return redirect(url_for("energy_sum.targets", kind=kind, level=level, factory=fid))
    ref = now_dt().date()
    rows = SM.target_rows(db, kind, fid, level, ref)
    return render_template("energy/targets.html", **_ctx(rows=rows, kind=kind, level=level, fid=fid, facs=M.list_factories(db),
                                                       kinds_ok=KINDS_OK, pct=EN.settings(db).get("target_pct"), ref=ref))


@bp.route("/meters/<int:mid>/target", methods=["POST"])
@require_role("admin", "supervisor")
def meter_target(mid):
    db = get_db()
    m = EN.meter(db, mid)
    if not m:
        return redirect(url_for("energy.meters"))
    try:
        SM.save_target(db, m["kind"], m["factory_id"], "meter", str(mid), request.form.get("daily"), request.form.get("note", ""),
                       current_user_id())
        db.commit()
        flash("บันทึก Target ของมิเตอร์แล้ว" if (request.form.get("daily") or "").strip() else "ล้าง Target — ใช้ค่าอัตโนมัติ", "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy.meter_detail", mid=mid))


@bp.route("/meters/<int:mid>/profile.json")
@require_role(*ALL_ROLES)
def meter_profile(mid):
    """v0.88 ค่าทุก 15 นาทีของมิเตอร์ในวันที่เลือก + วันก่อนหน้า (สำหรับกราฟหน้ามิเตอร์)"""
    from datetime import datetime, time

    from .. import energy_live as LV
    db = get_db()
    m = EN.meter(db, mid)
    if not m:
        return jsonify({"error": "ไม่พบมิเตอร์"}), 404
    try:
        day = min(date.fromisoformat(request.args.get("day") or ""), now_dt().date())
    except ValueError:
        day = now_dt().date()
    cmp = "week" if request.args.get("cmp") == "week" else "yday"
    cday = day - timedelta(days=7 if cmp == "week" else 1)
    a, ca = datetime.combine(day, time(0, 0)), datetime.combine(cday, time(0, 0))
    cur = LV._sums(db, [mid], a, a + timedelta(days=1)).get(mid) or [None] * LV.NSLOT      # noqa: SLF001
    prev = LV._sums(db, [mid], ca, ca + timedelta(days=1)).get(mid) or [None] * LV.NSLOT    # noqa: SLF001
    res = LV._resolution(cur) if any(v is not None for v in cur) else LV.SLOT_MIN            # noqa: SLF001
    k = EN.KINDS.get(m["kind"], {})
    unit = m["unit"] or k.get("unit", "")
    vals = [v for v in cur if v is not None]
    pk = max(range(len(cur)), key=lambda i: cur[i] if cur[i] is not None else -1) if vals else None
    last = max((i for i, v in enumerate(cur) if v is not None), default=None)

    def hsum(arr, h):                                     # v0.99.41 รายชั่วโมง
        xs = [v for v in arr[h * 4:(h + 1) * 4] if v is not None]
        return round(sum(xs), 4) if xs else None
    hours = [{"h": f"{h:02d}:00", "v": hsum(cur, h), "c": hsum(prev, h), "n": sum(1 for v in cur[h * 4:(h + 1) * 4] if v is not None)}
             for h in range(24)]
    same = sum(v for i, v in enumerate(prev) if v is not None and last is not None and i <= last)
    if request.args.get("format") == "csv":               # v0.99.41 ส่งออกค่าราย 15 นาที
        import csv
        import io
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["เวลา", f"{day:%d/%m/%Y} ({unit})", f"{cday:%d/%m/%Y} ({unit})"])
        for i, lbl in enumerate(LV.slot_labels()):
            w.writerow([lbl, "" if cur[i] is None else round(cur[i], 4), "" if prev[i] is None else round(prev[i], 4)])
        return current_app.response_class("\ufeff" + buf.getvalue(), mimetype="text/csv; charset=utf-8",
                                          headers={"Content-Disposition": f"attachment; filename=meter{mid}_{day.isoformat()}_15min.csv"})
    return jsonify({"day": day.isoformat(), "cmp_day": cday.isoformat(), "cmp": cmp, "slots": LV.slot_labels(), "v": cur, "prev": prev,
                    "unit": unit, "rate": 60 / res, "res": res, "rate_unit": "kW" if m["kind"] == "elec" else f"{m['unit']}/ชม.",
                    "sum": round(sum(vals), 3) if vals else None, "peak": round(cur[pk] * 60 / res, 3) if pk is not None else None,
                    "peak_at": LV.slot_labels()[pk] if pk is not None else None, "hours": hours,
                    "cmp_sum": round(sum(v for v in prev if v is not None), 3) if any(v is not None for v in prev) else None,
                    "cmp_same": round(same, 3) if last is not None else None,
                    "diff_pct": round(100 * (sum(vals) - same) / same, 1) if vals and same else None,
                    "last": (LV.slot_labels() + ["24:00"])[last + 1] if last is not None else None})       # เวลาสิ้นสุดของช่วงล่าสุด


@bp.route("/meters/<int:mid>/now.json")
@require_role(*ALL_ROLES)
def meter_now(mid):
    """v0.99.41 วันนี้ใช้ไปเท่าไหร่ / ชั่วโมงนี้ใช้ไปเท่าไหร่ (อัปเดตทุก 1 นาทีบนหน้ามิเตอร์)"""
    from .. import energy_profile as PR
    db = get_db()
    m = EN.meter(db, mid)
    if not m:
        return jsonify({"error": "ไม่พบมิเตอร์"}), 404
    return jsonify(PR.now_summary(db, m))


# ───────────────────────── v0.88 นำเข้าไฟล์ค่าต่อช่วง (ทุก 15 นาที / รายชั่วโมง) ─────────────────────────

def _iv_ctx(db, **kw):
    from .. import energy_interval as EI
    from .energy import _facs_scope, _is_lead
    return dict(tab="intervals", hist=[], iv_hist=EI.imports(db), facs_scope=_facs_scope(db), year=now_dt().year,
                uid=current_user_id(), is_lead=_is_lead(), pv=None, **kw)


@bp.route("/import/intervals", methods=["GET", "POST"])
@require_role("admin", "supervisor", "technician")
def import_intervals():
    from os import remove  # noqa: F401
    from .. import energy_interval as EI
    from .energy import _save_tmp
    db = get_db()
    ipv = None
    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename:
            flash("เลือกไฟล์ก่อน", "error")
            return redirect(url_for("energy_sum.import_intervals"))
        raw = f.read()
        if len(raw) > 40 * 1024 * 1024:
            flash("ไฟล์ใหญ่เกิน 40 MB — แบ่งไฟล์เป็นรายเดือน", "error")
            return redirect(url_for("energy_sum.import_intervals"))
        fid = request.form.get("factory", type=int) or None
        kind = request.form.get("kind") if request.form.get("kind") in EN.KINDS else None
        shift = request.form.get("shift", type=int) or 0
        try:
            parsed = EI.parse_file(raw, f.filename)
            pv = EI.preview(db, parsed, fid, kind, shift)
        except ValidationError as exc:
            flash(exc.errors[0], "error")
            return redirect(url_for("energy_sum.import_intervals"))
        token = _save_tmp({"rows": [[k, d.strftime("%Y-%m-%d %H:%M:%S"), v] for k, d, v in parsed["rows"]],
                           "format": parsed["format"], "bad": parsed["bad"], "filename": f.filename})
        ipv = {**pv, "token": token, "filename": f.filename, "fid": fid, "kind": kind, "shift": shift}
    return render_template("energy/import.html", **_ctx(**_iv_ctx(db, ipv=ipv)))


@bp.route("/import/intervals/confirm", methods=["POST"])
@require_role("admin", "supervisor", "technician")
def import_intervals_confirm():
    import os

    from .. import energy_interval as EI
    from ..services import parse_ts
    from .energy import _load_tmp
    db = get_db()
    blob, path = _load_tmp(request.form.get("token", ""))
    if not blob:
        flash("หมดอายุแล้ว — อัปโหลดไฟล์ใหม่", "error")
        return redirect(url_for("energy_sum.import_intervals"))
    parsed = {"rows": [(k, parse_ts(t), v) for k, t, v in blob["rows"]], "format": blob["format"], "bad": blob["bad"]}
    sel = {int(x) for x in request.form.getlist("sel") if x.isdigit()}
    try:
        r = EI.commit_import(db, parsed, blob["filename"], current_user_id(), request.form.get("factory", type=int) or None,
                             request.form.get("kind") or None, request.form.get("shift", type=int) or 0, sel or None,
                             rebuild=request.form.get("rebuild") == "1")
        db.commit()
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return redirect(url_for("energy_sum.import_intervals"))
    try:
        os.remove(path)
    except OSError:
        pass
    flash(f"นำเข้าค่าต่อช่วงแล้ว: {r['rows']:,} ค่า · {r['meters']} มิเตอร์ · {r['from']} ถึง {r['to']}"
          + (f" · สร้างค่าอ่านรายวัน {r['readings']} ค่า ({r['rebuilt']} มิเตอร์)" if r["rebuilt"] else "")
          + (f" · {r['skipped_rebuild']} มิเตอร์มีค่าจดเองในช่วงนี้ — ไม่แทนค่าอ่านรายวัน" if r["skipped_rebuild"] and request.form.get("rebuild") == "1" else ""), "ok")
    return redirect(url_for("energy_sum.import_intervals"))


@bp.route("/import/intervals/<int:iid>/undo", methods=["POST"])
@require_role("admin", "supervisor", "technician")
def import_intervals_undo(iid):
    from .. import energy_interval as EI
    db = get_db()
    try:
        r = EI.undo_import(db, iid, current_user_id())
        db.commit()
        flash(f"ยกเลิกการนำเข้าแล้ว · คืนค่า {r['rows']:,} ค่า · {r['meters']} มิเตอร์", "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy_sum.import_intervals"))


@bp.route("/import/intervals-sample.xlsx")
@require_role(*ALL_ROLES)
def import_intervals_sample():
    from .. import energy_interval as EI
    from .rep import _send
    return _send(EI.sample_xlsx(), "xlsx", "ตัวอย่างไฟล์ค่าทุก15นาที.xlsx")
