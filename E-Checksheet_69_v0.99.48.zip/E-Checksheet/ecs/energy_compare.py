"""ecs/energy_compare.py — v0.99.45 เปรียบเทียบก่อน–หลังปรับปรุง (ใช้ค่าราย 15 นาที)

ใช้ตอบคำถาม 2 ข้อ:
1. สูญเสียตรงไหน — ช่วงเวลานอกเวลางานที่ยังใช้สูงกว่าโหลดพื้นฐาน (เช่น เครื่องเปิดค้างพักเที่ยง/กลางคืน/วันหยุด)
2. ปรับแก้แล้วลดได้เท่าไร — เลือกช่วง “ก่อน” และ “หลัง” (วันเดียวหรือหลายวัน · เลือกเฉพาะวันทำงาน/วันหยุดได้) เทียบ “เฉลี่ยต่อวัน”
   แยกช่วงเวลา · รายชั่วโมง · รายมิเตอร์ → kWh · บาท · tCO₂ ต่อวัน / เดือน (30 วัน) / ปี (365 วัน)

เงิน (ไฟฟ้า): ส่วนต่างหน่วยของแต่ละช่วง 15 นาที × อัตราของช่วงเวลานั้น (อัตราเฉลี่ยของช่วงนั้นในช่วง A) ตามอัตราค่าไฟของโรงงาน — TOU: On-Peak/Off-Peak
              + Ft + VAT · ไม่ใช้ TOU: อัตราเดียว · (ค่า Demand แสดง kW สูงสุดแยก ไม่รวมในเงินที่ลดได้)
ประเภทอื่น: ราคาต่อหน่วยที่ตั้งไว้ในหมวด · CO₂: ค่า EF ของหมวด (ไฟฟ้าใช้ ef_elec)
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta

from . import energy as EN
from . import energy_live as LV
from . import energy_power as PW

MAX_DAYS = 31
BANDS = [("night", "กลางคืน", 0, 6, False), ("prep", "ก่อนเข้างาน", 6, 8, False), ("am", "เวลางานเช้า", 8, 12, True),
         ("lunch", "พักเที่ยง", 12, 13, False), ("pm", "เวลางานบ่าย", 13, 17, True), ("after", "หลังเลิกงาน", 17, 22, False),
         ("late", "ดึก", 22, 24, False)]
DAYTYPES = {"all": "ทุกวัน", "work": "เฉพาะวันทำงาน", "off": "เฉพาะวันหยุด"}


def _days(a: date, b: date) -> list[date]:
    if b < a:
        a, b = b, a
    b = min(b, a + timedelta(days=MAX_DAYS - 1))
    return [a + timedelta(days=i) for i in range((b - a).days + 1)]


def _price(db, kind: str, cfg: dict) -> tuple[float | None, float | None]:
    """(ราคาต่อหน่วย, kgCO₂ ต่อหน่วย) ของหมวดที่ไม่ใช่ไฟฟ้า / ค่า EF ไฟฟ้า"""
    k = EN.KINDS.get(kind, {})
    ef = k.get("ef") if k.get("ef") is not None else (float(cfg.get("ef_elec") or 0) if kind == "elec" else None)
    price = k.get("price") if k.get("price") is not None else (float(cfg.get("price_elec") or 0) if kind == "elec" else None)
    return price, ef


def _rate_fn(db, kind: str, fid: int | None, d_from: date, d_to: date, price: float | None):
    """ฟังก์ชัน (เวลา) → บาท/หน่วย · ไฟฟ้าตาม TOU ของโรงงาน (+Ft ×VAT)"""
    if kind != "elec":
        return (lambda _t: price), {"mode": "flat", "rate": price}
    if not fid:
        return (lambda _t: price), {"mode": "flat", "rate": price}
    cfg = PW.tariff(db, fid)
    hol = PW.holidays(db, fid, d_from, d_to)
    vat = 1 + float(cfg.get("vat") or 0) / 100
    ft = float(cfg.get("ft") or 0)
    if int(cfg.get("tou") or 0):
        on, off = (float(cfg["on_rate"]) + ft) * vat, (float(cfg["off_rate"]) + ft) * vat
        return (lambda t: on if PW.is_on_peak(t, cfg, hol) else off), {"mode": "tou", "on": round(on, 4), "off": round(off, 4),
                                                                       "peak": f"{cfg['peak_start']}–{cfg['peak_end']}"}
    flat = (float(cfg["flat_rate"]) + ft) * vat
    return (lambda _t: flat), {"mode": "flat", "rate": round(flat, 4)}


def _period(db, ms: list[dict], days: list[date], daytype: str, wcfg: dict, whol: dict, rates: dict) -> dict:
    """ผลรวมต่อช่วง 15 นาที (96) เฉลี่ยต่อวัน: หน่วย · บาท ต่อมิเตอร์ และรวม · เฉพาะวันที่มีข้อมูลและตรงชนิดวัน"""
    ids = [m["id"] for m in ms]
    tot = [0.0] * LV.NSLOT
    baht = [0.0] * LV.NSLOT
    per: dict[int, dict] = {}
    used, skipped = [], 0
    for d in days:
        wd = PW.work_day(d, wcfg, whol)
        if (daytype == "work" and not wd) or (daytype == "off" and wd):
            continue
        a = datetime.combine(d, time(0, 0))
        rows = LV._sums(db, ids, a, a + timedelta(days=1)) if ids else {}
        if not any(any(v is not None for v in r) for r in rows.values()):
            skipped += 1
            continue
        used.append(d)
        for m in ms:
            r = rows.get(m["id"])
            if not r:
                continue
            fn = rates.get(m["factory_id"]) or rates.get(None)
            pm = per.setdefault(m["id"], {"u": 0.0, "b": 0.0, "slots": [0.0] * LV.NSLOT})
            for k, v in enumerate(r):
                if v is None:
                    continue
                v = v * EN.sign(m)
                bt = v * (fn(a + timedelta(minutes=15 * k)) or 0)
                tot[k] += v
                baht[k] += bt
                pm["u"] += v
                pm["b"] += bt
                pm["slots"][k] += v
    n = len(used)
    if n:
        tot = [x / n for x in tot]
        baht = [x / n for x in baht]
        for pm in per.values():
            pm["u"] /= n
            pm["b"] /= n
            pm["slots"] = [x / n for x in pm["slots"]]
    return {"days": used, "n": n, "skipped": skipped, "slots": tot, "baht": baht, "per": per}


def _band(slots: list[float], h0: int, h1: int) -> float:
    return sum(slots[h0 * 4:h1 * 4])


def compare(db, kind: str, a_from: date, a_to: date, b_from: date, b_to: date, fid=None, grp=None, meter_ids=None,
            daytype: str = "all") -> dict:
    kind = kind if kind in EN.KINDS else "elec"
    meta = EN.KINDS[kind]
    cfg = EN.settings(db)
    ms_all = EN.meters(db, fid, kind, True, None, grp or None, None)
    ms = [m for m in EN.counted(ms_all) if m["is_main"] != -1]
    if meter_ids:
        pick = set(meter_ids)
        ms = [m for m in ms_all if m["id"] in pick]
    daytype = daytype if daytype in DAYTYPES else "all"
    da, db_ = _days(a_from, a_to), _days(b_from, b_to)
    span = (min(da[0], db_[0]), max(da[-1], db_[-1]))
    price, ef = _price(db, kind, cfg)
    facs = sorted({m["factory_id"] for m in ms if m["factory_id"]})
    rates, rinfo = {}, {}
    for f in facs or [None]:
        fn, info = _rate_fn(db, kind, f, *span, price)
        rates[f] = fn
        rinfo[f] = info
    wf = fid or (facs[0] if facs else None)
    wcfg = PW.tariff(db, wf) if wf else dict(PW.DEFAULT_TARIFF)
    whol = PW.holidays(db, wf, *span) if wf else {}
    A = _period(db, ms, da, daytype, wcfg, whol, rates)
    B = _period(db, ms, db_, daytype, wcfg, whol, rates)
    co2 = (ef or 0) / 1000                                    # ตัน CO₂ ต่อหน่วย
    sa, sb = sum(A["slots"]), sum(B["slots"])
    # อัตราต่อช่วง 15 นาที = อัตราเฉลี่ยของช่วงนั้นในช่วง A (เช่น On-Peak วันทำงาน) → เงินที่ลดได้ = ส่วนต่างหน่วย × อัตราของช่วงเวลานั้น
    # (ไม่ปนผลจากชนิดวันที่ต่างกัน เช่น ช่วง B มีวันเสาร์ที่เป็น Off-Peak ทั้งวัน)
    rate_k = [(A["baht"][k] / A["slots"][k]) if A["slots"][k] else ((B["baht"][k] / B["slots"][k]) if B["slots"][k] else 0.0)
              for k in range(LV.NSLOT)]
    dbaht = [(B["slots"][k] - A["slots"][k]) * rate_k[k] for k in range(LV.NSLOT)]

    def row(a_u, b_u, d_b):
        d = b_u - a_u
        return {"a": round(a_u, 2), "b": round(b_u, 2), "diff": round(d, 2), "pct": round(100 * d / a_u, 1) if a_u else None,
                "baht": round(d_b, 2), "co2": round(d * co2, 4)}
    hours = []
    for h in range(24):
        r = row(_band(A["slots"], h, h + 1), _band(B["slots"], h, h + 1), _band(dbaht, h, h + 1))
        r["h"] = f"{h:02d}:00–{(h + 1) % 24:02d}:00"
        r["work"] = int(wcfg["work_start"][:2]) <= h < int(wcfg["work_end"][:2])
        hours.append(r)
    # โหลดพื้นฐาน = ชั่วโมงที่ใช้น้อยที่สุด (ช่วง A) · ช่วงนอกเวลางานที่สูงกว่าโหลดพื้นฐาน = “น่าจะสูญเสีย”
    ha = [_band(A["slots"], h, h + 1) for h in range(24)]
    base_a = min((x for x in ha if x > 0), default=0.0)
    hb = [_band(B["slots"], h, h + 1) for h in range(24)]
    base_b = min((x for x in hb if x > 0), default=0.0)
    work_avg = sum(ha[h] for h in range(24) if hours[h]["work"]) / max(1, sum(1 for x in hours if x["work"]))
    bands = []
    for key, th, h0, h1, work in BANDS:
        r = row(_band(A["slots"], h0, h1), _band(B["slots"], h0, h1), _band(dbaht, h0, h1))
        hrs = h1 - h0
        waste_a = max(0.0, r["a"] - base_a * hrs) if not work else None
        waste_b = max(0.0, r["b"] - base_b * hrs) if not work else None
        r.update({"key": key, "th": th, "lbl": f"{h0:02d}:00–{h1:02d}:00", "work": work, "kw_a": round(r["a"] / hrs, 1), "kw_b": round(r["b"] / hrs, 1),
                  "waste_a": round(waste_a, 1) if waste_a is not None else None, "waste_b": round(waste_b, 1) if waste_b is not None else None,
                  "flag": (not work) and work_avg > 0 and r["a"] / hrs > max(base_a * 1.25, 0.35 * work_avg)})
        bands.append(r)
    # ชั่วโมงนอกเวลางานที่น่าจะสูญเสียมากที่สุด (ช่วง A) — ส่วนที่เกินโหลดพื้นฐาน
    losses = sorted([{"h": hours[h]["h"], "kwh": round(ha[h] - base_a, 1), "kw": round(ha[h], 1),
                      "baht": round((ha[h] - base_a) * (sum(A["baht"][h * 4:h * 4 + 4]) / ha[h] if ha[h] else 0), 1)}
                     for h in range(24) if not hours[h]["work"] and ha[h] - base_a > 0.05 * max(work_avg, 1e-9)],
                    key=lambda x: -x["kwh"])[:8]
    meters = []
    tot_save = sa - sb
    for m in ms:
        pa, pb = A["per"].get(m["id"]), B["per"].get(m["id"])
        if not pa and not pb:
            continue
        ua, ub = (pa or {}).get("u", 0.0), (pb or {}).get("u", 0.0)
        sa_, sb_ = (pa or {}).get("slots") or [0.0] * LV.NSLOT, (pb or {}).get("slots") or [0.0] * LV.NSLOT
        r = row(ua, ub, sum((sb_[k] - sa_[k]) * rate_k[k] for k in range(LV.NSLOT)))
        r.update({"id": m["id"], "name": EN.label(m), "sid": m.get("scada_source_id"), "tag": (m.get("scada_tag") or "").strip(),
                  "share": round(100 * (ua - ub) / tot_save, 1) if tot_save > 0 and ua - ub > 0 else None,
                  "missing": "A" if not pa else ("B" if not pb else None)})
        meters.append(r)
    meters.sort(key=lambda r: r["diff"])
    pk_a = max(range(LV.NSLOT), key=lambda k: A["slots"][k]) if A["n"] else None
    pk_b = max(range(LV.NSLOT), key=lambda k: B["slots"][k]) if B["n"] else None
    total = row(sa, sb, sum(dbaht))
    save_u, save_b, save_c = -total["diff"], -total["baht"], -total["co2"]
    return {"kind": kind, "th": meta["th"], "unit": meta["unit"], "color": meta["color"], "icon": meta["icon"],
            "rate_unit": "kW" if kind == "elec" else f"{meta['unit']}/ชม.", "ef": ef, "price": price, "rates": rinfo,
            "a": {"from": da[0].isoformat(), "to": da[-1].isoformat(), "n": A["n"], "skipped": A["skipped"], "days": [d.isoformat() for d in A["days"]]},
            "b": {"from": db_[0].isoformat(), "to": db_[-1].isoformat(), "n": B["n"], "skipped": B["skipped"], "days": [d.isoformat() for d in B["days"]]},
            "daytype": daytype, "daytype_th": DAYTYPES[daytype], "work": f"{wcfg['work_start']}–{wcfg['work_end']}",
            "total": total, "save": {"day": {"u": round(save_u, 1), "baht": round(save_b, 0), "co2": round(save_c, 3)},
                                     "month": {"u": round(save_u * 30, 0), "baht": round(save_b * 30, 0), "co2": round(save_c * 30, 2)},
                                     "year": {"u": round(save_u * 365, 0), "baht": round(save_b * 365, 0), "co2": round(save_c * 365, 1)}},
            "peak_a": round(A["slots"][pk_a] * 4, 1) if pk_a is not None else None, "peak_a_at": LV.slot_labels()[pk_a] if pk_a is not None else None,
            "peak_b": round(B["slots"][pk_b] * 4, 1) if pk_b is not None else None, "peak_b_at": LV.slot_labels()[pk_b] if pk_b is not None else None,
            "base_a": round(base_a, 1), "base_b": round(base_b, 1), "slots": LV.slot_labels(),
            "prof_a": [round(x, 3) for x in A["slots"]], "prof_b": [round(x, 3) for x in B["slots"]],
            "hours": hours, "bands": bands, "losses": losses, "meters": meters, "n_meters": len(ms)}
