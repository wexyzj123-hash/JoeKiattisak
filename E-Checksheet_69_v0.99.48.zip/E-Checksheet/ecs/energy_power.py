"""ecs/energy_power.py — v0.91 บริหารไฟฟ้า: TOU · Peak Demand · ใช้ไฟนอกเวลาผลิต · kWh/หน่วยผลิตรายไลน์ · บิล vs มิเตอร์ · PF

แหล่งข้อมูล
  - ค่าต่อช่วงเวลา (en_intervals, 15 นาที/รายชั่วโมงจาก SCADA) → แยก On-Peak/Off-Peak, kW สูงสุด, โหลดนอกเวลา
  - การใช้รายวัน (EN.series) → มิเตอร์ที่จดมือ (นอกเวลา = การใช้ในวันหยุด/วันหยุดผลิต) และยอดเทียบบิล
  - ทุกยอดใช้กติกาเดียวทั้งระบบ (EN.counted) — ไม่นับซ้ำมิเตอร์หลัก+ย่อย
ตารางใหม่
  en_tariff       อัตราค่าไฟ/ตั้งค่าต่อโรงงาน (TOU · Demand · Ft · ค่าบริการ · VAT · เป้า kW · เวลาทำงาน · เกณฑ์ PF)
  en_param_tags   Tag SCADA ของค่าทางไฟฟ้าอื่นของมิเตอร์ (pf / kw / kvar)
  en_params       ค่าที่อ่านได้ (ตามเวลา) ของพารามิเตอร์เหล่านั้น
  en_line_prod    ยอดผลิตรายเดือนต่อหน่วยงาน/ไลน์ (ใช้คิด kWh/หน่วยผลิต)
"""
from __future__ import annotations

import calendar
import statistics
from datetime import date, datetime, time, timedelta

from . import energy as EN
from . import masterdata as M
from . import services as S
from .services import parse_ts, ts

PARAMS = {"pf": ("Power Factor", ""), "kw": ("กำลังไฟฟ้า", "kW"), "kvar": ("กำลังไฟฟ้ารีแอคทีฟ", "kVAR")}
SLOT = 15
# ค่าเริ่มต้น: อัตรา กฟภ. ประเภท 4.2.2 กิจการขนาดใหญ่ TOU แรงดัน 22–33 kV (ตรวจ/แก้ให้ตรงบิลจริงที่หน้า ตั้งค่าอัตรา)
DEFAULT_TARIFF = {"tou": 1, "on_rate": 4.1839, "off_rate": 2.6037, "flat_rate": 3.9086, "demand_rate": 132.93, "service": 312.24,
                  "ft": 0.0, "vat": 7.0, "peak_start": "09:00", "peak_end": "22:00", "demand_target": None,
                  "work_start": "08:00", "work_end": "17:00", "work_days": "1111110", "pf_limit": 0.85, "kvar_rate": 56.07,
                  "bill_tol": 5.0}
FIELDS = list(DEFAULT_TARIFF)

DDL = """
CREATE TABLE IF NOT EXISTS en_tariff (
    factory_id  INTEGER PRIMARY KEY,
    cfg         TEXT NOT NULL DEFAULT '{}',
    updated_at  TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS en_param_tags (
    meter_id    INTEGER NOT NULL,
    param       TEXT NOT NULL,
    tag         TEXT NOT NULL,
    scale       REAL NOT NULL DEFAULT 1,
    PRIMARY KEY (meter_id, param)
);
CREATE TABLE IF NOT EXISTS en_params (
    meter_id    INTEGER NOT NULL,
    param       TEXT NOT NULL,
    ts          TEXT NOT NULL,
    value       REAL NOT NULL,
    PRIMARY KEY (meter_id, param, ts)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS idx_enp_ts ON en_params(ts);
CREATE TABLE IF NOT EXISTS en_line_prod (
    factory_id  INTEGER NOT NULL,
    grp         TEXT NOT NULL DEFAULT '',
    line        TEXT NOT NULL DEFAULT '',
    month       TEXT NOT NULL,
    qty         REAL NOT NULL,
    unit        TEXT NOT NULL DEFAULT 'ชิ้น',
    updated_at  TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (factory_id, grp, line, month)
);
"""


def ensure(db) -> None:
    if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='en_line_prod'").fetchone():
        db.executescript(DDL)


# ───────────────────────── ตั้งค่าอัตรา ─────────────────────────

def tariff(db, fid: int) -> dict:
    import json
    ensure(db)
    cfg = dict(DEFAULT_TARIFF)
    r = db.execute("SELECT cfg FROM en_tariff WHERE factory_id=?", (fid,)).fetchone()
    if r:
        try:
            cfg.update({k: v for k, v in json.loads(r[0]).items() if k in DEFAULT_TARIFF})
        except ValueError:
            pass
    return cfg


def _hm(v: str, label: str) -> str:
    try:
        h, m = (int(x) for x in str(v).strip().split(":"))
        if 0 <= h <= 24 and 0 <= m < 60 and h * 60 + m <= 1440:
            return f"{h:02d}:{m:02d}"
    except (TypeError, ValueError):
        pass
    raise S.ValidationError(f"{label} ต้องเป็นเวลา HH:MM")


def save_tariff(db, fid: int, data: dict, actor) -> dict:
    import json
    cfg = tariff(db, fid)
    for k in FIELDS:
        if k not in data:
            continue
        v = str(data.get(k) or "").strip()
        if k in ("peak_start", "peak_end", "work_start", "work_end"):
            cfg[k] = _hm(v, k)
        elif k == "work_days":
            if len(v) != 7 or set(v) - {"0", "1"}:
                raise S.ValidationError("วันทำงานต้องเป็นตัว 0/1 จำนวน 7 ตัว (จันทร์→อาทิตย์)")
            cfg[k] = v
        elif k == "tou":
            cfg[k] = 1 if v in ("1", "on", "true") else 0
        elif v == "":
            cfg[k] = None if k == "demand_target" else DEFAULT_TARIFF[k]
        else:
            try:
                f = float(v.replace(",", ""))
            except ValueError:
                raise S.ValidationError(f"{k} ต้องเป็นตัวเลข") from None
            if f < 0:
                raise S.ValidationError("ค่าต้องไม่ติดลบ")
            cfg[k] = f
    db.execute("""INSERT INTO en_tariff(factory_id, cfg, updated_at) VALUES (?,?,?)
                  ON CONFLICT(factory_id) DO UPDATE SET cfg=excluded.cfg, updated_at=excluded.updated_at""",
               (fid, json.dumps(cfg), ts(S.now_dt())))
    S.audit(db, actor, "energy_tariff", "en_tariff", fid, after=cfg)
    return cfg


# ───────────────────────── ปฏิทิน ─────────────────────────

def _mins(hm: str) -> int:
    h, m = (int(x) for x in hm.split(":"))
    return h * 60 + m


def holidays(db, fid: int, d_from: date, d_to: date) -> dict[str, str]:
    """{วัน: 'holiday' | 'shutdown'} — วันหยุดนักขัตฤกษ์ (ทุกโรงงาน) + วันหยุดผลิตของโรงงาน"""
    out = {}
    for r in db.execute("""SELECT day, kind FROM en_holidays WHERE day BETWEEN ? AND ? AND (factory_id IS NULL OR factory_id=?)""",
                        (d_from.isoformat(), d_to.isoformat(), fid)):
        out[r[0]] = r[1] or "holiday"
    return out


def is_on_peak(t: datetime, cfg: dict, hol: dict) -> bool:
    """TOU: จันทร์–ศุกร์ ช่วง peak_start–peak_end (ค่าเริ่มต้น 09:00–22:00) ยกเว้นวันหยุดนักขัตฤกษ์"""
    if t.weekday() >= 5 or hol.get(t.date().isoformat()) == "holiday":
        return False
    mm = t.hour * 60 + t.minute
    return _mins(cfg["peak_start"]) <= mm < _mins(cfg["peak_end"])


def is_work(t: datetime, cfg: dict, hol: dict) -> bool:
    """เวลาทำงาน/ผลิต: วันทำงาน (work_days จ→อา) ที่ไม่ใช่วันหยุด/หยุดผลิต และอยู่ในช่วง work_start–work_end"""
    if cfg["work_days"][t.weekday()] != "1" or t.date().isoformat() in hol:
        return False
    mm = t.hour * 60 + t.minute
    a, b = _mins(cfg["work_start"]), _mins(cfg["work_end"])
    return a <= mm < b if a <= b else (mm >= a or mm < b)        # กะข้ามคืน เช่น 20:00–05:00


def work_day(d: date, cfg: dict, hol: dict) -> bool:
    return cfg["work_days"][d.weekday()] == "1" and d.isoformat() not in hol


# ───────────────────────── ค่าต่อช่วง → ช่วง 15 นาที ─────────────────────────

def _slots(db, ids: list[int], d_from: date, d_to: date) -> tuple[dict[int, dict[datetime, float]], dict[int, int]]:
    """{meter: {เวลาเริ่มช่วง 15 นาที: kWh}} ของ [d_from 00:00, d_to+1 00:00) · ค่าที่ ts = เวลาสิ้นสุดช่วง
    ข้อมูลรายชั่วโมง → กระจายเท่ากันลง 4 ช่วง 15 นาที · คืนความละเอียด (นาที) ต่อมิเตอร์"""
    out: dict[int, dict] = {}
    raw: dict[int, list] = {}
    a = datetime.combine(d_from, time(0, 0))
    b = datetime.combine(d_to + timedelta(days=1), time(0, 0))
    for i in range(0, len(ids), 800):
        ch = ids[i:i + 800]
        for mid, stamp, v in db.execute(f"""SELECT meter_id, ts, value FROM en_intervals WHERE ts>? AND ts<=? AND meter_id IN
                                            ({','.join('?' * len(ch))}) ORDER BY meter_id, ts""", [ts(a), ts(b), *ch]):
            raw.setdefault(mid, []).append((parse_ts(stamp), v))
    res: dict[int, int] = {}
    for mid, rows in raw.items():
        gaps = [int((y[0] - x[0]).total_seconds() // 60) for x, y in zip(rows, rows[1:])]
        gaps = [g for g in gaps if g > 0]
        r = min(gaps) if gaps else SLOT
        r = max(SLOT, (r // SLOT) * SLOT) if r >= SLOT else SLOT
        res[mid] = r
        n = r // SLOT
        d = out.setdefault(mid, {})
        for t_end, v in rows:
            for k in range(n):
                st = t_end - timedelta(minutes=r - SLOT * k)
                if a <= st < b:
                    d[st] = d.get(st, 0.0) + v / n
    rest = [i for i in ids if i not in raw]                  # v0.99.43 มิเตอร์แบบเลขสะสม → ผลต่างราย 15 นาทีจาก en_profile
    if rest:
        from . import energy_profile as PR
        for mid, row in PR.slots(db, rest, a, b).items():
            out[mid] = {a + timedelta(minutes=SLOT * k): v for k, v in enumerate(row) if v is not None}
            res[mid] = SLOT
    return out, res


def interval_meters(db, ids: list[int], a: datetime, b: datetime) -> set[int]:
    """v0.99.43 มิเตอร์ที่มีค่ารายช่วงเวลาในช่วง (ค่าต่อช่วง en_intervals หรือ เลขสะสมราย 15 นาที en_profile)"""
    from . import energy_profile as PR
    PR.ensure(db)
    if not ids:
        return set()
    q = ",".join(str(int(i)) for i in ids)
    have = {r[0] for r in db.execute(f"SELECT DISTINCT meter_id FROM en_intervals WHERE ts>? AND ts<=? AND meter_id IN ({q})", (ts(a), ts(b)))}
    have |= {r[0] for r in db.execute(f"SELECT DISTINCT meter_id FROM en_profile WHERE ts>=? AND ts<=? AND meter_id IN ({q})", (ts(a), ts(b)))}
    return have


def _elec_counted(db, fid: int) -> list[dict]:
    return EN.counted(EN.meters(db, fid, "elec"))


# ───────────────────────── TOU + Peak Demand ─────────────────────────

def tou(db, fid: int, month: date, today: date | None = None) -> dict:
    """เดือนของโรงงาน: kWh On/Off-Peak · kW สูงสุด (On-Peak = ที่ใช้คิดค่า Demand) · ประมาณบิล TOU · เทียบบิลจริง · ย้ายโหลด"""
    ensure(db)
    cfg = tariff(db, fid)
    today = today or S.now_dt().date()
    d_from, d_to = EN.month_bounds(month)
    d_end = min(d_to, today)
    days = EN._days(d_from, d_end) if d_end >= d_from else []
    ms = EN.meters(db, fid, "elec")
    cm = EN.counted(ms)
    hol = holidays(db, fid, d_from, d_to)
    # มิเตอร์ที่มีค่าต่อช่วงในเดือนนี้ → ชุดที่ไม่ซ้อนกัน (กติกาเดียวทั้งระบบ) ใช้หาสัดส่วน On/Off และ kW สูงสุด
    have = set()
    if days and ms:
        have = interval_meters(db, [m["id"] for m in ms], datetime.combine(d_from, time(0, 0)),
                               datetime.combine(d_end + timedelta(days=1), time(0, 0)))
    with_int = EN.counted([m for m in ms if m["id"] in have])
    slots, res = _slots(db, [m["id"] for m in with_int], d_from, d_end) if with_int else ({}, {})
    tot: dict[datetime, float] = {}
    for m in with_int:
        sg = EN.sign(m)
        for t, v in (slots.get(m["id"]) or {}).items():
            tot[t] = tot.get(t, 0.0) + sg * v
    ser = EN.series(db, cm, d_from, d_end) if cm and days else {}
    daily_kwh = sum(EN.sign(m) * sum((x.get("u") or 0) for x in (ser.get(m["id"]) or {}).values()) for m in cm)
    on = off = 0.0
    per_day = {d: {"on": 0.0, "off": 0.0, "peak": 0.0, "peak_at": None} for d in days}
    prof = {"wd": [[] for _ in range(24)], "we": [[] for _ in range(24)]}
    hourly: dict[tuple, float] = {}
    peak_on = peak_all = 0.0
    peak_on_at = peak_all_at = None
    peaks = []
    for t, v in tot.items():
        kw = v * 60 / SLOT
        d = t.date().isoformat()
        if d not in per_day:
            continue
        if is_on_peak(t, cfg, hol):
            on += v
            per_day[d]["on"] += v
            if kw > peak_on:
                peak_on, peak_on_at = kw, t
        else:
            off += v
            per_day[d]["off"] += v
        if kw > per_day[d]["peak"]:
            per_day[d]["peak"], per_day[d]["peak_at"] = kw, t
        if kw > peak_all:
            peak_all, peak_all_at = kw, t
        hourly[(d, t.hour)] = hourly.get((d, t.hour), 0.0) + v
        peaks.append((kw, t))
    for (d, h), v in hourly.items():
        wd = date.fromisoformat(d).weekday() < 5 and hol.get(d) != "holiday"
        prof["wd" if wd else "we"][h].append(v)
    profile = {k: [round(statistics.mean(x), 1) if x else None for x in v] for k, v in prof.items()}
    peaks.sort(key=lambda x: -x[0])
    top, seen = [], set()
    for kw, t in peaks:                                  # 10 ช่วงสูงสุด (ไม่ซ้ำวัน-ชั่วโมง)
        k = (t.date(), t.hour)
        if k in seen:
            continue
        seen.add(k)
        top.append({"kw": round(kw, 1), "at": t, "on": is_on_peak(t, cfg, hol)})
        if len(top) >= 10:
            break
    kwh_int = on + off
    cover = round(100 * kwh_int / daily_kwh, 1) if daily_kwh and kwh_int else None    # % ของยอดโรงงานที่มีข้อมูล 15 นาที
    # ประมาณบิล (สัดส่วน On/Off จากค่าต่อช่วง × ยอดมิเตอร์รายวันทั้งหมด เมื่อบางมิเตอร์ไม่มีค่าต่อช่วง)
    share_on = on / kwh_int if kwh_int else None
    base_kwh = daily_kwh if daily_kwh else kwh_int
    est = None
    if base_kwh:
        e_on = base_kwh * share_on if share_on is not None else None
        e_off = base_kwh - e_on if e_on is not None else None
        energy = (e_on * cfg["on_rate"] + e_off * cfg["off_rate"]) if (cfg["tou"] and e_on is not None) else base_kwh * cfg["flat_rate"]
        demand = (peak_on if cfg["tou"] else peak_all) * cfg["demand_rate"]
        ft = base_kwh * (cfg["ft"] or 0)
        pre = energy + demand + ft + cfg["service"]
        est = {"kwh": round(base_kwh), "on": round(e_on) if e_on is not None else None, "off": round(e_off) if e_off is not None else None,
               "energy": round(energy), "demand": round(demand), "ft": round(ft), "service": round(cfg["service"], 2),
               "pre_vat": round(pre), "total": round(pre * (1 + cfg["vat"] / 100)), "rate": round(pre / base_kwh, 4)}
    bill = db.execute("SELECT kwh, amount, ft, demand, vat FROM en_bills WHERE factory_id=? AND month=?", (fid, month.strftime("%Y-%m"))).fetchone()
    bill = dict(bill) if bill else None
    shift = []
    if est and est["on"]:
        for pct in (5, 10, 20):
            mv = est["on"] * pct / 100
            shift.append({"pct": pct, "kwh": round(mv), "baht": round(mv * (cfg["on_rate"] - cfg["off_rate"]) * (1 + cfg["vat"] / 100))})
    target = cfg.get("demand_target")
    return {"cfg": cfg, "days": days, "per_day": [{"day": d, **{k: (round(v, 1) if isinstance(v, float) else v) for k, v in per_day[d].items()}}
                                                   for d in days],
            "on": round(on), "off": round(off), "share_on": round(100 * share_on, 1) if share_on is not None else None,
            "peak_on": round(peak_on, 1), "peak_on_at": peak_on_at, "peak_all": round(peak_all, 1), "peak_all_at": peak_all_at,
            "top": top, "profile": profile, "cover": cover, "n_int": len(with_int), "n_counted": len(cm), "daily_kwh": round(daily_kwh),
            "est": est, "bill": bill, "shift": shift, "target": target,
            "over": bool(target and peak_on > target), "near": bool(target and not peak_on > target and peak_on > 0.9 * target),
            "hol": hol}


# ───────────────────────── ใช้ไฟนอกเวลาผลิต ─────────────────────────

def offhours(db, fid: int, month: date, today: date | None = None) -> dict:
    """ต่อหน่วยงาน/ไลน์: kWh นอกเวลาผลิต (กลางคืน · วันหยุด · หยุดผลิต) · โหลดพื้นฐาน kW · ค่าใช้จ่ายโดยประมาณ
    มิเตอร์ที่มีค่าต่อช่วง → แยกตามเวลา · จดรายวัน → การใช้ในวันที่ไม่ผลิต"""
    ensure(db)
    cfg = tariff(db, fid)
    today = today or S.now_dt().date()
    d_from, d_to = EN.month_bounds(month)
    d_end = min(d_to, today)
    if d_end < d_from:
        return {"rows": [], "cfg": cfg}
    hol = holidays(db, fid, d_from, d_to)
    ms = EN.meters(db, fid, "elec")
    slots, _ = _slots(db, [m["id"] for m in ms], d_from, d_end)
    ser = EN.series(db, ms, d_from, d_end)
    per: dict[int, dict] = {}
    n_off_slots = sum(1 for d in EN._days(d_from, d_end) for k in range(96)
                      if not is_work(datetime.combine(date.fromisoformat(d), time(0, 0)) + timedelta(minutes=SLOT * k), cfg, hol))
    for m in ms:
        s = slots.get(m["id"])
        if s:
            off = sum(v for t, v in s.items() if not is_work(t, cfg, hol))
            tot = sum(s.values())
            per[m["id"]] = {"tot": tot, "off": off, "base": off / (n_off_slots * SLOT / 60) if n_off_slots else None, "src": "int"}
        else:
            us = {d: x.get("u") for d, x in (ser.get(m["id"]) or {}).items() if x.get("u") is not None}
            tot = sum(us.values())
            nw = [u for d, u in us.items() if not work_day(date.fromisoformat(d), cfg, hol)]
            off = sum(nw)
            per[m["id"]] = {"tot": tot, "off": off, "base": (statistics.mean(nw) / 24) if nw else None, "src": "daily"}
    fm = EN.factory_mains(ms)
    groups: dict[tuple, list] = {}
    for m in ms:
        if m["id"] in fm:
            continue
        g = (m["grp"] or "").strip() or "ไม่ระบุหน่วยงาน"
        groups.setdefault((g, ""), []).append(m)
        if (m.get("line") or "").strip():
            groups.setdefault((g, m["line"].strip()), []).append(m)
    rows = []
    for (g, ln), lst in groups.items():
        cm = EN.counted(lst)
        if not cm:
            continue
        tot = sum(EN.sign(m) * per[m["id"]]["tot"] for m in cm)
        off = sum(EN.sign(m) * per[m["id"]]["off"] for m in cm)
        base = sum(EN.sign(m) * (per[m["id"]]["base"] or 0) for m in cm)
        src = {per[m["id"]]["src"] for m in cm}
        if tot <= 0:
            continue
        rows.append({"grp": g, "line": ln, "tot": round(tot), "off": round(off), "pct": round(100 * off / tot, 1), "base_kw": round(base, 1),
                     "baht": round(off * (cfg["off_rate"] if cfg["tou"] else cfg["flat_rate"])), "src": "15 นาที" if src == {"int"} else
                     ("รายวัน" if src == {"daily"} else "ผสม"), "n": len(cm)})
    rows.sort(key=lambda r: (r["line"] != "", -r["off"]))
    secs = [r for r in rows if not r["line"]]
    return {"rows": rows, "secs": secs, "lines": [r for r in rows if r["line"]], "cfg": cfg,
            "total_off": sum(r["off"] for r in secs), "total": sum(r["tot"] for r in secs),
            "baht": sum(r["baht"] for r in secs), "n_hol": len(hol)}


# ───────────────────────── kWh / หน่วยผลิต ต่อไลน์ ─────────────────────────

def units_of(db, fid: int) -> list[dict]:
    """หน่วยที่บันทึกยอดผลิตได้: ทุกหน่วยงาน (ทั้งหน่วยงาน) + ทุกไลน์ในหน่วยงาน — จากมิเตอร์ไฟฟ้าของโรงงาน"""
    ms = EN.meters(db, fid, "elec")
    fm = EN.factory_mains(ms)
    out: dict[tuple, dict] = {}
    for m in ms:
        if m["id"] in fm:
            continue
        g = (m["grp"] or "").strip()
        if not g:
            continue
        out.setdefault((g, ""), {"grp": g, "line": "", "ms": []})["ms"].append(m)
        if (m.get("line") or "").strip():
            out.setdefault((g, m["line"].strip()), {"grp": g, "line": m["line"].strip(), "ms": []})["ms"].append(m)
    return sorted(out.values(), key=lambda u: (u["grp"], u["line"]))


def save_prod_grid(db, fid: int, year: int, form, actor) -> int:
    ensure(db)
    n = 0
    stamp = ts(S.now_dt())
    for u in units_of(db, fid):
        key = f"{u['grp']}|{u['line']}"
        unit = str(form.get(f"unit::{key}") or "ชิ้น").strip()[:20] or "ชิ้น"
        for mo in range(1, 13):
            v = form.get(f"q::{key}::{mo}")
            if v is None:
                continue
            ym = f"{year}-{mo:02d}"
            v = str(v).replace(",", "").strip()
            if v == "":
                n += db.execute("DELETE FROM en_line_prod WHERE factory_id=? AND grp=? AND line=? AND month=?", (fid, u["grp"], u["line"], ym)).rowcount
                continue
            try:
                q = float(v)
            except ValueError:
                raise S.ValidationError(f"ยอดผลิต {u['grp']} {u['line']} เดือน {mo} ต้องเป็นตัวเลข") from None
            if q < 0:
                raise S.ValidationError("ยอดผลิตต้องไม่ติดลบ")
            db.execute("""INSERT INTO en_line_prod(factory_id, grp, line, month, qty, unit, updated_at) VALUES (?,?,?,?,?,?,?)
                          ON CONFLICT(factory_id, grp, line, month) DO UPDATE SET qty=excluded.qty, unit=excluded.unit,
                          updated_at=excluded.updated_at""", (fid, u["grp"], u["line"], ym, q, unit, stamp))
            n += 1
    S.audit(db, actor, "energy_line_prod", "en_line_prod", fid, after={"year": year, "n": n})
    return n


def intensity(db, fid: int, year: int, today: date | None = None) -> dict:
    """kWh รายเดือนของแต่ละหน่วยงาน/ไลน์ (กติกาเดียวทั้งระบบ) ÷ ยอดผลิต → kWh/หน่วย · เทียบค่าเฉลี่ยของปี"""
    ensure(db)
    today = today or S.now_dt().date()
    us = units_of(db, fid)
    d_from, d_to = date(year, 1, 1), min(date(year, 12, 31), today)
    all_ms = EN.meters(db, fid, "elec")
    ser = EN.series(db, all_ms, d_from, d_to) if all_ms and d_to >= d_from else {}
    prod = {(r[0], r[1], r[2]): (r[3], r[4]) for r in db.execute(
        "SELECT grp, line, month, qty, unit FROM en_line_prod WHERE factory_id=? AND month LIKE ?", (fid, f"{year}-%"))}
    rows = []
    for u in us:
        cm = EN.counted(u["ms"])
        kwh = [0.0] * 12
        for m in cm:
            for d, x in (ser.get(m["id"]) or {}).items():
                if x.get("u") is not None:
                    kwh[int(d[5:7]) - 1] += EN.sign(m) * x["u"]
        qty = [prod.get((u["grp"], u["line"], f"{year}-{mo:02d}"), (None, None))[0] for mo in range(1, 13)]
        unit = next((prod[(u["grp"], u["line"], f"{year}-{mo:02d}")][1] for mo in range(1, 13)
                     if (u["grp"], u["line"], f"{year}-{mo:02d}") in prod), "ชิ้น")
        ki = [round(k / q, 3) if q else None for k, q in zip(kwh, qty)]
        vals = [x for x in ki if x is not None]
        avg = statistics.mean(vals) if vals else None
        rows.append({"grp": u["grp"], "line": u["line"], "key": f"{u['grp']}|{u['line']}", "kwh": [round(k) for k in kwh], "qty": qty,
                     "ki": ki, "unit": unit, "avg": round(avg, 3) if avg else None,
                     "last": next((x for x in reversed(ki) if x is not None), None), "n": len(cm)})
    return {"rows": rows, "year": year}


# ───────────────────────── บิล vs มิเตอร์ ─────────────────────────

def bill_check(db, year: int, today: date | None = None) -> dict:
    """ทุกโรงงาน ทุกเดือน: kWh ตามบิล vs ผลรวมมิเตอร์ (กติกาเดียวทั้งระบบ) · ต่างเกิน bill_tol% = ต้องตรวจ"""
    ensure(db)
    today = today or S.now_dt().date()
    out = []
    for f in M.list_factories(db):
        cfg = tariff(db, f["id"])
        cm = _elec_counted(db, f["id"])
        d_to = min(date(year, 12, 31), today)
        ser = EN.series(db, cm, date(year, 1, 1), d_to) if cm and d_to >= date(year, 1, 1) else {}
        mk = [0.0] * 12
        for m in cm:
            for d, x in (ser.get(m["id"]) or {}).items():
                if x.get("u") is not None:
                    mk[int(d[5:7]) - 1] += EN.sign(m) * x["u"]
        bills = {r[0]: dict(r) for r in db.execute("SELECT month, kwh, amount, demand, ft, vat FROM en_bills WHERE factory_id=? AND month LIKE ?",
                                                   (f["id"], f"{year}-%"))}
        months = []
        for mo in range(1, 13):
            b = bills.get(f"{year}-{mo:02d}")
            diff = round(100 * (mk[mo - 1] - b["kwh"]) / b["kwh"], 1) if b and b["kwh"] else None
            months.append({"mo": mo, "meter": round(mk[mo - 1]), "bill": b, "diff": diff,
                           "flag": diff is not None and abs(diff) > (cfg["bill_tol"] or 5)})
        if any(x["meter"] or x["bill"] for x in months):
            out.append({"fid": f["id"], "name": f["name"], "months": months, "tol": cfg["bill_tol"],
                        "n_flag": sum(1 for x in months if x["flag"])})
    return {"factories": out, "year": year}


# ───────────────────────── PF / kW / kVAR จาก SCADA ─────────────────────────

def param_tags(db, mid: int) -> dict[str, dict]:
    ensure(db)
    return {r["param"]: dict(r) for r in db.execute("SELECT * FROM en_param_tags WHERE meter_id=?", (mid,))}


def save_param_tags(db, mid: int, data: dict, actor) -> None:
    ensure(db)
    for p in PARAMS:
        if f"tag_{p}" not in data:
            continue
        tag = str(data.get(f"tag_{p}") or "").strip()[:80]
        if not tag:
            db.execute("DELETE FROM en_param_tags WHERE meter_id=? AND param=?", (mid, p))
            continue
        try:
            sc = float(str(data.get(f"scale_{p}") or "1").strip() or 1)
        except ValueError:
            raise S.ValidationError("ตัวคูณของ Tag ต้องเป็นตัวเลข") from None
        db.execute("""INSERT INTO en_param_tags(meter_id, param, tag, scale) VALUES (?,?,?,?)
                      ON CONFLICT(meter_id, param) DO UPDATE SET tag=excluded.tag, scale=excluded.scale""", (mid, p, tag, sc))
    S.audit(db, actor, "energy_param_tags", "en_param_tags", mid, after=param_tags(db, mid))


def source_param_tags(db, sid: int) -> list[str]:
    """Tag พารามิเตอร์ของมิเตอร์ที่อ่านจากแหล่ง SCADA นี้ (ดึงเพิ่มพร้อม Tag kWh)"""
    ensure(db)
    return [r[0] for r in db.execute("""SELECT DISTINCT TRIM(t.tag) FROM en_param_tags t JOIN en_meters m ON m.id=t.meter_id
                                        WHERE m.scada_source_id=? AND m.active=1 AND TRIM(t.tag)<>''""", (sid,))]


def store_params(db, src: dict, rows) -> int:
    """แถว (tag, เวลา, ค่า) จาก SCADA → en_params ของมิเตอร์ที่ผูก Tag นั้น · PF ที่อ่านเป็น % (เช่น 92) แปลงเป็น 0.92"""
    ensure(db)
    tmap: dict[str, list] = {}
    for r in db.execute("""SELECT t.meter_id, t.param, TRIM(t.tag), t.scale FROM en_param_tags t JOIN en_meters m ON m.id=t.meter_id
                           WHERE m.scada_source_id=? AND m.active=1""", (src["id"],)):
        tmap.setdefault(r[2], []).append((r[0], r[1], r[3] or 1))
    if not tmap:
        return 0
    n = 0
    for tag, dt, val in rows:
        for mid, p, sc in tmap.get(str(tag).strip(), []):
            if val is None or dt is None:
                continue
            try:
                v = float(val) * sc
            except (TypeError, ValueError):
                continue
            if p == "pf":
                v = abs(v)
                if 1.0 < v <= 100.0:
                    v /= 100.0
                if v > 1.0:
                    continue
            elif v < 0 or v > 1e7:
                continue
            db.execute("INSERT OR REPLACE INTO en_params(meter_id, param, ts, value) VALUES (?,?,?,?)",
                       (mid, p, ts(dt.replace(second=0, microsecond=0)), v))
            n += 1
    return n


def pf_report(db, fid: int | None, d_from: date, d_to: date) -> dict:
    """ต่อมิเตอร์ที่มี Tag PF/kW/kVAR: PF เฉลี่ย · ต่ำสุด · % เวลาที่ PF ต่ำกว่าเกณฑ์ · kW สูงสุด · kVAR สูงสุด"""
    ensure(db)
    ms = {m["id"]: m for m in EN.meters(db, fid, "elec")}
    tags = [dict(r) for r in db.execute("SELECT * FROM en_param_tags")]
    by: dict[int, dict] = {}
    for t in tags:
        if t["meter_id"] in ms:
            by.setdefault(t["meter_id"], {})[t["param"]] = t["tag"]
    rows = []
    a, b = ts(datetime.combine(d_from, time(0, 0))), ts(datetime.combine(d_to + timedelta(days=1), time(0, 0)))
    for mid, ps in by.items():
        m = ms[mid]
        lim = tariff(db, m["factory_id"])["pf_limit"] if m["factory_id"] else DEFAULT_TARIFF["pf_limit"]
        st = {}
        for p in ps:
            vals = [r[0] for r in db.execute("SELECT value FROM en_params WHERE meter_id=? AND param=? AND ts>=? AND ts<?", (mid, p, a, b))]
            if vals:
                st[p] = {"avg": round(statistics.mean(vals), 3), "min": round(min(vals), 3), "max": round(max(vals), 3), "n": len(vals)}
                if p == "pf":
                    st[p]["low"] = round(100 * sum(1 for v in vals if v < lim) / len(vals), 1)
            last = db.execute("SELECT value, ts FROM en_params WHERE meter_id=? AND param=? ORDER BY ts DESC LIMIT 1", (mid, p)).fetchone()
            if last:
                st.setdefault(p, {})["last"], st[p]["last_at"] = last[0], last[1]
        rows.append({"m": m, "label": EN.label(m), "tags": ps, "st": st, "limit": lim,
                     "bad": bool(st.get("pf", {}).get("avg") is not None and st["pf"]["avg"] < lim)})
    rows.sort(key=lambda r: (not r["bad"], (r["st"].get("pf") or {}).get("avg") or 9))
    return {"rows": rows}


def pf_daily(db, mid: int, days: int = 30) -> dict:
    ensure(db)
    d_to = S.now_dt().date()
    d_from = d_to - timedelta(days=days - 1)
    out = {}
    for p in PARAMS:
        rows = db.execute("""SELECT substr(ts,1,10), AVG(value), MIN(value), MAX(value) FROM en_params WHERE meter_id=? AND param=? AND ts>=?
                             GROUP BY 1 ORDER BY 1""", (mid, p, d_from.isoformat())).fetchall()
        if rows:
            out[p] = [{"day": r[0], "avg": round(r[1], 3), "min": round(r[2], 3), "max": round(r[3], 3)} for r in rows]
    return out


# ───────────────────────── โครงสร้าง + ตรวจตัวคูณ ─────────────────────────

CT_STEPS = (1000, 100, 10)


def structure(db, fid: int, kind: str = "elec", days: int = 30) -> dict:
    """ต้นไม้มิเตอร์ (หลักรวม → หลัก Section → ย่อย) + สมดุล N วัน + คำแนะนำตัวคูณ/หน่วยที่น่าจะผิด"""
    today = S.now_dt().date()
    d_from, d_to = today - timedelta(days=days), today - timedelta(days=1)
    ms = EN.meters(db, fid, kind)
    by_id = {m["id"]: m for m in ms}
    ser = EN.series(db, ms, d_from, d_to) if ms else {}
    use = {m["id"]: round(sum((x.get("u") or 0) for x in (ser.get(m["id"]) or {}).values()), 1) for m in ms}
    n_days = {m["id"]: sum(1 for x in (ser.get(m["id"]) or {}).values() if x.get("u") is not None) for m in ms}
    cv = EN.covers(ms)
    kids: dict[int, list] = {}
    for m in ms:
        direct = [p for p in cv.get(m["id"], set()) if p in by_id]
        if direct:                                       # แม่ตรง = ตัวที่ลึกที่สุด (ถูกครอบโดยแม่ตัวอื่น)
            best = max(direct, key=lambda p: len([x for x in cv.get(p, set()) if x in by_id]))
            kids.setdefault(best, []).append(m)
    roots = [m for m in ms if not [p for p in cv.get(m["id"], set()) if p in by_id]]
    bal = {tuple(p["id"] for p in b["parents"]): b for b in EN.balance(ms, use)}
    sug: dict[int, str] = {}
    bal = {key[0]: b for key, b in bal.items()}          # ชุดหลายหลัก (เช่น IN COMING 1+2) แสดงที่หลักตัวแรก
    for key, b in list(bal.items()):
        key = (key,)
        if not b["pu"] or not b["ku"]:
            continue
        r = b["ku"] / b["pu"]
        for k in CT_STEPS:
            if 0.7 * k <= r <= 1.3 * k:
                sug[key[0]] = f"ย่อยรวม ≈ {k:,}× ของหลัก → ตัวคูณของมิเตอร์หลักน่าจะขาด ×{k:,} (หรือหน้าปัดเป็น MWh)"
            elif 0.7 / k <= r <= 1.3 / k:
                sug[key[0]] = f"หลัก ≈ {k:,}× ของย่อยรวม → มิเตอร์ย่อยบางตัวน่าจะขาดตัวคูณ ×{k:,}"
        if key[0] not in sug and (r > 1.25 or r < 0.5):
            sug[key[0]] = ("ย่อยรวมมากกว่าหลัก — ตรวจ CT ของมิเตอร์ย่อยที่ใช้มากผิดปกติ หรือย่อยบางตัวไม่ได้อยู่ใต้หลักนี้"
                           if r > 1.25 else "ย่อยรวมน้อยกว่าครึ่งของหลัก — ยังมีโหลดที่ไม่มีมิเตอร์ หรือ CT ของหลักสูงเกิน")
    flat = []

    def walk(m, depth):
        b = bal.get(m["id"])
        flat.append({"m": m, "label": EN.label(m), "depth": depth, "u": use[m["id"]], "nd": n_days[m["id"]], "bal": b,
                     "sug": sug.get(m["id"]), "n_kids": len(kids.get(m["id"], []))})
        for k in sorted(kids.get(m["id"], []), key=lambda x: (-(x["is_main"] == 1), x["grp"] or "", -use[x["id"]])):
            walk(k, depth + 1)
    for r in sorted(roots, key=lambda x: (-(x["is_main"] == 1), x["grp"] or "", -use[x["id"]])):
        walk(r, 0)
    return {"rows": flat, "d_from": d_from, "d_to": d_to, "days": days, "n_sug": len(sug),
            "total": round(sum(EN.sign(m) * use[m["id"]] for m in EN.counted(ms)), 1)}


def save_structure(db, fid: int, form, actor) -> int:
    """บันทึกหลายมิเตอร์พร้อมกันจากหน้าโครงสร้าง: บทบาท · มิเตอร์แม่ · ตัวคูณ (CT)"""
    n = 0
    for m in EN.meters(db, fid, None, active_only=False):
        k = str(m["id"])
        if f"role_{k}" not in form:
            continue
        role = {"1": 1, "0": 0, "-1": -1, "2": 2}.get(form.get(f"role_{k}"), m["is_main"])
        pv = str(form.get(f"parent_{k}") or "").strip()
        pid = int(pv) if pv.isdigit() else None
        try:
            mult = float(str(form.get(f"mult_{k}") or m["multiplier"]).replace(",", ""))
        except ValueError:
            raise S.ValidationError(f"ตัวคูณของ {EN.label(m)} ต้องเป็นตัวเลข") from None
        if mult <= 0:
            raise S.ValidationError(f"ตัวคูณของ {EN.label(m)} ต้องมากกว่า 0")
        if (role, pid, mult) == (m["is_main"], m.get("parent_id"), m["multiplier"]):
            continue
        if pid:
            EN.check_parent(db, m["id"], pid, m["kind"], m["factory_id"])
        db.execute("UPDATE en_meters SET is_main=?, parent_id=?, multiplier=? WHERE id=?", (role, pid, mult, m["id"]))
        S.audit(db, actor, "energy_structure", "en_meters", m["id"],
                before={"is_main": m["is_main"], "parent_id": m.get("parent_id"), "multiplier": m["multiplier"]},
                after={"is_main": role, "parent_id": pid, "multiplier": mult})
        n += 1
    return n


def demand_alerts(db, today: date | None = None) -> list[dict]:
    """โรงงานที่ kW On-Peak เดือนนี้เกิน/ใกล้เป้า (ใช้แสดงแจ้งเตือนบน Dashboard/หน้าไฟฟ้า)"""
    ensure(db)
    today = today or S.now_dt().date()
    out = []
    for r in db.execute("SELECT factory_id FROM en_tariff"):
        cfg = tariff(db, r[0])
        if not cfg.get("demand_target"):
            continue
        t = tou(db, r[0], today.replace(day=1), today)
        if t["over"] or t["near"]:
            f = db.execute("SELECT name FROM factories WHERE id=?", (r[0],)).fetchone()
            out.append({"fid": r[0], "name": f[0] if f else "", "peak": t["peak_on"], "at": t["peak_on_at"], "target": cfg["demand_target"],
                        "over": t["over"]})
    return out


def month_days(y: int, m: int) -> int:
    return calendar.monthrange(y, m)[1]
