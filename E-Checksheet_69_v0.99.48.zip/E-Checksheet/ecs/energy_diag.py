"""ecs/energy_diag.py — v0.99.40 ตรวจวินิจฉัยแหล่งข้อมูล SCADA ของ Energy + ข้อมูลดิบจาก SQL ต้นทาง

ถาม SQL ตรง ๆ (อ่านอย่างเดียว ห่อคำสั่งของผู้ใช้เป็น sub-query) แล้วบอกสาเหตุที่ "ดึงแล้วได้ 0 แถว" พร้อมปุ่มแก้:
 1 เชื่อมต่อ + ข้อมูลล่าสุดในตาราง          2 ความสดของข้อมูล / เวลาเพี้ยน (UTC, นาฬิกา SCADA)
 3 เงื่อนไขเวลา (?) ใน SQL ใช้ได้จริงไหม     4 Tag ที่จับคู่ยังมีข้อมูลไหม (ชื่อ Tag เปลี่ยน → แนะนำชื่อใหม่)
 5 รอบบันทึก (เช่น ทุก 15 นาที)              6 ค่าในช่วงเวลาอ่านเมื่อวาน/วันนี้ → ค่าอ่านรายวัน
 7 จุดดึงล่าสุด (watermark) ค้าง / เลยปัจจุบัน
raw(): ข้อมูลดิบของ Tag ในช่วงเวลาที่เลือก — ดูได้ว่าค่าอ่านรายวันมาจากแถวไหนของ SQL"""
from __future__ import annotations

import difflib
import json
import time as _time
from datetime import date, datetime, timedelta

from . import connectors as CN
from . import energy_src as ES
from . import services as S
from .services import parse_ts, ts

STATE_RANK = {"ok": 0, "info": 0, "warn": 1, "fail": 2}
RAW_MAX_DAYS = 7
SHIFT_STEPS = [m for h in range(1, 15) for m in (h * 60, -h * 60)]      # ค้นค่าชดเชยเวลาใน SQL ทีละชั่วโมง ±14 ชม.


def _dt(v) -> datetime | None:
    return CN._to_dt(v) if v is not None else None                    


def _fmt(d: datetime | None) -> str:
    return d.strftime("%d/%m/%Y %H:%M") if d else "–"


def _human(minutes: float) -> str:
    m = abs(round(minutes))
    if m < 60:
        return f"{m} นาที"
    if m < 1440 * 2:
        return f"{m / 60:.1f} ชม."
    return f"{m / 1440:.1f} วัน"


class _Probe:
    """ถาม SQL ด้วยเวลา "ท้องถิ่น" (หักเลื่อนเวลา + ชดเชยเวลาในเงื่อนไข ให้เหมือนตอนดึงจริง)"""

    def __init__(self, src: dict, extra_pshift: int = 0):
        self.src, self.kind, self.cfg = src, src["kind"], src["config"]
        self.shift = timedelta(minutes=int(src.get("ts_shift_min") or 0))
        self.pshift = ES.param_shift(src) + timedelta(minutes=extra_pshift)
        self.inner = CN.inner_query(self.cfg.get("query", "")) if self.kind in ("mssql", "sqlite") else None
        self.n_queries = 0
        self.ms = 0

    def p(self, wall: datetime):
        return CN.sql_param(self.kind, wall - self.shift - self.pshift)

    def run(self, sql: str, params: list, limit: int = 5000):
        t0 = _time.time()
        self.n_queries += 1
        try:
            return CN.query_any(self.kind, self.cfg, sql, params, limit)
        finally:
            self.ms += int((_time.time() - t0) * 1000)

    def _params(self, since: datetime, extra: list | None = None) -> list:
        return ([self.p(since)] if "?" in self.inner else []) + list(extra or [])

    def agg(self, since: datetime, until: datetime | None = None) -> dict:
        """MAX/MIN/COUNT ของข้อมูลหลัง since (เวลาที่ได้ = เวลาในคอลัมน์ ยังไม่เลื่อนเวลา)"""
        sql = f"SELECT MAX(q.ts) AS mx, MIN(q.ts) AS mn, COUNT(*) AS n, COUNT(DISTINCT q.tag) AS nt FROM ({self.inner}) q"
        extra = []
        if until is not None:
            sql += " WHERE q.ts <= ?"
            extra.append(self.p(until))
        _cols, rows = self.run(sql, self._params(since, extra), 1)
        mx, mn, n, nt = rows[0] if rows else (None, None, 0, 0)
        return {"mx": _dt(mx), "mn": _dt(mn), "n": int(n or 0), "nt": int(nt or 0)}

    def by_tag(self, since: datetime) -> dict[str, tuple[datetime | None, int, float | None]]:
        sql = f"SELECT q.tag AS tag, MAX(q.ts) AS last, COUNT(*) AS n FROM ({self.inner}) q GROUP BY q.tag"
        _cols, rows = self.run(sql, self._params(since), 20000)
        out = {}
        for tag, last, n in rows:
            if tag in (None, ""):
                continue
            out[str(tag).strip()] = (_dt(last), int(n or 0), None)
        return out


def _check(key, title, state, msg, detail=None, actions=None) -> dict:
    return {"key": key, "title": title, "state": state, "msg": msg, "detail": detail or [], "actions": actions or []}


def diagnose(db, sid: int, now: datetime | None = None) -> dict:
    now = now or S.now_dt()
    src = ES.get_source(db, sid)
    if not src:
        raise CN.SourceError("ไม่พบแหล่งข้อมูล")
    checks: list[dict] = []
    shift_min = int(src.get("ts_shift_min") or 0)
    pshift_min = int(ES.param_shift(src).total_seconds() // 60)
    interval = int(src.get("interval_min") or 15)
    late = int(src.get("late_min") if src.get("late_min") is not None else CN.LATE_MIN_DEFAULT)
    hh, mm, win = ES._read_cfg(db)                                     
    mapped = ES.mapped_tags(db, sid)
    meters = {r[0].strip(): r[1] for r in db.execute(
        "SELECT TRIM(scada_tag), COUNT(*) FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>'' AND active=1 GROUP BY TRIM(scada_tag)", (sid,))}
    facts = {"now": now, "shift": shift_min, "pshift": pshift_min, "interval": interval, "late": late, "mapped": len(mapped),
             "meters": sum(meters.values()), "watermark": parse_ts(src["watermark"]) if src.get("watermark") else None,
             "read": f"{hh:02d}:{mm:02d} ± {win} นาที", "queries": 0, "ms": 0, "newest": None, "kind": src["kind"]}
    out = {"source": src, "facts": facts, "checks": checks, "verdict": "ok", "headline": "", "tags": None}
    if src["kind"] not in ("mssql", "sqlite"):
        checks.append(_check("kind", "ชนิดแหล่งข้อมูล", "info",
                             "ตรวจวินิจฉัยเชิงลึกใช้กับ SQL Server / SQLite — แหล่งชนิดนี้ใช้ “ทดสอบ” และประวัติการดึงข้อมูลแทน"))
        return _finish(out)
    pr = _Probe(src)
    # ── 1 เชื่อมต่อ + ข้อมูลล่าสุด ──
    if pr.inner is None:
        checks.append(_check("conn", "คำสั่ง SQL", "warn", "คำสั่งเป็นแบบ WITH / TOP — ตรวจวินิจฉัยเชิงลึกไม่ได้ ใช้ปุ่ม “ทดสอบ” แทน"))
        return _finish(out)
    try:
        a62 = pr.agg(now - timedelta(days=62))
    except CN.SourceError as exc:
        checks.append(_check("conn", "เชื่อมต่อ / คำสั่ง SQL", "fail", str(exc),
                             ["ตรวจ Connection string, สิทธิ์ผู้ใช้ readonly, ชื่อตาราง และคอลัมน์ (ต้องคืน tag, ts, value)"]))
        return _finish(out, pr)
    a_all = a62
    compare_broken = False
    if not a62["n"]:
        try:
            a_all = pr.agg(datetime.fromisoformat("2000-01-01"))
        except CN.SourceError as exc:
            a_all = {"mx": None, "n": 0, "nt": 0, "mn": None}
            checks.append(_check("conn", "เชื่อมต่อ / คำสั่ง SQL", "fail", str(exc)))
            return _finish(out, pr)
    mx = (a_all["mx"] + pr.shift) if a_all["mx"] else None
    facts["newest"] = mx
    if not a_all["n"] or not mx:
        checks.append(_check("conn", "ข้อมูลในตาราง", "fail", "เชื่อมต่อได้ แต่คำสั่ง SQL ไม่คืนข้อมูลเลย",
                             ["ตรวจชื่อตาราง/มุมมอง (เช่น History) และเงื่อนไข WHERE ในคำสั่ง SQL",
                              "ลองรันคำสั่งเดียวกันใน SQL Server Management Studio โดยแทน ? ด้วยเวลาเมื่อวาน"]))
        return _finish(out, pr)
    if not a62["n"]:
        if mx >= now - timedelta(days=62):
            compare_broken = True                     # มีข้อมูลล่าสุด แต่ WHERE ts > ? (62 วันก่อน) ไม่คืน → การเทียบเวลาใน SQL เพี้ยน
        else:
            checks.append(_check("conn", "ข้อมูลในตาราง", "fail",
                                 f"ข้อมูลล่าสุดในคำสั่ง SQL นี้คือ {_fmt(mx)} — หลังจากนั้นไม่มีข้อมูลเลย",
                                 ["SCADA / DataLog อาจหยุดเขียนตารางนี้ หรือย้ายไปเขียนตาราง/ฐานข้อมูลใหม่ → แก้คำสั่ง SQL ให้ชี้ไปที่ตารางปัจจุบัน"]))
            return _finish(out, pr)
    checks.append(_check("conn", "เชื่อมต่อ / คำสั่ง SQL", "ok",
                         f"เชื่อมต่อได้ · ข้อมูล 62 วันล่าสุด {a62['n']:,} แถว · {a62['nt']} Tag · ข้อมูลล่าสุด {_fmt(mx)}"))
    # ── 2 ความสด / เวลาเพี้ยน ──
    lag = (now - mx).total_seconds() / 60
    fresh_lim = max(3 * interval, 45)
    hours = round(lag / 60)
    if lag < -ES.FUTURE_TOL_MIN:
        acts, why = [], []
        if shift_min and abs(-lag - shift_min) <= 30:
            acts.append({"do": "set_shift", "value": 0, "label": "ตั้ง “เลื่อนเวลา” เป็น 0 (ข้อมูลเป็นเวลาไทยอยู่แล้ว)"})
            why.append(f"ตั้ง “เลื่อนเวลา” ไว้ {shift_min:+d} นาที แต่ข้อมูลใน SQL เป็นเวลาไทยอยู่แล้ว → เวลาเลยปัจจุบัน")
        elif hours and abs(-lag - (-hours) * 60) <= 20:
            acts.append({"do": "set_shift", "value": shift_min + hours * 60, "label": f"ตั้ง “เลื่อนเวลา” เป็น {shift_min + hours * 60:+d} นาที"})
            why.append(f"เวลาของข้อมูลเร็วกว่าเวลาเซิร์ฟเวอร์ราว {-hours} ชม. พอดี — นาฬิกา/โซนเวลาของเครื่อง SCADA หรือเครื่องเซิร์ฟเวอร์ไม่ตรงกัน")
        else:
            why.append("นาฬิกาเครื่อง SCADA เดินเร็ว หรือมีแถวที่บันทึกเวลาผิด")
        why.append(f"เวลาเซิร์ฟเวอร์ E-Checksheet ตอนตรวจ: {_fmt(now)} — ถ้าไม่ตรงกับเวลาจริง ให้ตั้งเวลา/โซนเวลาของเครื่องเซิร์ฟเวอร์")
        checks.append(_check("fresh", "เวลาของข้อมูล", "fail", f"ข้อมูลล่าสุด {_fmt(mx)} เลยเวลาปัจจุบัน {_human(-lag)}", why, acts))
    elif lag <= fresh_lim + late:
        checks.append(_check("fresh", "ความสดของข้อมูล", "ok", f"ข้อมูลล่าสุด {_fmt(mx)} (ก่อนตอนนี้ {_human(lag)})"))
    elif 1 <= hours <= 14 and abs(lag - hours * 60) <= 20:
        sug = shift_min + hours * 60
        checks.append(_check("fresh", "เวลาของข้อมูล", "warn",
                             f"ข้อมูลล่าสุด {_fmt(mx)} ช้ากว่าปัจจุบัน {hours} ชม. พอดี — ข้อมูลน่าจะเก็บเป็นเวลา {'UTC' if hours == 7 else 'อีกโซนเวลา'}",
                             ["ถ้าข้อมูลใน SQL ยังบันทึกต่อเนื่อง (รอบล่าสุดห่างกันตามรอบปกติ) ให้ตั้ง “เลื่อนเวลา” ให้เป็นเวลาไทย"],
                             [{"do": "set_shift", "value": sug, "label": f"ตั้ง “เลื่อนเวลา” เป็น {sug:+d} นาที"}] if -1440 <= sug <= 1440 else []))
    else:
        checks.append(_check("fresh", "ความสดของข้อมูล", "fail" if lag > 1440 else "warn",
                             f"ข้อมูลล่าสุดใน SQL คือ {_fmt(mx)} — ห่างจากปัจจุบัน {_human(lag)}",
                             ["SCADA / DataLog หยุดเขียน หรือเขียนไปตารางอื่น — ตรวจที่เครื่อง SCADA",
                              "ถ้ามั่นใจว่ามีข้อมูลใหม่ใน SQL ให้ดูข้อ “เงื่อนไขเวลาใน SQL” ด้านล่าง"]))
    # ── 3 เงื่อนไขเวลา (?) ──
    if "?" in pr.inner:
        probe_from = mx - timedelta(hours=2)
        try:
            n2 = pr.agg(probe_from)["n"] if not compare_broken else 0
        except CN.SourceError:
            n2 = 0
        if n2:
            checks.append(_check("param", "เงื่อนไขเวลาใน SQL ( ? )", "ok",
                                 f"WHERE … > ? ทำงานถูกต้อง (2 ชม. ล่าสุดของข้อมูล {n2:,} แถว)"
                                 + (f" · ชดเชยเวลาในเงื่อนไข {pshift_min:+d} นาที" if pshift_min else "")))
        else:
            found = None
            tol = timedelta(minutes=max(int(1.5 * interval), 30))
            for k in SHIFT_STEPS:                         # ค่าแรกที่ทำให้ได้ข้อมูลเริ่มที่ต้นช่วงพอดี (ไม่ใช่แค่ได้บางแถว)
                try:
                    r = _Probe(src, k).agg(probe_from)
                except CN.SourceError:
                    break
                if r["n"] and r["mn"] and r["mn"] + pr.shift <= probe_from + tol:
                    found = k
                    break
            facts["queries"] += len(SHIFT_STEPS)
            if found is not None:
                val = pshift_min + found
                checks.append(_check("param", "เงื่อนไขเวลาใน SQL ( ? )", "fail",
                                     f"SQL มีข้อมูลถึง {_fmt(mx)} แต่ WHERE … > ? คืน 0 แถว — การเทียบเวลาใน SQL ต่างจากเวลาที่คืนมา {found // 60:+d} ชม.",
                                     ["มักเกิดกับคอลัมน์ DATETIMEOFFSET หรือเก็บเป็น UTC: SQL เทียบเป็นเวลา UTC แต่คืนค่าเป็นเวลาไทย",
                                      "ผลคือรอบดึงปกติได้ 0 แถว และค่าอ่านรายวันขาด — แก้ได้โดยชดเชยเวลาที่ส่งให้ SQL (ระบบกรองช่วงเวลาจริงให้อีกชั้น)"],
                                     [{"do": "set_pshift", "value": val, "label": f"ตั้ง “ชดเชยเวลาในเงื่อนไข SQL” เป็น {val:+d} นาที แล้วดึงใหม่"}]))
            else:
                checks.append(_check("param", "เงื่อนไขเวลาใน SQL ( ? )", "fail",
                                     f"SQL มีข้อมูลถึง {_fmt(mx)} แต่ WHERE … > ? ไม่คืนแถวใหม่",
                                     [("คอลัมน์เวลาอาจเป็นข้อความ (varchar) — แก้คำสั่ง SQL ให้แปลงก่อนเทียบ เช่น "
                                       "WHERE CONVERT(datetime2, [DateTime]) > ?"),
                                      "หรือคอลัมน์ DATETIMEOFFSET — ใช้ WHERE CAST([DateTime] AS datetime2) > ?"]))
    # ── 4 Tag ──
    tag_since = now - timedelta(days=2) if lag <= 1440 * 2 else mx - timedelta(days=2)
    try:
        _tag_checks(db, sid, checks, out, pr.by_tag(tag_since), mapped, meters, mx, tag_since)
    except CN.SourceError as exc:
        checks.append(_check("tags", "Tag ที่จับคู่", "warn", f"สรุปราย Tag ไม่ได้: {exc}"))
    # ── 6 ค่าในช่วงเวลาอ่าน ──
    _reading_check(db, src, checks, now, hh, mm, win, mapped)
    # ── 7 จุดดึงล่าสุด ──
    wm = facts["watermark"]
    runs = [dict(r) for r in db.execute("SELECT status, rows_read, message, started_at FROM en_source_runs WHERE source_id=? ORDER BY id DESC LIMIT 12", (sid,))]
    zero = 0
    for r in runs:
        if r["status"] == "ok" and not r["rows_read"]:
            zero += 1
        else:
            break
    facts["zero_runs"] = zero
    if wm and wm > now + timedelta(minutes=ES.FUTURE_TOL_MIN):
        checks.append(_check("wm", "จุดดึงล่าสุด (ข้อมูลถึง)", "fail", f"จุดดึงล่าสุด {_fmt(wm)} เลยเวลาปัจจุบัน — รอบดึงขอเฉพาะข้อมูลหลังเวลานี้ จึงได้ 0 แถว",
                             ["ระบบรีเซ็ตให้เองในรอบดึงถัดไป หรือกดรีเซ็ตตอนนี้"],
                             [{"do": "reset_wm", "value": 0, "label": "รีเซ็ตจุดดึง + ดึงใหม่ + เติมค่ารายวัน 14 วัน"}]))
    elif wm and mx and wm < mx - timedelta(minutes=late + 3 * interval) and src.get("active"):
        checks.append(_check("wm", "จุดดึงล่าสุด (ข้อมูลถึง)", "fail",
                             f"จุดดึงค้างที่ {_fmt(wm)} แต่ SQL มีข้อมูลถึง {_fmt(mx)}" + (f" · ดึงได้ 0 แถวติดกัน {zero} รอบ" if zero else ""),
                             ["ดูสาเหตุในข้อ “เงื่อนไขเวลาใน SQL” และ “Tag ที่จับคู่” ด้านบน แก้แล้วกดรีเซ็ต"],
                             [{"do": "reset_wm", "value": 0, "label": "รีเซ็ตจุดดึง + ดึงใหม่ + เติมค่ารายวัน 14 วัน"}]))
    else:
        checks.append(_check("wm", "จุดดึงล่าสุด (ข้อมูลถึง)", "ok", f"จุดดึงล่าสุด {_fmt(wm)}" + (f" · 0 แถวติดกัน {zero} รอบ" if zero else "")))
    return _finish(out, pr)


def _tag_checks(db, sid, checks, out, found, mapped, meters, mx, since):
    pr_shift = timedelta(minutes=int(out["source"].get("ts_shift_min") or 0))
    found = {t: ((last + pr_shift) if last else None, n, v) for t, (last, n, v) in found.items()}
    m_set = set(mapped)
    hit = sorted(m_set & set(found))
    miss = sorted(m_set - set(found))
    free = sorted(set(found) - m_set)
    sugg = []
    taken = set()
    for t in miss:
        c = _rename_match(t, [f for f in free if f not in taken])
        if c:
            taken.add(c)
            sugg.append({"old": t, "new": c, "meters": meters.get(t, 0)})
    stale = [t for t in hit if found[t][0] and mx and found[t][0] < mx - timedelta(hours=6)]
    ns = sorted(n for _l, n, _v in found.values() if n)
    cadence = None
    if ns:
        span = max(1.0, ((mx or since) - since).total_seconds() / 60)
        cadence = round(span / max(1, ns[len(ns) // 2]))
    out["tags"] = {"hit": hit, "miss": miss, "free_n": len(free), "sugg": sugg, "stale": stale, "found": found,
                   "cadence": cadence, "since": since}
    detail = [f"จับคู่ไว้ {len(m_set)} Tag · พบข้อมูลใน 2 วันล่าสุด {len(hit)} Tag · Tag อื่นใน SQL ที่ยังไม่จับคู่ {len(free)}"]
    if miss:
        detail.append("Tag ที่จับคู่แต่ไม่พบข้อมูล: " + ", ".join(miss[:12]) + (f" … อีก {len(miss) - 12}" if len(miss) > 12 else ""))
    if stale:
        detail.append("Tag ที่ค่าค้าง (เกิน 6 ชม.): " + ", ".join(stale[:10]))
    acts = []
    if sugg:
        detail.append("ชื่อ Tag ที่น่าจะเปลี่ยนใหม่: " + ", ".join(f"{s['old']} → {s['new']}" for s in sugg[:8]))
        acts.append({"do": "remap", "value": json.dumps([[s["old"], s["new"]] for s in sugg], ensure_ascii=False),
                     "label": f"เปลี่ยนชื่อ Tag ให้มิเตอร์ตามที่แนะนำ ({len(sugg)}) แล้วเติมค่ารายวัน 14 วัน"})
    if not m_set:
        checks.append(_check("tags", "Tag ที่จับคู่", "warn", "ยังไม่ได้จับคู่ Tag กับมิเตอร์ — ไปที่ “จับคู่ Tag → มิเตอร์”", detail, acts))
    elif not hit:
        checks.append(_check("tags", "Tag ที่จับคู่", "fail", "Tag ที่จับคู่ไว้ไม่มีข้อมูลใน SQL เลย — ชื่อ Tag ใน SQL อาจเปลี่ยน", detail, acts))
    elif miss or stale:
        checks.append(_check("tags", "Tag ที่จับคู่", "warn", f"มีข้อมูล {len(hit)}/{len(m_set)} Tag", detail, acts))
    else:
        checks.append(_check("tags", "Tag ที่จับคู่", "ok", f"มีข้อมูลครบ {len(hit)}/{len(m_set)} Tag", detail))
    if cadence:
        checks.append(_check("cadence", "รอบบันทึกของ SCADA", "info", f"บันทึกประมาณทุก {cadence} นาที ต่อ Tag"))


def _tokens(tag: str) -> list[str]:
    import re
    return [x for x in re.split(r"[^0-9a-z]+", tag.lower()) if x]


def _rename_match(old: str, cands: list[str]) -> str | None:
    """ชื่อ Tag ใหม่ที่น่าจะเป็นตัวเดียวกัน (DataLog ตั้งชื่อใหม่ เช่น PM_F1_MDB1 → F1.PM.MDB1.kWh)
    ใช้ส่วนของชื่อ (คำ/ตัวเลข) ครบทุกส่วน + ความคล้ายของตัวอักษร · ต้องชัดเจนกว่าตัวเลือกอันดับสอง"""
    to = _tokens(old)
    if not to:
        return None
    scored = []
    for c in cands:
        tc = _tokens(c)
        cover = sum(1 for x in to if x in tc) / len(to)
        if cover < 1:
            continue
        ratio = difflib.SequenceMatcher(None, " ".join(sorted(to)), " ".join(sorted(tc))).ratio()
        scored.append((cover + ratio - 0.02 * abs(len(tc) - len(to)), c))
    if not scored:
        best = difflib.get_close_matches(old, cands, n=1, cutoff=0.85)
        return best[0] if best else None
    scored.sort(reverse=True)
    if len(scored) > 1 and scored[0][0] - scored[1][0] < 0.05:
        return None
    return scored[0][1]


def _reading_check(db, src, checks, now, hh, mm, win, mapped):
    if not mapped:
        return
    rows_out = []
    worst = "ok"
    for d in (now.date() - timedelta(days=1), now.date()):
        t = datetime.combine(d, datetime.min.time()).replace(hour=hh, minute=mm)
        if now < t + timedelta(minutes=win):
            continue
        try:
            rows, _k, _b = ES.fetch_all(db, dict(src), now, tags=mapped, since=t - timedelta(minutes=win + 1), until=t + timedelta(minutes=win + 1))
        except CN.SourceError as exc:
            checks.append(_check("read", "ค่าในช่วงเวลาอ่าน", "warn", f"ดึงช่วงเวลาอ่านไม่ได้: {exc}"))
            return
        have = {r[0] for r in rows}
        m_ids = [r[0] for r in db.execute("SELECT id FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>'' AND active=1", (src["id"],))]
        got = db.execute(f"SELECT COUNT(*) FROM en_readings WHERE day=? AND meter_id IN ({','.join('?' * len(m_ids))})",
                         [d.isoformat(), *m_ids]).fetchone()[0] if m_ids else 0
        st = "ok" if len(have) >= len(set(mapped)) and got >= len(m_ids) else ("warn" if have else "fail")
        if STATE_RANK[st] > STATE_RANK[worst]:
            worst = st
        rows_out.append({"day": d, "at": t, "sql": len(have), "tags": len(set(mapped)), "got": got, "meters": len(m_ids)})
    if not rows_out:
        return
    detail = [f"{r['day'].strftime('%d/%m')} {r['at'].strftime('%H:%M')} ± {win} นาที: มีค่าใน SQL {r['sql']}/{r['tags']} Tag · ลงค่าอ่านแล้ว {r['got']}/{r['meters']} มิเตอร์"
              for r in rows_out]
    acts = []
    if any(r["sql"] and r["got"] < r["meters"] for r in rows_out):
        acts.append({"do": "fill", "value": 14, "label": "เติมค่ารายวันที่ขาดจาก SQL (14 วัน)"})
    msg = "ค่าในช่วงเวลาอ่านครบ และลงค่าอ่านรายวันแล้ว" if worst == "ok" else (
        "SQL มีค่าในช่วงเวลาอ่าน แต่ค่าอ่านรายวันยังไม่ครบ" if any(r["sql"] for r in rows_out) else "SQL ไม่มีค่าในช่วงเวลาอ่านของ Tag ที่จับคู่")
    checks.append(_check("read", "ค่าในช่วงเวลาอ่าน → ค่าอ่านรายวัน", worst, msg, detail, acts))


def _finish(out: dict, pr: _Probe | None = None) -> dict:
    if pr:
        out["facts"]["queries"] += pr.n_queries
        out["facts"]["ms"] = pr.ms
    worst = "ok"
    for c in out["checks"]:
        if STATE_RANK.get(c["state"], 0) > STATE_RANK[worst]:
            worst = c["state"]
    out["verdict"] = worst
    bad = [c for c in out["checks"] if c["state"] in ("fail", "warn")]
    out["headline"] = bad[0]["msg"] if bad else f"ตรวจ {len(out['checks'])} ข้อ — ไม่พบปัญหา · ดึงข้อมูลและลงค่าอ่านรายวันได้ตามปกติ"
    return out


# ───────────────────────── แก้ไขตามที่ตรวจพบ ─────────────────────────

def apply(db, sid: int, action: str, value, actor, now: datetime | None = None) -> str:
    """ปุ่มแก้จากหน้าตรวจวินิจฉัย → ข้อความผลลัพธ์"""
    now = now or S.now_dt()
    src = ES.get_source(db, sid)
    if not src:
        raise CN.SourceError("ไม่พบแหล่งข้อมูล")
    notes = []
    if action == "set_shift":
        v = int(float(value))
        if not -1440 <= v <= 1440:
            raise CN.SourceError("เลื่อนเวลา −1440 ถึง 1440 นาที")
        db.execute("UPDATE en_sources SET ts_shift_min=?, watermark='' WHERE id=?", (v, sid))
        S.audit(db, actor, "update", "en_sources", sid, before={"ts_shift_min": src.get("ts_shift_min")},
                after={"ts_shift_min": v, "reason": "ตรวจวินิจฉัย: ตั้งเลื่อนเวลาตามที่แนะนำ"})
        notes.append(f"ตั้งเลื่อนเวลา {v:+d} นาที")
        r = ES.reapply(db, sid, 14, actor, None, now)
        if r:
            notes.append(f"ลงค่าอ่านใหม่ย้อนหลัง {r['days']} วัน ได้ {r['readings']} ค่า")
    elif action == "set_pshift":
        v = int(float(value))
        if not -1440 <= v <= 1440:
            raise CN.SourceError("ชดเชยเวลา −1440 ถึง 1440 นาที")
        cfg = {**src["config"], "param_shift_min": v}
        if not v:
            cfg.pop("param_shift_min", None)
        db.execute("UPDATE en_sources SET config_json=?, watermark='' WHERE id=?", (json.dumps(cfg, ensure_ascii=False), sid))
        S.audit(db, actor, "update", "en_sources", sid, before={"param_shift_min": ES.param_shift(src).total_seconds() // 60},
                after={"param_shift_min": v, "reason": "ตรวจวินิจฉัย: ชดเชยเวลาในเงื่อนไข SQL"})
        notes.append(f"ตั้งชดเชยเวลาในเงื่อนไข SQL {v:+d} นาที")
        notes += _repull(db, sid, now)
    elif action == "reset_wm":
        db.execute("UPDATE en_sources SET watermark='', catchup=0 WHERE id=?", (sid,))
        S.audit(db, actor, "update", "en_sources", sid, before={"watermark": src.get("watermark")}, after={"watermark": "", "reason": "ตรวจวินิจฉัย: รีเซ็ตจุดดึง"})
        notes.append("รีเซ็ตจุดดึงแล้ว")
        notes += _repull(db, sid, now)
    elif action == "remap":
        pairs = json.loads(value or "[]")
        n = 0
        for old, new in pairs:
            n += db.execute("UPDATE en_meters SET scada_tag=? WHERE scada_source_id=? AND TRIM(scada_tag)=?", (str(new).strip(), sid, str(old).strip())).rowcount
        S.audit(db, actor, "update", "en_meters", sid, after={"remap": pairs[:200], "reason": "ตรวจวินิจฉัย: เปลี่ยนชื่อ Tag"})
        notes.append(f"เปลี่ยนชื่อ Tag ให้มิเตอร์ {n} ตัว")
        notes += _repull(db, sid, now)
    elif action == "fill":
        notes += _fill(db, sid, now, int(float(value or 14)))
    else:
        raise CN.SourceError("ไม่รู้จักคำสั่ง")
    return " · ".join(notes)


def _fill(db, sid, now, days=14) -> list[str]:
    src = ES.get_source(db, sid)
    try:
        r = ES.fill_range(db, src, now.date() - timedelta(days=days - 1), now.date(), now)
    except Exception as exc:                                          # noqa: BLE001
        return [f"เติมค่ารายวันไม่สำเร็จ: {getattr(exc, 'errors', [exc])[0]}"]
    return [f"เติมค่ารายวัน {days} วัน ได้ {r.get('readings', 0)} ค่า"]


def _repull(db, sid, now) -> list[str]:
    r = ES.run_source(db, sid, manual=True, now=now)
    return [("ดึงใหม่: " if r["ok"] else "ดึงใหม่ไม่สำเร็จ: ") + r["message"]] + _fill(db, sid, now)


# ───────────────────────── ข้อมูลดิบจาก SQL ต้นทาง ─────────────────────────

def raw(db, sid: int, tag: str, d_from: date, d_to: date, now: datetime | None = None) -> dict:
    """แถวจาก SQL ของ Tag เดียว (เวลาหลังเลื่อนเวลาแล้ว) + เวลาอ่านของแต่ละวัน + ค่าอ่านรายวันที่ระบบลงไว้"""
    now = now or S.now_dt()
    src = ES.get_source(db, sid)
    if not src:
        raise CN.SourceError("ไม่พบแหล่งข้อมูล")
    if d_to < d_from:
        d_from, d_to = d_to, d_from
    d_from = max(d_from, d_to - timedelta(days=RAW_MAX_DAYS - 1))
    since = datetime.combine(d_from, datetime.min.time()) - timedelta(seconds=1)
    until = min(datetime.combine(d_to, datetime.max.time()).replace(microsecond=0), now + timedelta(days=1))
    fsrc = dict(src)
    rows, _k, bad = ES.fetch(db, fsrc, now, tags=[tag], since=since, until=until)
    hh, mm, win = ES._read_cfg(db)                                     
    sc = db.execute("SELECT scale, add_offset FROM en_source_tags WHERE source_id=? AND tag=?", (sid, tag)).fetchone()
    k, o = (sc[0] or 1.0, sc[1] or 0.0) if sc else (1.0, 0.0)
    meters = [dict(r) for r in db.execute("SELECT id, code, name FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)=?", (sid, tag))]
    days = []
    d = d_from
    while d <= d_to:
        t = datetime.combine(d, datetime.min.time()).replace(hour=hh, minute=mm)
        reads = []
        for m in meters:
            r = db.execute("SELECT value, src, read_at, note FROM en_readings WHERE meter_id=? AND day=?", (m["id"], d.isoformat())).fetchone()
            reads.append({"meter": m, "reading": dict(r) if r else None})
        days.append({"day": d, "at": t, "reads": reads})
        d += timedelta(days=1)
    shift = timedelta(minutes=int(src.get("ts_shift_min") or 0))
    read_at = {r["reading"]["read_at"] for x in days for r in x["reads"] if r["reading"] and r["reading"].get("read_at")}
    out = [{"ts": dt, "sql_ts": dt - shift, "value": v, "scaled": v * k + o, "used": ts(dt) in read_at,
            "in_win": any(abs((dt - x["at"]).total_seconds()) <= win * 60 for x in days), "future": dt > now + timedelta(minutes=ES.FUTURE_TOL_MIN)}
           for _t, dt, v in rows]
    return {"source": src, "tag": tag, "rows": out, "bad": bad, "days": days, "meters": meters, "from": d_from, "to": d_to,
            "win": win, "read": f"{hh:02d}:{mm:02d}", "scale": k, "offset": o, "truncated": bool(fsrc.get("_truncated")),
            "shift": int(src.get("ts_shift_min") or 0), "pshift": int(ES.param_shift(src).total_seconds() // 60)}
