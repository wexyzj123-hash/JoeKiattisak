"""v0.99.46: ตรวจทุกหน้า Energy — แก้ตัวเลขที่ทำให้เข้าใจผิด + หน้าเปิดมาไม่ว่าง
· มิเตอร์ที่เดือนนี้ไม่ส่งข้อมูลเลย ไม่นับในยอดเดือนก่อน (เดิม: กลายเป็น “ลดได้ ▼100%” · CO₂ ลดเกินจริง) + แจ้งเตือนแยก
· ความครบของยอดรายวันไม่นับมิเตอร์ที่ไม่ส่งข้อมูลทั้งเดือน (เดิม: “ข้อมูลยังไม่ครบ” ตลอด → ไม่เคยเทียบวันก่อน)
· กราฟแนวโน้มตัดวันท้ายที่ยังไม่ปิดยอด (เดิม: เส้นดิ่งลงเหมือนใช้น้อย)
· หน้าตาราง / บันทึกค่า / ต้นทุน เปิดที่โรงงาน + ประเภทที่มีข้อมูลล่าสุด (เดิม: โรงงานแรก + น้ำใช้ → ว่าง)"""
import json
import re
from datetime import timedelta

from conftest import login
from ecs import energy as EN
from ecs import energy_manage as MG
from ecs import services as S


def _rd(db, mid, day, v):
    db.execute("INSERT INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,?,?)", (mid, day.isoformat(), v, "manual", S.ts()))


def _setup(app, db):
    today = S.now_dt().date()
    m0 = today.replace(day=1)
    p0 = (m0 - timedelta(days=1)).replace(day=1)
    live = EN.save_meter(db, None, {"factory_id": app.config["F2"], "kind": "elec", "code": "L1", "name": "Live"}, None)
    dead = EN.save_meter(db, None, {"factory_id": app.config["F2"], "kind": "elec", "code": "D1", "name": "Dead"}, None)
    d = p0 - timedelta(days=1)                            # เริ่มก่อน 1 วัน → วันที่ 1 ของเดือนก่อนมีผลต่างให้คำนวณ
    while d <= today:                                    # ใช้ 100/วัน ต่อเนื่อง (เลขหน้าปัดไม่กระโดดข้ามเดือน)
        k = (d - p0).days
        _rd(db, live, d, 1000 + 100 * k)
        if d < p0 + timedelta(days=25):                  # ตัวที่ตาย: มีค่าแค่เดือนก่อน
            _rd(db, dead, d, 5000 + 100 * k)
        d += timedelta(days=1)
    db.commit()
    return today, m0, live, dead


def test_dead_meter_not_counted_as_saving(app, db):
    today, m0, _live, _dead = _setup(app, db)
    if today.day < 3:
        return                                            # ต้นเดือนยังไม่มีวันที่ปิดยอดพอเทียบ
    d = EN.dashboard(db, m0, app.config["F2"], "elec", today)
    k = d["kinds"][0]
    assert "D1 Dead" in " ".join(k["nodata"])
    assert k["change"] is not None and abs(k["change"]) < 1.0, k["change"]           # เดิม ≈ −50% (ตัวที่ตายถูกนับเป็นลด)
    U = MG.build(db, m0, app.config["F2"])
    row = next(r for kk in U["kinds"] for r in kk["rows"] if r["fid"] == app.config["F2"]) if U.get("kinds") and "rows" in U["kinds"][0] else None
    if row:
        assert row["chg"] is None or abs(row["chg"]) < 1.0


def test_dashboard_banner_coverage_and_trend_trim(app, db, client):
    today, _m0, _live, _dead = _setup(app, db)
    if today.day < 3:
        return
    login(client, "t_admin")
    html = client.get(f"/energy/?factory={app.config['F2']}").get_data(as_text=True)
    assert "ไม่ส่งข้อมูลเลย" in html and "ไม่นับ" in html
    data = json.loads(re.search(r'<script type="application/json" id="cr-data">(.*?)</script>', html, re.DOTALL).group(1))
    e = data["kp"]["elec"]
    assert len(e["daily"]) == len(data["days"]) and e["daily"] and e["daily"][-1] > 0                # ไม่มีวันท้ายที่เป็น 0
    assert "ข้อมูลยังไม่ครบ (1/2)" not in html                                                         # ไม่นับตัวที่ตายในความครบ


def test_pages_open_on_factory_and_kind_with_data(app, db, client):
    _setup(app, db)
    login(client, "t_admin")
    for url in ("/energy/sheet", "/energy/entry"):
        html = client.get(url).get_data(as_text=True)
        assert "ยังไม่มีมิเตอร์น้ำใช้" not in html, url                                                  # เดิม: น้ำใช้ของโรงงานแรก → ว่าง
    from ecs.views.energy import _default_fk
    with app.test_request_context():
        f, k = _default_fk(db, None, None)
    assert f == app.config["F2"] and k == "elec"
    assert _default_fk(db, app.config["F2"], "water") == (app.config["F2"], "water")                   # ผู้ใช้เลือกเอง → ใช้ตามนั้น
