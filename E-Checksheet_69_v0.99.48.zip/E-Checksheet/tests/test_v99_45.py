"""v0.99.45: หน้าภาพรวม Energy — เจาะดูรายวันทุก 15 นาที + ใช้ลด/เพิ่มตรงไหน (เดือนนี้ vs เดือนก่อน)
· /energy/api/drill: โหลด 96 ช่วง · เทียบเมื่อวาน/สัปดาห์ก่อน · สูงสุด · โหลดกลางคืน · ในเวลางาน/นอกเวลา · มิเตอร์ที่เปลี่ยน + ลิงก์กราฟ/ข้อมูลดิบ SQL
· /energy/api/shape: โปรไฟล์รายชั่วโมงเฉลี่ยต่อวัน 2 เดือน · 4 ช่วงเวลา · Heatmap · มิเตอร์ที่ลด/เพิ่ม · มิเตอร์ที่เดือนนี้ไม่มีค่า ไม่นับเป็น “ลดได้”"""
import json
import sqlite3 as _sq
from datetime import date as _date
from datetime import datetime as _dt
from datetime import time as _time
from datetime import timedelta

from _scada_sim import build
from conftest import login
from ecs import energy as EN
from ecs import energy_compare as CMP
from ecs import energy_drill as DR
from ecs import energy_src as ES
from ecs import services as S


def _plant(app, db, tmp_path, days=40):
    now = S.now_dt()
    path = str(tmp_path / "scada.db")
    build(path, now, days=days, step_min=15)
    sid = ES.save_source(db, {"name": "SQL", "kind": "sqlite", "active": "1", "config": json.dumps({
        "path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 1})}, None)
    mid = EN.save_meter(db, None, {"factory_id": app.config["F1"], "kind": "elec", "code": "KA", "name": "MDB KA",
                                   "scada_source_id": str(sid), "scada_tag": "KA"}, None)
    db.commit()
    ES.backfill(db, sid, now.date() - timedelta(days=days - 1), now.date(), "fill", None, now=now)
    ES.run_source(db, sid, now=now)
    db.commit()
    return now, sid, mid


def test_day_detail_15min_and_meter_links(app, db, client, tmp_path):
    now, sid, mid = _plant(app, db, tmp_path, days=12)
    d0 = (now - timedelta(days=2)).date()
    d = DR.day_detail(db, "elec", d0, app.config["F1"], cmp="week")
    assert d["has15"] and len(d["v"]) == 96 and d["cmp_day"] == (d0 - timedelta(days=7)).isoformat()
    assert abs(d["sum"] - 50 * 24) < 1e-3 and abs(d["cmp_sum"] - 50 * 24) < 1e-3 and d["pct"] == 0.0      # KA 50 kWh/ชม.
    assert d["peak"] == 50.0 and d["base"] == 50.0 and abs(d["work"] - 50 * 9) < 1e-3 and abs(d["off"] - 50 * 15) < 1e-3
    assert len(d["hours"]) == 24 and all(abs(h["v"] - 50) < 1e-6 for h in d["hours"])
    assert d["meters"][0]["id"] == mid and d["meters"][0]["via"] == "15m"
    login(client, "t_admin")
    j = client.get(f"/energy/api/drill?kind=elec&day={d0}&factory={app.config['F1']}&cmp=yday").get_json()
    assert j["cmp_day"] == (d0 - timedelta(days=1)).isoformat()
    m = j["meters"][0]
    assert m["url"].endswith(f"?pday={d0}#prof") and f"/energy/sources/{sid}/raw" in m["raw"] and "tag=KA" in m["raw"]
    assert j["url_daily"].startswith("/energy/daily") and j["url_live"].startswith("/energy/live")
    page = client.get(f"/energy/meters/{mid}?pday={d0}").get_data(as_text=True)
    assert f'value="{d0}"' in page                                                      # เปิดกราฟ 15 นาทีของวันนั้น


def test_day_detail_falls_back_to_daily_readings(app, db, client):
    m = EN.save_meter(db, None, {"factory_id": app.config["F2"], "kind": "elec", "code": "D1", "name": "Daily only"}, None)
    today = S.now_dt().date()
    for k, v in ((10, 1000.0), (9, 1100.0), (8, 1250.0), (3, 2000.0), (2, 2100.0), (1, 2230.0)):
        db.execute("INSERT INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,?,?)",
                   (m, (today - timedelta(days=k)).isoformat(), v, "manual", S.ts()))
    db.commit()
    d = DR.day_detail(db, "elec", today - timedelta(days=2), app.config["F2"], cmp="week")
    assert not d["has15"] and d["meters"] and d["meters"][0]["via"] == "day"


def test_month_shape_bands_heat_and_meter_changes(app, db, client, tmp_path):
    now, _sid, _mid = _plant(app, db, tmp_path, days=40)
    gone = EN.save_meter(db, None, {"factory_id": app.config["F1"], "kind": "elec", "code": "G1", "name": "Gone"}, None)
    m0 = now.date().replace(day=1)
    p0 = (m0 - timedelta(days=1)).replace(day=1)
    for k, v in ((0, 100.0), (1, 150.0), (2, 210.0)):                                  # มีค่าแค่เดือนก่อน
        db.execute("INSERT INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,?,?)",
                   (gone, (p0 + timedelta(days=k)).isoformat(), v, "manual", S.ts()))
    db.commit()
    s = DR.month_shape(db, "elec", m0, app.config["F1"], today=now.date())
    assert len(s["avg_cur"]) == 24 and len(s["bands"]) == 4 and [b["key"] for b in s["bands"]] == ["night", "morning", "afternoon", "evening"]
    if now.date().day >= 2:                                                              # เดือนปัจจุบันเทียบเฉพาะวันที่จบแล้ว
        assert s["range"] == f"1–{now.date().day - 1}" and s["n_cur"] >= 1
        assert all(v is None or abs(v - 50) < 1e-6 for v in s["avg_cur"]) and all(d is None or abs(d) < 1e-6 for d in s["diff"])
        assert s["heat"] and all(abs(x[2] - 50) < 1e-6 for x in s["heat"])
    assert gone in [x["id"] for x in s["gone"]] and gone not in [x["id"] for x in s["downs"]]   # ไม่มีค่าเดือนนี้ ≠ ลดได้
    login(client, "t_admin")
    j = client.get(f"/energy/api/shape?kind=elec&factory={app.config['F1']}&month={m0:%Y-%m}").get_json()
    assert j["n_gone"] >= 1 and j["gone"][0]["url"].startswith("/energy/meters/")
    html = client.get(f"/energy/?factory={app.config['F1']}").get_data(as_text=True)
    for x in ('id="crDrill"', 'id="crShape"', "เจาะดูรายวัน", "ใช้ลด / เพิ่มตรงไหน", "energy_drill.js", "/energy/api/drill", "/energy/api/shape"):
        assert x in html, x


# ───────────── เปรียบเทียบก่อน–หลังปรับปรุง ─────────────


def _improve_plant(app, db, tmp_path, improve: _date, end: _date):
    """เลขสะสมทุก 15 นาที: เวลางาน 08–17 ใช้ 100 kWh/ชม. · นอกเวลา 40 → หลังวัน improve นอกเวลาเหลือ 20"""
    path = str(tmp_path / "imp.db")
    con = _sq.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    start = _dt.combine(improve - timedelta(days=14), _time(0, 0))
    t, acc, rows = start, 10000.0, []
    while t <= _dt.combine(end + timedelta(days=1), _time(0, 0)):
        rows.append(("P1", t.strftime("%Y-%m-%d %H:%M:%S"), round(acc, 4)))
        work = 8 <= t.hour < 17
        acc += (100 if work else (20 if t.date() >= improve else 40)) / 4
        t += timedelta(minutes=15)
    con.executemany("INSERT INTO h VALUES (?,?,?)", rows)
    con.commit()
    con.close()
    sid = ES.save_source(db, {"name": "SQL", "kind": "sqlite", "active": "1", "config": json.dumps({
        "path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 1})}, None)
    mid = EN.save_meter(db, None, {"factory_id": app.config["F2"], "kind": "elec", "code": "P1", "name": "Press line",
                                   "scada_source_id": str(sid), "scada_tag": "P1"}, None)
    db.commit()
    from ecs import energy_profile as PR
    PR.backfill(db, ES.get_source(db, sid), start.date(), end, _dt.combine(end + timedelta(days=2), _time(0, 0)))
    db.commit()
    return sid, mid


def _weekday_before(d: _date, wd: int) -> _date:
    while d.weekday() != wd:
        d -= timedelta(days=1)
    return d


def test_compare_savings_kwh_baht_co2_by_time_band(app, db, client, tmp_path):
    today = S.now_dt().date()
    b_day = _weekday_before(today - timedelta(days=2), 1)                 # อังคาร (วันทำงาน · มี On-Peak)
    a_day = b_day - timedelta(days=7)
    _sid, mid = _improve_plant(app, db, tmp_path, improve=b_day - timedelta(days=3), end=b_day)
    r = CMP.compare(db, "elec", a_day, a_day, b_day, b_day, app.config["F2"])
    assert r["a"]["n"] == 1 and r["b"]["n"] == 1
    assert abs(r["total"]["a"] - 1500) < 1e-3 and abs(r["total"]["b"] - 1200) < 1e-3          # 9×100 + 15×40 → 9×100 + 15×20
    assert abs(r["save"]["day"]["u"] - 300) < 0.05 and abs(r["save"]["month"]["u"] - 9000) < 1
    on, off = 4.1839 * 1.07, 2.6037 * 1.07                                                     # อัตราเริ่มต้น TOU + VAT 7%
    exp_baht = 20 * (10 * off + 5 * on)                                                        # นอกเวลาที่ลด: 00–08 · 22–24 = Off · 17–22 = On
    assert abs(r["save"]["day"]["baht"] - round(exp_baht)) <= 1, (r["save"]["day"]["baht"], exp_baht)
    assert abs(r["save"]["day"]["co2"] - round(300 * 0.4999 / 1000, 3)) < 1e-6
    bands = {b["key"]: b for b in r["bands"]}
    assert abs(bands["night"]["diff"] + 120) < 1e-3 and abs(bands["am"]["diff"]) < 1e-6           # เวลางานเท่าเดิม
    assert abs(bands["after"]["baht"] + 20 * 5 * on) < 0.05                                         # หลังเลิกงาน = On-Peak
    assert bands["after"]["waste_a"] is not None and r["base_a"] == 40.0 and r["base_b"] == 20.0
    m = next(x for x in r["meters"] if x["id"] == mid)
    assert abs(m["diff"] + 300) < 1e-3 and m["share"] == 100.0
    login(client, "t_admin")
    q = f"kind=elec&factory={app.config['F2']}&a_from={a_day}&a_to={a_day}&b_from={b_day}&b_to={b_day}"
    html = client.get(f"/energy/compare?{q}").get_data(as_text=True)
    for x in ('id="cpResult"', 'id="cpBands"', 'id="cpChart"', 'id="cpMeters"', 'id="cpHours"', "ประหยัดเงิน", "tCO₂/วัน",
              "ลดได้", "สูญเสีย / ลดได้ ช่วงเวลาไหน", "On-Peak", "energy_compare.js"):
        assert x in html, x
    csv = client.get(f"/energy/compare?{q}&format=csv")
    body = csv.data.decode("utf-8-sig")
    assert csv.mimetype == "text/csv" and "กลางคืน 00:00–06:00" in body and "Press line" in body and body.count("\n") > 30


def test_compare_daytype_filter_and_empty_state(app, db, client, tmp_path):
    today = S.now_dt().date()
    b_day = _weekday_before(today - timedelta(days=2), 1)
    _improve_plant(app, db, tmp_path, improve=b_day - timedelta(days=3), end=b_day)
    sun = _weekday_before(b_day, 6)
    r = CMP.compare(db, "elec", sun - timedelta(days=7), sun, sun - timedelta(days=7), sun, app.config["F2"], daytype="off")
    assert r["a"]["n"] >= 1 and all(_date.fromisoformat(d).weekday() == 6 for d in r["a"]["days"])     # วันหยุด = อาทิตย์ (ค่าเริ่มต้น จ–ส ทำงาน)
    login(client, "t_admin")
    old = (today - timedelta(days=300)).isoformat()
    html = client.get(f"/energy/compare?kind=elec&factory={app.config['F2']}&a_from={old}&a_to={old}&b_from={b_day}&b_to={b_day}").get_data(as_text=True)
    assert "ยังเปรียบเทียบไม่ได้" in html
    nav = client.get("/energy/").get_data(as_text=True)
    assert "/energy/compare" in nav and "เปรียบเทียบก่อน–หลัง" in nav
