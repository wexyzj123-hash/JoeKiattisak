"""ชุดทดสอบ E-Checksheet — ทุกการทดสอบใช้ฐานข้อมูลชั่วคราว ไม่แตะข้อมูลจริง"""
import io
import os
import sqlite3
import struct
import sys
import uuid
import zlib

import pytest


def pytest_configure(config):
    """v0.99.43 ชุดทดสอบหลายไฟล์คำนวณ “วันนี้” ตอนโหลดไฟล์ — ถ้ารันคร่อมเที่ยงคืน วันที่จะไม่ตรงกันกลางทาง (ล้มแบบสุ่ม)
    เริ่มรันช่วง 23:40–00:20 → รอถึง 00:20 ก่อน (ทดสอบที่ใช้ “ตอนนี้ − 10 นาที” ไม่คร่อมวัน) (ทำครั้งเดียวที่ตัวควบคุม ไม่ใช่ทุก worker)"""
    import time as _time
    if hasattr(config, "workerinput") or os.environ.get("ECS_NO_MIDNIGHT_WAIT"):
        return
    tm = _time.localtime()
    sec = tm.tm_hour * 3600 + tm.tm_min * 60 + tm.tm_sec            # วินาทีนับจาก 00:00 (เวลาเครื่อง)
    until = 20 * 60 + 5                                               # 00:20:05
    if sec >= 23 * 3600 + 40 * 60 or sec < until:
        wait = (until - sec) % 86400
        print(f"\n[conftest] เวลา {tm.tm_hour:02d}:{tm.tm_min:02d} ใกล้เที่ยงคืน — รอ {wait / 60:.1f} นาที ก่อนเริ่มทดสอบ (กันวันที่เปลี่ยนกลางทาง)", flush=True)
        _time.sleep(wait)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

PASSWORD = "Test#1234"

_ICON_EMOJI = {"signal": "📡", "bulb": "💡", "lock": "🔒", "bolt": "⚡", "ban": "⛔", "okc": "✅", "pen": "✍", "cal": "📅", "clip": "📋"}


def emo(html):
    """v0.99.1 อีโมจิในข้อความถูกแทนด้วยไอคอนเส้น (<i class="ei ei-xxx">) — แปลงกลับเป็นอีโมจิเดิมเพื่อเทียบข้อความในเทสต์"""
    import re as _re
    return _re.sub(r'<i class="ei ei-(\w+)" aria-hidden="true"></i>', lambda m: _ICON_EMOJI.get(m.group(1), "·"), html)


def png_bytes():
    raw = b"".join(b"\x00" + b"\xc8\x3c\x3c" * 8 for _ in range(8))
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 8, 8, 8, 2, 0, 0, 0)) + \
        chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")


@pytest.fixture(autouse=True)
def _usage_day(request, monkeypatch):
    """v0.89 ชุดทดสอบเดิม (ก่อน v0.89) เขียนตามแบบเดิม = การใช้ลงวันที่อ่านค่า
    ไฟล์ทดสอบที่ต้องการแบบใหม่ (ลงวันที่ใช้จริง) ให้ประกาศ ACTUAL_DAY = True"""
    from ecs import energy as EN
    if not getattr(request.module, "ACTUAL_DAY", False):
        monkeypatch.setitem(EN.DEFAULTS, "usage_day", 0)
    if not getattr(request.module, "SPLIT_GAP", False):     # v0.90 ชุดทดสอบเดิม: ค่าอ่านห่างหลายวัน = ก้อนเดียว
        monkeypatch.setitem(EN.DEFAULTS, "split_gap", 0)
    yield


@pytest.fixture()
def app(tmp_path):
    from ecs import create_app
    application = create_app({"TESTING": True, "DATABASE": str(tmp_path / "t.db"),
                              "UPLOAD_FOLDER": str(tmp_path / "up"), "ENABLE_JOBS": False})
    from ecs import masterdata as M
    from ecs.db import connect
    db = connect(application.config["DATABASE"])
    f1, f2 = [r["id"] for r in db.execute("SELECT id FROM factories ORDER BY id LIMIT 2")]
    for username, role, fac in (("t_admin", "admin", None), ("t_sup", "supervisor", f1), ("t_sup2", "supervisor", f2),
                                ("t_tech", "technician", f1), ("t_tech2", "technician", f2), ("t_view", "viewer", None)):
        M.save_user(db, {"username": username, "name": "ทดสอบ " + username, "role": role, "factory_id": fac,
                         "password": PASSWORD, "must_change_pw": 0}, None)
    db.commit()
    db.close()
    application.config["F1"], application.config["F2"] = f1, f2
    return application


@pytest.fixture()
def db(app):
    con = sqlite3.connect(app.config["DATABASE"])
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    yield con
    con.close()


@pytest.fixture()
def client(app):
    return app.test_client()


def csrf_of(client):
    client.get("/login")
    with client.session_transaction() as s:
        return s.get("_csrf")


def login(client, username, password=PASSWORD):
    tok = csrf_of(client)
    res = client.post("/login", data={"username": username, "password": password, "csrf_token": tok})
    assert res.status_code == 302, res.data[:400]
    client.get("/account/password")          # สร้าง token ใหม่หลัง session ถูกล้าง
    with client.session_transaction() as s:
        return s["_csrf"]


def uid(db, username):
    return db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()[0]


@pytest.fixture()
def published_form(app, db):
    """เครื่อง F1 + แบบฟอร์ม 4 หัวข้อ (ตัวเลข, OK/NG, มิเตอร์สะสม, ตัวเลือก) + รอบตรวจรายวัน"""
    from ecs import masterdata as M
    from ecs import services as S
    admin = uid(db, "t_admin")
    eq = M.save_equipment(db, {"code": "SCT0002", "name": "Air Compressor", "factory_id": app.config["F1"]}, admin)
    fid = S.create_form(db, {"name": "Daily AC", "equipment_id": eq}, admin)
    d = S.get_draft(db, fid)
    S.save_draft_items(db, d["id"], [
        {"item_key": "oil", "name": "Oil Pressure", "item_type": "number", "unit": "bar", "min_value": 1.7, "max_value": 2.5, "warn_high": 2.4},
        {"item_key": "noise", "name": "เสียงผิดปกติ", "item_type": "ok_ng", "photo_on_ng": 1},
        {"item_key": "hour", "name": "Running hour", "item_type": "counter", "unit": "hr", "counter_max_step": 24},
        {"item_key": "filter", "name": "ไส้กรอง", "item_type": "choice", "options": [{"label": "สะอาด"}, {"label": "ต้องเปลี่ยน", "ng": 1}]},
        {"item_key": "note", "name": "หมายเหตุอื่น", "item_type": "text", "required": 0},
    ], admin)
    S.publish_version(db, d["id"], admin)
    db.commit()
    return {"form_id": fid, "equipment_id": eq, "version_id": d["id"]}


def payload(form, answers, **kw):
    base = {"client_uuid": str(uuid.uuid4()), "form_id": form["form_id"], "form_version_id": form["version_id"],
            "answers": [{"item_key": k, **v} for k, v in answers.items()]}
    base.update(kw)
    return base


GOOD = {"oil": {"value": "2.1"}, "noise": {"value": "OK"}, "hour": {"value": "1000"}, "filter": {"value": "สะอาด"}}
