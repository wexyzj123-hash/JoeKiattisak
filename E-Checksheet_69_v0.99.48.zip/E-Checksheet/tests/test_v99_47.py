"""v0.99.47: Energy — หน้าหน่วยงาน (scorecard + จัดอันดับ) · จัดหมวดมิเตอร์ · เป้าต่อเดือน · แท็บหน้าภาพรวม · เมนูตามบทบาท"""
from datetime import timedelta

from conftest import login, uid

from ecs import energy as EN
from ecs import energy_dept as DP
from ecs import energy_summary as SMY
from ecs import services as S


def _rd(db, mid, day, v):
    db.execute("INSERT INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,?,?)", (mid, day.isoformat(), v, "manual", S.ts()))


def _plant(app, db):
    """F2: Section A (เดือนก่อน 100/วัน → เดือนนี้ 80/วัน) · Section B (50 → 60) · มิเตอร์ยังไม่ระบุหน่วยงาน 1 ตัว"""
    today = S.now_dt().date()
    m0 = today.replace(day=1)
    p0 = (m0 - timedelta(days=1)).replace(day=1)
    f2 = app.config["F2"]
    a = EN.save_meter(db, None, {"factory_id": f2, "kind": "elec", "code": "A1", "name": "Press A", "grp": "Press", "line": "L1"}, None)
    b = EN.save_meter(db, None, {"factory_id": f2, "kind": "elec", "code": "B1", "name": "Paint B", "grp": "Paint", "line": "L9"}, None)
    u = EN.save_meter(db, None, {"factory_id": f2, "kind": "elec", "code": "U1", "name": "Paint booth fan"}, None)
    va = vb = vu = 1000.0
    d = p0 - timedelta(days=1)
    while d <= today:
        _rd(db, a, d, va)
        _rd(db, b, d, vb)
        _rd(db, u, d, vu)
        cur = d >= m0 - timedelta(days=1)                # ค่าที่บวกหลังจดวัน D−1 = การใช้ของวัน D
        va += 80 if cur else 100
        vb += 60 if cur else 50
        vu += 10
        d += timedelta(days=1)
    db.commit()
    return today, m0, a, b, u


def test_ranking_and_scorecard(app, db):
    today, m0, a, _b, _u = _plant(app, db)
    if today.day < 3:
        return
    SMY.save_target(db, "elec", app.config["F2"], "grp", "Press", 90, "", None)
    db.commit()
    R = DP.ranking(db, "elec", app.config["F2"], m0, today)
    rows = {r["grp"]: r for r in R["rows"]}
    n = R["n_days"]
    assert abs(rows["Press"]["u"] - 80 * n) < 1e-6 and abs(rows["Press"]["prev"] - 100 * n) < 1e-6 and rows["Press"]["chg"] == -20.0
    assert rows["Paint"]["chg"] == 20.0 and rows["Press"]["rank"] == 1 and rows["Paint"]["rank"] == 2          # ลดมากสุด = อันดับ 1
    assert rows["Press"]["t_mtd"] == 90 * n and rows["Press"]["t_pct"] == round(100 * 80 / 90, 1)
    assert rows["-"]["name"] == "ไม่ระบุหน่วยงาน" and R["unassigned"]["n"] == 1
    assert rows["Press"]["baht"] and rows["Press"]["co2"]
    d = DP.scorecard(db, "elec", app.config["F2"], "Press", m0, today)
    assert d["row"]["rank"] == 1 and d["lines"][0]["name"] == "L1" and d["meters"][0]["id"] == a
    assert len(d["daily"]) == n and all(abs(x - 80) < 1e-6 for x in d["daily"]) and d["target_day"] == 90


def test_dept_pages(app, db, client):
    _today, _m0, _a, _b, _u = _plant(app, db)
    login(client, "t_view")
    html = client.get(f"/energy/dept?factory={app.config['F2']}").get_data(as_text=True)
    assert "จัดอันดับหน่วยงาน" in html and "Press" in html and "Paint" in html and "ยังไม่ระบุหน่วยงาน 1 ตัว" in html
    card = client.get(f"/energy/dept?factory={app.config['F2']}&grp=Press").get_data(as_text=True)
    for x in ("ใช้เดือนนี้", "เทียบเป้า", "คาดการณ์สิ้นเดือน", "อันดับ", "ไลน์", "มิเตอร์", "เทียบกับหน่วยงานอื่น", "dpDaily"):
        assert x in card, x
    assert client.get(f"/energy/dept?factory={app.config['F2']}&grp=NoSuch").status_code == 200


def test_assign_meters_suggest_and_save(app, db, client):
    _plant(app, db)
    A = DP.assign_rows(db, app.config["F2"], "elec")
    r = next(x for x in A["rows"] if x["code"] == "U1")
    assert r["missing"] and r["sug_grp"] == "Paint"                                       # ชื่อ “Paint booth fan” → Section Paint
    assert A["n_missing"] == 1 and A["n_done"] == 2
    tok = login(client, "t_admin")
    page = client.get(f"/energy/meters/assign?factory={app.config['F2']}").get_data(as_text=True)
    assert "จัดแล้ว 2 / 3" in page and f'name="grp_{r["id"]}"' in page
    res = client.post("/energy/meters/assign", data={"csrf_token": tok, "factory": app.config["F2"], f"grp_{r['id']}": "Paint",
                                                       f"line_{r['id']}": "L9", f"prj_{r['id']}": ""}, follow_redirects=True)
    assert "บันทึกแล้ว 1 มิเตอร์" in res.get_data(as_text=True)
    m = EN.meter(db, r["id"])
    assert m["grp"] == "Paint" and m["line"] == "L9"
    login(client, "t_view")
    assert client.get("/energy/meters/assign").status_code in (302, 403)                # ผู้ดูแก้ไม่ได้


def test_overview_tabs_banner_and_role_menu(app, db, client):
    _plant(app, db)
    login(client, "t_admin")
    html = client.get(f"/energy/?factory={app.config['F2']}").get_data(as_text=True)
    for x in ('class="ez-tabs"', 'data-tab="sum"', 'data-tab="trend"', 'data-tab="day"', 'data-tab="shape"', 'data-tp="day" role="tabpanel" hidden',
              "มิเตอร์ยังไม่ระบุหน่วยงาน 1 ตัว", "/energy/meters/assign", "/energy/dept"):
        assert x in html, x
    tg = client.get("/energy/targets?kind=elec&level=grp").get_data(as_text=True)
    assert "= ต่อเดือน" in tg and 'id="tgAll"' in tg
    login(client, "t_view")
    v = client.get("/energy/").get_data(as_text=True)
    aside = v[v.index('<aside class="sidenav"'):v.index("</aside>")]
    assert 'data-grp="en-more"' in aside and 'data-grp="en-rep"' in aside and 'data-grp="en-data"' not in aside
    assert "/energy/meters" in aside and "/energy/manage" in aside                       # ไม่ได้ตัดเมนูออก — อยู่ใน “เพิ่มเติม”
    assert uid(db, "t_view")
