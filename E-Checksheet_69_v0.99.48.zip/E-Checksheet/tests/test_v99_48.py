"""v0.99.48: Energy — ค่าฐานตามยอดผลิต + CUSUM · วิเคราะห์ตามกะ · การไหลของพลังงาน (Sankey) · ตั้งกะ + ยอดผลิตรายกะ"""
from datetime import date, datetime, timedelta
from itertools import pairwise

import pytest
from conftest import login

from ecs import energy as EN
from ecs import energy_interval as EI
from ecs import energy_perf as PF
from ecs import energy_power as PW
from ecs import services as S
from ecs.services import ValidationError


def _rd(db, mid, day, v):
    db.execute("INSERT OR REPLACE INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,?,?)",
               (mid, day.isoformat(), v, "manual", S.ts()))


def _meter(db, f, code, **kw):
    return EN.save_meter(db, None, {"factory_id": f, "kind": "elec", "code": code, "name": code, **kw}, None)


# ───────────── กะ ─────────────

def test_shift_layout_rules():
    L = PF.layout(PF.DEFAULT_SHIFTS)
    assert [(s["off"], s["dur"]) for s in L] == [(0, 480), (480, 480), (960, 480)]                 # ดึก 00–08 = ท้ายวันผลิตที่เริ่ม 08:00
    sm = PF.slot_map({"list": L})
    assert [sm.count(i) for i in range(3)] == [32, 32, 32] and None not in sm
    two = PF.layout([{"name": "กลางวัน", "start": "07:30", "end": "19:30"}, {"name": "กลางคืน", "start": "19:30", "end": "07:30"}])
    assert [s["dur"] for s in two] == [720, 720] and two[1]["code"] == "B"
    gap = PF.slot_map({"list": PF.layout([{"name": "เดียว", "start": "08:00", "end": "17:00"}])})
    assert gap.count(0) == 36 and gap.count(None) == 60                                            # นอกกะ
    for bad, msg in (([{"name": "a", "start": "08:00", "end": "16:00"}, {"name": "b", "start": "15:00", "end": "23:00"}], "ทับกัน"),
                     ([{"name": "a", "start": "08:10", "end": "16:00"}], "15 นาที"),
                     ([{"name": "a", "start": "8", "end": "16:00"}], "ไม่ถูกต้อง"),
                     ([{"name": "", "start": "08:00", "end": "16:00"}], "ชื่อกะ"),
                     ([{"name": str(i), "start": f"{i:02d}:00", "end": f"{i + 1:02d}:00"} for i in range(5)], "4 กะ"),
                     ([], "อย่างน้อย")):
        with pytest.raises(ValidationError) as e:
            PF.layout(bad)
        assert msg in e.value.errors[0]


def _shift_plant(app, db):
    """F2 · Press: ข้อมูลราย 15 นาที 2 วันผลิต — เช้า 1.0/ช่อง · บ่าย 2.0 · ดึก 0.5 · Solar (หักออก) 0.25/ช่อง เฉพาะกะเช้า"""
    EI.ensure(db)
    f2 = app.config["F2"]
    m = _meter(db, f2, "P1", grp="Press", line="L1")
    pv = _meter(db, f2, "PV", grp="Press", is_main="-1")
    d0 = S.now_dt().date() - timedelta(days=5)
    t = datetime.combine(d0, datetime.min.time()) + timedelta(hours=8)
    end = t + timedelta(days=2)
    while t < end:
        h = t.hour
        v = 1.0 if 8 <= h < 16 else (2.0 if h >= 16 else 0.5)
        db.execute("INSERT INTO en_intervals(meter_id, ts, value) VALUES (?,?,?)", (m, S.ts(t), v))
        if 8 <= h < 16:
            db.execute("INSERT INTO en_intervals(meter_id, ts, value) VALUES (?,?,?)", (pv, S.ts(t), 0.25))
        t += timedelta(minutes=15)
    db.commit()
    return f2, d0, m, pv


def test_shift_report_and_production(app, db):
    f2, d0, _m, _pv = _shift_plant(app, db)
    d1 = d0 + timedelta(days=1)
    n = PF.save_prod(db, f2, "Press", {(d.isoformat(), c): q for d in (d0, d1) for c, q in (("A", "100"), ("B", "80"), ("C", "10"))},
                     {"A", "B", "C"}, None)
    db.commit()
    assert n == 6
    R = PF.shift_report(db, f2, "elec", "Press", None, d0, d1)
    rows = {r["code"]: r for r in R["rows"]}
    assert rows["A"]["u"] == 2 * (32 - 8) and rows["B"]["u"] == 2 * 64 and rows["C"]["u"] == 2 * 16      # Solar หักออกจากกะเช้า
    assert rows["A"]["avg"] == 24 and rows["B"]["per_h"] == 8 and rows["A"]["cover"] == 100.0 and rows["A"]["days"] == 2
    assert rows["A"]["prod"] == 200 and rows["A"]["per_unit"] == 0.24 and rows["B"]["per_unit"] == 0.8 and rows["C"]["per_unit"] == 1.6
    assert R["total"] == 208 and R["gap"] == 0 and R["has_15m"] and R["has_prod"]
    assert R["note"]["hi"] == "ดึก" and R["note"]["lo"] == "เช้า" and R["note"]["extra"] == round((1.6 - 0.24) * 20)
    assert R["daily"][0]["u"] == [24, 64, 16] and R["daily"][0]["pu"] == [0.24, 0.8, 1.6]
    # ทั้งโรงงาน (ไม่เลือกหน่วยงาน) → ใช้ผลรวมยอดผลิตทุกหน่วยงาน
    assert PF.prod_rows(db, f2, None, d0, d1)[d0.isoformat()] == {"A": 100, "B": 80, "C": 10}
    # ช่องว่าง = ลบ · ตัวอักษร = แจ้งเตือน
    PF.save_prod(db, f2, "Press", {(d0.isoformat(), "A"): ""}, {"A", "B", "C"}, None)
    assert "A" not in PF.prod_rows(db, f2, "Press", d0, d0)[d0.isoformat()]
    with pytest.raises(ValidationError):
        PF.save_prod(db, f2, "Press", {(d0.isoformat(), "A"): "abc"}, {"A"}, None)
    with pytest.raises(ValidationError):
        PF.save_prod(db, f2, "Press", {(d0.isoformat(), "A"): "-5"}, {"A"}, None)
    # วันที่ข้อมูลไม่ครบทั้งกะ → ไม่นับใน kWh/ชิ้น
    R2 = PF.shift_report(db, f2, "elec", "Press", None, d0, d1 + timedelta(days=1))
    assert R2["daily"][2]["u"] == [None, None, None] and {r["code"]: r for r in R2["rows"]}["B"]["cover"] == round(100 * 2 / 3, 1)


def test_custom_shifts_and_last_full_day(app, db):
    f2 = app.config["F2"]
    PF.save_shifts(db, f2, [{"code": "D", "name": "กลางวัน", "start": "07:00", "end": "19:00"},
                            {"code": "N", "name": "กลางคืน", "start": "19:00", "end": "07:00"}], None)
    db.commit()
    sh = PF.shifts(db, f2)
    assert sh["custom"] and sh["t0"] == 420 and [s["code"] for s in sh["list"]] == ["D", "N"]
    assert PF.shifts(db, app.config["F1"])["custom"] is False                                   # โรงงานอื่นยังใช้ค่าเริ่มต้น
    now = datetime(2026, 5, 10, 6, 59)
    assert PF.last_full_day(sh, now) == date(2026, 5, 8)                                       # วันผลิต 9 พ.ค. จบ 10 พ.ค. 07:00
    assert PF.last_full_day(sh, datetime(2026, 5, 10, 7, 0)) == date(2026, 5, 9)


# ───────────── ค่าฐาน + CUSUM ─────────────

def _base_plant(app, db, days=70, prod=True):
    """Press: การใช้ = 500 + 2 × ยอดผลิต · 10 วันสุดท้ายประหยัด 10% (ยอดผลิตเท่าเดิม)"""
    f2 = app.config["F2"]
    m = _meter(db, f2, "B1", grp="Press", line="L1")
    today = S.now_dt().date()
    start = today - timedelta(days=days)
    r1 = today - timedelta(days=1)
    r0 = r1 - timedelta(days=9)
    v = 10000.0
    d = start
    _rd(db, m, d - timedelta(days=1), v)
    i = 0
    while d <= r1:
        p = 100 + (i % 7) * 20 + (i % 3) * 5
        use = 500 + 2 * p
        if d >= r0:
            use *= 0.9
        v += use
        _rd(db, m, d, v)
        if prod:
            db.execute("INSERT INTO en_shift_prod(factory_id, grp, day, shift, qty) VALUES (?,?,?,?,?)", (f2, "Press", d.isoformat(), "A", p))
        d += timedelta(days=1)
        i += 1
    db.commit()
    return f2, start, r0, r1


def test_baseline_daily_regression_and_cusum(app, db):
    PF.ensure(db)
    f2, start, r0, r1 = _base_plant(app, db)
    B = PF.baseline(db, f2, "elec", "Press", None, start, r0 - timedelta(days=1), r0, r1)
    M = B["model"]
    assert B["mode"] == "daily" and abs(M["a"] - 500) < 0.01 and abs(M["b"] - 2) < 1e-4 and M["r2"] > 0.999 and B["quality"] == "good"
    assert B["n_rep"] == 10 and abs(B["save_pct"] - 10.0) < 0.01 and B["save"] > 0
    assert abs(B["chg_total"] - (B["chg_prod"] + B["chg_eff"])) < 0.5 and abs(B["chg_eff"] + B["save"]) < 0.5
    cus = [p["c"] for p in B["points"] if p["rep"]]
    assert all(b < a for a, b in pairwise(cus)) and abs(cus[-1] + B["save"]) < 0.5            # CUSUM ลดลงทุกวัน = ประหยัดต่อเนื่อง
    assert all(p["c"] is None for p in B["points"] if p["base"]) and B["baht"] and B["co2"]
    with pytest.raises(ValidationError):
        PF.baseline(db, f2, "elec", "Press", None, start, r1, r0, r1)                              # ช่วงทับกัน


def test_baseline_production_effect_vs_real_saving(app, db):
    """ใช้ลดลงเพราะผลิตน้อยลงอย่างเดียว → ประหยัดจริง ≈ 0 (ไม่หลอกว่าลดได้)"""
    PF.ensure(db)
    f2 = app.config["F2"]
    m = _meter(db, f2, "C1", grp="Cast")
    today = S.now_dt().date()
    start, r0, r1 = today - timedelta(days=50), today - timedelta(days=10), today - timedelta(days=1)
    v = 0.0
    _rd(db, m, start - timedelta(days=1), v)
    d, i = start, 0
    while d <= r1:
        p = (100 + (i % 5) * 30) * (0.5 if d >= r0 else 1)                                        # ช่วงติดตามผลิตลดครึ่ง
        v += 300 + 3 * p
        _rd(db, m, d, v)
        db.execute("INSERT INTO en_shift_prod(factory_id, grp, day, shift, qty) VALUES (?,?,?,?,?)", (f2, "Cast", d.isoformat(), "A", p))
        d += timedelta(days=1)
        i += 1
    db.commit()
    B = PF.baseline(db, f2, "elec", "Cast", None, start, r0 - timedelta(days=1), r0, r1)
    assert B["chg_total"] < 0 and abs(B["save"]) < 0.5 and abs(B["chg_prod"] - B["chg_total"]) < 0.5


def test_baseline_fallbacks(app, db):
    PF.ensure(db)
    PW.ensure(db)
    f2, start, r0, r1 = _base_plant(app, db, days=40, prod=False)
    B = PF.baseline(db, f2, "elec", "Press", None, start, r0 - timedelta(days=1), r0, r1)
    assert B["mode"] == "daytype" and B["quality"] == "info" and "ไม่มียอดผลิต" in B["qmsg"] and B["model"]["r2"] is None
    assert B["save"] > 0 and "aw" in B["model"]
    E = PF.baseline(db, f2, "gas" if "gas" in EN.KINDS else "water", None, None, start, r0 - timedelta(days=1), r0, r1)
    assert E["msg"] and E["model"] is None                                                          # ไม่มีข้อมูล → ข้อความ ไม่ error


def test_baseline_monthly_mode(app, db):
    PF.ensure(db)
    PW.ensure(db)
    f2 = app.config["F2"]
    m = _meter(db, f2, "M1", grp="Weld")
    today = S.now_dt().date()
    first = (today.replace(day=1) - timedelta(days=1)).replace(day=1)                              # ต้นเดือนก่อน
    months = []
    x = first
    for _ in range(5):
        x = (x - timedelta(days=1)).replace(day=1)
        months.insert(0, x)
    months.append(first)                                                                            # 5 เดือนฐาน + เดือนก่อน = ติดตาม
    v = 0.0
    _rd(db, m, months[0] - timedelta(days=1), v)
    for k, mo in enumerate(months):
        q = 1000 + k * 150 if k < 5 else 1300
        nd = ((mo + timedelta(days=32)).replace(day=1) - mo).days
        per = (2000 + 1.5 * q) / nd * (0.85 if k == 5 else 1)
        for i in range(nd):
            v += per
            _rd(db, m, mo + timedelta(days=i), v)
        db.execute("INSERT INTO en_line_prod(factory_id, grp, line, month, qty) VALUES (?,?,?,?,?)", (f2, "Weld", "", mo.strftime("%Y-%m"), q))
    db.commit()
    last = (first + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    B = PF.baseline(db, f2, "elec", "Weld", None, months[0], first - timedelta(days=1), first, last)
    assert B["mode"] == "monthly" and B["n_base"] == 5 and B["n_rep"] == 1
    assert abs(B["model"]["b"] - 1.5) < 1e-3 and abs(B["model"]["a"] - 2000) < 0.5 and abs(B["save_pct"] - 15) < 0.01


# ───────────── การไหลของพลังงาน ─────────────

def test_flow_sankey(app, db):
    f2 = app.config["F2"]
    main = _meter(db, f2, "MAIN", is_main="1")
    a = _meter(db, f2, "A", grp="Press", line="L1")
    a2 = _meter(db, f2, "A2", grp="Press", line="L2")
    b = _meter(db, f2, "B", grp="Paint")
    pv = _meter(db, f2, "PV", is_main="-1")
    today = S.now_dt().date()
    d0 = today - timedelta(days=4)
    for mid, per in ((main, 100), (a, 40), (a2, 20), (b, 30), (pv, 5)):
        for i in range(5):
            _rd(db, mid, d0 - timedelta(days=1) + timedelta(days=i), 1000 + per * i)
    db.commit()
    F = PF.flow(db, f2, "elec", d0, today - timedelta(days=1))
    L = {(x["source"], x["target"]): x["value"] for x in F["links"]}
    n = 4
    assert F["total"] == (100 - 5) * n and F["has_main"] and F["solar"] == 5 * n
    assert L[("รวมไฟฟ้า", "Press")] == 60 * n and L[("Press", "L1")] == 40 * n and L[("Press", "L2")] == 20 * n
    assert L[("Paint", "Paint · ไม่ระบุไลน์")] == 30 * n
    assert L[("รวมไฟฟ้า", "ไม่ได้วัด / ส่วนกลาง / สูญเสีย")] == 10 * n and F["unm_pct"] == 10.0
    assert L[("Solar / หักออก", "รวมไฟฟ้า")] == 5 * n and L[("จากมิเตอร์หลัก", "รวมไฟฟ้า")] == 95 * n
    roles = {x["name"]: x["role"] for x in F["nodes"]}
    assert roles["Press"] == "dept" and roles["L1"] == "line" and roles["รวมไฟฟ้า"] == "root"
    inflow = sum(v for (s, _t), v in L.items() if s == "รวมไฟฟ้า")
    assert inflow == F["root"]                                                                       # ไหลเข้า = ไหลออก


def test_flow_without_main_meter(app, db):
    f2 = app.config["F2"]
    a = _meter(db, f2, "X1", grp="Press", line="L1")
    today = S.now_dt().date()
    for i in range(3):
        _rd(db, a, today - timedelta(days=3 - i), 50 * i)
    db.commit()
    F = PF.flow(db, f2, "elec", today - timedelta(days=2), today - timedelta(days=1))
    assert not F["has_main"] and F["unmeasured"] == 0 and min(x["depth"] for x in F["nodes"]) == 0
    assert not any("ไม่ได้วัด" in x["name"] for x in F["nodes"])


# ───────────── หน้าเว็บ ─────────────

def test_pages_and_permissions(app, db, client):
    f2, d0, _m, _pv = _shift_plant(app, db)
    login(client, "t_view")
    for u, txt in ((f"/energy/baseline?factory={f2}&grp=Press", "ค่าฐานตามยอดผลิต"),
                   (f"/energy/shifts?factory={f2}&grp=Press&month={d0.strftime('%Y-%m')}", "วิเคราะห์ตามกะ"),
                   (f"/energy/flow?factory={f2}", "การไหลของพลังงาน")):
        r = client.get(u)
        assert r.status_code == 200 and txt in r.get_data(as_text=True), u
    assert client.get(f"/energy/shifts/setup?factory={f2}").status_code in (302, 403)               # ผู้ดูกรอกไม่ได้
    assert client.get(f"/energy/baseline?factory={f2}&b0=bad&r0=2001-01-01").status_code == 200
    tok = login(client, "t_tech2")
    page = client.get(f"/energy/shifts/setup?factory={f2}&grp=Press&month={d0.strftime('%Y-%m')}").get_data(as_text=True)
    assert f'name="q_{d0.isoformat()}_A"' in page and "เวลากะของโรงงาน" not in page                 # ช่างกรอกยอดได้ ตั้งกะไม่ได้
    r = client.post("/energy/shifts/setup", data={"csrf_token": tok, "act": "cfg", "factory": f2, "name_0": "x", "start_0": "08:00", "end_0": "20:00"},
                    follow_redirects=True)
    assert "เฉพาะหัวหน้างาน" in r.get_data(as_text=True)
    r = client.post("/energy/shifts/setup", data={"csrf_token": tok, "act": "prod", "factory": f2, "grp": "Press", "month": d0.strftime("%Y-%m"),
                                                  f"q_{d0.isoformat()}_A": "1,200", f"q_{d0.isoformat()}_B": "90"}, follow_redirects=True)
    assert "บันทึกยอดผลิตแล้ว" in r.get_data(as_text=True)
    assert PF.prod_rows(db, f2, "Press", d0, d0)[d0.isoformat()] == {"A": 1200.0, "B": 90.0}
    tok = login(client, "t_admin")
    r = client.post("/energy/shifts/setup", data={"csrf_token": tok, "act": "cfg", "factory": f2, "code_0": "D", "name_0": "กลางวัน", "start_0": "08:00",
                                                  "end_0": "20:00", "code_1": "N", "name_1": "กลางคืน", "start_1": "20:00", "end_1": "08:00"},
                    follow_redirects=True)
    assert "บันทึกเวลากะแล้ว" in r.get_data(as_text=True) and [s["code"] for s in PF.shifts(db, f2)["list"]] == ["D", "N"]
    csv = client.get(f"/energy/shifts?factory={f2}&grp=Press&month={d0.strftime('%Y-%m')}&format=csv")
    assert csv.status_code == 200 and "กลางวัน" in csv.get_data(as_text=True)
    menu = client.get("/energy/").get_data(as_text=True)
    assert 'href="/energy/baseline"' in menu
