"""v0.99.43: Energy — หน้าภาพรวม / หน้าไฟฟ้า ดูง่าย แบ่งส่วนชัด บอกเวลาของข้อมูล เลือกวันที่ได้
· ภาพรวม: ① ตอนนี้ (ราย 15 นาที) ② ยอดรายวัน (เลือกวันได้) ③ ยอดเดือน ④ รายละเอียดเพิ่มเติม (พับเก็บ)
· หน้าไฟฟ้า: ใช้ค่าราย 15 นาทีจากเลขสะสม · เปิดที่โรงงานที่มีข้อมูลล่าสุด · บอกว่าข้อมูลถึงเมื่อไร · เลือกเดือนได้"""
import json
from datetime import timedelta

from _scada_sim import build
from conftest import login
from ecs import energy as EN
from ecs import energy_dash as DASH
from ecs import energy_power as PW
from ecs import energy_src as ES
from ecs import services as S


def _scada(app, db, tmp_path, fac="F2"):
    now = S.now_dt()
    path = str(tmp_path / "scada.db")
    build(path, now, days=10, step_min=15)
    sid = ES.save_source(db, {"name": "SQL", "kind": "sqlite", "active": "1", "config": json.dumps({
        "path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 1})}, None)
    mid = EN.save_meter(db, None, {"factory_id": app.config[fac], "kind": "elec", "code": "KA", "name": "MDB KA",
                                   "scada_source_id": str(sid), "scada_tag": "KA"}, None)
    db.commit()
    ES.run_source(db, sid, now=now)
    db.commit()
    return now, sid, mid


def test_dashboard_sections_and_live_now(app, db, client, tmp_path):
    now, _sid, _mid = _scada(app, db, tmp_path)
    login(client, "t_admin")
    html = client.get("/energy/?factory=").get_data(as_text=True)
    for x in ('id="sec-now"', 'id="sec-day"', 'id="sec-month"', 'id="sec-more"', "ตอนนี้", "ยอดรายวัน", "ยอดเดือน", "รายละเอียดเพิ่มเติม",
              "ข้อมูลสดจาก SCADA", "ชั่วโมงนี้", "กำลังใช้ตอนนี้", 'name="day"'):
        assert x in html, x
    live = DASH.now_panel(db, None, now=now)
    e = next(x for x in live if x["kind"] == "elec")
    assert e["n_data"] == 1 and e["today"] is not None and e["last_ts"] is not None and e["rate_unit"] == "kW"
    if e["rate"] is not None:
        assert abs(e["rate"] - 50.0) < 1e-6                                     # KA 50 kWh/ชม. → 50 kW


def test_dashboard_pick_day(app, db, client, tmp_path):
    now, _sid, _mid = _scada(app, db, tmp_path)
    login(client, "t_admin")
    d = (now - timedelta(days=4)).date()
    html = client.get(f"/energy/?factory=&day={d.isoformat()}").get_data(as_text=True)
    assert f"วันที่ <b>{d:%d/%m}/{d.year + 543}</b> · เลือกเอง" in html and "↺ ล่าสุด" in html
    c = DASH.control(db, d.replace(day=1), None, pick=d)
    assert c["ref_day"] == d.isoformat()
    future = (now + timedelta(days=3)).date()
    assert client.get(f"/energy/?day={future.isoformat()}").status_code == 200           # วันอนาคต → ใช้วันนี้
    old = client.get("/energy/?factory=&month=2020-01").get_data(as_text=True)
    assert 'id="sec-now"' not in old                                                    # เดือนเก่า: ไม่มีส่วน “ตอนนี้”


def test_power_uses_cumulative_15min_and_picks_factory_with_data(app, db, client, tmp_path):
    now, _sid, mid = _scada(app, db, tmp_path)
    t = PW.tou(db, app.config["F2"], now.date().replace(day=1))
    assert t["n_int"] >= 1 and t["peak_all"] > 0                                       # เดิม: เลขสะสม → 0 ทั้งหมด
    login(client, "t_admin")
    html = client.get("/energy/power").get_data(as_text=True)
    assert "ค่าราย 15 นาทีล่าสุด" in html and "ค่าอ่านรายวันล่าสุด" in html and 'type="month"' in html
    f2 = next(f for f in db.execute("SELECT id, name FROM factories") if f[0] == app.config["F2"])
    assert f"{f2[1]} · TOU" in html                                                      # เปิดที่โรงงานที่มีข้อมูลล่าสุด
    assert "ยังไม่มีค่าราย 15 นาที / รายชั่วโมง" not in html
    assert PW.interval_meters(db, [mid], now - timedelta(days=1), now) == {mid}
