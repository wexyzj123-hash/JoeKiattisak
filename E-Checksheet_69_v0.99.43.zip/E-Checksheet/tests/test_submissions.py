"""Phase 2: รับผลตรวจ (ความครบถ้วน, NG ต้องมีหมายเหตุ+รูป, กันส่งซ้ำ, รอบตรวจ, ตีกลับ/ส่งใหม่, อนุมัติ)"""
import io
import json
import os
from datetime import datetime, timedelta

import pytest
from werkzeug.datastructures import FileStorage

from conftest import GOOD, csrf_of, login, payload, png_bytes, uid
from ecs import services as S
from ecs import submissions as SUB


def photo():
    return FileStorage(io.BytesIO(png_bytes()), filename="p.png")


def submit(app, db, form, answers, user="t_tech", photos=None, **kw):
    p = payload(form, answers, **kw)
    res = SUB.create_submission(db, p, photos or {}, uid(db, user), app.config["UPLOAD_FOLDER"])
    db.commit()
    return res, p


def test_good_submission(app, db, published_form):
    res, _ = submit(app, db, published_form, GOOD)
    assert res["ng_count"] == 0 and res["warn_count"] == 0 and not res["duplicate"]
    sub = SUB.get_submission(db, res["id"])
    assert {a["item_key"]: a["value_num"] for a in sub["answers"]}["oil"] == 2.1
    assert sub["approval_status"] == "pending" and sub["inspector_name"] == "ทดสอบ t_tech"


def test_required_items_enforced(app, db, published_form):
    with pytest.raises(S.ValidationError) as e:
        submit(app, db, published_form, {"oil": {"value": "2.1"}})
    msgs = " ".join(e.value.errors)
    assert "เสียงผิดปกติ: ยังไม่ได้กรอก" in msgs and "Running hour: ยังไม่ได้กรอก" in msgs
    assert "หมายเหตุอื่น" not in msgs                       # หัวข้อไม่บังคับ


def test_ng_needs_remark_and_photo(app, db, published_form):
    bad = dict(GOOD, noise={"value": "NG"})
    with pytest.raises(S.ValidationError) as e:
        submit(app, db, published_form, bad)
    assert any("ต้องใส่หมายเหตุ" in m for m in e.value.errors) and any("ต้องแนบรูป" in m for m in e.value.errors)
    ok = dict(GOOD, noise={"value": "NG", "remark": "เสียงดังจากมอเตอร์", "photos": ["p1"]})
    res, _ = submit(app, db, published_form, ok, photos={"p1": photo()})
    assert res["ng_count"] == 1
    p = db.execute("SELECT * FROM cs_photos WHERE submission_id=?", (res["id"],)).fetchone()
    assert os.path.exists(os.path.join(app.config["UPLOAD_FOLDER"], p["file_path"]))


def test_number_out_of_range_is_ng_and_warn(app, db, published_form):
    res, _ = submit(app, db, published_form, dict(GOOD, oil={"value": "2.45"}))
    assert res["warn_count"] == 1 and res["ng_count"] == 0
    with pytest.raises(S.ValidationError):   # 1.2 = NG แต่ไม่มีหมายเหตุ/รูป (photo_on_ng ค่าเริ่มต้น = 1)
        submit(app, db, published_form, dict(GOOD, oil={"value": "1.2"}))
    with pytest.raises(S.ValidationError) as e:
        submit(app, db, published_form, dict(GOOD, oil={"value": "abc"}))
    assert "ต้องเป็นตัวเลข" in e.value.errors[0]


def test_counter_uses_previous_value(app, db, published_form):
    submit(app, db, published_form, GOOD)                  # hour 1000
    with pytest.raises(S.ValidationError):                  # ลดลง → NG → ต้องมีหมายเหตุ
        submit(app, db, published_form, dict(GOOD, hour={"value": "990"}))
    res, _ = submit(app, db, published_form, dict(GOOD, hour={"value": "1030"}))
    assert res["warn_count"] == 1                           # เพิ่ม 30 > 24


def test_idempotent_resend(app, db, published_form):
    res, p = submit(app, db, published_form, GOOD)
    again = SUB.create_submission(db, p, {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    assert again["duplicate"] and again["id"] == res["id"]
    assert db.execute("SELECT COUNT(*) FROM cs_submissions").fetchone()[0] == 1


def test_bad_uuid_and_unknown_form(app, db, published_form):
    with pytest.raises(S.ValidationError):
        SUB.create_submission(db, dict(payload(published_form, GOOD), client_uuid="legacy-1"), {}, 1, app.config["UPLOAD_FOLDER"])
    with pytest.raises(S.ValidationError):
        SUB.create_submission(db, dict(payload(published_form, GOOD), form_version_id=9999), {}, 1, app.config["UPLOAD_FOLDER"])


def test_non_image_upload_rejected(app, db, published_form):
    fake = FileStorage(io.BytesIO(b"MZ\x90\x00 not an image"), filename="evil.jpg")
    with pytest.raises(S.ValidationError) as e:
        submit(app, db, published_form, dict(GOOD, noise={"value": "OK", "photos": ["x"]}), photos={"x": fake})
    assert "JPG" in e.value.errors[0]
    assert not any(files for _, _, files in os.walk(app.config["UPLOAD_FOLDER"]))   # ไม่มีไฟล์ค้าง


def test_technician_other_factory_blocked(app, db, published_form):
    with pytest.raises(S.ValidationError):
        submit(app, db, published_form, GOOD, user="t_tech2")


def _round(db, form, due, window=120):
    sid = S.create_schedule(db, form["form_id"], {"freq_type": "daily", "times": due.strftime("%H:%M"), "window_min": window}, None)
    db.execute("INSERT OR REPLACE INTO cs_meta(key,value) VALUES('rounds_start', ?)", (S.ts(due - timedelta(hours=1)),))
    S.generate_rounds(db, now=due - timedelta(minutes=30), horizon_days=0)
    db.commit()
    return db.execute("SELECT * FROM cs_rounds WHERE schedule_id=? AND due_at=?", (sid, S.ts(due))).fetchone()


def test_round_on_time_and_late(app, db, published_form):
    due = datetime.now().replace(second=0, microsecond=0) - timedelta(hours=3)
    r = _round(db, published_form, due, window=60)        # เลยกำหนดแล้ว
    res, _ = submit(app, db, published_form, GOOD, round_id=r["id"])
    assert res["round_status"] == "done_late"
    # ส่งซ้ำรอบเดิมด้วยการตรวจใหม่ → กลายเป็นนอกรอบ
    res2, _ = submit(app, db, published_form, dict(GOOD, hour={"value": "1001"}), round_id=r["id"])
    assert res2["round_status"] is None and res2["warnings"]
    # ถ้าส่งโดยระบุเวลาเสร็จ (ออฟไลน์) ก่อนกำหนด → ตรงเวลา
    due2 = datetime.now().replace(second=0, microsecond=0) - timedelta(minutes=20)
    r2 = _round(db, published_form, due2, window=120)
    res3, _ = submit(app, db, published_form, dict(GOOD, hour={"value": "1002"}), round_id=r2["id"],
                     scanned_at=S.ts(due2 + timedelta(minutes=1)), finished_at=S.ts(due2 + timedelta(minutes=3)))
    row = db.execute("SELECT * FROM cs_submissions WHERE id=?", (res3["id"],)).fetchone()
    assert res3["round_status"] == "done_on_time" and row["duration_sec"] == 120


def test_future_client_clock_clamped(app, db, published_form):
    res, _ = submit(app, db, published_form, GOOD, finished_at=S.ts(datetime.now() + timedelta(hours=5)))
    assert res["warnings"]
    row = db.execute("SELECT finished_at, received_at FROM cs_submissions WHERE id=?", (res["id"],)).fetchone()
    assert S.parse_ts(row["finished_at"]) <= datetime.now() + timedelta(minutes=1)


def test_return_and_resubmit_flow(app, db, published_form):
    due = datetime.now().replace(second=0, microsecond=0) - timedelta(minutes=10)
    r = _round(db, published_form, due, window=240)
    res, _ = submit(app, db, published_form, GOOD, round_id=r["id"])
    with pytest.raises(S.ValidationError):
        SUB.return_submission(db, res["id"], uid(db, "t_sup"), "")         # ต้องมีเหตุผล
    with pytest.raises(S.ValidationError):
        SUB.return_submission(db, res["id"], uid(db, "t_sup2"), "ต่างโรงงาน")   # หัวหน้าต่างโรงงาน
    SUB.return_submission(db, res["id"], uid(db, "t_sup"), "อ่านค่าผิด ให้ตรวจใหม่")
    db.commit()
    assert db.execute("SELECT status FROM cs_rounds WHERE id=?", (r["id"],)).fetchone()[0] == "returned"
    tasks = SUB.my_tasks(db, uid(db, "t_tech"))
    assert [t["id"] for t in tasks["groups"]["returned"]] == [r["id"]]
    res2, _ = submit(app, db, published_form, dict(GOOD, hour={"value": "1001"}), round_id=r["id"])
    old = db.execute("SELECT status FROM cs_submissions WHERE id=?", (res["id"],)).fetchone()[0]
    new = db.execute("SELECT resubmit_of FROM cs_submissions WHERE id=?", (res2["id"],)).fetchone()[0]
    assert old == "superseded" and new == res["id"]
    assert db.execute("SELECT status, submission_id FROM cs_rounds WHERE id=?", (r["id"],)).fetchone()[1] == res2["id"]
    SUB.approve(db, res2["id"], uid(db, "t_sup"))
    db.commit()
    assert SUB.get_submission(db, res2["id"])["approval_status"] == "approved"
    assert len(SUB.get_submission(db, res2["id"])["history"]) == 2


def test_bulk_approve_skips_ng(app, db, published_form):
    a, _ = submit(app, db, published_form, GOOD)
    b, _ = submit(app, db, published_form, dict(GOOD, hour={"value": "1001"}, noise={"value": "NG", "remark": "x", "photos": ["p"]}),
                  photos={"p": photo()})
    out = SUB.bulk_approve_ok(db, [a["id"], b["id"]], uid(db, "t_sup"))
    assert out == {"approved": 1, "skipped": 1}


def test_my_tasks_scope(app, db, published_form):
    now = datetime.now().replace(second=0, microsecond=0)
    due = min(now + timedelta(minutes=30), now.replace(hour=23, minute=59))   # ไม่ข้ามเที่ยงคืน (รันช่วง 23:30–24:00 ก็ยังเป็นงานของวันนี้)
    _round(db, published_form, due)
    g = SUB.my_tasks(db, uid(db, "t_tech"))["groups"]
    assert len(g["due"]) + len(g["overdue"]) == 1                                  # F1 ช่าง
    assert SUB.my_tasks(db, uid(db, "t_tech2"))["total"] == 0                  # F2 ช่าง ไม่เห็น


# ── HTTP ──
def test_submit_over_http_multipart(client, db, published_form):
    tok = login(client, "t_tech")
    p = payload(published_form, dict(GOOD, noise={"value": "NG", "remark": "มีเสียง", "photos": ["pa"]}))
    res = client.post("/api/m/submissions", headers={"X-CSRF-Token": tok},
                      data={"payload": json.dumps(p), "pa": (io.BytesIO(png_bytes()), "pa.png")},
                      content_type="multipart/form-data")
    assert res.status_code == 200, res.get_json()
    body = res.get_json()
    assert body["ng_count"] == 1
    # ส่งซ้ำ (เช่นสัญญาณหลุดตอนรอคำตอบ) → ไม่สร้างซ้ำ
    res2 = client.post("/api/m/submissions", headers={"X-CSRF-Token": tok},
                       data={"payload": json.dumps(p), "pa": (io.BytesIO(png_bytes()), "pa.png")}, content_type="multipart/form-data")
    assert res2.get_json()["duplicate"] is True
    # รูปดูได้เมื่อ login เท่านั้น
    path = db.execute("SELECT file_path FROM cs_photos").fetchone()[0]
    assert client.get("/media/" + path).status_code == 200
    anon = client.application.test_client()
    assert anon.get("/media/" + path).status_code in (302, 401)
    assert anon.get("/media/../t.db").status_code in (302, 401, 404)


def test_submit_http_validation_errors(client, published_form):
    tok = login(client, "t_tech")
    res = client.post("/api/m/submissions", headers={"X-CSRF-Token": tok},
                      data={"payload": json.dumps(payload(published_form, {"oil": {"value": "2"}}))}, content_type="multipart/form-data")
    assert res.status_code == 422 and len(res.get_json()["errors"]) == 3
    assert client.post("/api/m/submissions", data={"payload": "{}"}).status_code == 400      # ไม่มี CSRF


def test_package_and_tasks_api(client, db, published_form):
    login(client, "t_tech")
    pkg = client.get(f"/api/m/forms/{published_form['form_id']}/package").get_json()
    assert [i["item_key"] for i in pkg["items"]] == ["oil", "noise", "hour", "filter", "note"]
    assert "password" not in json.dumps(pkg)
    assert client.get("/api/m/tasks").status_code == 200
    ping = client.get("/api/m/ping").get_json()
    assert ping["logged_in"] and ping["csrf"]


def test_qr_redirects_to_form(client, db, published_form):
    token = db.execute("SELECT qr_token FROM equipment WHERE id=?", (published_form["equipment_id"],)).fetchone()[0]
    anon = client.get(f"/e/{token}")
    assert anon.status_code == 302 and "/login" in anon.headers["Location"]
    login(client, "t_tech")
    res = client.get(f"/e/{token}")
    assert res.status_code == 302 and res.headers["Location"].endswith(f"/m/fill#f={published_form['form_id']}&qr=1")
    assert client.get("/e/not-a-token").status_code == 404
    look = client.get("/api/m/lookup?q=SCT0002").get_json()
    assert look["forms"][0]["id"] == published_form["form_id"]


def test_review_pages(client, db, app, published_form):
    res, _ = submit(app, db, published_form, GOOD)
    tok = login(client, "t_sup")
    assert client.get("/approvals").status_code == 200
    assert client.get(f"/submissions/{res['id']}").status_code == 200
    r = client.post(f"/submissions/{res['id']}/approve", data={"csrf_token": tok, "note": "ok"})
    assert r.status_code == 302
    assert SUB.get_submission(db, res["id"])["approval_status"] == "approved"
    client.post("/logout", data={"csrf_token": tok})
    tok = login(client, "t_tech")
    assert client.post(f"/submissions/{res['id']}/approve", data={"csrf_token": tok}).status_code == 403
