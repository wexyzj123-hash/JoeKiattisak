"""v0.99.39 เบราว์เซอร์ในแอป (LINE / Facebook / Instagram ฯลฯ)

สแกน QR ด้วยแอปเหล่านี้ → หน้าเว็บเปิดใน "เบราว์เซอร์ในแอป" ซึ่งถ่ายรูป/แนบรูปมักไม่ได้ (กดแล้วกล้องไม่เปิด หรือถ่ายแล้วรูปไม่กลับมา)
· LINE: เติม ?openExternalBrowser=1 → LINE ส่งต่อไปเปิดในเบราว์เซอร์หลักของเครื่องเอง
· แอปอื่น: หน้าแนะนำให้เปิดใน Chrome / Safari (ใช้ต่อในแอปเดิมได้ถ้าต้องการ)"""
from __future__ import annotations

import re

_RULES = (
    ("line", re.compile(r"\bLine/\d")),
    ("facebook", re.compile(r"FBAN|FBAV|FB_IAB|FBIOS")),
    ("instagram", re.compile(r"Instagram")),
    ("tiktok", re.compile(r"musical_ly|BytedanceWebview|TikTok")),
    ("wechat", re.compile(r"MicroMessenger")),
    ("webview", re.compile(r"; wv\)")),
)
NAMES = {"line": "LINE", "facebook": "Facebook / Messenger", "instagram": "Instagram", "tiktok": "TikTok",
         "wechat": "WeChat", "webview": "แอปที่ใช้สแกน"}


def detect(ua: str | None) -> str | None:
    """ชนิดเบราว์เซอร์ในแอปจาก User-Agent (None = เบราว์เซอร์ปกติ เช่น Chrome / Safari / Samsung Internet)"""
    ua = ua or ""
    for kind, rx in _RULES:
        if rx.search(ua):
            return kind
    return None


def is_android(ua: str | None) -> bool:
    return "Android" in (ua or "")
