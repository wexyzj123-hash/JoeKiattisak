"""ecs/connectors.py — Phase 5: ดึงข้อมูลจากระบบภายนอก (SCADA SQL / CSV / REST API) → ผลตรวจอัตโนมัติ

แนวคิด
- แต่ละแหล่งคืนข้อมูลรูปแบบเดียวกัน: (tag, เวลา, ค่า)
- จับคู่ Tag → หัวข้อตัวเลขในแบบฟอร์ม (คูณ/บวกค่าแปลงหน่วยได้)
- รวมค่าเป็นช่วง (เช่น รายชั่วโมง: ค่าล่าสุด/เฉลี่ย/ต่ำสุด/สูงสุด) → 1 ผลตรวจอัตโนมัติต่อแบบฟอร์มต่อช่วง
- ผลตรวจอัตโนมัติผ่านการตัดสินเกณฑ์ + ตรวจจับความผิดปกติ + แจ้งเตือนเหมือนผลตรวจจากช่าง
  แต่ไม่ผูกกับรอบตรวจ (ไม่นับใน % ตรวจตรงเวลา) และอนุมัติอัตโนมัติ
- อ่านอย่างเดียว: SQL รับเฉพาะคำสั่ง SELECT/WITH, SQLite เปิดแบบ read-only, ไม่ย้าย/ลบไฟล์ CSV ต้นทาง
- ดึงซ้ำได้ปลอดภัย: ผลตรวจอัตโนมัติมีรหัสไม่ซ้ำต่อ (แหล่ง, แบบฟอร์ม, ช่วงเวลา)
"""
from __future__ import annotations

import csv
import fnmatch
import io
import json
import logging
import os
import re
import secrets
import sqlite3
import urllib.error
import urllib.request
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any, Iterable

from . import services as S
from .services import ValidationError, parse_ts, ts

log = logging.getLogger(__name__)

KIND_TH = {"mssql": "SQL Server (SCADA / GENESIS64)", "sqlite": "ไฟล์ฐานข้อมูล SQLite", "csv": "ไฟล์ CSV ในโฟลเดอร์",
           "rest": "REST API (JSON)"}
AGG_TH = {"last": "ค่าล่าสุด", "avg": "ค่าเฉลี่ย", "min": "ค่าต่ำสุด", "max": "ค่าสูงสุด"}
MAX_ROWS = 50000
MAX_PAGES = 6                           # v0.73 ข้อมูลค้างมาก → ดึงต่อในรอบเดียวได้สูงสุดกี่ชุด
LATE_MIN_DEFAULT = 180                  # v0.73 ดึงทับย้อนหลังทุกรอบ (นาที) รับค่าที่ Historian เขียนช้า
MAX_FILE_MB = 20
SYSTEM_USER = "_auto"

DEFAULT_CONFIG = {
    "mssql": {"conn": "DRIVER={ODBC Driver 17 for SQL Server};SERVER=scada-sql;DATABASE=Historian;UID=readonly;PWD=${SCADA_SQL_PASSWORD}",
              "query": "SELECT TagName AS tag, [DateTime] AS ts, Value AS value FROM History WHERE [DateTime] > ? ORDER BY [DateTime]",
              "backfill_days": 1, "good_quality": ""},
    "sqlite": {"path": "", "query": "SELECT tag, ts, value FROM readings WHERE ts > ? ORDER BY ts", "backfill_days": 1, "good_quality": ""},
    "csv": {"folder": "", "pattern": "*.csv", "layout": "long", "tag_col": "tag", "ts_col": "timestamp", "value_col": "value",
            "ts_format": "", "delimiter": ",", "encoding": "utf-8-sig"},
    "rest": {"url": "", "headers": {}, "items_path": "", "tag_field": "tag", "ts_field": "ts", "value_field": "value",
             "backfill_days": 1},
}


class SourceError(Exception):
    pass


# ───────────────────────── helpers ─────────────────────────

def _expand_env(text: str) -> str:
    """แทน ${ชื่อ} ด้วยค่าจาก .env / ตัวแปรระบบ — ไม่ต้องเก็บรหัสผ่านไว้ในฐานข้อมูล"""
    from .settings import env
    return re.sub(r"\$\{([A-Z0-9_]+)\}", lambda m: env(m.group(1), ""), text or "")


def mask_secret(text: str) -> str:
    return re.sub(r"((?:PWD|PASSWORD|Password|pwd)\s*=\s*)([^;${][^;]*)", r"\1••••", text or "")


def _to_dt(v: Any, fmt: str = "") -> datetime | None:
    if isinstance(v, datetime):
        return v.replace(tzinfo=None, microsecond=0)
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):                  # epoch (วินาที หรือ มิลลิวินาที)
        x = float(v)
        return datetime.fromtimestamp(x / 1000 if x > 1e11 else x).replace(microsecond=0)
    s = str(v).strip()
    if fmt:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            return None
    s2 = s.replace("T", " ").replace("Z", "")
    s2 = re.sub(r"([+-]\d{2}:?\d{2})$", "", s2).split(".")[0]
    for f in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%Y/%m/%d %H:%M:%S",
              "%Y/%m/%d %H:%M", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y %I:%M:%S %p", "%Y-%m-%d"):
        try:
            return datetime.strptime(s2, f)
        except ValueError:
            continue
    return None


def _to_float(v: Any) -> float | None:
    if v is None or v == "":
        return None
    try:
        x = float(str(v).replace(",", "").strip())
    except ValueError:
        return None
    return x if x == x and abs(x) != float("inf") else None


def _check_select(query: str) -> str:
    q = re.sub(r"--[^\n]*|/\*.*?\*/", " ", query or "", flags=re.S).strip().rstrip(";").strip()
    if not re.match(r"^(select|with)\b", q, re.I):
        raise SourceError("คำสั่ง SQL ต้องเป็น SELECT (หรือ WITH … SELECT) เท่านั้น")
    if ";" in q:
        raise SourceError("ใส่คำสั่ง SQL ได้เพียงคำสั่งเดียว")
    if re.search(r"\b(insert|update|delete|merge|drop|alter|create|truncate|exec|execute|grant|revoke|into)\b", q, re.I):
        raise SourceError("คำสั่ง SQL มีคำสั่งแก้ไขข้อมูล — อนุญาตเฉพาะการอ่าน")
    return q


class _Rows(list):
    """แถวที่อ่านได้ + truncated = ถึงเพดาน MAX_ROWS (ยังมีข้อมูลเหลือ ต้องดึงต่อ) · bad_quality = แถวที่ตัดเพราะคุณภาพไม่ดี"""
    truncated = False
    bad_quality = 0
    has_quality = False


def parse_quality(text) -> list[tuple[float, float]] | None:
    """ค่าคุณภาพที่ใช้ได้ เช่น "192" · "0, 192" · "192-255" → [(ต่ำ, สูง)] · ว่าง = ใช้ทุกค่า"""
    out = []
    for part in re.split(r"[,\s]+", str(text or "").strip()):
        if not part:
            continue
        m = re.match(r"^(-?\d+(?:\.\d+)?)(?:\s*-\s*(-?\d+(?:\.\d+)?))?$", part)
        if not m:
            raise SourceError(f"ค่าคุณภาพไม่ถูกต้อง: {part} (ตัวอย่าง 192 หรือ 0,192 หรือ 192-255)")
        lo = float(m.group(1))
        out.append((lo, float(m.group(2)) if m.group(2) else lo))
    return out or None


def _rows_from_cursor(cur, limit: int | None = None, good: list[tuple[float, float]] | None = None) -> list[tuple]:
    """แถว (tag, ts, value) · ถ้ามีคอลัมน์ quality และตั้งค่าคุณภาพที่ใช้ได้ไว้ → ตัดแถวคุณภาพไม่ดีออก (นับใน bad_quality)"""
    limit = limit or MAX_ROWS
    cols = [c[0].lower() for c in cur.description or []]
    need = {"tag", "ts", "value"}
    if not need <= set(cols):
        raise SourceError(f"ผลลัพธ์ต้องมีคอลัมน์ tag, ts, value (ได้ {', '.join(cols) or '-'}) — ใช้ AS ตั้งชื่อคอลัมน์")
    it, iv, ival = cols.index("tag"), cols.index("ts"), cols.index("value")
    iq = cols.index("quality") if "quality" in cols else None
    raw = cur.fetchmany(limit)
    out = _Rows()
    bad = 0
    for row in raw:
        if good and iq is not None:
            try:
                q = float(row[iq])
            except (TypeError, ValueError):
                q = None
            if q is None or not any(lo <= q <= hi for lo, hi in good):
                bad += 1
                continue
        out.append((row[it], row[iv], row[ival]))
    out.truncated = len(raw) >= limit
    out.bad_quality = bad
    out.has_quality = iq is not None
    return out


# ───────────────────────── fetchers → [(tag, datetime, float)] ─────────────────────────

def _wrap_tags(query: str, n: int, until: bool = False) -> str | None:
    """v0.73 ห่อคำสั่ง SQL ให้ดึงเฉพาะ Tag ที่จับคู่แล้ว (+ ช่วงเวลาสิ้นสุด) — ลดปริมาณข้อมูลมาก
    คำสั่งที่ห่อไม่ได้ (WITH … / TOP …) คืน None แล้วใช้คำสั่งเดิม"""
    if (not n and not until) or n > 900 or re.match(r"^\s*with\b", query, re.I) or re.search(r"\btop\b", query, re.I):
        return None
    inner = re.sub(r"\border\s+by\s+[^()]*$", "", query.strip(), flags=re.I).strip()
    cond = []
    if n:
        cond.append(f"q.tag IN ({', '.join('?' * n)})")
    if until:
        cond.append("q.ts <= ?")
    return f"SELECT q.* FROM ({inner}) q WHERE {' AND '.join(cond)} ORDER BY q.ts"


def fetch_sql(kind: str, cfg: dict, since: datetime, tags: list[str] | None = None, until: datetime | None = None) -> list[tuple]:
    """อ่านจาก SQL (อ่านอย่างเดียว) · tags = ดึงเฉพาะ Tag เหล่านี้ · until = ไม่เกินเวลานี้ (ใช้ตอนเติมช่องที่ขาด)"""
    query = _check_select(cfg.get("query", ""))
    conv = (lambda d: d) if kind == "mssql" else (lambda d: d.strftime("%Y-%m-%d %H:%M:%S"))
    base = [conv(since)] if "?" in query else []
    good = parse_quality(cfg.get("good_quality"))
    wrapped = _wrap_tags(query, len(tags or []), until is not None)
    if wrapped:
        try:
            return _fetch_sql(kind, cfg, wrapped, base + list(tags or []) + ([conv(until)] if until else []), good)
        except SourceError as exc:
            if "SQL:" not in str(exc):
                raise
            log.warning("tag filter wrap failed, fallback to full query: %s", exc)
    return _fetch_sql(kind, cfg, query, base, good)


def _dto(raw: bytes) -> datetime:
    """SQL Server DATETIMEOFFSET (ODBC −155) → datetime ตามเวลาที่บันทึก (ไม่แปลงโซน — ใช้ “เลื่อนเวลา” ถ้าต้องการ)"""
    import struct
    t = struct.unpack("<6hI2h", raw)
    return datetime(t[0], t[1], t[2], t[3], t[4], t[5], t[6] // 1000)


def sql_param(kind: str, dt: datetime):
    """เวลาที่ส่งเข้า ? ของคำสั่ง SQL (SQL Server = datetime · SQLite = ข้อความ)"""
    return dt if kind == "mssql" else dt.strftime("%Y-%m-%d %H:%M:%S")


def inner_query(query: str) -> str | None:
    """v0.99.40 คำสั่งของผู้ใช้ที่ห่อเป็น sub-query ได้ (ตัด ORDER BY ท้าย) — WITH / TOP ห่อไม่ได้ → None"""
    q = _check_select(query)
    if re.match(r"^\s*with\b", q, re.IGNORECASE) or re.search(r"\btop\b", q, re.IGNORECASE):
        return None
    return re.sub(r"\border\s+by\s+[^()]*$", "", q.strip(), flags=re.IGNORECASE).strip()


def query_any(kind: str, cfg: dict, query: str, params: list, limit: int = 5000) -> tuple[list[str], list[tuple]]:
    """v0.99.40 รันคำสั่งอ่านอย่างเดียวที่ระบบสร้างเอง (สรุป MAX/COUNT/GROUP BY สำหรับตรวจวินิจฉัย) → (คอลัมน์, แถว)"""
    def grab(cur):
        return [c[0].lower() for c in cur.description or []], [tuple(r) for r in cur.fetchmany(limit)]
    return _fetch_sql(kind, cfg, query, params, handler=grab)


def _fetch_sql(kind: str, cfg: dict, query: str, params: list, good=None, handler=None) -> list[tuple]:
    handler = handler or (lambda cur: _rows_from_cursor(cur, good=good))
    if kind == "sqlite":
        path = cfg.get("path") or ""
        if not os.path.isfile(path):
            raise SourceError(f"ไม่พบไฟล์ฐานข้อมูล: {path}")
        con = sqlite3.connect(f"file:{os.path.abspath(path)}?mode=ro", uri=True, timeout=10)
        try:
            cur = con.execute(query, params)
            return handler(cur)
        except sqlite3.Error as exc:
            raise SourceError(f"SQL: {exc}") from None
        finally:
            con.close()
    try:
        import pyodbc  # type: ignore
    except ImportError:
        raise SourceError("ยังไม่ได้ติดตั้ง pyodbc — รัน: pip install pyodbc และติดตั้ง Microsoft ODBC Driver for SQL Server") from None
    try:
        con = pyodbc.connect(_expand_env(cfg.get("conn", "")), timeout=15, readonly=True, autocommit=False)
    except TypeError:                                  # pyodbc รุ่นเก่าไม่มี readonly
        con = pyodbc.connect(_expand_env(cfg.get("conn", "")), timeout=15, autocommit=False)
    except pyodbc.Error as exc:
        raise SourceError(f"เชื่อมต่อ SQL Server ไม่ได้: {mask_secret(str(exc))[:300]}") from None
    try:
        con.timeout = 60
        try:
            con.add_output_converter(-155, _dto)            # คอลัมน์ DATETIMEOFFSET
        except Exception:                                   # noqa: BLE001
            pass
        cur = con.cursor()
        cur.execute(query, *params) if params else cur.execute(query)
        return handler(cur)
    except pyodbc.Error as exc:
        raise SourceError(f"SQL: {mask_secret(str(exc))[:300]}") from None
    finally:
        try:
            con.rollback()
        finally:
            con.close()


def parse_csv(text: str, cfg: dict) -> list[tuple]:
    delim = cfg.get("delimiter") or ","
    reader = csv.reader(io.StringIO(text), delimiter="\t" if delim in ("\\t", "tab") else delim)
    rows = list(reader)
    if not rows:
        return []
    head = [h.strip() for h in rows[0]]
    low = [h.lower() for h in head]

    def col(name: str) -> int:
        n = (name or "").strip().lower()
        if n in low:
            return low.index(n)
        raise SourceError(f"ไม่พบคอลัมน์ '{name}' ในไฟล์ (มี: {', '.join(head[:12])})")
    out = []
    tcol = col(cfg.get("ts_col") or "timestamp")
    if (cfg.get("layout") or "long") == "wide":        # เวลา + 1 คอลัมน์ต่อ Tag
        tags = [(i, h) for i, h in enumerate(head) if i != tcol and h]
        for r in rows[1:MAX_ROWS]:
            if len(r) <= tcol:
                continue
            for i, h in tags:
                if i < len(r):
                    out.append((h, r[tcol], r[i]))
    else:
        tg, vc = col(cfg.get("tag_col") or "tag"), col(cfg.get("value_col") or "value")
        for r in rows[1:MAX_ROWS]:
            if len(r) > max(tg, tcol, vc):
                out.append((r[tg], r[tcol], r[vc]))
    return out


def fetch_csv_folder(db, source_id: int, cfg: dict, force: bool = False, table: str = "cs_source_files") -> tuple[list[tuple], list[str]]:
    folder = cfg.get("folder") or ""
    if not os.path.isdir(folder):
        raise SourceError(f"ไม่พบโฟลเดอร์: {folder}")
    done = {r[0] for r in db.execute(f"SELECT file_key FROM {table} WHERE source_id=?", (source_id,))}
    rows, keys = [], []
    names = sorted(n for n in os.listdir(folder) if fnmatch.fnmatch(n.lower(), (cfg.get("pattern") or "*.csv").lower()))
    for name in names[:200]:
        full = os.path.join(folder, name)
        if not os.path.isfile(full):
            continue
        st = os.stat(full)
        key = f"{name}|{st.st_size}|{int(st.st_mtime)}"
        if key in done and not force:
            continue
        if st.st_size > MAX_FILE_MB * 1024 * 1024:
            raise SourceError(f"ไฟล์ {name} ใหญ่เกิน {MAX_FILE_MB} MB")
        with open(full, "r", encoding=cfg.get("encoding") or "utf-8-sig", errors="replace") as fh:
            rows += parse_csv(fh.read(), cfg)
        keys.append(key)
        if len(keys) >= 50 or len(rows) >= MAX_ROWS:
            break
    return rows, keys


def _dig(obj: Any, path: str) -> Any:
    for part in [p for p in (path or "").split(".") if p]:
        if isinstance(obj, dict):
            obj = obj.get(part)
        elif isinstance(obj, list) and part.isdigit():
            obj = obj[int(part)] if int(part) < len(obj) else None
        else:
            return None
    return obj


def fetch_rest(cfg: dict, since: datetime) -> list[tuple]:
    url = (cfg.get("url") or "").replace("{since}", since.strftime("%Y-%m-%dT%H:%M:%S"))
    if not re.match(r"^https?://", url):
        raise SourceError("URL ต้องขึ้นต้นด้วย http:// หรือ https://")
    headers = {k: _expand_env(str(v)) for k, v in (cfg.get("headers") or {}).items()}
    req = urllib.request.Request(_expand_env(url), headers={"Accept": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:  # noqa: S310 (URL ตั้งโดยผู้ดูแลระบบ)
            raw = resp.read(5 * 1024 * 1024 + 1)
    except urllib.error.HTTPError as exc:
        raise SourceError(f"HTTP {exc.code}") from None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise SourceError(f"เชื่อมต่อไม่ได้: {getattr(exc, 'reason', exc)}") from None
    if len(raw) > 5 * 1024 * 1024:
        raise SourceError("ข้อมูลที่ได้ใหญ่เกิน 5 MB")
    try:
        data = json.loads(raw.decode("utf-8-sig"))
    except ValueError:
        raise SourceError("ข้อมูลที่ได้ไม่ใช่ JSON") from None
    items = _dig(data, cfg.get("items_path") or "") if cfg.get("items_path") else data
    if not isinstance(items, list):
        raise SourceError("ไม่พบรายการข้อมูล (ตรวจ items_path)")
    tf, sf, vf = cfg.get("tag_field") or "tag", cfg.get("ts_field") or "ts", cfg.get("value_field") or "value"
    return [(_dig(it, tf), _dig(it, sf), _dig(it, vf)) for it in items[:MAX_ROWS] if isinstance(it, dict)]


def normalize(raw: Iterable[tuple], ts_format: str = "") -> tuple[list[tuple[str, datetime, float]], int]:
    out, bad = [], 0
    for tag, t, v in raw:
        dt, val = _to_dt(t, ts_format), _to_float(v)
        if tag in (None, "") or dt is None or val is None:
            bad += 1
            continue
        out.append((str(tag).strip()[:120], dt, val))
    out.sort(key=lambda x: x[1])
    return out, bad


# ───────────────────────── sources CRUD ─────────────────────────

def get_source(db, sid: int) -> dict | None:
    r = db.execute("SELECT * FROM cs_sources WHERE id=?", (sid,)).fetchone()
    if not r:
        return None
    d = dict(r)
    try:
        d["config"] = json.loads(d["config_json"] or "{}")
    except ValueError:
        d["config"] = {}
    return d


def list_sources(db) -> list[dict]:
    rows = db.execute("""SELECT s.*, (SELECT COUNT(*) FROM cs_source_tags t WHERE t.source_id=s.id) AS tags,
                                (SELECT COUNT(*) FROM cs_source_tags t WHERE t.source_id=s.id AND t.form_id IS NOT NULL
                                 AND t.item_key<>'') AS mapped
                         FROM cs_sources s ORDER BY s.active DESC, s.name""").fetchall()
    return [dict(r) for r in rows]


def save_source(db, data: dict, actor_id, sid: int | None = None, now: datetime | None = None) -> int:
    errors = []
    name = str(data.get("name") or "").strip()[:120]
    kind = data.get("kind")
    if not name:
        errors.append("กรุณาตั้งชื่อแหล่งข้อมูล")
    if kind not in KIND_TH:
        errors.append("ชนิดแหล่งข้อมูลไม่ถูกต้อง")
        kind = "csv"
    try:
        interval = int(data.get("interval_min") or 15)
        bucket = int(data.get("bucket_min") if data.get("bucket_min") not in (None, "") else 60)
        if not (1 <= interval <= 1440 and 0 <= bucket <= 1440):
            raise ValueError
    except (TypeError, ValueError):
        errors.append("รอบดึงข้อมูล 1–1440 นาที และช่วงรวมค่า 0–1440 นาที")
        interval, bucket = 15, 60
    agg = data.get("agg") if data.get("agg") in AGG_TH else "last"
    _cr = str(data.get("confirm_required", "1"))                          # v0.45 · v0.83: 2 = ยืนยันเฉพาะรอบที่มี NG/เตือน
    confirm = 2 if _cr == "2" else (1 if _cr in ("1", "True", "on") else 0)
    prefill = 1 if str(data.get("prefill", "1")) in ("1", "True", "on") else 0
    try:                                                  # v0.44 เลื่อนเวลา (นาที) · เก็บค่าดิบ (วัน)
        shift = int(float(data.get("ts_shift_min") or 0))
        keep = int(float(data.get("keep_days") or 35))
        if not (-1440 <= shift <= 1440 and 3 <= keep <= 400):
            raise ValueError
    except (TypeError, ValueError):
        errors.append("เลื่อนเวลา −1440 ถึง 1440 นาที และเก็บค่าดิบ 3–400 วัน")
        shift, keep = 0, 35
    try:                                                  # v0.73 ดึงทับย้อนหลัง (นาที)
        late = int(float(data.get("late_min") if data.get("late_min") not in (None, "") else LATE_MIN_DEFAULT))
        if not 0 <= late <= 1440:
            raise ValueError
    except (TypeError, ValueError):
        errors.append("ดึงทับย้อนหลัง 0–1440 นาที")
        late = LATE_MIN_DEFAULT
    cfg = dict(DEFAULT_CONFIG[kind])
    raw_cfg = data.get("config")
    if isinstance(raw_cfg, str):
        try:
            raw_cfg = json.loads(raw_cfg or "{}")
        except ValueError:
            errors.append("การตั้งค่าไม่ใช่ JSON ที่ถูกต้อง")
            raw_cfg = {}
    for k, v in (raw_cfg or {}).items():
        if k in cfg:
            cfg[k] = v
    if sid and kind == "mssql":                       # ช่องรหัสผ่านที่แสดงแบบซ่อน → คงค่าเดิม
        old = get_source(db, sid)
        if old and "••••" in str(cfg.get("conn", "")):
            cfg["conn"] = old["config"].get("conn", "")
    if kind in ("mssql", "sqlite"):
        try:
            _check_select(cfg.get("query", ""))
            parse_quality(cfg.get("good_quality"))
        except SourceError as exc:
            errors.append(str(exc))
    if kind == "rest" and not re.match(r"^https?://", str(cfg.get("url") or "")):
        errors.append("URL ต้องขึ้นต้นด้วย http:// หรือ https://")
    if kind == "rest" and not isinstance(cfg.get("headers"), dict):
        errors.append("headers ต้องเป็น JSON object")
    if errors:
        raise ValidationError(errors)
    now = now or S.now_dt()
    row = {"name": name, "kind": kind, "config_json": json.dumps(cfg, ensure_ascii=False), "interval_min": interval,
           "bucket_min": bucket, "agg": agg, "ts_shift_min": shift, "keep_days": keep, "late_min": late, "confirm_required": confirm, "prefill": prefill, "active": 1 if str(data.get("active", "1")) in ("1", "True", "on") else 0,
           "updated_at": ts(now)}
    if sid:
        old = get_source(db, sid)
        if old and old.get("watermark") and int(old.get("ts_shift_min") or 0) != shift:   # v0.76 คงจุดที่ดึงถึงตามเวลาของแหล่ง
            row["watermark"] = ts(parse_ts(old["watermark"]) + timedelta(minutes=shift - int(old.get("ts_shift_min") or 0)))
        db.execute(f"UPDATE cs_sources SET {', '.join(f'{k}=?' for k in row)} WHERE id=?", (*row.values(), sid))
        S.audit(db, actor_id, "update", "cs_sources", sid, after={**row, "config_json": mask_secret(row["config_json"])})
        return sid
    row.update(created_by=actor_id, created_at=ts(now), next_run_at=ts(now))
    sid = db.execute(f"INSERT INTO cs_sources({', '.join(row)}) VALUES ({', '.join('?' * len(row))})",
                     tuple(row.values())).lastrowid
    S.audit(db, actor_id, "create", "cs_sources", sid, after={"name": name, "kind": kind})
    return sid


def delete_source(db, sid: int, actor_id) -> None:
    db.execute("DELETE FROM cs_source_values WHERE source_id=?", (sid,))
    db.execute("DELETE FROM cs_source_forms WHERE source_id=?", (sid,))
    for t in ("cs_source_tags", "cs_source_runs", "cs_source_files"):
        db.execute(f"DELETE FROM {t} WHERE source_id=?", (sid,))
    db.execute("DELETE FROM cs_sources WHERE id=?", (sid,))
    S.audit(db, actor_id, "delete", "cs_sources", sid)


def list_tags(db, sid: int) -> list[dict]:
    return [dict(r) for r in db.execute("""
        SELECT t.*, f.name AS form_name, e.code AS eq_code FROM cs_source_tags t LEFT JOIN cs_forms f ON f.id=t.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id WHERE t.source_id=? ORDER BY (t.form_id IS NULL), t.tag""", (sid,))]


def parse_range(lo, hi) -> tuple[float | None, float | None]:
    """ช่วงค่าที่เป็นไปได้ของ Tag: (ต่ำสุด, สูงสุด) — ว่าง = ไม่จำกัดด้านนั้น"""
    def f(v, label):
        if v in (None, ""):
            return None
        try:
            return float(str(v).replace(",", "").strip())
        except ValueError:
            raise ValidationError(f"ช่วงค่าที่เป็นไปได้ ({label}) ต้องเป็นตัวเลข") from None
    a, b = f(lo, "ต่ำสุด"), f(hi, "สูงสุด")
    if a is not None and b is not None and a > b:
        raise ValidationError("ช่วงค่าที่เป็นไปได้: ต่ำสุดต้องไม่มากกว่าสูงสุด")
    return a, b


def in_range(v: float, lo, hi) -> bool:
    return (lo is None or v >= lo) and (hi is None or v <= hi)


def save_mapping(db, sid: int, mapping: list[dict], actor_id) -> int:
    """mapping = [{tag, target: 'form_id:item_key' | '', scale, add_offset}]"""
    n = 0
    errors = []
    for m in mapping:
        tag = str(m.get("tag") or "").strip()[:120]
        if not tag:
            continue
        target = str(m.get("target") or "")
        fid, key = None, ""
        if target:
            f, _, key = target.partition(":")
            try:
                fid = int(f)
            except ValueError:
                errors.append(f"{tag}: เป้าหมายไม่ถูกต้อง")
                continue
            form = S.get_form(db, fid)
            items = S.get_items(db, form["current_version_id"]) if form and form["current_version_id"] else []
            if not any(i["item_key"] == key and i["item_type"] in ("number", "counter") for i in items):
                errors.append(f"{tag}: ไม่พบหัวข้อตัวเลขที่เลือก")
                continue
        try:
            scale = float(m.get("scale") if m.get("scale") not in (None, "") else 1)
            off = float(m.get("add_offset") if m.get("add_offset") not in (None, "") else 0)
        except (TypeError, ValueError):
            errors.append(f"{tag}: ตัวคูณ/ค่าบวกต้องเป็นตัวเลข")
            continue
        rng = None
        if "valid_min" in m or "valid_max" in m:          # v0.77 ช่วงค่าที่เป็นไปได้ (ว่าง = ไม่จำกัด)
            try:
                rng = parse_range(m.get("valid_min"), m.get("valid_max"))
            except ValidationError as exc:
                errors.append(f"{tag}: {exc.errors[0]}")
                continue
        db.execute("""INSERT INTO cs_source_tags(source_id, tag, form_id, item_key, scale, add_offset) VALUES (?,?,?,?,?,?)
                      ON CONFLICT(source_id, tag) DO UPDATE SET form_id=excluded.form_id, item_key=excluded.item_key,
                      scale=excluded.scale, add_offset=excluded.add_offset""", (sid, tag, fid, key, scale, off))
        if rng is not None:
            db.execute("UPDATE cs_source_tags SET valid_min=?, valid_max=? WHERE source_id=? AND tag=?", (*rng, sid, tag))
        n += 1
    if errors:
        raise ValidationError(errors)
    S.audit(db, actor_id, "update", "cs_source_tags", sid, after={"mapped": n})
    return n


def mapping_targets(db) -> list[dict]:
    rows = db.execute("""
        SELECT f.id AS form_id, f.name AS form_name, e.code AS eq_code, i.item_key, i.name, i.unit, i.item_type
        FROM cs_forms f JOIN cs_form_items i ON i.version_id=f.current_version_id LEFT JOIN equipment e ON e.id=f.equipment_id
        WHERE f.active=1 AND i.item_type IN ('number','counter') ORDER BY e.code, f.name, i.order_no""").fetchall()
    return [dict(r) for r in rows]


# ───────────────────────── import ─────────────────────────

def _system_user(db) -> int:
    row = db.execute("SELECT id FROM users WHERE username=?", (SYSTEM_USER,)).fetchone()
    if row:
        return row["id"]
    from .security import hash_password
    now = ts()
    return db.execute("""INSERT INTO users(username, password, name, role, active, must_change_pw, created_at, updated_at)
                         VALUES (?,?,?, 'viewer', 0, 0, ?, ?)""",
                      (SYSTEM_USER, hash_password(secrets.token_urlsafe(24)), "ข้อมูลอัตโนมัติ (ระบบภายนอก)", now, now)).lastrowid


def create_auto_submission(db, source: dict, form_id: int, at: datetime, values: dict[str, float],
                           uuid: str | None = None) -> int | None:
    """บันทึกผลตรวจอัตโนมัติ (เฉพาะหัวข้อที่มีค่า) — คืน id หรือ None ถ้ามีอยู่แล้ว/ไม่มีหัวข้อที่ใช้ได้"""
    uuid = uuid or f"src{source['id']}:{form_id}:{at:%Y%m%d%H%M%S}"
    if db.execute("SELECT 1 FROM cs_submissions WHERE client_uuid=?", (uuid,)).fetchone():
        return None
    form = S.get_form(db, form_id)
    if not form or not form["current_version_id"] or not form["active"]:
        return None
    from .srcmap import equipment_down_at
    if equipment_down_at(db, form["equipment_id"], at):     # v0.84 เครื่องหยุด/สำรอง → ไม่ลงค่าจาก SCADA
        return None
    items = {i["item_key"]: i for i in S.get_items(db, form["current_version_id"]) if i["item_type"] in ("number", "counter")}
    evaluated = []
    for key, val in values.items():
        it = items.get(key)
        if not it:
            continue
        prev = None
        if it["item_type"] == "counter":
            p = db.execute("""SELECT a.value_num FROM cs_answers a JOIN cs_submissions s ON s.id=a.submission_id
                              WHERE s.form_id=? AND a.item_key=? AND s.status='submitted' AND s.finished_at <= ?
                              AND a.value_num IS NOT NULL ORDER BY s.finished_at DESC LIMIT 1""",
                           (form_id, key, ts(at))).fetchone()
            prev = p[0] if p else None
        try:
            res = S.evaluate(it, "%g" % round(val, 3), prev_value=prev)
        except ValidationError:
            continue
        evaluated.append((it, res))
    if not evaluated:
        return None
    ng = sum(1 for _, r in evaluated if r["judgement"] == "ng")
    warn = sum(1 for _, r in evaluated if r["judgement"] == "warn")
    now_s = ts()
    confirm = int(source.get("confirm_required", 0) or 0)   # v0.45 ค่าอัตโนมัติรอ Sr.Tech ยืนยัน
    confirm = 1 if confirm == 1 or (confirm == 2 and (ng or warn)) else 0   # v0.83 2 = ค่าปกติอนุมัติเอง
    sid = db.execute("""INSERT INTO cs_submissions(client_uuid, round_id, form_id, form_version_id, equipment_id, inspector_id,
                        scanned_at, finished_at, received_at, duration_sec, status, ng_count, warn_count, approval_status,
                        approved_at, approval_note, note, client_info, source)
                        VALUES (?, NULL, ?,?,?,?,?,?,?, NULL, 'submitted', ?, ?, ?, ?, ?, ?, ?, 'auto')""",
                     (uuid, form_id, form["current_version_id"], form["equipment_id"], _system_user(db), ts(at), ts(at),
                      now_s, ng, warn, "pending" if confirm else "approved", None if confirm else now_s,
                      "" if confirm else "อนุมัติอัตโนมัติ (ข้อมูลจากระบบภายนอก)",
                      f"นำเข้าจาก {source['name']}", f"auto:{source['kind']}:{source['name']}"[:300])).lastrowid
    for it, res in evaluated:
        db.execute("""INSERT INTO cs_answers(submission_id, item_id, item_key, value_num, value_text, judgement, remark)
                      VALUES (?,?,?,?,?,?,?)""", (sid, it["id"], it["item_key"], res["value_num"], res["value_text"],
                                                  res["judgement"], "ค่าจากระบบอัตโนมัติ" if res["judgement"] != "ok" else ""))
    from .anomaly import check_submission
    check_submission(db, sid)
    return sid


def _bucket(dt: datetime, minutes: int) -> datetime:
    if minutes <= 0:
        return dt
    base = dt.replace(second=0, microsecond=0)
    total = base.hour * 60 + base.minute
    start = total - total % minutes
    return base.replace(hour=0, minute=0) + timedelta(minutes=start)


def ingest(db, source: dict, rows: list[tuple[str, datetime, float]], now: datetime | None = None, truncated: bool = False) -> dict:
    """บันทึก Tag ที่พบ + สร้างผลตรวจอัตโนมัติจาก Tag ที่จับคู่แล้ว (เฉพาะช่วงเวลาที่ครบแล้ว)"""
    now = now or S.now_dt()
    bucket = int(source["bucket_min"] or 0)
    agg = source["agg"] or "last"
    tags = {r["tag"]: dict(r) for r in db.execute("SELECT * FROM cs_source_tags WHERE source_id=?", (source["id"],))}
    from . import srcmap as SM
    SM.store_values(db, source, rows)                     # v0.44 ค่าดิบสำหรับลงค่าตามเวลารอบตรวจ
    try:                                                  # v0.77 แจ้งค่านอกช่วงที่เป็นไปได้
        SM.check_ranges(db, source, rows, now)
    except Exception:                                     # noqa: BLE001
        log.exception("range check failed")
    bucket_only = SM.bucket_forms(db, source["id"]) if not bucket else set()   # v0.76 รวมเป็นช่วง → ลงผ่านช่องเวลา (fill_slots)
    last: dict[str, tuple[datetime, float]] = {}
    groups: dict[tuple[int, datetime], dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    cutoff = _bucket(now, bucket) if bucket else now + timedelta(seconds=1)   # ช่วงปัจจุบันยังไม่ครบ → รอรอบหน้า
    max_done = None
    for tag, dt, val in rows:
        last[tag] = (dt, val)
        m = tags.get(tag)
        if not m or not m["form_id"] or not m["item_key"] or m["form_id"] not in bucket_only:
            continue
        b = _bucket(dt, bucket)
        if bucket and b >= cutoff:
            continue
        groups[(m["form_id"], b)][m["item_key"]].append(val * float(m["scale"] or 1) + float(m["add_offset"] or 0))
        max_done = max(max_done, dt) if max_done else dt
    for tag, (dt, val) in last.items():
        db.execute("""INSERT INTO cs_source_tags(source_id, tag, last_value, last_seen) VALUES (?,?,?,?)
                      ON CONFLICT(source_id, tag) DO UPDATE SET last_value=excluded.last_value, last_seen=excluded.last_seen""",
                   (source["id"], tag, val, ts(dt)))
    made = 0
    for (form_id, b), vals in sorted(groups.items(), key=lambda x: x[0][1]):
        at = b + timedelta(minutes=bucket) - timedelta(seconds=1) if bucket else b
        agg_vals = {}
        for key, xs in vals.items():
            agg_vals[key] = {"last": xs[-1], "avg": sum(xs) / len(xs), "min": min(xs), "max": max(xs)}[agg]
        if SM.slot_voided(db, source["id"], form_id, at):      # v0.74 ผู้ดูแลยกเลิกค่าช่วงนี้แล้ว
            continue
        if create_auto_submission(db, source, form_id, at, agg_vals):
            made += 1
    made += SM.fill_slots(db, source, now)               # v0.44 1 ผลตรวจต่อเวลารอบตรวจ ลงช่องเวลาที่ถูกต้อง
    # จุดที่ดึงถึงแล้ว: ถ้ารวมเป็นช่วง ให้หยุดที่ต้นช่วงที่ยังไม่ครบ เพื่อดึงข้อมูลช่วงนั้นซ้ำรอบหน้า
    if rows:
        newest = rows[-1][1]
        wm = min(newest, cutoff - timedelta(seconds=1)) if bucket else newest
        old = parse_ts(source["watermark"]) if source.get("watermark") else None
        if truncated:                                     # ชุดที่ถึงเพดาน: วินาทีสุดท้ายอาจยังอ่านไม่ครบ → อ่านซ้ำวินาทีนั้น
            wm2 = min(wm, newest - timedelta(seconds=1))
            wm = wm2 if (not old or wm2 > old) else newest
        if not old or wm > old:
            db.execute("UPDATE cs_sources SET watermark=? WHERE id=?", (ts(wm), source["id"]))
    return {"rows": len(rows), "submissions": made, "tags_seen": len(last)}


def mapped_tags(db, sid: int) -> list[str]:
    """Tag ที่จับคู่กับหัวข้อในแบบฟอร์มแล้ว (ดึงเฉพาะ Tag เหล่านี้ตอนดึงอัตโนมัติ)"""
    return [r[0] for r in db.execute("""SELECT DISTINCT tag FROM cs_source_tags WHERE source_id=? AND form_id IS NOT NULL
                                        AND item_key<>'' ORDER BY tag""", (sid,))]


def fetch(db, source: dict, now: datetime | None = None, force_files: bool = False, tags: list[str] | None = None,
          since: datetime | None = None, until: datetime | None = None) -> tuple[list[tuple], list[str], int]:
    """ดึงข้อมูล → [(tag, เวลาไทย, ค่า)] · ตั้ง source['_truncated'] = True ถ้าข้อมูลถึงเพดาน (ต้องดึงต่อ)
    since ไม่ระบุ = ต่อจากจุดที่ดึงแล้ว (watermark) ย้อนทับ late_min นาที เพื่อรับค่าที่ Historian เขียนช้า
    (ระหว่างดึงตามให้ทัน (catchup) ไม่ย้อนทับ)"""
    now = now or S.now_dt()
    cfg = source["config"]
    if since is None:
        if source.get("watermark"):
            since = parse_ts(source["watermark"])
            if not int(source.get("catchup") or 0):
                since -= timedelta(minutes=int(source.get("late_min") if source.get("late_min") is not None else LATE_MIN_DEFAULT))
        else:
            since = now - timedelta(days=float(cfg.get("backfill_days") or 1))
    shift = timedelta(minutes=int(source.get("ts_shift_min") or 0))      # v0.44 เวลาของแหล่งข้อมูล → เวลาไทย
    keys: list[str] = []
    if source["kind"] in ("mssql", "sqlite"):
        raw = fetch_sql(source["kind"], cfg, since - shift, tags=tags, until=(until - shift) if until else None)
    elif source["kind"] == "csv":
        raw, keys = fetch_csv_folder(db, source["id"], cfg, force=force_files)
    else:
        raw = fetch_rest(cfg, since - shift)
    source["_truncated"] = bool(getattr(raw, "truncated", False))
    source["_bad_quality"] = int(getattr(raw, "bad_quality", 0) or 0)
    rows, bad = normalize(raw, cfg.get("ts_format", "") if source["kind"] == "csv" else "")
    if shift:
        rows = [(t, d + shift, v) for t, d, v in rows]
    if source["kind"] != "csv":
        rows = [r for r in rows if r[1] > since and (until is None or r[1] <= until)]
    if tags:
        want = set(tags)
        rows = [r for r in rows if r[0] in want]
    return rows, keys, bad


def run_source(db, sid: int, manual: bool = False, now: datetime | None = None, rows_override: list[tuple] | None = None,
               label: str = "") -> dict:
    """ดึงข้อมูล 1 รอบ: อ่านต่อจากจุดเดิม (ย้อนทับรับค่าที่มาช้า) → ถ้าข้อมูลค้างมากอ่านต่อเป็นชุดจนทัน (สูงสุด MAX_PAGES ชุด)
    → ลงค่าในใบตรวจ → เติมช่องเวลาที่ยังขาดเอง (ดึงย้อนหลังเฉพาะช่วงนั้น)"""
    src = get_source(db, sid)
    if not src:
        return {"ok": False, "message": "ไม่พบแหล่งข้อมูล"}
    now = now or S.now_dt()
    started = ts(now)
    bad = 0
    keys: list[str] = []
    truncated = False
    healed = 0
    badq = 0
    try:
        if rows_override is not None:
            rows, bad = normalize(rows_override, src["config"].get("ts_format", ""))
            if int(src.get("ts_shift_min") or 0):
                rows = [(t, d + timedelta(minutes=int(src["ts_shift_min"])), v) for t, d, v in rows]
            res = ingest(db, src, rows, now)
        else:
            tags = mapped_tags(db, sid) or None
            res = {"rows": 0, "submissions": 0, "tags_seen": 0}
            for page in range(MAX_PAGES):
                old_wm = parse_ts(src["watermark"]) if src.get("watermark") else None
                rows, k, b = fetch(db, src, now, tags=tags)
                keys += k
                bad += b
                badq += int(src.get("_bad_quality") or 0)
                truncated = bool(src.get("_truncated"))
                r = ingest(db, src, rows, now, truncated=truncated)
                new = sum(1 for x in rows if not old_wm or x[1] > old_wm)      # แถวใหม่ (ไม่นับที่อ่านทับซ้ำ)
                res = {"rows": res["rows"] + new, "submissions": res["submissions"] + r["submissions"],
                       "tags_seen": max(res["tags_seen"], r["tags_seen"])}
                if not truncated:
                    break
                src = {**get_source(db, sid), "catchup": 1}          # ชุดถัดไปอ่านต่อจากจุดล่าสุด ไม่ย้อนทับ
            db.execute("UPDATE cs_sources SET catchup=? WHERE id=?", (1 if truncated else 0, sid))
            if not truncated and src["kind"] != "csv":
                from . import srcmap as SM
                healed = SM.heal(db, get_source(db, sid), now)
                res["submissions"] += healed
                SM.compact(db, get_source(db, sid), now)          # v0.76 ย่อค่าดิบที่เก่ากว่า 3 วัน
        for k in keys:
            db.execute("INSERT OR IGNORE INTO cs_source_files(source_id, file_key, imported_at) VALUES (?,?,?)", (sid, k, started))
        if res["submissions"] and int(src.get("confirm_required") or 0):     # v0.74 แจ้งผู้อนุมัติ: ค่าลงรายงานแล้ว รอยืนยัน
            from . import srcmap as SM
            SM.notify_pending(db, src, now)
        msg = (f"{label + ' · ' if label else ''}อ่าน {res['rows']} แถว{'ใหม่' if rows_override is None else ''} · Tag {res['tags_seen']} · สร้างผลตรวจ {res['submissions']}"
               + (f" (เติมช่องที่ขาด {healed})" if healed else "")
               + (f" · ข้าม {bad} แถวที่อ่านค่าไม่ได้" if bad else "") + (f" · ไฟล์ใหม่ {len(keys)}" if keys else "")
               + (f" · ตัดค่าคุณภาพไม่ดี {badq}" if badq else "")
               + (" · ข้อมูลค้างมาก กำลังดึงต่อจนทัน" if truncated else ""))
        status = "ok"
    except (SourceError, ValidationError) as exc:
        res = {"rows": 0, "submissions": 0}
        msg = str(exc) if isinstance(exc, SourceError) else "; ".join(exc.errors)
        status = "failed"
    except Exception as exc:  # noqa: BLE001 — บันทึกข้อผิดพลาดไว้ให้ผู้ดูแลเห็น ไม่ให้งานเบื้องหลังล้ม
        log.exception("source %s failed", sid)
        res = {"rows": 0, "submissions": 0}
        msg, status = f"ผิดพลาด: {mask_secret(str(exc))[:300]}", "failed"
    db.execute("""INSERT INTO cs_source_runs(source_id, started_at, finished_at, status, rows_read, submissions, message, manual)
                  VALUES (?,?,?,?,?,?,?,?)""", (sid, started, ts(S.now_dt()), status, res["rows"], res["submissions"],
                                                msg[:500], 1 if manual else 0))
    upd = {"last_run_at": started, "last_status": status, "last_message": msg[:300]}
    if truncated:
        upd["next_run_at"] = started                                   # ยังไม่ทัน → รอบถัดไปทันที
    elif not manual:
        upd["next_run_at"] = ts(now + timedelta(minutes=int(src["interval_min"] or 15)))
    db.execute(f"UPDATE cs_sources SET {', '.join(f'{k}=?' for k in upd)} WHERE id=?", (*upd.values(), sid))
    db.execute("""DELETE FROM cs_source_runs WHERE source_id=? AND id NOT IN
                  (SELECT id FROM cs_source_runs WHERE source_id=? ORDER BY id DESC LIMIT 200)""", (sid, sid))
    if rows_override is None:                             # v0.75 แจ้งขัดข้อง / กลับมาปกติ (+ ดึงช่วงที่ขาด)
        from .srcwatch import safe_check
        safe_check(db, "echeck", sid, now)
    return {"ok": status == "ok", "message": msg, **res}


def preview(db, sid: int, cfg_override: dict | None = None, now: datetime | None = None) -> dict:
    """ทดสอบการเชื่อมต่อ: ดึงข้อมูลแต่ไม่บันทึก"""
    src = get_source(db, sid)
    if not src:
        raise SourceError("ไม่พบแหล่งข้อมูล")
    if cfg_override:
        src["config"].update(cfg_override)
    src = {**src, "watermark": ""}
    rows, keys, bad = fetch(db, src, now)
    tags: dict[str, int] = defaultdict(int)
    last: dict[str, tuple] = {}
    for t, d, v in rows:
        tags[t] += 1
        last[t] = (d, v)
    for t, (d, v) in last.items():                        # v0.73 จำรายชื่อ Tag ไว้ให้จับคู่ได้ทันที (ไม่สร้างผลตรวจ)
        db.execute("""INSERT INTO cs_source_tags(source_id, tag, last_value, last_seen) VALUES (?,?,?,?)
                      ON CONFLICT(source_id, tag) DO UPDATE SET last_value=excluded.last_value, last_seen=excluded.last_seen""",
                   (sid, t, v, ts(d)))
    return {"rows": len(rows), "bad": bad, "files": len(keys), "bad_quality": src.get("_bad_quality", 0),
            "sample": [{"tag": t, "ts": ts(d), "value": v} for t, d, v in rows[-20:]],
            "tags": sorted(({"tag": k, "count": v} for k, v in tags.items()), key=lambda x: -x["count"])[:200]}


def run_due_sources(app, now: datetime | None = None) -> int:
    con = sqlite3.connect(app.config["DATABASE"], timeout=15)
    con.row_factory = sqlite3.Row
    try:
        con.execute("PRAGMA busy_timeout=15000")
        now = now or S.now_dt()
        due = [r[0] for r in con.execute("""SELECT id FROM cs_sources WHERE active=1 AND (next_run_at IS NULL OR next_run_at <= ?)""",
                                         (ts(now),))]
        made = 0
        for sid in due:
            res = run_source(con, sid, now=now)
            con.commit()
            made += res.get("submissions", 0)
        try:                                              # v0.84.1 ค่าจาก SCADA ในช่วงเครื่องหยุด → เอาออก (ลองใหม่ทุกชั่วโมง)
            from . import srcmap as SM
            SM.sweep_down(con, now)
            con.commit()
        except Exception:                                 # noqa: BLE001
            con.rollback()
            log.exception("scada downtime sweep failed")
        if made:
            from .notify import wake
            wake()
        return len(due)
    finally:
        con.close()
