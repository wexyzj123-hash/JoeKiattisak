/* E-Checksheet mobile core — เก็บข้อมูลในเครื่อง (IndexedDB) + ส่งผลตรวจแบบคิว (ทำงานได้แม้สัญญาณหลุด)
   stores:  kv       ข้อมูลทั่วไป (งานของฉัน, แพ็กเกจแบบฟอร์ม)
            drafts   แบบร่างที่กำลังกรอก (บันทึกทุกครั้งที่แตะ)
            outbox   ผลตรวจที่กดส่งแล้วแต่ยังไม่ถึงเซิร์ฟเวอร์
            photos   รูปถ่าย (Blob) ของแบบร่าง/คิวส่ง */
(function () {
  'use strict';
  const DB_NAME = 'ecs', DB_VER = 1;
  let dbp = null;

  function openDb() {
    if (dbp) return dbp;
    dbp = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = () => {
        const db = req.result;
        ['kv', 'drafts', 'outbox', 'photos'].forEach(s => { if (!db.objectStoreNames.contains(s)) db.createObjectStore(s); });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbp;
  }
  async function tx(store, mode, fn) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, mode), s = t.objectStore(store);
      let out;
      const r = fn(s);
      if (r && 'onsuccess' in r) r.onsuccess = () => { out = r.result; };
      t.oncomplete = () => resolve(out);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error || new Error('บันทึกข้อมูลในเครื่องไม่สำเร็จ (พื้นที่เต็ม?)'));
    });
  }
  const store = name => ({
    get: k => tx(name, 'readonly', s => s.get(k)),
    put: (k, v) => tx(name, 'readwrite', s => s.put(v, k)),
    del: k => tx(name, 'readwrite', s => s.delete(k)),
    all: () => tx(name, 'readonly', s => s.getAll()),
    keys: () => tx(name, 'readonly', s => s.getAllKeys()),
  });

  // UUID v4 — crypto.randomUUID ใช้ไม่ได้บน http:// จึงสร้างเองจาก getRandomValues
  function uuid() {
    const b = crypto.getRandomValues(new Uint8Array(16));
    b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
    const h = [...b].map(x => x.toString(16).padStart(2, '0')).join('');
    return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
  }
  function pad(n) { return String(n).padStart(2, '0'); }
  function nowTs(d) {
    d = d || new Date();
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }
  function parseTs(s) { return s ? new Date(String(s).replace(' ', 'T')) : null; }
  function fmt(s, withDate) {
    const d = parseTs(s); if (!d || isNaN(d)) return '–';
    const t = pad(d.getHours()) + ':' + pad(d.getMinutes());
    return withDate ? `${pad(d.getDate())}/${pad(d.getMonth() + 1)} ${t}` : t;
  }
  const TH_M = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
  function fmtDate(s) {          // '2026-10-03' → '3 ต.ค.'
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s || '')); if (!m) return '–';
    return `${Number(m[3])} ${TH_M[Number(m[2]) - 1] || ''}`;
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // ย่อรูปก่อนเก็บ/ส่ง (ด้านยาวไม่เกิน 1280 px, JPEG) — ลดเวลาส่งบนเครือข่ายโรงงาน
  // ย่อรูปในเครื่องก่อนส่ง (ประหยัดเน็ต/ที่เก็บออฟไลน์) — ถ้าเบราว์เซอร์อ่านรูปชนิดนี้ไม่ได้ (เช่น HEIC บน Android)
  // ส่งไฟล์ต้นฉบับไปให้เซิร์ฟเวอร์ย่อแทน
  async function resizeImage(file, maxSide = 1600, quality = 0.82) {
    try { return await resizeInBrowser(file, maxSide, quality); } catch (e) { return file; }
  }
  async function resizeInBrowser(file, maxSide, quality) {
    let bmp;
    try { bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
    catch (e) {
      bmp = await new Promise((resolve, reject) => {
        const img = new Image(); img.onload = () => resolve(img); img.onerror = reject; img.src = URL.createObjectURL(file);
      });
    }
    const w = bmp.width, h = bmp.height, k = Math.min(1, maxSide / Math.max(w, h));
    const c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    return new Promise(resolve => c.toBlob(b => resolve(b || file), 'image/jpeg', quality));
  }

  // ── เชื่อมต่อเซิร์ฟเวอร์ ──
  let csrfToken = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
  async function ping() {
    try {
      const r = await fetch(U('/api/m/ping'), { credentials: 'same-origin', cache: 'no-store' });
      if (!r.ok) return { online: true, loggedIn: false };
      const d = await r.json();
      if (d.csrf) csrfToken = d.csrf;
      return { online: true, loggedIn: !!d.logged_in };
    } catch (e) { return { online: false, loggedIn: false }; }
  }
  async function getJson(url) {
    const r = await fetch(U(url), { credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' });
    let d = {}; try { d = await r.json(); } catch (e) { /* html (เช่นหน้า login) */ }
    if (!r.ok || r.redirected) { const e = new Error(d.error || 'HTTP ' + r.status); e.status = r.redirected ? 401 : r.status; e.data = d; throw e; }
    return d;
  }

  // ── คิวส่งผลตรวจ ──
  const outbox = store('outbox');
  // v0.99.39 รูปในเครื่อง: เบราว์เซอร์ในแอปบางตัว (LINE / Facebook บน iPhone) เก็บ Blob ลง IndexedDB ไม่ได้ → "บันทึกรูปไม่สำเร็จ"
  // → เก็บเป็น ArrayBuffer แทน แล้วแปลงกลับเป็น Blob ตอนอ่าน (ผู้เรียกใช้ .blob เหมือนเดิม)
  const photoStore = store('photos');
  function blobBuf(b) {
    if (b.arrayBuffer) return b.arrayBuffer();
    return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsArrayBuffer(b); });
  }
  const photos = Object.assign({}, photoStore, {
    async put(k, v) {
      try { return await photoStore.put(k, v); } catch (e) {
        if (!v || !(v.blob instanceof Blob)) throw e;
        const rest = Object.assign({}, v); delete rest.blob;
        return photoStore.put(k, Object.assign(rest, { buf: await blobBuf(v.blob), type: v.blob.type || 'image/jpeg' }));
      }
    },
    async get(k) {
      const v = await photoStore.get(k);
      if (v && !v.blob && v.buf) v.blob = new Blob([v.buf], { type: v.type || 'image/jpeg' });
      return v;
    },
  });
  let syncing = null;

  async function sendOne(item) {
    const fd = new FormData();
    fd.append('payload', JSON.stringify(item.payload));
    for (const pid of item.photoIds || []) {
      const p = await photos.get(pid);
      if (p) fd.append(pid, p.blob, pid + '.jpg');
    }
    let r;
    try {
      r = await fetch(U(item.endpoint || '/api/m/submissions'), { method: 'POST', body: fd, credentials: 'same-origin',
        headers: { 'X-CSRF-Token': csrfToken, Accept: 'application/json' } });
    } catch (e) { return { state: 'offline' }; }
    let d = {}; try { d = await r.json(); } catch (e) { /* */ }
    if (r.ok) {
      await outbox.del(item.client_uuid);
      for (const pid of item.photoIds || []) await photos.del(pid);
      if (item.endpoint) { document.dispatchEvent(new CustomEvent('ecs:sent', { detail: { item, result: d } })); return { state: 'sent', result: d }; }
      const recent = (await store('kv').get('recent')) || [];
      recent.unshift({ id: d.id, form_name: item.form_name, ng: d.ng_count, warn: d.warn_count, at: nowTs(), offline: !!item.queued_offline });
      await store('kv').put('recent', recent.slice(0, 20));
      return { state: 'sent', result: d };
    }
    if (r.status === 401) return { state: 'login' };
    if (r.status === 400 && /CSRF/.test(d.error || '')) { await ping(); return { state: 'retry' }; }
    if (r.status === 403 && d.code === 'must_change_password') return { state: 'login' };
    if (r.status === 422 || r.status === 400 || r.status === 404) {
      item.error = (d.errors && d.errors.length) ? d.errors : [d.error || 'ส่งไม่สำเร็จ'];
      item.status = 'rejected';
      await outbox.put(item.client_uuid, item);
      return { state: 'rejected', errors: item.error };
    }
    return { state: 'offline' };   // 5xx / proxy error → ลองใหม่ภายหลัง
  }

  async function sync() {
    if (syncing) return syncing;
    syncing = (async () => {
      const items = ((await outbox.all()) || []).filter(i => i.status !== 'rejected')
        .sort((a, b) => (a.created_at < b.created_at ? -1 : 1));
      let sent = 0, state = 'idle';
      if (items.length) {
        const p = await ping();
        if (!p.online) state = 'offline';
        else if (!p.loggedIn) state = 'login';
        else {
          for (const it of items) {
            let res = await sendOne(it);
            if (res.state === 'retry') res = await sendOne(it);
            if (res.state === 'sent') sent++;
            else if (res.state === 'offline' || res.state === 'login') { state = res.state; break; }
          }
        }
      }
      const info = await status();
      info.sent = sent; info.state = state;
      document.dispatchEvent(new CustomEvent('ecs:sync', { detail: info }));
      return info;
    })();
    try { return await syncing; } finally { syncing = null; }
  }

  async function status() {
    const all = (await outbox.all()) || [];
    return { pending: all.filter(i => i.status !== 'rejected').length, rejected: all.filter(i => i.status === 'rejected').length, items: all };
  }

  // ── แถบสถานะการเชื่อมต่อ (ทุกหน้า) ──
  function renderNetBar(info) {
    const bar = document.getElementById('netbar'); if (!bar) return;
    const online = navigator.onLine && (!info || info.state !== 'offline');
    let txt = '', cls = '';
    if (!online) { txt = 'ออฟไลน์ — ผลตรวจจะถูกเก็บไว้ในเครื่องและส่งอัตโนมัติเมื่อมีสัญญาณ'; cls = 'off'; }
    else if (info && info.state === 'login') { txt = 'กรุณาเข้าสู่ระบบใหม่เพื่อส่งผลตรวจที่ค้างอยู่'; cls = 'warn'; }
    if (info && info.pending) { txt = (txt ? txt + ' · ' : '') + `รอส่ง ${info.pending} รายการ`; cls = cls || 'warn'; }
    if (info && info.rejected) { txt = (txt ? txt + ' · ' : '') + `ส่งไม่ผ่าน ${info.rejected} รายการ (แตะเพื่อแก้ไข)`; cls = 'err'; }
    bar.textContent = txt; bar.className = 'netbar ' + cls; bar.hidden = !txt;
  }
  document.addEventListener('ecs:sync', e => renderNetBar(e.detail));
  window.addEventListener('online', () => sync());
  window.addEventListener('offline', () => renderNetBar({ state: 'offline' }));
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') sync(); });
  setInterval(() => { if (navigator.onLine) sync(); }, 60000);

  if ('serviceWorker' in navigator && window.isSecureContext) {
    navigator.serviceWorker.register(U('/m/sw.js'), { scope: U('/m/') }).catch(() => { /* ไม่มี SW ก็ยังใช้งานได้ */ });
  }

  // ── v0.31 อ่าน QR จากรูปถ่าย (ใช้ได้บน http:// ในโรงงาน ไม่ต้องออกไปแอปกล้องนอกเว็บ → ไม่หลุด login) ──
  const SELF_SRC = (document.currentScript && document.currentScript.src) || '';
  const canLiveScan = 'BarcodeDetector' in window && window.isSecureContext && !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  let jsqrP = null;
  function loadJsQR() {
    if (window.jsQR) return Promise.resolve(window.jsQR);
    if (!jsqrP) jsqrP = new Promise((resolve, reject) => {
      const sc = document.createElement('script');
      sc.src = SELF_SRC ? SELF_SRC.replace(/core\.js(\?[^#]*)?$/, 'jsqr.js$1') : U('/static/m/jsqr.js');
      sc.onload = () => resolve(window.jsQR); sc.onerror = () => { jsqrP = null; reject(new Error('โหลดตัวอ่าน QR ไม่ได้')); };
      document.head.appendChild(sc);
    });
    return jsqrP;
  }
  function pickPhoto() {
    return new Promise(resolve => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'image/*'; inp.setAttribute('capture', 'environment');
      inp.style.cssText = 'position:fixed;left:-9999px;opacity:0';
      inp.onchange = () => { const f = inp.files && inp.files[0]; inp.remove(); resolve(f || null); };
      document.body.appendChild(inp); inp.click();
    });
  }
  async function decodeFile(file) {
    const url = URL.createObjectURL(file);
    try {
      const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
      const jsQR = await loadJsQR();
      const W = img.naturalWidth, H = img.naturalHeight;
      for (const max of [1000, 1600, 700, 2400]) {                 // ลองหลายขนาด: รูปไกล/ใกล้/เบลอ
        const k = Math.min(1, max / Math.max(W, H));
        const c = document.createElement('canvas'); c.width = Math.round(W * k); c.height = Math.round(H * k);
        const g = c.getContext('2d'); g.drawImage(img, 0, 0, c.width, c.height);
        const d = g.getImageData(0, 0, c.width, c.height);
        const r = jsQR(d.data, d.width, d.height, { inversionAttempts: 'attemptBoth' });
        if (r && r.data) return r.data;
      }
      return null;
    } finally { URL.revokeObjectURL(url); }
  }
  // ถ่ายรูป QR → คืนข้อความใน QR (null = ยกเลิก / อ่านไม่ออก — แจ้งผู้ใช้แล้ว)
  async function photoQR() {
    const f = await pickPhoto();
    if (!f) return null;
    let v = null;
    try { v = await decodeFile(f); } catch (e) { alert(e.message || 'อ่าน QR ไม่ได้'); return null; }
    if (!v) alert('อ่าน QR ในรูปไม่ออก — ถ่ายให้ป้าย QR อยู่กลางภาพ เต็มกรอบพอประมาณ ไม่เอียงและไม่สะท้อนแสง หรือพิมพ์รหัสใต้ QR แทน');
    else buzz('ok');
    return v;
  }

  // v0.99.16 สั่นเครื่อง: สแกนติด = สั้น 3 จังหวะ · NG = ยาว 2 ครั้ง (เครื่องที่ไม่รองรับ = เงียบ)
  function buzz(kind) {
    try { if (navigator.vibrate) navigator.vibrate(kind === 'ng' ? [90, 60, 90] : [25, 35, 55]); } catch (e) { /* */ }
  }
  // v0.99.16 กรอบสแกนเลเซอร์บนวิดีโอกล้อง: มุมเรืองแสง + เส้นเลเซอร์วิ่ง · พบ QR → กรอบหดเข้าหาโค้ด + สั่น
  function scanHud(view) {
    const h = document.createElement('div');
    h.className = 'scan-hud'; h.setAttribute('aria-hidden', 'true');
    h.innerHTML = '<i class="sh-c tl"></i><i class="sh-c tr"></i><i class="sh-c bl"></i><i class="sh-c br"></i><i class="sh-laser"></i><span class="sh-t">หันกล้องไปที่ป้าย QR</span>';
    view.classList.add('scan-view'); view.appendChild(h);
    return { lock() { h.classList.add('lock'); h.querySelector('.sh-t').textContent = 'พบ QR แล้ว'; buzz('ok'); return new Promise((r) => setTimeout(r, 420)); } };
  }

  window.ECS = { kv: store('kv'), drafts: store('drafts'), outbox, photos, uuid, nowTs, parseTs, fmt, fmtDate, esc,
    resizeImage, ping, getJson, sync, sendOne, status, renderNetBar, csrf: () => csrfToken,
    canLiveScan, photoQR, decodeFile, loadJsQR, buzz, scanHud };
})();
