"""ecs/views/energy.py — Energy Data (มิเตอร์ไฟฟ้า / ลม / น้ำ / น้ำ RO / ชั่วโมงเดินเครื่อง)

/energy/            Dashboard ภาพรวม 3 โรงงาน
/energy/meters      ทะเบียนมิเตอร์ + รายละเอียด/ตั้งค่า
/energy/entry       กรอกค่าอ่านรายวัน (ตารางเดียว กด Enter ไล่ช่อง)
/energy/sheet       ตารางรายเดือนแบบ Excel (ค่าอ่าน / การใช้) + ดาวน์โหลด
/energy/import      นำเข้าไฟล์บันทึกมิเตอร์ (.xls/.xlsx) แบบดูก่อนแล้วยืนยัน
/energy/anomalies   ตรวจความผิดปกติ 7 กฎ + เคสติดตาม (เปิด → กำลังตรวจ → แก้แล้ว/ไม่ใช่ปัญหา)
/energy/report      รายงานตาม Section · ค่าไฟ (บิล) + ยอดผลิต → บาท/kWh, kWh/หน่วยผลิต
/energy/settings    ตั้งค่า (EF ไฟฟ้า, ค่าไฟ, เกณฑ์ตรวจ) + ปฏิทินวันหยุด
"""
from __future__ import annotations

from datetime import date, timedelta

from flask import (Blueprint, Response, flash, jsonify, redirect, render_template, request, session, url_for)

from .. import energy as EN
from .. import energy_field as EF
from .. import energy_ops as OPS
from .. import energy_struct as ST
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import ValidationError, now_dt

bp = Blueprint("energy", __name__, url_prefix="/energy")
ENTRY_ROLES = ("admin", "supervisor", "technician")
LEAD = ("admin", "supervisor")


@bp.before_request
def _load_kinds():
    """หมวดหมู่มิเตอร์ตั้งได้เอง (en_kinds) — โหลดล่าสุดก่อนทุกหน้า"""
    from flask import session
    if "user_id" in session:
        EN.ensure(get_db())


def _month(arg: str | None) -> date:
    try:
        y, m = (int(x) for x in (arg or "").split("-")[:2])
        return date(y, m, 1)
    except (TypeError, ValueError):
        return now_dt().date().replace(day=1)


def _day(arg: str | None) -> date:
    try:
        return date.fromisoformat(arg or "")
    except ValueError:
        return now_dt().date()


def _kind(arg: str | None, allow_empty=True) -> str | None:
    return arg if arg in EN.KINDS else (None if allow_empty else "water")


def _ctx(**kw):
    db = get_db()
    return dict(KINDS=EN.KINDS, KIND_ORDER=EN.KIND_ORDER, factories=M.list_factories(db), ST=OPS.STATUS, RULES=OPS.RULES, RULES_ALL=OPS.RULES_ALL,
                SEV=OPS.SEV, SKIP=EF.SKIP_REASONS, SECTION="energy", **kw)


def _struct_ctx(db, fid=None) -> dict:
    """ตัวเลือก Project / Section / Line สำหรับฟอร์มมิเตอร์ (รวมรายการที่ผู้ดูแลตั้งไว้ล่วงหน้า)"""
    secs = ST.sections(db, fid)
    lns = ST.lines(db, fid)
    return {"projects": ST.projects(db, True), "sections": sorted({x["name"] for x in secs if x["name"]}),
            "lines_by_sec": {}, "line_opts": [{"section": x["section"], "name": x["name"]} for x in lns]}


def _sf() -> dict:
    """ตัวกรองโครงสร้างที่ใช้ร่วมกันทุกหน้า: project (id / -1 = ยังไม่กำหนด) · grp (Section) · line"""
    return {"project_id": request.args.get("project", type=int) or None, "grp": (request.args.get("grp") or "")[:80] or None,
            "line": (request.args.get("line") or "")[:80] or None}


# ───────────────────────── Dashboard ─────────────────────────

@bp.route("/")
@require_role(*ALL_ROLES)
def dashboard():
    """Dashboard แบบห้องควบคุม (v0.69) — ภาพรวม 3 โรงงาน + drill-down"""
    from .. import energy_dash as DASH
    db = get_db()
    tv = request.args.get("tv") == "1"
    keep = ("factory", "loc", "project", "line")
    if not request.args and session.get("en_dash"):    # v0.92 จำตัวกรองล่าสุด (โรงงาน/พื้นที่/Project/Line)
        return redirect(url_for("energy.dashboard", **session["en_dash"]))
    if request.args and not tv:
        session["en_dash"] = {k: request.args[k] for k in keep if request.args.get(k)}
    month = _month(request.args.get("month"))
    fid = request.args.get("factory", type=int) or None
    loc = (request.args.get("loc") or "")[:80]
    if loc.startswith("ไม่ระบุ"):                      # v0.92.2 ลิงก์เก่า “ไม่ระบุ” → มิเตอร์ที่ยังไม่มี Section
        loc = "-"
    sf = _sf()
    c = DASH.control(db, month, fid, loc or sf["grp"] or "", project_id=sf["project_id"], line=sf["line"])
    prev = (month - timedelta(days=1)).replace(day=1)
    nxt = (month + timedelta(days=32)).replace(day=1)
    chart = {"days": c["days"], "donut": c["donut"], "cmp": c["cmp"], "fid": fid, "month": month.strftime("%Y-%m"),
             "url_daily": url_for("energy.daily"), "url_dash": url_for("energy.dashboard"), "loc": loc or "",       # v0.99.40 กดกราฟ → ข้อมูลต้นทาง
             "kp": {k: {x: v[x] for x in ("daily", "target", "unit", "color", "th")} for k, v in c["kp"].items()}}
    from .. import energy_manage as MG
    U = MG.build(db, month, fid, project_id=sf["project_id"], grp=(loc or sf["grp"] or None), line=sf["line"])   # v0.90 หน่วยงาน & ไลน์
    fids = [fid] if fid else [f["id"] for f in c["facs"]]
    filtered = bool(loc or sf["grp"] or sf["project_id"] or sf["line"])
    if filtered and not c["kp"] and session.get("en_dash"):   # ตัวกรองที่ไม่มีข้อมูล → ไม่จำไว้ (กันค้างทุกครั้งที่เปิด)
        session["en_dash"] = {k: v for k, v in session["en_dash"].items() if k == "factory"}
    fresh = DASH.freshness(db, fids)
    rsrc = DASH.rate_source(db, fids, month)
    ex = DASH.executive(db, month, fids, {} if filtered else c["kp"], U) if c["kp"] else None
    if ex and filtered:                                # เลือกพื้นที่ → ไม่มีเป้าระดับโรงงาน แต่ยังดูพื้นที่ที่เพิ่มขึ้นได้
        ex["goals"] = []
    tv_next = None
    if tv:                                             # โหมดจอทีวี: วนทีละโรงงาน
        ids = [f["id"] for f in c["facs"]]
        seq = [None] + ids
        cur = seq.index(fid) if fid in seq else 0
        nxt_f = seq[(cur + 1) % len(seq)]
        tv_next = url_for("energy.dashboard", tv=1, factory=nxt_f or "", month=request.args.get("month") or "")
    return render_template("energy/control.html", **_ctx(c=c, chart=chart, month=month, fid=fid, loc=loc or sf["grp"] or "", sf=sf,
                                                       U=U, link_fn=_unit_link(month), pw_alerts=PW_alerts(db),
                                                       fresh=fresh, rsrc=rsrc, ex=ex, tv=tv, tv_next=tv_next,
                                                       projects=ST.projects(db, True), prev=prev, nxt=nxt,
                                                       is_current=month == now_dt().date().replace(day=1)))


def PW_alerts(db) -> list:
    """v0.91 kW On-Peak ใกล้/เกินเป้า (เฉพาะโรงงานที่ตั้งเป้าไว้)"""
    from .. import energy_power as PW
    try:
        return PW.demand_alerts(db)
    except Exception:                                     # noqa: BLE001 — ไม่ให้แจ้งเตือนทำหน้า Dashboard ล่ม
        return []


def _unit_link(month: date):
    """ลิงก์ drill-down จากแผงหน่วยงาน & ไลน์ → Dashboard เฉพาะหน่วยงาน/ไลน์นั้น"""
    def fn(fid, sec, line):
        kw = {"month": month.strftime("%Y-%m"), "factory": fid, "loc": "-" if sec.startswith("ไม่ระบุ") else sec}
        if line:
            kw["line"] = line
        return url_for("energy.dashboard", **kw) + "#units"
    return fn


@bp.route("/manage")
@require_role(*ALL_ROLES)
def manage():
    """v0.90 บริหารพลังงานจากค่าจดมิเตอร์ดิบ: โรงงาน × ประเภท · หน่วยงาน & ไลน์ · สมดุลมิเตอร์ · ความครบของการจด"""
    from .. import energy_manage as MG
    db = get_db()
    month = _month(request.args.get("month"))
    fid = request.args.get("factory", type=int) or None
    U = MG.build(db, month, fid)
    if request.args.get("fmt") == "xlsx":
        return Response(MG.to_xlsx(U), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        headers={"Content-Disposition": f"attachment; filename=energy_manage_{month:%Y-%m}.xlsx"})
    prev = (month - timedelta(days=1)).replace(day=1)
    nxt = (month + timedelta(days=32)).replace(day=1)
    return render_template("energy/manage.html", **_ctx(U=U, month=month, fid=fid, prev=prev, nxt=nxt, link_fn=_unit_link(month),
                                                      kind_cols=[k for k in EN.KIND_ORDER if any(x["kind"] == k for x in U["matrix"])]))


@bp.route("/register", methods=["GET", "POST"])
@require_role(*ALL_ROLES)
def register():
    """v0.90 ทะเบียนมิเตอร์มาตรฐานจากไฟล์จดมิเตอร์ ไอชิน 1–3 → เทียบ/เพิ่ม/ปรับมิเตอร์ในระบบ"""
    from .. import energy_register as ER
    db = get_db()
    fno = request.values.get("f", type=int) or None
    kind = _kind(request.values.get("kind"))
    if request.method == "POST":
        if not _is_lead():
            return render_template("error.html", code=403, message="เฉพาะหัวหน้างาน/ผู้ดูแลระบบ"), 403
        try:
            r = ER.apply(db, request.form.get("mode") or "fill", current_user_id(), fno, kind,
                         deactivate_extra=request.form.get("deactivate") == "1")
            db.commit()
            flash(f"ปรับทะเบียนแล้ว: เพิ่มมิเตอร์ {r['new']} · ปรับข้อมูล {r['updated']} · ตั้งมิเตอร์แม่ {r['parents']}"
                  + (f" · ปิดใช้งาน {r['deactivated']}" if r["deactivated"] else ""), "ok")
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
        return redirect(url_for("energy.register", f=fno or "", kind=kind or ""))
    p = ER.plan(db, fno, kind)
    show = request.args.get("show") or ("todo" if p["counts"]["new"] + p["counts"]["diff"] else "all")
    items = [it for it in p["items"] if show == "all" or it["status"] != "same"]
    return render_template("energy/register.html", **_ctx(p=p, items=items, fno=fno, kind=kind, show=show, FTH=ER.FIELD_TH,
                                                        ROLES=EN.ROLES, is_lead=_is_lead()))


@bp.route("/api/trend")
@require_role(*ALL_ROLES)
def api_trend():
    from .. import energy_dash as DASH
    db = get_db()
    kind = request.args.get("kind", "elec")
    if kind not in EN.KINDS:
        return jsonify({"error": "kind"}), 400
    return jsonify(DASH.trend_months(db, request.args.get("factory", type=int) or None, kind, _month(request.args.get("month"))))


@bp.route("/classic")
@require_role(*ALL_ROLES)
def dashboard_classic():
    db = get_db()
    month = _month(request.args.get("month"))
    fid = request.args.get("factory", type=int) or None
    kind = _kind(request.args.get("kind"))
    data = EN.dashboard(db, month, fid, kind)
    prev = (month - timedelta(days=1)).replace(day=1)
    nxt = (month + timedelta(days=32)).replace(day=1)
    return render_template("energy/dashboard.html", **_ctx(d=data, month=month, fid=fid, kind=kind, prev=prev, nxt=nxt,
                                                         is_current=month == now_dt().date().replace(day=1)))


# ───────────────────────── มิเตอร์ ─────────────────────────

@bp.route("/meters")
@require_role(*ALL_ROLES)
def meters():
    db = get_db()
    fid = request.args.get("factory", type=int) or None
    kind = _kind(request.args.get("kind"))
    show_off = request.args.get("all") == "1"
    sf = _sf()
    base = EN.meters(db, fid, kind, active_only=not show_off)
    fc = ST.facets(base)                                   # ปุ่มกรองนับจากทั้งหมวด (ไม่ซ่อนตัวเลือกอื่นเมื่อกรองแล้ว)
    ms = ST.apply_filter(base, sf["project_id"], sf["grp"], sf["line"])
    today = now_dt().date()
    ser = EN.series(db, ms, today - timedelta(days=13), today)
    for m in ms:
        s = ser[m["id"]]
        m["label"] = EN.label(m)
        m["path"] = ST.path(m)
        m["spark"] = [round((s.get((today - timedelta(days=13 - i)).isoformat()) or {}).get("u") or 0, 2) for i in range(14)]
        m["u7"] = round(sum((x.get("u") or 0) for d, x in s.items() if d >= (today - timedelta(days=6)).isoformat()), 2)
        last = db.execute("SELECT day, value FROM en_readings WHERE meter_id=? ORDER BY day DESC LIMIT 1", (m["id"],)).fetchone()
        m["last_day"], m["last_v"] = (last[0], last[1]) if last else (None, None)
        m["flags"] = sum(1 for x in s.values() if x["flag"] in ("reset", "spike"))
    if sf["grp"]:
        fc["lines"] = [x for x in fc["lines"] if x["section"] == ("" if sf["grp"] == "-" else sf["grp"])]
    return render_template("energy/meters.html", **_ctx(ms=ms, fid=fid, kind=kind, show_off=show_off, today=today, fc=fc, sf=sf,
                                                      projects=ST.projects(db, True), n_all=len(base),
                                                      yday=(today - timedelta(days=1)).isoformat()))


@bp.route("/meters/bulk", methods=["POST"])
@require_role(*ENTRY_ROLES)
def meters_bulk():
    """เลือกหลายมิเตอร์: ปิด/เปิดใช้งาน · ลบ (ยังไม่มีค่าอ่าน) · ตั้ง Project/Section/Line · ย้ายหมวด"""
    db = get_db()
    act = request.form.get("act")
    ids = [int(x) for x in request.form.getlist("ids") if x.isdigit()]
    done = skipped = 0
    for mid in ids:
        m = EN.meter(db, mid)
        if not m or not EF.can_touch(db, current_user_id(), m):
            skipped += 1
            continue
        try:
            if act in ("off", "on"):
                db.execute("UPDATE en_meters SET active=? WHERE id=?", (1 if act == "on" else 0, mid))
            elif act == "delete":
                EN.delete_meter(db, mid, current_user_id())
            elif act == "grp":
                ST.bulk_assign(db, [mid], current_user_id(), grp=request.form.get("grp") or "")
            elif act == "line":
                ST.bulk_assign(db, [mid], current_user_id(), line=request.form.get("line") or "")
            elif act == "project":
                ST.bulk_assign(db, [mid], current_user_id(), project_id=request.form.get("project_id", type=int), set_project=True)
            elif act == "kind" and request.form.get("kind") in EN.KINDS:
                k = request.form.get("kind")
                if db.execute("SELECT 1 FROM en_meters WHERE factory_id IS ? AND kind=? AND key=? AND id<>?",
                              (m["factory_id"], k, m["key"], mid)).fetchone():
                    skipped += 1
                    continue
                db.execute("UPDATE en_meters SET kind=? WHERE id=?", (k, mid))
            else:
                skipped += 1
                continue
            done += 1
        except ValidationError:
            skipped += 1
    from ..services import audit
    audit(db, current_user_id(), "energy_meter_bulk", "en_meters", None, after={"act": act, "ids": ids, "done": done, "skipped": skipped})
    db.commit()
    flash(f"ทำรายการแล้ว {done} มิเตอร์" + (f" · ข้าม {skipped} (ไม่มีสิทธิ์/มีค่าอ่านแล้ว/ชื่อซ้ำ)" if skipped else ""), "ok" if done else "error")
    return redirect(request.referrer or url_for("energy.meters"))


@bp.route("/meters/<int:mid>", methods=["GET", "POST"])
@require_role(*ALL_ROLES)
def meter_detail(mid):
    db = get_db()
    if request.method == "POST":
        m0 = EN.meter(db, mid)
        if not m0 or not EF.can_touch(db, current_user_id(), m0):
            return render_template("error.html", code=403, message="ไม่มีสิทธิ์แก้ไขมิเตอร์ของโรงงานนี้"), 403
        if request.form.get("act") == "delete":
            try:
                EN.delete_meter(db, mid, current_user_id())
                db.commit()
                flash("ลบมิเตอร์แล้ว", "ok")
                return redirect(url_for("energy.meters", kind=m0["kind"]))
            except ValidationError as exc:
                db.rollback()
                flash(exc.errors[0], "error")
                return redirect(url_for("energy.meter_detail", mid=mid))
        try:
            form = request.form.to_dict()
            sc = EF.user_scope(db, current_user_id())
            if sc["factory_id"]:
                form["factory_id"] = str(sc["factory_id"])
            EN.save_meter(db, mid, form, current_user_id())
            db.commit()
            flash("บันทึกการตั้งค่ามิเตอร์แล้ว", "ok")
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
        return redirect(url_for("energy.meter_detail", mid=mid))
    try:
        det = EN.meter_detail(db, mid, request.args.get("days", 60, type=int) if request.args.get("days") in ("30", "60", "90", "180", "365") else 60)
    except ValidationError:
        return render_template("error.html", code=404, message="ไม่พบมิเตอร์"), 404
    m = det["m"]
    eqs = [dict(r) for r in db.execute("""SELECT e.id, e.code, e.name, e.legacy_id FROM equipment e WHERE e.active=1
                                          AND (e.factory_id IS ? OR ? IS NULL) ORDER BY e.code""", (m["factory_id"], m["factory_id"]))] \
        if EF.can_touch(db, current_user_id(), m) else []
    src_tags = EF.scada_tags(db, m["scada_source_id"]) if m.get("scada_source_id") else []
    tok = EF.qr_token(db, mid)
    db.commit()
    swaps = [dict(r) for r in db.execute("""SELECT s.*, u.name AS user_name FROM en_swaps s LEFT JOIN users u ON u.id=s.user_id
                                            WHERE s.meter_id=? ORDER BY s.id DESC LIMIT 20""", (mid,))]
    touch = EF.can_touch(db, current_user_id(), m)
    from .. import energy_interval as EI
    from .. import energy_summary as SMY
    EI.ensure(db)
    tgt = SMY.target_for(db, m["kind"], "meter", str(mid), m["factory_id"], [m], now_dt().date())       # v0.88
    fam = _family(db, m)
    from .. import energy_power as PW                     # v0.91 Tag PF / kW / kVAR
    pw_tags, pw_daily = PW.param_tags(db, mid), PW.pf_daily(db, mid)
    last_int = db.execute("SELECT MAX(ts) FROM en_intervals WHERE meter_id=?", (mid,)).fetchone()[0]
    return render_template("energy/meter.html", **_ctx(det=det, m=m, label=EN.label(m), can_edit=touch, is_lead=_is_lead(),
                                                     tgt=tgt, last_int=last_int, fam=fam, pw_tags=pw_tags, pw_daily=pw_daily,
                                                     PW_PARAMS=PW.PARAMS, can_target=session.get("role") in ("admin", "supervisor"),
                                                     **_struct_ctx(db, m["factory_id"]),
                                                     facs_scope=_facs_scope(db),
                                                     can_fix=EF.can_touch(db, current_user_id(), m), eqs=eqs, swaps=swaps,
                                                     sources=EF.scada_sources(db), src_tags=src_tags,
                                                     qr_token=tok, cfg_hh=int(EN.settings(db)['scada_hh']),
                                                     cfg_mm=int(EN.settings(db)['scada_mm'])))


def _family(db, m: dict) -> dict:
    """v0.90 โครงสร้างมิเตอร์: มิเตอร์แม่ (ตั้งเอง/อัตโนมัติ) · มิเตอร์ย่อยที่ครอบ · สมดุล 30 วัน"""
    sib = EN.meters(db, m["factory_id"], m["kind"], active_only=False)
    act = [x for x in sib if x["active"]]
    cv = EN.covers(act + ([m] if not m["active"] else []))
    by_id = {x["id"]: x for x in sib}
    auto = EN.covers([dict(x, parent_id=None) if x["id"] == m["id"] else x for x in act])
    parents = [dict(by_id[p], label=EN.label(by_id[p])) for p in sorted(cv.get(m["id"], set())) if p in by_id]
    kids = [x for x in act if m["id"] in cv.get(x["id"], set())]
    bal = None
    if kids:
        today = now_dt().date()
        grp = [m] + kids
        ser = EN.series(db, grp, today - timedelta(days=30), today - timedelta(days=1))
        use = {i: sum((x.get("u") or 0) for x in s.values()) for i, s in ser.items()}
        b = [x for x in EN.balance(grp, use) if any(p["id"] == m["id"] for p in x["parents"])]
        bal = b[0] if b else None
    return {"parents": parents, "kids": kids, "bal": bal,
            "auto_parents": [EN.label(by_id[p]) for p in sorted(auto.get(m["id"], set())) if p in by_id],
            "options": [dict(x, label=EN.label(x)) for x in sib if x["id"] != m["id"] and x["is_main"] in (1, 0) and x["active"]]}


@bp.route("/meters/qr")
@require_role(*ALL_ROLES)
def qr_labels():
    """พิมพ์ป้าย QR มิเตอร์ (A4 · 3 คอลัมน์) — ?factory= &kind= หรือ ?ids=1,2,3"""
    from .admin import qr_base, qr_svg
    db = get_db()
    ids = [int(x) for x in (request.args.get("ids") or "").split(",") if x.strip().isdigit()]
    if ids:
        ms = [m for m in (EN.meter(db, i) for i in ids) if m]
    else:
        ms = EN.meters(db, request.args.get("factory", type=int) or None, _kind(request.args.get("kind")))
    base = qr_base()
    labels = []
    for m in ms:
        tok = EF.qr_token(db, m["id"])
        url = f"{base}/q/{tok}"
        labels.append({"m": m, "label": EN.label(m), "url": url, "svg": qr_svg(url, box=5), "tok": tok})
    db.commit()
    return render_template("energy/qr_labels.html", labels=labels, KINDS=EN.KINDS)


@bp.route("/meters/<int:mid>/scada", methods=["POST"])
@require_role(*ENTRY_ROLES)
def meter_scada(mid):
    db = get_db()
    m0 = EN.meter(db, mid)
    if not m0 or not EF.can_touch(db, current_user_id(), m0):
        return render_template("error.html", code=403, message="ไม่มีสิทธิ์"), 403
    try:
        r = EF.scada_backfill(db, mid, request.form.get("days", 31, type=int))
        db.commit()
        flash(f"ดึงจาก SQL แล้ว: ตรวจ {r['rows']} วันที่ขาด · ได้ค่าอ่าน {r['days']} วัน"
              + (f" (ประมาณจากค่าก่อน/หลังเวลาอ่าน {r['interp']} วัน)" if r.get("interp") else "")
              + (f" · SQL ยังไม่มีค่า {len(r['no_data'])} วัน" if r.get("no_data") else ""), "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy.meter_detail", mid=mid))


@bp.route("/meters/<int:mid>/scada-day", methods=["POST"])
@require_role(*ENTRY_ROLES)
def meter_scada_day(mid):
    """v0.99.37 ดึงค่าของวันเดียวจาก SQL ให้มิเตอร์นี้ (ช่วงเวลาอ่าน · ไม่มีค่า → ประมาณจากค่าก่อน/หลัง)"""
    from .. import energy_src as ES
    db = get_db()
    m0 = EN.meter(db, mid)
    if not m0 or not EF.can_touch(db, current_user_id(), m0):
        return render_template("error.html", code=403, message="ไม่มีสิทธิ์"), 403
    try:
        day = date.fromisoformat(request.form.get("day") or "")
        src = ES.get_source(db, m0.get("scada_source_id") or 0)
        if not src:
            raise ValidationError(["มิเตอร์นี้ยังไม่ได้ผูกแหล่งข้อมูล SCADA / SQL"])
        ES.refetch_day(db, src, mid, day)
        db.commit()
        r = db.execute("SELECT value, note FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
        if r:
            flash(f"{day:%d/%m/%Y}: ได้ค่าอ่าน {r[0]:,.2f}" + (f" ({r[1]})" if r[1] and str(r[1]).startswith('≈') else " จาก SQL"), "ok")
        else:
            flash(f"{day:%d/%m/%Y}: SQL ยังไม่มีค่าของ Tag นี้ในช่วงเวลาอ่าน (และก่อน/หลังไม่เกิน 12 ชม.)", "error")
    except ValueError:
        flash("วันที่ไม่ถูกต้อง", "error")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("energy.meter_detail", mid=mid) + "#daily")


def _facs_scope(db):
    sc = EF.user_scope(db, current_user_id())
    return [f for f in M.list_factories(db) if not sc["factory_id"] or f["id"] == sc["factory_id"]]


@bp.route("/meters/new", methods=["GET", "POST"])
@require_role(*ENTRY_ROLES)
def meter_new():
    db = get_db()
    if request.method == "POST":
        try:
            form = request.form.to_dict()
            sc = EF.user_scope(db, current_user_id())
            if sc["factory_id"]:
                form["factory_id"] = str(sc["factory_id"])
            mid = EN.save_meter(db, None, form, current_user_id())
            db.commit()
            flash("เพิ่มมิเตอร์แล้ว", "ok")
            return redirect(url_for("energy.meter_detail", mid=mid))
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
    return render_template("energy/meter_new.html", **_ctx(kind=_kind(request.args.get("kind")) or (EN.KIND_ORDER[0] if EN.KIND_ORDER else ""),
                                                         fid=request.args.get("factory", type=int), facs_scope=_facs_scope(db),
                                                         **_struct_ctx(db, request.args.get("factory", type=int))))


# ───────────────────────── หมวดหมู่ + Section (ตั้งเองได้) ─────────────────────────

@bp.route("/categories", methods=["GET", "POST"])
@require_role(*ENTRY_ROLES)
def categories():
    db = get_db()
    sc = EF.user_scope(db, current_user_id())
    if request.method == "POST":
        act = request.form.get("act")
        uid = current_user_id()
        f = request.form
        try:
            if sc["factory_id"] and f.get("factory_id") and int(f.get("factory_id")) != sc["factory_id"] and act.startswith(("section", "line")):
                raise ValidationError("แก้ได้เฉพาะ Section/Line ของโรงงานตัวเอง")
            if act == "kind":
                k = EN.save_kind(db, f, uid, f.get("key_edit") or None)
                msg = f"บันทึกหมวด “{EN.KINDS[k]['th']}” แล้ว"
            elif act == "kind_del":
                EN.delete_kind(db, f.get("key", ""), uid)
                msg = "ลบหมวดหมู่แล้ว"
            elif act == "project":
                ST.save_project(db, f, uid, f.get("id", type=int))
                msg = "บันทึก Project แล้ว"
            elif act == "project_del":
                n = ST.delete_project(db, f.get("id", type=int) or 0, uid)
                msg = f"ลบ Project แล้ว (มิเตอร์ {n} ตัวกลับเป็น ‘ยังไม่กำหนด’)"
            elif act == "section_add":
                ST.add_section(db, f.get("factory_id") or None, f.get("name"), uid, f.get("note", ""))
                msg = "เพิ่ม Section แล้ว"
            elif act == "section":
                n = ST.rename_section(db, f.get("factory_id") or None, f.get("old", ""), f.get("new", ""), uid)
                msg = f"เปลี่ยนชื่อ/รวม Section แล้ว ({n} มิเตอร์)"
            elif act == "section_project":
                n = ST.set_section_project(db, f.get("factory_id") or None, f.get("old", ""), f.get("project_id") or None, uid,
                                           bool(f.get("all_factories")))
                msg = f"ตั้ง Project ให้ Section “{f.get('old') or '(ไม่ระบุ)'}” แล้ว ({n} มิเตอร์)"
            elif act == "section_del":
                ST.delete_section(db, f.get("factory_id") or None, f.get("old", ""), uid)
                msg = "ลบ Section แล้ว"
            elif act == "line_add":
                ST.add_line(db, f.get("factory_id") or None, f.get("section", ""), f.get("name"), uid)
                msg = "เพิ่ม Line แล้ว"
            elif act == "line":
                n = ST.rename_line(db, f.get("factory_id") or None, f.get("section", ""), f.get("old", ""), f.get("new", ""), uid)
                msg = f"เปลี่ยนชื่อ/รวม Line แล้ว ({n} มิเตอร์)"
            elif act == "line_del":
                ST.delete_line(db, f.get("factory_id") or None, f.get("section", ""), f.get("old", ""), uid)
                msg = "ลบ Line แล้ว"
            else:
                raise ValidationError("คำสั่งไม่ถูกต้อง")
            db.commit()
            flash(msg, "ok")
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
        return redirect(url_for("energy.categories", tab=f.get("tab") or None, factory=f.get("factory_id") or None))
    tab = request.args.get("tab") if request.args.get("tab") in ("kinds", "projects", "sections", "lines") else "kinds"
    fid = sc["factory_id"] or request.args.get("factory", type=int) or None
    return render_template("energy/categories.html", **_ctx(kinds=EN.kinds_admin(db), secs=ST.sections(db, fid), lns=ST.lines(db, fid), tab=tab,
                                                          projects_all=ST.projects(db), sec_proj=ST.section_projects(db), cfid=fid, scope_fid=sc["factory_id"],
                                                          facs_scope=_facs_scope(db)))


def _is_lead() -> bool:
    from ..security import current_role
    return current_role() in LEAD


# ───────────────────────── กรอกค่ารายวัน ─────────────────────────

@bp.route("/entry", methods=["GET", "POST"])
@require_role(*ENTRY_ROLES)
def entry():
    db = get_db()
    facs = M.list_factories(db)
    fid = request.values.get("factory", type=int) or (facs[0]["id"] if facs else None)
    kind = _kind(request.values.get("kind"), allow_empty=False)
    day = _day(request.values.get("day"))
    from .. import energy_forms as FM
    form_id = request.values.get("form", type=int)
    frm = FM.form(db, form_id) if form_id else None
    if request.method == "POST":
        body = request.get_json(silent=True) or {}
        try:
            allowed = None
            if frm:
                allowed = [i for i in FM.meter_ids(db, frm["id"])
                           if EF.can_touch(db, current_user_id(), EN.meter(db, i) or {})]
            res = EN.save_entry(db, fid, kind, _day(body.get("day")), body.get("values") or {}, current_user_id(),
                                reason=body.get("reason") or "", allowed_ids=allowed)
            db.commit()
            return jsonify({"ok": True, **res})
        except ValidationError as exc:
            db.rollback()
            if exc.errors[0] == "NEED_REASON":
                return jsonify({"error": "แก้ค่าที่บันทึกไว้แล้วต้องระบุเหตุผล", "need_reason": True}), 422
            return jsonify({"error": exc.errors[0]}), 422
    sc = EF.user_scope(db, current_user_id())
    if sc["factory_id"]:
        fid = sc["factory_id"]
        facs = [f for f in facs if f["id"] == fid]
    if frm:
        mrows = {r["id"]: r for r in EN.entry_rows_for(db, [m for m in (EN.meter(db, i) for i in FM.meter_ids(db, frm["id"])) if m], day)}
        rows, hdr = [], None
        hints = {}
        for it in frm["items"]:
            if it["type"] == "header":
                hdr = it["title"]
            elif it["meter_id"] in mrows:
                rows.append(dict(mrows[it["meter_id"]], grp=hdr or "", hint=it["hint"], need_photo=it["photo"]))
    else:
        rows = EN.entry_rows(db, fid, kind, day) if fid else []
    done = sum(1 for r in rows if r["cur"] is not None)
    counts = {k: len(EN.meters(db, fid, k)) for k in EN.KIND_ORDER} if fid else {}
    return render_template("energy/entry.html", **_ctx(rows=rows, fid=fid, kind=kind, day=day, done=done, counts=counts, facs_scope=facs,
                                                     frm=frm, forms=FM.forms(db, current_user_id(), fid, active_only=True),
                                                     today=now_dt().date(),
                                                     timedelta1=timedelta(days=1)))


# ───────────────────────── รายงานรายวัน ─────────────────────────

def _report_day(v) -> date:
    """วันที่ของหน้ารายงานรายวัน: ค่าเริ่มต้น = เมื่อวาน · ไม่เกินวันนี้ (v0.81.1 แยกชื่อ — เดิมชื่อซ้ำกับ _day ของหน้าบันทึกค่า ทำให้วันอนาคตถูกบันทึกเป็นวันนี้)"""
    try:
        d = date.fromisoformat(v or "")
    except ValueError:
        d = now_dt().date() - timedelta(days=1)
    return min(d, now_dt().date())


@bp.route("/daily")
@require_role(*ALL_ROLES)
def daily():
    db = get_db()
    facs = M.list_factories(db)
    fid = request.args.get("factory", type=int) or None
    kind = _kind(request.args.get("kind") or "elec", allow_empty=False)
    day = _report_day(request.args.get("day"))
    sf = _sf()
    rep = ST.daily_report(db, day, fid, kind, **sf)
    fc = rep["facets"]
    if sf["grp"]:
        fc["lines"] = [x for x in fc["lines"] if x["section"] == ("" if sf["grp"] == "-" else sf["grp"])]
    counts = {k: len(EN.meters(db, fid, k)) for k in EN.KIND_ORDER}
    return render_template("energy/daily.html", **_ctx(rep=rep, fid=fid, kind=kind, day=day, sf=sf, fc=fc, counts=counts, facs=facs,
                                                     today=now_dt().date(), d_prev=day - timedelta(days=1), d_next=day + timedelta(days=1)))


@bp.route("/daily.xlsx")
@require_role(*ALL_ROLES)
def daily_xlsx():
    db = get_db()
    fid = request.args.get("factory", type=int) or None
    kind = _kind(request.args.get("kind") or "elec", allow_empty=False)
    day = _report_day(request.args.get("day"))
    data = ST.daily_xlsx(db, day, fid, kind, **_sf())
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="energy_daily_{kind}_{day:%Y-%m-%d}.xlsx"'})


# ───────────────────────── ตารางรายเดือน ─────────────────────────

@bp.route("/sheet")
@require_role(*ALL_ROLES)
def sheet():
    db = get_db()
    facs = M.list_factories(db)
    fid = request.args.get("factory", type=int) or (facs[0]["id"] if facs else None)
    kind = _kind(request.args.get("kind"), allow_empty=False)
    month = _month(request.args.get("month"))
    view = "v" if request.args.get("view") == "v" else "u"
    sf = _sf()
    sh = EN.month_sheet(db, fid, kind, month, **sf) if fid else None
    counts = {k: len(EN.meters(db, fid, k)) for k in EN.KIND_ORDER} if fid else {}
    fc = ST.facets(EN.meters(db, fid, kind)) if fid else {"projects": [], "sections": [], "lines": []}
    if sf["grp"]:
        fc["lines"] = [x for x in fc["lines"] if x["section"] == ("" if sf["grp"] == "-" else sf["grp"])]
    return render_template("energy/sheet.html", **_ctx(sh=sh, fid=fid, kind=kind, month=month, view=view, counts=counts, sf=sf, fc=fc,
                                                     prev=(month - timedelta(days=1)).replace(day=1),
                                                     nxt=(month + timedelta(days=32)).replace(day=1)))


@bp.route("/sheet.xlsx")
@require_role(*ALL_ROLES)
def sheet_xlsx():
    db = get_db()
    fid = request.args.get("factory", type=int)
    kind = _kind(request.args.get("kind"), allow_empty=False)
    month = _month(request.args.get("month"))
    if not fid:
        return redirect(url_for("energy.sheet"))
    data = EN.sheet_xlsx(db, fid, kind, month, **_sf())
    fn = f"energy_{kind}_F{fid}_{month:%Y-%m}.xlsx"
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{fn}"'})


# ───────────────────────── ตั้งค่า + ปฏิทินวันหยุด ─────────────────────────

@bp.route("/settings", methods=["GET", "POST"])
@require_role(*LEAD)
def settings():
    db = get_db()
    year = request.args.get("year", type=int) or now_dt().year
    if request.method == "POST":
        act = request.form.get("act")
        try:
            if act == "holiday":
                OPS.add_holiday(db, request.form.get("factory_id"), request.form.get("day"), request.form.get("name"),
                                request.form.get("kind"), current_user_id())
                msg = "เพิ่มวันหยุดแล้ว"
            elif act == "holiday_del":
                OPS.del_holiday(db, request.form.get("id", type=int) or 0, current_user_id())
                msg = "ลบวันหยุดแล้ว"
            else:
                data = request.form.to_dict()
                for cb in ("sunday_off", "ocr"):
                    if cb in request.form:
                        data[cb] = "1" if "1" in request.form.getlist(cb) else "0"
                before = (int(EN.settings(db).get("usage_day", 1)), int(EN.settings(db)["scada_hh"]), int(EN.settings(db)["scada_mm"]))
                cfg = EN.save_settings(db, data, current_user_id())
                msg = "บันทึกการตั้งค่าแล้ว"
                if before != (int(cfg.get("usage_day", 1)), int(cfg["scada_hh"]), int(cfg["scada_mm"])):   # v0.89 วิธีนับวันเปลี่ยน
                    from .. import energy_interval as EI
                    n = EI.ensure_cut(db)
                    if n:
                        msg += f" · สร้างค่าอ่านรายวันจากค่าต่อช่วงใหม่ {n} ค่า"
            db.commit()
            flash(msg, "ok")
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
        return redirect(url_for("energy.settings", year=year))
    return render_template("energy/settings.html", **_ctx(cfg=EN.settings(db), hols=OPS.holidays(db, year), year=year))


@bp.route("/api/meter/<int:mid>")
@require_role(*ALL_ROLES)
def api_meter(mid):
    db = get_db()
    try:
        det = EN.meter_detail(db, mid, 60)
    except ValidationError:
        return jsonify({"error": "ไม่พบมิเตอร์"}), 404
    return jsonify({"label": EN.label(det["m"]), "days": det["days"], "u": det["u"], "unit": det["m"]["unit"]})


# เส้นทางที่แยกไปไฟล์ย่อย (ต้อง import ท้ายไฟล์ เพราะไฟล์ย่อยอ้างชื่อจากไฟล์นี้)
from . import energy_import  # noqa: E402,F401
from . import energy_forms_ui  # noqa: E402,F401
from . import energy_cases  # noqa: E402,F401
from . import energy_report  # noqa: E402,F401
from .energy_import import _load_tmp, _save_tmp, _tmp_dir  # noqa: E402,F401  (ไฟล์อื่น import ชื่อนี้จาก energy)
