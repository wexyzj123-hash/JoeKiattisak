"""ecs/views/energy_src.py — v0.72 แหล่งข้อมูล SCADA ของ Energy Data (แยกจาก E-Check)

/energy/sources                    รายการแหล่งข้อมูล + เพิ่มใหม่
/energy/sources/<id>               ตั้งค่า · ทดสอบ · จับคู่ Tag ↔ มิเตอร์ · ประวัติ
/energy/sources/<id>/test          ทดสอบเชื่อมต่อ (JSON) — ไม่บันทึกค่าอ่าน, แสดงค่าที่จะลงให้มิเตอร์
/energy/sources/<id>/tags          บันทึกการจับคู่   /mapping.xlsx  /mapping-import   ส่งออก/นำเข้า Excel
/energy/meters/<mid>/scada-test    ทดสอบค่าของมิเตอร์ตัวเดียว (JSON)
"""
from __future__ import annotations

from datetime import timedelta

from flask import Blueprint, Response, abort, flash, jsonify, redirect, render_template, request, url_for

from .. import connectors as CN
from .. import energy as EN
from .. import energy_field as EF
from .. import energy_src as ES
from ..db import get_db
from ..security import current_user_id, require_role
from ..services import ValidationError
from .energy import _ctx

bp = Blueprint("energy_src", __name__, url_prefix="/energy")
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


@bp.before_request
def _ensure():
    from flask import session
    if "user_id" in session:
        EN.ensure(get_db())


def _form_data() -> dict:
    f = request.form
    data = {k: f.get(k) for k in ("name", "kind", "interval_min", "ts_shift_min", "note", "late_min", "value_kind", "param_shift_min")}
    data["active"] = "1" if f.get("active") else "0"
    kind = f.get("kind")
    cfg = {}
    import json
    for key in CN.DEFAULT_CONFIG.get(kind, {}):
        name = f"cfg.{key}"
        if name not in f:
            continue
        val = f.get(name)
        if key == "headers":
            try:
                val = json.loads(val or "{}")
            except ValueError:
                raise ValidationError(["headers ต้องเป็น JSON"]) from None
        elif key == "backfill_days":
            try:
                val = max(0.0, min(float(val or 1), 90.0))
            except ValueError:
                val = 1
        cfg[key] = val
    data["config"] = cfg
    return data


def _has_pyodbc() -> bool:
    import importlib.util
    return importlib.util.find_spec("pyodbc") is not None


@bp.route("/sources", methods=["GET", "POST"])
@require_role("admin")
def sources():
    db = get_db()
    if request.method == "POST":
        try:
            sid = ES.save_source(db, _form_data(), current_user_id())
            db.commit()
            flash("เพิ่มแหล่งข้อมูลแล้ว — กด “ทดสอบ” เพื่อดึงรายชื่อ Tag แล้วจับคู่กับมิเตอร์", "ok")
            return redirect(url_for("energy_src.source_detail", sid=sid))
        except ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
    rows = ES.list_sources(db)
    from .. import services as S
    now = S.now_dt()
    for r in rows:                                        # v0.73 ค่าอ่านรายวัน 3 วันล่าสุด
        r["health"] = ES.health(db, r["id"])
        wm = S.parse_ts(r["watermark"]) if r.get("watermark") else None     # v0.99.40 จุดดึงเลยปัจจุบัน / ค้าง
        r["wm_future"] = bool(wm and wm > now + timedelta(minutes=ES.FUTURE_TOL_MIN))
        gap = (now - wm).total_seconds() / 3600 if wm and not r["wm_future"] else 0
        r["wm_stale"] = (f"{gap / 24:.0f} วัน" if gap >= 48 else f"{gap:.0f} ชม.") if r["active"] and gap >= max(3, 3 * int(r["interval_min"] or 15) / 60 + 3) else ""
        last0 = r["last_status"] == "ok" and str(r.get("last_message") or "").find("อ่าน 0 แถว") >= 0
        r["problem"] = bool(r["active"] and (r["wm_future"] or r["wm_stale"] or r.get("alert_state") or r["last_status"] == "failed"
                                             or (last0 and (r["health"]["count"]["missing"] or 0))))
    return render_template("energy/sources.html", **_ctx(rows=rows, kinds=ES.KIND_TH, defaults=ES.DEFAULT_CONFIG))


@bp.route("/sources/<int:sid>", methods=["GET", "POST"])
@require_role("admin")
def source_detail(sid):
    db = get_db()
    src = ES.get_source(db, sid)
    if not src:
        abort(404)
    if request.method == "POST":
        try:
            data = _form_data()
            data["kind"] = src["kind"]
            ES.save_source(db, data, current_user_id(), sid)
            db.commit()
            flash("บันทึกการตั้งค่าแล้ว", "ok")
            new_vk = ES.get_source(db, sid).get("value_kind") or "reading"
            if new_vk != (src.get("value_kind") or "reading"):              # v0.87 เปลี่ยนชนิดค่า → ล้างค่าอ่านจาก SCADA เดิมแล้วลงใหม่
                _switch_kind(db, sid, new_vk)
                return redirect(url_for("energy_src.source_detail", sid=sid))
            if int(ES.get_source(db, sid).get("ts_shift_min") or 0) != int(src.get("ts_shift_min") or 0):   # v0.76
                _do_reapply(db, sid, None, "เปลี่ยนเลื่อนเวลาแล้ว — ")
            return redirect(url_for("energy_src.source_detail", sid=sid))
        except ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
    cfg = {**CN.DEFAULT_CONFIG.get(src["kind"], {}), **src["config"]}      # v0.75 ช่องตั้งค่าใหม่แสดงให้แหล่งเดิมด้วย
    if src["kind"] == "mssql":
        cfg["conn"] = CN.mask_secret(cfg.get("conn", ""))
    runs = [dict(r) for r in db.execute("SELECT * FROM en_source_runs WHERE source_id=? ORDER BY id DESC LIMIT 30", (sid,))]
    rows = ES.tag_rows(db, sid)
    sug = ES.suggest(db, sid, rows)
    flt = request.args.get("show") if request.args.get("show") in ("free", "mapped", "dup") else ""
    q = (request.args.get("q") or "").strip()
    shown = [r for r in rows if (flt == "free" and not r["meter"]) or (flt == "mapped" and r["meter"]) or (flt == "dup" and r["dup"]) or not flt]
    if q:                                                  # v0.86 ค้นหาทุก Tag (ไม่จำกัดแค่ที่แสดง)
        words = q.lower().split()
        shown = [r for r in shown if all(w in f"{r['tag']} {r['text']}".lower() for w in words)]
    cs = EN.settings(db)
    from datetime import date

    from .. import services as S
    try:
        sday = date.fromisoformat(request.args.get("sday") or "")
    except ValueError:
        sday = S.now_dt().date()
    return render_template("energy/source_detail.html", **_ctx(
        sday=sday, dstat=ES.day_status(db, sid, sday), hl=ES.health(db, sid), STATES=ES.STATES, today=S.now_dt().date(),
        s=src, cfg=cfg, kinds=ES.KIND_TH, runs=runs, tags=shown, all_tags=rows, sug=sug, flt=flt, q=q, pyodbc=_has_pyodbc(),
        n_dup=sum(1 for r in rows if r["dup"]), groups=sorted({(m["m"].get("grp") or "") for m in ES.meter_choices(db)} - {""}),
        bf_max=ES.BACKFILL_MAX_DAYS, timedelta=timedelta, VALUE_KINDS=__import__("ecs.energy_interval", fromlist=["x"]).VALUE_KINDS,
        choices=ES.meter_choices(db), n_mapped=sum(1 for r in rows if r["meter"]), n_free=sum(1 for r in rows if not r["meter"]),
        hh=int(cs["scada_hh"]), mm=int(cs["scada_mm"]), win=int(cs["scada_window"])))


def _switch_kind(db, sid, vk):
    """ชนิดค่าเปลี่ยน (เลขสะสม ↔ ค่าต่อช่วง): ค่าอ่านจาก SCADA เดิมของมิเตอร์ในแหล่งนี้คิดคนละแบบ → ลบทั้งหมด แล้วดึงใหม่ N วัน"""
    from .. import energy_interval as EI
    from .. import services as S
    ids = [r[0] for r in db.execute("SELECT id FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>''", (sid,))]
    n = 0
    for i in range(0, len(ids), 500):
        ch = ids[i:i + 500]
        n += db.execute(f"DELETE FROM en_readings WHERE src='scada' AND meter_id IN ({','.join('?' * len(ch))})", ch).rowcount
        if vk != "interval":
            EI.clear(db, ch, S.now_dt().date() - timedelta(days=3650), S.now_dt().date())
    db.commit()
    days = _reapply_days() or 7
    flash(f"เปลี่ยนชนิดค่าเป็น “{EI.VALUE_KINDS[vk]}” — ล้างค่าอ่านจาก SCADA เดิม {n} ค่า แล้วดึงใหม่ {days} วัน", "ok")
    try:
        today = S.now_dt().date()
        r = ES.backfill(db, sid, today - timedelta(days=days - 1), today, "replace", current_user_id())
        db.commit()
        flash(f"ดึงใหม่แล้ว · ได้ค่าอ่าน {r['readings']} ค่า" + (f" · ไม่มีค่าใน SCADA {len(r['no_data'])} วัน" if r["no_data"] else "")
              + " · ต้องการย้อนหลังมากกว่านี้ใช้ “ดึงค่าย้อนหลัง”", "ok")
    except (ValidationError, CN.SourceError) as exc:
        db.rollback()
        flash(f"ดึงใหม่ไม่สำเร็จ: {exc.errors[0] if isinstance(exc, ValidationError) else exc}", "error")


def _reapply_days() -> int:
    v = request.form.get("reapply_days", type=int)
    return v if v in (0, 1, 3, 7, 14, 31, 62) else 7


def _do_reapply(db, sid, meter_ids, prefix=""):
    """v0.76 ลงค่าอ่านใหม่ย้อนหลังหลังแก้การตั้งค่า"""
    try:
        r = ES.reapply(db, sid, _reapply_days(), current_user_id(), meter_ids)
        db.commit()
        if r:
            flash(f"{prefix}ลงค่าอ่านใหม่ย้อนหลัง {r['days']} วัน: {r['meters']} มิเตอร์ · ได้ค่าอ่าน {r['readings']} ค่า", "ok")
    except (ValidationError, CN.SourceError) as exc:
        db.rollback()
        flash(f"ลงค่าอ่านใหม่ย้อนหลังไม่สำเร็จ: {exc.errors[0] if isinstance(exc, ValidationError) else exc}", "error")


@bp.route("/sources/<int:sid>/test", methods=["POST"])
@require_role("admin")
def source_test(sid):
    db = get_db()
    try:
        res = ES.test(db, sid, days=float((request.get_json(silent=True) or {}).get("days", 2) or 2))
        db.commit()
        return jsonify({"ok": True, **res})
    except (CN.SourceError, ValidationError) as exc:
        db.rollback()
        return jsonify({"error": str(exc) if isinstance(exc, CN.SourceError) else "; ".join(exc.errors)}), 400


@bp.route("/sources/<int:sid>/run", methods=["POST"])
@require_role("admin")
def source_run(sid):
    db = get_db()
    if not ES.get_source(db, sid):
        abort(404)
    res = ES.run_source(db, sid, manual=True)
    db.commit()
    flash(res["message"], "ok" if res["ok"] else "error")
    return redirect(url_for("energy_src.source_detail", sid=sid) + "#runs")


@bp.route("/sources/<int:sid>/heal", methods=["POST"])
@require_role("admin")
def source_heal(sid):
    """v0.73 เติมค่าอ่านที่ขาด (2 วันล่าสุด) ตอนนี้"""
    db = get_db()
    src = ES.get_source(db, sid)
    if not src:
        abort(404)
    before = ES.health(db, sid)["count"]["missing"]
    try:
        n = ES.heal(db, src, force=True)
        db.commit()
        after = ES.health(db, sid)["count"]["missing"]
        flash((f"เติมค่าอ่านแล้ว {n} ค่า" + (f" · ยังขาด {after} (แหล่งข้อมูลไม่มีค่าในช่วงเวลาอ่าน)" if after else " · ครบแล้ว"))
              if before else "ไม่มีค่าอ่านที่ขาดใน 2 วันล่าสุด", "ok")
    except CN.SourceError as exc:
        db.rollback()
        flash(f"ดึงข้อมูลย้อนหลังไม่สำเร็จ: {exc}", "error")
    return redirect(url_for("energy_src.source_detail", sid=sid, sday=request.form.get("sday") or None) + "#status")


@bp.route("/sources/<int:sid>/upload", methods=["POST"])
@require_role("admin")
def source_upload(sid):
    db = get_db()
    src = ES.get_source(db, sid)
    if not src:
        abort(404)
    f = request.files.get("file")
    if not f or not f.filename:
        flash("กรุณาเลือกไฟล์ CSV", "error")
        return redirect(url_for("energy_src.source_detail", sid=sid))
    raw = f.read(CN.MAX_FILE_MB * 1024 * 1024 + 1)
    if len(raw) > CN.MAX_FILE_MB * 1024 * 1024:
        flash(f"ไฟล์ใหญ่เกิน {CN.MAX_FILE_MB} MB", "error")
        return redirect(url_for("energy_src.source_detail", sid=sid))
    cfg = dict(CN.DEFAULT_CONFIG["csv"])
    cfg.update({k: v for k, v in src["config"].items() if k in cfg})
    try:
        rows = CN.parse_csv(raw.decode(cfg.get("encoding") or "utf-8-sig", errors="replace"), cfg)
    except CN.SourceError as exc:
        flash(str(exc), "error")
        return redirect(url_for("energy_src.source_detail", sid=sid))
    res = ES.run_source(db, sid, manual=True, rows_override=rows, label=f"อัปโหลด {f.filename}")
    db.commit()
    flash(res["message"], "ok" if res["ok"] else "error")
    return redirect(url_for("energy_src.source_detail", sid=sid) + "#runs")


@bp.route("/sources/<int:sid>/tags", methods=["POST"])
@require_role("admin")
def source_tags(sid):
    db = get_db()
    if not ES.get_source(db, sid):
        abort(404)
    f = request.form
    items = [{"tag": t, "meter": f.get(f"meter.{i}", ""), "scale": f.get(f"scale.{i}"), "offset": f.get(f"offset.{i}"),
              **({"vmin": f.get(f"vmin.{i}"), "vmax": f.get(f"vmax.{i}")} if f"vmin.{i}" in f or f"vmax.{i}" in f else {})}
             for i, t in enumerate(f.getlist("tag"))]
    if (f.get("new_tag") or "").strip():
        items.append({"tag": f.get("new_tag"), "meter": f.get("new_meter", ""), "scale": 1, "offset": 0})
    before = ES.meter_snapshot(db, sid)
    try:
        r = ES.save_mapping(db, sid, items, current_user_id())
        db.commit()
        flash(f"บันทึกการจับคู่แล้ว · ผูกใหม่ {r['mapped']} · ถอด {r['unmapped']}" + (f" · ย้าย {r['moved']}" if r.get("moved") else ""), "ok")
        for w in r.get("warnings", [])[:10]:
            flash(w, "info" if w.startswith("ย้าย") else "error")
        after = ES.meter_snapshot(db, sid)
        changed = {m for m in set(before) | set(after) if before.get(m) != after.get(m) and m in after}
        if changed:
            _do_reapply(db, sid, changed)
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors[:10]:
            flash(e, "error")
    return redirect(url_for("energy_src.source_detail", sid=sid, show=f.get("show") or None, q=f.get("q") or None) + "#tags")


@bp.route("/sources/<int:sid>/mapping.xlsx")
@require_role("admin")
def source_mapping_xlsx(sid):
    db = get_db()
    if not ES.get_source(db, sid):
        abort(404)
    return Response(ES.export_xlsx(db, sid), mimetype=XLSX,
                    headers={"Content-Disposition": f'attachment; filename="energy-tag-mapping-{sid}.xlsx"'})


@bp.route("/sources/<int:sid>/mapping-import", methods=["POST"])
@require_role("admin")
def source_mapping_import(sid):
    db = get_db()
    if not ES.get_source(db, sid):
        abort(404)
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(".xlsx"):
        flash("กรุณาเลือกไฟล์ .xlsx", "error")
        return redirect(url_for("energy_src.source_detail", sid=sid) + "#tags")
    before = ES.meter_snapshot(db, sid)
    try:
        r = ES.import_xlsx(db, sid, f.read(5 * 1024 * 1024), current_user_id())
        db.commit()
        after = ES.meter_snapshot(db, sid)
        changed = {m for m in set(before) | set(after) if before.get(m) != after.get(m) and m in after}
        if changed:
            _do_reapply(db, sid, changed)
        flash(f"นำเข้าการจับคู่แล้ว · {r['rows']} แถว · ผูกใหม่ {r['mapped']} · ถอด {r['unmapped']}", "ok")
        for w in r.get("warnings", [])[:10]:
            flash(w, "info" if w.startswith("ย้าย") else "error")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors[:10]:
            flash(e, "error")
    return redirect(url_for("energy_src.source_detail", sid=sid) + "#tags")


@bp.route("/sources/<int:sid>/delete", methods=["POST"])
@require_role("admin")
def source_delete(sid):
    db = get_db()
    if not ES.get_source(db, sid):
        abort(404)
    n = ES.delete_source(db, sid, current_user_id())
    db.commit()
    flash(f"ลบแหล่งข้อมูลแล้ว · มิเตอร์ {n} ตัวกลับเป็นจดด้วยมือ (ค่าอ่านที่ดึงแล้วยังอยู่)", "ok")
    return redirect(url_for("energy_src.sources"))


@bp.route("/meters/<int:mid>/scada-test", methods=["POST"])
@require_role("admin", "supervisor", "technician")
def meter_scada_test(mid):
    """ทดสอบค่าของมิเตอร์ตัวเดียว: ดึง 3 วันล่าสุดจากแหล่งที่ผูกไว้ แล้วแสดงค่าที่จะลงเป็นค่าอ่านรายวัน (ไม่บันทึก)"""
    db = get_db()
    m = EN.meter(db, mid)
    if not m or not EF.can_touch(db, current_user_id(), m):
        return jsonify({"error": "ไม่มีสิทธิ์"}), 403
    if not m.get("scada_source_id") or not (m.get("scada_tag") or "").strip():
        return jsonify({"error": "มิเตอร์นี้ยังไม่ได้ผูกแหล่ง SCADA และ Tag"}), 400
    src = ES.get_source(db, m["scada_source_id"])
    if not src:
        return jsonify({"error": "ไม่พบแหล่งข้อมูล"}), 400
    from datetime import timedelta

    from .. import services as S
    try:
        if src["kind"] == "csv":
            raise CN.SourceError("แหล่ง CSV ทดสอบรายมิเตอร์ไม่ได้ — ใช้ปุ่มทดสอบที่หน้าแหล่งข้อมูล")
        rows, _k, bad = ES.fetch(db, {**src, "watermark": S.ts(S.now_dt() - timedelta(days=3))})
    except CN.SourceError as exc:
        return jsonify({"error": str(exc)}), 400
    tag = m["scada_tag"].strip()
    mine = [r for r in rows if str(r[0]).strip() == tag]
    best = EF.scada_pick(db, src, rows, only_meter=mid)
    return jsonify({"ok": True, "rows": len(rows), "tag_rows": len(mine), "found": bool(mine),
                    "last": ({"ts": S.ts(mine[-1][1]), "value": mine[-1][2]} if mine else None),
                    "plan": [{"day": d, "at": S.ts(dt), "value": round(v, 3), "dist": round(dist)} for (_, d), (dist, dt, v) in sorted(best.items())]})


# ───────────────────────── v0.74 ตรวจสอบ / แก้ไข ค่าอ่านจาก SCADA ย้อนหลัง ─────────────────────────

def _need_fixer(db):
    from .. import submissions as SUB
    if not SUB.can_approve(db, current_user_id()):
        abort(403)


def _range():
    from datetime import date, timedelta

    from .. import services as S
    today = S.now_dt().date()
    try:
        d2 = date.fromisoformat(request.values.get("to") or "")
    except ValueError:
        d2 = today
    try:
        d1 = date.fromisoformat(request.values.get("from") or "")
    except ValueError:
        d1 = d2 - timedelta(days=6)
    if d1 > d2:
        d1, d2 = d2, d1
    if (d2 - d1).days > 30:
        d1 = d2 - timedelta(days=30)
    return d1, d2


@bp.route("/sources/<int:sid>/audit")
@require_role("admin", "supervisor", "technician")
def source_audit(sid):
    """ตรวจสอบค่าอ่านรายวันจาก SCADA ช่วงวันที่: มิเตอร์ × วัน — มา / ไม่มา / แก้ / ยกเลิก + ปัญหา"""
    from .. import services as S
    db = get_db()
    _need_fixer(db)
    src = ES.get_source(db, sid)
    if not src:
        abort(404)
    d1, d2 = _range()
    grp = request.args.get("grp") or None
    only = request.args.get("only") if request.args.get("only") in ("problem", "fix") else ""
    rep = ES.audit(db, sid, d1, d2, grp=grp)
    groups = sorted({m["grp"] or "" for m in ES.audit(db, sid, d2, d2)["meters"]} - {""}) if rep["meters"] or grp else []
    return render_template("energy/source_audit.html", **_ctx(s=src, rep=rep, d1=d1, d2=d2, grp=grp, only=only, groups=groups,
                                                              STATES={**ES.STATES, "fix": "แก้ไขค่า"}, sources=ES.list_sources(db),
                                                              today=S.now_dt().date()))


@bp.route("/sources/<int:sid>/audit.xlsx")
@require_role("admin", "supervisor", "technician")
def source_audit_xlsx(sid):
    db = get_db()
    _need_fixer(db)
    if not ES.get_source(db, sid):
        abort(404)
    d1, d2 = _range()
    return Response(ES.audit_xlsx(db, sid, d1, d2), mimetype=XLSX,
                    headers={"Content-Disposition": f'attachment; filename="energy-scada-audit-{sid}-{d1:%Y%m%d}-{d2:%Y%m%d}.xlsx"'})


def _back(sid):
    f = request.form
    return redirect(url_for("energy_src.source_audit", sid=sid, **{"from": f.get("from"), "to": f.get("to"), "grp": f.get("grp") or None,
                                                                   "only": f.get("only") or None})
                    + (f"#m{f.get('meter_id')}" if f.get("meter_id") else ""))


@bp.route("/sources/<int:sid>/fix", methods=["POST"])
@require_role("admin", "supervisor", "technician")
def source_fix(sid):
    from datetime import date

    from .. import energy_ops as OPS
    db = get_db()
    _need_fixer(db)
    src = ES.get_source(db, sid)
    if not src:
        abort(404)
    f = request.form
    try:
        mid = int(f.get("meter_id") or 0)
        day = date.fromisoformat(f.get("day") or "")
        m = EN.meter(db, mid)
        if not m or m.get("scada_source_id") != sid:
            raise ValidationError(["มิเตอร์ไม่ได้ผูกกับแหล่งข้อมูลนี้"])
        act = f.get("act")
        if act == "value":
            OPS.correct(db, mid, day.isoformat(), f.get("value"), "", f.get("reason"), current_user_id())
            db.execute("DELETE FROM en_skips WHERE meter_id=? AND day=? AND reason='scada_void'", (mid, day.isoformat()))
            msg = "บันทึกค่าที่แก้แล้ว (ระบบไม่ลงทับ)"
        elif act == "void":
            ES.void_day(db, mid, day, f.get("reason"), current_user_id())
            msg = "ยกเลิกค่า SCADA ของวันนี้แล้ว (ระบบไม่ลงซ้ำ)"
        elif act == "clear":
            n = ES.restore_day(db, src, mid, day, current_user_id())
            msg = f"คืนค่าจาก SCADA แล้ว ({'ได้ค่า' if n else 'ไม่มีค่าในช่วงเวลาอ่าน'})"
        elif act == "refetch":
            n = ES.refetch_day(db, src, mid, day)
            msg = f"ดึงค่าวันนี้ใหม่แล้ว ({'ได้ค่า' if n else 'ไม่มีค่าใหม่ / ค่าที่แก้ไว้ไม่ถูกทับ'})"
        else:
            raise ValidationError(["คำสั่งไม่ถูกต้อง"])
        db.commit()
        flash(msg + f" · {day:%d/%m/%Y}", "ok")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    except CN.SourceError as exc:
        db.rollback()
        flash(f"ดึงข้อมูลจาก SCADA ไม่สำเร็จ: {exc}", "error")
    except ValueError:
        db.rollback()
        flash("ข้อมูลไม่ครบ", "error")
    return _back(sid)


@bp.route("/sources/<int:sid>/backfill", methods=["POST"])
@require_role("admin", "supervisor", "technician")
def source_backfill(sid):
    """v0.86 ดึงค่าย้อนหลังตามช่วงที่กำหนดเอง — เติมเฉพาะวันที่ขาด หรือ ลงค่าจาก SCADA ใหม่ทั้งช่วง"""
    db = get_db()
    _need_fixer(db)
    if not ES.get_source(db, sid):
        abort(404)
    from datetime import date
    try:
        d1, d2 = date.fromisoformat(request.form.get("from") or ""), date.fromisoformat(request.form.get("to") or "")
    except ValueError:
        d1, d2 = _range()
    mode = "replace" if request.form.get("mode") == "replace" else "fill"
    grp = request.form.get("grp") or None
    try:
        r = ES.backfill(db, sid, d1, d2, mode, current_user_id(), grp=grp)
        db.commit()
        msg = f"ดึงค่าย้อนหลัง {r['from']:%d/%m/%Y} – {r['to']:%d/%m/%Y}" + (f" (Section {grp})" if grp else "")
        msg += f" · ลงใหม่ {r['removed']} ค่า" if mode == "replace" else ""
        msg += f" · วันที่ต้องดึง {r['days']} วัน · ได้ค่าอ่าน {r['readings']} ค่า"
        flash(msg, "ok")
        if r["no_data"]:
            flash(f"ไม่มีค่าใน SCADA {len(r['no_data'])} วัน: " + ", ".join(d.strftime("%d/%m") for d in r["no_data"][:15])
                  + (" …" if len(r["no_data"]) > 15 else "") + " — ตรวจตาราง/เวลาอ่าน หรือจดเอง", "error")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    if request.form.get("back") == "audit":
        return _back(sid)
    return redirect(url_for("energy_src.source_detail", sid=sid) + "#backfill")


@bp.route("/sources/<int:sid>/fill-range", methods=["POST"])
@require_role("admin", "supervisor", "technician")
def source_fill_range(sid):
    db = get_db()
    _need_fixer(db)
    src = ES.get_source(db, sid)
    if not src:
        abort(404)
    d1, d2 = _range()
    try:
        r = ES.fill_range(db, src, d1, d2)
        db.commit()
        flash(f"ดึงวันที่ขาดแล้ว: {r['days']} วัน · ได้ค่าอ่าน {r['readings']} ค่า", "ok")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    return _back(sid)


# ───────────────────────── v0.99.40 ตรวจวินิจฉัย + ข้อมูลดิบจาก SQL ต้นทาง ─────────────────────────

@bp.route("/sources/<int:sid>/diagnose")
@require_role("admin")
def source_diagnose(sid):
    """ถาม SQL ตรง ๆ แล้วบอกสาเหตุที่ดึงข้อมูลไม่ได้ / ค่าอ่านขาด พร้อมปุ่มแก้"""
    from .. import energy_diag as ED
    db = get_db()
    if not ES.get_source(db, sid):
        abort(404)
    try:
        res = ED.diagnose(db, sid)
        err = ""
    except (CN.SourceError, ValidationError) as exc:
        res, err = None, (str(exc) if isinstance(exc, CN.SourceError) else "; ".join(exc.errors))
    db.commit()
    return render_template("energy/source_diag.html", **_ctx(d=res, err=err, s=ES.get_source(db, sid), sources=ES.list_sources(db)))


@bp.route("/sources/<int:sid>/diagnose/fix", methods=["POST"])
@require_role("admin")
def source_diagnose_fix(sid):
    from .. import energy_diag as ED
    db = get_db()
    if not ES.get_source(db, sid):
        abort(404)
    try:
        msg = ED.apply(db, sid, request.form.get("do", ""), request.form.get("value", ""), current_user_id())
        db.commit()
        flash("แก้ไขแล้ว — " + msg, "ok")
    except (CN.SourceError, ValidationError, ValueError) as exc:
        db.rollback()
        flash("แก้ไขไม่สำเร็จ: " + (exc.errors[0] if isinstance(exc, ValidationError) else str(exc)), "error")
    return redirect(url_for("energy_src.source_diagnose", sid=sid))


@bp.route("/sources/<int:sid>/raw")
@require_role("admin", "supervisor", "viewer")
def source_raw(sid):
    """ข้อมูลดิบของ Tag จาก SQL ต้นทาง (สด) — ทุกแถวในช่วงที่เลือก + แถวที่ใช้เป็นค่าอ่านรายวัน"""
    from datetime import date

    from .. import energy_diag as ED
    from .. import services as S
    db = get_db()
    src = ES.get_source(db, sid)
    if not src:
        abort(404)
    tag = (request.args.get("tag") or "").strip()
    today = S.now_dt().date()

    def _d(k, dflt):
        try:
            return date.fromisoformat(request.args.get(k) or "")
        except ValueError:
            return dflt
    d_to = _d("to", today)
    d_from = _d("from", d_to - timedelta(days=1))
    tags = [r["tag"] for r in ES.tag_rows(db, sid)]
    res, err = None, ""
    if tag:
        try:
            res = ED.raw(db, sid, tag, d_from, d_to)
        except (CN.SourceError, ValidationError) as exc:
            err = str(exc) if isinstance(exc, CN.SourceError) else "; ".join(exc.errors)
    if res and request.args.get("format") == "csv":
        import csv
        import io
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["tag", "time", "time_in_sql", "value", "value_x_scale", "used_as_daily_reading"])
        for r in res["rows"]:
            w.writerow([tag, S.ts(r["ts"]), S.ts(r["sql_ts"]), r["value"], r["scaled"], "Y" if r["used"] else ""])
        return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=scada_{sid}_{d_from}_{d_to}.csv"})
    return render_template("energy/source_raw.html", **_ctx(s=src, tag=tag, tags=tags, res=res, err=err, d_from=d_from, d_to=d_to,
                                                          today=today, max_days=ED.RAW_MAX_DAYS, timedelta=timedelta))
