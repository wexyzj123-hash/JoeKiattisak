"""v0.99.39 สแกน QR เปิดเช็คชีทโดยตรงแล้วแนบรูปไม่เข้า

สาเหตุหลัก: สแกนด้วย LINE / Facebook ฯลฯ → หน้าเปิดใน "เบราว์เซอร์ในแอป" ซึ่งถ่าย/แนบรูปไม่ได้
· LINE → ส่งต่อไปเบราว์เซอร์หลักของเครื่อง (?openExternalBrowser=1) · แอปอื่น → หน้าแนะนำเปิดใน Chrome / Safari (ใช้ต่อในแอปได้)
· เบราว์เซอร์ปกติ (Chrome / Safari / Samsung Internet) ทำงานเหมือนเดิมทุกอย่าง
(ฝั่งหน้าเว็บ: เก็บรูปเป็น ArrayBuffer เมื่อเก็บ Blob ไม่ได้ · แจ้งเมื่อรูปหายเพราะหน้าถูกปิดระหว่างเปิดกล้อง — ทดสอบด้วยเบราว์เซอร์จริงแยก)"""
import pytest
from conftest import login
from ecs import inapp as IA

CHROME = "Mozilla/5.0 (Linux; Android 14; SM-A546E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
SAFARI = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1"
SAMSUNG = "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/26.0 Chrome/122.0.0.0 Mobile Safari/537.36"
LINE_A = ("Mozilla/5.0 (Linux; Android 14; SM-A546E Build/UP1A; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 "
          "Chrome/130.0.0.0 Mobile Safari/537.36 Line/14.19.1/IAB")
LINE_I = ("Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 "
          "Safari Line/14.19.0")
FB_A = ("Mozilla/5.0 (Linux; Android 14; SM-A546E Build/UP1A; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 "
        "Chrome/130.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/480.0.0.0;]")
FB_I = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBAV/480.0]"


@pytest.mark.parametrize("ua,kind", [(CHROME, None), (SAFARI, None), (SAMSUNG, None), ("", None), (None, None),
                                     (LINE_A, "line"), (LINE_I, "line"), (FB_A, "facebook"), (FB_I, "facebook"),
                                     (CHROME.replace("SM-A546E", "SM-A546E; wv"), "webview")])
def test_detect(ua, kind):
    assert IA.detect(ua) == kind


def _token(db, published_form):
    return db.execute("SELECT qr_token FROM equipment WHERE id=?", (published_form["equipment_id"],)).fetchone()[0]


def test_normal_browsers_unchanged(app, db, published_form):
    tok, fid = _token(db, published_form), published_form["form_id"]
    for ua in (CHROME, SAFARI, SAMSUNG):
        c = app.test_client()
        r = c.get(f"/e/{tok}", headers={"User-Agent": ua})
        assert r.status_code == 302 and r.headers["Location"] == f"/login?next=/e/{tok}"
        login(c, "t_tech")
        r = c.get(f"/e/{tok}", headers={"User-Agent": ua})
        assert r.headers["Location"].endswith(f"/m/fill#f={fid}&qr=1")
        r = c.get(f"/p/{fid}/afdr2m", headers={"User-Agent": ua})
        assert r.headers["Location"].endswith(f"/m/fill#f={fid}&pt=AFDR2M")


def test_line_hands_off_to_device_browser(app, db, published_form):
    tok, fid = _token(db, published_form), published_form["form_id"]
    c = app.test_client()
    for ua in (LINE_A, LINE_I):
        r = c.get(f"/e/{tok}", headers={"User-Agent": ua})
        assert r.status_code == 302 and r.headers["Location"] == f"/e/{tok}?openExternalBrowser=1"
        r = c.get(f"/p/{fid}/afdr2m", headers={"User-Agent": ua})
        assert r.status_code == 302 and r.headers["Location"] == f"/p/{fid}/afdr2m?openExternalBrowser=1"
    # LINE รุ่นที่ส่งต่อไม่ได้ → หน้าแนะนำ (ไม่วนซ้ำ)
    r = c.get(f"/e/{tok}?openExternalBrowser=1", headers={"User-Agent": LINE_A})
    page = r.get_data(as_text=True)
    assert r.status_code == 200 and "LINE" in page and "intent://localhost/e/" in page and "เปิดใน Chrome" in page


def test_other_inapp_shows_open_in_browser_page(app, db, published_form):
    tok = _token(db, published_form)
    c = app.test_client()
    a = c.get(f"/e/{tok}", headers={"User-Agent": FB_A}).get_data(as_text=True)
    assert "Facebook" in a and f"intent://localhost/e/{tok}#Intent;scheme=http;" in a and "S.browser_fallback_url=http%3A%2F%2Flocalhost%2Fe%2F" in a
    assert f'href="/e/{tok}?inapp=1"' in a and f'value="http://localhost/e/{tok}"' in a
    i = c.get(f"/e/{tok}", headers={"User-Agent": FB_I}).get_data(as_text=True)
    assert "intent://" not in i and "เปิดใน Safari" in i


def test_stay_in_app_keeps_working_after_login(app, db, published_form):
    """เลือก "ใช้ต่อในแอปนี้" → login → กลับมาเปิดแบบฟอร์มได้ (ไม่วนกลับหน้าแนะนำ)"""
    tok, fid = _token(db, published_form), published_form["form_id"]
    c = app.test_client()
    r = c.get(f"/e/{tok}?inapp=1", headers={"User-Agent": FB_A})
    assert r.status_code == 302 and r.headers["Location"] == f"/login?next=/e/{tok}?inapp%3D1"
    login(c, "t_tech")
    r = c.get(f"/e/{tok}?inapp=1", headers={"User-Agent": FB_A})
    assert r.headers["Location"].endswith(f"/m/fill#f={fid}&qr=1")
    r = c.get(f"/p/{fid}/afdr2m?inapp=1", headers={"User-Agent": FB_A})
    assert r.headers["Location"].endswith(f"/m/fill#f={fid}&pt=AFDR2M")


def test_login_next_with_query_lands_back_on_qr(app, db, published_form):
    tok, fid = _token(db, published_form), published_form["form_id"]
    c = app.test_client()
    from conftest import PASSWORD, csrf_of
    c.get(f"/login?next=/e/{tok}?inapp%3D1")
    r = c.post("/login", data={"username": "t_tech", "password": PASSWORD, "next": f"/e/{tok}?inapp=1", "csrf_token": csrf_of(c)},
               headers={"User-Agent": FB_A})
    assert r.status_code == 302 and r.headers["Location"] == f"/e/{tok}?inapp=1"
    assert c.get(r.headers["Location"], headers={"User-Agent": FB_A}).headers["Location"].endswith(f"/m/fill#f={fid}&qr=1")


def test_prefix_when_inside_cmms_portal(app, db, published_form):
    """รวมอยู่ใน UT-CMMS (/echeck) → ลิงก์ส่งต่อมี /echeck ครบ"""
    tok = _token(db, published_form)
    c = app.test_client()
    r = c.get(f"/e/{tok}", headers={"User-Agent": LINE_A}, base_url="http://plant.local/echeck")
    assert r.headers["Location"] == f"/echeck/e/{tok}?openExternalBrowser=1"
    page = c.get(f"/e/{tok}", headers={"User-Agent": FB_A}, base_url="http://plant.local/echeck").get_data(as_text=True)
    assert f"intent://plant.local/echeck/e/{tok}#Intent" in page and f'href="/echeck/e/{tok}?inapp=1"' in page


def test_fill_page_assets(app):
    c = app.test_client()
    login(c, "t_tech")
    assert c.get("/m/fill").status_code == 200
    js = c.get("/static/m/fill.js").get_data(as_text=True)
    core = c.get("/static/m/core.js").get_data(as_text=True)
    assert "inappBar" in js and "lostPhotoCheck" in js and "buf: await blobBuf" in core
