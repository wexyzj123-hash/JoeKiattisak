"""v0.99.40 Energy: SQL บันทึกทุก 15 นาที แต่หน้า "แหล่งข้อมูล SCADA" ขึ้น "อ่าน 0 แถวใหม่" — แก้ให้ดึงได้จริง + ตรวจวินิจฉัย + ดูข้อมูลดิบถึงต้นทาง

จำลอง 3 อาการจากหน้างาน (SQL บันทึกทุก 15 นาที ย้อนหลัง 20 วัน):
F2  จุดดึง (ข้อมูลถึง) เลยเวลาปัจจุบัน → ทุกรอบขอข้อมูลหลังเวลาในอนาคต → 0 แถว           → ระบบรีเซ็ตเอง
F1  ชื่อ Tag ใน SQL เปลี่ยน (PM_F1_MDB1 → F1.PM.MDB1.kWh) → Tag ที่จับคู่ไม่มีข้อมูล     → ตรวจวินิจฉัยแนะนำชื่อใหม่ + กดเปลี่ยนให้
F3  คอลัมน์เวลาเทียบเป็น UTC (แบบ DATETIMEOFFSET) → WHERE ts > ? ได้ 0 แถว               → ตรวจวินิจฉัยหาค่าชดเชย +420 + กดใช้"""
import json
import sqlite3
from datetime import datetime, time, timedelta

from conftest import login
from ecs import energy as EN
from ecs import energy_diag as ED
from ecs import energy_src as ES
from ecs import services as S

RATE = 100.0                                                    # kWh / ชม.


def _val(t, t0):
    return round(10000 + RATE * (t - t0).total_seconds() / 3600, 2)


def _sql(path, now, rename_at=None, days=20):
    """ตาราง h: tag, ts (เวลาไทย), ts_utc (UTC), value · บันทึกทุก 15 นาที"""
    t0 = datetime.combine((now - timedelta(days=days)).date(), time(0, 0))
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, ts_utc TEXT, value REAL)")
    rows, t = [], t0
    while t <= now:
        for tag in ("PM_F1_MDB1", "PM_F1_MDB2"):
            name = tag.replace("PM_F1_", "F1.PM.") + ".kWh" if rename_at and t >= rename_at else tag
            rows.append((name, t.strftime("%Y-%m-%d %H:%M:%S"), (t - timedelta(hours=7)).strftime("%Y-%m-%d %H:%M:%S"), _val(t, t0)))
        t += timedelta(minutes=15)
    con.executemany("INSERT INTO h VALUES (?,?,?,?)", rows)
    con.commit()
    con.close()
    return t0


def _src(app, db, tmp_path, query="SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", rename_at=None, now=None):
    now = now or S.now_dt()
    path = str(tmp_path / "plant.db")
    t0 = _sql(path, now, rename_at)
    sid = ES.save_source(db, {"name": "DataLog — ไฟฟ้า", "kind": "sqlite", "active": "1", "interval_min": "15",
                              "config": json.dumps({"path": path, "query": query, "backfill_days": 1})}, None)
    ms = {t: EN.save_meter(db, None, {"factory_id": app.config["F1"], "kind": "elec", "code": t[-4:], "name": t,
                                       "scada_source_id": str(sid), "scada_tag": t}, None) for t in ("PM_F1_MDB1", "PM_F1_MDB2")}
    db.commit()
    return now, t0, sid, ms


def _read_t(db, day):
    c = EN.settings(db)
    return datetime.combine(day, time(int(c["scada_hh"]), int(c["scada_mm"])))


def test_future_watermark_resets_itself(app, db, tmp_path):
    now, _t0, sid, _ms = _src(app, db, tmp_path)
    fut = now + timedelta(hours=6)
    db.execute("UPDATE en_sources SET watermark=? WHERE id=?", (S.ts(fut), sid))
    db.commit()
    assert not ES.valid_watermark(ES.get_source(db, sid), now)
    r = ES.run_source(db, sid, manual=True, now=now)
    assert r["ok"] and r["rows"] > 0 and "รีเซ็ตจุดดึงที่เลยเวลาปัจจุบัน" in r["message"]
    wm = S.parse_ts(ES.get_source(db, sid)["watermark"])
    assert wm <= now and now - wm < timedelta(minutes=30)
    r2 = ES.run_source(db, sid, manual=True, now=now + timedelta(minutes=1))      # รอบถัดไปทำงานปกติ
    assert r2["ok"] and "รีเซ็ต" not in r2["message"]


def test_future_rows_do_not_move_watermark(app, db, tmp_path):
    now, _t0, sid, _ms = _src(app, db, tmp_path)
    ES.run_source(db, sid, manual=True, now=now)
    wm0 = ES.get_source(db, sid)["watermark"]
    bad = [("PM_F1_MDB1", now + timedelta(hours=7), 99999.0)]                    # แถวเวลาอนาคต (นาฬิกา SCADA เพี้ยน)
    res = ES.ingest(db, ES.get_source(db, sid), bad, now)
    assert res["future"] == 1 and ES.get_source(db, sid)["watermark"] == wm0
    assert not db.execute("SELECT 1 FROM en_readings WHERE value=99999").fetchone()
    r = ES.run_source(db, sid, manual=True, now=now, rows_override=[("PM_F1_MDB1", S.ts(now + timedelta(hours=7)), 99999.0)])
    assert "ข้ามข้อมูลเวลาเกินปัจจุบัน 1 แถว" in r["message"]


def test_daily_reading_is_exact_even_when_regular_pull_starts_inside_window(app, db, tmp_path):
    """รอบดึงปกติเริ่ม "เมื่อวาน 08:16" (ย้อน 1 วัน) → เดิมได้ค่า 08:30 เป็นค่าอ่านเมื่อวาน — ต้องได้ค่า 08:00 จาก SQL"""
    base_now = S.now_dt()
    now = datetime.combine(base_now.date(), time(0, 0)) + (_read_t(db, base_now.date()) - datetime.combine(base_now.date(), time(0, 0))) \
        + timedelta(minutes=16)
    if now > base_now:
        now -= timedelta(days=1)
    now, t0, sid, ms = _src(app, db, tmp_path, now=now)
    ES.run_source(db, sid, manual=True, now=now)
    y = (now - timedelta(days=1)).date()
    v, at = db.execute("SELECT value, read_at FROM en_readings WHERE meter_id=? AND day=?", (ms["PM_F1_MDB1"], y.isoformat())).fetchone()
    assert at.endswith(_read_t(db, y).strftime("%H:%M:00")) and abs(v - _val(_read_t(db, y), t0)) < 1e-6


def test_tag_rename_diagnosed_and_fixed(app, db, tmp_path, client):
    now0 = S.now_dt()
    rename = now0 - timedelta(days=5)
    now, t0, sid, ms = _src(app, db, tmp_path, rename_at=rename)
    db.execute("UPDATE en_sources SET watermark=? WHERE id=?", (S.ts(rename), sid))
    db.commit()
    r = ES.run_source(db, sid, manual=True, now=now)
    assert r["ok"] and r["rows"] == 0                                              # อาการที่หน้างานเห็น
    d = ED.diagnose(db, sid, now)
    tag = next(c for c in d["checks"] if c["key"] == "tags")
    assert d["verdict"] == "fail" and tag["state"] == "fail"
    act = next(a for a in tag["actions"] if a["do"] == "remap")
    assert sorted(json.loads(act["value"])) == [["PM_F1_MDB1", "F1.PM.MDB1.kWh"], ["PM_F1_MDB2", "F1.PM.MDB2.kWh"]]
    msg = ED.apply(db, sid, "remap", act["value"], None, now)
    db.commit()
    assert "เปลี่ยนชื่อ Tag ให้มิเตอร์ 2 ตัว" in msg
    assert db.execute("SELECT scada_tag FROM en_meters WHERE id=?", (ms["PM_F1_MDB1"],)).fetchone()[0] == "F1.PM.MDB1.kWh"
    assert ED.diagnose(db, sid, now)["verdict"] in ("ok", "info")
    y = (now - timedelta(days=1)).date()                                          # ค่าอ่านเมื่อวานได้จาก Tag ชื่อใหม่ ตรงเวลาอ่าน
    v = db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (ms["PM_F1_MDB1"], y.isoformat())).fetchone()
    assert v and abs(v[0] - _val(_read_t(db, y), t0)) < 1e-6
    # หน้าเว็บ: ตรวจวินิจฉัย + ปุ่มแก้ + ข้อมูลดิบ
    login(client, "t_admin")
    page = client.get(f"/energy/sources/{sid}/diagnose").get_data(as_text=True)
    assert "ตรวจวินิจฉัยการดึงข้อมูล" in page and "F1.PM.MDB1.kWh" in page


def test_utc_compare_column_diagnosed_and_fixed(app, db, tmp_path):
    """WHERE ts_utc > ? (เทียบ UTC) แต่คืนเวลาไทย — แบบคอลัมน์ DATETIMEOFFSET → รอบดึงตามจุดดึงได้ 0 แถว ค่ารายวันขาด"""
    now, t0, sid, ms = _src(app, db, tmp_path, query="SELECT tag, ts, value FROM h WHERE ts_utc > ? ORDER BY ts")
    db.execute("UPDATE en_sources SET watermark=? WHERE id=?", (S.ts(now - timedelta(minutes=20)), sid))
    db.commit()
    assert ES.run_source(db, sid, manual=True, now=now)["rows"] == 0
    d = ED.diagnose(db, sid, now)
    pc = next(c for c in d["checks"] if c["key"] == "param")
    assert pc["state"] == "fail" and pc["actions"][0]["do"] == "set_pshift" and int(pc["actions"][0]["value"]) == 420
    ED.apply(db, sid, "set_pshift", 420, None, now)
    db.commit()
    src = ES.get_source(db, sid)
    assert src["config"]["param_shift_min"] == 420 and ES.param_shift(src) == timedelta(minutes=420)
    assert next(c for c in ED.diagnose(db, sid, now)["checks"] if c["key"] == "param")["state"] == "ok"
    for k in range(3):
        ES.run_source(db, sid, manual=True, now=now + timedelta(seconds=k))
        db.execute("UPDATE en_sources SET last_heal_at=NULL WHERE id=?", (sid,))
    y = (now - timedelta(days=1)).date()
    v = db.execute("SELECT value, read_at FROM en_readings WHERE meter_id=? AND day=?", (ms["PM_F1_MDB2"], y.isoformat())).fetchone()
    assert v and abs(v[0] - _val(_read_t(db, y), t0)) < 1e-6
    # ตั้งจากหน้าตั้งค่าได้ และคงค่าเดิมเมื่อฟอร์มไม่ส่งมา
    ES.save_source(db, {"name": src["name"], "kind": "sqlite", "config": src["config_json"], "param_shift_min": ""}, None, sid)
    assert ES.get_source(db, sid)["config"]["param_shift_min"] == 420


def test_stale_table_and_bad_query_explained(app, db, tmp_path):
    now = S.now_dt()
    path = str(tmp_path / "old.db")
    _sql(path, now - timedelta(days=80), days=3)                                   # DataLog หยุดเขียนตารางนี้ไปแล้ว
    sid = ES.save_source(db, {"name": "เก่า", "kind": "sqlite", "active": "1", "config": json.dumps(
        {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 1})}, None)
    d = ED.diagnose(db, sid, now)
    assert d["verdict"] == "fail" and "หลังจากนั้นไม่มีข้อมูลเลย" in d["headline"]
    sid2 = ES.save_source(db, {"name": "ผิด", "kind": "sqlite", "active": "1", "config": json.dumps(
        {"path": path, "query": "SELECT tag, ts, value FROM nope WHERE ts > ? ORDER BY ts", "backfill_days": 1})}, None)
    d2 = ED.diagnose(db, sid2, now)
    assert d2["verdict"] == "fail" and d2["checks"][0]["key"] == "conn"


def test_raw_viewer_shows_source_rows_and_used_reading(app, db, tmp_path, client):
    now, _t0, sid, _ms = _src(app, db, tmp_path)
    for k in range(3):
        ES.run_source(db, sid, manual=True, now=now + timedelta(seconds=k))
        db.execute("UPDATE en_sources SET last_heal_at=NULL WHERE id=?", (sid,))
    db.commit()
    y = (now - timedelta(days=1)).date()
    res = ED.raw(db, sid, "PM_F1_MDB1", y, y, now)
    assert len(res["rows"]) == 96                                                  # ทุก 15 นาที = 96 แถว/วัน
    used = [r for r in res["rows"] if r["used"]]
    assert len(used) == 1 and used[0]["ts"] == _read_t(db, y)
    login(client, "t_admin")
    html = client.get(f"/energy/sources/{sid}/raw?tag=PM_F1_MDB1&from={y}&to={y}").get_data(as_text=True)
    assert "ใช้เป็นค่าอ่านรายวัน" in html and "raw-used" in html
    csv = client.get(f"/energy/sources/{sid}/raw?tag=PM_F1_MDB1&from={y}&to={y}&format=csv")
    assert csv.status_code == 200 and csv.get_data(as_text=True).count("\n") == 97
    assert client.get(f"/energy/sources/{sid}/raw").status_code == 200              # ยังไม่เลือก Tag
    lst = client.get("/energy/sources").get_data(as_text=True)
    assert f"/energy/sources/{sid}/diagnose" in lst and f"/energy/sources/{sid}#runs" in lst
    det = client.get(f"/energy/sources/{sid}").get_data(as_text=True)
    assert f"/energy/sources/{sid}/raw?tag=PM_F1_MDB1" in det and 'name="param_shift_min"' in det


def test_sources_list_flags_problem_sources(app, db, tmp_path, client):
    now, _t0, sid, _ms = _src(app, db, tmp_path)
    db.execute("UPDATE en_sources SET watermark=? WHERE id=?", (S.ts(now + timedelta(hours=6)), sid))
    db.commit()
    login(client, "t_admin")
    html = client.get("/energy/sources").get_data(as_text=True)
    assert "เลยเวลาปัจจุบัน" in html and "แหล่งข้อมูลที่ดึงข้อมูลไม่ได้" in html
    r = client.post(f"/energy/sources/{sid}/diagnose/fix", data={"do": "reset_wm", "value": "0",
                                                                   "csrf_token": __import__("conftest").csrf_of(client)})
    assert r.status_code == 302
    assert S.parse_ts(ES.get_source(db, sid)["watermark"]) <= S.now_dt() + timedelta(minutes=1)
