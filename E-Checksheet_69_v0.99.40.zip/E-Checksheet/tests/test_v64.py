"""v0.64: จดมิเตอร์หน้างาน (มือถือ/ออฟไลน์/QR/รูป/อ่านไม่ได้/เปลี่ยนมิเตอร์/SCADA) + หมวดหมู่ตั้งเองได้ + ช่างแก้/เพิ่มมิเตอร์ได้"""
import io
import json
import sqlite3
from datetime import date, datetime, timedelta

import pytest
from conftest import login, uid

from ecs import energy as EN
from ecs import energy_field as EF
from ecs import energy_ops as OPS
from ecs import services as S

TODAY = date.today()


def _mk(db, fid, code, grp="LINE", kind="elec", mult="1", is_main="0"):
    return EN.save_meter(db, None, {"factory_id": fid, "kind": kind, "code": code, "name": f"M {code}", "grp": grp,
                                    "multiplier": mult, "is_main": is_main}, None)


def _feed(db, mid, start=1000.0, per=100.0, days=20, upto=1):
    v = start
    for i in range(days, upto - 1, -1):
        EN.set_reading(db, mid, (TODAY - timedelta(days=i)).isoformat(), v, None, src="t")
        v += per
    return v - per


def _jpg():
    from PIL import Image
    b = io.BytesIO()
    Image.new("RGB", (64, 48), (200, 200, 200)).save(b, "JPEG")
    return b.getvalue()


class _FS:
    def __init__(self, data):
        self.data = data
        self.filename = "p.jpg"

    def read(self, n=-1):
        return self.data


def test_expect_and_check(app, db):
    mid = _mk(db, app.config["F1"], "E1")
    last = _feed(db, mid, start=99000, per=100)            # 99000 … 100900 → 5 → 6 หลัก
    db.execute("UPDATE en_meters SET digits=6 WHERE id=?", (mid,))
    m = EN.meter(db, mid)
    ex = EF.expect(db, m, TODAY)
    assert ex["prev"] == last and ex["typ"] == 100 and ex["hi"] > last + 100 and ex["digits"] == 6
    assert EF.check(ex, last + 100)["level"] == "ok"
    assert EF.check(ex, last + 100)["u"] == 100
    c = EF.check(ex, last + 5000)
    assert c["level"] == "warn" and "สูงกว่าปกติ" in c["msgs"][0]
    c = EF.check(ex, (last + 100) / 10)                     # ตกหลัก
    assert c["level"] == "bad" and any("จำนวนหลัก" in x for x in c["msgs"])
    # มิเตอร์ 6 หลักวนรอบ 999,950 → 50
    db.execute("UPDATE en_readings SET value=999950 WHERE meter_id=? AND day=?", (mid, ex["prev_day"]))
    ex2 = EF.expect(db, m, TODAY)
    c = EF.check(ex2, 50)
    assert c["level"] == "bad" and c["rollover"] == 100


def test_submit_read_rules(app, db, tmp_path):
    f1 = app.config["F1"]
    mid = _mk(db, f1, "R1")
    last = _feed(db, mid)
    tech = uid(db, "t_tech")
    up = str(tmp_path / "up")
    base = {"meter_id": mid, "day": TODAY.isoformat(), "from": "m"}
    r = EF.submit(db, {**base, "client_uuid": "u1", "value": last + 100, "read_at": S.ts()}, {}, tech, up)
    assert r["level"] == "ok" and r["u"] == 100
    assert EF.submit(db, {**base, "client_uuid": "u1", "value": last + 100}, {}, tech, up)["duplicate"]     # คิวส่งซ้ำ → ไม่บันทึกซ้ำ
    row = db.execute("SELECT src, read_at FROM en_readings WHERE meter_id=? AND day=?", (mid, TODAY.isoformat())).fetchone()
    assert row["src"] == "mobile" and row["read_at"]
    # แก้ค่าเดิมต้องมีเหตุผล
    with pytest.raises(S.ValidationError):
        EF.submit(db, {**base, "value": last + 120}, {}, tech, up)
    EF.submit(db, {**base, "value": last + 120, "note": "อ่านผิด"}, {}, tech, up)
    assert OPS.fix_log(db, mid)[0]["reason"] == "อ่านผิด"
    # ค่าผิดปกติ: ไม่ยืนยัน → ไม่ผ่าน · ยืนยันแต่ไม่มีรูป → ไม่ผ่าน (photo_rule 1) · มีรูป → ผ่าน
    mid2 = _mk(db, f1, "R2")
    last2 = _feed(db, mid2)
    b2 = {"meter_id": mid2, "day": TODAY.isoformat()}
    with pytest.raises(S.ValidationError) as e:
        EF.submit(db, {**b2, "value": last2 + 9000}, {}, tech, up)
    assert "ค่าผิดปกติ" in e.value.errors[0]
    with pytest.raises(S.ValidationError) as e:
        EF.submit(db, {**b2, "value": last2 + 9000, "confirm": True, "note": "เดินเครื่องเพิ่ม"}, {}, tech, up)
    assert "รูป" in e.value.errors[0]
    r = EF.submit(db, {**b2, "value": last2 + 9000, "confirm": True, "note": "เดินเครื่องเพิ่ม", "photo": "p1"}, {"p1": _FS(_jpg())}, tech, up)
    assert r["level"] == "warn" and r["photo"].startswith("energy/")
    # ล่วงหน้าไม่ได้ · ต่างโรงงานไม่ได้
    with pytest.raises(S.ValidationError):
        EF.submit(db, {**base, "day": (TODAY + timedelta(days=1)).isoformat(), "value": 1}, {}, tech, up)
    mid3 = _mk(db, app.config["F2"], "X2")
    with pytest.raises(S.ValidationError):
        EF.submit(db, {"meter_id": mid3, "day": TODAY.isoformat(), "value": 5}, {}, tech, up)
    # ช่างแก้ย้อนหลังเกินกำหนด → ไม่ได้ · หัวหน้างานได้
    EN.save_settings(db, {"tech_back_days": "3"}, None)
    old_day = (TODAY - timedelta(days=10)).isoformat()
    with pytest.raises(S.ValidationError):
        EF.submit(db, {"meter_id": mid, "day": old_day, "value": 1, "note": "x", "confirm": True}, {}, tech, up)
    assert EF.back_limit_ok(db, uid(db, "t_sup"), old_day, EN.settings(db))
    db.commit()


def test_rollover_skip_swap(app, db, tmp_path):
    f1 = app.config["F1"]
    up = str(tmp_path / "up")
    tech = uid(db, "t_tech")
    # วนรอบ
    mid = _mk(db, f1, "RO")
    _feed(db, mid, start=999300, per=50, days=12, upto=1)
    db.execute("UPDATE en_meters SET digits=6 WHERE id=?", (mid,))
    prev = db.execute("SELECT value FROM en_readings WHERE meter_id=? ORDER BY day DESC LIMIT 1", (mid,)).fetchone()[0]
    newv = prev + 200 - 1_000_000
    r = EF.submit(db, {"meter_id": mid, "day": TODAY.isoformat(), "value": newv, "rollover": True, "photo": "p"},
                  {"p": _FS(_jpg())}, tech, up)
    assert r["u"] == 200
    s = EN.series(db, [EN.meter(db, mid)], TODAY, TODAY)[mid][TODAY.isoformat()]
    assert s["u"] == 200 and s["flag"] == "fix"
    # อ่านไม่ได้ → เคส + ไม่ขึ้นในรายการยังไม่จด
    m2 = _mk(db, f1, "SK")
    _feed(db, m2, days=5, upto=2)
    r = EF.submit(db, {"meter_id": m2, "day": TODAY.isoformat(), "type": "skip", "reason": "broken", "note": "จอดับ"}, {}, tech, up)
    assert r["case_id"] and OPS.case(db, r["case_id"])["rule"] == "fault"
    d = EN.dashboard(db, TODAY.replace(day=1), f1, "elec", today=TODAY)
    assert m2 not in [x["id"] for x in d["missing"]]
    with pytest.raises(S.ValidationError):
        EF.submit(db, {"meter_id": m2, "day": TODAY.isoformat(), "type": "skip", "reason": "nope"}, {}, tech, up)
    # เปลี่ยนมิเตอร์: เก่าสุดท้าย prev+30 · ใหม่เริ่ม 0 ตอนนี้ 12 · CT ใหม่ 2
    m3 = _mk(db, f1, "SW")
    last = _feed(db, m3, days=6, upto=1)
    with pytest.raises(S.ValidationError):        # ต้องมีรูป
        EF.submit(db, {"meter_id": m3, "day": TODAY.isoformat(), "type": "swap", "note": "จอเสีย",
                       "swap": {"old_final": last + 30, "new_start": 0, "new_value": 12, "new_mult": 2}}, {}, tech, up)
    r = EF.submit(db, {"meter_id": m3, "day": TODAY.isoformat(), "type": "swap", "note": "จอเสีย", "photo": "p",
                       "swap": {"old_final": last + 30, "new_start": 0, "new_value": 12, "new_mult": 2}}, {"p": _FS(_jpg())}, tech, up)
    assert r["u"] == 30 + 24
    assert EN.meter(db, m3)["multiplier"] == 2
    assert EN.series(db, [EN.meter(db, m3)], TODAY, TODAY)[m3][TODAY.isoformat()]["u"] == 54
    EN.set_reading(db, m3, (TODAY + timedelta(days=0)).isoformat(), 12, None)        # วันถัดไปคิดจากเลขใหม่ × CT ใหม่
    assert db.execute("SELECT COUNT(*) FROM en_swaps WHERE meter_id=?", (m3,)).fetchone()[0] == 1
    db.commit()


def test_scada_auto_reading(app, db, tmp_path):
    f1 = app.config["F1"]
    src_db = tmp_path / "scada.db"
    con = sqlite3.connect(src_db)
    con.execute("CREATE TABLE t (tag TEXT, ts TEXT, v REAL)")
    base = datetime.combine(TODAY - timedelta(days=2), datetime.min.time())
    for d in range(3):
        for h in (6, 7, 8, 9, 12):
            dt = base + timedelta(days=d, hours=h, minutes=5)
            con.execute("INSERT INTO t VALUES (?,?,?)", ("30_MH9120", dt.strftime("%Y-%m-%d %H:%M:%S"), 5000 + d * 1000 + h))
    con.commit()
    con.close()
    from ecs import energy_src as C
    sid = C.save_source(db, {"name": "SCADA test", "kind": "sqlite", "interval_min": "15", "active": "1",
                             "config": json.dumps({"path": str(src_db), "query": "SELECT tag, ts, v AS value FROM t WHERE ts > ?", "backfill_days": 5})},
                        uid(db, "t_admin"))
    mid = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "S1", "name": "SCADA meter", "scada_source_id": str(sid),
                                   "scada_tag": "30_MH9120"}, None)
    assert C.run_source(db, sid, manual=True)["ok"]
    rows = db.execute("SELECT day, value, src, read_at FROM en_readings WHERE meter_id=? ORDER BY day", (mid,)).fetchall()
    assert len(rows) == 3 and all(r["src"] == "scada" for r in rows)
    assert rows[0]["value"] == 5008 and rows[0]["read_at"].endswith("08:05:00")
    # ค่าที่ช่างแก้ไว้ไม่ถูกทับ
    OPS.correct(db, mid, rows[1]["day"], "6100", "", "SCADA ค่าผิด", None)
    n = EF.scada_ingest(db, C.get_source(db, sid), [("30_MH9120", datetime.fromisoformat(rows[1]["day"] + " 08:00:00"), 1.0)])
    assert n == 0 and db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (mid, rows[1]["day"])).fetchone()[0] == 6100
    # ดึงย้อนหลังรายมิเตอร์
    db.execute("DELETE FROM en_readings WHERE meter_id=? AND src='scada'", (mid,))
    cs = EN.settings(db)                                  # v0.99.40 วันนี้นับเมื่อเลยเวลาอ่าน + ช่วงที่ยอมให้แล้ว (ก่อนนั้นยังไม่ถึงกำหนด)
    due_today = __import__('ecs.services', fromlist=['x']).now_dt() >= datetime.combine(TODAY, datetime.min.time()).replace(hour=int(cs["scada_hh"]), minute=int(cs["scada_mm"])) \
        + timedelta(minutes=int(cs["scada_window"]))
    assert EF.scada_backfill(db, mid, 7)["days"] == (2 if due_today else 1)
    pk = EF.pack(db, uid(db, "t_admin"), f1)
    assert next(x for x in pk["meters"] if x["id"] == mid)["auto"] is True
    db.commit()


def test_categories_and_tech_meter_admin(app, client, db):
    f1, f2 = app.config["F1"], app.config["F2"]
    k = EN.save_kind(db, {"th": "ไอน้ำ", "unit": "ตัน", "icon": "♨️", "color": "#ef4444", "price": "850", "ef": "180", "key": "steam"}, None)
    assert k == "steam" and EN.KINDS["steam"]["unit"] == "ตัน" and "steam" in EN.KIND_ORDER
    mid = _mk(db, f1, "ST1", grp="Boiler", kind="steam")
    _feed(db, mid, per=2, days=5)
    d = EN.dashboard(db, TODAY.replace(day=1), f1, "steam", today=TODAY)
    ks = d["kinds"][0]
    assert ks["kind"] == "steam" and ks["cost"] == round(ks["total"] * 850) and ks["co2"] == round(ks["total"] * 180 / 1000, 2)
    with pytest.raises(S.ValidationError):
        EN.delete_kind(db, "steam", None)                 # ยังมีมิเตอร์
    with pytest.raises(S.ValidationError):
        EN.delete_kind(db, "elec", None)
    assert EN.rename_section(db, f1, "steam", "Boiler", "Boiler House", None) == 1
    with pytest.raises(S.ValidationError):
        EN.rename_section(db, f2, "steam", "x", "y", None, scope_factory=f1)
    db.commit()
    # ช่างเพิ่ม/แก้มิเตอร์ + หมวดหมู่ได้เอง (เฉพาะโรงงานตัวเอง)
    tok = login(client, "t_tech")
    P = lambda url, data: client.post(url, data={**data, "csrf_token": tok})
    assert client.get("/energy/categories").status_code == 200
    r = P("/energy/categories", {"act": "kind", "th": "ก๊าซ LPG", "unit": "kg", "icon": "🔥", "color": "#f97316", "active_present": "1", "active": "1"})
    assert r.status_code == 302 and any(v["th"] == "ก๊าซ LPG" for v in EN.kinds_admin(db))
    lpg = next(v["key"] for v in EN.kinds_admin(db) if v["th"] == "ก๊าซ LPG")
    r = P("/energy/meters/new", {"factory_id": str(f2), "kind": lpg, "code": "G1", "name": "LPG Canteen", "grp": "Canteen", "multiplier": "1"})
    assert r.status_code == 302
    g = db.execute("SELECT * FROM en_meters WHERE code='G1'").fetchone()
    assert g["factory_id"] == f1 and g["kind"] == lpg                     # บังคับเป็นโรงงานของช่าง
    r = P(f"/energy/meters/{g['id']}", {"kind": "steam", "code": "G1", "name": "LPG→Steam", "grp": "Canteen", "multiplier": "1",
                                       "active_present": "1", "active": "1", "is_main": "0"})
    assert r.status_code == 302 and EN.meter(db, g["id"])["kind"] == "steam"
    assert P(f"/energy/meters/{g['id']}", {"act": "delete"}).status_code == 302 and not EN.meter(db, g["id"])
    m_f2 = _mk(db, f2, "F2M")
    db.commit()
    assert P(f"/energy/meters/{m_f2}", {"code": "hack", "name": "x"}).status_code == 403
    r = P("/energy/categories", {"act": "kind_del", "key": lpg})
    assert r.status_code == 302 and lpg not in EN.KINDS


def test_mobile_pages_and_api(app, client, db):
    f1 = app.config["F1"]
    mid = _mk(db, f1, "MB")
    last = _feed(db, mid)
    db.commit()
    tok = login(client, "t_tech")
    r = client.get("/m/energy")
    assert r.status_code == 200 and b"energy.js" in r.data and b"ocr.js" in r.data
    pk = client.get("/api/m/energy/pack").get_json()
    me = next(x for x in pk["meters"] if x["id"] == mid)
    assert me["tok"] and me["ex"]["prev"] == last and pk["reasons"]["broken"] and pk["cfg"]["photo_rule"] == 1
    assert all(x["factory_id"] == f1 for x in pk["meters"])
    r = client.get(f"/q/{me['tok']}")
    assert r.status_code == 302 and r.headers["Location"].endswith(f"/m/energy#m={mid}")
    assert client.get("/q/nope").status_code == 404
    payload = {"client_uuid": "abc", "meter_id": mid, "day": TODAY.isoformat(), "value": last + 100, "photo": "p1", "box": [0.1, 0.3, 0.8, 0.3]}
    r = client.post("/api/m/energy/submit", data={"payload": json.dumps(payload), "p1": (io.BytesIO(_jpg()), "p1.jpg")},
                    headers={"X-CSRF-Token": tok}, content_type="multipart/form-data")
    assert r.status_code == 200 and r.get_json()["u"] == 100
    assert json.loads(EN.meter(db, mid)["ocr_box"]) == [0.1, 0.3, 0.8, 0.3]
    r = client.post("/api/m/energy/submit", data={"payload": json.dumps({**payload, "client_uuid": "abd", "value": 1})},
                    headers={"X-CSRF-Token": tok}, content_type="multipart/form-data")
    assert r.status_code == 422 and r.get_json()["error"]
    r = client.get(f"/energy/meters/qr?ids={mid}")
    assert r.status_code == 200 and me["tok"].encode() in r.data and b"<svg" in r.data
    # หน้าตารางกรอก: แก้ค่าเดิมต้องมีเหตุผล
    r = client.post(f"/energy/entry?factory={f1}&kind=elec", json={"day": TODAY.isoformat(), "values": {str(mid): str(last + 150)}},
                    headers={"X-CSRF-Token": tok})
    assert r.status_code == 422 and r.get_json()["need_reason"]
    r = client.post(f"/energy/entry?factory={f1}&kind=elec", json={"day": TODAY.isoformat(), "values": {str(mid): str(last + 150)},
                                                                   "reason": "พิมพ์ผิด"}, headers={"X-CSRF-Token": tok})
    assert r.status_code == 200 and OPS.fix_log(db, mid)[0]["reason"] == "พิมพ์ผิด"
    assert client.get(f"/energy/meters/{mid}").status_code == 200
    assert client.get("/m/").status_code == 200 and "จดมิเตอร์".encode() in client.get("/m/").data


def test_cmms_wo_for_broken_meter(app, db, tmp_path):
    path = tmp_path / "cmms.db"
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, name TEXT, role TEXT);
    CREATE TABLE equipment (id INTEGER PRIMARY KEY, code TEXT, name TEXT, location TEXT DEFAULT '', factory TEXT DEFAULT '');
    CREATE TABLE work_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, wo_number TEXT UNIQUE NOT NULL, equipment_id INTEGER,
      title TEXT, description TEXT, priority TEXT, status TEXT DEFAULT 'pending', requested_by INTEGER, assignee_id INTEGER,
      created_at TEXT, completed_at TEXT, due_date TEXT, root_cause TEXT DEFAULT '', action_taken TEXT DEFAULT '',
      notes TEXT DEFAULT '', updated_at TEXT, department TEXT, repair_type TEXT, repair_category TEXT, line_no TEXT,
      mc_no TEXT, data_entry_by TEXT, reporter_name TEXT, factory TEXT, work_window TEXT, repaired_by TEXT DEFAULT '');
    CREATE TABLE activity_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT, target_type TEXT, target_id INTEGER, details TEXT);
    INSERT INTO users VALUES (1,'admin','Admin','admin');
    INSERT INTO equipment VALUES (88,'MDB-1','Main panel','Sub station','AISIN1');
    """)
    con.commit()
    con.close()
    app.config["CMMS_DATABASE"] = str(path)
    try:
        from ecs import masterdata as M
        eq = M.save_equipment(db, {"code": "MDB-1", "name": "Main panel", "factory_id": app.config["F1"]}, uid(db, "t_admin"))
        db.execute("UPDATE equipment SET legacy_id=88 WHERE id=?", (eq,))
        mid = EN.save_meter(db, None, {"factory_id": app.config["F1"], "kind": "elec", "code": "W1", "name": "Panel meter",
                                       "equipment_id": str(eq)}, None)
        r = EF.submit(db, {"meter_id": mid, "day": TODAY.isoformat(), "type": "skip", "reason": "broken", "wo": True, "note": "จอดับ"},
                      {}, uid(db, "t_tech"), str(tmp_path / "up"), app.config)
        assert r["wo_number"].startswith("WO-")
        c = sqlite3.connect(path)
        wo = c.execute("SELECT equipment_id, title, data_entry_by FROM work_orders").fetchone()
        assert wo[0] == 88 and "มิเตอร์เสีย" in wo[1] and wo[2] == "Energy Data"
        assert db.execute("SELECT wo_number FROM en_skips WHERE meter_id=?", (mid,)).fetchone()[0] == r["wo_number"]
    finally:
        app.config.pop("CMMS_DATABASE", None)
