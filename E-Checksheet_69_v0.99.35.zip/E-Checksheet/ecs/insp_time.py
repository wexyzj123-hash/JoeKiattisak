"""v0.99.32 เวลาตรวจเช็ค — สรุปเวลาที่ใช้ตรวจ รวมทุกโรงงาน → โรงงาน → พื้นที่ → เครื่อง → รายการตรวจ

เวลาตรวจ = duration_sec ของผลตรวจ (เปิดฟอร์ม/สแกน QR → กดส่ง บนเครื่องของช่าง)
นับเฉพาะเวลาที่ "เชื่อถือได้" — กติกาเดียวกับส่วนอื่นของระบบ (fieldinfo · ผลงานรายคน):
  · 10 วินาที – 2 ชั่วโมง (สั้นกว่า = กดผ่าน · ยาวกว่า = เปิดค้าง) → นับแยกเป็น "เวลาผิดปกติ" ให้เห็น
  · ไม่นับผลที่ลงจาก SCADA อัตโนมัติ (source='auto') — ไม่มีเวลาคน
  · ไม่นับผลที่ถูกส่งแทนแล้ว (superseded)
พื้นที่ของผลตรวจ = พื้นที่ของเครื่อง (ถ้าผูกเครื่อง) ไม่งั้นพื้นที่ของแบบฟอร์ม"""
from __future__ import annotations

import io
from datetime import date, timedelta
from statistics import median

MIN_SEC, MAX_SEC = 10, 7200


def _bounds(d_from: date, d_to: date) -> tuple[str, str]:
    return f"{d_from.isoformat()} 00:00:00", f"{(d_to + timedelta(days=1)).isoformat()} 00:00:00"


def _rows(db, d_from: date, d_to: date, factory_ids: list[int] | None = None, area_id: int | None = None,
          equipment_id: int | None = None, form_id: int | None = None) -> list[dict]:
    """ผลตรวจทุกใบในช่วง (รวมใบที่เวลาใช้ไม่ได้ — ติดป้าย ok=False) พร้อมโรงงาน/พื้นที่/เครื่อง/ผู้ตรวจ"""
    a, b = _bounds(d_from, d_to)
    where, p = ["s.status<>'superseded'", "s.finished_at >= ?", "s.finished_at < ?"], [a, b]
    if factory_ids:
        where.append(f"f.factory_id IN ({','.join('?' * len(factory_ids))})")
        p += list(factory_ids)
    if area_id:
        where.append("COALESCE(e.area_id, f.area_id)=?")
        p.append(area_id)
    if equipment_id:
        where.append("f.equipment_id=?")
        p.append(equipment_id)
    if form_id:
        where.append("s.form_id=?")
        p.append(form_id)
    rows = db.execute(f"""
        SELECT s.id, s.form_id, s.finished_at, s.scanned_at, s.duration_sec, s.inspector_id, s.ng_count, s.source,
               u.name AS inspector, f.name AS form_name, f.code AS form_code, f.equipment_id,
               e.code AS eq_code, e.name AS eq_name,
               fa.id AS factory_id, fa.name AS factory_name, fa.sort_no AS factory_sort,
               ar.id AS area_id, ar.name AS area_name
        FROM cs_submissions s
        JOIN cs_forms f ON f.id=s.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN areas ar ON ar.id=COALESCE(e.area_id, f.area_id)
        LEFT JOIN users u ON u.id=s.inspector_id
        WHERE {' AND '.join(where)}
        ORDER BY s.finished_at""", p).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["auto"] = (d.get("source") or "") == "auto"
        sec = d.get("duration_sec")
        d["ok"] = (not d["auto"]) and sec is not None and MIN_SEC <= sec <= MAX_SEC
        out.append(d)
    return out


def _agg(rows: list[dict]) -> dict:
    """สรุปกลุ่ม: เวลารวม · จำนวน · เฉลี่ย · มัธยฐาน · ยาวสุด (เฉพาะเวลาที่ใช้ได้) + จำนวนที่ไม่นับ"""
    secs = [r["duration_sec"] for r in rows if r["ok"]]
    tot = sum(secs)
    return {"sec": tot, "n": len(secs), "avg": round(tot / len(secs)) if secs else None,
            "med": round(median(secs)) if secs else None, "max": max(secs) if secs else None,
            "bad": sum(1 for r in rows if not r["ok"] and not r["auto"]), "auto": sum(1 for r in rows if r["auto"]),
            "ng": sum(r["ng_count"] or 0 for r in rows if not r["auto"])}


def _group(rows: list[dict], key, label, extra=None) -> list[dict]:
    g: dict = {}
    for r in rows:
        g.setdefault(key(r), []).append(r)
    out = []
    for k, rs in g.items():
        x = {"key": k, "label": label(rs[0]), **_agg(rs)}
        if extra:
            x.update(extra(rs[0]))
        out.append(x)
    total = sum(x["sec"] for x in out) or 0
    for x in out:
        x["share"] = round(100.0 * x["sec"] / total, 1) if total else 0
    return sorted(out, key=lambda x: (-x["sec"], str(x["label"])))


def _head(db, rows: list[dict], d_from: date, d_to: date) -> dict:
    """ตัวเลขหัวสรุป: _agg + เฉลี่ยต่อวัน · จำนวนผู้ตรวจ/ใบตรวจ · แยกกะกลางวัน/กลางคืน"""
    from .itemfreq import get_calendar
    from .sign_blocks import shift_of
    head = _agg(rows)
    days = (d_to - d_from).days + 1
    head["per_day"] = round(head["sec"] / days) if days else 0
    head["inspectors"] = len({r["inspector_id"] for r in rows if r["ok"] and r["inspector_id"]})
    head["machines"] = len({r["form_id"] for r in rows if r["ok"]})
    cal = get_calendar(db)
    sh = {"day": 0, "night": 0}
    for r in rows:
        if r["ok"] and r["finished_at"]:
            m = int(r["finished_at"][11:13]) * 60 + int(r["finished_at"][14:16])
            sh[shift_of(m, cal)] += r["duration_sec"]
    head["shift_day"], head["shift_night"] = sh["day"], sh["night"]
    return head


def summary(db, d_from: date, d_to: date, factory_ids: list[int] | None = None, factory_id: int | None = None,
            area_id: int | None = None, equipment_id: int | None = None, form_id: int | None = None,
            people_fids: list[int] | None | bool = False) -> dict:
    """ภาพรวม + ระดับถัดไป (โรงงาน → พื้นที่ → เครื่อง → รายการ) ตามตัวกรองที่เลือก
    factory_ids = โรงงานที่ผู้ใช้เห็นได้ (None = ทั้งหมด) · people_fids: False = ไม่แสดงรายคน · None = ทุกคน · [ids] = เฉพาะโรงงานนั้น"""
    fids = [factory_id] if factory_id else factory_ids
    if factory_id and factory_ids is not None and factory_id not in factory_ids:
        fids = [-1]                                                           # เลือกโรงงานที่ไม่มีสิทธิ์ → ว่าง
    rows = _rows(db, d_from, d_to, fids, area_id, equipment_id, form_id)
    head = _head(db, rows, d_from, d_to)
    days = (d_to - d_from).days + 1
    # ระดับถัดไป
    if form_id or equipment_id:
        level = "items"
        children = []
    elif area_id:
        level = "machine"
        children = _group(rows, lambda r: r["form_id"], lambda r: (r["eq_code"] + " · " if r["eq_code"] else "") + (r["form_name"] or ""),
                          lambda r: {"form_id": r["form_id"], "equipment_id": r["equipment_id"], "eq_code": r["eq_code"]})
    elif factory_id:
        level = "area"
        children = _group(rows, lambda r: r["area_id"] or 0, lambda r: r["area_name"] or "ไม่ระบุพื้นที่",
                          lambda r: {"area_id": r["area_id"]})
    else:
        level = "factory"
        children = _group(rows, lambda r: r["factory_id"] or 0, lambda r: r["factory_name"] or "ไม่ระบุโรงงาน",
                          lambda r: {"factory_id": r["factory_id"], "sort": r["factory_sort"] or 0})
        # ทุกโรงงาน: แตกพื้นที่ย่อยไว้ด้วย (ดูภาพรวมได้ในหน้าเดียว)
        for c in children:
            c["areas"] = _group([r for r in rows if (r["factory_id"] or 0) == c["key"]], lambda r: r["area_id"] or 0,
                                lambda r: r["area_name"] or "ไม่ระบุพื้นที่", lambda r: {"area_id": r["area_id"]})
    # รายวัน (แยกตามระดับถัดไป สูงสุด 6 กลุ่ม + อื่น ๆ) — สำหรับกราฟแท่งซ้อน
    labels = [(d_from + timedelta(days=i)).isoformat() for i in range(days)]
    top = children[:6] if level != "items" else []
    keyf = {"factory": lambda r: r["factory_id"] or 0, "area": lambda r: r["area_id"] or 0,
            "machine": lambda r: r["form_id"]}.get(level)
    series = []
    for c in top:
        v = dict.fromkeys(labels, 0)
        for r in rows:
            if r["ok"] and keyf(r) == c["key"]:
                v[r["finished_at"][:10]] = v.get(r["finished_at"][:10], 0) + r["duration_sec"]
        series.append({"name": c["label"], "data": [round(v[d] / 60, 1) for d in labels]})
    if level == "items" or len(children) > 6:
        keys = {c["key"] for c in top}
        v = dict.fromkeys(labels, 0)
        for r in rows:
            if r["ok"] and (keyf is None or keyf(r) not in keys):
                v[r["finished_at"][:10]] = v.get(r["finished_at"][:10], 0) + r["duration_sec"]
        series.append({"name": "รวม" if level == "items" else "อื่น ๆ", "data": [round(v[d] / 60, 1) for d in labels]})
    people = None
    if people_fids is not False:
        pr = [r for r in rows if people_fids is None or r["factory_id"] in people_fids]
        people = [p for p in _group([r for r in pr if r["inspector_id"]], lambda r: r["inspector_id"], lambda r: r["inspector"] or "–",
                                    lambda r: {"uid": r["inspector_id"]}) if p["n"]]
    ok_rows = [r for r in rows if r["ok"]]
    slow = sorted(ok_rows, key=lambda r: -r["duration_sec"])[:10]
    subs = sorted(rows, key=lambda r: r["finished_at"] or "", reverse=True)[:200] if level == "items" else []
    return {"head": head, "level": level, "children": children, "labels": labels, "series": series,
            "people": people, "slow": slow, "subs": subs, "days": days}


def report(db, d_from: date, d_to: date, factory_ids: list[int] | None = None, factory_id: int | None = None,
           area_id: int | None = None, form_id: int | None = None) -> dict:
    """v0.99.34 รายงานสรุปเวลาตรวจ (เอกสาร A4): หัวสรุป · รายโรงงาน · รายพื้นที่ · รายเครื่อง/ใบตรวจ · รายวัน · นานสุด 10 ใบ"""
    fids = [factory_id] if factory_id else factory_ids
    if factory_id and factory_ids is not None and factory_id not in factory_ids:
        fids = [-1]
    rows = _rows(db, d_from, d_to, fids, area_id, None, form_id)
    head = _head(db, rows, d_from, d_to)
    facs = _group(rows, lambda r: r["factory_id"] or 0, lambda r: r["factory_name"] or "ไม่ระบุโรงงาน", lambda r: {"factory_id": r["factory_id"]})
    areas = _group(rows, lambda r: (r["factory_id"] or 0, r["area_id"] or 0), lambda r: r["area_name"] or "ไม่ระบุพื้นที่",
                   lambda r: {"factory": r["factory_name"] or "–", "factory_id": r["factory_id"], "area_id": r["area_id"]})
    machines = _group(rows, lambda r: r["form_id"], lambda r: r["form_name"] or "–",
                      lambda r: {"eq_code": r["eq_code"] or "", "factory": r["factory_name"] or "–", "area": r["area_name"] or "–",
                                 "form_id": r["form_id"]})
    daily = []
    for i in range((d_to - d_from).days + 1):
        d = (d_from + timedelta(days=i)).isoformat()
        a = _agg([r for r in rows if (r["finished_at"] or "")[:10] == d])
        daily.append({"date": d, **a})
    slow = sorted([r for r in rows if r["ok"]], key=lambda r: -r["duration_sec"])[:10]
    return {"head": head, "factories": facs, "areas": areas, "machines": machines, "daily": daily, "slow": slow,
            "days": (d_to - d_from).days + 1}


def svg_daily(daily: list[dict], width: int = 1000, height: int = 200) -> str:
    """แท่งเวลาตรวจรายวัน (นาที) สำหรับรายงาน — SVG ล้วน พิมพ์/PDF ได้คมชัด"""
    if not daily:
        return ""
    pad_l, pad_r, pad_t, pad_b = 40, 8, 16, 30
    w, h = width - pad_l - pad_r, height - pad_t - pad_b
    mins = [d["sec"] / 60 for d in daily]
    mx = max(mins + [1])
    step = w / len(daily)
    bw = max(2.0, min(22.0, step * 0.62))
    out = [f'<svg viewBox="0 0 {width} {height}" width="100%" role="img" aria-label="เวลาตรวจรายวัน (นาที)" style="font-family:inherit;font-size:10px">']
    for i in range(5):
        y = pad_t + h - h * i / 4
        out.append(f'<line x1="{pad_l}" x2="{width - pad_r}" y1="{y:.1f}" y2="{y:.1f}" stroke="#e5e7eb"/>'
                   f'<text x="{pad_l - 4}" y="{y + 3:.1f}" text-anchor="end" fill="#64748b">{mx * i / 4:.0f}</text>')
    every = 1 if len(daily) <= 16 else (2 if len(daily) <= 31 else 5)
    for i, (d, m) in enumerate(zip(daily, mins, strict=True)):
        x = pad_l + i * step + step / 2
        bh = h * m / mx
        out.append(f'<rect x="{x - bw / 2:.1f}" y="{pad_t + h - bh:.1f}" width="{bw:.1f}" height="{bh:.1f}" rx="2" fill="#1d4ed8"><title>{d["date"]} {m:.0f} นาที</title></rect>')
        if i % every == 0 or i == len(daily) - 1:
            out.append(f'<text x="{x:.1f}" y="{height - pad_b + 14}" text-anchor="middle" fill="#64748b">{d["date"][8:10]}/{d["date"][5:7]}</text>')
    out.append(f'<text x="4" y="{pad_t - 4}" fill="#64748b">นาที</text></svg>')
    return "".join(out)


def to_xlsx(db, d_from: date, d_to: date, factory_ids=None, factory_id=None, area_id=None, equipment_id=None, form_id=None) -> bytes:
    """ทุกผลตรวจในขอบเขตที่เลือก (รวมที่ไม่นับ + เหตุผล) — นำไปวิเคราะห์ต่อได้"""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    fids = [factory_id] if factory_id else factory_ids
    if factory_id and factory_ids is not None and factory_id not in factory_ids:
        fids = [-1]
    rows = _rows(db, d_from, d_to, fids, area_id, equipment_id, form_id)
    wb = Workbook()
    ws = wb.active
    ws.title = "เวลาตรวจ"
    hdr = ["วันที่", "เวลาเริ่ม", "เวลาส่ง", "นาที", "วินาที", "นับในสรุป", "เหตุผลที่ไม่นับ", "โรงงาน", "พื้นที่", "รหัสเครื่อง",
           "เครื่อง", "แบบฟอร์ม", "ผู้ตรวจ", "NG", "เลขผลตรวจ"]
    ws.append(hdr)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="142A75")
    for r in rows:
        sec = r["duration_sec"]
        why = "" if r["ok"] else ("ลงจาก SCADA อัตโนมัติ" if r["auto"] else ("ไม่มีเวลา" if sec is None else
                                  ("สั้นกว่า 10 วินาที" if sec < MIN_SEC else "นานกว่า 2 ชั่วโมง (เปิดค้าง)")))
        ws.append([(r["finished_at"] or "")[:10], (r["scanned_at"] or "")[11:19], (r["finished_at"] or "")[11:19],
                   round(sec / 60, 2) if sec is not None else None, sec, "ใช่" if r["ok"] else "ไม่", why,
                   r["factory_name"] or "", r["area_name"] or "", r["eq_code"] or "", r["eq_name"] or "", r["form_name"] or "",
                   r["inspector"] or "", r["ng_count"] or 0, r["id"]])
    for col, w in zip("ABCDEFGHIJKLMNO", (11, 10, 10, 8, 8, 10, 26, 14, 22, 12, 28, 32, 18, 6, 10)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def dash_card(db, d_from: date, d_to: date, factory_ids: list[int] | None = None) -> dict:
    """การ์ดสรุปบนหน้าภาพรวม: รวม + รายโรงงาน"""
    rows = _rows(db, d_from, d_to, factory_ids)
    facs = _group(rows, lambda r: r["factory_id"] or 0, lambda r: r["factory_name"] or "ไม่ระบุโรงงาน",
                  lambda r: {"factory_id": r["factory_id"]})
    for c in facs:      # v0.99.33 แผงดูต่อของช่อง "เวลาตรวจรวม" ลงถึงพื้นที่
        c["areas"] = _group([r for r in rows if (r["factory_id"] or 0) == c["key"]], lambda r: r["area_id"] or 0,
                            lambda r: r["area_name"] or "ไม่ระบุพื้นที่", lambda r: {"area_id": r["area_id"]})
    return {"head": _head(db, rows, d_from, d_to), "factories": facs, "from": d_from, "to": d_to}


def fmt_dur(sec: float | None) -> str:
    """เวลาแบบอ่านง่าย: 1 ชม. 05 น. · 12 น. 30 วิ. · 45 วิ."""
    if sec is None:
        return "–"
    s = round(sec)
    h, m, ss = s // 3600, s % 3600 // 60, s % 60
    if h:
        return f"{h:,} ชม. {m:02d} น."
    if m:
        return f"{m} น. {ss:02d} วิ."
    return f"{ss} วิ."
