"""ecs/views/rep.py — Phase 5: หน้ารายงาน (รายวัน/รายเดือน: เว็บ, PDF, Excel) + ตั้งเวลาส่งรายงานทางอีเมล"""
from __future__ import annotations

import os
from datetime import date, datetime, timedelta

from flask import (Blueprint, Response, current_app, flash, jsonify, redirect, render_template, request, session,
                   url_for)

from .. import masterdata as M
from .. import report_docs as RD
from .. import schedules as SC
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role, wants_json
from ..services import ValidationError

bp = Blueprint("rep", __name__)


def _int(v):
    try:
        return int(v or 0) or None
    except (TypeError, ValueError):
        return None


def _ref(kind: str) -> date:
    today = date.today()
    if kind == "monthly":
        try:
            y, m = (int(x) for x in (request.args.get("month") or "").split("-"))
            return date(y, m, 1)
        except (TypeError, ValueError):
            return today.replace(day=1)
    try:
        return min(date.fromisoformat(request.args.get("date") or ""), today)
    except ValueError:
        return today


def render_report(kind: str, ref: date, factory_id, fmt: str, user_name: str = "") -> tuple[bytes | str, str, str]:
    """คืน (เนื้อหา, mimetype, ชื่อไฟล์) — ใช้ทั้งหน้าเว็บและการส่งตามเวลา (ต้องอยู่ใน request context)"""
    db = get_db()
    rep = RD.build(db, kind, ref, factory_id, user_name)
    db.commit()
    if fmt == "xlsx":
        return RD.to_excel(rep), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", RD.filename(rep, "xlsx")
    pdf = fmt == "pdf"
    upload = current_app.config["UPLOAD_FOLDER"]

    def photo_src(rel: str) -> str:
        if pdf:
            return "file:///" + os.path.abspath(os.path.join(upload, rel)).replace(os.sep, "/").lstrip("/")
        return url_for("mobile.media", relpath=rel)

    charts = {"daily": RD.svg_daily_bars(rep["days"]),
              "pareto": RD.svg_hbars(rep["pareto"]["items"], "label", "ng", suffix_key="cum_pct")}
    q = {"factory": factory_id or None}
    q.update({"month": ref.strftime("%Y-%m")} if kind == "monthly" else {"date": ref.isoformat()})
    html = render_template("reports/print.html", r=rep, charts=charts, pdf=pdf, photo_src=photo_src,
                           pdf_url=url_for(f"rep.{kind}", format="pdf", **q), xlsx_url=url_for(f"rep.{kind}", format="xlsx", **q))
    if pdf:
        from ..pdf import html_to_pdf
        return html_to_pdf(html), "application/pdf", RD.filename(rep, "pdf")
    return html, "text/html", ""


def _serve(kind: str):
    fmt = request.args.get("format", "html")
    fmt = fmt if fmt in ("html", "pdf", "xlsx") else "html"
    user = session.get("name") or ""
    if not user:
        row = get_db().execute("SELECT name FROM users WHERE id=?", (current_user_id(),)).fetchone()
        user = row["name"] if row else ""
    try:
        body, mime, fname = render_report(kind, _ref(kind), _int(request.args.get("factory")), fmt, user)
    except Exception as exc:  # noqa: BLE001 — แสดงข้อความที่เข้าใจได้แทนหน้า 500
        from ..pdf import PdfError
        if isinstance(exc, PdfError):
            flash(str(exc), "error")
            return redirect(url_for("rep.index"))
        raise
    if fmt == "html":
        return body
    return Response(body, mimetype=mime, headers={"Content-Disposition": f'attachment; filename="{fname}"',
                                                  "Cache-Control": "no-store"})


@bp.route("/reports")
@require_role(*ALL_ROLES)
def index():
    db = get_db()
    from ..pdf import find_browser
    from ..services import list_forms
    forms = [f for f in list_forms(db) if f["current_version_id"] and not f["is_template"]]
    # v0.27 ค้นหาใบบันทึก: สถิติของเดือนที่เลือก (วันที่ตรวจ · จำนวนครั้ง · อนุมัติ · ลงนาม)
    month = _ref("monthly")
    if month > date.today().replace(day=1):
        month = date.today().replace(day=1)
    from .. import signoffs as SO
    from calendar import monthrange
    last = monthrange(month.year, month.month)[1]
    stats = {r["form_id"]: dict(r) for r in db.execute(
        """SELECT form_id, COUNT(*) n, GROUP_CONCAT(DISTINCT CAST(substr(finished_at, 9, 2) AS INTEGER)) days,
                  MAX(finished_at) last_at, SUM(approval_status='approved') approved,
                  SUM(approval_status<>'approved' AND status IN ('submitted','returned')) pending, SUM(ng_count>0) ng
           FROM cs_submissions WHERE status<>'superseded' AND finished_at BETWEEN ? AND ? GROUP BY form_id""",
        (f"{month:%Y-%m}-01 00:00:00", f"{month:%Y-%m}-{last:02d} 23:59:59"))}
    signs = {}
    try:
        for f, al in SO.form_slots(db, month):
            need = [x for x in al if not x["na"]]
            signs[f["id"]] = (sum(1 for x in need if x["rec"]), len(need))
    except Exception:                                      # noqa: BLE001 — หน้ารายงานต้องเปิดได้เสมอ
        pass
    for f in forms:
        st = stats.get(f["id"]) or {}
        days = sorted({int(x) for x in (st.get("days") or "").split(",") if x.strip().isdigit()})
        f["m_days"] = days
        f["m_days_th"] = SO.days_text(month, days)
        f["m_n"] = st.get("n") or 0
        f["m_last"] = st.get("last_at")
        f["m_pending"] = st.get("pending") or 0
        f["m_approved"] = st.get("approved") or 0                                   # v0.98 ความคืบหน้าอนุมัติ
        f["m_ng"] = st.get("ng") or 0
        f["m_sign"] = signs.get(f["id"], (0, 0))
        f["m_cat"] = f.get("category") or f.get("eq_type") or ""
    # v0.99.18 แถบวันของเดือน: ผลตรวจ / NG / จำนวนแบบฟอร์มต่อวัน — กดวันเพื่อดูเฉพาะวัน
    per = {r["d"]: dict(r) for r in db.execute(
        """SELECT CAST(substr(finished_at, 9, 2) AS INTEGER) d, COUNT(*) n, SUM(ng_count>0) ng, COUNT(DISTINCT form_id) nf
           FROM cs_submissions WHERE status<>'superseded' AND finished_at BETWEEN ? AND ? GROUP BY d""",
        (f"{month:%Y-%m}-01 00:00:00", f"{month:%Y-%m}-{last:02d} 23:59:59"))}
    today = date.today()
    mdays = []
    for d in range(1, last + 1):
        dd = month.replace(day=d)
        r = per.get(d) or {}
        mdays.append({"d": d, "iso": dd.isoformat(), "wd": dd.weekday(), "n": r.get("n") or 0, "ng": r.get("ng") or 0,
                      "nf": r.get("nf") or 0, "future": dd > today, "today": dd == today})
    sel_day = _int(request.args.get("day"))
    sel_day = sel_day if sel_day and 1 <= sel_day <= last and month.replace(day=sel_day) <= today else None
    forms.sort(key=lambda f: (-(f["m_n"] > 0), f["m_last"] and -int(f["m_last"][:10].replace("-", "")) or 0, f["code"] or ""))
    cats = sorted({f["m_cat"] for f in forms if f["m_cat"]})
    return render_template("reports/index.html", factories=M.list_factories(db), today=date.today(), forms=forms, rt_from=date.today() - timedelta(days=29),
                           areas=M.list_areas(db), cats=cats, sheet_month=month, last_day=last,
                           month=month.strftime("%Y-%m"), this_month=date.today().strftime("%Y-%m"), pdf_ready=bool(find_browser()),
                           schedules=SC.list_schedules(db) if session.get("role") == "admin" else [],
                           mdays=mdays, sel_day=sel_day, mdays_max=max([x["n"] for x in mdays] + [1]))


@bp.route("/reports/daily")
@require_role(*ALL_ROLES)
def daily():
    return _serve("daily")


@bp.route("/reports/weekly")
@require_role(*ALL_ROLES)
def weekly():
    return _serve("weekly")


@bp.route("/reports/monthly")
@require_role(*ALL_ROLES)
def monthly():
    return _serve("monthly")


# ───────────────────────── ตั้งเวลาส่งรายงาน ─────────────────────────

@bp.route("/admin/report-schedules", methods=["GET", "POST"])
@require_role("admin")
def schedules():
    db = get_db()
    edit_id = _int(request.values.get("id"))
    if request.method == "POST":
        data = request.form.to_dict()
        data["formats"] = request.form.getlist("formats")
        try:
            SC.save_schedule(db, data, current_user_id(), edit_id)
            db.commit()
            flash("บันทึกกำหนดการส่งรายงานแล้ว", "ok")
            return redirect(url_for("rep.schedules"))
        except ValidationError as exc:
            db.rollback()
            for e in exc.errors:
                flash(e, "error")
    from .. import notify as N
    cfg = N.get_settings(db, with_secrets=False)
    return render_template("reports/schedules.html", rows=SC.list_schedules(db), factories=M.list_factories(db),
                           edit=SC.get_schedule(db, edit_id) if edit_id else None, runs=SC.list_runs(db, 30),
                           email_ready=N.channel_ready(N.get_settings(db), "email"), cfg=cfg,
                           data=request.form if request.method == "POST" else {})


@bp.route("/admin/report-schedules/<int:sid>/run", methods=["POST"])
@require_role("admin")
def schedule_run(sid):
    db = get_db()
    res = SC.run_schedule(db, sid, manual=True)
    db.commit()
    if wants_json():
        return jsonify(res)
    flash(res["message"], "ok" if res["ok"] else "error")
    return redirect(url_for("rep.schedules"))


@bp.route("/admin/report-schedules/<int:sid>/delete", methods=["POST"])
@require_role("admin")
def schedule_delete(sid):
    db = get_db()
    SC.delete_schedule(db, sid, current_user_id())
    db.commit()
    flash("ลบกำหนดการแล้ว", "ok")
    return redirect(url_for("rep.schedules"))


def run_due_schedules(app, now: datetime | None = None) -> int:
    """เรียกจากงานเบื้องหลัง: สร้างรายงานที่ถึงเวลาแล้วส่งอีเมล"""
    with app.test_request_context("/"):
        db = get_db()
        n = 0
        for sid in SC.due_schedules(db, now):
            SC.run_schedule(db, sid)
            db.commit()
            n += 1
        return n


# ───────────────────────── ใบบันทึกผลทางการ (รายแบบฟอร์ม / รายครั้ง) ─────────────────────────

def _sheet_ctx(pdf: bool) -> dict:
    """ตัวช่วยที่เทมเพลต reports/sheet.html ใช้ (รูป/โลโก้เป็น file:/// ตอนทำ PDF)"""
    from .. import sheet_report as SR
    from .. import sign_blocks as SB
    from .admin import qr_svg
    upload = current_app.config["UPLOAD_FOLDER"]

    def photo_src(rel: str) -> str:
        if pdf:
            return "file:///" + os.path.abspath(os.path.join(upload, rel)).replace(os.sep, "/").lstrip("/")
        return url_for("mobile.media", relpath=rel)

    def img_src(name: str) -> str:
        path = _doc_image(name)
        if pdf:
            return "file:///" + os.path.abspath(path).replace(os.sep, "/").lstrip("/")
        return url_for("rep.doc_image", name=name) + f"?v={int(os.path.getmtime(path)) if os.path.exists(path) else 0}"
    return {"pdf": pdf, "photo_src": photo_src, "logo_src": img_src("aisin-logo.png"), "stamp_src": lambda key="utility": img_src(SB.STAMPS.get(key, SB.STAMPS["utility"])[0]),
            "stamp_alt": lambda key="utility": SB.STAMPS.get(key, SB.STAMPS["utility"])[1], "th_dt": SR.th_dt, "cell": SR.cell_text,
            "short": SR._short, "qr": lambda u: qr_svg(u, box=3) if u else None}


def _stamp_paths() -> dict:
    from .. import sign_blocks as SB
    return {k: _doc_image(v[0]) for k, v in SB.STAMPS.items()}


def _doc_image(name: str) -> str:
    """รูปบนเอกสาร (ตรามุมซ้ายบน / โลโก้มุมขวาล่าง) — ใช้รูปที่ผู้ดูแลระบบอัปโหลด (uploads/doc/) ถ้ามี ไม่งั้นใช้ static/img"""
    from .. import sheet_layout as SL
    ov = SL.override_path(current_app.config["UPLOAD_FOLDER"], name)
    return ov if name in SL.IMAGES and os.path.exists(ov) else os.path.join(current_app.static_folder, "img", name)


@bp.route("/reports/doc-image/<name>")
@require_role(*ALL_ROLES)
def doc_image(name):
    from flask import abort, send_file
    from .. import sheet_layout as SL
    if name not in SL.IMAGES:
        abort(404)
    path = _doc_image(name)
    if not os.path.exists(path):
        abort(404)
    return send_file(path, mimetype="image/png", max_age=0)


@bp.route("/reports/layout", methods=["GET", "POST"])
@require_role("admin")
def sheet_layout():
    """v0.26 ผู้ดูแลระบบแก้รูปแบบใบบันทึก (PDF / Excel) เอง"""
    from .. import services as S
    from .. import sheet_layout as SL
    db = get_db()
    up = current_app.config["UPLOAD_FOLDER"]
    if request.method == "POST":
        act = request.form.get("action", "save")
        try:
            if act == "reset":
                SL.reset(db, current_user_id())
                flash("คืนค่าเริ่มต้นแล้ว (ข้อความและการแสดงผล)", "ok")
            elif act.startswith("delimg:"):
                SL.delete_image(up, act[7:])
                flash("ใช้รูปเริ่มต้นแล้ว", "ok")
            else:
                SL.save(db, request.form, current_user_id())
                for name in SL.IMAGES:
                    f = request.files.get("img_" + name.replace(".", "_"))
                    if f and f.filename:
                        SL.save_image(up, name, f.read())
                flash("บันทึกรูปแบบใบบันทึกแล้ว — มีผลกับ PDF และ Excel ทันที", "ok")
            db.commit()
        except S.ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
        return redirect(url_for("rep.sheet_layout"))
    f = db.execute("""SELECT id FROM cs_forms WHERE is_template=0 AND active=1 AND current_version_id IS NOT NULL
                      ORDER BY id LIMIT 1""").fetchone()
    imgs = {n: {"label": t, "custom": os.path.exists(SL.override_path(up, n)),
                "src": url_for("rep.doc_image", name=n) + f"?v={int(os.path.getmtime(_doc_image(n))) if os.path.exists(_doc_image(n)) else 0}"}
            for n, t in SL.IMAGES.items()}
    return render_template("reports/layout.html", L=SL.get(db), D=SL.DEFAULTS, LABELS=SL.LABELS, imgs=imgs,
                           preview_form=f[0] if f else None, this_month=date.today().strftime("%Y-%m"))


def _online(path: str) -> str:
    return request.host_url.rstrip("/") + path


def _send(body, fmt: str, fname: str):
    if fmt == "html":
        return body
    mime = "application/pdf" if fmt == "pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    from urllib.parse import quote
    ascii_name = "".join(ch if 32 < ord(ch) < 127 and ch not in '"\\;' else "_" for ch in fname) or "report"
    disp = f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(fname)}"
    return Response(body, mimetype=mime, headers={"Content-Disposition": disp, "Cache-Control": "no-store"})


@bp.route("/reports/sheets")
@require_role(*ALL_ROLES)
def sheets():
    """ใบบันทึกผลการตรวจประจำเดือน — เลือกได้หลายแบบฟอร์ม (1 แบบฟอร์ม = 1 ชีท/หน้า) · เว็บ / PDF / Excel"""
    from .. import services as S
    from .. import sheet_report as SR
    db = get_db()
    fmt = request.args.get("format", "html")
    fmt = fmt if fmt in ("html", "pdf", "xlsx") else "html"
    try:
        y, m = (int(x) for x in (request.args.get("month") or "").split("-"))
        month = date(y, m, 1)
    except (TypeError, ValueError):
        month = date.today().replace(day=1)
    ids = [int(x) for part in request.args.getlist("form") for x in str(part).split(",") if x.strip().isdigit()]
    if request.args.get("all") == "1":
        fid, aid = _int(request.args.get("factory")), _int(request.args.get("area"))
        ids += [f["id"] for f in S.list_forms(db, fid) if f["current_version_id"] and not f["is_template"] and (not aid or f["area_id"] == aid)]
    ids = list(dict.fromkeys(ids))[:80]
    if not ids:
        flash("เลือกแบบฟอร์มอย่างน้อย 1 ฉบับ", "error")
        return redirect(url_for("rep.index"))
    user = session.get("name") or ""
    secret = current_app.secret_key or ""
    docs = []
    for fid in ids:
        try:
            d = SR.build_month_sheet(db, fid, month, secret, user)
        except ValidationError:
            continue
        d["online_url"] = _online(url_for("rep.sheets", form=fid, month=month.strftime("%Y-%m")))
        d["mk"] = month.strftime("%Y-%m")
        if fmt == "html":                                   # v0.85 ปุ่มอนุมัติ / ลงนามในหน้าใบบันทึก
            d["acts"] = _sheet_acts(db, fid, month)
        docs.append(d)
    if not docs:
        flash("ไม่พบแบบฟอร์มที่เลือก", "error")
        return redirect(url_for("rep.index"))
    tag = docs[0]["doc_no"] if len(docs) == 1 else f"CheckSheets-{month.strftime('%Y%m')}-{len(docs)}forms"
    if fmt == "xlsx":
        return _send(SR.to_excel(docs, _doc_image("aisin-logo.png"), _doc_image("doc-stamp.png"), _stamp_paths()), "xlsx", f"{tag}.xlsx")
    q = {"form": ",".join(str(i) for i in ids), "month": month.strftime("%Y-%m")}
    html = render_template("reports/sheet.html", docs=docs, title=f"ใบบันทึกผลการตรวจ {SR.th_month(month)}",
                           back_url=url_for("rep.index"), pdf_url=url_for("rep.sheets", format="pdf", **q),
                           xlsx_url=url_for("rep.sheets", format="xlsx", **q),
                           sign_url=url_for("rep.sheet_sign", form=ids[0], month=month.strftime("%Y-%m"))
                           if len(ids) == 1 and fmt == "html" and session.get("role") in ("admin", "supervisor", "technician") else None,
                           here=request.full_path, **_sheet_ctx(fmt == "pdf"))
    if fmt == "pdf":
        from ..pdf import PdfError, html_to_pdf
        try:
            return _send(html_to_pdf(html, timeout=180), "pdf", f"{tag}.pdf")
        except PdfError as exc:
            current_app.logger.error("PDF (ใบบันทึกรายเดือน %s): %s", tag, exc)
            flash(f"{exc} — เปิดฉบับเว็บแล้วกด 'พิมพ์' › 'บันทึกเป็น PDF' แทนได้ (ผู้ดูแลระบบ: ดูรายละเอียดใน log / หน้า สถานะระบบ)", "error")
            return redirect(url_for("rep.sheets", **q))
    return html


def _me(db) -> dict:
    r = db.execute("SELECT id, name, role, factory_id, COALESCE(position,'') AS position FROM users WHERE id=?",
                   (current_user_id(),)).fetchone()
    return dict(r) if r else {"id": current_user_id(), "role": session.get("role"), "name": "", "position": "", "factory_id": None}


def _sheet_acts(db, fid: int, month: date) -> dict | None:
    from .. import services as S
    from .. import sheet_actions as SA
    try:
        form = S.get_form(db, fid)
        return SA.actions(db, dict(form), month, _me(db)) if form else None
    except Exception:                                       # noqa: BLE001 — ปุ่มไม่ขึ้น ดีกว่าหน้ารายงานล้ม
        current_app.logger.exception("sheet actions failed (form %s)", fid)
        return None


def _sheet_target():
    from .. import services as S
    from .. import view_scope as VS
    db = get_db()
    fid = _int(request.form.get("form"))
    try:
        y, m = (int(x) for x in (request.form.get("month") or "").split("-"))
        month = date(y, m, 1)
    except (TypeError, ValueError):
        month = None
    form = S.get_form(db, fid) if fid and VS.can_see_form(fid) else None
    return db, (dict(form) if form else None), month


def _back_to_sheet(form, month):
    from ..security import safe_next
    dflt = url_for("rep.sheets", form=form["id"], month=month.strftime("%Y-%m")) if form and month else url_for("rep.index")
    return redirect(safe_next(request.form.get("next"), dflt))


@bp.route("/reports/sheets/approve", methods=["POST"])
@require_role(*ALL_ROLES)
def sheet_approve():
    """v0.85 แถวหัวหน้างาน (Sr.Tech) ในใบบันทึก: อนุมัติผลตรวจที่รอ + รับรองค่าจาก SCADA ของช่วงนั้น"""
    from .. import sheet_actions as SA
    db, form, month = _sheet_target()
    try:
        if not form or not month:
            raise ValidationError("ไม่พบแบบฟอร์ม")
        start, span = _int(request.form.get("start")) or 1, _int(request.form.get("span")) or 1
        r = SA.approve_range(db, form, month, start, span, current_user_id(), include_ng=request.form.get("ng") == "1")
        db.commit()
        parts = [f"อนุมัติ {r['approved']} รายการ" if r["approved"] else "", f"รับรองค่าจาก SCADA {r['certified']} รายการ" if r["certified"] else ""]
        flash(" · ".join(p for p in parts if p) or "ไม่มีรายการที่ต้องอนุมัติในช่วงนี้", "ok")
        if r["skipped_ng"]:
            flash(f"ยังไม่อนุมัติรายการที่มี NG {r['skipped_ng']} รายการ — กด “อนุมัติรวม NG” หรือตรวจที่หน้ารออนุมัติ", "error")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0] if getattr(exc, "errors", None) else str(exc), "error")
    return _back_to_sheet(form, month)


@bp.route("/reports/sheets/sign-all", methods=["POST"])
@require_role(*ALL_ROLES)
def sheet_sign_all():
    """v0.85 อนุมัติ / ลงนามทุกช่องที่ผู้ใช้ทำได้ในใบบันทึกนี้ (ไม่รวมรายการ NG)"""
    from .. import sheet_actions as SA
    db, form, month = _sheet_target()
    try:
        if not form or not month:
            raise ValidationError("ไม่พบแบบฟอร์ม")
        r = SA.do_all(db, form, month, _me(db))
        db.commit()
        msg = [f"อนุมัติ {r['approved']}" if r["approved"] else "", f"รับรองค่าจาก SCADA {r['certified']}" if r["certified"] else "",
               f"ลงนาม {r['signed']} ช่อง" if r["signed"] else ""]
        flash(" · ".join(x for x in msg if x) or "ไม่มีช่องที่คุณอนุมัติ / ลงนามได้ตอนนี้", "ok")
        if r["skipped_ng"]:
            flash(f"รายการที่มี NG {r['skipped_ng']} รายการยังไม่อนุมัติ — กด “อนุมัติรวม NG” ในแถวหัวหน้างาน หรือตรวจที่หน้ารออนุมัติ", "error")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0] if getattr(exc, "errors", None) else str(exc), "error")
    return _back_to_sheet(form, month)


@bp.route("/submissions/<int:sub_id>/record")
@require_role(*ALL_ROLES)
def record(sub_id):
    """ใบบันทึกผลการตรวจรายครั้ง (ทางการ) · เว็บ / PDF"""
    from .. import sheet_report as SR
    db = get_db()
    fmt = "pdf" if request.args.get("format") == "pdf" else "html"
    try:
        d = SR.build_record(db, sub_id, current_app.secret_key or "", session.get("name") or "")
    except ValidationError:
        from flask import abort
        abort(404)
    d["online_url"] = _online(url_for("rep.record", sub_id=sub_id))
    html = render_template("reports/sheet.html", docs=[d], title=f"ใบบันทึกผลการตรวจ {d['doc_no']}",
                           back_url=url_for("review.submission_detail", sub_id=sub_id),
                           pdf_url=url_for("rep.record", sub_id=sub_id, format="pdf"), xlsx_url=None, **_sheet_ctx(fmt == "pdf"))
    if fmt == "pdf":
        from ..pdf import PdfError, html_to_pdf
        try:
            return _send(html_to_pdf(html), "pdf", f"{d['doc_no']}.pdf")
        except PdfError as exc:
            current_app.logger.error("PDF (ใบบันทึกรายครั้ง %s): %s", sub_id, exc)
            flash(f"{exc} — เปิด 'ใบบันทึกผล' แล้วกด 'พิมพ์' › 'บันทึกเป็น PDF' แทนได้", "error")
            return redirect(url_for("review.submission_detail", sub_id=sub_id))
    return html


# ───────────────────────── v0.54 ลงนามรับทราบ / ลงนามย้อนหลังในใบบันทึก ─────────────────────────

@bp.route("/reports/sheets/sign", methods=["GET", "POST"])
@require_role("admin", "supervisor", "technician")
def sheet_sign():
    """ช่องผู้ตรวจที่ยังว่างของเดือน → รับทราบ (ลงนาม) หรือกรอกข้อมูลย้อนหลังของรอบที่ขาด"""
    from .. import services as S
    from .. import shiftsign as SSG
    db = get_db()
    fid = _int(request.values.get("form"))
    try:
        y, m = (int(x) for x in (request.values.get("month") or "").split("-"))
        month = date(y, m, 1)
    except (TypeError, ValueError):
        month = date.today().replace(day=1)
    form = S.get_form(db, fid) if fid else None
    if not form:
        flash("ไม่พบแบบฟอร์ม", "error")
        return redirect(url_for("rep.index"))
    if request.method == "POST":
        try:
            if request.form.get("undo"):
                SSG.unsign(db, int(request.form["undo"]), current_user_id(), session.get("role"))
                msg = "ยกเลิกการลงนามแล้ว"
            else:
                keys = request.form.getlist("cell")             # "YYYY-MM-DD|shift"
                if not keys:
                    raise ValidationError("เลือกช่องที่จะลงนามอย่างน้อย 1 ช่อง")
                for k in keys[:62]:
                    d, sh = k.split("|")
                    SSG.sign(db, fid, date.fromisoformat(d), sh, current_user_id(), request.form.get("note") or "")
                msg = f"ลงนามรับทราบแล้ว {len(keys[:62])} ช่อง"
            db.commit()
            flash(msg, "ok")
        except (ValidationError, ValueError) as exc:
            db.rollback()
            flash(getattr(exc, "errors", [str(exc)])[0], "error")
        return redirect(url_for("rep.sheet_sign", form=fid, month=month.strftime("%Y-%m")))
    from ..signoffs import signature_png
    from .. import backfill as BF
    return render_template("reports/sheet_sign.html", form=form, month=month, rows=SSG.missing(db, fid, month),
                           can_grant=BF.can_grant(db, current_user_id()), bf_days=BF.granted_days(db, current_user_id(), fid),
                           acks=SSG.my_acks(db, fid, month), max_days=SSG.MAX_BACK_DAYS,
                           has_sig=bool(signature_png(db, current_user_id())),
                           prev=(month - timedelta(days=1)).replace(day=1), next=(month + timedelta(days=32)).replace(day=1))
