"""ecs/views/team.py — v0.50 ทีมช่าง: ต้องจัดการวันนี้ · ตารางกะ (เชื่อม UT-CMMS) · มอบหมายโรงงาน · คำอธิบายสถานะ"""
from __future__ import annotations

from datetime import date, timedelta

from flask import Blueprint, current_app, flash, jsonify, redirect, render_template, request, url_for

from .. import cmms_tpm as TPM
from .. import roster as RO
from .. import submissions as SUB
from .. import terms as TR
from .. import today as TD
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import ValidationError

bp = Blueprint("team", __name__)
LEAD = ("admin", "supervisor")


@bp.route("/today")
@require_role(*LEAD)
def today():
    db = get_db()
    data = TD.build(db, current_user_id())
    db.commit()                                     # ใบส่งกะที่ถึงเวลาถูกสร้างระหว่างเปิดหน้า
    return render_template("team/today.html", t=data)


@bp.route("/today/approve", methods=["POST"])
@require_role(*LEAD)
def today_approve():
    """อนุมัติใบที่ปกติทั้งใบ (ไม่มี NG) ในความรับผิดชอบ — คำนวณใหม่ฝั่งเซิร์ฟเวอร์ ไม่เชื่อรายการจากหน้าเว็บ"""
    db = get_db()
    ids = TD.build(db, current_user_id())["pending"]["ok_ids"]
    res = SUB.bulk_approve_ok(db, ids, current_user_id(), note="อนุมัติแบบกลุ่ม (ปกติทั้งใบ) จากหน้าต้องจัดการวันนี้")
    db.commit()
    TPM.safe(TPM.on_approve, db, current_app.config, ids, current_user_id())
    flash(f"อนุมัติใบที่ปกติแล้ว {res['approved']} ใบ" + (f" · ข้าม {res['skipped']}" if res["skipped"] else ""), "ok")
    return redirect(url_for("team.today"))


def _month_arg() -> date:
    try:
        y, m = (request.args.get("month") or "").split("-")
        return date(int(y), int(m), 1)
    except ValueError:
        from ..services import now_dt
        return now_dt().date().replace(day=1)


@bp.route("/admin/roster")
@require_role(*LEAD)
def roster():
    db = get_db()
    g = RO.month_grid(db, _month_arg())
    from .. import handover as HO
    return render_template("team/roster.html", g=g, cfg=RO.get_settings(db), shifts=TR.SHIFT,
                           types=[("", "day")] + [(t, t) for t in RO.PLAN_TYPES],
                           patterns=RO.patterns(db), ho=HO.get_settings(db))


@bp.route("/admin/roster/save", methods=["POST"])
@require_role(*LEAD)
def roster_save():
    db = get_db()
    data = request.get_json(silent=True) or {}
    try:
        n = RO.set_plans(db, list(data.get("items") or []), current_user_id())
        db.commit()
    except ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0] if getattr(exc, "errors", None) else str(exc)}), 400
    return jsonify({"ok": True, "saved": n})


@bp.route("/admin/roster/settings", methods=["POST"])
@require_role("admin")
def roster_settings():
    db = get_db()
    cfg = RO.save_settings(db, request.form, current_user_id())
    db.commit()
    flash("เปิดการกรองงานตามตารางกะแล้ว" if cfg["filter"] else "ปิดการกรองงานตามตารางกะแล้ว — ช่างเห็นงานทุกกะในโรงงานของตน", "ok")
    return redirect(url_for("team.roster", month=request.form.get("month") or None))


@bp.route("/admin/assign", methods=["GET", "POST"])
@require_role(*LEAD)
def assign():
    db = get_db()
    if request.method == "POST":
        people = RO.team(db)
        for p in people:
            if request.form.get(f"seen.{p['id']}"):
                RO.set_factories(db, p["id"], [int(x) for x in request.form.getlist(f"fac.{p['id']}") if x.isdigit()],
                                 current_user_id())
        db.commit()
        flash("บันทึกการมอบหมายโรงงานแล้ว — งานของฉันของช่างเปลี่ยนตามทันที", "ok")
        return redirect(url_for("team.assign"))
    from ..services import now_dt
    now = now_dt()
    R = RO.load(db, now.date(), now.date())
    people = RO.team(db)
    for p in people:
        k = RO.shift_key(R, p["id"], now.date())
        p["shift"] = TR.SHIFT[k]
    fac = RO.factory_names(db)
    counts = {fid: sum(1 for p in people if p["role"] == "technician" and (p["factories"] is None or fid in p["factories"]))
              for fid in fac}
    return render_template("team/assign.html", people=people, factories=fac, counts=counts, source=R["source"])


@bp.route("/help/status")
@require_role(*ALL_ROLES)
def status_help():
    return render_template("team/status_help.html", groups=TR.GROUPS)


# ───────────────────────── v0.51 รูปแบบหมุนกะ ─────────────────────────

def _json_err(exc):
    return jsonify({"error": exc.errors[0] if getattr(exc, "errors", None) else str(exc)}), 400


@bp.route("/admin/roster/pattern/save", methods=["POST"])
@require_role(*LEAD)
def pattern_save():
    db = get_db()
    try:
        p = RO.save_pattern(db, request.get_json(silent=True) or {}, current_user_id())
        db.commit()
    except ValidationError as exc:
        db.rollback()
        return _json_err(exc)
    return jsonify({"ok": True, "pattern": p, "patterns": RO.patterns(db)})


@bp.route("/admin/roster/pattern/delete", methods=["POST"])
@require_role(*LEAD)
def pattern_delete():
    db = get_db()
    RO.delete_pattern(db, str((request.get_json(silent=True) or {}).get("id") or ""), current_user_id())
    db.commit()
    return jsonify({"ok": True, "patterns": RO.patterns(db)})


@bp.route("/admin/roster/pattern/apply", methods=["POST"])
@require_role(*LEAD)
def pattern_apply():
    db = get_db()
    data = request.get_json(silent=True) or {}
    try:
        d0, d1 = date.fromisoformat(str(data.get("from"))), date.fromisoformat(str(data.get("to")))
        n = RO.apply_pattern(db, str(data.get("id") or ""), list(data.get("people") or []), d0, d1, current_user_id(),
                             skip_holidays=bool(data.get("skip_holidays", True)), keep_leave=bool(data.get("keep_leave", True)))
        db.commit()
    except ValueError as exc:
        db.rollback()
        if isinstance(exc, ValidationError):
            return _json_err(exc)
        return jsonify({"error": "วันที่ไม่ถูกต้อง"}), 400
    return jsonify({"ok": True, "saved": n})


# ───────────────────────── v0.51 สรุปผลงานรายคนรายสัปดาห์ ─────────────────────────

def _week_arg():
    from .. import scorecard as SC
    from ..services import now_dt
    try:
        d = date.fromisoformat(request.args.get("week") or "")
    except ValueError:
        d = now_dt().date() - timedelta(days=7)
    return SC.week_start(d)


def _lead_fids(db):
    from flask import session
    return None if session.get("role") == "admin" else RO.factories_of(db, current_user_id())


@bp.route("/team/scorecard")
@require_role(*LEAD)
def scorecard():
    from .. import scorecard as SC
    db = get_db()
    monday = _week_arg()
    sc = SC.build(db, monday, _lead_fids(db))
    return render_template("team/scorecard.html", sc=sc, cfg=SC.get_settings(db), WD=SC.WD_TH,
                           prev=monday - timedelta(days=7), next=monday + timedelta(days=7))


@bp.route("/team/people/<int:uid>")
@require_role(*ALL_ROLES)
def person(uid):
    """v0.99.24 ผลงานรายคน (เจาะลึก): หัวหน้างาน/ผู้ดูแลดูได้ทุกคนในโรงงานที่รับผิดชอบ · ช่างดูของตัวเองได้"""
    from flask import abort, session

    from .. import scorecard as SC
    db = get_db()
    if session.get("role") not in LEAD and uid != current_user_id():
        abort(403)
    today = date.today()
    a = request.args
    try:
        if a.get("day"):
            d_from = d_to = min(date.fromisoformat(a["day"]), today)
        elif a.get("week"):
            d_from = SC.week_start(date.fromisoformat(a["week"]))
            d_to = d_from + timedelta(days=6)
        elif a.get("from") or a.get("to"):
            d_to = min(date.fromisoformat(a.get("to") or today.isoformat()), today)
            d_from = date.fromisoformat(a.get("from") or (d_to - timedelta(days=29)).isoformat())
        else:
            n = max(1, min(366, int(a.get("days") or 30)))
            d_to, d_from = today, today - timedelta(days=n - 1)
    except ValueError:
        d_to, d_from = today, today - timedelta(days=29)
    if d_from > d_to:
        d_from, d_to = d_to, d_from
    d_from = max(d_from, d_to - timedelta(days=365))
    P = SC.person(db, uid, d_from, d_to, _lead_fids(db) if session.get("role") in LEAD else None)
    if not P:
        abort(404)
    n_days = (d_to - d_from).days + 1
    return render_template("team/person.html", P=P, n_days=n_days, today=today, args=a,
                           prev_day=d_from - timedelta(days=1), next_day=(d_to + timedelta(days=1)) if d_to < today else None,
                           week_of=SC.week_start(d_to))


@bp.route("/team/scorecard.xlsx")
@require_role(*LEAD)
def scorecard_xlsx():
    from flask import Response

    from .. import scorecard as SC
    db = get_db()
    monday = _week_arg()
    data = SC.to_xlsx(SC.build(db, monday, _lead_fids(db)))
    return Response(data, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename=scorecard_{monday.isoformat()}.xlsx"})


@bp.route("/team/scorecard/settings", methods=["POST"])
@require_role("admin")
def scorecard_settings():
    from .. import scorecard as SC
    db = get_db()
    try:
        SC.save_settings(db, request.form, current_user_id())
        db.commit()
        if request.form.get("send_now"):
            SC.weekly_send(db, base_url=current_app.config.get("BASE_URL", ""), force=True)
            db.commit()
            flash("ส่งสรุปสัปดาห์ที่แล้วถึงหัวหน้างาน/ผู้ดูแลระบบแล้ว", "ok")
        else:
            flash("บันทึกการส่งสรุปอัตโนมัติแล้ว", "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("team.scorecard"))


# ───────────────────────── v0.51 ส่งกะ / รับกะ ─────────────────────────

@bp.route("/handover")
@require_role(*LEAD)
def handover_list():
    from .. import handover as HO
    db = get_db()
    HO.generate(db, base_url=current_app.config.get("BASE_URL", ""))      # เปิดหน้า = ตรวจว่ามีใบที่ถึงเวลาแล้วหรือยัง
    db.commit()
    return render_template("team/handover_list.html", rows=HO.recent(db, _lead_fids(db), days=7), cfg=HO.get_settings(db))


@bp.route("/handover/settings", methods=["POST"])
@require_role("admin")
def handover_settings():
    from .. import handover as HO
    db = get_db()
    try:
        HO.save_settings(db, request.form, current_user_id())
        db.commit()
        flash("บันทึกเวลาเปลี่ยนกะแล้ว", "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("team.handover_list"))


@bp.route("/m/handover/<int:hid>")
@require_role(*ALL_ROLES)
def handover_view(hid):
    from flask import abort

    from .. import handover as HO
    db = get_db()
    h = HO.get(db, hid)
    if not h:
        abort(404)
    return render_template("team/handover.html", h=h)


@bp.route("/m/handover/<int:hid>/<action>", methods=["POST"])
@require_role("admin", "supervisor", "technician")
def handover_action(hid, action):
    from .. import handover as HO
    db = get_db()
    try:
        if action == "ack":
            HO.acknowledge(db, hid, current_user_id(), request.form.get("note") or "")
            msg = "รับกะแล้ว ✓"
        elif action == "note":
            HO.add_note(db, hid, current_user_id(), request.form.get("note") or "")
            msg = "บันทึกหมายเหตุส่งกะแล้ว"
        else:
            return redirect(url_for("team.handover_view", hid=hid))
        db.commit()
        flash(msg, "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("team.handover_view", hid=hid))


# ───────────────────────── v0.52 สิทธิ์การใช้งาน · ดูหน้าจอแทนผู้ใช้ ─────────────────────────

@bp.route("/admin/permissions")
@require_role("admin")
def permissions():
    from .. import perms as PM
    from ..services import list_forms
    db = get_db()
    forms = [f for f in list_forms(db) if f.get("current_version_id") or f.get("is_template")]
    from ..view_scope import forms_by_dept
    dept_of = forms_by_dept(db)
    counts = {d: sum(1 for v in dept_of.values() if v == d) for d in PM.DEPT_TH}
    return render_template("team/permissions.html", matrix=PM.MATRIX, users=PM.user_overview(db), grants=PM.list_grants(db),
                           forms=forms, dept_of=dept_of, DEPT_TH=PM.DEPT_TH, dept_counts=counts)


@bp.route("/admin/permissions/grant", methods=["POST"])
@require_role("admin")
def permission_grant():
    from .. import perms as PM
    db = get_db()
    try:
        PM.add_grant(db, request.form, current_user_id())
        db.commit()
        flash("ให้สิทธิ์แก้ไขแบบฟอร์มแล้ว — มีผลทันที", "ok")
    except ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("team.permissions") + "#grants")


@bp.route("/admin/permissions/revoke/<int:gid>", methods=["POST"])
@require_role("admin")
def permission_revoke(gid):
    from .. import perms as PM
    db = get_db()
    PM.remove_grant(db, gid, current_user_id())
    db.commit()
    flash("ยกเลิกสิทธิ์แล้ว", "ok")
    return redirect(url_for("team.permissions") + "#grants")


@bp.route("/admin/view-as/<int:uid>", methods=["POST"])
@require_role("admin")
def view_as_start(uid):
    from .. import perms as PM
    db = get_db()
    try:
        PM.start_view_as(db, uid)
        db.commit()
    except ValidationError as exc:
        flash(exc.errors[0], "error")
        return redirect(url_for("team.permissions"))
    role = db.execute("SELECT role FROM users WHERE id=?", (uid,)).fetchone()[0]
    return redirect(url_for("mobile.home") if role == "technician" else url_for("index"))


@bp.route("/view-as/stop", methods=["POST"])
def view_as_stop():
    from .. import perms as PM
    db = get_db()
    if PM.stop_view_as(db):
        db.commit()
        flash("กลับเป็นผู้ดูแลระบบแล้ว", "ok")
    return redirect(url_for("team.permissions"))


# ───────────────────────── v0.55 สิทธิ์ลงข้อมูลเช็คชีทย้อนหลัง (รายวัน) ─────────────────────────

@bp.route("/team/backfill")
@require_role(*ALL_ROLES)
def backfill():
    from .. import backfill as BF
    from ..services import list_forms
    db = get_db()
    if not BF.can_grant(db, current_user_id()):
        return render_template("error.html", code=403,
                               message="หน้านี้สำหรับผู้ดูแลระบบหรือหัวหน้างานระดับ FM/SV/SSV/DM"), 403
    fid = request.args.get("form", type=int) or 0
    forms = [f for f in list_forms(db) if f.get("current_version_id") and f.get("active")]
    return render_template("team/backfill.html", users=BF.users(db), days=BF.open_days(db, fid or None),
                           grants=BF.grants(db), recent=BF.recent_backfills(db), forms=forms, fid=fid,
                           max_days=BF.MAX_BACK_DAYS)


@bp.route("/team/backfill/grant", methods=["POST"])
@require_role(*ALL_ROLES)
def backfill_grant():
    from .. import backfill as BF
    db = get_db()
    fid = request.form.get("form", type=int) or 0
    try:
        if request.form.get("revoke"):
            BF.revoke(db, int(request.form["revoke"]), current_user_id())
            msg = "ยกเลิกสิทธิ์แล้ว"
        else:
            uids = [int(x) for x in request.form.getlist("user_id") if x.isdigit()]
            days = [BF.parse_day(x) for x in request.form.getlist("day")]
            n = BF.grant(db, uids, days, fid, request.form.get("note") or "", current_user_id())
            msg = f"ให้สิทธิ์ลงข้อมูลย้อนหลังแล้ว {len(uids)} คน × {len(days)} วัน" + ("" if n else " (มีสิทธิ์อยู่แล้ว)")
        db.commit()
        flash(msg, "ok")
    except (ValidationError, ValueError) as exc:
        db.rollback()
        flash(getattr(exc, "errors", ["ข้อมูลไม่ถูกต้อง"])[0], "error")
    return redirect(url_for("team.backfill", form=fid or None))


@bp.route("/backfill/pick")
@require_role("admin", "supervisor", "technician")
def backfill_pick():
    """v0.58 หน้าตัวเลือกลงข้อมูลย้อนหลัง — รอบที่ขาดตรวจ เลือกแล้วเปิดหน้ากรอกของรอบนั้น"""
    from .. import backfill as BF
    db = get_db()
    today_ = date.today()

    def _d(k, dflt):
        try:
            return date.fromisoformat(request.args.get(k) or "")
        except ValueError:
            return dflt
    d_to = _d("to", today_)
    d_from = _d("from", d_to - timedelta(days=6))
    data = BF.missing_rounds(db, current_user_id(), d_from, d_to, request.args.get("factory", type=int),
                             request.args.get("form", type=int), request.args.get("mine") == "1")
    return render_template("team/backfill_pick.html", d=data, f_factory=request.args.get("factory", type=int) or 0,
                           f_form=request.args.get("form", type=int) or 0, mine=request.args.get("mine") == "1",
                           max_days=BF.MAX_BACK_DAYS, today=today_)
