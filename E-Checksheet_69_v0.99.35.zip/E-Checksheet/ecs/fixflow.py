"""v0.99.35 สถานะการแก้ไข ("ต้องจัดการตอนนี้" หน้าภาพรวม) — แต่ละรายการถึงขั้นไหน ใครรับผิดชอบ ค้างมานานเท่าไร ขั้นต่อไปคืออะไร

แจ้งเตือน : แจ้งเตือน → รับทราบ → กำลังแก้ไข → แก้ไขแล้ว (รอปิดงาน) — รวมสถานะงานแก้ไข (CAPA) และใบแจ้งซ่อม (UT-CMMS) ที่ผูกอยู่
รอบตรวจ   : ถึงกำหนด → ส่งผลตรวจ → อนุมัติ
เครื่องหยุด : แจ้งหยุด → กำลังซ่อม → เดินเครื่อง — ใบแจ้งซ่อม / งานแก้ไขของเครื่อง · วันคาดเสร็จ
stage (ใช้กรองและนับ): new = ยังไม่มีผู้รับทราบ/ยังไม่เริ่ม · ack = รับทราบแล้ว รอเริ่มแก้ · doing = กำลังแก้ไข · check = แก้ไขแล้ว รอปิด/อนุมัติ
  · plan = หยุดตามแผน/สำรอง · done = ปิดงานแล้ว (ไม่นับในสรุป)"""
from __future__ import annotations

from datetime import date, datetime

from .services import parse_ts

STAGE_TH = {"new": "ยังไม่รับทราบ", "ack": "รับทราบแล้ว", "doing": "กำลังแก้ไข", "check": "รอปิดงาน", "plan": "ตามแผน / สำรอง", "done": "ปิดงานแล้ว"}
STAGE_ORDER = ("new", "ack", "doing", "check", "plan")
ALERT_STEPS = ["แจ้งเตือน", "รับทราบ", "กำลังแก้ไข", "แก้ไขแล้ว"]
ROUND_STEPS = ["ถึงกำหนด", "ส่งผลตรวจ", "อนุมัติ"]
DOWN_STEPS = ["แจ้งหยุด", "กำลังซ่อม", "เดินเครื่อง"]
CAPA_OPEN = ("open", "in_progress", "done")
WO_OPEN = ("pending", "approved", "in_progress")


def age(since, now: datetime) -> str:
    """ระยะเวลาที่ค้าง: 45 นาที · 3 ชม. 20 นาที · 2 วัน 4 ชม."""
    t = parse_ts(since) if isinstance(since, str) else since
    if not t:
        return ""
    m = max(0, int((now - t).total_seconds() // 60))
    if m < 60:
        return f"{m} นาที"
    h, mm = divmod(m, 60)
    if h < 24:
        return f"{h} ชม." + (f" {mm} นาที" if mm else "")
    d, hh = divmod(h, 24)
    return f"{d} วัน" + (f" {hh} ชม." if hh else "")


def _names(db, ids) -> dict:
    ids = sorted({i for i in ids if i})
    if not ids:
        return {}
    return {r["id"]: r["name"] for r in db.execute(f"SELECT id, name FROM users WHERE id IN ({','.join('?' * len(ids))})", ids)}


def _dm(s) -> str:
    s = str(s or "")
    return f"{s[8:10]}/{s[5:7]}" if len(s) >= 10 else ""


def _capa(r, names: dict, today: date) -> dict:
    from .capa import STATUS_TH
    due = r["due_date"] or ""
    late = bool(due and r["status"] in ("open", "in_progress") and due < today.isoformat())
    return {"id": r["id"], "code": r["code"], "status": r["status"], "status_th": STATUS_TH.get(r["status"], r["status"]),
            "owner": names.get(r["owner_id"], ""), "due": _dm(due), "late": late}


def _wo(r) -> dict:
    from .cmms_wo import STATUS_TH
    return {"no": r["wo_number"] or f"#{r['wo_id']}", "status": r["status"], "status_th": STATUS_TH.get(r["status"], r["status"] or "")}


def alerts(db, items: list[dict], now: datetime) -> None:
    """เติม a['fx'] ให้แจ้งเตือนทุกรายการ (แก้ในที่)"""
    if not items:
        return
    ids = [a["id"] for a in items]
    ph = ",".join("?" * len(ids))
    capas = {}
    for r in db.execute(f"""SELECT * FROM cs_actions WHERE alert_id IN ({ph}) AND status<>'cancelled' ORDER BY id""", ids):
        capas[r["alert_id"]] = r                                    # งานล่าสุดของแจ้งเตือนนั้น
    wo_ids = [a["wo_id"] for a in items if a.get("wo_id")]
    wos = {}
    if wo_ids:
        for r in db.execute(f"SELECT * FROM cs_cmms_wo WHERE wo_id IN ({','.join('?' * len(wo_ids))})", wo_ids):
            wos[r["wo_id"]] = r
    names = _names(db, [a.get(k) for a in items for k in ("ack_by", "assigned_to", "resolved_by")]
                   + [c["owner_id"] for c in capas.values()])
    today = now.date()
    for a in items:
        st = a.get("status") or "open"
        step = {"open": 0, "acknowledged": 1, "in_progress": 2, "resolved": 3, "closed": 4}.get(st, 0)
        c = capas.get(a["id"])
        capa = _capa(c, names, today) if c else None
        if capa and step < 3:                                      # งานแก้ไข (CAPA) เดินหน้ากว่าแจ้งเตือน → ใช้ขั้นของงาน
            step = max(step, {"in_progress": 2, "done": 3, "closed": 3}.get(capa["status"], step))
        wo = _wo(wos[a["wo_id"]]) if a.get("wo_id") in wos else None
        if wo and wo["status"] == "in_progress" and step < 2:
            step = 2
        who = names.get(a.get("assigned_to")) or (capa or {}).get("owner") or names.get(a.get("ack_by")) or ""
        if step >= 4:
            stage, label, nxt = "done", "ปิดงานแล้ว", ""
        elif step == 3:
            stage, label, nxt = "check", "แก้ไขแล้ว · รอปิดงาน", "หัวหน้างานตรวจรับและปิดงาน"
            who = names.get(a.get("resolved_by")) or who
        elif step == 2:
            stage, label, nxt = "doing", "กำลังแก้ไข", "แก้ไขให้เสร็จแล้วบันทึกผล"
        elif step == 1:
            stage, label, nxt = "ack", "รับทราบแล้ว · รอเริ่มแก้", "มอบหมายผู้รับผิดชอบ / เปิดงานแก้ไข (CAPA)"
        else:
            stage, label, nxt = "new", "ยังไม่มีผู้รับทราบ", "หัวหน้างาน/ช่างกดรับทราบ"
        a["fx"] = {"kind": "alert", "stage": stage, "steps": ALERT_STEPS, "step": min(step, 4), "label": label, "who": who,
                   "age": age(a.get("created_at"), now), "next": nxt, "capa": capa, "wo": wo,
                   "late": bool(capa and capa["late"])}


def rounds(items: list[dict], now: datetime) -> None:
    """เติม c['fx'] ให้รอบตรวจที่ขาด / ตีกลับ / เลยกำหนด"""
    for c in items:
        st = c.get("status")
        if st == "returned":
            label, nxt, since = "ตีกลับให้แก้ไข · รอส่งใหม่", "ช่างแก้ไขแล้วส่งผลตรวจใหม่", c.get("due_at")
        elif st == "missed":
            label, nxt, since = "ขาดตรวจ · ไม่มีผลส่ง", "บันทึกย้อนหลัง หรือระบุเหตุผล", c.get("due_at")
        else:
            label, nxt, since = "เลยกำหนด · ยังไม่ส่งผล", "ช่างตรวจและส่งผลโดยเร็ว", c.get("due_at")
        c["fx"] = {"kind": "round", "stage": "new", "steps": ROUND_STEPS, "step": 1, "label": label,
                   "who": c.get("inspector_name") or c.get("inspector") or "", "age": age(since, now), "next": nxt,
                   "capa": None, "wo": None, "late": st in ("missed", "overdue")}


def downs(db, items: list[dict], now: datetime) -> None:
    """เติม d['fx'] ให้เครื่องที่หยุด: ใบแจ้งซ่อม/งานแก้ไขที่ยังเปิด · วันคาดเสร็จ"""
    if not items:
        return
    ids = [d["id"] for d in items]
    ph = ",".join("?" * len(ids))
    wos, capas, dts = {}, {}, {}
    for r in db.execute(f"""SELECT * FROM cs_cmms_wo WHERE equipment_id IN ({ph}) AND status IN ({','.join('?' * len(WO_OPEN))})
                            ORDER BY id""", ids + list(WO_OPEN)):
        wos[r["equipment_id"]] = r
    for r in db.execute(f"""SELECT * FROM cs_actions WHERE equipment_id IN ({ph}) AND status IN ({','.join('?' * len(CAPA_OPEN))})
                            ORDER BY id""", ids + list(CAPA_OPEN)):
        capas[r["equipment_id"]] = r
    for r in db.execute(f"""SELECT * FROM cs_downtime WHERE equipment_id IN ({ph}) AND end_at IS NULL ORDER BY start_at""", ids):
        dts[r["equipment_id"]] = r
    names = _names(db, [c["owner_id"] for c in capas.values()] + [r["started_by"] for r in dts.values()])
    today = now.date()
    for d in items:
        dt = dts.get(d["id"])
        wo = _wo(wos[d["id"]]) if d["id"] in wos else None
        capa = _capa(capas[d["id"]], names, today) if d["id"] in capas else None
        until = d.get("down_until") or (dt["expected_end"] if dt else None)
        late = bool(d.get("late"))
        if d.get("cat") == "standby" or (dt and dt["category"] in ("standby", "stop", "pm")):
            cat = (dt["category"] if dt else "standby") or "standby"
            label = {"standby": "สำรอง · ไม่ต้องซ่อม", "stop": "หยุดตามแผนการผลิต", "pm": "PM ตามแผน"}.get(cat, "หยุดตามแผน")
            stage, step, nxt = "plan", None, "เดินเครื่องเมื่อพร้อม แล้วกดเปลี่ยนสถานะเป็นเดิน"
        elif (wo and wo["status"] == "in_progress") or (capa and capa["status"] == "in_progress"):
            stage, step, label, nxt = "doing", 1, "กำลังซ่อม", "ซ่อมเสร็จ → ทดสอบแล้วกดเดินเครื่อง"
        elif capa and capa["status"] == "done":
            stage, step, label, nxt = "check", 2, "ซ่อมเสร็จ · รอเดินเครื่อง", "ทดสอบแล้วกดเปลี่ยนสถานะเป็นเดิน"
        elif wo or capa:
            stage, step, label, nxt = "ack", 1, "เปิดงานซ่อมแล้ว · รอช่างเริ่ม", "ช่างรับงานและเริ่มซ่อม"
        else:
            stage, step, label, nxt = "new", 0, "แจ้งหยุดแล้ว · ยังไม่มีใบงานซ่อม", "เปิดใบแจ้งซ่อม / งานแก้ไข"
        meta_until = (f"คาดเสร็จ {_dm(until)} {str(until)[11:16]}".strip() if until else "")
        d["fx"] = {"kind": "down", "stage": stage, "steps": DOWN_STEPS if step is not None else [], "step": step or 0,
                   "label": label, "who": (capa or {}).get("owner") or (names.get(dt["started_by"], "") if dt else ""),
                   "age": age(d.get("down_since"), now), "next": nxt, "capa": capa, "wo": wo, "until": meta_until,
                   "late": late or bool(capa and capa["late"])}


def summary(fxs: list[dict]) -> list[tuple[str, str, int]]:
    """นับตามขั้นการแก้ไข (เฉพาะที่มี) + เกินกำหนด"""
    out = [(k, STAGE_TH[k], sum(1 for f in fxs if f and f["stage"] == k)) for k in STAGE_ORDER]
    out = [x for x in out if x[2]]
    late = sum(1 for f in fxs if f and f.get("late"))
    if late:
        out.append(("late", "เกินกำหนด", late))
    return out
