"""ecs/cmms_bridge.py — เชื่อม E-Checksheet เข้ากับ UT-CMMS (เข้าสู่ระบบครั้งเดียวใช้ได้ทั้งสองระบบ)

ทำงานเมื่อ CMMS_LINK=1 (portal.py ตั้งให้อัตโนมัติ):
- ผู้ใช้ที่ login ใน UT-CMMS แล้ว เปิด E-Checksheet ได้ทันทีไม่ต้อง login ซ้ำ (อ่าน cookie ของ UT-CMMS แบบตรวจลายเซ็น)
- login ที่หน้า E-Checksheet ด้วยรหัส UT-CMMS → ได้ session ของ UT-CMMS ด้วย (ใช้รหัสเดียวกันทั้งสองระบบ)
- ออกจากระบบฝั่งใดฝั่งหนึ่ง = ออกทั้งสองฝั่ง
- ผู้ใช้ผูกกันด้วย users.legacy_id = id ของผู้ใช้ใน UT-CMMS; ยังไม่มีในระบบ → สร้างให้อัตโนมัติ (บทบาทตามตาราง ROLE_MAP)
- ปิดใช้งานผู้ใช้ใน UT-CMMS → เข้า E-Checksheet ไม่ได้ภายใน 5 นาที; ปิดใน E-Checksheet → เข้าเฉพาะส่วนนี้ไม่ได้

ฐานข้อมูล UT-CMMS ถูกอ่านแบบ read-only เท่านั้น — ไฟล์นี้ไม่แก้ไขข้อมูลของระบบเดิม
"""
from __future__ import annotations

import hashlib
import hmac
import sqlite3
import time
from datetime import timedelta

from flask import Blueprint, current_app, jsonify, redirect, request, session, url_for
from itsdangerous import BadSignature, URLSafeTimedSerializer

from .services import audit, ts

bp = Blueprint("cmms", __name__)

# บทบาท UT-CMMS → บทบาท E-Checksheet (ใช้ตอนสร้างผู้ใช้ครั้งแรก หลังจากนั้นผู้ดูแลปรับได้เองในหน้าผู้ใช้)
ROLE_MAP = {"admin": "admin", "supervisor": "supervisor", "manager": "supervisor",
            "technician": "technician", "user": "viewer"}
RECHECK_SEC = 300
LINKED_PASSWORD = "!cmms"          # รหัสที่ใช้ตรวจไม่ผ่านเสมอ — ผู้ใช้ที่ผูกไว้ต้องใช้รหัสของ UT-CMMS
SKIP_ENDPOINTS = {"static", "mobile.service_worker", "mobile.manifest"}


def enabled() -> bool:
    return bool(current_app.config.get("CMMS_LINK"))


def home_url() -> str:
    return current_app.config.get("CMMS_HOME") or "/"


# ───────────────────────── cookie ของ UT-CMMS ─────────────────────────

def _serializer() -> URLSafeTimedSerializer | None:
    """ตัวเข้ารหัสเดียวกับ session cookie มาตรฐานของ Flask (UT-CMMS ใช้แบบนี้)"""
    secret = current_app.config.get("CMMS_SECRET_KEY")
    if not secret:
        return None
    from flask.json.tag import TaggedJSONSerializer
    return URLSafeTimedSerializer(secret, salt="cookie-session", serializer=TaggedJSONSerializer(),
                                  signer_kwargs={"key_derivation": "hmac", "digest_method": hashlib.sha1})


def _cookie_name() -> str:
    return current_app.config.get("CMMS_COOKIE_NAME") or "session"


def read_cmms_session() -> dict:
    raw = request.cookies.get(_cookie_name())
    ser = _serializer()
    if not raw or ser is None:
        return {}
    try:
        data = ser.loads(raw, max_age=int(timedelta(days=31).total_seconds()))
    except BadSignature:
        return {}
    return data if isinstance(data, dict) else {}


def set_cmms_cookie(resp, cmms_user: dict) -> None:
    ser = _serializer()
    if ser is None:
        return
    value = ser.dumps({"user_id": cmms_user["id"], "role": cmms_user["role"], "username": cmms_user["username"]})
    resp.set_cookie(_cookie_name(), value, httponly=True, samesite="Lax", path="/",
                    secure=bool(current_app.config.get("SECURE_COOKIES")))


def clear_cmms_cookie(resp) -> None:
    resp.delete_cookie(_cookie_name(), path="/")


# ───────────────────────── ฐานข้อมูล UT-CMMS (อ่านอย่างเดียว) ─────────────────────────

def _cmms_db() -> sqlite3.Connection | None:
    path = current_app.config.get("CMMS_DATABASE")
    if not path:
        return None
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10)
    except sqlite3.Error:
        return None
    con.row_factory = sqlite3.Row
    return con


def cmms_user_by_id(uid) -> dict | None:
    con = _cmms_db()
    if con is None:
        return None
    try:
        row = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        return dict(row) if row else None
    except sqlite3.Error:
        return None
    finally:
        con.close()


def cmms_check_password(username: str, password: str) -> dict | None:
    """ตรวจรหัสผ่านกับตารางผู้ใช้ของ UT-CMMS (รูปแบบ SHA-256 ของระบบเดิม)"""
    con = _cmms_db()
    if con is None or not username:
        return None
    try:
        row = con.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE AND active=1", (username,)).fetchone()
    except sqlite3.Error:
        row = None
    finally:
        con.close()
    if not row:
        return None
    digest = hashlib.sha256((password or "").encode()).hexdigest()
    return dict(row) if hmac.compare_digest(str(row["password"]).lower(), digest) else None


def cmms_username_exists(username: str) -> bool:
    """v0.99.25 มีชื่อผู้ใช้นี้ใน UT-CMMS หรือไม่ (ใช้ตอนสมัครเอง — ผู้ใช้ UT-CMMS ใช้รหัสเดิมเข้าได้เลย)"""
    con = _cmms_db()
    if con is None or not username:
        return False
    try:
        return bool(con.execute("SELECT 1 FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone())
    except sqlite3.Error:
        return False
    finally:
        con.close()


# ───────────────────────── ผูกผู้ใช้ ─────────────────────────

class LinkError(Exception):
    pass


def link_user(db, cu: dict) -> dict:
    """หา/สร้างผู้ใช้ E-Checksheet ที่ผูกกับผู้ใช้ UT-CMMS แล้วอัปเดตชื่อ/อีเมล/โทรศัพท์ให้ตรงกัน"""
    row = db.execute("SELECT * FROM users WHERE legacy_id=?", (cu["id"],)).fetchone()
    if not row:
        row = db.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (cu["username"],)).fetchone()
        if row and row["legacy_id"] and row["legacy_id"] != cu["id"]:
            raise LinkError("ชื่อผู้ใช้นี้ผูกกับบัญชี UT-CMMS อื่นอยู่แล้ว — ติดต่อผู้ดูแลระบบ")
        if row and row["username"] == "_auto":
            raise LinkError("ชื่อผู้ใช้นี้สงวนไว้สำหรับระบบ")
        if row and not row["legacy_id"] and dict(row).get("signup_status") in ("pending", "rejected"):
            # v0.99.25 คำขอสมัครเองที่ยังไม่อนุมัติ (ไม่มีข้อมูลผูก) ใช้ชื่อซ้ำกับผู้ใช้ UT-CMMS ตัวจริง → ลบคำขอ แล้วสร้างบัญชีที่ผูกให้เจ้าของจริง
            db.execute("DELETE FROM users WHERE id=?", (row["id"],))
            audit(db, None, "delete", "users", row["id"], before={"username": row["username"], "signup_status": row["signup_status"]},
                  after={"reason": "ชื่อซ้ำผู้ใช้ UT-CMMS ที่เข้าสู่ระบบ"})
            row = None
    now = ts()
    if row:
        db.execute("""UPDATE users SET legacy_id=?, name=?, email=COALESCE(NULLIF(?, ''), email),
                      phone=COALESCE(NULLIF(?, ''), phone), last_login_at=?, updated_at=? WHERE id=?""",
                   (cu["id"], cu.get("name") or row["name"], cu.get("email") or "", cu.get("phone") or "",
                    now, now, row["id"]))
        uid = row["id"]
        action = "cmms_link" if not row["legacy_id"] else "login"
    else:
        role = ROLE_MAP.get(cu.get("role") or "", "viewer")
        uid = db.execute("""INSERT INTO users(username, password, name, role, email, phone, active, must_change_pw,
                            legacy_id, last_login_at, created_at, updated_at) VALUES (?,?,?,?,?,?,1,0,?,?,?,?)""",
                         (cu["username"], LINKED_PASSWORD, cu.get("name") or cu["username"], role,
                          cu.get("email") or "", cu.get("phone") or "", cu["id"], now, now, now)).lastrowid
        action = "cmms_provision"
    audit(db, uid, action, "users", uid, after={"cmms_user_id": cu["id"], "cmms_username": cu["username"]})
    db.commit()
    return dict(db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone())


def start_session(user: dict, cmms_uid) -> None:
    session.clear()
    session.update(user_id=user["id"], role=user["role"], name=user["name"], factory_id=user["factory_id"],
                   must_change_pw=False, cmms_uid=cmms_uid, cmms_checked=time.time())


# ───────────────────────── ทำงานทุก request ─────────────────────────

def sync_session():
    """เรียกใน before_request: ทำให้สถานะ login ของ E-Checksheet ตรงกับ UT-CMMS"""
    if not enabled() or request.endpoint in SKIP_ENDPOINTS:
        return None
    from .db import get_db
    cm_uid = read_cmms_session().get("user_id")
    if "user_id" in session:
        linked = session.get("cmms_uid")
        if not linked:
            return None                       # บัญชีเฉพาะของ E-Checksheet (login ด้วยรหัสของระบบนี้)
        if linked != cm_uid:
            session.clear()                   # ออกจาก UT-CMMS แล้ว หรือเปลี่ยนผู้ใช้
        elif time.time() - float(session.get("cmms_checked") or 0) > RECHECK_SEC:
            cu = cmms_user_by_id(cm_uid)
            u = get_db().execute("SELECT active, role, factory_id FROM users WHERE id=?", (session["user_id"],)).fetchone()
            if not cu or not cu.get("active") or not u or not u["active"]:
                session.clear()
            else:
                session.update(cmms_checked=time.time(), role=u["role"], factory_id=u["factory_id"])
            return None
        else:
            return None
    if not cm_uid:
        return None
    cu = cmms_user_by_id(cm_uid)
    if not cu or not cu.get("active"):
        return None
    db = get_db()
    known = db.execute("SELECT active FROM users WHERE legacy_id=?", (cm_uid,)).fetchone()
    if known and not known["active"]:
        return None                           # ปิดสิทธิ์ E-Checksheet ไว้ — ไม่ต้องเขียนฐานข้อมูลทุก request
    try:
        user = link_user(db, cu)
    except LinkError:
        return None
    if user["active"]:
        start_session(user, cm_uid)
    return None


# ───────────────────────── API สำหรับปุ่มลัดในหน้า UT-CMMS ─────────────────────────

@bp.route("/api/portal/badge")
def badge():
    if "user_id" not in session:
        return jsonify({"logged_in": False})      # 200 เพื่อไม่ให้หน้า UT-CMMS มี error ใน console
    from .db import get_db
    db = get_db()
    alerts = db.execute("SELECT COUNT(*) FROM cs_alerts WHERE status IN ('open','acknowledged','in_progress')").fetchone()[0]
    today = ts()[:10]
    rounds = db.execute("""SELECT COUNT(*) FROM cs_rounds WHERE status IN ('pending','in_progress','overdue')
                           AND substr(due_at,1,10)<=?""", (today,)).fetchone()[0]
    try:
        unread = db.execute("SELECT COUNT(*) FROM cs_notifications WHERE user_id=? AND read_at IS NULL",
                            (session["user_id"],)).fetchone()[0]
    except sqlite3.Error:
        unread = 0
    return jsonify({"logged_in": True, "name": session.get("name"), "alerts": alerts, "rounds": rounds,
                    "unread": unread, "url": url_for("index")})


@bp.route("/legacy/checksheet/<int:cmms_eq_id>")
def legacy_qr(cmms_eq_id):
    """QR เดิมของ UT-CMMS (/checksheet/<id>) → หน้า QR ของเครื่องเดียวกันใน E-Checksheet"""
    from .db import get_db
    row = get_db().execute("SELECT qr_token FROM equipment WHERE legacy_id=? AND active=1", (cmms_eq_id,)).fetchone()
    if not row:
        # เครื่องนี้ยังไม่อยู่ในระบบใหม่ → เปิดหน้าสแกน/ค้นหาเครื่องของ E-Checksheet (ไม่กลับไปใช้ระบบเดิม)
        return redirect(url_for("mobile.scan"))
    return redirect(url_for("mobile.equipment_qr", token=row["qr_token"]))
