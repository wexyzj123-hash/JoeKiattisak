"""ecs/scorecard.py — v0.51 สรุปผลงานรายคนรายสัปดาห์ (จันทร์–อาทิตย์)

ต่อช่าง: วันเข้ากะ · รอบในกะที่รับผิดชอบ (ตามตารางกะ + โรงงานที่มอบหมาย) และทำครบกี่ % · ขาดตรวจในกะ
         · ตรวจเอง (ครั้ง) · ตรงเวลา % · NG ที่พบ · ถูกตีกลับ · เวลาเฉลี่ยต่อใบ
ส่งอัตโนมัติทุกสัปดาห์ถึงหัวหน้างาน/ผู้ดูแลระบบ (ตั้งวัน-เวลาได้) — ข้อความสั้น + ลิงก์หน้ารายละเอียด
"""
from __future__ import annotations

import io
import json
from datetime import date, datetime, timedelta

from . import roster as RO
from . import services as S
from .services import parse_ts, ts

DEFAULTS = {"enabled": True, "weekday": 0, "time": "08:30"}      # จันทร์ 08:30 (สรุปสัปดาห์ที่แล้ว)
WD_TH = ("จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์", "เสาร์", "อาทิตย์")


def get_settings(db) -> dict:
    cfg = dict(DEFAULTS)
    row = db.execute("SELECT value FROM cs_meta WHERE key='scorecard'").fetchone()
    if row and row[0]:
        try:
            cfg.update({k: v for k, v in json.loads(row[0]).items() if k in DEFAULTS})
        except ValueError:
            pass
    return cfg


def save_settings(db, data: dict, actor_id) -> dict:
    try:
        wd = max(0, min(6, int(data.get("weekday") or 0)))
        hh, mm = (int(x) for x in str(data.get("time") or "08:30").split(":"))
        assert 0 <= hh < 24 and 0 <= mm < 60
    except (ValueError, AssertionError):
        raise S.ValidationError("วัน/เวลาส่งไม่ถูกต้อง") from None
    cfg = {"enabled": data.get("enabled") in (1, True, "1", "on", "true"), "weekday": wd, "time": f"{hh:02d}:{mm:02d}"}
    db.execute("INSERT INTO cs_meta(key, value) VALUES('scorecard', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(cfg),))
    S.audit(db, actor_id, "update", "cs_meta", None, after={"scorecard": cfg})
    return cfg


def week_start(d: date) -> date:
    return d - timedelta(days=d.weekday())


def build(db, monday: date, fids=None) -> dict:
    start = datetime.combine(monday, datetime.min.time())
    end = start + timedelta(days=7)
    R = RO.load(db, monday - timedelta(days=1), monday + timedelta(days=8))
    members = [p for p in RO.team(db) if p["role"] == "technician"]
    if fids:
        members = [p for p in members if p["factories"] is None or any(f in fids for f in p["factories"])]
    fac_cond, fac_p = "", []
    if fids:
        fac_cond = f" AND f.factory_id IN ({','.join('?' * len(fids))})"
        fac_p = list(fids)
    rounds = [dict(r) for r in db.execute(f"""
        SELECT r.id, r.status, r.due_at, r.deadline_at, f.factory_id, COALESCE(e.run_status,'running') AS run_status
        FROM cs_rounds r JOIN cs_schedules sc ON sc.id=r.schedule_id JOIN cs_forms f ON f.id=r.form_id
        LEFT JOIN equipment e ON e.id=f.equipment_id
        WHERE f.active=1 AND r.due_at>=? AND r.due_at<? AND r.status<>'skipped'{fac_cond}""", [ts(start), ts(end)] + fac_p)]
    stats = {p["id"]: {"id": p["id"], "name": p["name"], "days": 0, "resp": 0, "resp_done": 0, "missed": 0, "subs": 0,
                       "on_time": 0, "late": 0, "ng": 0, "returned": 0, "dur": []} for p in members}
    filt = RO.get_settings(db)["filter"]
    for p in members:
        stats[p["id"]]["days"] = sum(1 for i in range(7) if RO.windows(R, p["id"], monday + timedelta(days=i)))
    for r in rounds:
        due, dl = parse_ts(r["due_at"]), parse_ts(r["deadline_at"])
        pool = [p for p in members if RO.in_scope(p, r["factory_id"])]
        resp = [p for p in pool if RO.covers(R, p["id"], due, dl)] if filt else pool
        resp = resp or pool
        done = r["status"] in ("done_on_time", "done_late")
        for p in resp:
            st = stats[p["id"]]
            st["resp"] += 1
            st["resp_done"] += done
            st["missed"] += r["status"] == "missed"
    ids = list(stats)
    if ids:
        for s in db.execute(f"""
            SELECT s.inspector_id, s.ng_count, s.approval_status, s.duration_sec, r.status AS round_status
            FROM cs_submissions s LEFT JOIN cs_rounds r ON r.id=s.round_id JOIN cs_forms f ON f.id=s.form_id
            WHERE s.inspector_id IN ({','.join('?' * len(ids))}) AND s.finished_at>=? AND s.finished_at<?
              AND COALESCE(s.source,'')<>'auto'{fac_cond}""", ids + [ts(start), ts(end)] + fac_p):
            st = stats[s["inspector_id"]]
            st["subs"] += 1
            st["ng"] += bool(s["ng_count"])
            st["returned"] += s["approval_status"] == "rejected"
            if s["round_status"] == "done_on_time":
                st["on_time"] += 1
            elif s["round_status"] == "done_late":
                st["late"] += 1
            if s["duration_sec"] and 0 < s["duration_sec"] < 4 * 3600:
                st["dur"].append(s["duration_sec"])
    rows = []
    for st in stats.values():
        dur = st.pop("dur")
        st["avg_min"] = round(sum(dur) / len(dur) / 60, 1) if dur else None
        st["cover_pct"] = round(100 * st["resp_done"] / st["resp"]) if st["resp"] else None
        rnd = st["on_time"] + st["late"]
        st["on_time_pct"] = round(100 * st["on_time"] / rnd) if rnd else None
        st["flag"] = "ng" if (st["missed"] and st["cover_pct"] is not None and st["cover_pct"] < 80) else \
            ("warn" if st["missed"] or (st["on_time_pct"] is not None and st["on_time_pct"] < 90) else "ok")
        rows.append(st)
    rows.sort(key=lambda x: (-(x["missed"]), x["cover_pct"] if x["cover_pct"] is not None else 101, x["name"]))
    tot_rounds = len(rounds)
    tot_done = sum(1 for r in rounds if r["status"] in ("done_on_time", "done_late"))
    return {"monday": monday, "sunday": monday + timedelta(days=6), "rows": rows, "rounds": tot_rounds, "done": tot_done,
            "missed": sum(1 for r in rounds if r["status"] == "missed"),
            "pct": round(100 * tot_done / tot_rounds) if tot_rounds else None, "source": R["source"], "filter": filt}


def to_xlsx(sc: dict) -> bytes:
    from openpyxl import Workbook
    from .reports import _sheet
    wb = Workbook()
    head = ["ช่าง", "วันเข้ากะ", "รอบในกะ", "ทำครบ %", "ขาดตรวจในกะ", "ตรวจเอง (ครั้ง)", "ตรงเวลา %", "ตรวจล่าช้า",
            "พบ NG (ใบ)", "ถูกตีกลับ", "เวลาเฉลี่ย (นาที)"]
    rows = [[r["name"], r["days"], r["resp"], r["cover_pct"], r["missed"], r["subs"], r["on_time_pct"], r["late"], r["ng"],
             r["returned"], r["avg_min"]] for r in sc["rows"]]
    _sheet(wb, True, "สรุปผลงานรายคน", f"สัปดาห์ {sc['monday']:%d/%m/%Y} – {sc['sunday']:%d/%m/%Y} · รอบทั้งหมด {sc['rounds']} · "
           f"ตรวจแล้ว {sc['done']} · ขาดตรวจ {sc['missed']}", head, rows, [26, 10, 10, 10, 12, 12, 10, 10, 10, 10, 12],
           highlight=lambda r: "ng" if r[4] and (r[3] or 0) < 80 else ("warn" if r[4] else None), sheet_name="ผลงานรายคน")
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def text(sc: dict) -> tuple[str, str]:
    subject = f"📊 ผลงานช่างสัปดาห์ {sc['monday']:%d/%m}–{sc['sunday']:%d/%m}: ตรวจแล้ว {sc['done']}/{sc['rounds']} รอบ" + \
        (f" ({sc['pct']}%)" if sc["pct"] is not None else "") + f" · ขาดตรวจ {sc['missed']}"
    lines = []
    for r in sc["rows"][:20]:
        mark = "🔴" if r["flag"] == "ng" else ("🟡" if r["flag"] == "warn" else "🟢")
        lines.append(f"{mark} {r['name']}: ตรวจ {r['subs']} · ทำครบ {'-' if r['cover_pct'] is None else str(r['cover_pct']) + '%'}"
                     f" · ขาดในกะ {r['missed']} · ตรงเวลา {'-' if r['on_time_pct'] is None else str(r['on_time_pct']) + '%'} · NG {r['ng']}")
    return subject, "\n".join(lines) or "ไม่มีข้อมูลช่างในสัปดาห์นี้"


def weekly_send(db, now: datetime | None = None, base_url: str = "", force: bool = False) -> bool:
    cfg = get_settings(db)
    if not cfg["enabled"] and not force:
        return False
    now = now or S.now_dt()
    hh, mm = (int(x) for x in cfg["time"].split(":"))
    if not force and (now.weekday() != cfg["weekday"] or (now.hour, now.minute) < (hh, mm)):
        return False
    monday = week_start(now.date()) - timedelta(days=7)               # สัปดาห์ที่แล้ว
    key = f"scorecard:{monday.isoformat()}"
    if not force and db.execute("SELECT 1 FROM cs_meta WHERE key='scorecard_sent' AND value=?", (key,)).fetchone():
        return False
    sc = build(db, monday)
    subject, body = text(sc)
    users = [dict(u) for u in db.execute("SELECT * FROM users WHERE active=1 AND role IN ('admin','supervisor')")]
    from . import notify as N
    if users:
        N._deliver(db, N.get_settings(db), base_url, {"users": users, "groups": []}, kind="summary", subject=subject, body=body,
                   path=f"/team/scorecard?week={monday.isoformat()}", severity="info", ref_key=key + (":f" if force else ""), now=now)
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('scorecard_sent', ?)", (key,))
    return True


# ───────────────────────── v0.99.24 ผลงานรายคน (เจาะลึก 1 คน) ─────────────────────────

def person(db, uid: int, d_from: date, d_to: date, fids=None) -> dict | None:
    """ผลงานของช่าง 1 คนในช่วงวันที่: ตัวเลขสรุป · รอบในกะที่รับผิดชอบ/ขาด · เครื่องที่ตรวจ · ผลตรวจทุกใบ · NG ที่พบ · รายวัน · กะ"""
    u = db.execute("SELECT id, name, role, factory_id, COALESCE(position,'') AS position, active FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        return None
    u = dict(u)
    start = datetime.combine(d_from, datetime.min.time())
    end = datetime.combine(d_to + timedelta(days=1), datetime.min.time())
    fac_cond, fac_p = "", []
    if fids:
        fac_cond = f" AND f.factory_id IN ({','.join('?' * len(fids))})"
        fac_p = list(fids)
    subs = [dict(r) for r in db.execute(f"""
        SELECT s.id, s.form_id, s.finished_at, s.duration_sec, s.ng_count, s.warn_count, s.status, s.approval_status,
               s.round_id, r.status AS round_status, r.due_at, f.name AS form_name, f.code AS form_code,
               e.id AS eq_id, e.code AS eq_code, e.name AS eq_name, fa.name AS factory_name, ar.name AS area_name,
               (SELECT COUNT(*) FROM cs_photos p WHERE p.submission_id=s.id) AS photos
        FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id LEFT JOIN cs_rounds r ON r.id=s.round_id
        LEFT JOIN equipment e ON e.id=COALESCE(s.equipment_id, f.equipment_id) LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN areas ar ON ar.id=e.area_id
        WHERE s.inspector_id=? AND s.status<>'superseded' AND s.finished_at>=? AND s.finished_at<?{fac_cond}
        ORDER BY s.finished_at DESC""", [uid, ts(start), ts(end)] + fac_p)]
    days = []
    d = d_from
    per_day = {}
    for s in subs:
        x = per_day.setdefault(s["finished_at"][:10], {"n": 0, "ng": 0})
        x["n"] += 1
        x["ng"] += bool(s["ng_count"])
    while d <= d_to:
        x = per_day.get(d.isoformat(), {"n": 0, "ng": 0})
        days.append({"iso": d.isoformat(), "d": d.day, "wd": d.weekday(), "n": x["n"], "ng": x["ng"]})
        d += timedelta(days=1)
    # เครื่องที่ตรวจ
    mach = {}
    for s in subs:
        k = s["eq_id"] or ("f", s["form_id"])
        m = mach.setdefault(k, {"eq_id": s["eq_id"], "eq_code": s["eq_code"] or s["form_code"], "eq_name": s["eq_name"] or s["form_name"],
                                "form_id": s["form_id"], "form_name": s["form_name"], "where": " › ".join(x for x in (s["factory_name"], s["area_name"]) if x),
                                "n": 0, "ng": 0, "warn": 0, "late": 0, "last": s["finished_at"], "dur": []})
        m["n"] += 1
        m["ng"] += bool(s["ng_count"])
        m["warn"] += bool(s["warn_count"]) and not s["ng_count"]
        m["late"] += s["round_status"] == "done_late"
        if s["duration_sec"] and 0 < s["duration_sec"] < 4 * 3600:
            m["dur"].append(s["duration_sec"])
    machines = []
    for m in mach.values():
        dur = m.pop("dur")
        m["avg_sec"] = round(sum(dur) / len(dur)) if dur else None
        machines.append(m)
    machines.sort(key=lambda m: (-m["n"], m["eq_code"] or ""))
    # NG ที่พบ (รายหัวข้อ)
    ids = [s["id"] for s in subs if s["ng_count"] or s["warn_count"]]
    findings = []
    for i in range(0, len(ids), 500):
        part = ids[i:i + 500]
        findings += [dict(r) for r in db.execute(f"""
            SELECT a.submission_id AS sid, a.judgement, a.value_num, a.value_text, a.remark, it.name AS item_name, it.unit,
                   it.min_value, it.max_value, s.finished_at, e.code AS eq_code, f.name AS form_name
            FROM cs_answers a JOIN cs_form_items it ON it.id=a.item_id JOIN cs_submissions s ON s.id=a.submission_id
            JOIN cs_forms f ON f.id=s.form_id LEFT JOIN equipment e ON e.id=COALESCE(s.equipment_id, f.equipment_id)
            WHERE a.submission_id IN ({','.join('?' * len(part))}) AND a.judgement IN ('ng','warn')""", part)]
    findings.sort(key=lambda x: x["finished_at"], reverse=True)
    # รอบในกะที่รับผิดชอบ (หลักเดียวกับหน้าสรุปรายสัปดาห์)
    R = RO.load(db, d_from - timedelta(days=1), d_to + timedelta(days=1))
    me = next((p for p in RO.team(db) if p["id"] == uid), None)
    filt = RO.get_settings(db)["filter"]
    resp, resp_done, missed_rounds = 0, 0, []
    duty_days = 0
    if me and me["role"] == "technician":
        members = [p for p in RO.team(db) if p["role"] == "technician"]
        duty_days = sum(1 for i in range((d_to - d_from).days + 1) if RO.windows(R, uid, d_from + timedelta(days=i)))
        for r in db.execute(f"""
            SELECT r.id, r.status, r.due_at, r.deadline_at, f.factory_id, f.name AS form_name, e.code AS eq_code
            FROM cs_rounds r JOIN cs_schedules sc ON sc.id=r.schedule_id JOIN cs_forms f ON f.id=r.form_id
            LEFT JOIN equipment e ON e.id=f.equipment_id
            WHERE f.active=1 AND r.due_at>=? AND r.due_at<? AND r.status<>'skipped'{fac_cond}
            ORDER BY r.due_at DESC""", [ts(start), ts(end)] + fac_p):
            if not RO.in_scope(me, r["factory_id"]):
                continue
            due, dl = parse_ts(r["due_at"]), parse_ts(r["deadline_at"])
            pool = [p for p in members if RO.in_scope(p, r["factory_id"])]
            who = ([p for p in pool if RO.covers(R, p["id"], due, dl)] if filt else pool) or pool
            if not any(p["id"] == uid for p in who):
                continue
            resp += 1
            resp_done += r["status"] in ("done_on_time", "done_late")
            if r["status"] == "missed":
                missed_rounds.append(dict(r))
    # ตัวเลขสรุป
    on_time = sum(1 for s in subs if s["round_status"] == "done_on_time")
    late = sum(1 for s in subs if s["round_status"] == "done_late")
    dur = [s["duration_sec"] for s in subs if s["duration_sec"] and 0 < s["duration_sec"] < 4 * 3600]
    hours = [0] * 24
    for s in subs:
        try:
            hours[int(s["finished_at"][11:13])] += 1
        except ValueError:
            pass
    day_n = sum(hours[6:18])
    k = {"subs": len(subs), "on_time": on_time, "late": late, "off_round": sum(1 for s in subs if not s["round_id"]),
         "on_time_pct": round(100 * on_time / (on_time + late)) if on_time + late else None,
         "ng_subs": sum(1 for s in subs if s["ng_count"]), "ng_items": sum(1 for f in findings if f["judgement"] == "ng"),
         "warn_items": sum(1 for f in findings if f["judgement"] == "warn"),
         "returned": sum(1 for s in subs if s["approval_status"] == "rejected" or s["status"] == "returned"),
         "approved": sum(1 for s in subs if s["approval_status"] == "approved"),
         "pending": sum(1 for s in subs if s["approval_status"] == "pending" and s["status"] in ("submitted", "returned")),
         "avg_sec": round(sum(dur) / len(dur)) if dur else None, "fast": sum(1 for x in dur if x < 30),
         "photos": sum(s["photos"] or 0 for s in subs), "machines": len(machines),
         "work_days": sum(1 for x in days if x["n"]), "duty_days": duty_days,
         "resp": resp, "resp_done": resp_done, "missed": len(missed_rounds),
         "cover_pct": round(100 * resp_done / resp) if resp else None,
         "day_shift": day_n, "night_shift": len(subs) - day_n}
    return {"user": u, "d_from": d_from, "d_to": d_to, "k": k, "days": days, "days_max": max([x["n"] for x in days] + [1]),
            "machines": machines, "subs": subs, "findings": findings, "missed": missed_rounds, "hours": hours,
            "source": R["source"], "filter": filt}
