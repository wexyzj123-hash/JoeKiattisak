/* v0.99.26 พื้นหลังเคลื่อนไหว "Utility 4.0" ทุกหน้า (ฉากเดียวกับหน้าเข้าสู่ระบบ แบบเบา: 30 fps · ความละเอียด 1x · ไม่มีเรดาร์)
   อยู่หลังเนื้อหาทั้งหมด เห็นเฉพาะพื้นที่ว่าง · เปิด/ปิดได้ที่เมนูชื่อผู้ใช้ (จำในเครื่อง) · จอเล็ก/ลดภาพเคลื่อนไหว = ปิดเป็นค่าเริ่มต้น */
(function () {
  'use strict';
  const root = document.documentElement, layer = document.getElementById('world');
  if (!layer || !window.ECSScene) return;
  const KEY = 'ecs_world';
  const get = () => { try { return localStorage.getItem(KEY); } catch (e) { return null; } };
  const put = (v) => { try { localStorage.setItem(KEY, v); } catch (e) { /* */ } };
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const small = () => window.innerWidth < 760;
  const wanted = () => { const v = get(); return v === '1' || (v === null && !reduce && !small()); };
  // ธีมสว่าง → ภาพจางลง (อ่านง่าย)
  function tone() {
    const m = getComputedStyle(document.body).backgroundColor.match(/\d+(\.\d+)?/g) || [0, 0, 0];
    const lum = (0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2]) / 255;
    root.classList.toggle('world-light', lum > 0.6);
  }
  let scene = null;
  function apply() {
    const on = wanted();
    root.classList.toggle('world-on', on);
    document.querySelectorAll('[data-world-toggle]').forEach((b) => { b.setAttribute('aria-pressed', on); b.querySelector('b') && (b.querySelector('b').textContent = on ? 'เปิด' : 'ปิด'); });
    if (on) { tone(); if (!scene) scene = ECSScene(document.getElementById('worldFx'), { keep: '', maxNodes: 16, density: 110000, fps: 30, dpr: 1, radar: false, labels: false }); else scene.start(); }
    else if (scene) scene.stop();
  }
  document.addEventListener('click', (e) => {
    const b = e.target.closest && e.target.closest('[data-world-toggle]'); if (!b) return;
    e.preventDefault(); put(wanted() ? '0' : '1'); apply();
  });
  new MutationObserver(() => { if (root.classList.contains('world-on')) tone(); }).observe(root, { attributes: true, attributeFilter: ['data-theme'] });
  apply();
})();
