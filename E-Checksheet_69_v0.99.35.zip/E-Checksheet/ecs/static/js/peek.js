/* v0.99.17 ป้ายลอยข้อมูลเครื่อง — ชี้ (หรือโฟกัสคีย์บอร์ด) ที่รหัสเครื่องตรงไหนก็ได้ในระบบ
   → สถานะเดิน/หยุด · รอบตรวจวันนี้ · ค่าล่าสุดของหัวข้อสำคัญ + กราฟเล็ก 7 จุดล่าสุด · ลิงก์ประวัติเครื่อง
   ใช้ข้อมูลเดียวกับแผงดูต่อ (/api/equipment/<id>/drill) · เฉพาะอุปกรณ์ที่มีเมาส์ (จอสัมผัสไม่ขึ้น) */
(function () {
  'use strict';
  if (!window.fetch || !window.matchMedia || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
  const U = window.U || ((p) => p);
  const esc = (x) => String(x == null ? '' : x).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const SKIP = 'input, textarea, select, .pk, .pal, .sbf, .od, .lt-stack, .tv-lamp, script, style, svg';
  let codes = null, re = null, tip = null, cur = null, showT = 0, hideT = 0;
  const cache = new Map();
  async function loadCodes() {
    if (codes) return codes;
    try { const c = sessionStorage.getItem('peek_codes'); if (c) { const o = JSON.parse(c); if (o.t > Date.now() - 300000) codes = o.d; } } catch (e) { /* */ }
    if (!codes) {
      const r = await fetch(U('/api/equipment/codes'), { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      if (!r.ok) throw new Error(r.status);
      codes = await r.json();
      try { sessionStorage.setItem('peek_codes', JSON.stringify({ t: Date.now(), d: codes })); } catch (e) { /* */ }
    }
    const keys = Object.keys(codes).sort((a, b) => b.length - a.length).map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    re = keys.length ? new RegExp('^(?:' + keys.join('|') + ')(?![A-Za-z0-9_-])') : null;
    return codes;
  }
  // องค์ประกอบที่ข้อความ "ขึ้นต้นด้วยรหัสเครื่อง" และสั้น (ไม่ใช่ย่อหน้ายาว)
  function codeOf(el) {
    if (!re || !el || el.nodeType !== 1 || el.closest(SKIP)) return null;
    for (let n = el, d = 0; n && d < 3; n = n.parentElement, d++) {
      if (n.closest(SKIP)) return null;
      const t = (n.textContent || '').trim();
      if (t.length > 70) break;
      const m = re.exec(t); if (m) return { el: n, code: m[0] };
    }
    return null;
  }
  function spark(vals, lo, hi) {
    const v = vals.filter((x) => typeof x === 'number').slice(-7); if (v.length < 2) return '';
    let a = Math.min(...v), b = Math.max(...v);
    if (lo != null) a = Math.min(a, lo); if (hi != null) b = Math.max(b, hi); if (a === b) { a -= 1; b += 1; }
    const W = 92, H = 26, x = (i) => (i / (v.length - 1)) * (W - 4) + 2, y = (n) => H - 3 - ((n - a) / (b - a)) * (H - 6);
    const band = lo != null && hi != null ? '<rect x="0" y="' + y(hi).toFixed(1) + '" width="' + W + '" height="' + Math.max(1, y(lo) - y(hi)).toFixed(1) + '" class="pk-band"/>' : '';
    return '<svg class="pk-sp" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true">' + band +
      '<polyline points="' + v.map((n, i) => x(i).toFixed(1) + ',' + y(n).toFixed(1)).join(' ') + '"/><circle cx="' + x(v.length - 1).toFixed(1) + '" cy="' + y(v[v.length - 1]).toFixed(1) + '" r="2.6"/></svg>';
  }
  function html(d) {
    const m = d.machine, down = m.run_status === 'down';
    const done = d.rounds.filter((r) => /^done_/.test(r.status)).length;
    const J = { ng: ['ไม่ผ่าน', 'ng'], warn: ['เตือน', 'warn'], ok: ['ปกติ', 'ok'] };
    const items = d.items.filter((i) => i.last != null).slice(0, 4);
    return '<div class="pk-h"><b>' + esc(m.code) + '</b><span class="pk-st ' + (down ? 'down' : 'run') + '">' + (down ? 'หยุดอยู่' : 'เดินเครื่อง') + '</span></div>' +
      '<div class="pk-n">' + esc(m.name) + '</div><div class="pk-m">' + esc([m.factory_name, m.area_name].filter(Boolean).join(' · ')) + '</div>' +
      (down ? '<div class="pk-down">' + esc(m.down_reason || 'แจ้งหยุด') + (m.down_since ? ' · ตั้งแต่ ' + esc(m.down_since.slice(5, 16)) : '') + '</div>' : '') +
      '<div class="pk-r"><span>รอบตรวจวันนี้</span><b>' + done + ' / ' + d.rounds.length + '</b></div>' +
      (items.length ? '<ul class="pk-items">' + items.map((i) => { const j = J[i.judgement] || ['', ''];
        return '<li><span class="pk-in">' + esc(i.name) + '</span>' + spark(i.values || [], i.min_value, i.max_value) +
          '<b class="' + j[1] + '">' + esc(i.last) + (i.unit ? ' <small>' + esc(i.unit) + '</small>' : '') + '</b></li>'; }).join('') + '</ul>'
        : '<div class="pk-m">ยังไม่มีค่าที่ตรวจ</div>') +
      '<div class="pk-l"><a href="' + esc(d.links.m360) + '">ประวัติเครื่อง 360°</a>' + (d.links.latest ? '<a href="' + esc(d.links.latest) + '">ผลตรวจล่าสุด</a>' : '') + '</div>';
  }
  function place(el) {
    const r = el.getBoundingClientRect(), w = tip.offsetWidth, h = tip.offsetHeight, m = 10;
    let x = Math.min(Math.max(m, r.left), innerWidth - w - m), y = r.bottom + 8;
    if (y + h > innerHeight - m) y = Math.max(m, r.top - h - 8);
    tip.style.left = x + 'px'; tip.style.top = y + 'px';
  }
  async function show(hit) {
    const id = codes[hit.code]; if (!id) return;
    if (!tip) { tip = document.createElement('div'); tip.className = 'pk'; tip.setAttribute('role', 'tooltip'); tip.id = 'pkTip'; document.body.appendChild(tip);
      tip.addEventListener('mouseenter', () => clearTimeout(hideT)); tip.addEventListener('mouseleave', hide); }
    cur = hit;
    let d = cache.get(id);
    if (!d || d.t < Date.now() - 60000) {
      tip.innerHTML = '<div class="pk-h"><b>' + esc(hit.code) + '</b></div><div class="pk-m">กำลังโหลด…</div>'; tip.classList.add('in'); place(hit.el);
      try { const r = await fetch(U('/api/equipment/' + id + '/drill'), { credentials: 'same-origin', headers: { Accept: 'application/json' } });
        if (!r.ok) throw new Error(r.status); d = { t: Date.now(), j: await r.json() }; cache.set(id, d); } catch (e) { hide(); return; }
      if (cur !== hit) return;
    }
    tip.innerHTML = html(d.j); tip.classList.add('in'); place(hit.el);
    hit.el.setAttribute('aria-describedby', 'pkTip');
  }
  function hide() {
    clearTimeout(showT);
    if (cur && cur.el) cur.el.removeAttribute('aria-describedby');
    cur = null; if (tip) tip.classList.remove('in');
  }
  function arm(target) {
    const hit = codeOf(target);
    if (hit && cur && hit.el === cur.el) { clearTimeout(hideT); return; }
    clearTimeout(showT);
    if (!hit) { if (cur) { clearTimeout(hideT); hideT = setTimeout(hide, 220); } return; }
    clearTimeout(hideT);
    showT = setTimeout(() => show(hit), cur ? 60 : 380);
  }
  loadCodes().then(() => {
    document.addEventListener('mouseover', (e) => arm(e.target), { passive: true });
    document.addEventListener('focusin', (e) => { if (e.target.matches && e.target.matches('a, button')) arm(e.target); });
    document.addEventListener('focusout', () => { hideT = setTimeout(hide, 150); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hide(); });
    window.addEventListener('scroll', hide, { passive: true });
  }).catch(() => { /* ไม่มีสิทธิ์/ออฟไลน์ = ไม่แสดงป้าย */ });
})();
