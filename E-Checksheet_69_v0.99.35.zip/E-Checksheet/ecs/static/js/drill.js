/* v0.99.6 หน้าภาพรวม: แผงดูต่อด้านขวา (กดการ์ด/แถวใดก็ได้ที่มี data-od) + การเคลื่อนไหวมีมิติ
   data-od = JSON: {"t":"machine","id":1} · {"t":"item","form":1,"item":"k1"} · {"t":"panel", title, sub, tone, facts, rows, links}
   ลึกลงไปได้หลายชั้น (ย้อนกลับ ‹ / Esc) · Ctrl/⌘/Shift+คลิก = เปิดลิงก์ตามปกติ · สร้างองค์ประกอบด้วย textContent เท่านั้น */
(function () {
  'use strict';
  const root = document.querySelector('[data-od-root]');
  if (!root) return;
  const U_ = (p) => (window.U ? window.U(p) : p);
  const day = root.dataset.day || '';
  const SYM = { crit: '✕', warn: '!', good: '✓', none: '–', info: '◷', down: '‖' };
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function num(v) { return (v === null || v === undefined || v === '') ? '–' : (Math.abs(v) >= 1000 ? Number(v).toLocaleString('en-US') : String(+(+v).toFixed(3))); }
  function hm(t) { const m = /(\d{4})-(\d\d)-(\d\d)[ T](\d\d):(\d\d)/.exec(t || ''); return m ? (+m[3]) + '/' + m[2] + ' ' + m[4] + ':' + m[5] : (t || '–'); }
  const toneOf = (j) => ({ ng: 'crit', warn: 'warn', ok: 'good' }[j] || 'none');
  const specTxt = (mn, mx) => (mn == null && mx == null) ? 'ไม่มีเกณฑ์' : (mn == null ? '≤ ' + num(mx) : (mx == null ? '≥ ' + num(mn) : num(mn) + ' – ' + num(mx)));

  // ── โครงแผง (สร้างครั้งเดียว) ──
  const scrim = el('div', 'od-scrim'); scrim.hidden = true;
  const box = el('aside', 'od'); box.hidden = true;
  box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', 'รายละเอียด'); box.tabIndex = -1;
  const head = el('div', 'od-h');
  const bBack = el('button', 'od-ib', '‹'); bBack.type = 'button'; bBack.setAttribute('aria-label', 'ย้อนกลับ');
  const crumb = el('nav', 'od-crumb'); crumb.setAttribute('aria-label', 'ตำแหน่งที่กำลังดู');
  const bClose = el('button', 'od-ib', '✕'); bClose.type = 'button'; bClose.setAttribute('aria-label', 'ปิด');
  head.append(bBack, crumb, bClose);
  const body = el('div', 'od-b');
  box.append(head, body);
  document.body.append(scrim, box);

  let stack = [], opener = null, seq = 0;

  function open(spec, from) {
    if (!stack.length) opener = from || null;
    stack.push(spec); render(true);
  }
  function back() { if (stack.length > 1) { stack.pop(); render(false); } else close(); }
  function close() {
    stack = [];
    box.classList.remove('in'); scrim.classList.remove('in'); document.documentElement.classList.remove('od-open');
    const done = () => { box.hidden = true; scrim.hidden = true; };
    if (reduce) done(); else setTimeout(done, 260);
    if (opener && opener.focus) opener.focus();
  }

  function render(forward) {
    const spec = stack[stack.length - 1]; if (!spec) return;
    box.hidden = false; scrim.hidden = false;
    requestAnimationFrame(() => { box.classList.add('in'); scrim.classList.add('in'); document.documentElement.classList.add('od-open'); });
    bBack.hidden = stack.length < 2;
    crumb.textContent = '';
    stack.forEach((s, i) => { if (i) crumb.append(el('span', 'od-sep', '›')); crumb.append(el(i === stack.length - 1 ? 'b' : 'span', null, s.crumb || s.title || '…')); });
    body.textContent = '';
    const page = el('div', 'od-page ' + (forward ? 'fwd' : 'bwd')); body.append(page); body.scrollTop = 0;
    const my = ++seq;
    if (spec.t === 'machine') loadMachine(spec, page, my);
    else if (spec.t === 'item') loadItem(spec, page, my);
    else draw(page, spec);
    box.focus({ preventScroll: true });
  }

  // ── ส่วนประกอบมาตรฐานของแผง ──
  function draw(page, d) {
    const hero = el('div', 'od-hero');
    const ic = el('span', 'od-ic t-' + (d.tone || 'none'), d.sym || SYM[d.tone] || '•'); ic.setAttribute('aria-hidden', 'true');
    const tt = el('div', 'od-tt'); tt.append(el('b', null, d.title || '')); if (d.sub) tt.append(el('span', null, d.sub));
    hero.append(ic, tt); page.append(hero);
    if (d.facts && d.facts.length) {
      const dl = el('dl', 'od-facts');
      d.facts.forEach(([k, v, tone]) => { const w = el('div', tone ? 't-' + tone : null); w.append(el('dt', null, k), el('dd', null, v)); dl.append(w); });
      page.append(dl);
    }
    if (d.chart) page.append(chart(d.chart));
    if (d.note) page.append(el('p', 'od-note', d.note));
    (d.groups || (d.rows ? [{ title: d.rowsTitle || '', rows: d.rows }] : [])).forEach((g) => {
      if (!g.rows || !g.rows.length) return;
      if (g.title) page.append(el('h3', 'od-gh', g.title));
      const ul = el('ul', 'od-list');
      g.rows.forEach((r, i) => {
        const li = el('li'); li.style.setProperty('--i', i);
        const a = el(r.href && !r.od ? 'a' : 'button', 'od-row');
        if (a.tagName === 'A') a.href = r.href; else a.type = 'button';
        const s = el('span', 'od-dot t-' + (r.tone || 'none'), r.sym || SYM[r.tone] || '•'); s.setAttribute('aria-hidden', 'true');
        const tx = el('span', 'od-rt'); tx.append(el('b', null, r.title || '')); if (r.sub) tx.append(el('small', null, r.sub));
        a.append(s, tx);
        if (r.right) a.append(el('span', 'od-rr t-' + (r.rightTone || 'none'), r.right));
        a.append(el('span', 'od-go', '›'));
        if (r.od) a.addEventListener('click', (e) => { if (e.ctrlKey || e.metaKey || e.shiftKey) return; e.preventDefault(); open(r.od); });
        li.append(a); ul.append(li);
      });
      page.append(ul);
    });
    if (d.empty && !(d.rows && d.rows.length) && !(d.groups && d.groups.some((g) => g.rows && g.rows.length))) page.append(el('p', 'od-note', d.empty));
    if (d.links && d.links.length) {
      const acts = el('div', 'od-acts');
      d.links.forEach(([label, href, primary]) => { if (!href) return; const a = el('a', 'btn' + (primary ? ' btn-primary' : ''), label); a.href = href; acts.append(a); });
      page.append(acts);
    }
  }

  function chart(c) {   // กราฟเส้นค่าที่ตรวจ + แถบเกณฑ์ (SVG สร้างด้วย DOM)
    const NS = 'http://www.w3.org/2000/svg', W = 400, H = 140, v = c.values || [];
    const wrap = el('div', 'od-chart');
    if (v.length < 2) { wrap.append(el('p', 'od-note', 'ข้อมูลยังไม่พอสำหรับกราฟ')); return wrap; }
    const lim = [c.min, c.max].filter((x) => x !== null && x !== undefined);
    let lo = Math.min(...v, ...lim), hi = Math.max(...v, ...lim); const pad = (hi - lo || 1) * 0.12; lo -= pad; hi += pad;
    const X = (i) => (i * (W - 8) / (v.length - 1) + 4), Y = (x) => (H - 6 - (x - lo) / (hi - lo) * (H - 12));
    const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H); svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', 'กราฟค่าที่ตรวจ ' + v.length + ' ครั้งล่าสุด');
    const mk = (n, a) => { const e = document.createElementNS(NS, n); Object.keys(a).forEach((k) => e.setAttribute(k, a[k])); svg.append(e); return e; };
    if (c.min != null && c.max != null) mk('rect', { x: 0, y: Y(c.max), width: W, height: Math.max(0, Y(c.min) - Y(c.max)), class: 'od-band' });
    lim.forEach((x) => mk('line', { x1: 0, x2: W, y1: Y(x), y2: Y(x), class: 'od-lim' }));
    mk('polyline', { points: v.map((x, i) => X(i).toFixed(1) + ',' + Y(x).toFixed(1)).join(' '), class: 'od-line', pathLength: 1 });
    v.forEach((x, i) => { const bad = (c.min != null && x < c.min) || (c.max != null && x > c.max); if (bad || i === v.length - 1) mk('circle', { cx: X(i), cy: Y(x), r: 4, class: bad ? 'od-pt bad' : 'od-pt' }); });
    wrap.append(svg); return wrap;
  }

  function loading(page) { page.append(el('div', 'od-skel')); page.append(el('div', 'od-skel s2')); page.append(el('div', 'od-skel s3')); }
  function fail(page, msg, href) {
    page.textContent = ''; page.append(el('p', 'od-note', msg || 'โหลดข้อมูลไม่สำเร็จ'));
    if (href) { const a = el('a', 'btn btn-primary', 'เปิดหน้าเต็มแทน'); a.href = href; page.append(a); }
  }
  async function getJSON(url) { const r = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } }); if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }

  async function loadMachine(spec, page, my) {
    loading(page);
    try {
      const d = await getJSON(U_('/api/equipment/' + spec.id + '/drill') + '?date=' + encodeURIComponent(day));
      if (my !== seq) return;
      const m = d.machine, down = m.run_status === 'down';
      const done = d.rounds.filter((r) => r.status === 'done_on_time' || r.status === 'done_late').length;
      const ng = d.items.filter((i) => i.judgement === 'ng').length, warn = d.items.filter((i) => i.judgement === 'warn').length;
      const tone = down ? 'down' : (ng ? 'crit' : (warn || d.rounds.some((r) => ['overdue', 'missed', 'returned'].includes(r.status)) ? 'warn' : 'good'));
      const rtone = (s) => ({ done_on_time: 'good', done_late: 'warn', overdue: 'warn', missed: 'crit', returned: 'crit', skipped: 'down', pending: 'info', in_progress: 'info' }[s] || 'none');
      spec.crumb = m.code;
      page.textContent = '';
      draw(page, {
        title: m.code + ' · ' + m.name, sub: [m.factory_name, m.area_name, m.eq_type].filter(Boolean).join(' › '), tone,
        facts: [['ตรวจวันนี้', d.rounds.length ? done + '/' + d.rounds.length + ' รอบ' : 'ไม่มีรอบ'],
          ['สถานะเครื่อง', down ? 'หยุด' + (m.down_reason ? ' · ' + m.down_reason : '') : 'เดินเครื่อง', down ? 'down' : null],
          ['หัวข้อ NG ล่าสุด', String(ng), ng ? 'crit' : null], ['หัวข้อเตือน', String(warn), warn ? 'warn' : null]],
        groups: [
          { title: 'รอบตรวจของวัน', rows: d.rounds.map((r) => ({ title: hm(r.due_at).split(' ')[1] + ' · ' + r.form, sub: r.status_th + (r.inspector ? ' · ' + r.inspector : '') + (r.ng ? ' · NG ' + r.ng : ''), tone: rtone(r.status), href: r.url })) },
          { title: 'ค่าล่าสุดของทุกหัวข้อ (กดดูกราฟ)', rows: d.items.map((i) => ({ title: i.name, sub: specTxt(i.min_value, i.max_value) + ' · ' + hm(i.last_at),
            right: num(i.last) + (i.unit ? ' ' + i.unit : ''), rightTone: toneOf(i.judgement), tone: toneOf(i.judgement), od: { t: 'item', form: i.form_id, item: i.item_key, crumb: i.name } })) }
        ],
        empty: 'ยังไม่มีผลตรวจของเครื่องนี้',
        links: [['ผลตรวจล่าสุด', d.links.latest, true], ['ประวัติเครื่อง 360°', d.links.m360], ['แนวโน้มค่าที่ตรวจ', d.links.trends], ['ข้อมูลเครื่อง', d.links.detail]]
      });
      crumb.lastChild.textContent = m.code;
    } catch (e) { if (my === seq) fail(page, 'โหลดข้อมูลเครื่องไม่สำเร็จ', U_('/machines/' + spec.id)); }
  }

  async function loadItem(spec, page, my) {
    loading(page);
    const full = U_('/trends') + '?form=' + spec.form + '&item=' + encodeURIComponent(spec.item);
    try {
      const d = await getJSON(U_('/api/trend') + '?form=' + spec.form + '&item=' + encodeURIComponent(spec.item) + '&days=30');
      if (my !== seq) return;
      const it = d.item, st = d.stats || {}, pts = d.points || [], last = pts[pts.length - 1];
      page.textContent = '';
      draw(page, {
        title: it.name, sub: (d.form.eq_code ? d.form.eq_code + ' · ' : '') + d.form.name + ' · 30 วัน', tone: last ? toneOf(last.judgement) : 'none', sym: '∿',
        facts: [['ค่าล่าสุด', last ? num(last.v) + (it.unit ? ' ' + it.unit : '') : '–', last ? toneOf(last.judgement) : null],
          ['เกณฑ์', specTxt(it.min_value, it.max_value)],
          ['เฉลี่ย · ครั้ง', st.n ? num(st.mean) + ' · ' + st.n + ' ครั้ง' : '–'],
          ['NG · เตือน', st.n ? (st.ng || 0) + ' · ' + (st.warn || 0) : '–', st.ng ? 'crit' : null]],
        chart: { values: pts.map((p) => p.v), min: it.min_value, max: it.max_value },
        rowsTitle: 'ผลตรวจล่าสุด (กดเปิดผลตรวจ)',
        rows: pts.slice(-8).reverse().map((p) => ({ title: num(p.v) + (it.unit ? ' ' + it.unit : ''), sub: hm(p.t) + (p.inspector ? ' · ' + p.inspector : '') + (p.remark ? ' · ' + p.remark : ''),
          tone: toneOf(p.judgement), href: p.sub_id ? U_('/submissions/' + p.sub_id) : '' })),
        empty: 'ไม่มีผลตรวจในช่วง 30 วัน',
        links: [['เปิดกราฟเต็ม', full, true]]
      });
    } catch (e) { if (my === seq) fail(page, 'โหลดกราฟไม่สำเร็จ', full); }
  }

  // ── เหตุการณ์ ──
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-od]');
    if (!t || box.contains(t) || e.ctrlKey || e.metaKey || e.shiftKey || e.button) return;
    let spec; try { spec = JSON.parse(t.dataset.od); } catch (err) { return; }
    e.preventDefault(); stack = []; open(spec, t);
  });
  bBack.addEventListener('click', back);
  bClose.addEventListener('click', close);
  scrim.addEventListener('click', close);
  document.addEventListener('keydown', (e) => {
    if (box.hidden) return;
    if (e.key === 'Escape') { e.preventDefault(); back(); return; }
    if (e.key === 'Tab') {        // วนโฟกัสในแผง
      const f = [...box.querySelectorAll('button:not([hidden]),a[href]')].filter((x) => x.offsetParent !== null);
      if (!f.length) return;
      if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
    }
  });

  // ── การเคลื่อนไหวตอนเปิดหน้า: ตัวเลขนับขึ้น · หลอด/แท่งค่อย ๆ ยาวขึ้น ──
  if (!reduce) {
    // v0.99.28 ค่าจริงเก็บไว้ที่ data-final ครั้งเดียว (ตัวนับใน fx.js ข้ามตัวที่นับแล้ว) · จบที่ค่าจริงเสมอ
    // (เดิม fx.js นับซ้ำโดยอ่านตัวเลขระหว่างนับ ~13% เป็นค่าจริง → หลังรีเฟรชค้างที่ค่าผิด)
    const items = [...root.querySelectorAll('[data-count]')].filter((n) => !n.dataset.final)
      .map((n) => { n.dataset.final = n.textContent; return { n, txt: n.textContent }; });
    const t0 = performance.now(), dur = 1000;
    const fmt = (s, p) => s.replace(/\d[\d,]*(\.\d+)?/g, (m) => { const dec = (m.split('.')[1] || '').length, v = parseFloat(m.replace(/,/g, '')) * p; return dec ? v.toFixed(dec) : Math.round(v).toLocaleString('en-US'); });
    const done = () => items.forEach((i) => { i.n.textContent = i.txt; });
    const tick = (t) => { const x = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - x, 3); if (x >= 1) return done(); items.forEach((i) => { i.n.textContent = fmt(i.txt, e); }); requestAnimationFrame(tick); };
    if (items.length) { requestAnimationFrame(tick); setTimeout(done, dur + 400); }   // แท็บซ่อน/เครื่องช้า: ยังจบที่ค่าจริง
  }
  root.classList.add('od-ready');
})();
