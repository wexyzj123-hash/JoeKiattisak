/* v0.99.26 ฉาก "Utility 4.0" ใช้ร่วมกัน — หน้าเข้าสู่ระบบ/สมัคร (js/authfx.js) และพื้นหลังทุกหน้า (js/worldfx.js)
   โหนดระบบสาธารณูปโภคเชื่อมด้วยท่อเรืองแสง มีอนุภาคไหล · ชีพจร ✓ OK · เรดาร์กวาด · ขยับตามเมาส์
   เคารพ prefers-reduced-motion (วาดภาพนิ่ง) · หยุดเมื่อแท็บถูกซ่อน · ภาพตกแต่งเท่านั้น ไม่ใช่ข้อมูลจริง */
(function () {
  'use strict';
  /* ECSScene(canvas, {keep, maxNodes, density, fps, dpr, radar, labels}) → {start, stop}
     keep = selector ของสิ่งที่ห้ามวางโหนดทับ · fps = จำกัดเฟรม (ประหยัดเครื่อง) */
  window.ECSScene = function (cv, o) {
  o = Object.assign({ keep: '', maxNodes: 22, density: 70000, fps: 60, dpr: 2, radar: true, labels: true }, o || {});
  if (!cv || !cv.getContext) return null;
  const ctx = cv.getContext('2d');
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const DPR = Math.min(o.dpr, window.devicePixelRatio || 1);
  const KINDS = [['AIR', '#7dd3fc'], ['H₂O', '#38bdf8'], ['kWh', '#facc15'], ['STEAM', '#fb923c'], ['CHW', '#22d3ee'], ['N₂', '#a78bfa'], ['GAS', '#f472b6']];
  let W = 0, H = 0, nodes = [], pipes = [], parts = [], pings = [], mx = 0, my = 0, tx = 0, ty = 0, t0 = performance.now(), raf = 0, last = 0, on = false;

  function rnd(a, b) { return a + Math.random() * (b - a); }
  function build() {
    W = cv.clientWidth; H = cv.clientHeight;
    cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR); ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const n = Math.max(7, Math.min(o.maxNodes, Math.round(W * H / o.density)));
    nodes = [];
    // ไม่วางโหนดทับข้อความหัวเรื่องและการ์ดฟอร์ม (อ่านง่าย)
    const keep = (o.keep ? [...document.querySelectorAll(o.keep)] : [])
      .map((e) => e.getBoundingClientRect()).filter((r) => r.width && r.height);
    const clear = (x, y) => !keep.some((r) => x > r.left - 40 && x < r.right + 40 && y > r.top - 30 && y < r.bottom + 30);
    for (let i = 0; i < n; i++) {
      const k = KINDS[i % KINDS.length];
      let x = 0, y = 0;
      for (let tries = 0; tries < 30; tries++) { x = rnd(.03, .97) * W; y = rnd(.05, .93) * H; if (clear(x, y)) break; }
      nodes.push({ x, y, z: rnd(.4, 1), r: rnd(5, 9), label: k[0], c: k[1], ph: rnd(0, 6.28) });
    }
    pipes = [];
    nodes.forEach((a, i) => {                       // เชื่อมเพื่อนบ้านใกล้สุด 2 ตัว
      nodes.map((b, j) => [j, Math.hypot(a.x - b.x, a.y - b.y)]).filter((x) => x[0] !== i).sort((p, q) => p[1] - q[1]).slice(0, 2)
        .forEach(([j]) => { if (!pipes.some((p) => (p.a === j && p.b === i) || (p.a === i && p.b === j))) pipes.push({ a: i, b: j, bend: rnd(-.25, .25) }); });
    });
    parts = [];
    pipes.forEach((p, i) => { for (let m = 0; m < 2; m++) parts.push({ p: i, t: Math.random(), v: rnd(.0012, .0035) * (Math.random() < .5 ? 1 : -1) }); });
  }
  function pos(n) { return [n.x + tx * 26 * n.z, n.y + ty * 18 * n.z]; }
  function ctrl(p) {
    const [ax, ay] = pos(nodes[p.a]), [bx, by] = pos(nodes[p.b]);
    const mxp = (ax + bx) / 2, myp = (ay + by) / 2, dx = bx - ax, dy = by - ay;
    return [ax, ay, mxp - dy * p.bend, myp + dx * p.bend, bx, by];
  }
  function at(c, t) {
    const u = 1 - t;
    return [u * u * c[0] + 2 * u * t * c[2] + t * t * c[4], u * u * c[1] + 2 * u * t * c[3] + t * t * c[5]];
  }
  function frame(now) {
    if (on && !reduce) raf = requestAnimationFrame(frame);
    if (o.fps < 60 && now - last < 1000 / o.fps - 2) return;
    last = now;
    const dt = Math.min(50, now - t0); t0 = now;
    tx += (mx - tx) * .04; ty += (my - ty) * .04;
    ctx.clearRect(0, 0, W, H);
    // ท่อ
    ctx.lineCap = 'round';
    pipes.forEach((p) => {
      const c = ctrl(p), col = nodes[p.a].c;
      ctx.beginPath(); ctx.moveTo(c[0], c[1]); ctx.quadraticCurveTo(c[2], c[3], c[4], c[5]);
      ctx.strokeStyle = 'rgba(120,170,255,.10)'; ctx.lineWidth = 5; ctx.stroke();
      ctx.strokeStyle = col + '40'; ctx.lineWidth = 1.2; ctx.stroke();
    });
    // อนุภาคไหลในท่อ
    parts.forEach((q) => {
      q.t += q.v * dt / 16; if (q.t > 1) q.t -= 1; if (q.t < 0) q.t += 1;
      const p = pipes[q.p], c = ctrl(p), [x, y] = at(c, q.t), col = nodes[p.a].c;
      const g = ctx.createRadialGradient(x, y, 0, x, y, 7); g.addColorStop(0, col); g.addColorStop(1, 'transparent');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 7, 0, 6.283); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, 1.3, 0, 6.283); ctx.fill();
    });
    // ชีพจร "ตรวจเสร็จ"
    if (Math.random() < dt / 900) pings.push({ n: Math.floor(Math.random() * nodes.length), t: 0 });
    pings = pings.filter((g) => (g.t += dt / 1600) < 1);
    pings.forEach((g) => {
      const n = nodes[g.n], [x, y] = pos(n);
      ctx.strokeStyle = 'rgba(141,220,179,' + (1 - g.t) * .8 + ')'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y, n.r + g.t * 46, 0, 6.283); ctx.stroke();
      if (g.t < .5) { ctx.fillStyle = 'rgba(141,220,179,' + (1 - g.t * 2) + ')'; ctx.font = '600 11px system-ui, sans-serif'; ctx.fillText('✓ OK', x + n.r + 8, y - n.r - 8 - g.t * 20); }
    });
    // โหนด
    nodes.forEach((n) => {
      const [x, y] = pos(n), pulse = 1 + Math.sin(now / 700 + n.ph) * .15;
      const g = ctx.createRadialGradient(x, y, 0, x, y, n.r * 4 * pulse); g.addColorStop(0, n.c + 'aa'); g.addColorStop(1, 'transparent');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, n.r * 4 * pulse, 0, 6.283); ctx.fill();
      ctx.fillStyle = '#0b1430'; ctx.strokeStyle = n.c; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y, n.r, 0, 6.283); ctx.fill(); ctx.stroke();
      ctx.fillStyle = n.c; ctx.beginPath(); ctx.arc(x, y, n.r * .38, 0, 6.283); ctx.fill();
      if (o.labels) { ctx.font = '600 10px ui-monospace, Menlo, monospace'; ctx.fillStyle = 'rgba(210,228,255,' + (.35 + n.z * .4) + ')';
        ctx.fillText(n.label, x + n.r + 6, y + 3); }
    });
    // เรดาร์กวาด
    if (!o.radar) return;
    const rx = W * .5 + tx * 10, ry = H * .55, rr = Math.max(W, H) * .75, a = (now / 4200) % 6.283;
    const sg = ctx.createRadialGradient(rx, ry, 0, rx, ry, rr); sg.addColorStop(0, 'rgba(90,184,255,.06)'); sg.addColorStop(1, 'transparent');
    ctx.save(); ctx.translate(rx, ry); ctx.rotate(a); ctx.translate(-rx, -ry);
    ctx.fillStyle = sg; ctx.beginPath(); ctx.moveTo(rx, ry); ctx.arc(rx, ry, rr, 0, .45); ctx.closePath(); ctx.fill(); ctx.restore();
  }
  const onMove = (e) => { mx = (e.clientX / innerWidth - .5) * 2; my = (e.clientY / innerHeight - .5) * 2; };
  let rt;
  const onResize = () => { clearTimeout(rt); rt = setTimeout(() => { build(); if (reduce || !on) frame(performance.now()); }, 150); };
  const onVis = () => { if (!on || reduce) return; if (document.hidden) cancelAnimationFrame(raf); else { t0 = performance.now(); raf = requestAnimationFrame(frame); } };
  window.addEventListener('pointermove', onMove, { passive: true });
  window.addEventListener('resize', onResize);
  document.addEventListener('visibilitychange', onVis);
  build();
  const api = {
    start() { if (on) return api; on = true; t0 = performance.now(); if (reduce) frame(t0); else raf = requestAnimationFrame(frame); return api; },
    stop() { on = false; cancelAnimationFrame(raf); ctx.clearRect(0, 0, W, H); return api; },
    rebuild() { build(); return api; },
  };
  return api.start();
  };
})();
