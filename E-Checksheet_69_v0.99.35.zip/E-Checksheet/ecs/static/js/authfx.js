/* v0.99.25 หน้าเข้าสู่ระบบ/สมัคร — ฉากหลังจาก js/scene.js (ECSScene) + ตัวช่วยฟอร์ม */
(function () {
  'use strict';
  if (window.ECSScene) ECSScene(document.getElementById('auFx'), { keep: '.au-hero .au-chip, .au-hero .au-title, .au-hero .au-feat, .au-hero .au-ticker, .au-card' });

  // ── ฟอร์ม: แสดง/ซ่อนรหัส · แจ้ง Caps Lock · ปุ่มกำลังส่ง · ความแข็งแรงรหัสผ่าน ──
  document.querySelectorAll('[data-eye]').forEach((b) => b.addEventListener('click', () => {
    const i = document.getElementById(b.dataset.eye); if (!i) return;
    const show = i.type === 'password'; i.type = show ? 'text' : 'password'; b.setAttribute('aria-pressed', show); b.textContent = show ? 'ซ่อน' : 'แสดง'; i.focus();
  }));
  document.querySelectorAll('input[type=password]').forEach((i) => {
    const hint = i.closest('.au-field') && i.closest('.au-field').querySelector('.au-caps');
    if (hint) ['keyup', 'keydown'].forEach((ev) => i.addEventListener(ev, (e) => { hint.hidden = !(e.getModifierState && e.getModifierState('CapsLock')); }));
  });
  document.querySelectorAll('form.au-form').forEach((f) => f.addEventListener('submit', () => {
    const b = f.querySelector('button[type=submit]'); if (b) { b.classList.add('busy'); setTimeout(() => { b.disabled = true; }, 0); }
  }));
  const pw = document.getElementById('su-pw'), meter = document.getElementById('su-meter');
  if (pw && meter) {
    const lab = ['อ่อนมาก', 'อ่อน', 'พอใช้', 'ดี', 'แข็งแรง'];
    pw.addEventListener('input', () => {
      const v = pw.value; let s = 0;
      if (v.length >= 8) s++; if (v.length >= 12) s++; if (/[a-zA-Z]/.test(v) && /\d/.test(v)) s++; if (/[^a-zA-Z0-9]/.test(v)) s++; if (/[a-z]/.test(v) && /[A-Z]/.test(v)) s++;
      s = Math.min(4, v ? s : 0); meter.dataset.s = v ? s : ''; meter.querySelector('b').textContent = v ? lab[s] : '';
    });
  }
  const un = document.getElementById('su-user');
  if (un) un.addEventListener('input', () => { un.value = un.value.replace(/\s+/g, ''); un.setCustomValidity(/^[A-Za-z0-9._-]{0,40}$/.test(un.value) ? '' : 'ใช้ได้เฉพาะ A-Z a-z 0-9 . _ -'); });
  const p2 = document.getElementById('su-pw2');
  if (pw && p2) { const chk = () => p2.setCustomValidity(p2.value && p2.value !== pw.value ? 'ยืนยันรหัสผ่านไม่ตรงกัน' : ''); p2.addEventListener('input', chk); pw.addEventListener('input', chk); }
})();
