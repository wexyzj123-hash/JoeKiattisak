"""v0.99.25: หน้าเข้าสู่ระบบโลกอนาคต + สมัครใช้งานเอง (รอผู้ดูแลระบบอนุมัติ)"""
import pytest
from conftest import csrf_of, login

from ecs import cmms_bridge as CB
from ecs import masterdata as M
from ecs.services import ValidationError
from ecs.views import auth as AUTH


@pytest.fixture(autouse=True)
def _reset_throttle():
    AUTH._SIGNUPS.clear()
    yield
    AUTH._SIGNUPS.clear()


def _signup(client, **kw):
    data = {"name": "สมชาย ใจดี", "username": "somchai.j", "password": "Pass1234", "password2": "Pass1234", "role": "technician",
            "csrf_token": csrf_of(client), **kw}
    return client.post("/signup", data=data)


def test_login_page_futuristic_and_signup_link(client):
    h = client.get("/login").get_data(as_text=True)
    assert 'id="auFx"' in h and "js/authfx.js" in h and "auth-page" in h and 'href="/signup"' in h
    assert 'name="username"' in h and 'name="password"' in h and 'name="next"' in h
    s = client.get("/signup").get_data(as_text=True)
    assert 'name="password2"' in s and 'name="website"' in s and 'value="technician"' in s and 'value="viewer"' in s
    assert 'value="admin"' not in s and 'value="supervisor"' not in s          # สมัครเองเป็นผู้ดูแล/หัวหน้างานไม่ได้


def test_signup_pending_then_approve(client, db):
    r = _signup(client, emp_code="E1001", note="กะ B")
    assert r.status_code == 200 and "ส่งคำขอสมัครแล้ว" in r.get_data(as_text=True)
    u = db.execute("SELECT * FROM users WHERE username='somchai.j'").fetchone()
    assert u["active"] == 0 and u["signup_status"] == "pending" and u["role"] == "technician" and "E1001" in u["signup_note"]
    assert u["password"] != "Pass1234"                                          # เก็บแบบแฮช
    assert db.execute("SELECT COUNT(*) FROM cs_notifications WHERE kind='signup' AND ref_key=?", (f"signup:{u['id']}",)).fetchone()[0] >= 1
    # ก่อนอนุมัติ: รหัสถูก = บอกว่ารออนุมัติ · รหัสผิด = ข้อความกลาง ๆ
    tok = csrf_of(client)
    h = client.post("/login", data={"username": "somchai.j", "password": "Pass1234", "csrf_token": tok}).get_data(as_text=True)
    assert "รอผู้ดูแลระบบอนุมัติ" in h
    h = client.post("/login", data={"username": "somchai.j", "password": "Wrong1234", "csrf_token": csrf_of(client)}).get_data(as_text=True)
    assert "รอผู้ดูแล" not in h and "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" in h
    # ช่าง/หัวหน้างานอนุมัติไม่ได้
    t = login(client, "t_sup")
    assert client.post(f"/admin/signups/{u['id']}/approve", data={"csrf_token": t, "role": "admin"}).status_code == 403
    client.post("/logout", data={"csrf_token": t})
    t = login(client, "t_admin")
    page = client.get("/admin/users").get_data(as_text=True)
    assert 'id="signups"' in page and "somchai.j" in page and "E1001" in page
    r = client.post(f"/admin/signups/{u['id']}/approve", data={"csrf_token": t, "role": "viewer", "factory_id": ""})
    assert r.status_code == 302
    u = db.execute("SELECT * FROM users WHERE username='somchai.j'").fetchone()
    assert u["active"] == 1 and u["signup_status"] == "approved" and u["role"] == "viewer"
    client.post("/logout", data={"csrf_token": t})
    login(client, "somchai.j", "Pass1234")                                     # เข้าระบบได้หลังอนุมัติ


def test_signup_reject_and_validation(client, db):
    h = _signup(client, username="tech x", password="short", password2="nomatch", name="").get_data(as_text=True)
    assert "ชื่อผู้ใช้ 3–40 ตัว" in h and "รหัสผ่านต้องมีอย่างน้อย" in h and "กรุณาระบุชื่อ" in h
    assert "ยืนยันรหัสผ่านไม่ตรงกัน" in _signup(client, password2="Pass9999").get_data(as_text=True)
    assert "ถูกใช้แล้ว" in _signup(client, username="t_admin").get_data(as_text=True)
    assert "สงวนไว้" in _signup(client, username="admin").get_data(as_text=True)
    assert "เลือกประเภทผู้ใช้ไม่ถูกต้อง" in _signup(client, role="admin").get_data(as_text=True)
    assert "อีเมลไม่ถูกต้อง" in _signup(client, email="bad").get_data(as_text=True)
    assert db.execute("SELECT COUNT(*) FROM users WHERE signup_status='pending'").fetchone()[0] == 0
    _signup(client)
    uid = db.execute("SELECT id FROM users WHERE username='somchai.j'").fetchone()[0]
    t = login(client, "t_admin")
    client.post(f"/admin/signups/{uid}/reject", data={"csrf_token": t, "reason": "ไม่ใช่พนักงาน"})
    u = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    assert u["active"] == 0 and u["signup_status"] == "rejected" and "ไม่ใช่พนักงาน" in u["signup_note"]
    with pytest.raises(ValidationError):
        M.approve_signup(db, uid, "technician", None, None)                     # ไม่อนุมัติแล้ว อนุมัติซ้ำไม่ได้
    client.post("/logout", data={"csrf_token": t})
    h = client.post("/login", data={"username": "somchai.j", "password": "Pass1234", "csrf_token": csrf_of(client)}).get_data(as_text=True)
    assert "ไม่ได้รับอนุมัติ" in h


def test_signup_honeypot_rate_limit_and_toggle(client, db):
    assert "ส่งคำขอสมัครแล้ว" in _signup(client, website="spam").get_data(as_text=True)
    assert db.execute("SELECT COUNT(*) FROM users WHERE username='somchai.j'").fetchone()[0] == 0     # บอทไม่ถูกสร้างจริง
    for i in range(AUTH.MAX_SIGNUPS):
        assert "ส่งคำขอสมัครแล้ว" in _signup(client, username=f"user{i}x").get_data(as_text=True)
    assert "หลายครั้งเกินไป" in _signup(client, username="oneMore").get_data(as_text=True)
    assert db.execute("SELECT COUNT(*) FROM users WHERE username='oneMore'").fetchone()[0] == 0
    t = login(client, "t_admin")
    client.post("/admin/signups/toggle", data={"csrf_token": t, "on": "0"})
    assert not M.signup_enabled(db)
    client.post("/logout", data={"csrf_token": t})
    assert client.get("/signup").status_code == 302 and 'href="/signup"' not in client.get("/login").get_data(as_text=True)


def test_signup_name_collision_with_cmms(db):
    """ชื่อที่มีใน UT-CMMS สมัครไม่ได้ · ถ้ามีคำขอค้างแล้วผู้ใช้ UT-CMMS ตัวจริงเข้าสู่ระบบ → ลบคำขอ แล้วสร้างบัญชีผูกให้เจ้าของจริง"""
    with pytest.raises(ValidationError) as e:
        M.signup(db, {"name": "x y", "username": "boss", "password": "Pass1234", "password2": "Pass1234", "role": "viewer"},
                 cmms_taken=lambda u: u.lower() == "boss")
    assert "มีอยู่แล้วใน UT-CMMS" in e.value.errors[0]
    uid = M.signup(db, {"name": "x y", "username": "boss2", "password": "Pass1234", "password2": "Pass1234", "role": "viewer"})
    db.commit()
    user = CB.link_user(db, {"id": 777, "username": "boss2", "name": "Boss ตัวจริง", "role": "technician"})
    assert user["id"] != uid and user["active"] == 1 and user["legacy_id"] == 777
    assert db.execute("SELECT COUNT(*) FROM users WHERE id=?", (uid,)).fetchone()[0] == 0
