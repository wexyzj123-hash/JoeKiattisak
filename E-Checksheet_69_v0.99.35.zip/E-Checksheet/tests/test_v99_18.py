"""v0.99.18: หน้าแนวโน้ม + หน้ารายงานเป็นแดชบอร์ดธีมเดียวกับภาพรวม · ดูเฉพาะวัน (?day=) · แถบวันของเดือนในหน้ารายงาน"""
import re
from calendar import monthrange
from datetime import date, timedelta

from conftest import GOOD, login, payload, uid

from ecs import submissions as SUB


def _submit(app, db, form, oil="2.1"):
    SUB.create_submission(db, payload(form, {**GOOD, "oil": {"value": oil}}), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()


def test_trends_hero_and_single_day(app, client, db, published_form):
    _submit(app, db, published_form)
    login(client, "t_view")
    fid, today = published_form["form_id"], date.today()
    h = client.get(f"/trends?form={fid}&item=oil").get_data(as_text=True)
    assert "dash-luxe lx-page" in h and 'class="lx-hero' in h and h.count('class="kx"') == 6
    assert "30 วัน</b>" in h and 'class="kcards"' in h                    # ของเดิมยังอยู่ (ย้ายตัวเลขขึ้นแถบหัว)
    assert 'data-mcfilter="bad"' in h and "kx-ring" in h
    # ดูเฉพาะวันนี้: เห็นค่าที่ตรวจวันนี้ · ลิงก์ในหน้าคงวันไว้
    d = client.get(f"/trends?form={fid}&item=oil&day={today.isoformat()}").get_data(as_text=True)
    assert "เฉพาะวัน</b>" in d and "c-trend" in d
    assert f"day={today.isoformat()}&mode=spc#deep" in d
    assert f"from={today.isoformat()}&amp;to={today.isoformat()}" in d       # Excel คุณภาพใช้ช่วงวันเดียว
    assert 'aria-label="วันถัดไป"' not in d                                  # วันนี้ไม่มีวันถัดไป
    assert f'name="day" value="{today.isoformat()}"' in d
    # วันอื่นที่ไม่มีผลตรวจ
    y = (today - timedelta(days=1)).isoformat()
    e = client.get(f"/trends?form={fid}&item=oil&day={y}").get_data(as_text=True)
    assert "ลองเลือกวันอื่น" in e and 'aria-label="วันถัดไป"' in e
    # วันอนาคต → วันนี้ · ค่าผิดรูปแบบ → ช่วงปกติ
    f = client.get(f"/trends?form={fid}&day={(today + timedelta(days=9)).isoformat()}").get_data(as_text=True)
    assert f'name="day" value="{today.isoformat()}"' in f
    g = client.get(f"/trends?form={fid}&day=xx").get_data(as_text=True)
    assert "30 วัน</b>" in g
    # ช่วง from/to เดิมยังใช้ได้ และลิงก์คงช่วงไว้
    a = (today - timedelta(days=3)).isoformat()
    r = client.get(f"/trends?form={fid}&item=oil&from={a}&to={today.isoformat()}").get_data(as_text=True)
    assert "4 วัน</b>" in r and f"from={a}" in r


def test_trends_quality_links_keep_range(app, client, db, published_form):
    _submit(app, db, published_form)
    login(client, "t_view")
    fid = published_form["form_id"]
    h = client.get(f"/trends?form={fid}&days=7").get_data(as_text=True)
    assert "/quality?days=7" in h or "quality?qscope=num&amp;days=7" in h
    assert "days=7&qscope=all#quality" in h


def test_reports_day_strip(app, client, db, published_form):
    _submit(app, db, published_form)
    _submit(app, db, published_form, oil="2.2")
    login(client, "t_view")
    today = date.today()
    last = monthrange(today.year, today.month)[1]
    h = client.get("/reports").get_data(as_text=True)
    assert "dash-luxe lx-page" in h and 'class="lx-hero' in h and 'id="rpDays"' in h
    assert len(re.findall(r'class="rd[^"]*" data-day="\d+"', h)) == last
    m = re.search(rf'class="rd([^"]*)" data-day="{today.day}"[^>]*data-n="(\d+)" data-ng="(\d+)" data-nf="(\d+)"', h)
    assert m and " td" in m.group(1) and m.group(2) == "2" and m.group(4) == "1"
    assert len(re.findall(r'data-day="\d+"[^>]*\bdisabled\b', h)) == last - today.day      # วันอนาคตกดไม่ได้
    assert 'data-sel=""' in h
    assert f'data-sel="{today.day}"' in client.get(f"/reports?day={today.day}").get_data(as_text=True)
    assert 'data-sel=""' in client.get("/reports?day=99").get_data(as_text=True)
    # ของเดิมครบ: การ์ดสถานะ 5 ใบ · ตัวกรองวันที่ · รายงานสรุป · ข้อมูลดิบ
    for s in ('data-kf="has:1"', 'data-kf="st:pending"', 'data-kf="st:ng"', 'data-kf="st:unsigned"', 'data-kf="has:0"',
              'id="sfFrom"', 'id="sfTo"', 'id="fSum"', 'id="fRaw"', 'id="sheetList"'):
        assert s in h
    # เดือนก่อน: ทุกวันกดได้
    pm = (today.replace(day=1) - timedelta(days=1))
    p = client.get(f"/reports?month={pm:%Y-%m}").get_data(as_text=True)
    assert len(re.findall(r'class="rd[^"]*" data-day="\d+"', p)) == pm.day
    assert not re.findall(r'data-day="\d+"[^>]*\bdisabled\b', p)


def test_approvals_dashboard(app, client, db, published_form):
    """v0.99.18 หน้ารออนุมัติแบบแดชบอร์ด: ตัวเลขสรุป · อายุที่รอ · ชิปกรอง · ของเดิมครบ (อนุมัติกลุ่ม / SCADA / ยกเลิกค่า)"""
    from datetime import datetime
    _submit(app, db, published_form)                    # ปกติ
    _submit(app, db, published_form, oil="2.45")        # ช่วงเตือน
    sid = db.execute("SELECT id FROM cs_submissions ORDER BY id LIMIT 1").fetchone()[0]
    old = (datetime.now() - timedelta(hours=30)).strftime("%Y-%m-%d %H:%M:%S")
    db.execute("UPDATE cs_submissions SET finished_at=? WHERE id=?", (old, sid))
    db.commit()
    login(client, "t_sup")
    h = client.get("/approvals").get_data(as_text=True)
    assert "dash-luxe lx-page" in h and 'class="lx-hero' in h and h.count('class="kx"') == 6
    assert "รอนานสุด</b> 1 วัน" in h or "รอนานสุด</b> 30 ชม." in h
    assert re.search(r'data-apf="old">\s*<span class="kx-l">รอเกิน 24 ชม.</span>\s*<span class="kx-v"><b class="t-warn" data-count>1</b>', h)
    assert len(re.findall(r'<tr class="ap-row', h)) == 2
    assert re.search(r'data-k="ok old[ "]', h) and re.search(r'data-k="warn', h)
    assert 'id="apQ"' in h and 'data-aps="old"' in h and 'id="apFloat"' in h
    # ของเดิม: ฟอร์มอนุมัติกลุ่ม · ช่องเลือก · ตัวกรองที่มา/NG · แท็บ · กล่องยกเลิกค่า
    for s in ('id="bulk"', 'id="chkAll"', 'id="btnBulk"', 'name="src"', 'name="ng"', 'id="dlgVoid"', "อนุมัติรายสัปดาห์"):
        assert s in h
    assert h.count('class="chk"') == 2
    # อนุมัติกลุ่มทำงานเหมือนเดิม
    tok = re.search(r'name="csrf_token" value="([^"]+)"', h).group(1)
    r = client.post("/approvals/bulk", data={"csrf_token": tok, "ids": [str(sid)]})
    assert r.status_code == 302
    h2 = client.get("/approvals").get_data(as_text=True)
    assert len(re.findall(r'<tr class="ap-row', h2)) == 1 and "อนุมัติแล้ว 1 รายการ" in h2


def test_approvals_empty_state(client, published_form):
    login(client, "t_sup")
    h = client.get("/approvals").get_data(as_text=True)
    assert "ไม่มีรายการรออนุมัติ" in h and "ap-done-ic" in h and 'class="lx-hero' in h


def test_submissions_dashboard(app, client, db, published_form):
    """ประวัติผลตรวจแบบแดชบอร์ด: ตัวเลขสรุปตรงกับรายการ · ?day= เฉพาะวัน · ตัวกรองเดิมครบ · ไม่มีผล = ไม่มี JS พัง"""
    from ecs import submissions as S2
    _submit(app, db, published_form)
    _submit(app, db, published_form, oil="2.45")
    login(client, "t_admin")
    today = date.today()
    h = client.get("/submissions").get_data(as_text=True)
    assert "dash-luxe lx-page" in h and 'class="lx-hero' in h and h.count('class="kx"') == 6
    for n in ('name="from"', 'name="to"', 'name="factory"', 'name="form"', 'name="approval"', 'name="ng"'):
        assert n in h
    assert len(re.findall(r'<a class="rd', h)) == 30
    st = S2.submission_stats(db)
    assert st["n"] == 2 and st["warn"] == 1 and st["ng"] == 0 and st["days"][0]["n"] == 2
    assert f"from={today.isoformat()}&amp;to={today.isoformat()}" in h           # แถบวันลิงก์เฉพาะวัน
    d = client.get(f"/submissions?day={today.isoformat()}").get_data(as_text=True)
    assert "เฉพาะวัน</b>" in d and f'name="from" value="{today.isoformat()}"' in d and "2 รายการ" in d
    e = client.get(f"/submissions?day={(today - timedelta(days=1)).isoformat()}").get_data(as_text=True)
    assert "ไม่พบผลตรวจตามเงื่อนไข" in e and 'aria-label="วันถัดไป"' in e
    assert "if (!bar) return;" in e                                                  # หน้าว่างไม่ทำให้สคริปต์ลบพัง
    assert client.get("/submissions?day=2026-99-99").status_code == 200
    a = (today - timedelta(days=6)).isoformat()
    r = client.get(f"/submissions?from={a}&to={today.isoformat()}").get_data(as_text=True)
    assert len(re.findall(r'<a class="rd', r)) == 7 and "ช่วง</b>" in r


def test_machine360_dashboard_and_day(app, client, db, published_form):
    _submit(app, db, published_form)
    login(client, "t_view")
    eq, today = published_form["equipment_id"], date.today()
    h = client.get(f"/machines/{eq}").get_data(as_text=True)
    assert "dash-luxe lx-page" in h and 'class="lx-hero' in h and h.count('class="kx"') == 6
    assert len(re.findall(r'<a class="rd', h)) == 90 and "rp-days-row many" in h
    assert "ตรวจตรงเวลา" in h and "MTBF" in h and "MTTR" in h and 'id="timeline"' in h
    d = client.get(f"/machines/{eq}?day={today.isoformat()}").get_data(as_text=True)
    assert "เฉพาะวัน</b>" in d and f"?day={today.isoformat()}&ev=sub#timeline" in d
    assert d.count('class="m3-day"') == 1 and len(re.findall(r'<a class="rd', d)) == 30
    p = client.get("/machines").get_data(as_text=True)
    assert 'class="lx-hero' in p and 'data-mf="down"' in p and 'id="mq"' in p and "SCT0002" in p


def test_area_board_futuristic_markup(app, client, db, published_form):
    """v0.99.20 สถานะรายพื้นที่: แถบสเปกตรัม · วงแหวนความคืบหน้าโรงงาน · ลำดับแถว — ของเดิม (ชิปกรอง/แผง) ครบ"""
    from ecs import masterdata as M
    aid = M.save_area(db, {"factory_id": app.config["F1"], "name": "Compressor Room"}, None)
    db.execute("UPDATE equipment SET area_id=? WHERE id=?", (aid, published_form["equipment_id"]))
    db.commit()
    _submit(app, db, published_form)
    login(client, "t_sup")
    h = client.get("/dashboard").get_data(as_text=True)
    assert 'class="ab-spec"' in h and re.search(r'class="ab-fico" aria-hidden="true" style="--p:\d+"', h)
    assert re.search(r'class="ab-tile st-\w+" style="--i:\d+"', h)
    for s in ('data-flt="all"', 'data-flt="critical"', 'data-flt="warning"', 'data-flt="good"', 'data-flt="none"', "data-panel"):
        assert s in h


def test_dashboard_blocks_relayout(app, client, db, published_form):
    """v0.99.21 จัดเนื้อหาในบล็อกใหม่: ชิปพื้นที่ · สรุปงานค้าง · โดนัทเครื่องจักร · 2×2 วันนี้ · รายผู้ตรวจแยกการ์ด · ส่วนเดิมครบ"""
    from ecs import masterdata as M
    aid = M.save_area(db, {"factory_id": app.config["F1"], "name": "Compressor Room"}, None)
    db.execute("UPDATE equipment SET area_id=? WHERE id=?", (aid, published_form["equipment_id"]))
    db.commit()
    _submit(app, db, published_form)
    login(client, "t_sup")
    h = client.get("/dashboard").get_data(as_text=True)
    assert f'data-goto="{aid}"' in h and 'class="ab-acs"' in h
    assert 'class="ms-donut"' in h and h.count('<li class="ok"><i></i><span>เดินเครื่อง') == 1
    assert 'class="td-grid"' in h and h.count('class="td-k"') == 4 and 'id="hourly"' in h
    assert 'id="ins-people"' in h and 'id="ins-shift"' in h and "รายผู้ตรวจ" in h
    assert 'class="docs docs-grid"' in h and 'class="ins-docs"' in h
    for sid in ("areas", "todo", "mv", "cl", "ins-trend", "ins-mach", "c-week", "c-comp", "ins-docs", "ov-docs"):
        assert f'id="{sid}"' in h


def test_heatmap_fills_card(client, published_form):
    """v0.99.22 heatmap: เริ่มแกนจากวันแรกที่มีรอบตรวจ + ยืดเต็มการ์ด"""
    import pathlib
    login(client, "t_sup")
    js = (pathlib.Path(__file__).resolve().parents[1] / "ecs/static/js/charts.js").read_text(encoding="utf-8")
    assert "Math.min(...data0.cells.map((c) => c.x))" in js and "el.style.minHeight" in js
    h = client.get("/dashboard").get_data(as_text=True)
    assert "note: $('heat-note')" in h


def test_forms_list_dashboard_and_import_dialog(client, published_form):
    """v0.99.23 หน้าแบบฟอร์ม: แถบหัว + ตัวเลข · กล่องนำเข้า Excel อยู่ในหน้า (เดิมอยู่ใน <title> กดไม่ได้)"""
    login(client, "t_admin")
    h = client.get("/forms").get_data(as_text=True)
    title = h[h.index("<title>"):h.index("</title>")]
    assert "<dialog" not in title and title.startswith("<title>แบบฟอร์ม")
    body = h[h.index("<body"):]
    assert 'id="dlgXlsxNew"' in body and 'id="dlgNew"' in body and 'id="dlgTpl"' in body
    assert "dash-luxe lx-page" in h and h.count('class="kx') >= 6 and 'id="fFilter"' in h
    for n in ('name="q"', 'name="factory"', 'name="area"', 'name="cat"', 'name="sort"', 'name="inactive"'):
        assert n in h
    v = client.get("/forms?bind=yes").get_data(as_text=True)
    assert 'class="kx on" role="listitem" href="/forms?bind=yes' in v or 'kx on' in v


def test_person_performance_page(app, client, db, published_form):
    """v0.99.24 ผลงานรายคน: ตัวเลข/เครื่อง/ผลตรวจ/NG ตรงข้อมูล · ช่างดูได้เฉพาะของตัวเอง · หัวหน้างานดูได้ทุกคน · ลิงก์จากสรุปรายสัปดาห์"""
    from ecs import scorecard as SC
    _submit(app, db, published_form)
    _submit(app, db, published_form, oil="2.45")
    import io

    from conftest import png_bytes
    from werkzeug.datastructures import FileStorage
    SUB.create_submission(db, payload(published_form, {**GOOD, "oil": {"value": "9.9", "remark": "สูง", "photos": ["p1"]}}),
                          {"p1": FileStorage(io.BytesIO(png_bytes()), filename="p.png")}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()                                                       # NG (เกินเกณฑ์) พร้อมหมายเหตุ + รูป
    tech = uid(db, "t_tech")
    today = date.today()
    P = SC.person(db, tech, today - timedelta(days=6), today)
    assert P["k"]["subs"] == 3 and P["k"]["ng_subs"] == 1 and len(P["machines"]) == 1 and P["machines"][0]["n"] == 3
    assert P["k"]["ng_items"] == 1 and P["k"]["warn_items"] == 1 and len(P["days"]) == 7 and P["days"][-1]["n"] == 3
    assert {f["item_name"] for f in P["findings"]} == {"Oil Pressure"}
    assert SC.person(db, 999999, today, today) is None
    login(client, "t_sup")
    h = client.get(f"/team/people/{tech}").get_data(as_text=True)
    assert "dash-luxe lx-page" in h and 'id="ps-mach"' in h and 'id="ps-subs"' in h and 'id="ps-ng"' in h and 'id="ps-miss"' in h
    assert "SCT0002" in h and "Oil Pressure" in h and h.count('<tr data-k="') == 3
    d = client.get(f"/team/people/{tech}?day={today.isoformat()}").get_data(as_text=True)
    assert "เฉพาะวัน</b>" in d
    w = client.get(f"/team/people/{tech}?week={today.isoformat()}").get_data(as_text=True)
    assert "7 วัน</b>" in w
    assert client.get(f"/team/people/{tech}?from=bad").status_code == 200
    assert client.get("/team/people/999999").status_code == 404
    sc = client.get(f"/team/scorecard?week={today.isoformat()}").get_data(as_text=True)
    assert f"/team/people/{tech}?week=" in sc
    client.post("/logout", data={"csrf_token": ""})
    login(client, "t_tech")
    assert client.get(f"/team/people/{tech}").status_code == 200                       # ของตัวเอง
    assert client.get(f"/team/people/{uid(db, 't_sup')}").status_code == 403         # คนอื่น
