"""v0.99.33: ช่อง "เวลาตรวจรวม" ในแถบตัวเลขหน้าภาพรวม → แผงดูต่อ (โรงงาน › พื้นที่) → หน้าเวลาตรวจเช็ค
(v0.99.34: ช่องนับเฉพาะวันที่เลือกบนหน้า — ดูย้อนหลังด้วยการเลือกวันที่ด้านบน)"""
import html
import json
import re

from conftest import login
from ecs import insp_time as IT
from test_v99_32 import T, timed  # noqa: F401  (fixture)


def _tile(page: str) -> tuple[str, dict]:
    m = re.search(r'<a class="kx lift kx-it"[^>]*href="([^"]+)"[^>]*data-od=\'([^\']+)\'', page)
    assert m, "ไม่พบช่องเวลาตรวจรวม"
    return html.unescape(m.group(1)), json.loads(html.unescape(m.group(2)))


def test_dash_card_has_areas_and_shift(app, db, timed):  # noqa: F811
    c = IT.dash_card(db, T, T)
    assert c["head"]["sec"] == 600 and c["head"]["n"] == 3
    assert c["head"]["shift_day"] + c["head"]["shift_night"] == 600
    f = c["factories"][0]
    assert f["sec"] == 600 and sum(a["sec"] for a in f["areas"]) == 600
    assert any(a["label"] == "Compressor Room" for a in f["areas"])


def test_overview_tile_links_to_inspection_time(app, client, db, timed):  # noqa: F811
    login(client, "t_admin")
    page = client.get("/dashboard").get_data(as_text=True)
    grid = page[page.index('id="ov-today"'):]
    assert grid[:grid.index("</div>")].count('class="kx lift') == 7      # 6 ช่องเดิมครบ + ช่องใหม่
    href, od = _tile(page)
    assert href.startswith("/analytics/inspection-time") and "เวลาตรวจรวม" in page
    assert od["t"] == "panel" and od["title"].startswith("เวลาตรวจรวม 10 น.")
    facts = {f[0]: f[1] for f in od["facts"]}
    assert facts["จำนวนครั้ง"] == "3" and facts["เฉลี่ย/ครั้ง"] == "3 น. 20 วิ."
    fac_rows, area_rows = od["groups"][0]["rows"], [r for g in od["groups"][1:] for r in g["rows"]]
    assert fac_rows and all("factory=" in r["href"] for r in fac_rows)
    assert area_rows and all("area=" in r["href"] for r in area_rows)
    for u in [href] + [r["href"] for r in fac_rows + area_rows] + [x[1] for x in od["links"]]:
        assert client.get(u).status_code == 200, u


def test_tile_respects_factory_filter(app, client, db, timed):  # noqa: F811
    login(client, "t_admin")
    other = db.execute("SELECT id FROM factories WHERE id<>? ORDER BY id LIMIT 1", (app.config["F1"],)).fetchone()
    if other:
        page = client.get(f"/dashboard?factory={other['id']}").get_data(as_text=True)
        href, od = _tile(page)
        assert f"factory={other['id']}" in href and {f[0]: f[1] for f in od["facts"]}["จำนวนครั้ง"] == "0"
