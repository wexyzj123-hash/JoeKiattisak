"""v0.99.28: ตัวเลขหน้าภาพรวมหลังรีเฟรชไม่ตรงข้อมูลจริง (ค้างที่ ~13–22% ของค่าจริง)
สาเหตุ: ตัวนับ 2 ตัว (drill.js + fx.js) นับตัวเลขเดียวกัน — fx.js อ่านตัวเลขระหว่างที่ drill.js กำลังนับเป็น "ค่าจริง" """
import pathlib

JS = pathlib.Path(__file__).resolve().parents[1] / "ecs" / "static" / "js"


def _src(name):
    return (JS / name).read_text(encoding="utf-8")


def test_counters_share_one_true_value():
    for name in ("drill.js", "fx.js"):
        s = _src(name)
        assert "!n.dataset.final" in s, name                                     # ข้ามตัวที่ถูกนับแล้ว (ไม่นับซ้อน)
        assert "n.dataset.final = n.textContent" in s, name                      # จำค่าจริงก่อนเริ่มนับ ครั้งเดียว
        assert "i.n.textContent = i.txt" in s, name                              # จบที่ข้อความจริงเป๊ะ ๆ
        assert "setTimeout(done, dur + 400)" in s, name                          # แท็บซ่อน/เครื่องช้า: ยังจบที่ค่าจริง


def test_dashboard_numbers_rendered_by_server(client):
    from conftest import login
    login(client, "t_admin")
    h = client.get("/dashboard").get_data(as_text=True)
    assert h.count("data-count") >= 5 and "js/drill.js" in h and "js/fx.js" in h
