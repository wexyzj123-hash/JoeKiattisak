"""v0.99.34: ช่องเวลาตรวจรวม = เฉพาะวันที่เลือกบนหน้าภาพรวม · หน้าเวลาตรวจ 7/30/60 วันนับถึงวันที่เลือก · รายงานสรุปเวลาตรวจ (เอกสาร/PDF)"""
import html
import json
import re
from datetime import timedelta

from conftest import login
from ecs import insp_time as IT
from test_v99_32 import T, timed  # noqa: F401  (fixture)


def _od(page: str) -> tuple[str, dict]:
    m = re.search(r'<a class="kx lift kx-it"[^>]*href="([^"]+)"[^>]*data-od=\'([^\']+)\'', page)
    assert m, "ไม่พบช่องเวลาตรวจรวม"
    return html.unescape(m.group(1)), json.loads(html.unescape(m.group(2)))


def test_tile_counts_only_the_selected_date(app, client, db, timed):  # noqa: F811
    login(client, "t_admin")
    page = client.get("/dashboard").get_data(as_text=True)
    href, od = _od(page)
    assert "เวลาตรวจรวมวันนี้" in page and od["title"] == "เวลาตรวจรวม 10 น. 00 วิ."
    assert {f[0]: f[1] for f in od["facts"]}["จำนวนครั้ง"] == "3" and f"from={T.isoformat()}&to={T.isoformat()}" in href
    assert all(f"from={T.isoformat()}&to={T.isoformat()}" in r["href"] for g in od["groups"] for r in g["rows"])
    assert "itd=" not in page and 'class="it-seg"' not in page             # ไม่มีตัวเลือกช่วงแยกในช่อง
    y = T - timedelta(days=1)                                   # ดูย้อนหลัง = เลือกวันที่ด้านบน
    page = client.get(f"/dashboard?date={y.isoformat()}&days=7").get_data(as_text=True)
    href, od = _od(page)
    assert "เวลาตรวจรวมวันที่เลือก" in page and {f[0]: f[1] for f in od["facts"]}["จำนวนครั้ง"] == "0"
    assert f"from={y.isoformat()}&to={y.isoformat()}" in href
    # การ์ดด้านล่าง = ช่วง 7/30/90 วันของหน้า นับย้อนจากวันที่เลือก
    lo = html.unescape(page[page.index('id="ins-time"'):])
    assert f"from={(y - timedelta(days=6)).isoformat()}&to={y.isoformat()}" in lo
    assert f"7 วัน ({(y - timedelta(days=6)).strftime('%d/%m')}–{y.strftime('%d/%m/%Y')})" in lo
    page = client.get(f"/dashboard?date={T.isoformat()}&days=30").get_data(as_text=True)
    assert "30 วัน (" in page and "10 น. 00 วิ." in page[page.index('id="ins-time"'):]
    _, od = _od(page)
    assert any("รายงานสรุป" in x[0] and "/inspection-time/report" in x[1] for x in od["links"])


def test_page_lookback_anchored_to_end_date(app, client, db, timed):  # noqa: F811
    login(client, "t_admin")
    e = T - timedelta(days=10)
    page = html.unescape(client.get(f"/analytics/inspection-time?from={(e - timedelta(days=6)).isoformat()}&to={e.isoformat()}").get_data(as_text=True))
    for n in (7, 30, 60):
        assert f"from={(e - timedelta(days=n - 1)).isoformat()}&to={e.isoformat()}" in page
    assert ">90 วัน<" not in page and "/analytics/inspection-time/report?" in page


def test_report_document(app, client, db, timed, monkeypatch):  # noqa: F811
    login(client, "t_view")                                     # ทุกบทบาทเปิดได้
    q = f"from={T.isoformat()}&to={T.isoformat()}"
    page = client.get(f"/analytics/inspection-time/report?{q}").get_data(as_text=True)
    for s in ("รายงานสรุปเวลาการตรวจเช็ค", "สรุปรายโรงงาน", "สรุปรายพื้นที่", "สรุปรายเครื่อง / ใบตรวจ", "รายวัน",
              "ใช้เวลานานที่สุด 10 ครั้ง", "ข้อสังเกต", "ผู้จัดทำรายงาน", "Compressor Room", "<svg"):
        assert s in page, s
    assert page.count("10 น. 00 วิ.") >= 3                     # หัวสรุป · รวมรายโรงงาน · รวมรายวัน
    r = IT.report(db, T, T, None, app.config["F1"])
    assert r["head"]["sec"] == 600 and sum(a["sec"] for a in r["areas"]) == 600 and sum(m["sec"] for m in r["machines"]) == 600
    assert sum(d["sec"] for d in r["daily"]) == 600 and len(r["daily"]) == 1
    page = client.get(f"/analytics/inspection-time/report?{q}&factory={app.config['F1']}").get_data(as_text=True)
    assert "สรุปรายโรงงาน" not in page and "Compressor Room" in page
    import ecs.pdf as P
    monkeypatch.setattr(P, "html_to_pdf", lambda h, timeout=90: b"%PDF-1.4 test")
    res = client.get(f"/analytics/inspection-time/report?{q}&format=pdf")
    assert res.status_code == 200 and res.mimetype == "application/pdf" and res.data.startswith(b"%PDF")
    def boom(h, timeout=90):
        raise P.PdfError("ไม่พบเบราว์เซอร์")
    monkeypatch.setattr(P, "html_to_pdf", boom)
    res = client.get(f"/analytics/inspection-time/report?{q}&format=pdf")
    assert res.status_code == 302 and "/inspection-time/report" in res.headers["Location"]


def test_reports_index_has_time_report(app, client):
    login(client, "t_admin")
    page = client.get("/reports").get_data(as_text=True)
    assert 'id="rpTime"' in page and "/analytics/inspection-time/report" in page and 'data-rt="60"' in page


def test_tile_explains_excluded_time(app, client, db, timed):  # noqa: F811
    db.execute("DELETE FROM cs_submissions WHERE source<>'auto' AND duration_sec BETWEEN 10 AND 7200")
    db.commit()
    login(client, "t_admin")
    page = client.get("/dashboard").get_data(as_text=True)
    _, od = _od(page)
    f = {x[0]: x[1] for x in od["facts"]}
    assert f["จำนวนครั้ง"] == "0" and f["ไม่นับ: เวลาผิดปกติ"] == "2" and f["ไม่นับ: SCADA อัตโนมัติ"] == "1"
    tile = page[page.index('class="kx lift kx-it"'):]
    assert "ไม่นับ 3 ครั้ง (เวลาผิดปกติ / SCADA)" in tile[:tile.index("</a>")]
