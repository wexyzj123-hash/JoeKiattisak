"""v0.99.26: พื้นหลังเคลื่อนไหวแบบหน้าเข้าสู่ระบบในทุกหน้า + ทุกหน้าใช้ธีมแดชบอร์ดเดียวกัน"""
from conftest import login


def test_world_layer_on_every_page(client):
    login(client, "t_admin")
    for url in ("/dashboard", "/rounds", "/alerts", "/admin/users", "/forms", "/reports"):
        h = client.get(url).get_data(as_text=True)
        assert 'id="world"' in h and 'id="worldFx"' in h, url
        assert "js/scene.js" in h and "js/worldfx.js" in h, url
        assert "dash-luxe lx-page" in h, url                                      # ธีมแดชบอร์ดทุกหน้า
        assert "data-world-toggle" in h, url                                      # ปุ่มเปิด/ปิดในเมนูผู้ใช้


def test_login_uses_shared_scene_without_world(client):
    h = client.get("/login").get_data(as_text=True)
    assert "js/scene.js" in h and "js/authfx.js" in h and 'id="auFx"' in h
    assert 'id="world"' not in h and "worldfx.js" not in h                      # หน้าเข้าสู่ระบบมีฉากของตัวเองแล้ว
    assert client.get("/static/js/scene.js").status_code == 200
    assert client.get("/static/js/worldfx.js").status_code == 200


def _css():
    import pathlib
    return (pathlib.Path(__file__).resolve().parents[1] / "ecs" / "static" / "css" / "app.css").read_text(encoding="utf-8")


def _js(name):
    import pathlib
    return (pathlib.Path(__file__).resolve().parents[1] / "ecs" / "static" / "js" / name).read_text(encoding="utf-8")


def test_shift_brief_class_does_not_collide_with_backfill(client):
    """บั๊ก: หน้า SCADA ส่วน "ดึงค่าย้อนหลัง" ใช้ class="card bf" ชนกับหน้าต่างสรุปเปลี่ยนกะ (.bf = position:fixed เต็มจอ) → หน้าเพี้ยน"""
    import re
    css = _css()
    assert not re.search(r"(^|[\s,}])\.bf\s*\{", css)                         # ไม่มีกฎ .bf (ตัวเปล่า) อีก
    assert ".sbf { position: fixed;" in css and ".sbf-card" in css
    js = _js("brief.js")
    assert "className = 'sbf'" in js and "'<div class=\"bf-" not in js and "sbf-slide" in js
    assert ".sbf," in _js("peek.js")
    login(client, "t_admin")
    h = client.get("/admin/sources").get_data(as_text=True)
    assert "js/brief.js" in client.get("/dashboard").get_data(as_text=True)
    assert h                                                                   # หน้าเปิดได้


def test_global_theme_keeps_sticky_bars_print_and_menus():
    css = _css()
    # การ์ด: position relative แบบความเจาะจง 0 → แถบอนุมัติ/ตัวแก้ไข Builder/แถบบันทึก ยัง sticky ได้
    assert ":where(.lx-page) :where(.card, .chart-card) { position: relative; }" in css
    assert ".lx-page .card, .lx-page .chart-card { position: relative" not in css
    # หัวหน้าไม่ตัดขอบ (เมนู/ป๊อปอัปในหัวหน้าไม่ถูกตัด)
    head = css.split("main.lx-page > .page-head {", 1)[1].split("}", 1)[0]
    assert "overflow" not in head
    # พิมพ์: แผ่นที่ยังรอเลื่อนถึงต้องพิมพ์ออกครบ
    assert "@media print { .fx-on .dash-luxe .fx-wait" in css
    # เปิดหน้าไม่เอียง 3 มิติ (เดิมทำให้หน้ากว้างเกินจอชั่วขณะ)
    assert "@keyframes vt-rise { from { opacity: 0; transform: perspective(1400px) translateZ(-90px) translateY(26px); filter" in css
    # มือถือ: ฟอร์มดึงค่าย้อนหลังไม่ล้นจอ
    assert ".bf-form { display: grid; grid-template-columns: minmax(0, 1fr);" in css
