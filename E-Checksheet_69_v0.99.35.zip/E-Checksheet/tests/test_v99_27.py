"""v0.99.27: เนื้อหาต้องไม่ถูกซ่อนค้าง (บั๊ก: ตาราง Tag ของหน้า SCADA ยาวมาก → ไม่ปรากฏเลย เห็นแต่พื้นหลังว่าง)"""
import pathlib

FX = (pathlib.Path(__file__).resolve().parents[1] / "ecs" / "static" / "js" / "fx.js").read_text(encoding="utf-8")


def test_reveal_never_leaves_content_hidden():
    assert "threshold: 0.08" not in FX                                         # เดิม: แผ่นยาวเกิน ~12 จอ ไม่มีวันถึง 8% → ซ่อนค้าง
    assert "{ threshold: 0 }" in FX
    assert "r.height < vh * 1.2" in FX                                         # แผ่นสูงเกินจอไม่ซ่อนตั้งแต่แรก
    assert "addEventListener('scroll', soon" in FX and "getBoundingClientRect().top < window.innerHeight" in FX   # ตัวสำรองตอนเลื่อน/กระโดด
    assert "'beforeprint'" in FX and "'hashchange'" in FX


def test_scada_source_page_with_many_tags_renders(client, db, tmp_path):
    import sqlite3

    from conftest import login
    from ecs import connectors as CN
    path = str(tmp_path / "scada.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    con.commit()
    con.close()
    sid = CN.save_source(db, {"name": "BIG", "kind": "sqlite", "prefill": "0",
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 2}}, None)
    for i in range(200):                                                       # ตาราง Tag ยาวมากแบบหน้างานจริง
        db.execute("INSERT INTO cs_source_tags(source_id, tag) VALUES (?, ?)", (sid, f"BIG.TAG_{i:03d}"))
    db.commit()
    login(client, "t_admin")
    h = client.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert 'id="tags"' in h and 'id="status"' in h and 'id="backfill"' in h and 'id="fmap"' in h
    assert "BIG.TAG_199" in h
