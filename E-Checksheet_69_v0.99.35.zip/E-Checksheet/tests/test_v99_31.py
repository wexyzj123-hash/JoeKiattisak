"""v0.99.31: สถานะรายพื้นที่นับตามกะ — กติกาเดียวกับการ์ด "เช็คชีทวันนี้" (analytics.shift_scope)
วันนี้ = เฉพาะกะที่กำลังทำ · วันอื่น = ทุกกะที่เริ่มในวันนั้น · ไม่นับเครื่องหยุด · ตีกลับนับเป็นเลยกำหนด"""
from datetime import date, datetime

import pytest
from ecs import analytics as AN
from ecs import masterdata as M
from ecs.services import ts

D = date(2026, 10, 26)


@pytest.fixture()
def area_form(app, db, published_form):
    aid = M.get_or_create_area(db, app.config["F1"], "Compressor Room")
    db.execute("UPDATE equipment SET area_id=? WHERE id=?", (aid, published_form["equipment_id"]))
    sid = db.execute("INSERT INTO cs_schedules(form_id, freq_type, times, created_at, updated_at) VALUES (?, 'daily', '08:00', ?, ?)",
                     (published_form["form_id"], ts(datetime.now()), ts(datetime.now()))).lastrowid
    for due, st in (("2026-10-25 21:00:00", "done_on_time"),   # กะกลางคืนของวันที่ 25
                    ("2026-10-26 02:00:00", "missed"),         # กะกลางคืนของวันที่ 25 (หลังเที่ยงคืน)
                    ("2026-10-26 09:00:00", "done_on_time"),   # กะกลางวันวันที่ 26 ↓
                    ("2026-10-26 10:00:00", "returned"),
                    ("2026-10-26 11:00:00", "skipped"),        # เครื่องหยุด → ไม่นับ
                    ("2026-10-26 16:00:00", "pending"),
                    ("2026-10-26 21:00:00", "pending")):       # กะกลางคืนวันที่ 26
        db.execute("""INSERT INTO cs_rounds(schedule_id, form_id, due_at, deadline_at, close_at, status, updated_at)
                      VALUES (?,?,?,?,?,?,?)""", (sid, published_form["form_id"], due, due, due, st, due))
    db.commit()
    return {**published_form, "area_id": aid}


def _area(rows, aid):
    return next(a for a in rows if a["id"] == aid)


def test_area_counts_only_current_shift_like_tile(db, area_form):
    now = datetime(2026, 10, 26, 13, 0)
    a = _area(AN.area_status(db, D, now=now), area_form["area_id"])
    assert (a["done"], a["rounds"], a["done_pct"]) == (1, 3, 33)              # 09:00 จาก 09:00/10:00/16:00 (ไม่นับเครื่องหยุด)
    assert (a["overdue"], a["missed"], a["pending"]) == (1, 0, 1)             # ตีกลับนับเป็นเลยกำหนด · ขาดตรวจของกะเมื่อคืนไม่นับ
    assert a["status"] == "warning" and "ตีกลับ 1" in a["reason"] and "เลยกำหนด" not in a["reason"]
    t = AN.shift_progress(db, D, now=now)["head"]
    assert (t["done"], t["total"]) == (a["done"], a["rounds"])               # การ์ด = สถานะรายพื้นที่ (กติกาเดียวกัน)


def test_area_night_shift_and_past_day(db, area_form):
    night = _area(AN.area_status(db, D, now=datetime(2026, 10, 26, 3, 0)), area_form["area_id"])
    assert (night["done"], night["rounds"], night["missed"], night["status"]) == (1, 2, 1, "critical")   # กะ 25 ต.ค. 20:00 → 26 ต.ค. 08:00
    past = _area(AN.area_status(db, D, now=datetime(2026, 10, 28, 9, 0)), area_form["area_id"])
    assert (past["done"], past["rounds"]) == (1, 4)                           # ทุกกะที่เริ่มวันที่ 26 (กลางวัน 3 + กลางคืน 1)
    assert AN.shift_progress(db, D, now=datetime(2026, 10, 28, 9, 0))["head"]["total"] == past["rounds"]


def test_board_shows_scope_and_unassigned_note(client, db, area_form):
    from conftest import login
    login(client, "t_admin")
    h = client.get("/dashboard").get_data(as_text=True)
    assert 'class="ab-scope"' in h and "ไม่นับเครื่องหยุด" in h
    db.execute("UPDATE equipment SET area_id=NULL")
    db.execute("UPDATE cs_forms SET area_id=NULL")
    db.commit()
    day = date.today()
    exp = AN.shift_progress(db, day)["head"]["total"]                        # ใช้นาฬิกาจริงเหมือนหน้าเว็บ
    h = client.get("/dashboard?date=" + day.isoformat()).get_data(as_text=True)
    if exp:
        assert f"ไม่ระบุพื้นที่ {exp} รอบ" in h                              # รอบที่ไม่มีพื้นที่ แจ้งให้เห็น (ยอดรวมจะได้ตรงกับการ์ด)
    past = AN.shift_progress(db, D, now=datetime(2026, 10, 28, 9, 0))["head"]["total"]
    rows = AN.area_status(db, D, now=datetime(2026, 10, 28, 9, 0))
    assert past == 4 and sum(a["rounds"] for a in rows) == 0                   # ไม่มีพื้นที่ → ไม่อยู่ในกระดาน แต่การ์ดยังนับ
