"""v0.99.35: "ต้องจัดการตอนนี้" แสดงสถานะการแก้ไขของแต่ละรายการ (ขั้นตอน · ผู้รับผิดชอบ · ค้างมา · CAPA / ใบแจ้งซ่อม · ขั้นต่อไป)"""
import html
import json
import re
from datetime import date, datetime, timedelta

from conftest import login, uid
from ecs import downtime as DT
from ecs import fixflow as FX

NOW = datetime.now().replace(microsecond=0)


def _alert(db, form, status, title, created, **kw):
    cols = {"alert_type": "ng", "severity": "critical", "dedup_key": title, "form_id": form["form_id"], "equipment_id": form["equipment_id"],
            "title": title, "status": status, "created_at": str(created), "updated_at": str(NOW), **kw}
    cur = db.execute(f"INSERT INTO cs_alerts({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", list(cols.values()))
    return cur.lastrowid


def _capa(db, form, alert_id, status, due, owner, code):
    db.execute("""INSERT INTO cs_actions(code, source, alert_id, form_id, equipment_id, title, status, owner_id, due_date, created_at, updated_at)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?)""", (code, "alert", alert_id, form["form_id"], form["equipment_id"], "แก้ไข " + code, status, owner,
                                                    due, str(NOW), str(NOW)))


def test_age_text():
    assert FX.age(NOW - timedelta(minutes=45), NOW) == "45 นาที"
    assert FX.age(NOW - timedelta(hours=3, minutes=20), NOW) == "3 ชม. 20 นาที"
    assert FX.age(NOW - timedelta(days=2, hours=4), NOW) == "2 วัน 4 ชม."
    assert FX.age(None, NOW) == ""


def test_alert_stages_capa_and_wo(app, db, published_form):
    f = published_form
    sup, tech = uid(db, "t_sup"), uid(db, "t_tech")
    a_new = _alert(db, f, "open", "A-new", NOW - timedelta(hours=5))
    a_ack = _alert(db, f, "acknowledged", "A-ack", NOW - timedelta(days=1), ack_by=sup, ack_at=str(NOW))
    a_capa = _alert(db, f, "acknowledged", "A-capa", NOW - timedelta(days=3), ack_by=sup)
    _capa(db, f, a_capa, "in_progress", (date.today() - timedelta(days=1)).isoformat(), tech, "CAPA-T1")      # เลยกำหนด
    a_wo = _alert(db, f, "open", "A-wo", NOW - timedelta(hours=2), wo_id=777)
    db.execute("INSERT INTO cs_cmms_wo(wo_id, wo_number, equipment_id, status, created_at) VALUES (777, 'WO-777', ?, 'in_progress', ?)",
               (f["equipment_id"], str(NOW)))
    a_res = _alert(db, f, "resolved", "A-res", NOW - timedelta(days=2), resolved_by=tech)
    a_cls = _alert(db, f, "closed", "A-cls", NOW - timedelta(days=2))
    rows = [dict(r) for r in db.execute("SELECT * FROM cs_alerts WHERE id IN (?,?,?,?,?,?) ORDER BY id", (a_new, a_ack, a_capa, a_wo, a_res, a_cls))]
    FX.alerts(db, rows, NOW)
    fx = {r["title"]: r["fx"] for r in rows}
    assert (fx["A-new"]["stage"], fx["A-new"]["step"], fx["A-new"]["age"]) == ("new", 0, "5 ชม.")
    assert fx["A-ack"]["stage"] == "ack" and fx["A-ack"]["who"] and "CAPA" in fx["A-ack"]["next"]
    c = fx["A-capa"]
    assert c["stage"] == "doing" and c["step"] == 2 and c["capa"]["code"] == "CAPA-T1" and c["capa"]["late"] and c["late"]
    assert c["capa"]["status_th"] == "กำลังดำเนินการ" and c["who"] == c["capa"]["owner"]
    assert fx["A-wo"]["stage"] == "doing" and fx["A-wo"]["wo"]["no"] == "WO-777" and fx["A-wo"]["wo"]["status_th"] == "กำลังซ่อม"
    assert fx["A-res"]["stage"] == "check" and "รอปิดงาน" in fx["A-res"]["label"]
    assert fx["A-cls"]["stage"] == "done"
    s = {k: n for k, _t, n in FX.summary(list(fx.values()))}
    assert s == {"new": 1, "ack": 1, "doing": 2, "check": 1, "late": 1}       # ปิดงานแล้วไม่นับ


def test_rounds_and_downs(app, db, published_form):
    items = [{"status": "missed", "due_at": str(NOW - timedelta(hours=26))}, {"status": "returned", "due_at": str(NOW - timedelta(hours=1)), "inspector_name": "ช่าง ก"},
             {"status": "overdue", "due_at": str(NOW - timedelta(minutes=30))}]
    FX.rounds(items, NOW)
    assert [i["fx"]["label"].split(" · ")[0] for i in items] == ["ขาดตรวจ", "ตีกลับให้แก้ไข", "เลยกำหนด"]
    assert items[1]["fx"]["who"] == "ช่าง ก" and items[0]["fx"]["late"] and not items[1]["fx"]["late"]
    eq = published_form["equipment_id"]
    d = {"id": eq, "cat": "repair", "down_since": str(NOW - timedelta(days=2)), "late": False}
    FX.downs(db, [d], NOW)
    assert d["fx"]["stage"] == "new" and "ยังไม่มีใบงานซ่อม" in d["fx"]["label"]
    db.execute("INSERT INTO cs_cmms_wo(wo_id, wo_number, equipment_id, status, created_at) VALUES (9, 'WO-9', ?, 'pending', ?)", (eq, str(NOW)))
    FX.downs(db, [d], NOW)
    assert d["fx"]["stage"] == "ack" and d["fx"]["wo"]["no"] == "WO-9"
    db.execute("UPDATE cs_cmms_wo SET status='in_progress' WHERE wo_id=9")
    FX.downs(db, [d], NOW)
    assert d["fx"]["stage"] == "doing" and d["fx"]["step"] == 1 and d["fx"]["age"] == "2 วัน"
    s = {"id": eq, "cat": "standby", "down_since": str(NOW), "late": False}
    FX.downs(db, [s], NOW)
    assert s["fx"]["stage"] == "plan" and s["fx"]["steps"] == []


def test_dashboard_card_shows_progress(app, client, db, published_form):
    now = datetime.now().replace(microsecond=0)     # เวลาจริงตอนรัน (ชุดทดสอบเต็มรันหลายนาที)
    f = published_form
    sup, tech = uid(db, "t_sup"), uid(db, "t_tech")
    a = _alert(db, f, "acknowledged", "NG: แรงดันสูง", now - timedelta(hours=7), ack_by=sup)
    _capa(db, f, a, "in_progress", (date.today() + timedelta(days=2)).isoformat(), tech, "CAPA-D1")
    _alert(db, f, "open", "NG: อุณหภูมิสูง", now - timedelta(hours=1))
    DT.set_down(db, f["equipment_id"], sup, "มอเตอร์เสีย", "repair", expected_end=str(now + timedelta(days=1))[:16])
    db.commit()
    login(client, "t_admin")
    page = client.get("/dashboard").get_data(as_text=True)
    card = page[page.index('id="todo"'):]
    card = card[:card.index("</section>")]
    assert "สถานะการแก้ไข" in card and 'data-qs="new"' in card and 'data-qs="doing"' in card
    assert "กำลังแก้ไข" in card and "CAPA-D1 · กำลังดำเนินการ" in card and "ยังไม่มีผู้รับทราบ" in card
    assert ">กำลังซ่อม<" in card and "คาดเสร็จ" in card          # เครื่องมีงานแก้ไข (CAPA-D1) กำลังดำเนินการ → กำลังซ่อม
    assert card.count('class="fx-steps"') >= 3 and 'data-stage="doing"' in card and 'data-stage="new"' in card
    m = re.search(r'data-od=\'([^\']+)\'>\s*<span class="od-dot t-\w+"[^>]*>[^<]*</span>\s*<span class="qx-t"><b>NG: แรงดันสูง', card)
    od = json.loads(html.unescape(m.group(1)))
    facts = {x[0]: x[1] for x in od["facts"]}
    assert facts["ขั้นการแก้ไข"] == "กำลังแก้ไข" and facts["ค้างมา"].startswith("7 ชม.") and facts["งานแก้ไข (CAPA)"].startswith("CAPA-D1")
    assert facts["ขั้นต่อไป"] and facts["ผู้รับผิดชอบ"] != "ยังไม่ระบุ"
