"""v0.99.32: เวลาตรวจเช็ค รวมทุกโรงงาน → โรงงาน → พื้นที่ → เครื่อง → รายการ (ecs/insp_time.py)"""
import io
import uuid
from datetime import date, datetime, timedelta

import pytest
from conftest import login, uid
from ecs import insp_time as IT
from ecs import masterdata as M
from openpyxl import load_workbook

T = date.today()


@pytest.fixture()
def timed(app, db, published_form):
    aid = M.get_or_create_area(db, app.config["F1"], "Compressor Room")
    db.execute("UPDATE equipment SET area_id=? WHERE id=?", (aid, published_form["equipment_id"]))
    tech = uid(db, "t_tech")
    day = datetime.combine(T, datetime.min.time())
    for h, sec, src, st in ((9, 120, "v3", "submitted"), (10, 300, "v3", "submitted"), (21, 180, "v3", "submitted"),   # นับ 3 ใบ = 600 วิ.
                            (11, 5, "v3", "submitted"),            # สั้นกว่า 10 วิ. → ไม่นับ
                            (12, 9000, "v3", "submitted"),         # นานกว่า 2 ชม. (เปิดค้าง) → ไม่นับ
                            (13, 200, "auto", "submitted"),        # ลงจาก SCADA อัตโนมัติ → ไม่นับ
                            (14, 200, "v3", "superseded")):        # ถูกส่งแทนแล้ว → ไม่อยู่ในข้อมูล
        fin = day + timedelta(hours=h)
        db.execute("""INSERT INTO cs_submissions(client_uuid, form_id, form_version_id, equipment_id, inspector_id, scanned_at, finished_at,
                      received_at, duration_sec, status, source, ng_count) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                   (str(uuid.uuid4()), published_form["form_id"], published_form["version_id"], published_form["equipment_id"], tech,
                    str(fin - timedelta(seconds=sec)), str(fin), str(fin), sec, st, src, 1 if h == 9 else 0))
    db.commit()
    return {**published_form, "area_id": aid}


def test_counts_only_trustworthy_time(app, db, timed):
    s = IT.summary(db, T, T)
    h = s["head"]
    assert (h["sec"], h["n"], h["avg"], h["med"], h["max"]) == (600, 3, 200, 180, 300)
    assert (h["bad"], h["auto"], h["ng"]) == (2, 1, 1)
    assert h["shift_day"] + h["shift_night"] == 600 and h["shift_night"] == 180       # 21:00 = กะกลางคืน
    f = s["children"][0]
    assert s["level"] == "factory" and f["sec"] == 600 and f["share"] == 100.0 and f["areas"][0]["label"] == "Compressor Room"


def test_drill_down_levels_add_up(app, db, timed):
    fac = IT.summary(db, T, T, factory_id=app.config["F1"])
    assert fac["level"] == "area" and sum(c["sec"] for c in fac["children"]) == fac["head"]["sec"] == 600
    ar = IT.summary(db, T, T, factory_id=app.config["F1"], area_id=timed["area_id"])
    assert ar["level"] == "machine" and ar["children"][0]["form_id"] == timed["form_id"] and ar["children"][0]["sec"] == 600
    it = IT.summary(db, T, T, factory_id=app.config["F1"], area_id=timed["area_id"], form_id=timed["form_id"])
    assert it["level"] == "items" and len(it["subs"]) == 6 and sum(r["duration_sec"] for r in it["subs"] if r["ok"]) == 600
    assert IT.summary(db, T, T, factory_id=app.config["F2"])["head"]["n"] == 0
    assert round(sum(sum(x["data"]) for x in it["series"]) * 60) == 600


def test_fmt_dur():
    assert (IT.fmt_dur(None), IT.fmt_dur(45), IT.fmt_dur(750), IT.fmt_dur(3900), IT.fmt_dur(90000)) == ("–", "45 วิ.", "12 น. 30 วิ.", "1 ชม. 05 น.", "25 ชม. 00 น.")


def test_pages_permissions_and_excel(app, client, db, timed):
    login(client, "t_admin")
    q = f"from={T.isoformat()}&to={T.isoformat()}"
    for u in ("", f"&factory={app.config['F1']}", f"&factory={app.config['F1']}&area={timed['area_id']}",
              f"&factory={app.config['F1']}&area={timed['area_id']}&form={timed['form_id']}"):
        r = client.get(f"/analytics/inspection-time?{q}{u}")
        assert r.status_code == 200, u
    h = client.get(f"/analytics/inspection-time?{q}").get_data(as_text=True)
    assert "10 น. 00 วิ." in h and "เวลาตรวจรายคน" in h and "Compressor Room" in h
    d = client.get("/dashboard").get_data(as_text=True)
    assert 'id="ins-time"' in d and "/analytics/inspection-time" in d
    x = client.get(f"/analytics/inspection-time.xlsx?{q}")
    ws = load_workbook(io.BytesIO(x.data)).active
    rows = list(ws.iter_rows(values_only=True))[1:]
    assert len(rows) == 6 and sorted(r[6] for r in rows if r[5] == "ไม่") == ["นานกว่า 2 ชั่วโมง (เปิดค้าง)", "ลงจาก SCADA อัตโนมัติ", "สั้นกว่า 10 วินาที"]
    client.get("/logout")
    login(client, "t_tech")
    h = client.get(f"/analytics/inspection-time?{q}").get_data(as_text=True)
    assert "เวลาตรวจเช็ค" in h and "เวลาตรวจรายคน" not in h                    # ช่างไม่เห็นเวลารายคน
