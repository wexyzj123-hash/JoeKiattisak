"""v0.99.36: แท็บที่เลือกต้องอยู่ในจอ · ผังโรงงานซ้อนคอลัมน์บนจอเล็ก · หน้าเวลาตรวจไม่ล้นขอบบนมือถือ"""
from pathlib import Path

from conftest import login

CSS = (Path(__file__).resolve().parents[1] / "ecs" / "static" / "css" / "app.css").read_text(encoding="utf-8")


def test_active_tab_is_scrolled_into_view(app, client):
    login(client, "t_admin")
    page = client.get("/admin/health").get_data(as_text=True)
    assert "document.querySelectorAll('nav.tabs')" in page and "n.scrollLeft" in page        # สคริปต์เลื่อนแท็บที่เลือกให้อยู่ในจอ
    assert 'class="active">สถานะระบบ / แบ็กอัป' in page


def test_layout_page_columns_stack_on_small_screens(app, client):
    login(client, "t_admin")
    page = client.get("/admin/layout").get_data(as_text=True)
    assert 'class="dgrid lay-grid"' in page and 'style="grid-column' not in page              # ไม่ล็อกคอลัมน์ด้วย style ในหน้า
    assert '<section class="dcard span-8">' in page and '<section class="dcard span-4">' in page
    assert ".lay-grid > .span-8, .lay-grid > .span-4 { grid-column: span 12; }" in CSS


def test_inspection_time_columns_fit_phone():
    assert "minmax(min(380px, 100%), 1fr)" in CSS and ".it-cols > * { min-width: 0; }" in CSS


def test_batch_files_use_crlf():
    """ไฟล์ .bat ต้องขึ้นบรรทัดแบบ Windows (CRLF) — ถ้าเป็น LF ล้วน cmd.exe อ่านภาษาไทย (UTF-8) เพี้ยนเป็นคำสั่งแตก ๆ
    (พบจากการทดสอบบน Windows จริง: run_tests.bat ขึ้น '...' is not recognized แล้วล้มทันที)"""
    root = Path(__file__).resolve().parents[1]
    bats = sorted(root.glob("*.bat")) + sorted(root.glob("tools/*.bat"))
    assert bats
    for f in bats:
        data = f.read_bytes()
        lf = data.count(b"\n")
        assert lf and data.count(b"\r\n") == lf, f"{f.name}: ต้องเป็น CRLF ทุกบรรทัด"
