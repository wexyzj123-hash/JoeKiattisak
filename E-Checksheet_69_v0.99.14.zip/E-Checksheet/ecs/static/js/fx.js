/* v0.99.14 ภาพเคลื่อนไหวทั้งระบบ
   1) เปลี่ยนหน้า: เมนูซ้าย/แถบบนอยู่นิ่ง เนื้อหาเก่าจมลง เนื้อหาใหม่ลอยขึ้นมา (View Transitions ข้ามหน้า · CSS ใน app.css)
      ไฮไลต์เมนูที่เลือกเลื่อนจากเมนูเดิมไปเมนูใหม่ · เบราว์เซอร์ที่ไม่รองรับ: เนื้อหาใหม่ลอยขึ้นตอนโหลด
   2) แถบความคืบหน้าเรืองแสงด้านบนทันทีที่กดเมนู/ลิงก์ (รู้ว่ากำลังไป แม้เซิร์ฟเวอร์ช้า)
   3) หน้าภาพรวม: แผ่นเนื้อหาลอยขึ้นแบบ 3 มิติเมื่อเลื่อนถึง · แสงตามเมาส์บนแผ่นและแถบหัว
   ตั้งค่า "ลดการเคลื่อนไหว" ในเครื่อง → ปิดทั้งหมด */
(function () {
  'use strict';
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = window.matchMedia && window.matchMedia('(pointer: fine)').matches;
  const root = document.documentElement;

  // ── 1) เมนูที่เลือกตั้งชื่อใน base.html (ทันทีหลังเมนูซ้าย) · จับ pagereveal ใน <head> → window.__vt
  function trackVT(vt) {
    if (!vt) { enterFallback(); return; }
    root.dataset.vt = 'run';
    vt.finished.then(() => { root.dataset.vt = 'done'; }, () => { root.dataset.vt = 'skip'; });
  }
  window.addEventListener('pagereveal', (e) => trackVT(e.viewTransition));
  function enterFallback() {
    if (reduce) return;
    const m = document.querySelector('main.page'); if (!m) return;
    m.classList.add('pg-enter');
    m.addEventListener('animationend', () => m.classList.remove('pg-enter'), { once: true });
  }

  // ── 2) แถบความคืบหน้า
  let bar = null;
  function startBar() {
    if (!bar) { bar = document.createElement('div'); bar.className = 'navbar-fx'; bar.setAttribute('aria-hidden', 'true'); document.body.appendChild(bar); }
    bar.classList.remove('done'); void bar.offsetWidth; bar.classList.add('go');
  }
  function stopBar() { if (bar) { bar.classList.remove('go'); bar.classList.add('done'); } }
  document.addEventListener('click', (e) => {
    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest && e.target.closest('a[href]'); if (!a) return;
    if (a.target && a.target !== '_self') return;
    if (a.hasAttribute('download') || a.closest('[data-od]') || a.hasAttribute('data-od')) return;
    const href = a.getAttribute('href') || '';
    if (!href || href.charAt(0) === '#' || /^(javascript|mailto|tel):/i.test(href)) return;
    let u; try { u = new URL(a.href, location.href); } catch (err) { return; }
    if (u.origin !== location.origin || (u.pathname === location.pathname && u.search === location.search && u.hash)) return;
    if (/\.(pdf|xlsx|csv|zip|png|jpe?g)$/i.test(u.pathname) || /[?&]format=(xlsx|pdf|csv)/.test(u.search)) return;
    setTimeout(() => { if (!e.defaultPrevented) startBar(); }, 0);
  });
  document.addEventListener('submit', (e) => {
    const f = e.target; if (!f || f.target === '_blank') return;
    setTimeout(() => { if (!e.defaultPrevented && (f.method || 'get').toLowerCase() === 'get') startBar(); }, 0);
  });
  window.addEventListener('pageshow', stopBar);

  // ── 3) หน้าภาพรวม
  function dash() {
    const page = document.querySelector('main.dash-luxe'); if (!page || reduce) return;
    root.classList.add('fx-on');
    const vh = window.innerHeight;
    const sheets = [...page.querySelectorAll('.dgrid > section, .dgrid > .dcard')];
    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver((ents) => ents.forEach((en) => {
        if (!en.isIntersecting) return;
        const el = en.target; io.unobserve(el);
        const sib = [...el.parentElement.children].filter((x) => x.classList.contains('fx-wait'));
        el.style.animationDelay = Math.max(0, sib.indexOf(el)) * 90 + 'ms';
        el.classList.remove('fx-wait'); el.classList.add('fx-in');
        el.addEventListener('animationend', () => { el.classList.remove('fx-in'); el.style.animationDelay = ''; }, { once: true });
      }), { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
      sheets.forEach((el) => { if (el.getBoundingClientRect().top > vh * 0.92) { el.classList.add('fx-wait'); io.observe(el); } });
    }
    if (!fine) return;
    const spot = (el) => el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect();
      el.style.setProperty('--mx', (e.clientX - r.left) + 'px'); el.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
    page.querySelectorAll('.dcard, .lx-hero').forEach(spot);
  }

  function init() {
    dash();
    if (window.__revealed) trackVT(window.__vt);
    else if (!('onpagereveal' in window)) enterFallback();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
