"""ecs/energy_profile.py — v0.99.41 ค่าราย 15 นาทีจากเลขหน้าปัดสะสม (SCADA แบบ "ค่าอ่านมิเตอร์")

เดิม: แหล่ง SCADA ที่เก็บเลขหน้าปัดสะสม (kWh สะสมทุก 15 นาทีใน SQL Server) ระบบเลือกไว้แค่วันละ 1 ค่า (ณ เวลาอ่าน 08:00)
ค่าอื่นทั้งวันถูกทิ้ง → หน้ารายช่วงเวลา / กราฟ 15 นาที / "วันนี้ใช้ไปเท่าไหร่" ว่างเปล่า

ตอนนี้: เก็บทุกค่าที่ดึงมา (หลังคูณ scale + offset ของ Tag) ลง en_profile แล้วคำนวณการใช้ต่อช่วง = ผลต่างของเลขสะสม × CT
- เลขสะสม ณ ขอบช่วงเวลา (00:00, 00:15, …) = ค่าที่เวลาตรง หรือประมาณเส้นตรงจากค่าก่อน/หลัง (ห่างกันไม่เกิน 75 นาที)
- ผลต่างติดลบ (มิเตอร์รีเซ็ต/เปลี่ยน) = ไม่นับ · ช่วงที่ไม่มีข้อมูล = ว่าง (ไม่เดา)
- ค่าอ่านรายวัน (en_readings) ไม่เปลี่ยน — ใช้ระบบเดิม
"""
from __future__ import annotations

import bisect
import json
import logging
import math
from datetime import date, datetime, time, timedelta

from . import services as S
from .services import parse_ts, ts

log = logging.getLogger(__name__)

DDL = """
CREATE TABLE IF NOT EXISTS en_profile (
    meter_id  INTEGER NOT NULL,
    ts        TEXT NOT NULL,
    value     REAL NOT NULL,
    PRIMARY KEY (meter_id, ts)
) WITHOUT ROWID;
"""
SLOT_MIN = 15
MAX_SPAN_MIN = 75                 # ค่าก่อน/หลังห่างกันเกินนี้ → ไม่ประมาณเลขสะสม ณ ขอบช่วง
KEEP_DAYS = 400
AUTO_DAYS = 8                     # รอบดึงปกติเติมย้อนหลังเองให้ครบ วันนี้ · เมื่อวาน · สัปดาห์ก่อน
RETRY_H = 6
TAG_CHUNK = 150                   # Tag ต่อคำสั่ง SQL (1 วัน × 96 ค่า × 150 Tag = 14,400 แถว < เพดาน 50,000)


def ensure(db) -> None:
    db.executescript(DDL)


# ───────────────────────── เก็บค่า ─────────────────────────

def _tagmap(db, sid: int, only: set | None = None) -> dict[str, list[int]]:
    out: dict[str, list[int]] = {}
    for mid, tag in db.execute("SELECT id, TRIM(scada_tag) FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>'' AND active=1", (sid,)):
        if only is None or mid in only:
            out.setdefault(tag, []).append(mid)
    return out


def store(db, source: dict, rows, now: datetime | None = None, only: set | None = None) -> int:
    """เก็บเลขสะสมทุกค่าของ Tag ที่ผูกมิเตอร์ → จำนวนค่าที่เก็บ (ไม่รวมค่าเวลาในอนาคต / ค่านอกช่วงที่เป็นไปได้)"""
    from . import energy_interval as EI
    if EI.is_interval(source) or not rows:
        return 0
    ensure(db)
    tagmap = _tagmap(db, source["id"], only)
    if not tagmap:
        return 0
    sc = {r[0].strip(): (r[1], r[2], r[3], r[4]) for r in db.execute(
        "SELECT tag, scale, add_offset, valid_min, valid_max FROM en_source_tags WHERE source_id=?", (source["id"],))}
    lim = (now or S.now_dt()) + timedelta(minutes=15)
    out: dict[tuple[int, str], float] = {}
    for tag, dt, val in rows:
        t = str(tag).strip()
        mids = tagmap.get(t)
        if not mids or val is None or dt is None or dt > lim:
            continue
        try:
            k_, o_, lo_, hi_ = sc.get(t, (1.0, 0.0, None, None))
            v = float(val) * (k_ or 1.0) + (o_ or 0.0)
        except (TypeError, ValueError):
            continue
        if math.isnan(v) or v < 0 or (lo_ is not None and v < lo_) or (hi_ is not None and v > hi_):
            continue
        stamp = ts(dt.replace(microsecond=0))
        for mid in mids:
            out[(mid, stamp)] = v
    db.executemany("""INSERT INTO en_profile(meter_id, ts, value) VALUES (?,?,?)
                      ON CONFLICT(meter_id, ts) DO UPDATE SET value=excluded.value""", [(m, s, v) for (m, s), v in out.items()])
    return len(out)


def prune(db, now: datetime | None = None, keep_days: int = KEEP_DAYS) -> int:
    ensure(db)
    return db.execute("DELETE FROM en_profile WHERE ts<?", (ts((now or S.now_dt()) - timedelta(days=keep_days)),)).rowcount


def backfill(db, src: dict, d_from: date, d_to: date, now: datetime | None = None, meter_ids=None) -> dict:
    """ดึงค่าทั้งวันจาก SQL ทีละวัน (เฉพาะ Tag ที่ผูกมิเตอร์) แล้วเก็บ → {days, rows, no_data: [วัน]}"""
    from . import energy_interval as EI
    from . import energy_src as ES
    now = now or S.now_dt()
    if src.get("kind") == "csv" or EI.is_interval(src):
        return {"days": 0, "rows": 0, "no_data": []}
    only = set(meter_ids) if meter_ids else None
    tags = sorted(_tagmap(db, src["id"], only))
    if not tags:
        return {"days": 0, "rows": 0, "no_data": []}
    d_to = min(d_to, now.date())
    n_days, n_rows, empty = 0, 0, []
    d = d_from
    while d <= d_to:
        a = datetime.combine(d, time(0, 0)) - timedelta(minutes=MAX_SPAN_MIN)        # ค่าก่อนเที่ยงคืน → ขอบช่วง 00:00 ประมาณได้
        b = min(datetime.combine(d + timedelta(days=1), time(0, 0)) + timedelta(minutes=MAX_SPAN_MIN), now)
        got = 0
        for i in range(0, len(tags), TAG_CHUNK):
            fsrc = dict(src)
            rows, _k, _b = ES.fetch(db, fsrc, now, tags=tags[i:i + TAG_CHUNK], since=a, until=b)
            got += store(db, fsrc, rows, now, only)
        n_days += 1
        n_rows += got
        if not got:
            empty.append(d)
        d += timedelta(days=1)
    return {"days": n_days, "rows": n_rows, "no_data": empty}


def auto_fill(db, src: dict, now: datetime | None = None, days: int = AUTO_DAYS) -> int:
    """รอบดึงปกติ: วันล่าสุด {days} วันที่ยังไม่มีค่าราย 15 นาที → ดึงทั้งวันจาก SQL (วันที่ SQL ไม่มีข้อมูล ลองใหม่ทุก 6 ชม.)"""
    from . import energy_interval as EI
    now = now or S.now_dt()
    if src.get("kind") == "csv" or EI.is_interval(src):
        return 0
    ensure(db)
    ids = [r[0] for r in db.execute("SELECT id FROM en_meters WHERE scada_source_id=? AND TRIM(scada_tag)<>'' AND active=1", (src["id"],))]
    if not ids:
        return 0
    key = f"en_profile_try:{src['id']}"
    row = db.execute("SELECT value FROM cs_meta WHERE key=?", (key,)).fetchone()
    tried = json.loads(row[0]) if row and row[0] else {}
    ph = ",".join("?" * len(ids))
    total = 0
    for k in range(days - 1, -1, -1):
        d = now.date() - timedelta(days=k)
        a = datetime.combine(d, time(0, 0))
        span = min(now, a + timedelta(days=1)) - a
        expect = int(span.total_seconds() // (SLOT_MIN * 60))
        got = dict(db.execute(f"""SELECT meter_id, COUNT(DISTINCT substr(ts, 1, 13) || (CAST(substr(ts, 15, 2) AS INTEGER) / {SLOT_MIN}))
                                  FROM en_profile WHERE ts>=? AND ts<? AND meter_id IN ({ph}) GROUP BY meter_id""",
                              [ts(a), ts(a + timedelta(days=1)), *ids]).fetchall())
        if expect <= 1 or min(got.get(i, 0) for i in ids) >= expect * 0.9:      # ทุกมิเตอร์มีค่า ≥ 90% ของช่วง 15 นาทีที่ควรมี
            continue
        last = parse_ts(tried.get(d.isoformat())) if tried.get(d.isoformat()) else None
        if last and now - last < timedelta(hours=RETRY_H if k else 1):
            continue
        total += backfill(db, src, d, d, now)["rows"]
        tried[d.isoformat()] = ts(now)
    keep = (now.date() - timedelta(days=days + 1)).isoformat()
    tried = {d: v for d, v in tried.items() if d >= keep}
    db.execute("INSERT INTO cs_meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, json.dumps(tried)))
    return total


# ───────────────────────── คำนวณ ─────────────────────────

def _points(db, ids: list[int], a: datetime, b: datetime) -> dict[int, tuple[list[datetime], list[float]]]:
    out: dict[int, tuple[list, list]] = {}
    for i in range(0, len(ids), 800):
        ch = ids[i:i + 800]
        for mid, stamp, v in db.execute(f"""SELECT meter_id, ts, value FROM en_profile WHERE ts>=? AND ts<=?
                                            AND meter_id IN ({','.join('?' * len(ch))}) ORDER BY meter_id, ts""",
                                        [ts(a), ts(b), *ch]):
            t_, v_ = out.setdefault(mid, ([], []))
            t_.append(parse_ts(stamp))
            v_.append(float(v))
    return out


def cum_at(pts: tuple[list[datetime], list[float]], t: datetime) -> float | None:
    """เลขสะสม ณ เวลา t: ค่าที่เวลาตรง หรือเส้นตรงระหว่างค่าก่อน/หลัง (ห่างกันไม่เกิน 75 นาที และค่าไม่ลดลง)"""
    tt, vv = pts
    i = bisect.bisect_left(tt, t)
    if i < len(tt) and tt[i] == t:
        return vv[i]
    if i == 0 or i >= len(tt):
        return None
    t0, t1, v0, v1 = tt[i - 1], tt[i], vv[i - 1], vv[i]
    if (t1 - t0).total_seconds() > MAX_SPAN_MIN * 60 or v1 < v0:
        return None
    return v0 + (v1 - v0) * (t - t0).total_seconds() / (t1 - t0).total_seconds()


def _mults(db, ids) -> dict[int, float]:
    if not ids:
        return {}
    return {r[0]: float(r[1] or 1) for r in db.execute(f"SELECT id, multiplier FROM en_meters WHERE id IN ({','.join('?' * len(ids))})", list(ids))}


def slots(db, ids: list[int], a: datetime, b: datetime, slot_min: int = SLOT_MIN) -> dict[int, list[float | None]]:
    """{meter_id: [การใช้ต่อช่วง]} ของช่วง [a, b) แบ่งทีละ slot_min นาที (ผลต่างเลขสะสม × CT) — มิเตอร์ที่ไม่มีค่าเลยไม่อยู่ในผล"""
    ensure(db)
    if not ids:
        return {}
    pts = _points(db, ids, a - timedelta(minutes=MAX_SPAN_MIN), b + timedelta(minutes=MAX_SPAN_MIN))
    mult = _mults(db, list(pts))
    n = int((b - a).total_seconds() // (slot_min * 60))
    out: dict[int, list] = {}
    for mid, p in pts.items():
        k = mult.get(mid, 1.0)
        edges = [cum_at(p, a + timedelta(minutes=slot_min * i)) for i in range(n + 1)]
        row = [None] * n
        for i in range(n):
            c0, c1 = edges[i], edges[i + 1]
            if c0 is not None and c1 is not None and c1 >= c0:
                row[i] = round((c1 - c0) * k, 6)
        if any(v is not None for v in row):
            out[mid] = row
    return out


def last_ts(db, ids: list[int]) -> str | None:
    ensure(db)
    best = None
    for i in range(0, len(ids or []), 800):
        ch = ids[i:i + 800]
        r = db.execute(f"SELECT MAX(ts) FROM en_profile WHERE meter_id IN ({','.join('?' * len(ch))})", ch).fetchone()[0]
        if r and (not best or r > best):
            best = r
    return best


def has_profile(db) -> dict[str, int]:
    ensure(db)
    return {r[0]: r[1] for r in db.execute("""SELECT m.kind, COUNT(DISTINCT m.id) FROM en_meters m
                                              WHERE EXISTS (SELECT 1 FROM en_profile p WHERE p.meter_id=m.id) GROUP BY m.kind""")}


def _usage(p, k: float, t0: datetime, t1: datetime) -> float | None:
    c0, c1 = cum_at(p, t0), cum_at(p, t1)
    if c0 is None or c1 is None or c1 < c0:
        return None
    return (c1 - c0) * k


def now_summary(db, m: dict, now: datetime | None = None) -> dict:
    """“วันนี้ใช้ไปเท่าไหร่ / ชั่วโมงนี้ใช้ไปเท่าไหร่” ของมิเตอร์ (นับตามวันปฏิทิน 00:00) + เทียบเวลาเดียวกันของเมื่อวาน / สัปดาห์ก่อน"""
    from . import energy as EN
    ensure(db)
    now = now or S.now_dt()
    mid = m["id"]
    kind = m.get("kind") or "elec"
    unit = m.get("unit") or EN.KINDS.get(kind, {}).get("unit", "")
    base = {"meter_id": mid, "unit": unit, "rate_unit": "kW" if kind == "elec" else f"{unit}/ชม.", "now": ts(now), "has": False}
    k = float(m.get("multiplier") or 1)
    today0 = datetime.combine(now.date(), time(0, 0))
    p = _points(db, [mid], today0 - timedelta(days=8) - timedelta(minutes=MAX_SPAN_MIN), now + timedelta(minutes=15)).get(mid)
    src = "profile"
    if not p or not p[0]:
        p = _interval_cum(db, mid, today0 - timedelta(days=8), now)                # แหล่งแบบค่าต่อช่วง → สะสมเอง
        src, k = "interval", 1.0
    if not p or not p[0]:
        return base
    tt, vv = p
    last_t = max(t for t in tt if t <= now + timedelta(minutes=15))
    i_last = tt.index(last_t)
    v_last = vv[i_last]
    ref = min(last_t, now)

    def at(t: datetime) -> float | None:
        if t >= last_t:
            return v_last
        return cum_at(p, t)

    def used(t0: datetime, t1: datetime) -> float | None:
        c0, c1 = at(t0), at(t1)
        if c0 is None or c1 is None or c1 < c0:
            return None
        return round((c1 - c0) * k, 4)

    # วันนี้: ถ้าไม่มีค่าก่อน/ตรง 00:00 → ใช้ค่าแรกของวัน (บอกเวลาเริ่มนับ)
    start, note = today0, ""
    if at(today0) is None:
        first = next((t for t in tt if t >= today0), None)
        if first is not None and first <= ref:
            start, note = first, f"นับตั้งแต่ {first:%H:%M} (ไม่มีค่า 00:00)"
    today = used(start, ref) if ref >= start else None
    elapsed = ref - start
    hour0 = ref.replace(minute=0, second=0, microsecond=0)
    hour = used(hour0, ref)
    prev_hour = used(hour0 - timedelta(hours=1), hour0)
    # อัตราปัจจุบัน: ค่าล่าสุดเทียบกับค่าก่อนหน้า ~15 นาที
    rate = None
    j = bisect.bisect_right(tt, last_t - timedelta(minutes=10)) - 1        # ค่าก่อนหน้าที่ห่างอย่างน้อย 10 นาที (ข้อมูลทุก 15 นาที → ค่าก่อนหน้า)
    if 0 <= j < i_last:
        dt_h = (last_t - tt[j]).total_seconds() / 3600
        if 0 < dt_h <= 1.5 and vv[i_last] >= vv[j]:
            rate = round((vv[i_last] - vv[j]) * k / dt_h, 3)

    def same(days: int) -> dict:
        s = start - timedelta(days=days)
        e = s + elapsed
        return {"so_far": used(s, e) if elapsed.total_seconds() > 0 else None,
                "hour": used(hour0 - timedelta(days=days), ref - timedelta(days=days)),
                "full": used(today0 - timedelta(days=days), today0 - timedelta(days=days - 1))}
    yd, wk = same(1), same(7)

    def pct(a, b):
        return round(100 * (a - b) / b, 1) if a is not None and b else None
    hours = []
    for h in range(24):
        t0 = today0 + timedelta(hours=h)
        cur = used(t0, min(t0 + timedelta(hours=1), ref)) if t0 < ref else None
        hours.append({"h": f"{h:02d}:00", "today": cur, "yday": used(t0 - timedelta(days=1), t0 - timedelta(days=1) + timedelta(hours=1)),
                      "week": used(t0 - timedelta(days=7), t0 - timedelta(days=7) + timedelta(hours=1)),
                      "partial": t0 <= ref < t0 + timedelta(hours=1)})
    age = (now - last_t).total_seconds() / 60
    return {**base, "has": True, "src": src, "last": ts(last_t), "age_min": round(max(age, 0)), "stale": age > 90,
            "start": ts(start), "note": note, "today": today, "hour": hour, "hour_from": f"{hour0:%H:%M}", "hour_to": f"{ref:%H:%M}",
            "prev_hour": prev_hour, "prev_hour_lbl": f"{hour0 - timedelta(hours=1):%H:%M}–{hour0:%H:%M}", "rate": rate,
            "yday": yd, "week": wk, "vs_yday": pct(today, yd["so_far"]), "vs_week": pct(today, wk["so_far"]),
            "hour_vs_yday": pct(hour, yd["hour"]), "hours": hours, "reading": round(v_last, 3) if src == "profile" else None}


def _interval_cum(db, mid: int, a: datetime, b: datetime):
    """ค่าต่อช่วง (en_intervals) → เลขสะสมสมมติ ณ ปลายช่วง เพื่อใช้สูตรเดียวกัน"""
    rows = db.execute("SELECT ts, value FROM en_intervals WHERE meter_id=? AND ts>=? AND ts<=? ORDER BY ts", (mid, ts(a), ts(b))).fetchall()
    if not rows:
        return None
    tt, vv, run = [], [], 0.0
    first = parse_ts(rows[0][0])
    tt.append(first)
    vv.append(0.0)
    for i, (stamp, v) in enumerate(rows):
        t0 = parse_ts(stamp)
        nxt = parse_ts(rows[i + 1][0]) if i + 1 < len(rows) else None
        step = min(nxt - t0, timedelta(minutes=60)) if nxt else timedelta(minutes=SLOT_MIN)
        run += float(v)
        end = t0 + step
        if end > tt[-1]:
            tt.append(end)
            vv.append(run)
    return tt, vv
