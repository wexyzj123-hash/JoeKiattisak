"""v0.99.41: Energy — ค่าราย 15 นาทีจากเลขหน้าปัดสะสม (SQL Server เก็บทุก 15 นาที)
· เก็บทุกค่าที่ดึง (เดิมใช้แค่วันละ 1 ค่า) · ผลต่างทุก 15 นาที × CT · “วันนี้ / ชั่วโมงนี้ใช้ไปเท่าไหร่” + เทียบเมื่อวาน
· รอบดึงปกติเติมย้อนหลัง 8 วันเอง · หน้ารายช่วงเวลา / หน้ามิเตอร์ / CSV ใช้ได้กับแหล่งแบบเลขสะสม"""
import json
import sqlite3
from datetime import datetime, time, timedelta

from _scada_sim import build, value
from conftest import login
from ecs import energy as EN
from ecs import energy_live as LV
from ecs import energy_profile as PR
from ecs import energy_src as ES
from ecs import services as S


def _setup(app, db, tmp_path, tags=("KA",), days=10, step=15, mult=None):
    now = S.now_dt()
    path = str(tmp_path / "scada.db")
    t0 = build(path, now, days=days, step_min=step)
    sid = ES.save_source(db, {"name": "SQL", "kind": "sqlite", "active": "1", "config": json.dumps({
        "path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 1})}, None)
    ms = {}
    for t in tags:
        d = {"factory_id": app.config["F1"], "kind": "elec", "code": t, "name": t, "scada_source_id": str(sid), "scada_tag": t}
        if mult:
            d["multiplier"] = str(mult)
        ms[t] = EN.save_meter(db, None, d, None)
    db.commit()
    return now, path, t0, sid, ms


def _last_pt(now, step=15):
    t = now.replace(second=0, microsecond=0)
    return t - timedelta(minutes=t.minute % step)


def test_profile_stored_and_today_hour_exact(app, db, tmp_path):
    now, _p, t0, sid, ms = _setup(app, db, tmp_path, mult=2)
    r = ES.run_source(db, sid, now=now)
    db.commit()
    assert r["ok"], r["message"]
    mid = ms["KA"]
    assert db.execute("SELECT COUNT(*) FROM en_profile WHERE meter_id=?", (mid,)).fetchone()[0] > 96 * 7     # เติมย้อนหลัง 8 วันเอง
    N = PR.now_summary(db, EN.meter(db, mid), now)
    last = _last_pt(now)
    today0 = datetime.combine(now.date(), time(0, 0))
    assert N["has"] and N["last"] == S.ts(last)
    assert abs(N["today"] - 2 * (value("KA", last, t0) - value("KA", today0, t0))) < 1e-3                  # × CT 2
    h0 = last.replace(minute=0)
    assert abs(N["hour"] - 2 * (value("KA", last, t0) - value("KA", h0, t0))) < 1e-3
    assert abs(N["prev_hour"] - 2 * 50.0) < 1e-3                                                             # 50 kWh/ชม. × 2
    assert abs(N["yday"]["full"] - 2 * 50.0 * 24) < 1e-3
    if N["today"]:
        assert N["vs_yday"] == 0.0, (N["today"], N["yday"], N["start"], N["last"])                                                                            # ใช้เท่าเมื่อวานช่วงเดียวกัน
    assert abs(N["rate"] - 100.0) < 1e-3 or last - timedelta(minutes=15) < today0 - timedelta(days=8)
    assert len(N["hours"]) == 24 and abs(N["hours"][3]["yday"] - 100.0) < 1e-3
    assert db.execute("SELECT COUNT(*) FROM en_readings WHERE meter_id=?", (mid,)).fetchone()[0] >= 1      # ค่าอ่านรายวันเดิมยังลงตามปกติ


def test_slots_15min_and_live_dashboard(app, db, tmp_path):
    now, _p, _t0, sid, ms = _setup(app, db, tmp_path, tags=("KA", "KB"), step=2)
    ES.run_source(db, sid, now=now)
    db.commit()
    yd = (now - timedelta(days=1)).date()
    a = datetime.combine(yd, time(0, 0))
    sl = PR.slots(db, [ms["KA"]], a, a + timedelta(days=1))[ms["KA"]]
    assert len(sl) == 96 and all(abs(v - 12.5) < 1e-6 for v in sl)                                         # 50/ชม. = 12.5 ทุก 15 นาที
    d = LV.data(db, "elec", yd, app.config["F1"])
    exp = 50 * 24 + (30 * 24 if yd.day % 5 else 30 * 24 - 30 * 4.5)                                         # KB ดับ 06:00–10:30 → ช่วงนั้นว่าง
    assert d["kpi"]["n_data"] == 2 and abs(d["kpi"]["sum"] - exp) < 1e-3, (d["kpi"]["sum"], exp)
    assert d["kpi"]["hour"] is not None and d["heat"]
    assert LV.has_intervals(db).get("elec") == 2


def test_meter_reset_not_counted(app, db, tmp_path):
    now, path, t0, sid, ms = _setup(app, db, tmp_path, days=3)
    yd = (now - timedelta(days=1)).date()
    cut = datetime.combine(yd, time(12, 0))
    con = sqlite3.connect(path)                                        # มิเตอร์ถูกรีเซ็ตเป็น 0 ตอนเที่ยงเมื่อวาน
    con.execute("UPDATE h SET value = value - ? WHERE tag='KA' AND ts >= ?", (value("KA", cut, t0), cut.strftime("%Y-%m-%d %H:%M:%S")))
    con.commit()
    con.close()
    ES.run_source(db, sid, now=now)
    a = datetime.combine(yd, time(0, 0))
    sl = PR.slots(db, [ms["KA"]], a, a + timedelta(days=1))[ms["KA"]]
    assert sl[47] is None or sl[47] >= 0                                       # ช่วง 11:45–12:00 ติดลบ → ไม่นับ
    assert all(v is None or v >= 0 for v in sl) and abs(sum(v for v in sl if v is not None) - (50 * 24 - 12.5)) < 1e-3


def test_meter_page_now_panel_profile_json_csv(app, db, client, tmp_path):
    now, _p, _t0, _sid, ms = _setup(app, db, tmp_path)
    mid = ms["KA"]
    tok = login(client, "t_admin")
    page = client.get(f"/energy/meters/{mid}").get_data(as_text=True)
    assert 'id="now"' in page and "ดึงค่าราย 15 นาทีจาก SQL (8 วัน)" in page                               # ยังไม่มี → ปุ่มดึง
    res = client.post(f"/energy/meters/{mid}/pull", data={"csrf_token": tok, "days": "8"}, follow_redirects=True)
    html = res.get_data(as_text=True)
    assert "ค่าราย 15 นาที 8 วัน" in html and "วันนี้ใช้ไป" in html and "ชั่วโมงนี้" in html and "ชั่วโมงก่อน" in html
    assert 'id="prof"' in html and "รายชั่วโมง" in html and "เทียบสัปดาห์ก่อน" in html
    N = client.get(f"/energy/meters/{mid}/now.json").get_json()
    assert N["has"] and N["unit"] and N["rate_unit"] == "kW" and len(N["hours"]) == 24
    yd = (now - timedelta(days=1)).date()
    P = client.get(f"/energy/meters/{mid}/profile.json?day={yd}").get_json()
    assert P["cmp_day"] == (yd - timedelta(days=1)).isoformat() and abs(P["sum"] - 1200) < 1e-3
    assert len(P["hours"]) == 24 and all(abs(h["v"] - 50) < 1e-6 and abs(h["c"] - 50) < 1e-6 for h in P["hours"])
    assert P["diff_pct"] == 0.0
    W = client.get(f"/energy/meters/{mid}/profile.json?day={now.date()}&cmp=week").get_json()      # วันนี้ เทียบวันเดียวกันสัปดาห์ก่อน
    assert W["cmp_day"] == (now.date() - timedelta(days=7)).isoformat()
    assert all(abs(h["c"] - 50) < 1e-6 for h in W["hours"]) and all(abs(h["v"] - 50) < 1e-6 for h in W["hours"][:now.hour])
    c = client.get(f"/energy/meters/{mid}/profile.json?day={yd}&format=csv")
    body = c.data.decode("utf-8-sig")
    assert c.mimetype == "text/csv" and body.splitlines()[1].startswith("00:00,12.5,12.5") and len(body.splitlines()) == 97
    live = client.get(f"/energy/live/?kind=elec&day={yd}").get_data(as_text=True)
    assert "ยังไม่มีค่ารายช่วงเวลา" not in live and 'id="kHour"' in live


def test_auto_fill_retry_and_csv_source_untouched(app, db, tmp_path):
    now, path, _t0, sid, _ms = _setup(app, db, tmp_path, days=10)
    src = ES.get_source(db, sid)
    n1 = PR.auto_fill(db, src, now)
    assert n1 > 96 * 7
    assert PR.auto_fill(db, src, now) == 0                                     # ครบแล้ว → ไม่ดึงซ้ำ
    assert PR.auto_fill(db, {**src, "kind": "csv"}, now) == 0
    assert PR.store(db, {**src, "value_kind": "interval"}, [("KA", now, 1.0)], now) == 0
    con = sqlite3.connect(path)
    con.execute("DELETE FROM h")
    con.commit()
    con.close()
    db.execute("DELETE FROM en_profile")
    assert PR.auto_fill(db, src, now) == 0                                     # SQL ไม่มีข้อมูล → จำไว้ ไม่ถามซ้ำทุกรอบ
    tried = json.loads(db.execute("SELECT value FROM cs_meta WHERE key=?", (f"en_profile_try:{sid}",)).fetchone()[0])
    assert len(tried) == 8
