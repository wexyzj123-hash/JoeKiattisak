"""v0.85: ปุ่มอนุมัติ / ลงนามในหน้าใบบันทึกประจำเดือน"""
from conftest import login, uid
from test_v73 import _at, _day, _hist, _rows, _setup

from ecs import connectors as CN
from ecs import sheet_actions as SA
from ecs import signoffs as SO


def _sup_slot(db, fid, day):
    from ecs import services as S
    form = dict(S.get_form(db, fid))
    sg = SO.seg_of(db, form, day.replace(day=1), day.day)
    return form, sg, db.execute("SELECT user_id FROM cs_signoffs WHERE form_id=? AND month=? AND slot=?",
                                (fid, SO.month_key(day.replace(day=1)), f"row:sup:{sg['start']}")).fetchone()


def test_certify_scada_fills_srtech_row(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, [(t, x, 2.0) for t, x, _v in _rows(day)])            # ค่าปกติ (ไม่ NG)
    sid = _setup(db, published_form, path)
    db.execute("UPDATE cs_sources SET confirm_required=0 WHERE id=?", (sid,))
    CN.run_source(db, sid, now=_at(day, 23))                    # ค่าจาก SCADA อนุมัติอัตโนมัติ (ไม่มีชื่อผู้อนุมัติ)
    db.commit()
    fid = published_form["form_id"]
    form, sg, rec = _sup_slot(db, fid, day)
    assert rec is None                                          # เดิม: ช่องหัวหน้างานว่างตลอด
    me = {"id": uid(db, "t_sup"), "role": "supervisor"}
    acts = SA.actions(db, form, day.replace(day=1), me)
    st = acts["sup"][sg["start"]]
    assert st["unsigned"] == 2 and st["can"] and acts["n"] >= 1
    assert SA.actions(db, form, day.replace(day=1), {"id": uid(db, "t_tech"), "role": "technician"})["sup"][sg["start"]]["can"] is False
    r = SA.approve_range(db, form, day.replace(day=1), sg["start"], sg["span"], me["id"])
    db.commit()
    assert r["certified"] == 2
    assert _sup_slot(db, fid, day)[2][0] == me["id"]


def test_report_buttons_and_routes(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, [(t, x, 2.0) for t, x, _v in _rows(day)])            # ค่าปกติ (ไม่ NG)
    sid = _setup(db, published_form, path)
    db.execute("UPDATE cs_sources SET confirm_required=1 WHERE id=?", (sid,))   # รอยืนยันทุกรอบ
    db.commit()
    CN.run_source(db, sid, now=_at(day, 23))
    db.commit()
    fid = published_form["form_id"]
    mk = day.strftime("%Y-%m")
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get("/reports/sheets", query_string={"form": fid, "month": mk}).get_data(as_text=True)
    assert "✅ อนุมัติ" in page and "อนุมัติ / ลงนามทั้งหมดที่ฉันทำได้" in page and "รออนุมัติ 2" in page
    pdf_html = c.get("/reports/sheets", query_string={"form": fid, "month": mk, "format": "xlsx"})
    assert pdf_html.status_code == 200
    form, sg, _ = _sup_slot(db, fid, day)
    r = c.post("/reports/sheets/approve", data={"csrf_token": tok, "form": fid, "month": mk, "start": sg["start"], "span": sg["span"],
                                                "next": f"/reports/sheets?form={fid}&month={mk}"})
    assert r.status_code == 302 and "/reports/sheets" in r.headers["Location"]
    assert db.execute("SELECT COUNT(*) FROM cs_submissions WHERE form_id=? AND approval_status='pending'", (fid,)).fetchone()[0] == 0
    assert _sup_slot(db, fid, day)[2][0] == uid(db, "t_sup")
    page = c.get("/reports/sheets", query_string={"form": fid, "month": mk}).get_data(as_text=True)
    assert "รออนุมัติ 2" not in page
    # ช่างไม่มีสิทธิ์อนุมัติ → ไม่เห็นปุ่ม / กดแล้วถูกปฏิเสธ
    c2 = app.test_client()
    tok2 = login(c2, "t_tech")
    assert "✅ อนุมัติ" not in c2.get("/reports/sheets", query_string={"form": fid, "month": mk}).get_data(as_text=True)
    c2.post("/reports/sheets/sign-all", data={"csrf_token": tok2, "form": fid, "month": mk})


def test_sign_all_signs_month_slots(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, [(t, x, 2.0) for t, x, _v in _rows(day)])            # ค่าปกติ (ไม่ NG)
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 23))
    sv = uid(db, "t_sup")
    db.execute("UPDATE users SET position='sv' WHERE id=?", (sv,))
    db.commit()
    fid = published_form["form_id"]
    mk = day.strftime("%Y-%m")
    c = app.test_client()
    tok = login(c, "t_sup")
    page = c.get("/reports/sheets", query_string={"form": fid, "month": mk}).get_data(as_text=True)
    assert "อนุมัติ / ลงนามทั้งหมดที่ฉันทำได้" in page
    r = c.post("/reports/sheets/sign-all", data={"csrf_token": tok, "form": fid, "month": mk})
    assert r.status_code == 302
    assert _sup_slot(db, fid, day)[2][0] == sv
