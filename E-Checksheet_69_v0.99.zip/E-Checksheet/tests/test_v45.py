"""v0.45: ค่าอัตโนมัติให้ Sr.Tech ยืนยัน · ฟอร์มผสม SCADA + หน้างาน · เดาการจับคู่ Tag · นำเข้า/ส่งออก Excel"""
import io
import sqlite3
from datetime import datetime, time, timedelta

from conftest import GOOD, login, payload, uid

from ecs import connectors as CN
from ecs import services as S
from ecs import srcmap as SM
from ecs import submissions as SUB
from ecs import tagmatch as TM
from ecs.services import ts


def _src(db, tmp_path, rows, **kw):
    path = str(tmp_path / "scada.db")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE IF NOT EXISTS h (tag TEXT, ts TEXT, value REAL)")
    con.executemany("INSERT INTO h VALUES (?,?,?)", rows)
    con.commit()
    con.close()
    return CN.save_source(db, {"name": "SCADA", "kind": "sqlite", "bucket_min": 60, "agg": "last",
                               "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                          "backfill_days": 3}, **kw}, None)


def _sched(db, fid):
    S.create_schedule(db, fid, {"freq_type": "shift", "times": "08:30,20:30", "window_min": 240}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (ts(S.now_dt() - timedelta(days=3)),))
    S.generate_rounds(db)


def test_auto_values_need_srtech_confirm(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    day = (S.now_dt() - timedelta(days=1)).date()
    _sched(db, fid)
    rows = [("OIL", ts(datetime.combine(day, time(8, 30))), 2.0), ("OIL", ts(datetime.combine(day, time(20, 30))), 3.1)]
    sid = _src(db, tmp_path, rows)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil"}], None)
    db.commit()
    CN.run_source(db, sid)
    db.commit()
    subs = db.execute("SELECT * FROM cs_submissions WHERE source='auto' ORDER BY finished_at").fetchall()
    assert len(subs) == 2 and all(s["approval_status"] == "pending" for s in subs) and subs[1]["ng_count"] == 1
    assert all(s["round_id"] is None for s in subs)                 # ฟอร์มผสม: ไม่ปิดรอบแทนช่าง
    db.execute("UPDATE users SET position='srtech' WHERE username='t_tech'")
    db.commit()
    c = app.test_client()
    tok = login(c, "t_tech")
    html = c.get("/approvals").get_data(as_text=True)
    assert "ค่าอัตโนมัติจาก SCADA รอยืนยัน 2 รายการ" in html and "📡 SCADA" in html and "ยืนยันค่าปกติทั้งหมด (1)" in html
    assert c.get("/approvals?src=auto").status_code == 200
    c.post("/approvals/auto", data={"csrf_token": tok})
    st = [r[0] for r in db.execute("SELECT approval_status FROM cs_submissions WHERE source='auto' ORDER BY finished_at")]
    assert st == ["approved", "pending"]                              # ค่า NG ต้องเปิดดูทีละรายการ
    assert db.execute("SELECT approval_note FROM cs_submissions WHERE source='auto' ORDER BY finished_at").fetchone()[0] \
        == "ยืนยันค่าอัตโนมัติจาก SCADA"


def test_confirm_off_and_full_auto_form_links_round(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    day = (S.now_dt() - timedelta(days=1)).date()
    _sched(db, fid)
    sid = _src(db, tmp_path, [("OIL", ts(datetime.combine(day, time(8, 30))), 2.0)], confirm_required="0", prefill="0")
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil"}], None)
    db.commit()
    CN.run_source(db, sid)
    s = db.execute("SELECT * FROM cs_submissions WHERE source='auto'").fetchone()
    assert s["approval_status"] == "approved" and s["round_id"]


def test_mixed_form_prefill_and_src(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    now = S.now_dt()
    sid = _src(db, tmp_path, [("OIL", ts(now - timedelta(minutes=20)), 2.2)])
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil", "scale": 1}], None)
    db.commit()
    CN.run_source(db, sid)
    db.commit()
    pre = SM.prefill_values(db, fid)
    assert pre["oil"]["value"] == 2.2 and pre["oil"]["tag"] == "OIL"
    c = app.test_client()
    login(c, "t_tech")
    pkg = c.get(f"/api/m/forms/{fid}/package").get_json()
    assert pkg["scada"]["oil"]["value"] == 2.2
    js = c.get("/static/m/fill.js").get_data(as_text=True)
    assert "applyScada" in js and "ค่าจาก SCADA" in js and "src: a.src" in js
    p = payload(published_form, dict(GOOD, oil={"value": "2.2", "src": "scada"}))
    SUB.create_submission(db, p, {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()
    sub = db.execute("SELECT MAX(id) FROM cs_submissions WHERE source<>'auto' OR source IS NULL").fetchone()[0]
    src = dict(db.execute("SELECT item_key, value_src FROM cs_answers WHERE submission_id=?", (sub,)).fetchall())
    assert src["oil"] == "scada" and src["noise"] == ""
    login(c, "t_admin")
    assert "📡 SCADA" in c.get(f"/submissions/{sub}").get_data(as_text=True)
    db.execute("UPDATE cs_sources SET prefill=0")
    db.commit()
    assert SM.prefill_values(db, fid) == {}


def test_human_round_not_duplicated_by_auto(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    day = (S.now_dt() - timedelta(days=1)).date()
    _sched(db, fid)
    rid = db.execute("SELECT id FROM cs_rounds WHERE form_id=? AND due_at=?", (fid, ts(datetime.combine(day, time(8, 30))))).fetchone()[0]
    SUB.create_submission(db, payload(published_form, GOOD, round_id=rid), {}, uid(db, "t_admin"), app.config["UPLOAD_FOLDER"])
    sid = _src(db, tmp_path, [("OIL", ts(datetime.combine(day, time(8, 30))), 2.0),
                              ("OIL", ts(datetime.combine(day, time(20, 30))), 2.1)])
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil"}], None)
    db.commit()
    CN.run_source(db, sid)
    auto = [r[0][11:16] for r in db.execute("SELECT finished_at FROM cs_submissions WHERE source='auto' ORDER BY finished_at")]
    assert auto == ["20:30"]                                         # รอบ 08:30 ช่างกรอก Oil แล้ว → ไม่ลงซ้ำ


def test_tag_suggestions(app, db, published_form, tmp_path):
    fid = published_form["form_id"]
    now = S.now_dt()
    sid = _src(db, tmp_path, [("SCT0002_OIL_PRESS", ts(now), 2.1), ("SCT0002.RUN_HR", ts(now), 1500),
                              ("XYZ_RANDOM", ts(now), 5)])
    CN.run_source(db, sid)
    db.commit()
    sug = TM.suggest(db, sid)
    assert sug["SCT0002_OIL_PRESS"]["target"] == f"{fid}:oil" and sug["SCT0002_OIL_PRESS"]["score"] >= 70
    assert sug["SCT0002.RUN_HR"]["target"] == f"{fid}:hour"
    assert "XYZ_RANDOM" not in sug or sug["XYZ_RANDOM"]["score"] < 60
    c = app.test_client()
    login(c, "t_admin")
    html = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert "💡" in html and "ใช้คำแนะนำที่มั่นใจ" in html and "ส่งออก Excel" in html


def test_excel_export_import(app, db, published_form, tmp_path):
    from openpyxl import load_workbook
    fid = published_form["form_id"]
    code = S.get_form(db, fid)["code"]
    now = S.now_dt()
    sid = _src(db, tmp_path, [("SCT0002_OIL_PRESS", ts(now), 2.1), ("T2", ts(now), 1), ("T3", ts(now), 1)])
    CN.run_source(db, sid)
    db.commit()
    c = app.test_client()
    tok = login(c, "t_admin")
    r = c.get(f"/admin/sources/{sid}/mapping.xlsx")
    assert r.status_code == 200
    wb = load_workbook(io.BytesIO(r.data))
    ws = wb["จับคู่ Tag"]
    assert [x.value for x in ws[1]][:3] == ["Tag", "ค่าล่าสุด", "เวลาล่าสุด"] and "หัวข้อที่เลือกได้" in wb.sheetnames
    rows = {ws.cell(row=i, column=1).value: i for i in range(2, ws.max_row + 1)}
    assert "oil" in str(ws.cell(row=rows["SCT0002_OIL_PRESS"], column=13).value)      # คำแนะนำ (v0.77 เพิ่มคอลัมน์ช่วงค่า)
    ws.cell(row=rows["SCT0002_OIL_PRESS"], column=4, value=code)
    ws.cell(row=rows["SCT0002_OIL_PRESS"], column=6, value="oil")
    ws.cell(row=rows["SCT0002_OIL_PRESS"], column=9, value=0.1)
    ws.cell(row=rows["T2"], column=5, value="SCT0002")
    ws.cell(row=rows["T2"], column=7, value="Running hour")                           # ใช้ชื่อหัวข้อแทนรหัส
    ws.cell(row=rows["T3"], column=4, value=code)
    ws.cell(row=rows["T3"], column=6, value="noise")                                   # ไม่ใช่ตัวเลข → ผิด
    buf = io.BytesIO()
    wb.save(buf)
    r = c.post(f"/admin/sources/{sid}/mapping-import",
               data={"csrf_token": tok, "file": (io.BytesIO(buf.getvalue()), "map.xlsx")}, content_type="multipart/form-data")
    assert r.status_code == 302
    m = {t["tag"]: t for t in CN.list_tags(db, sid)}
    assert m["SCT0002_OIL_PRESS"]["item_key"] == "oil" and m["SCT0002_OIL_PRESS"]["scale"] == 0.1
    assert m["T2"]["item_key"] == "hour" and not m["T3"]["form_id"]
    page = c.get(f"/admin/sources/{sid}").get_data(as_text=True)
    assert "แถว" in page and "noise" in page
