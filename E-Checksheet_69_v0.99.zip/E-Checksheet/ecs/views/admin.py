"""ecs/views/admin.py — ข้อมูลหลัก: เครื่องจักร (+ QR), โรงงาน/พื้นที่, ผู้ใช้"""
from __future__ import annotations

import io
import os
import re

from flask import (Blueprint, Response, abort, current_app, flash, jsonify, redirect, render_template, request,
                   send_from_directory, url_for)

from .. import downtime as DT
from .. import masterdata as M
from ..db import get_db
from ..security import ALL_ROLES, MANAGE_ROLES, current_user_id, require_role, safe_next
from ..services import ValidationError, list_forms

bp = Blueprint("admin", __name__)


def _flash_errors(exc: ValidationError):
    for e in exc.errors:
        flash(e, "error")


def _int(v):
    try:
        return int(v or 0) or None
    except ValueError:
        return None


def server_ips() -> list[str]:
    """IPv4 ทั้งหมดของเครื่องแม่ข่าย (โรงงานมีหลายวง LAN → ป้าย QR เลือกได้ว่าจะชี้ IP ไหน)"""
    import socket
    ips = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and ip not in ips:
                ips.append(ip)
    except OSError:
        pass
    return ips


def qr_bases() -> list[str]:
    """ที่อยู่ที่ใช้ทำ QR ได้: ที่อยู่ที่กำลังเปิดอยู่ + ทุก IP ของเครื่อง (+ QR_BASE_URL ถ้าตั้งไว้)"""
    root = request.script_root or ""
    host = request.host                       # เช่น 192.168.133.129:5000 — IP/ชื่อที่ผู้ใช้เปิดเข้ามาจริง
    port = host.rsplit(":", 1)[1] if ":" in host and not host.endswith("]") else ""
    scheme = request.scheme
    out = [f"{scheme}://{host}{root}"]
    for ip in server_ips():
        b = f"{scheme}://{ip}{':' + port if port else ''}{root}"
        if b not in out:
            out.append(b)
    fixed = (current_app.config.get("QR_BASE_URL") or "").rstrip("/")
    if fixed and fixed not in out:
        out.insert(0, fixed)
    return out


def qr_base() -> str:
    """ค่าเริ่มต้น = ที่อยู่ที่ผู้ใช้กำลังเปิดอยู่ (ไม่ล็อค IP) · เลือก IP อื่นได้ด้วย ?base= · QR_BASE_URL ใน .env บังคับค่าคงที่"""
    bases = qr_bases()
    want = (request.args.get("base") or "").rstrip("/")
    if want in bases:
        return want
    fixed = (current_app.config.get("QR_BASE_URL") or "").rstrip("/")
    return fixed or bases[0]


def qr_url(token: str, base: str | None = None) -> str:
    return f"{base or qr_base()}/e/{token}"


def qr_svg(data: str, box: int = 6) -> str | None:
    """คืน SVG ของ QR (ต้องติดตั้ง qrcode) — ถ้าไม่มีไลบรารีคืน None"""
    try:
        import qrcode
        import qrcode.image.svg
    except ImportError:
        return None
    img = qrcode.make(data, image_factory=qrcode.image.svg.SvgPathImage, box_size=box, border=2)
    buf = io.BytesIO()
    img.save(buf)
    svg = buf.getvalue().decode("utf-8")
    return svg[svg.index("<svg"):]


# ───────────────────────── equipment ─────────────────────────

@bp.route("/equipment")
@require_role(*ALL_ROLES)
def equipment():
    db = get_db()
    factory_id, area_id = _int(request.args.get("factory")), _int(request.args.get("area"))
    q = request.args.get("q", "").strip()
    inactive = request.args.get("inactive") == "1"
    has_forms = request.args.get("forms", "")            # "" | yes | no
    eq_type = request.args.get("type", "")
    items = M.list_equipment(db, factory_id, area_id, q, inactive)
    types = sorted({(i["eq_type"] or "").strip() for i in items if (i["eq_type"] or "").strip()}, key=str.lower)
    counts = {"all": len(items), "yes": sum(1 for i in items if i["form_count"]),
              "no": sum(1 for i in items if not i["form_count"]),
              "down": sum(1 for i in items if i.get("run_status") == "down")}
    if has_forms == "down":
        items = [i for i in items if i.get("run_status") == "down"]
    if has_forms == "yes":
        items = [i for i in items if i["form_count"]]
    elif has_forms == "no":
        items = [i for i in items if not i["form_count"]]
    if eq_type:
        items = [i for i in items if (i["eq_type"] or "").strip().lower() == eq_type.lower()]
    return render_template("admin/equipment.html", items=items, types=types, counts=counts,
                           factories=M.list_factories(db), areas=M.list_areas(db), has_forms=has_forms,
                           eq_type=eq_type, factory_id=factory_id, area_id=area_id, q=q, inactive=inactive)


@bp.route("/api/equipment/delete-check")
@require_role("admin")
def api_equipment_delete_check():
    from ..services import equipment_delete_impact
    ids = [int(x) for part in request.args.getlist("ids") for x in part.split(",") if x.strip().isdigit()]
    return jsonify({"items": equipment_delete_impact(get_db(), ids)})


@bp.route("/equipment/delete", methods=["POST"])
@require_role("admin")
def equipment_delete():
    """ลบเครื่องจักร (หลายเครื่องได้) — forms=keep เก็บแบบฟอร์มไว้ / forms=delete ลบแบบฟอร์มและผลตรวจด้วย"""
    from ..services import delete_equipment, remove_upload_files
    db = get_db()
    ids = [int(x) for x in request.form.getlist("ids") if str(x).isdigit()]
    mode = request.form.get("forms", "keep")
    if not ids:
        flash("ยังไม่ได้เลือกเครื่องจักร", "error")
        return redirect(url_for("admin.equipment"))
    files, codes, kept, dropped = [], [], 0, 0
    try:
        for eid in ids:
            res = delete_equipment(db, eid, current_user_id(), delete_forms=(mode == "delete"))
            files += res["files"]
            codes.append(res["code"])
            kept += res["forms_kept"]
            dropped += res["forms_deleted"]
        db.commit()
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
        return redirect(url_for("admin.equipment"))
    remove_upload_files(current_app.config["UPLOAD_FOLDER"], files)
    msg = f"ลบเครื่องจักร {len(codes)} เครื่อง: " + ", ".join(codes[:12]) + (" …" if len(codes) > 12 else "")
    if kept:
        msg += f" · เก็บแบบฟอร์ม {kept} ฉบับไว้เป็นแบบฟอร์มไม่ผูกเครื่อง"
    if dropped:
        msg += f" · ลบแบบฟอร์ม {dropped} ฉบับ"
    flash(msg, "ok")
    return redirect(safe_next(request.form.get("back"), url_for("admin.equipment")))


@bp.route("/equipment/new", methods=["GET", "POST"])
@bp.route("/equipment/<int:equipment_id>/edit", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def equipment_edit(equipment_id=None):
    db = get_db()
    item = M.get_equipment(db, equipment_id) if equipment_id else None
    if equipment_id and not item:
        abort(404)
    if request.method == "POST":
        data = request.form.to_dict()
        data["notify_channels"] = request.form.getlist("notify_channels")
        data["active"] = 1 if request.form.get("active") else 0
        try:
            eid = M.save_equipment(db, data, current_user_id(), equipment_id)
            db.commit()
            flash("บันทึกเครื่องจักรแล้ว", "ok")
            return redirect(url_for("admin.equipment_detail", equipment_id=eid))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
            item = {**(item or {}), **data}
    return render_template("admin/equipment_edit.html", item=item, factories=M.list_factories(db),
                           areas=M.list_areas(db))


@bp.route("/equipment/<int:equipment_id>")
@require_role(*ALL_ROLES)
def equipment_detail(equipment_id):
    db = get_db()
    item = M.get_equipment(db, equipment_id)
    if not item:
        abort(404)
    from ..submissions import list_submissions
    subs, total = list_submissions(db, equipment_id=equipment_id, limit=20)
    from ..analytics import equipment_summary
    base = qr_base()
    url = qr_url(item["qr_token"], base)
    from .. import points as PT
    scan_forms = [{"form": f, "n": len(PT.label_list(db, [f], base))} for f in PT.scan_forms(db, [equipment_id])]
    return render_template("admin/equipment_detail.html", item=item, scan_forms=scan_forms,
                           n_points=sum(x["n"] for x in scan_forms), forms=list_forms(db, equipment_id=equipment_id,
                           include_inactive=True), subs=subs, sub_total=total, qr_link=url, qr=qr_svg(url),
                           qr_bases=qr_bases(), qr_base_now=base,
                           summary=equipment_summary(db, equipment_id), downtime=DT.history(db, equipment_id, 20),
                           DT_CATS=DT.CATEGORIES)


@bp.route("/equipment/<int:equipment_id>/regenerate-qr", methods=["POST"])
@require_role("admin")
def equipment_regenerate_qr(equipment_id):
    db = get_db()
    if not M.get_equipment(db, equipment_id):
        abort(404)
    M.regenerate_qr(db, equipment_id, current_user_id())
    db.commit()
    flash("สร้าง QR ใหม่แล้ว — ป้าย QR เดิมจะใช้ไม่ได้ ต้องพิมพ์ติดใหม่", "ok")
    return redirect(url_for("admin.equipment_detail", equipment_id=equipment_id))


@bp.route("/equipment/import", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def equipment_import():
    db = get_db()
    result = None
    if request.method == "POST":
        f = request.files.get("file")
        text = request.form.get("text", "")
        if f and f.filename:
            raw = f.read(2 * 1024 * 1024)
            for enc in ("utf-8-sig", "cp874", "tis-620"):
                try:
                    text = raw.decode(enc)
                    break
                except UnicodeDecodeError:
                    continue
        try:
            result = M.import_equipment_csv(db, text, current_user_id())
            from ..services import sync_forms_to_equipment
            sync_forms_to_equipment(db)
            db.commit()
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
    return render_template("admin/equipment_import.html", result=result, headers=M.EQUIPMENT_CSV_HEADERS)


@bp.route("/equipment/template.csv")
@require_role(*MANAGE_ROLES)
def equipment_template():
    body = "﻿" + ",".join(M.EQUIPMENT_CSV_HEADERS) + "\n" + \
        "SCT0002,Air Compressor SCT0002,Air Compressor,F1,Compressor Room,อาคาร 1\n"
    return Response(body, mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=equipment_template.csv"})


@bp.route("/equipment/qr-labels")
@require_role(*MANAGE_ROLES)
def qr_labels():
    """หน้าพิมพ์ป้าย QR (A4) รวมที่เดียว แยก 2 หมวด: ก. ป้ายเครื่องจักร · ข. ป้ายจุดตรวจ (แบบฟอร์มที่ต้องสแกนก่อนตรวจ)
    เลือกตามโรงงาน/พื้นที่ หรือระบุ id · kind=all|machine|points · form=<id> จำกัดป้ายจุดตรวจเฉพาะแบบฟอร์ม"""
    from .. import points as PT
    db = get_db()
    ids = [int(x) for x in request.args.getlist("id") if x.isdigit()]
    form_ids = [int(x) for x in request.args.getlist("form") if x.isdigit()]
    kind = request.args.get("kind", "all")
    if kind not in ("all", "machine", "points"):
        kind = "all"
    items = M.list_equipment(db, _int(request.args.get("factory")), _int(request.args.get("area")))
    if ids:
        items = [i for i in items if i["id"] in ids]
    base = qr_base()
    labels = [{**i, "url": qr_url(i["qr_token"], base), "svg": qr_svg(qr_url(i["qr_token"], base), box=5)} for i in items]
    eq_by_id = {i["id"]: i for i in items}
    points = []
    for lb in PT.label_list(db, PT.scan_forms(db, list(eq_by_id), form_ids), base):
        lb["svg"] = qr_svg(lb["url"], box=5)
        lb["eq"] = eq_by_id.get(lb["form"]["equipment_id"])
        points.append(lb)
    # จัดกลุ่มป้ายจุดตรวจตามเครื่อง › แบบฟอร์ม (หาง่ายตอนติดป้าย)
    groups: list[dict] = []
    for lb in points:
        if not groups or groups[-1]["form"]["id"] != lb["form"]["id"]:
            groups.append({"form": lb["form"], "eq": lb["eq"], "labels": []})
        groups[-1]["labels"].append(lb)
    any_svg = next((x["svg"] for x in labels + points), "")
    return render_template("admin/qr_labels.html", labels=labels, point_groups=groups, n_points=len(points), kind=kind,
                           missing_lib=any_svg is None, qr_bases=qr_bases(), qr_base_now=base)


# ───────────────────────── factories & areas ─────────────────────────

@bp.route("/admin/locations", methods=["GET", "POST"])
@require_role("admin")
def locations():
    db = get_db()
    if request.method == "POST":
        kind = request.form.get("kind")
        data = request.form.to_dict()
        data["active"] = 1 if request.form.get("active", "1") == "1" else 0
        try:
            if kind == "factory":
                M.save_factory(db, data, current_user_id(), _int(request.form.get("id")))
            else:
                M.save_area(db, data, current_user_id(), _int(request.form.get("id")))
            db.commit()
            flash("บันทึกแล้ว", "ok")
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
        return redirect(url_for("admin.locations"))
    return render_template("admin/locations.html", factories=M.list_factories(db, include_inactive=True),
                           areas=M.list_areas(db, include_inactive=True))


# ───────────────────────── ผังโรงงาน ─────────────────────────

@bp.route("/admin/layout")
@require_role("admin")
def layout():
    db = get_db()
    factories = M.list_factories(db)
    if not factories:
        return redirect(url_for("admin.locations"))
    fid = _int(request.args.get("factory")) or factories[0]["id"]
    factory = next((f for f in factories if f["id"] == fid), factories[0])
    from ..analytics import area_status
    from datetime import date
    areas = area_status(db, date.today(), factory["id"])
    return render_template("admin/layout.html", factories=factories, factory=factory, areas=areas)


@bp.route("/admin/layout/<int:factory_id>", methods=["POST"])
@require_role("admin")
def layout_upload(factory_id):
    db = get_db()
    try:
        if request.form.get("action") == "remove":
            M.set_factory_layout(db, factory_id, None, current_app.config["UPLOAD_FOLDER"], current_user_id())
            flash("ลบผังแล้ว — Dashboard จะแสดงเป็นผังแบบกล่องแทน", "ok")
        else:
            f = request.files.get("layout")
            M.set_factory_layout(db, factory_id, f.read(M.MAX_LAYOUT_BYTES + 1) if f else b"",
                                 current_app.config["UPLOAD_FOLDER"], current_user_id())
            flash("อัปโหลดผังแล้ว — เลือกพื้นที่ทางขวา แล้วคลิกบนผังเพื่อวางหมุด", "ok")
        db.commit()
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("admin.layout", factory=factory_id))


@bp.route("/admin/areas/<int:area_id>", methods=["GET", "POST"])
@require_role(*MANAGE_ROLES)
def area_detail(area_id):
    """จัดการพื้นที่: เลือกเครื่องจักร / แบบฟอร์มที่มีอยู่แล้วเข้าพื้นที่ → แสดงบนผังพื้นที่และสถานะทันที"""
    from ..services import get_form, set_equipment_location, sync_forms_to_equipment
    db = get_db()
    area = db.execute("""SELECT a.*, f.name AS factory_name FROM areas a JOIN factories f ON f.id=a.factory_id
                         WHERE a.id=?""", (area_id,)).fetchone()
    if not area:
        abort(404)
    area = dict(area)
    if request.method == "POST":
        act = request.form.get("action", "")
        ids = [int(x) for x in request.form.getlist("ids") if str(x).isdigit()]
        n = 0
        if act == "add_eq":
            for eid in ids:
                if db.execute("SELECT 1 FROM equipment WHERE id=?", (eid,)).fetchone():
                    set_equipment_location(db, eid, area["factory_id"], area_id, current_user_id())
                    n += 1
            flash(f"เพิ่มเครื่องจักร {n} เครื่องเข้าพื้นที่ {area['name']} แล้ว (แบบฟอร์มของเครื่องย้ายตามให้อัตโนมัติ)", "ok")
        elif act == "remove_eq":
            for eid in ids:
                row = db.execute("SELECT factory_id FROM equipment WHERE id=? AND area_id=?", (eid, area_id)).fetchone()
                if row:
                    set_equipment_location(db, eid, row["factory_id"], None, current_user_id())
                    n += 1
            flash(f"นำเครื่องจักรออกจากพื้นที่ {n} เครื่อง", "ok")
        elif act in ("add_form", "remove_form"):
            for fid in ids:
                form = get_form(db, fid)
                if not form or form["equipment_id"]:
                    continue                       # แบบฟอร์มที่ผูกเครื่อง ย้ายผ่านเครื่องจักรเท่านั้น
                new_area = area_id if act == "add_form" else None
                db.execute("UPDATE cs_forms SET factory_id=?, area_id=?, updated_at=? WHERE id=?",
                           (area["factory_id"] if act == "add_form" else form["factory_id"], new_area, _now(), fid))
                n += 1
            flash(("เพิ่ม" if act == "add_form" else "นำออก") + f"แบบฟอร์ม {n} รายการ", "ok")
        sync_forms_to_equipment(db)
        db.commit()
        return redirect(url_for("admin.area_detail", area_id=area_id))
    in_eq = M.list_equipment(db, area_id=area_id)
    candidates = [e for e in M.list_equipment(db) if e["area_id"] != area_id
                  and (e["factory_id"] in (None, area["factory_id"]))]
    others = [e for e in M.list_equipment(db) if e["factory_id"] not in (None, area["factory_id"])]
    loose_in = [dict(r) for r in db.execute("""SELECT id, code, name FROM cs_forms
                    WHERE area_id=? AND equipment_id IS NULL ORDER BY code""", (area_id,))]
    loose_out = [dict(r) for r in db.execute("""SELECT f.id, f.code, f.name, a.name AS area_name FROM cs_forms f
                    LEFT JOIN areas a ON a.id=f.area_id WHERE f.equipment_id IS NULL AND IFNULL(f.area_id, 0)<>?
                    AND (f.factory_id IS NULL OR f.factory_id=?) ORDER BY f.code""", (area_id, area["factory_id"]))]
    forms_by_eq = {}
    for r in db.execute("SELECT id, code, name, equipment_id FROM cs_forms WHERE equipment_id IS NOT NULL ORDER BY code"):
        forms_by_eq.setdefault(r["equipment_id"], []).append(dict(r))
    from ..analytics import area_status
    from datetime import date
    st = next((a for a in area_status(db, date.today(), area["factory_id"]) if a["id"] == area_id), None)
    return render_template("admin/area_detail.html", area=area, in_eq=in_eq, candidates=candidates, others=others,
                           loose_in=loose_in, loose_out=loose_out, forms_by_eq=forms_by_eq, st=st,
                           areas=M.list_areas(db, area["factory_id"]))


def _now():
    from ..services import ts
    return ts()


@bp.route("/api/areas/<int:area_id>/pin", methods=["POST"])
@require_role("admin")
def area_pin(area_id):
    db = get_db()
    data = request.get_json(silent=True) or {}
    try:
        if data.get("clear"):
            M.set_area_pin(db, area_id, None, None, current_user_id())
        else:
            M.set_area_pin(db, area_id, data.get("x"), data.get("y"), current_user_id())
        db.commit()
    except ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0]}), 400
    return jsonify({"ok": True})


# ───────────────────────── users ─────────────────────────

@bp.route("/admin/users")
@require_role("admin")
def users():
    db = get_db()
    return render_template("admin/users.html", users=M.list_users(db), factories=M.list_factories(db))


@bp.route("/admin/users/new", methods=["GET", "POST"])
@bp.route("/admin/users/<int:user_id>", methods=["GET", "POST"])
@require_role("admin")
def user_edit(user_id=None):
    db = get_db()
    user = M.get_user(db, user_id) if user_id else None
    if user_id and not user:
        abort(404)
    if request.method == "POST":
        data = request.form.to_dict()
        data["active"] = 1 if request.form.get("active") else 0
        data["can_delete_results"] = 1 if request.form.get("can_delete_results") else 0
        data["can_approve"] = 1 if request.form.get("can_approve") else 0
        data["restrict_view"] = 1 if request.form.get("restrict_view") else 0
        try:
            M.save_user(db, data, current_user_id(), user_id)
            db.commit()
            flash("บันทึกผู้ใช้แล้ว" + (" — ผู้ใช้ต้องเปลี่ยนรหัสผ่านเมื่อเข้าระบบครั้งแรก" if not user_id else ""), "ok")
            return redirect(url_for("admin.users"))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
            user = {**(user or {}), **data}
    return render_template("admin/user_edit.html", user=user, factories=M.list_factories(db))


# ───────────────────────── เวลากะ / วันทำงาน (ใช้กับความถี่รายหัวข้อ) ─────────────────────────

@bp.route("/admin/work-calendar", methods=["GET", "POST"])
@require_role("admin")
def work_calendar():
    from ..itemfreq import FREQS, UNIT_TH, FreqError, all_freqs, custom_freqs, get_calendar, save_calendar, save_custom_freqs
    db = get_db()
    if request.method == "POST" and request.form.get("action") == "freqs":        # v0.32 ความถี่ที่ผู้ดูแลระบบเพิ่มเอง
        rows = [{"label": lb, "n": n, "unit": u} for lb, n, u in zip(request.form.getlist("f_label"), request.form.getlist("f_n"),
                                                                     request.form.getlist("f_unit"))]
        try:
            out = save_custom_freqs(db, rows)
            __import__("ecs.services", fromlist=["audit"]).audit(db, current_user_id(), "update", "cs_meta", None, after={"custom_freqs": out})
            db.commit()
            flash(f"บันทึกความถี่แล้ว ({len(out)} แบบ) — เลือกได้ใน Builder ทันที", "ok")
        except FreqError as exc:
            db.rollback()
            flash(str(exc), "error")
        return redirect(url_for("admin.work_calendar") + "#freqs")
    if request.method == "POST":
        try:
            save_calendar(db, {"shift_times": request.form.get("shift_times"), "day_start": request.form.get("day_start")})
            db.commit()
            flash("บันทึกเวลากะแล้ว — มีผลกับหัวข้อ 'กะละ 1 ครั้ง' / 'วันละ 1 ครั้ง' ทันที", "ok")
            return redirect(url_for("admin.work_calendar"))
        except FreqError as exc:
            flash(str(exc), "error")
    used = db.execute("""SELECT i.check_freq, COUNT(*) n FROM cs_form_items i JOIN cs_forms f ON f.current_version_id=i.version_id
                         WHERE COALESCE(i.check_freq,'')<>'' GROUP BY i.check_freq""").fetchall()
    return render_template("admin/work_calendar.html", cal=get_calendar(db), used={r[0]: r[1] for r in used},
                           freqs=all_freqs(db), builtin=FREQS, custom=custom_freqs(db), units=UNIT_TH)


# ───────────────────────── ใบแจ้งซ่อม UT-CMMS จาก NG ─────────────────────────

@bp.route("/admin/cmms-wo", methods=["GET", "POST"])
@require_role("admin")
def cmms_wo_settings():
    from flask import current_app

    from .. import cmms_wo as W
    db = get_db()
    if request.method == "POST":
        try:
            W.save_settings(db, request.form.to_dict(), current_user_id())
            db.commit()
            flash("บันทึกการเชื่อมใบแจ้งซ่อม UT-CMMS แล้ว", "ok")
            return redirect(url_for("admin.cmms_wo_settings"))
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
    if request.args.get("sync") == "1":
        from ..jobs import sync_cmms
        res = sync_cmms(current_app) or {}
        flash(f"ดึงสถานะจาก UT-CMMS แล้ว: ตรวจ {res.get('checked', 0)} · เปลี่ยน {res.get('changed', 0)} · ปิดงาน {res.get('closed', 0)}", "ok")
        return redirect(url_for("admin.cmms_wo_settings"))
    return render_template("admin/cmms_wo.html", cfg=W.get_settings(db), info=W.status_info(db, current_app.config),
                           links=W.recent_links(db), MODE_TH=W.MODE_TH)


# ───────────────────────── แผน TPM ของ UT-CMMS ─────────────────────────

@bp.route("/admin/cmms-tpm", methods=["GET", "POST"])
@require_role("admin")
def cmms_tpm_settings():
    from flask import current_app

    from .. import cmms_tpm as TPM
    db = get_db()
    if request.method == "POST":
        try:
            if request.form.get("action") == "auto_link":
                res = TPM.auto_link(db, current_app.config, current_user_id())
                db.commit()
                flash(f"เชื่อมอัตโนมัติแล้ว {res['links']} แผน ใน {res['forms']} แบบฟอร์ม — ตรวจทานได้ที่แบบฟอร์ม › แท็บแผน TPM", "ok")
            else:
                TPM.save_settings(db, request.form.to_dict(), current_user_id())
                db.commit()
                flash("บันทึกการเชื่อมแผน TPM แล้ว", "ok")
        except ValidationError as exc:
            db.rollback()
            _flash_errors(exc)
        return redirect(url_for("admin.cmms_tpm_settings"))
    if request.args.get("sync") == "1":
        n = TPM.safe(TPM.refresh_states, db, current_app.config)
        flash(f"ดึงสถานะยืนยันจาก UT-CMMS แล้ว — อัปเดต {n} รายการ", "ok")
        return redirect(url_for("admin.cmms_tpm_settings"))
    available = TPM.available(current_app.config)
    ov, err = {"forms": [], "n_links": 0, "n_suggest": 0}, ""
    try:
        ov = TPM.overview(db, current_app.config)
    except Exception as exc:                            # noqa: BLE001
        err = str(exc)
    return render_template("admin/cmms_tpm.html", cfg=TPM.get_settings(db), available=available, ov=ov, err=err,
                           syncs=TPM.recent_syncs(db))


# ───────────────────────── สถานะช่าง UT-CMMS ─────────────────────────

@bp.route("/admin/cmms-status", methods=["GET", "POST"])
@require_role("admin")
def cmms_status_settings():
    from flask import current_app

    from .. import cmms_status as ST
    db = get_db()
    if request.method == "POST":
        ST.save_settings(db, request.form.to_dict(), current_user_id())
        db.commit()
        flash("บันทึกการเชื่อมสถานะช่างแล้ว", "ok")
        return redirect(url_for("admin.cmms_status_settings"))
    return render_template("admin/cmms_status.html", cfg=ST.get_settings(db), available=ST.available(current_app.config),
                           rows=ST.recent(db), STATE_TH=ST.STATE_TH, AFTER_TH=ST.AFTER_TH,
                           unlinked=ST.unlinked_inspectors(db))


# ───────────────────────── เครื่องหยุด / ซ่อม ─────────────────────────

@bp.route("/equipment/<int:equipment_id>/down", methods=["POST"])
@require_role(*MANAGE_ROLES)
def equipment_down(equipment_id):
    db = get_db()
    f = request.form
    try:
        if f.get("start_at") or f.get("end_at"):             # v0.58 กรอกวันหยุดเครื่องย้อนหลัง
            res = DT.record_down(db, equipment_id, current_user_id(), f.get("reason", ""), f.get("category", "repair"),
                                 f.get("start_at"), f.get("end_at") or None, f.get("note", ""))
        else:
            res = DT.set_down(db, equipment_id, current_user_id(), f.get("reason", ""), f.get("category", "repair"),
                              f.get("expected_end") or None)
        db.commit()
        flash(f"{'บันทึกช่วงหยุดย้อนหลังของ' if f.get('start_at') else 'แจ้ง'} {res['code']} หยุด/ซ่อมแล้ว — งดรอบตรวจ {res['skipped']} รอบ (ไม่นับขาดตรวจ)"
              + (f" · ทับแทนช่วงเดิม {res['replaced']} ช่วง" if res.get("replaced") else ""), "ok")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    return redirect(safe_next(request.form.get("back"), url_for("admin.equipment_detail", equipment_id=equipment_id)))


@bp.route("/equipment/<int:equipment_id>/running", methods=["POST"])
@require_role(*MANAGE_ROLES)
def equipment_running(equipment_id):
    db = get_db()
    try:
        res = DT.set_running_at(db, equipment_id, current_user_id(), request.form.get("at") or None, request.form.get("note", ""))
        db.commit()
        flash(f"{res['code']} กลับมาใช้งานแล้ว" + (f" ตั้งแต่ {res['at'][8:10]}/{res['at'][5:7]} {res['at'][11:16]}" if res.get("at") else "")
              + f" — เปิดรอบตรวจคืน {res['restored']} รอบ", "ok")
    except ValidationError as exc:
        db.rollback()
        for e in exc.errors:
            flash(e, "error")
    return redirect(safe_next(request.form.get("back"), url_for("admin.equipment_detail", equipment_id=equipment_id)))


@bp.route("/equipment/down")
@require_role(*ALL_ROLES)
def equipment_down_list():
    db = get_db()
    return render_template("admin/downtime.html", items=DT.down_list(db, _int(request.args.get("factory"))),
                           history=DT.history(db, None, 100), factories=M.list_factories(db),
                           factory_id=_int(request.args.get("factory")), DT_CATS=DT.CATEGORIES,
                           equipment=M.list_equipment(db), stale_n=len(DT.stale_downtimes(db)))


@bp.route("/equipment/down/fix", methods=["GET", "POST"])
@require_role("admin", "supervisor")
def equipment_down_fix():
    """v0.57 แก้ข้อมูลเก่า: มีผลตรวจระหว่างที่ระบบค้างสถานะหยุด → เดินเครื่องตั้งแต่เริ่มกะของผู้ตรวจ"""
    db = get_db()
    if request.method == "POST":
        ids = [int(x) for x in request.form.getlist("id") if x.isdigit()]
        if not ids:
            flash("เลือกรายการที่จะแก้อย่างน้อย 1 รายการ", "error")
        else:
            res = DT.fix_stale_downtimes(db, current_user_id(), ids)
            db.commit()
            flash(f"แก้ข้อมูลแล้ว {res['fixed']} ช่วงหยุด · คืนสถานะรอบ {res['rounds']} รอบ · ผูกผลตรวจนอกรอบเข้ารอบ {res['linked']} ใบ", "ok")
        return redirect(url_for("admin.equipment_down_fix"))
    return render_template("admin/downtime_fix.html", rows=DT.stale_downtimes(db))


# ───────────────────────── สถานะระบบ / แบ็กอัป ─────────────────────────

@bp.route("/admin/health")
@require_role("admin")
def health():
    from .. import health as H
    db = get_db()
    info = H.collect(db, current_app)
    return render_template("admin/health.html", h=info, integrity=request.args.get("integrity"))


@bp.route("/admin/health/backup", methods=["POST"])
@require_role("admin")
def health_backup():
    from .. import backup as BK
    res = BK.backup_now(current_app._get_current_object())
    if res.get("ok"):
        flash(f"แบ็กอัปสำเร็จ: {os.path.basename(res['file'])} ({res['size'] // 1024:,} KB · รูปใหม่ {res['photos']} ไฟล์ · {res['seconds']} วินาที)", "ok")
    else:
        flash("แบ็กอัปไม่สำเร็จ: " + str(res.get("error") or "ตรวจไฟล์ไม่ผ่าน"), "error")
    return redirect(url_for("admin.health"))


@bp.route("/admin/health/integrity", methods=["POST"])
@require_role("admin")
def health_integrity():
    from .. import health as H
    res = H.integrity(get_db())
    flash("ตรวจความสมบูรณ์ฐานข้อมูล: " + ("ปกติ (ok)" if res == "ok" else res), "ok" if res == "ok" else "error")
    return redirect(url_for("admin.health"))


@bp.route("/admin/health/download/<name>")
@require_role("admin")
def health_download(name):
    from .. import backup as BK
    if not re.fullmatch(r"echecksheet_\d{8}_\d{6}\.db", name):
        abort(404)
    folder = BK.settings(current_app.config)["dir"]
    if not os.path.exists(os.path.join(folder, name)):
        abort(404)
    return send_from_directory(folder, name, as_attachment=True)


# ───────────────────────── ผังย่อยรายพื้นที่ ─────────────────────────

@bp.route("/areas/<int:area_id>/map")
@require_role(*ALL_ROLES)
def area_map(area_id):
    """ผังย่อยของพื้นที่: หมุดรายเครื่องพร้อมสถานะการตรวจของวัน — ดูว่าครบจริงหรือไม่"""
    from datetime import date, timedelta
    from ..analytics import EQ_STATUS_TH, area_status, equipment_status
    db = get_db()
    area = db.execute("""SELECT a.*, f.name AS factory_name, f.id AS fid FROM areas a JOIN factories f ON f.id=a.factory_id
                         WHERE a.id=?""", (area_id,)).fetchone()
    if not area:
        abort(404)
    try:
        day = date.fromisoformat(request.args.get("date", ""))
    except ValueError:
        day = date.today()
    eqs = equipment_status(db, day, area_id)
    summary = {k: sum(1 for e in eqs if e["status"] == k) for k in EQ_STATUS_TH}
    rounds = sum(e["rounds"] for e in eqs)
    done = sum(e["done"] for e in eqs)
    siblings = area_status(db, day, area["factory_id"])
    return render_template("admin/area_map.html", area=dict(area), eqs=eqs, summary=summary, EQ_TH=EQ_STATUS_TH,
                           day=day, today=date.today(), prev=day - timedelta(days=1), next=day + timedelta(days=1),
                           rounds=rounds, done=done, edit=request.args.get("edit") == "1" and session_role() in MANAGE_ROLES,
                           siblings=siblings)


def session_role():
    from flask import session
    return session.get("role")


@bp.route("/areas/<int:area_id>/layout", methods=["POST"])
@require_role(*MANAGE_ROLES)
def area_layout_upload(area_id):
    db = get_db()
    try:
        if request.form.get("action") == "remove":
            M.set_area_layout(db, area_id, None, current_app.config["UPLOAD_FOLDER"], current_user_id())
            flash("ลบผังย่อยแล้ว — แสดงเป็นกล่องรายเครื่องแทน", "ok")
        else:
            f = request.files.get("layout")
            M.set_area_layout(db, area_id, f.read(M.MAX_LAYOUT_BYTES + 1) if f else b"",
                              current_app.config["UPLOAD_FOLDER"], current_user_id())
            flash("อัปโหลดผังย่อยแล้ว — เลือกเครื่องทางขวา แล้วคลิกบนผังเพื่อวางหมุด", "ok")
        db.commit()
    except ValidationError as exc:
        db.rollback()
        _flash_errors(exc)
    return redirect(url_for("admin.area_map", area_id=area_id, edit=1))


@bp.route("/api/equipment/<int:equipment_id>/pin", methods=["POST"])
@require_role(*MANAGE_ROLES)
def equipment_pin(equipment_id):
    db = get_db()
    data = request.get_json(silent=True) or {}
    try:
        if data.get("clear"):
            M.set_equipment_pin(db, equipment_id, None, None, current_user_id())
        else:
            M.set_equipment_pin(db, equipment_id, data.get("x"), data.get("y"), current_user_id())
        db.commit()
    except ValidationError as exc:
        db.rollback()
        return jsonify({"error": exc.errors[0]}), 400
    return jsonify({"ok": True})
