/* v0.40 เตรียมออฟไลน์ทั้งกะ + โหมดออฟไลน์ (เลือกเครื่องโดยไม่ต้องมีสัญญาณ)
   - เตรียม: โหลดงานวันนี้ · เส้นทาง · รายการแบบฟอร์ม · QR เครื่อง · แบบฟอร์มพร้อมประวัติเครื่อง เก็บใน IndexedDB
   - โหมดออฟไลน์ (/m/fill#pick): เลือกเครื่อง/สแกน QR จากรูป แล้วเปิดแบบฟอร์มในหน้าเดิม (ไม่ต้องโหลดหน้าใหม่)
     ระบบเปิดผ่าน http:// ในโรงงาน จึงเปิดหน้าใหม่ตอนไม่มีสัญญาณไม่ได้ → ต้องเปิดโหมดออฟไลน์ค้างไว้ก่อนเข้าที่อับสัญญาณ */
(function () {
  'use strict';
  const { esc, fmt } = ECS;
  const STALE_H = 12;
  const kv = ECS.kv;
  const hasSW = () => !!(window.isSecureContext && navigator.serviceWorker && navigator.serviceWorker.controller);

  async function prepare(opts) {
    const o = opts || {}, prog = o.onProgress || (() => {});
    prog({ step: 'list', done: 0, total: 0 });
    const d = await ECS.getJson('/api/m/offline-pack' + (o.all ? '?all=1' : ''));
    await kv.put('tasks', d.tasks);
    await kv.put('routes', d.routes);
    for (const [id, st] of Object.entries(d.route_details || {})) await kv.put('route:' + id, st);
    await kv.put('forms', d.forms);
    await kv.put('eqtok', d.tokens || {});
    const ids = d.form_ids || [], ok = [], fail = [];
    for (let i = 0; i < ids.length; i += 10) {
      const part = ids.slice(i, i + 10);
      try {
        const r = await ECS.getJson('/api/m/packages?ids=' + part.join(','));
        for (const id of part) {
          const p = (r.packages || {})[id];
          if (p && !p.error) { await kv.put('pkg:' + id, p); ok.push(id); } else fail.push(id);
        }
      } catch (e) { if (e.status === 401) throw e; fail.push(...part); }
      prog({ step: 'forms', done: Math.min(i + 10, ids.length), total: ids.length });
    }
    try { await ECS.loadJsQR(); } catch (e) { /* อ่าน QR จากรูปไม่ได้ → ยังเลือกจากรายการได้ */ }
    const info = { at: ECS.nowTs(), ids: ok, fails: fail, all: !!o.all, total: ids.length };
    await kv.put('offline_ready', info);
    return info;
  }

  async function readyInfo() {
    const r = await kv.get('offline_ready');
    if (!r) return null;
    const tasks = await kv.get('tasks');
    const need = tasks && tasks.prefetch_forms ? tasks.prefetch_forms : [];
    const have = new Set(r.ids || []);
    const missing = need.filter(id => !have.has(id));
    const age = (Date.now() - (ECS.parseTs(r.at) || new Date()).getTime()) / 3600000;
    return Object.assign({}, r, { missing, stale: age > STALE_H || r.at.slice(0, 10) !== ECS.nowTs().slice(0, 10) });
  }

  // ── กล่องบนหน้างานของฉัน ──
  async function renderHomeBox(box) {
    if (!box) return;
    const r = await readyInfo();
    const ok = r && !r.stale && !r.missing.length && r.ids.length;
    box.className = 'm-offbox' + (ok ? ' ready' : r ? ' warn' : '');
    box.innerHTML = `<div class="m-offst">${ok ? `<b>✓ พร้อมออฟไลน์</b> · ${r.ids.length} แบบฟอร์ม · เตรียมเมื่อ ${fmt(r.at)}`
        : r ? (r.stale ? `<b>⚠ ข้อมูลออฟไลน์เก่า</b> (เตรียมเมื่อ ${fmt(r.at, true)}) — เตรียมใหม่ก่อนออกเดิน`
          : r.missing.length ? `<b>⚠ มีงานใหม่ ${r.missing.length} แบบฟอร์มที่ยังไม่ได้เตรียม</b>` : `<b>⚠ ยังไม่มีแบบฟอร์มที่เตรียมไว้</b>`)
        : '📴 ก่อนลงพื้นที่อับสัญญาณ กดเตรียมออฟไลน์ไว้ก่อน'}${r && r.fails && r.fails.length ? ` · <span class="muted">โหลดไม่สำเร็จ ${r.fails.length}</span>` : ''}</div>
      <div class="m-offbtns"><button type="button" class="m-btn${ok ? '' : ' m-btn-primary'}" data-offprep>📥 เตรียมออฟไลน์ทั้งกะ</button>
        ${r && r.ids.length ? `<a class="m-btn${ok ? ' m-btn-primary' : ''}" href="${U('/m/fill')}#pick">📴 เปิดโหมดออฟไลน์</a>` : ''}</div>
      <label class="m-offall"><input type="checkbox" id="offAll" ${r && r.all ? 'checked' : ''}> รวมทุกแบบฟอร์มที่ตรวจได้ (สแกนเครื่องไหนก็เปิดได้ · ใช้เวลานานขึ้น)</label>
      <div class="m-offprog" hidden><div class="m-routebar"><div style="width:0%"></div></div><span class="small"></span></div>
      <div class="small muted">${hasSW() ? 'เครื่องนี้เปิดหน้าต่าง ๆ ได้แม้ไม่มีสัญญาณ'
        : 'สำคัญ: กด "เปิดโหมดออฟไลน์" ค้างไว้ก่อนเข้าที่อับสัญญาณ แล้วเลือกเครื่อง/สแกน QR จากในหน้านั้น (อย่าปิดแท็บ) — ระบบในโรงงานเปิดหน้าใหม่ตอนไม่มีสัญญาณไม่ได้'}</div>`;
  }
  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-offprep]'); if (!b) return;
    const box = b.closest('.m-offbox'); const pg = box.querySelector('.m-offprog'), bar = pg.querySelector('.m-routebar div'), txt = pg.querySelector('span');
    b.disabled = true; pg.hidden = false; txt.textContent = 'กำลังดึงรายการงาน…';
    try {
      const info = await prepare({ all: !!(box.querySelector('#offAll') || {}).checked, onProgress: p => {
        if (p.step === 'forms') { bar.style.width = (p.total ? Math.round(100 * p.done / p.total) : 100) + '%'; txt.textContent = `โหลดแบบฟอร์ม ${p.done}/${p.total}`; }
      } });
      await renderHomeBox(box);
      document.dispatchEvent(new CustomEvent('ecs:offready', { detail: info }));
      toast(info.fails.length ? `เตรียมแล้ว ${info.ids.length} แบบฟอร์ม · ไม่สำเร็จ ${info.fails.length}` : `✓ พร้อมออฟไลน์ ${info.ids.length} แบบฟอร์ม`, !info.fails.length);
    } catch (err) {
      b.disabled = false; pg.hidden = true;
      if (err.status === 401) { location.href = U('/login') + '?next=' + encodeURIComponent(location.pathname); return; }
      toast(navigator.onLine === false ? 'ไม่มีสัญญาณ — ต้องต่อสัญญาณตอนเตรียม' : 'เตรียมไม่สำเร็จ: ' + err.message);
    }
  });
  function toast(msg, ok) {
    const t = document.createElement('div'); t.className = 'm-toast ' + (ok ? 'ok' : 'err'); t.textContent = msg;
    document.body.appendChild(t); setTimeout(() => t.remove(), 3000);
  }

  // ── โหมดออฟไลน์: รายการเครื่องที่เตรียมไว้ ──
  async function renderPicker(app) {
    const r = await readyInfo();
    const forms = (await kv.get('forms')) || [];
    const prepared = new Set(r ? r.ids : []);
    for (const f of forms) if (!prepared.has(f.id) && await kv.get('pkg:' + f.id)) prepared.add(f.id);   // เคยเปิดแล้วก็ใช้ได้
    const byId = Object.fromEntries(forms.map(f => [f.id, f]));
    const st = await ECS.status();
    const queued = new Set(st.items.map(it => it.payload.form_id + ':' + (it.payload.round_id || 0)));
    const tasks = await kv.get('tasks');
    const routes = (await kv.get('routes')) || [];
    let q = '';
    const shown = new Set();
    const row = (fid, extra, rid, rt) => {
      shown.add(fid);
      const f = byId[fid] || {}, ok = prepared.has(fid), sent = queued.has(fid + ':' + (rid || 0));
      const href = `#f=${fid}${rid ? '&r=' + rid : ''}${rt ? '&rt=' + rt : ''}`;
      return `<a class="m-task${sent ? ' done' : ''}${ok ? '' : ' m-offno'}" ${ok ? `href="${href}"` : ''} data-q="${esc(((f.eq_code || '') + ' ' + (f.name || '') + ' ' + (f.area_name || '')).toLowerCase())}">
        <div class="m-task-main"><div class="m-task-title">${f.eq_code ? `<span class="mono">${esc(f.eq_code)}</span> · ` : ''}${esc(f.name || ('แบบฟอร์ม ' + fid))}</div>
        <div class="m-task-meta">${esc(f.area_name || f.factory_name || '')}${extra ? ' · ' + extra : ''}</div></div>
        <div class="m-task-side">${sent ? '<span class="badge b-ok">บันทึกแล้ว · รอส่ง</span>' : ok ? '' : '<span class="badge b-none">ไม่ได้เตรียม</span>'}</div></a>`;
    };
    let html = `<div class="m-offhead"><b>📴 โหมดออฟไลน์</b> · ${r ? `เตรียมไว้ ${prepared.size} แบบฟอร์ม · ${fmt(r.at, true)}` : 'ยังไม่ได้เตรียม'}
      ${st.items.length ? `<div class="small">รอส่ง <b>${st.items.length}</b> รายการ — ส่งเองเมื่อมีสัญญาณ <button type="button" class="linkbtn" data-offsync>ส่งตอนนี้</button></div>` : ''}</div>
      <button type="button" class="m-btn m-btn-primary m-btn-block m-btn-lg" data-offqr>📷 ถ่ายรูป QR ที่เครื่อง</button>
      <input type="search" class="m-input m-fsearch" id="offQ" placeholder="ค้นหา: รหัสเครื่อง / ชื่อ / พื้นที่">
      <div id="offList">`;
    if (tasks) {
      const g = tasks.groups || {}, keys = [['returned', 'ถูกตีกลับ'], ['overdue', 'เลยกำหนด'], ['due', 'ถึงเวลาตรวจ'], ['upcoming', 'ถัดไปวันนี้']];
      const rows = keys.flatMap(([k, lbl]) => (g[k] || []).map(t => row(t.form_id, `${lbl} ${fmt(t.due_at)}–${fmt(t.deadline_at)}`, t.id)));
      if (rows.length) html += `<h2 class="m-h">งานวันนี้ <small class="muted">(ข้อมูล ${fmt(tasks.now, true)})</small></h2>` + rows.join('');
    }
    for (const rt of routes) {
      const d = await kv.get('route:' + rt.id);
      if (d && d.stops && d.stops.length) html += `<h2 class="m-h">🚶 ${esc(d.route.name)}</h2>` + d.stops.map((s, i) => row(s.form_id, `จุดที่ ${i + 1}`, s.round_id, rt.id)).join('');
    }
    const others = [...prepared].filter(id => !shown.has(id));
    if (others.length) html += '<h2 class="m-h">แบบฟอร์มอื่นที่เตรียมไว้</h2>' + others.map(id => row(id, 'ตรวจนอกรอบ')).join('');
    if (!prepared.size) html += '<div class="m-empty"><strong>ยังไม่มีแบบฟอร์มในเครื่อง</strong><br>ต่อสัญญาณแล้วกด "เตรียมออฟไลน์ทั้งกะ" ที่หน้างานของฉัน</div>';
    html += `</div><div id="offMsg"></div><a class="m-btn m-btn-block" href="${U('/m/')}" style="margin-top:14px">กลับไปงานของฉัน (ต้องมีสัญญาณ)</a>`;
    app.innerHTML = html;
    const inp = app.querySelector('#offQ');
    inp.addEventListener('input', () => { q = inp.value.trim().toLowerCase();
      app.querySelectorAll('#offList .m-task').forEach(a => { a.hidden = !!q && !a.dataset.q.includes(q); });
      app.querySelectorAll('#offList .m-h').forEach(h => { h.hidden = !!q; }); });
  }

  function qrTarget(v, tokens) {
    const m = String(v || '').match(/\/(e\/[A-Za-z0-9_-]+|p\/\d+\/[A-Za-z0-9-]+)\/?$/);
    if (!m) return { error: 'QR นี้ไม่ใช่ป้ายของระบบ E-Checksheet' };
    if (m[1].charAt(0) === 'p') { const [, fid, code] = m[1].split('/'); return { hash: `f=${fid}&pt=${encodeURIComponent(code)}&qr=1`, fid: Number(fid) }; }
    const ids = tokens[m[1].slice(2)] || [];
    return ids.length ? { ids } : { error: 'เครื่องนี้ไม่อยู่ในแบบฟอร์มที่เตรียมไว้ — เตรียมออฟไลน์แบบ "รวมทุกแบบฟอร์ม" หรือรอมีสัญญาณ' };
  }
  document.addEventListener('click', async e => {
    if (e.target.closest('[data-offsync]')) { e.preventDefault(); await ECS.sync(); const app = document.getElementById('app'); if (location.hash === '#pick') renderPicker(app); return; }
    if (!e.target.closest('[data-offqr]')) return;
    e.preventDefault();
    const v = await ECS.photoQR(); if (!v) return;
    const t = qrTarget(v, (await kv.get('eqtok')) || {}), msg = document.getElementById('offMsg');
    if (t.error) { if (msg) msg.innerHTML = `<div class="m-err">${esc(t.error)}</div>`; return; }
    if (t.hash) { location.hash = t.hash; return; }
    if (t.ids.length === 1) { location.hash = 'f=' + t.ids[0] + '&qr=1'; return; }
    const forms = Object.fromEntries(((await kv.get('forms')) || []).map(f => [f.id, f]));
    if (msg) msg.innerHTML = '<div class="m-card"><b>เลือกแบบฟอร์มของเครื่องนี้</b>' + t.ids.map(id =>
      `<a class="m-btn m-btn-block" href="#f=${id}&qr=1">${esc((forms[id] || {}).name || ('แบบฟอร์ม ' + id))}</a>`).join('') + '</div>';
    if (msg) msg.scrollIntoView({ behavior: 'smooth' });
  });

  window.ECSOffline = { prepare, readyInfo, renderHomeBox, renderPicker, qrTarget };
})();
