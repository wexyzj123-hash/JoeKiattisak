"""v0.99.29: เช็คชีทวันนี้ คิดรายกะ — % = ตรวจแล้ว ÷ (ตรวจแล้ว + ยังไม่ตรวจ) · ไม่นับเครื่องหยุด · วันนี้นับเฉพาะกะปัจจุบัน
กะเป็นของวันที่เริ่มกะ (กะกลางคืน 20:00 → 08:00 วันถัดไป)"""
from datetime import date, datetime

import pytest
from ecs import analytics as AN
from ecs import services as S

D = date(2026, 10, 26)
ROUNDS = [  # (due_at, status)
    ("2026-10-25 21:00:00", "done_on_time"),     # กะกลางคืนของวันที่ 25 (ก่อนเที่ยงคืน)
    ("2026-10-26 02:00:00", "pending"),          # กะกลางคืนของวันที่ 25 (หลังเที่ยงคืน)
    ("2026-10-26 07:45:00", "done_late"),        # ก่อนเริ่มกะ 08:00 ≤ 30 นาที → กะกลางวันวันที่ 26
    ("2026-10-26 09:00:00", "done_on_time"),
    ("2026-10-26 10:00:00", "overdue"),
    ("2026-10-26 11:00:00", "skipped"),          # เครื่องหยุด → ไม่นับ
    ("2026-10-26 12:00:00", "missed"),
    ("2026-10-26 16:00:00", "pending"),
    ("2026-10-26 21:00:00", "pending"),          # กะกลางคืนวันที่ 26
    ("2026-10-27 03:00:00", "returned"),         # กะกลางคืนวันที่ 26 (หลังเที่ยงคืน)
]


@pytest.fixture
def fake(monkeypatch):
    def ov(db, d, factory_id=None):
        return {"items": [{"due_at": a, "status": b} for a, b in ROUNDS if a[:10] == d.isoformat()]}
    monkeypatch.setattr(S, "rounds_overview", ov)


def test_today_counts_only_current_day_shift(db, fake):
    r = AN.shift_progress(db, D, now=datetime(2026, 10, 26, 12, 30))
    h = r["head"]
    assert h["scope"] == "shift" and h["label"] == "กะกลางวัน" and h["range"] == "08:00–20:00"
    assert (h["done"], h["total"], h["pct"]) == (2, 5, 40)                # 07:45 + 09:00 จาก 5 (ไม่นับเครื่องหยุด)
    assert (h["wait"], h["late"], h["missed"], h["down_all"]) == (1, 1, 1, 1)
    states = {w["range"]: w["state"] for w in r["shifts"]}
    assert states == {"08:00–20:00": "current", "20:00–08:00": "future"}  # กะกลางคืนยังไม่ถึง = ไม่นับ


def test_night_shift_crosses_midnight(db, fake):
    r = AN.shift_progress(db, D, now=datetime(2026, 10, 26, 3, 0))
    h = r["head"]
    assert h["label"] == "กะกลางคืน" and h["prev_day"] is True                # กะที่เริ่มเมื่อวาน 20:00 และยังทำอยู่
    assert (h["done"], h["total"], h["pct"]) == (1, 2, 50)                 # 21:00 (เมื่อวาน) + 02:00 (วันนี้)


def test_past_day_sums_shifts_that_started_that_day(db, fake):
    r = AN.shift_progress(db, D, now=datetime(2026, 10, 28, 9, 0))
    h = r["head"]
    assert h["scope"] == "day"
    assert (h["done"], h["total"]) == (2, 7)                                # กะกลางวัน 5 + กะกลางคืน (21:00, 03:00 วันที่ 27) 2
    assert sum(w["total"] for w in r["shifts"]) == h["total"] and h["down_all"] == 1
    assert all(w["state"] == "past" for w in r["shifts"])


def test_dashboard_tile_renders_shift(client):
    from conftest import login
    login(client, "t_admin")
    h = client.get("/dashboard").get_data(as_text=True)
    assert "data-ck" in h and "sh-legend" in h
    assert "เครื่องหยุด" not in h.split('class="kx lift" data-ck', 1)[1].split("</a>", 1)[0].split("ไม่นับเครื่องหยุด")[0]
