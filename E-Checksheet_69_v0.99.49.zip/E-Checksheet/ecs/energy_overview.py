"""ecs/energy_overview.py — v0.99.49 หน้าภาพรวมพลังงาน (แบบ Pro): อ่านง่าย ดูสีรู้เลย ทุกตัวเลขกดไปข้อมูลต้นทางได้

ตัวกรอง: โรงงาน · Project · หน่วยงาน (Section) · ไลน์ · วันที่ — ใช้ตัวคำนวณเดียวกับหน้า “รายช่วงเวลา” (energy_live.data)
ส่วนประกอบ:
  kpis      ใช้ไฟวันนี้ · กำลังไฟตอนนี้ · ค่าไฟ · CO₂ (เทียบเมื่อวานช่วงเวลาเดียวกัน) + เส้นแนวโน้ม 7 วัน
  flow      ไฟฟ้ากำลังไหลไปที่ไหน: ขอบเขตที่เลือก → กลุ่มระดับถัดไป (โรงงาน › Project › หน่วยงาน › ไลน์ › มิเตอร์) kW ตอนนี้
  top       กลุ่มที่ใช้มากที่สุดวันนี้ (kWh) + ธงเมื่อสูงกว่าเมื่อวาน
  hourly    ทั้งวันทีละชั่วโมง วันนี้ vs เมื่อวาน · ชั่วโมงสูงสุด · ใช้นอกเวลาทำงาน · ส่วนต่างเทียบเมื่อวาน
  tracker   สถานะรายชั่วโมงของแต่ละกลุ่ม (ปกติ / สูงกว่าปกติ / ผิดปกติ / ไม่มีข้อมูล)
  health    มิเตอร์ที่ส่งข้อมูลราย 15 นาทีวันนี้ / ทั้งหมด
"""
from __future__ import annotations

import math
from datetime import date, datetime, time, timedelta

from . import energy as EN
from . import energy_live as LV
from . import services as S

KIND = "elec"
TOP_N = 6
HIGH = 15.0          # % สูงกว่าเมื่อวานชั่วโมงเดียวกัน → สูงกว่าปกติ
CRIT = 40.0          # % → ผิดปกติ
PALETTE = ["#5ec1de", "#f5b83d", "#b9a6ff", "#7ee0a8", "#ff9f7a", "#9ad1ff", "#e3c27e"]


def _hm(s: str) -> int:
    try:
        h, m = (int(x) for x in str(s).split(":"))
        return h * 60 + m
    except ValueError:
        return 0


def _fmt_ago(mins: int | None) -> str:
    if mins is None:
        return "–"
    if mins < 60:
        return f"{mins} นาทีที่แล้ว"
    if mins < 60 * 48:
        return f"{mins // 60} ชม.ที่แล้ว"
    return f"{mins // 1440} วันที่แล้ว"


def _hours(series: list) -> list:
    """96 ช่อง → 24 ชั่วโมง (None = ชั่วโมงนั้นไม่มีค่าเลย)"""
    out = []
    for h in range(24):
        xs = [v for v in series[h * 4:(h + 1) * 4] if v is not None]
        out.append(sum(xs) if xs else None)
    return out


def _spark(vals: list, w: int = 300, h: int = 40) -> dict:
    xs = [v for v in vals if v is not None]
    if len(xs) < 2:
        return {"line": "", "area": ""}
    lo, hi = min(xs), max(xs)
    span = (hi - lo) or 1.0
    pts = [(i * w / (len(vals) - 1), h - 4 - (h - 10) * ((v if v is not None else lo) - lo) / span) for i, v in enumerate(vals)]
    line = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    return {"line": line, "area": f"0,{h} {line} {w},{h}"}


def build(db, day: date, fid=None, project_id=None, grp=None, line=None, now: datetime | None = None) -> dict:
    from . import energy_dept as DP
    from . import energy_power as PW
    now = now or S.now_dt()
    today = now.date()
    day = min(day, today)
    is_today = day == today
    d = LV.data(db, KIND, day, fid, project_id, grp, line, "yday", heat=False)
    k = d["kpi"]
    rate_h = d["rate"]                                         # ค่าต่อช่วง → kW
    total, cmp_total = d["total"], d["cmp_total"]
    last = max((i for i, v in enumerate(total) if v is not None), default=None)
    # ── กลุ่มระดับถัดไป: วันนี้ + เมื่อวาน (ราย 15 นาที) ──
    ms_all = EN.meters(db, fid, KIND, True, project_id, grp, line)
    ms = [m for m in EN.counted(ms_all) if m["is_main"] != -1]
    solar_ms = [m for m in ms_all if m["is_main"] == -1]
    # ระดับถัดไป: ข้ามระดับที่มีกลุ่มเดียว (เช่น ยังไม่ได้ตั้ง Project) → ลงไปหน่วยงาน / ไลน์ / มิเตอร์ ให้เห็นการแยกจริง
    order = ["factory", "project", "grp", "line", "meter"]
    level = d["level"]
    while level != "meter" and len({LV._key(m, level)[0] for m in ms}) <= 1:
        level = order[order.index(level) + 1]
    level_th = {"factory": "โรงงาน", "project": "Project", "grp": "หน่วยงาน", "line": "ไลน์", "meter": "มิเตอร์"}[level]
    a = datetime.combine(day, time(0, 0))
    ids = [m["id"] for m in ms]
    per = LV._sums(db, ids, a, a + timedelta(days=1)) if ids else {}
    per_y = LV._sums(db, ids, a - timedelta(days=1), a) if ids else {}
    groups: dict = {}
    for m in ms:
        key, name, _c, q = LV._key(m, level)
        g = groups.setdefault(key, {"key": key, "name": name, "q": q, "s": [None] * LV.NSLOT, "y": [None] * LV.NSLOT, "n": 0, "n_data": 0, "meter_id": m["id"]})
        g["n"] += 1
        if m["id"] in per:
            g["n_data"] += 1
            LV._add(g["s"], per[m["id"]])
        if m["id"] in per_y:
            LV._add(g["y"], per_y[m["id"]])
    cut = last if last is not None else -1
    rows = []
    for g in groups.values():
        today_sum = sum(v for v in g["s"] if v is not None)
        same_y = sum(v for i, v in enumerate(g["y"]) if v is not None and i <= cut)
        last_g = max((i for i, v in enumerate(g["s"]) if v is not None), default=None)
        kw_now = g["s"][last] * rate_h if last is not None and g["s"][last] is not None else None
        stale = last is not None and (last_g is None or last - last_g >= 8)          # ไม่มีค่า ≥ 2 ชม. ล่าสุด
        chg = round(100 * (today_sum - same_y) / same_y, 1) if same_y else None
        st = "o" if stale or not g["n_data"] else ("w" if chg is not None and chg > HIGH else "n")
        hs, hy = _hours(g["s"]), _hours(g["y"])
        rows.append({**{x: g[x] for x in ("key", "name", "q", "n", "n_data", "meter_id")}, "sum": today_sum, "same_y": same_y, "chg": chg,
                     "kw": kw_now, "st": st, "hs": hs, "hy": hy})
    rows.sort(key=lambda r: (-r["sum"], str(r["name"])))
    tot_sum = k["sum"] or 0.0
    # ── KPI ──
    month = day.replace(day=1)
    rate = DP._rate(db, fid, KIND, month) or 0.0
    ef = DP._ef(db, KIND) or 0.0
    kw_now = total[last] * rate_h if last is not None else None
    peak_kw = k.get("peak")
    tgt_kw = None
    try:
        fids = [fid] if fid else [r[0] for r in db.execute("SELECT DISTINCT factory_id FROM en_meters WHERE active=1 AND factory_id IS NOT NULL")]
        tg = [PW.tariff(db, x).get("demand_target") for x in fids]
        if tg and all(tg) and not (project_id or grp or line):
            tgt_kw = float(sum(float(x) for x in tg))
    except Exception:                                          # noqa: BLE001 — ไม่มีตารางอัตราค่าไฟ
        tgt_kw = None
    cmp_same = k.get("cmp_same") or 0.0
    diff = tot_sum - cmp_same
    pct = k.get("diff_pct")
    # เส้นแนวโน้ม 7 วัน (ยอดรายวันจากค่าอ่านมิเตอร์ — ตัวคำนวณเดียวกับทุกหน้า)
    d7 = [day - timedelta(days=6 - i) for i in range(7)]
    daily7: list = [None] * 7
    if ms:
        ser = EN.series(db, ms, d7[0], d7[-1])
        for i, dd in enumerate(d7):
            xs = [ser.get(m["id"], {}).get(dd.isoformat(), {}).get("u") for m in ms]
            xs = [x for x in xs if x is not None]
            daily7[i] = sum(xs) if xs else None
    if is_today:
        daily7[-1] = tot_sum or daily7[-1]
    hr_today = _hours(total)
    hr_y = _hours(cmp_total)
    kw_line = [v * rate_h / 4 if v is not None else None for v in hr_today]   # kW เฉลี่ยรายชั่วโมง
    kpis = {
        "kwh": {"value": tot_sum, "cmp": cmp_same, "pct": pct, "spark": _spark(daily7)},
        "kw": {"value": kw_now, "peak": peak_kw, "peak_at": k.get("peak_at"), "target": tgt_kw,
               "pct": round(100 * kw_now / tgt_kw) if kw_now and tgt_kw else None, "spark": _spark([v for v in kw_line if v is not None] or [0, 0])},
        "baht": {"value": tot_sum * rate, "cmp": cmp_same * rate, "pct": pct, "rate": rate, "spark": _spark([v * rate if v is not None else None for v in daily7])},
        "co2": {"value": tot_sum * ef / 1000, "cmp": cmp_same * ef / 1000, "pct": pct, "ef": ef, "spark": _spark([v * ef if v is not None else None for v in daily7])},
    }
    # ── การไหล (kW ตอนนี้) ──
    shown = rows[:TOP_N]                                      # รวมกลุ่มที่ไม่ส่งข้อมูล (เส้นประสีเทา) ให้เห็นว่าขาดตรงไหน
    rest = rows[TOP_N:]
    nodes = []
    for i, r in enumerate(shown):
        nodes.append({**r, "color": {"n": "#5ec1de", "w": "#f5b83d", "o": "#9aa5af"}[r["st"]], "accent": PALETTE[i % len(PALETTE)]})
    if rest:
        nodes.append({"name": f"อื่น ๆ ({len(rest)})", "q": None, "kw": sum((r["kw"] or 0) for r in rest), "sum": sum(r["sum"] for r in rest), "st": "n",
                      "color": "#6f7b86", "accent": "#6f7b86", "chg": None, "other": True})
    n = len(nodes)
    H = max(300, 90 * n)
    kws = [max(x["kw"] or 0, 0) for x in nodes]
    mx = max(kws) if kws and max(kws) > 0 else 1
    for i, x in enumerate(nodes):
        y = H / (n + 1) * (i + 1) if n else H / 2
        x["y"] = round(y, 1)
        x["w"] = round(3 + 11 * math.sqrt(max(x["kw"] or 0, 0) / mx), 1)
        x0, y0 = 176, H / 2 + (i - (n - 1) / 2) * 10
        x["path"] = f"M{x0} {y0:.1f} C {360} {y0:.1f}, {360} {y:.1f}, {530} {y:.1f}"
        x["dash"] = "5 4" if x["st"] == "o" else "0"
    solar = None
    if solar_ms:
        sp = LV._sums(db, [m["id"] for m in solar_ms], a, a + timedelta(days=1))
        sv = [row[last] for row in sp.values() if last is not None and row[last] is not None]
        solar = round(sum(sv) * rate_h, 1) if sv else 0.0
    flow = {"nodes": nodes, "h": H, "cy": H / 2, "kw": kw_now, "solar": solar, "level": level, "level_th": level_th}
    # ── ทั้งวันทีละชั่วโมง ──
    cur_h = (last // 4) if last is not None else None
    peak_h = max(((h, v) for h, v in enumerate(hr_today) if v is not None), key=lambda x: x[1], default=None)
    cfg = PW.tariff(db, fid) if fid else PW.tariff(db, 0)
    ws, we = _hm(cfg.get("work_start") or "08:00") // 60, _hm(cfg.get("work_end") or "17:00") // 60
    off = sum(v for h, v in enumerate(hr_today) if v is not None and not (ws <= h < we))
    hourly = {"today": [round(v, 2) if v is not None else None for v in hr_today], "yday": [round(v, 2) if v is not None else None for v in hr_y],
              "cur": cur_h, "peak_h": peak_h[0] if peak_h else None, "peak_v": peak_h[1] if peak_h else None,
              "off_pct": round(100 * off / tot_sum) if tot_sum else None, "work": f"{ws:02d}:00–{we:02d}:00", "diff": diff}
    # ── สถานะรายชั่วโมง ──
    tracker = []
    for r in nodes:
        if r.get("other"):
            continue
        cells, ok, done = [], 0, 0
        for h in range(24):
            v, y = r["hs"][h], r["hy"][h]
            future = is_today and cur_h is not None and h > cur_h
            if future:
                st = "f"
            elif v is None:
                st = "x"
            else:
                done += 1
                p = 100 * (v - y) / y if y else None
                st = "c" if p is not None and p > CRIT else ("h" if p is not None and p > HIGH else "n")
                ok += st == "n"
            cells.append({"st": st, "h": h, "v": v, "y": y, "pct": round(100 * (v - y) / y, 1) if v is not None and y else None})
        tracker.append({"name": r["name"], "q": r["q"], "cells": cells, "ok": ok, "done": done})
    # ── สุขภาพข้อมูล ──
    health = {"n": k["n"], "n_data": k["n_data"], "pct": round(100 * k["n_data"] / k["n"]) if k["n"] else None,
              "last_ts": k.get("last_ts"), "age": None}
    if k.get("last_ts"):
        lt = S.parse_ts(k["last_ts"])
        if lt:
            health["age"] = max(0, round((now - lt).total_seconds() / 60))
    health["age_txt"] = _fmt_ago(health["age"])
    upto = (LV.slot_labels() + ["24:00"])[last + 1] if last is not None else None
    return {"day": day, "is_today": is_today, "level": level, "level_th": level_th, "kpis": kpis, "flow": flow, "top": rows[:TOP_N],
            "n_groups": len(rows), "hourly": hourly, "tracker": tracker, "health": health, "upto": upto, "unit": d["unit"],
            "has_data": last is not None, "rate": rate, "ef": ef, "n_meters": len(ms)}
