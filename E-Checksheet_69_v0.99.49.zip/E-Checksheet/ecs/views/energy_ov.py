"""v0.99.49 หน้าภาพรวมพลังงานแบบ Pro — ตัวกรอง โรงงาน · Project · หน่วยงาน · ไลน์ · วันที่ · ทุกตัวเลขกดไปข้อมูลต้นทาง"""
from __future__ import annotations

from datetime import date

from flask import jsonify, redirect, render_template, request, session, url_for

from .. import energy as EN
from .. import energy_field as EF
from .. import energy_overview as OV
from .. import energy_struct as ST
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import now_dt
from .energy import _ctx, bp

KEEP = ("factory", "project", "grp", "line")


def _filters():
    db = get_db()
    fid = request.args.get("factory", type=int) or None
    sc = EF.user_scope(db, current_user_id())
    if sc["factory_id"]:
        fid = sc["factory_id"]
    project_id = request.args.get("project", type=int) or None
    grp = (request.args.get("grp") or "")[:80] or None
    line = (request.args.get("line") or "")[:80] or None
    today = now_dt().date()
    try:
        day = min(date.fromisoformat(request.args.get("day") or ""), today)
    except ValueError:
        day = today
    return db, fid, project_id, grp, line, day, today


@bp.route("/overview")
@require_role(*ALL_ROLES)
def overview():
    if not request.args and session.get("en_ov"):            # จำตัวกรองล่าสุด
        return redirect(url_for("energy.overview", **session["en_ov"]))
    if request.args:
        session["en_ov"] = {k: request.args[k] for k in KEEP if request.args.get(k)}
    db, fid, project_id, grp, line, day, today = _filters()
    if request.args.get("meter", type=int):                   # กดมิเตอร์ (ระดับล่างสุด) → หน้ามิเตอร์
        return redirect(url_for("energy.meter_detail", mid=request.args.get("meter", type=int)) + f"?pday={day.isoformat()}#prof")
    O = OV.build(db, day, fid, project_id, grp, line)
    base = EN.meters(db, fid, OV.KIND, True)
    fc = ST.facets(base)
    fc_s = ST.facets(ST.apply_filter(base, project_id)) if project_id else fc
    fc_l = ST.facets(ST.apply_filter(base, project_id, grp)) if grp else fc_s
    q = {k: v for k, v in (("factory", fid), ("project", project_id), ("grp", grp), ("line", line)) if v}
    qd = {**q, "day": day.isoformat()} if day != today else dict(q)

    def drill(extra: dict | None) -> str | None:
        if extra is None:
            return None
        return url_for("energy.overview", **{**qd, **{k: v for k, v in extra.items() if v is not None}})
    src = {
        "live": url_for("energy_live.page", **{**q, "day": day.isoformat()}),
        "power": url_for("energy_pw.power", factory=fid or ""),
        "cost": url_for("energy_cost.home", factory=fid or ""),
        "co2": url_for("energy_sum.summary"),
        "dept": url_for("energy.dept", factory=fid or ""),
        "month": url_for("energy.dashboard", **q),
        "health": url_for("energy_src.sources") if session.get("role") == "admin" else url_for("energy.meters", factory=fid or ""),
        "compare": url_for("energy.compare", factory=fid or "", grp=grp or ""),
    }
    for r in O["top"]:
        r["url"] = drill(r["q"])
        r["dept_url"] = url_for("energy.dept", factory=fid or "", grp=r["q"].get("grp")) if O["level"] == "grp" else None
    for x in O["flow"]["nodes"]:
        x["url"] = drill(x.get("q"))
    for t in O["tracker"]:
        lq = {**q, **{k: v for k, v in t["q"].items() if k != "meter"}, "day": day.isoformat()}
        t["url"] = drill(t["q"])
        t["live"] = url_for("energy_live.page", **lq)
    names = {"factory": None, "project": None}
    from .. import masterdata as M
    facs = M.list_factories(db)
    crumbs = [{"label": "ทุกโรงงาน", "url": url_for("energy.overview", factory="", **({"day": day.isoformat()} if day != today else {}))}]
    if fid:
        crumbs.append({"label": next((f["name"] for f in facs if f["id"] == fid), f"#{fid}"), "url": drill({}) if not (project_id or grp or line) else
                       url_for("energy.overview", factory=fid, **({"day": day.isoformat()} if day != today else {}))})
    if project_id:
        names["project"] = next((p["name"] for p in fc["projects"] if p["id"] == project_id), "Project")
        crumbs.append({"label": names["project"], "url": url_for("energy.overview", **{k: v for k, v in qd.items() if k not in ("grp", "line")})})
    if grp:
        crumbs.append({"label": "ไม่ระบุหน่วยงาน" if grp == "-" else grp, "url": url_for("energy.overview", **{k: v for k, v in qd.items() if k != "line"})})
    if line:
        crumbs.append({"label": "ไม่ระบุไลน์" if line == "-" else line, "url": drill({})})
    chart = {"today": O["hourly"]["today"], "yday": O["hourly"]["yday"], "cur": O["hourly"]["cur"], "is_today": O["is_today"], "live": src["live"],
             "unit": O["unit"]}
    return render_template("energy/overview.html", **_ctx(O=O, fid=fid, project_id=project_id, grp=grp, line=line, day=day, today=today,
                                                         fc=fc, fc_s=fc_s, fc_l=fc_l, crumbs=crumbs, src=src, chart=chart, q=q, now=now_dt(),
                                                         scoped=bool(EF.user_scope(db, current_user_id())["factory_id"])))


@bp.route("/overview.json")
@require_role(*ALL_ROLES)
def overview_json():
    """ข้อมูลเดียวกับหน้าภาพรวม (สำหรับจอทีวี / ระบบอื่นดึงไปใช้)"""
    db, fid, project_id, grp, line, day, _today = _filters()
    O = OV.build(db, day, fid, project_id, grp, line)
    k = O["kpis"]
    return jsonify({"day": day.isoformat(), "upto": O["upto"], "level": O["level"],
                    "kwh": round(k["kwh"]["value"], 1), "kwh_cmp": round(k["kwh"]["cmp"], 1), "pct": k["kwh"]["pct"],
                    "kw": k["kw"]["value"], "baht": round(k["baht"]["value"]), "co2_t": round(k["co2"]["value"], 3),
                    "groups": [{"name": r["name"], "kwh": round(r["sum"], 1), "kw": r["kw"], "chg": r["chg"], "state": r["st"]} for r in O["top"]],
                    "hourly": O["hourly"]["today"], "hourly_yday": O["hourly"]["yday"],
                    "meters": O["health"]["n"], "meters_data": O["health"]["n_data"]})
