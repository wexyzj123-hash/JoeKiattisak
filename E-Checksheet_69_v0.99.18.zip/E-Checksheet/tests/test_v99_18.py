"""v0.99.18: หน้าแนวโน้ม + หน้ารายงานเป็นแดชบอร์ดธีมเดียวกับภาพรวม · ดูเฉพาะวัน (?day=) · แถบวันของเดือนในหน้ารายงาน"""
import re
from calendar import monthrange
from datetime import date, timedelta

from conftest import GOOD, login, payload, uid

from ecs import submissions as SUB


def _submit(app, db, form, oil="2.1"):
    SUB.create_submission(db, payload(form, {**GOOD, "oil": {"value": oil}}), {}, uid(db, "t_tech"), app.config["UPLOAD_FOLDER"])
    db.commit()


def test_trends_hero_and_single_day(app, client, db, published_form):
    _submit(app, db, published_form)
    login(client, "t_view")
    fid, today = published_form["form_id"], date.today()
    h = client.get(f"/trends?form={fid}&item=oil").get_data(as_text=True)
    assert "dash-luxe lx-page" in h and 'class="lx-hero' in h and h.count('class="kx"') == 6
    assert "30 วัน</b>" in h and 'class="kcards"' in h                    # ของเดิมยังอยู่ (ย้ายตัวเลขขึ้นแถบหัว)
    assert 'data-mcfilter="bad"' in h and "kx-ring" in h
    # ดูเฉพาะวันนี้: เห็นค่าที่ตรวจวันนี้ · ลิงก์ในหน้าคงวันไว้
    d = client.get(f"/trends?form={fid}&item=oil&day={today.isoformat()}").get_data(as_text=True)
    assert "เฉพาะวัน</b>" in d and "c-trend" in d
    assert f"day={today.isoformat()}&mode=spc#deep" in d
    assert f"from={today.isoformat()}&amp;to={today.isoformat()}" in d       # Excel คุณภาพใช้ช่วงวันเดียว
    assert 'aria-label="วันถัดไป"' not in d                                  # วันนี้ไม่มีวันถัดไป
    assert f'name="day" value="{today.isoformat()}"' in d
    # วันอื่นที่ไม่มีผลตรวจ
    y = (today - timedelta(days=1)).isoformat()
    e = client.get(f"/trends?form={fid}&item=oil&day={y}").get_data(as_text=True)
    assert "ลองเลือกวันอื่น" in e and 'aria-label="วันถัดไป"' in e
    # วันอนาคต → วันนี้ · ค่าผิดรูปแบบ → ช่วงปกติ
    f = client.get(f"/trends?form={fid}&day={(today + timedelta(days=9)).isoformat()}").get_data(as_text=True)
    assert f'name="day" value="{today.isoformat()}"' in f
    g = client.get(f"/trends?form={fid}&day=xx").get_data(as_text=True)
    assert "30 วัน</b>" in g
    # ช่วง from/to เดิมยังใช้ได้ และลิงก์คงช่วงไว้
    a = (today - timedelta(days=3)).isoformat()
    r = client.get(f"/trends?form={fid}&item=oil&from={a}&to={today.isoformat()}").get_data(as_text=True)
    assert "4 วัน</b>" in r and f"from={a}" in r


def test_trends_quality_links_keep_range(app, client, db, published_form):
    _submit(app, db, published_form)
    login(client, "t_view")
    fid = published_form["form_id"]
    h = client.get(f"/trends?form={fid}&days=7").get_data(as_text=True)
    assert "/quality?days=7" in h or "quality?qscope=num&amp;days=7" in h
    assert "days=7&qscope=all#quality" in h


def test_reports_day_strip(app, client, db, published_form):
    _submit(app, db, published_form)
    _submit(app, db, published_form, oil="2.2")
    login(client, "t_view")
    today = date.today()
    last = monthrange(today.year, today.month)[1]
    h = client.get("/reports").get_data(as_text=True)
    assert "dash-luxe lx-page" in h and 'class="lx-hero' in h and 'id="rpDays"' in h
    assert len(re.findall(r'class="rd[^"]*" data-day="\d+"', h)) == last
    m = re.search(rf'class="rd([^"]*)" data-day="{today.day}"[^>]*data-n="(\d+)" data-ng="(\d+)" data-nf="(\d+)"', h)
    assert m and " td" in m.group(1) and m.group(2) == "2" and m.group(4) == "1"
    assert len(re.findall(r'data-day="\d+"[^>]*\bdisabled\b', h)) == last - today.day      # วันอนาคตกดไม่ได้
    assert 'data-sel=""' in h
    assert f'data-sel="{today.day}"' in client.get(f"/reports?day={today.day}").get_data(as_text=True)
    assert 'data-sel=""' in client.get("/reports?day=99").get_data(as_text=True)
    # ของเดิมครบ: การ์ดสถานะ 5 ใบ · ตัวกรองวันที่ · รายงานสรุป · ข้อมูลดิบ
    for s in ('data-kf="has:1"', 'data-kf="st:pending"', 'data-kf="st:ng"', 'data-kf="st:unsigned"', 'data-kf="has:0"',
              'id="sfFrom"', 'id="sfTo"', 'id="fSum"', 'id="fRaw"', 'id="sheetList"'):
        assert s in h
    # เดือนก่อน: ทุกวันกดได้
    pm = (today.replace(day=1) - timedelta(days=1))
    p = client.get(f"/reports?month={pm:%Y-%m}").get_data(as_text=True)
    assert len(re.findall(r'class="rd[^"]*" data-day="\d+"', p)) == pm.day
    assert not re.findall(r'data-day="\d+"[^>]*\bdisabled\b', p)


def test_approvals_dashboard(app, client, db, published_form):
    """v0.99.18 หน้ารออนุมัติแบบแดชบอร์ด: ตัวเลขสรุป · อายุที่รอ · ชิปกรอง · ของเดิมครบ (อนุมัติกลุ่ม / SCADA / ยกเลิกค่า)"""
    from datetime import datetime
    _submit(app, db, published_form)                    # ปกติ
    _submit(app, db, published_form, oil="2.45")        # ช่วงเตือน
    sid = db.execute("SELECT id FROM cs_submissions ORDER BY id LIMIT 1").fetchone()[0]
    old = (datetime.now() - timedelta(hours=30)).strftime("%Y-%m-%d %H:%M:%S")
    db.execute("UPDATE cs_submissions SET finished_at=? WHERE id=?", (old, sid))
    db.commit()
    login(client, "t_sup")
    h = client.get("/approvals").get_data(as_text=True)
    assert "dash-luxe lx-page" in h and 'class="lx-hero' in h and h.count('class="kx"') == 6
    assert "รอนานสุด</b> 1 วัน" in h or "รอนานสุด</b> 30 ชม." in h
    assert re.search(r'data-apf="old">\s*<span class="kx-l">รอเกิน 24 ชม.</span>\s*<span class="kx-v"><b class="t-warn" data-count>1</b>', h)
    assert len(re.findall(r'<tr class="ap-row', h)) == 2
    assert re.search(r'data-k="ok old[ "]', h) and re.search(r'data-k="warn', h)
    assert 'id="apQ"' in h and 'data-aps="old"' in h and 'id="apFloat"' in h
    # ของเดิม: ฟอร์มอนุมัติกลุ่ม · ช่องเลือก · ตัวกรองที่มา/NG · แท็บ · กล่องยกเลิกค่า
    for s in ('id="bulk"', 'id="chkAll"', 'id="btnBulk"', 'name="src"', 'name="ng"', 'id="dlgVoid"', "อนุมัติรายสัปดาห์"):
        assert s in h
    assert h.count('class="chk"') == 2
    # อนุมัติกลุ่มทำงานเหมือนเดิม
    tok = re.search(r'name="csrf_token" value="([^"]+)"', h).group(1)
    r = client.post("/approvals/bulk", data={"csrf_token": tok, "ids": [str(sid)]})
    assert r.status_code == 302
    h2 = client.get("/approvals").get_data(as_text=True)
    assert len(re.findall(r'<tr class="ap-row', h2)) == 1 and "อนุมัติแล้ว 1 รายการ" in h2


def test_approvals_empty_state(client, published_form):
    login(client, "t_sup")
    h = client.get("/approvals").get_data(as_text=True)
    assert "ไม่มีรายการรออนุมัติ" in h and "ap-done-ic" in h and 'class="lx-hero' in h
