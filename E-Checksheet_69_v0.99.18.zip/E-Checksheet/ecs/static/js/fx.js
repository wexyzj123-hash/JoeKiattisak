/* v0.99.14 ภาพเคลื่อนไหวทั้งระบบ
   1) เปลี่ยนหน้า: เมนูซ้าย/แถบบนอยู่นิ่ง เนื้อหาเก่าจมลง เนื้อหาใหม่ลอยขึ้นมา (View Transitions ข้ามหน้า · CSS ใน app.css)
      ไฮไลต์เมนูที่เลือกเลื่อนจากเมนูเดิมไปเมนูใหม่ · เบราว์เซอร์ที่ไม่รองรับ: เนื้อหาใหม่ลอยขึ้นตอนโหลด
   2) แถบความคืบหน้าเรืองแสงด้านบนทันทีที่กดเมนู/ลิงก์ (รู้ว่ากำลังไป แม้เซิร์ฟเวอร์ช้า)
   3) หน้าภาพรวม: แผ่นเนื้อหาลอยขึ้นแบบ 3 มิติเมื่อเลื่อนถึง · แสงตามเมาส์บนแผ่นและแถบหัว
   ตั้งค่า "ลดการเคลื่อนไหว" ในเครื่อง → ปิดทั้งหมด */
(function () {
  'use strict';
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = window.matchMedia && window.matchMedia('(pointer: fine)').matches;
  const root = document.documentElement;

  // ── 1) เมนูที่เลือกตั้งชื่อใน base.html (ทันทีหลังเมนูซ้าย) · จับ pagereveal ใน <head> → window.__vt
  function trackVT(vt) {
    if (!vt) { enterFallback(); return; }
    root.dataset.vt = 'run';
    vt.finished.then(() => { root.dataset.vt = 'done'; }, () => { root.dataset.vt = 'skip'; });
  }
  window.addEventListener('pagereveal', (e) => trackVT(e.viewTransition));
  function enterFallback() {
    if (reduce) return;
    const m = document.querySelector('main.page'); if (!m) return;
    m.classList.add('pg-enter');
    m.addEventListener('animationend', () => m.classList.remove('pg-enter'), { once: true });
  }

  // ── 2) แถบความคืบหน้า
  let bar = null;
  function startBar() {
    if (!bar) { bar = document.createElement('div'); bar.className = 'navbar-fx'; bar.setAttribute('aria-hidden', 'true'); document.body.appendChild(bar); }
    bar.classList.remove('done'); void bar.offsetWidth; bar.classList.add('go');
  }
  function stopBar() { if (bar) { bar.classList.remove('go'); bar.classList.add('done'); } }
  window.ECSNav = startBar;      // v0.99.16 ช่องสั่งงานใช้แถบเดียวกันตอนเปิดหน้า
  document.addEventListener('click', (e) => {
    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest && e.target.closest('a[href]'); if (!a) return;
    if (a.target && a.target !== '_self') return;
    if (a.hasAttribute('download') || a.closest('[data-od]') || a.hasAttribute('data-od')) return;
    const href = a.getAttribute('href') || '';
    if (!href || href.charAt(0) === '#' || /^(javascript|mailto|tel):/i.test(href)) return;
    let u; try { u = new URL(a.href, location.href); } catch (err) { return; }
    if (u.origin !== location.origin || (u.pathname === location.pathname && u.search === location.search && u.hash)) return;
    if (/\.(pdf|xlsx|csv|zip|png|jpe?g)$/i.test(u.pathname) || /[?&]format=(xlsx|pdf|csv)/.test(u.search)) return;
    setTimeout(() => { if (!e.defaultPrevented) startBar(); }, 0);
  });
  document.addEventListener('submit', (e) => {
    const f = e.target; if (!f || f.target === '_blank') return;
    setTimeout(() => { if (!e.defaultPrevented && (f.method || 'get').toLowerCase() === 'get') startBar(); }, 0);
  });
  window.addEventListener('pageshow', stopBar);

  // ── 3) หน้าภาพรวม
  function dash() {
    const page = document.querySelector('main.dash-luxe'); if (!page || reduce) return;
    root.classList.add('fx-on');
    const vh = window.innerHeight;
    // v0.99.18 หน้าแนวโน้ม/รายงาน (main.lx-page): แผ่นเนื้อหาระดับบนสุดลอยขึ้นเหมือนกัน
    const sheets = [...page.querySelectorAll('.dgrid > section, .dgrid > .dcard, .fx-sheet, main.lx-page > .dcard, main.lx-page > .card, main.lx-page > .chart-card')]
      .filter((el, i, a) => a.indexOf(el) === i);
    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver((ents) => ents.forEach((en) => {
        if (!en.isIntersecting) return;
        const el = en.target; io.unobserve(el);
        const sib = [...el.parentElement.children].filter((x) => x.classList.contains('fx-wait'));
        el.style.animationDelay = Math.max(0, sib.indexOf(el)) * 90 + 'ms';
        el.classList.remove('fx-wait'); el.classList.add('fx-in');
        el.addEventListener('animationend', () => { el.classList.remove('fx-in'); el.style.animationDelay = ''; }, { once: true });
      }), { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
      sheets.forEach((el) => { if (el.getBoundingClientRect().top > vh * 0.92) { el.classList.add('fx-wait'); io.observe(el); } });
    }
    if (page.classList.contains('lx-page')) countUp(page.querySelectorAll('.lx-hero [data-count]'));
    if (!fine) return;
    const spot = (el) => el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect();
      el.style.setProperty('--mx', (e.clientX - r.left) + 'px'); el.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
    page.querySelectorAll('.dcard, .lx-hero, main.lx-page .card, main.lx-page .chart-card').forEach(spot);
  }
  // ตัวเลขนับขึ้นตอนเปิดหน้า (หน้าภาพรวมใช้ของ drill.js)
  function countUp(nums) {
    const items = [...nums].map((n) => ({ n, txt: n.textContent })).filter((i) => /\d/.test(i.txt));
    if (!items.length) return;
    const t0 = performance.now(), dur = 900;
    const fmt = (s, p) => s.replace(/\d[\d,]*(\.\d+)?/g, (m) => { const dec = (m.split('.')[1] || '').length, v = parseFloat(m.replace(/,/g, '')) * p;
      return dec ? v.toFixed(dec) : Math.round(v).toLocaleString('en-US'); });
    const tick = (t) => { const x = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - x, 3);
      items.forEach((i) => { i.n.textContent = x < 1 ? fmt(i.txt, e) : i.txt; }); if (x < 1) requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  }

  // ── 4) v0.99.15 แผงเวลา HUD: นาฬิกา · กะปัจจุบัน + เวลาที่เหลือ · นับถอยหลังกำหนดส่งรอบถัดไป
  function hud() {
    const h = document.querySelector('[data-hud]'); if (!h) return;
    const starts = (h.dataset.shifts || '480,1200').split(',').map(Number).filter((x) => !isNaN(x)).sort((a, b) => a - b);
    const nxt = h.dataset.next ? new Date(h.dataset.next.replace(' ', 'T')) : null;
    const nN = +h.dataset.nextN || 0;
    const q = (k) => h.querySelector('[data-hud-' + k + ']');
    const p2 = (n) => String(n).padStart(2, '0');
    const dur = (ms) => { const s = Math.max(0, Math.floor(ms / 1000)); const hh = Math.floor(s / 3600), mm = Math.floor(s % 3600 / 60);
      return hh ? hh + ' ชม. ' + p2(mm) + ' น.' : mm + ' น. ' + p2(s % 60) + ' วิ.'; };
    function tick() {
      const now = new Date(), m = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60;
      q('clock').textContent = p2(now.getHours()) + ':' + p2(now.getMinutes()) + ':' + p2(now.getSeconds());
      let st = starts.filter((x) => x <= m).pop(), en;
      if (st === undefined) { st = starts[starts.length - 1] - 1440; en = starts[0]; } else { en = starts.find((x) => x > st); if (en === undefined) en = starts[0] + 1440; }
      const sm = ((st % 1440) + 1440) % 1440, day = starts.length < 2 ? (m >= 360 && m < 1080) : (sm >= 300 && sm < 1020);
      q('shift').textContent = (day ? 'กะกลางวัน ' : 'กะกลางคืน ') + p2(Math.floor(sm / 60)) + ':' + p2(sm % 60);
      const pct = Math.min(100, Math.max(0, (m - st) / (en - st) * 100));
      q('bar').style.width = pct.toFixed(1) + '%';
      q('left').textContent = 'เหลือ ' + dur((en - m) * 60000);
      const nx = q('next');
      if (nxt) {
        const ms = nxt - now;
        nx.textContent = ms > 0 ? 'ส่งรอบถัดไปภายใน ' + dur(ms) + (nN > 1 ? ' · ' + nN + ' รอบ' : '') : 'ถึงกำหนดส่งรอบแล้ว — รีเฟรชเพื่อดูสถานะล่าสุด';
        nx.classList.toggle('soon', ms > 0 && ms < 30 * 60000);
      }
    }
    tick(); setInterval(tick, 1000);
  }

  // ── 5) v0.99.15 คลื่นแสงจากจุดที่กด (ปุ่ม · เมนู · ตัวเลข · แท็บ · ชิป) — ไม่บังการกด
  const RIP = '.btn, .sn-link, .sn-pin, .kx, .ov-tabs > a, .seg > a, .ab-chip, .cl-tabs > button, .appsw > a';
  document.addEventListener('pointerdown', (e) => {
    if (reduce || e.button !== 0) return;
    const t = e.target.closest && e.target.closest(RIP); if (!t) return;
    const r = document.createElement('i'); r.className = 'fx-ripple'; r.setAttribute('aria-hidden', 'true');
    r.style.left = e.clientX + 'px'; r.style.top = e.clientY + 'px';
    if (t.closest('.lx-hero, .sidenav')) r.classList.add('light');
    document.body.appendChild(r); r.addEventListener('animationend', () => r.remove(), { once: true });
  }, { passive: true });

  function init() {
    hud(); dash();
    if (window.__revealed) trackVT(window.__vt);
    else if (!('onpagereveal' in window)) enterFallback();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
