"""ecs/views/review.py — หัวหน้างาน: รออนุมัติ, อนุมัติ/ตีกลับ, ประวัติผลตรวจ"""
from __future__ import annotations

from flask import Blueprint, abort, current_app, flash, redirect, render_template, request, session, url_for

from .. import cmms_tpm as TPM
from .. import masterdata as M
from .. import services as S
from .. import submissions as SUB
from ..db import get_db
from ..security import ALL_ROLES, MANAGE_ROLES, current_user_id, require_role

bp = Blueprint("review", __name__)
PAGE_SIZE = 50


def _int(v):
    try:
        return int(v or 0) or None
    except ValueError:
        return None


def _scope_factory() -> int | None:
    """หัวหน้างานที่ผูกโรงงาน เห็นเฉพาะโรงงานตัวเอง"""
    if session.get("role") != "admin" and session.get("factory_id"):      # v0.38 รวมผู้อนุมัติตามตำแหน่งที่ผูกโรงงาน
        return session["factory_id"]
    return None


def _need_approver(db) -> None:
    """v0.38 หัวหน้างาน/ผู้ดูแลระบบ หรือผู้มีสิทธิ์อนุมัติ (ติ๊กสิทธิ์ / ตำแหน่ง Sr.Tech · FM · SV · SSV · DM)"""
    if not SUB.can_approve(db, current_user_id()):
        abort(403)


@bp.route("/approvals")
@require_role(*ALL_ROLES)
def approvals():
    db = get_db()
    _need_approver(db)
    only_ng = request.args.get("ng") == "1"
    src = request.args.get("src") if request.args.get("src") in ("auto", "manual") else None
    factory_id = _scope_factory() or _int(request.args.get("factory"))
    rows, total = SUB.list_submissions(db, factory_id=factory_id, approval="pending", only_ng=only_ng, limit=200, source=src)
    rows = [r for r in rows if r["status"] == "submitted"]
    auto = SUB.auto_pending(db, factory_id)                  # v0.45 ค่าอัตโนมัติจาก SCADA รอยืนยัน
    # v0.99.18 แดชบอร์ดรออนุมัติ: อายุที่รอ (ชม.) ต่อรายการ + ตัวเลขสรุปสำหรับแถบหัว
    from datetime import datetime as _dt
    now = _dt.now()
    rows = [dict(r) for r in rows]
    for r in rows:
        try:
            r["age_h"] = max(0.0, (now - _dt.fromisoformat(str(r["finished_at"])[:19])).total_seconds() / 3600)
        except (TypeError, ValueError):
            r["age_h"] = None
    ages = [r["age_h"] for r in rows if r["age_h"] is not None]
    st = {"n": len(rows), "ok": sum(1 for r in rows if not r["ng_count"]), "ng": sum(1 for r in rows if r["ng_count"]),
          "warn": sum(1 for r in rows if r.get("warn_count") and not r["ng_count"]),
          "auto": sum(1 for r in rows if r.get("source") == "auto"),
          "fast": sum(1 for r in rows if r.get("duration_sec") is not None and r["duration_sec"] < 30 and r.get("source") != "auto"),
          "late": sum(1 for r in rows if r.get("round_status") == "done_late"),
          "old": max(ages) if ages else None, "over24": sum(1 for a in ages if a >= 24)}
    return render_template("review/approvals.html", rows=rows, total=total, only_ng=only_ng, src=src, auto=auto,
                           factory_id=factory_id, factories=M.list_factories(db),
                           locked_factory=bool(_scope_factory()), st=st, now=now)


@bp.route("/approvals/auto", methods=["POST"])
@require_role(*ALL_ROLES)
def approvals_auto():
    """v0.45 ยืนยันค่าอัตโนมัติจาก SCADA ที่ปกติทั้งหมด (ในโรงงานที่รับผิดชอบ) — ค่า NG ต้องเปิดดูทีละรายการ"""
    db = get_db()
    _need_approver(db)
    factory_id = _scope_factory() or _int(request.form.get("factory"))
    ids = SUB.auto_pending(db, factory_id)["ok_ids"]
    res = SUB.bulk_approve_ok(db, ids, current_user_id(), note="ยืนยันค่าอัตโนมัติจาก SCADA")
    db.commit()
    flash(f"ยืนยันค่าจาก SCADA แล้ว {res['approved']} รายการ" + (f" · ข้าม {res['skipped']}" if res["skipped"] else ""), "ok")
    return redirect(url_for("review.approvals", src="auto"))


@bp.route("/approvals/auto-void", methods=["POST"])
@require_role(*ALL_ROLES)
def approvals_auto_void():
    """v0.74 ยกเลิกค่าอัตโนมัติจาก SCADA (เอาออกจากใบตรวจ/รายงาน · ไม่ลงซ้ำเมื่อดึงข้อมูลใหม่)"""
    from .. import srcmap as SM
    db = get_db()
    _need_approver(db)
    sub_id = _int(request.form.get("sub_id"))
    try:
        SM.void_submission(db, sub_id or 0, request.form.get("reason", ""), current_user_id())
        db.commit()
        flash("ยกเลิกค่าจาก SCADA แล้ว — เอาออกจากใบตรวจ/รายงาน และระบบจะไม่ลงซ้ำ", "ok")
    except S.ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    nxt = request.form.get("next") or ""
    return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("review.approvals", src="auto"))


@bp.route("/approvals/bulk", methods=["POST"])
@require_role(*ALL_ROLES)
def approvals_bulk():
    db = get_db()
    _need_approver(db)
    ids = [int(x) for x in request.form.getlist("ids") if x.isdigit()]
    res = SUB.bulk_approve_ok(db, ids, current_user_id())
    db.commit()
    n_tpm = TPM.safe(TPM.on_approve, db, current_app.config, ids, current_user_id())
    msg = f"อนุมัติแล้ว {res['approved']} รายการ"
    if res["skipped"]:
        msg += f" · ข้าม {res['skipped']} รายการ (มี NG หรืออยู่นอกความรับผิดชอบ — ต้องเปิดดูทีละรายการ)"
    if n_tpm:
        msg += f" · ยืนยันแผน TPM ใน UT-CMMS {n_tpm} แผน"
    flash(msg, "ok")
    return redirect(url_for("review.approvals"))


# ───────────────────────── v0.26 อนุมัติแบบกลุ่ม (แบบฟอร์ม × สัปดาห์) ─────────────────────────

def _group_month():
    from datetime import date
    try:
        y, m = (int(x) for x in (request.values.get("month") or "").split("-"))
        return date(y, m, 1)
    except (TypeError, ValueError):
        return date.today().replace(day=1)


def _week_groups(db, month, factory_id):
    """[{form, start, end, label, total, approved, pending, pending_ng, returned, ids}] ของเดือน"""
    from .. import signoffs as SO
    last = SO._last_day(month)
    a, b = f"{month:%Y-%m}-01 00:00:00", f"{month:%Y-%m}-{last:02d} 23:59:59"
    from ..view_scope import sql as _vs_sql                  # v0.29 บัญชีที่ถูกจำกัดการดู
    vs, vp = _vs_sql("s.form_id")
    rows = db.execute(f"""SELECT s.id, s.form_id, s.finished_at, s.status, s.approval_status, s.ng_count,
                                f.code, f.name, f.factory_id, fa.name AS factory_name, e.code AS eq_code
                         FROM cs_submissions s JOIN cs_forms f ON f.id=s.form_id
                         LEFT JOIN factories fa ON fa.id=f.factory_id LEFT JOIN equipment e ON e.id=f.equipment_id
                         WHERE s.status IN ('submitted','returned') AND s.finished_at BETWEEN ? AND ?
                           AND (? IS NULL OR f.factory_id=?){vs} ORDER BY f.code, f.name, s.finished_at""",
                      (a, b, factory_id, factory_id, *vp)).fetchall()
    recs = SO.records_all(db, month)
    groups: dict = {}
    from .. import sign_blocks as SB
    seg_cache: dict = {}
    for r in rows:
        d = S.parse_ts(r["finished_at"])
        if r["form_id"] not in seg_cache:                    # v0.37 ช่วงตามความยาวช่องหัวหน้างานของแบบฟอร์ม
            f = S.get_form(db, r["form_id"])
            seg_cache[r["form_id"]] = SB.sup_segments(db, f, month, last) if f else SB.week_segments(month, last)
        sg = next(x for x in seg_cache[r["form_id"]] if x["start"] <= d.day < x["start"] + x["span"])
        g = groups.setdefault((r["form_id"], sg["start"]), {
            "form_id": r["form_id"], "code": r["code"], "name": r["name"], "factory_name": r["factory_name"],
            "eq_code": r["eq_code"], "start": sg["start"], "end": sg["start"] + sg["span"] - 1,
            "total": 0, "approved": 0, "pending": 0, "pending_ng": 0, "returned": 0, "ids": [], "ng_ids": [],
            "so": recs.get(r["form_id"], {}).get(f"row:sup:{sg['start']}")})
        g["total"] += 1
        if r["approval_status"] == "approved":
            g["approved"] += 1
        elif r["status"] == "returned":
            g["returned"] += 1
        else:
            g["pending"] += 1
            (g["ng_ids"] if r["ng_count"] else g["ids"]).append(r["id"])
            g["pending_ng"] += 1 if r["ng_count"] else 0
    return sorted(groups.values(), key=lambda g: (-(g["pending"] > 0), g["code"] or "", g["start"]))


@bp.route("/approvals/group", methods=["GET", "POST"])
@require_role(*ALL_ROLES)
def approvals_group():
    """อนุมัติผลตรวจทั้งสัปดาห์ในคลิกเดียว — หัวหน้างาน/ผู้ดูแลระบบ หรือผู้ที่ผู้ดูแลระบบให้สิทธิ์อนุมัติ
    อนุมัติครบทั้งสัปดาห์ → แถว "หัวหน้างาน (Sr.Tech)" ในใบบันทึกเติมลายเซ็นผู้อนุมัติอัตโนมัติ"""
    db = get_db()
    uid = current_user_id()
    if not SUB.can_approve(db, uid):
        abort(403)
    me = SUB.user_scope(db, uid)
    month = _group_month()
    locked = me["role"] != "admin" and me.get("factory_id")
    factory_id = me["factory_id"] if locked else _int(request.values.get("factory"))
    if request.method == "POST":
        with_ng = request.form.get("with_ng") == "1"
        keys = set(request.form.getlist("grp"))
        ids = []
        for g in _week_groups(db, month, factory_id):
            if f"{g['form_id']}|{g['start']}" in keys:
                ids += g["ids"] + (g["ng_ids"] if with_ng else [])
        done, errs = 0, []
        for sid in ids:
            try:
                SUB.approve(db, sid, uid, "อนุมัติแบบกลุ่มรายสัปดาห์" + (" (รวมรายการ NG)" if with_ng else ""))
                done += 1
            except S.ValidationError as exc:
                errs.append(exc.errors[0])
        db.commit()
        n_tpm = TPM.safe(TPM.on_approve, db, current_app.config, ids, uid) if ids else 0
        flash(f"อนุมัติแล้ว {done} รายการ" + (f" · ยืนยันแผน TPM {n_tpm} แผน" if n_tpm else "")
              + (f" · ไม่สำเร็จ {len(errs)} รายการ: {errs[0]}" if errs else ""), "ok" if not errs else "error")
        return redirect(url_for("review.approvals_group", month=f"{month:%Y-%m}", factory=factory_id or None))
    from datetime import timedelta
    from .. import sheet_report as SR
    groups = _week_groups(db, month, factory_id)
    prev = (month - timedelta(days=1)).replace(day=1)
    nxt = (month.replace(day=28) + timedelta(days=4)).replace(day=1)
    return render_template("review/group.html", groups=groups, month=month, month_th=SR.th_month(month), prev=prev,
                           next_m=nxt if nxt <= S.now_dt().date().replace(day=1) else None, factory_id=factory_id,
                           locked_factory=bool(locked), factories=M.list_factories(db))


@bp.route("/submissions")
@require_role(*ALL_ROLES)
def submissions():
    db = get_db()
    page = max(1, _int(request.args.get("page")) or 1)
    f = {
        "factory_id": _scope_factory() or _int(request.args.get("factory")),
        "form_id": _int(request.args.get("form")),
        "equipment_id": _int(request.args.get("equipment")),
        "approval": request.args.get("approval") or None,
        "only_ng": request.args.get("ng") == "1",
        "date_from": request.args.get("from") or None,
        "date_to": request.args.get("to") or None,
    }
    if session.get("role") == "technician" and request.args.get("mine") == "1":
        f["inspector_id"] = current_user_id()
    rows, total = SUB.list_submissions(db, **f, limit=PAGE_SIZE, offset=(page - 1) * PAGE_SIZE)
    return render_template("review/submissions.html", rows=rows, total=total, page=page, page_size=PAGE_SIZE,
                           can_delete=SUB.can_delete_results(db, current_user_id()), filters=f, factories=M.list_factories(db), forms=S.list_forms(db, include_inactive=True),
                           args=request.args)


@bp.route("/submissions/<int:sub_id>")
@require_role(*ALL_ROLES)
def submission_detail(sub_id):
    db = get_db()
    sub = SUB.get_submission(db, sub_id)
    if not sub:
        abort(404)
    scope = _scope_factory()
    can_review = (SUB.can_approve(db, current_user_id()) and sub["status"] == "submitted"
                  and (not scope or sub["factory_id"] in (None, scope)))
    from .. import cmms_wo as W
    from .. import srcmap as SM
    auto_slot = SM.parse_uuid(sub.get("client_uuid") or "") if sub.get("source") == "auto" else None
    return render_template("review/detail.html", sub=sub, can_review=can_review, auto_slot=auto_slot,
                           can_fix=bool(auto_slot) and SUB.can_approve(db, current_user_id()),
                           can_delete=SUB.can_delete_results(db, current_user_id()),
                           wo_links=W.links_for_submission(db, sub_id),
                           can_wo=(session.get("role") in MANAGE_ROLES + ("technician",) and sub["ng_count"]
                                   and W.available(current_app.config)),
                           tpm_sync=TPM.sync_for_submission(db, sub_id),
                           can_tpm=(session.get("role") in MANAGE_ROLES and sub["status"] == "submitted"
                                    and TPM.available(current_app.config) and TPM.get_settings(db)["enabled"]
                                    and bool(TPM.form_links(db, sub["form_id"]))))


@bp.route("/submissions/<int:sub_id>/tpm", methods=["POST"])
@require_role(*MANAGE_ROLES)
def submission_tpm(sub_id):
    """บันทึกทำงานแผน TPM จากผลตรวจนี้ (กดเอง — เช่น ผลตรวจที่ส่งก่อนเชื่อมแผน)"""
    db = get_db()
    try:
        res = TPM.record_submission(db, current_app.config, sub_id,
                                    base_url=request.host_url.rstrip("/") + request.script_root)
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return redirect(url_for("review.submission_detail", sub_id=sub_id))
    if res:
        sub = SUB.get_submission(db, sub_id)
        if sub and sub["approval_status"] == "approved":
            TPM.safe(TPM.on_approve, db, current_app.config, [sub_id], current_user_id())
        flash("บันทึกทำงานแผน TPM แล้ว: " + ", ".join(r["task"] for r in res), "ok")
    else:
        flash("ไม่มีแผน TPM ที่ถึงช่วงทำ (หรือบันทึกไปแล้ว / หัวข้อที่กำหนดยังตรวจไม่ครบ)", "error")
    return redirect(url_for("review.submission_detail", sub_id=sub_id))


@bp.route("/submissions/<int:sub_id>/cmms-wo", methods=["POST"])
@require_role(*ALL_ROLES)
def submission_cmms_wo(sub_id):
    """เปิดใบแจ้งซ่อม UT-CMMS จากผลตรวจ NG (กดเอง)"""
    from .. import cmms_wo as W
    if session.get("role") not in MANAGE_ROLES + ("technician",):
        abort(403)
    db = get_db()
    try:
        res = W.create_for_submission(db, current_app.config, sub_id, current_user_id(), manual=True,
                                      base_url=request.host_url.rstrip("/") + request.script_root)
        db.commit()
        if not res:
            flash("ผลตรวจนี้เปิดใบแจ้งซ่อมไปแล้ว", "ok")
        elif res["repeat"]:
            flash(f"หัวข้อนี้มีใบแจ้งซ่อม {res['wo_number']} ค้างอยู่แล้ว — เพิ่มบันทึก 'พบ NG ซ้ำ' ในใบเดิม", "ok")
        else:
            flash(f"เปิดใบแจ้งซ่อม {res['wo_number']} ใน UT-CMMS แล้ว" + (f" (แนบรูป {res['photos']} รูป)" if res.get("photos") else ""), "ok")
    except S.ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
    return redirect(url_for("review.submission_detail", sub_id=sub_id))


def _do_delete(ids: list[int]) -> int:
    db = get_db()
    try:
        res = SUB.delete_submissions(db, ids, current_user_id(), request.form.get("reason", ""))
        db.commit()
    except S.ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return -1
    SUB.trash_photos(current_app.config["UPLOAD_FOLDER"], res["photos"])
    TPM.safe(TPM.on_reject, db, current_app.config, ids, "ลบผลตรวจ: " + request.form.get("reason", ""),
             state="cancelled", actor_id=current_user_id())
    flash(f"ลบผลตรวจแล้ว {res['deleted']} รายการ (บันทึกใน Audit Trail) — รอบตรวจที่เกี่ยวข้องกลับเป็นยังไม่ตรวจ/ขาดตรวจ", "ok")
    return res["deleted"]


@bp.route("/submissions/<int:sub_id>/delete", methods=["POST"])
@require_role(*ALL_ROLES)
def submission_delete(sub_id):
    if _do_delete([sub_id]) < 0:
        return redirect(url_for("review.submission_detail", sub_id=sub_id))
    return redirect(_back_to_list())


@bp.route("/submissions/delete", methods=["POST"])
@require_role(*ALL_ROLES)
def submissions_delete():
    ids = [int(x) for x in request.form.getlist("ids") if x.isdigit()]
    _do_delete(ids)
    return redirect(_back_to_list())


def _back_to_list() -> str:
    """กลับหน้ารายการผลตรวจพร้อมตัวกรองเดิม (รับเฉพาะ query string — กัน open redirect)"""
    qs = (request.form.get("qs") or "").lstrip("?")
    return url_for("review.submissions") + ("?" + qs if qs and "//" not in qs and "\n" not in qs else "")


@bp.route("/submissions/<int:sub_id>/approve", methods=["POST"])
@require_role(*ALL_ROLES)
def submission_approve(sub_id):
    db = get_db()
    _need_approver(db)
    try:
        SUB.approve(db, sub_id, current_user_id(), request.form.get("note", ""))
        db.commit()
        n_tpm = TPM.safe(TPM.on_approve, db, current_app.config, [sub_id], current_user_id())
        flash("อนุมัติผลตรวจแล้ว" + (f" · ยืนยันแผน TPM ใน UT-CMMS {n_tpm} แผน (คำนวณกำหนดครั้งถัดไปแล้ว)" if n_tpm else ""), "ok")
    except S.ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return redirect(url_for("review.submission_detail", sub_id=sub_id))
    return redirect(_next_pending(db, sub_id))


@bp.route("/submissions/<int:sub_id>/return", methods=["POST"])
@require_role(*ALL_ROLES)
def submission_return(sub_id):
    db = get_db()
    _need_approver(db)
    try:
        SUB.return_submission(db, sub_id, current_user_id(), request.form.get("note", ""))
        db.commit()
        TPM.safe(TPM.on_reject, db, current_app.config, [sub_id], request.form.get("note", ""),
                 actor_id=current_user_id())
        flash("ตีกลับแล้ว ผู้ตรวจจะเห็นในหน้า 'งานของฉัน' พร้อมเหตุผล", "ok")
    except S.ValidationError as exc:
        db.rollback()
        flash(exc.errors[0], "error")
        return redirect(url_for("review.submission_detail", sub_id=sub_id))
    return redirect(_next_pending(db, sub_id))


def _next_pending(db, after_id: int) -> str:
    """หลังอนุมัติ/ตีกลับ ไปยังรายการถัดไปที่รออนุมัติ (ทำงานต่อเนื่องได้ไว)"""
    rows, _ = SUB.list_submissions(db, factory_id=_scope_factory(), approval="pending", limit=1)
    rows = [r for r in rows if r["id"] != after_id and r["status"] == "submitted"]
    return url_for("review.submission_detail", sub_id=rows[0]["id"]) if rows else url_for("review.approvals")
