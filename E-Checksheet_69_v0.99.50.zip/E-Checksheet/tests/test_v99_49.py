"""v0.99.49: หน้าภาพรวมพลังงานแบบ Pro — ตัวกรอง Project / หน่วยงาน / ไลน์ · เจาะลึกทีละระดับ · ทุกตัวเลขลิงก์ไปข้อมูลต้นทาง"""
from datetime import datetime, timedelta

from conftest import login

from ecs import energy as EN
from ecs import energy_interval as EI
from ecs import energy_overview as OV
from ecs import services as S


def _plant(app, db):
    """F2: Press (L1 1.0 · L2 0.5 ต่อช่อง) · Paint 2.0 — วันก่อนหน้า L1 0.9 · L2 0.5 · Paint 1.0 (Paint ใช้เพิ่ม 100%)"""
    EI.ensure(db)
    f2 = app.config["F2"]
    a = EN.save_meter(db, None, {"factory_id": f2, "kind": "elec", "code": "PA1", "name": "Press L1", "grp": "Press", "line": "L1"}, None)
    b = EN.save_meter(db, None, {"factory_id": f2, "kind": "elec", "code": "PA2", "name": "Press L2", "grp": "Press", "line": "L2"}, None)
    c = EN.save_meter(db, None, {"factory_id": f2, "kind": "elec", "code": "PT1", "name": "Paint booth", "grp": "Paint", "line": ""}, None)
    day = S.now_dt().date() - timedelta(days=1)
    for d, vals in ((day, {a: 1.0, b: 0.5, c: 2.0}), (day - timedelta(days=1), {a: 0.9, b: 0.5, c: 1.0})):
        t0 = datetime.combine(d, datetime.min.time())
        for i in range(96):
            for mid, v in vals.items():
                db.execute("INSERT INTO en_intervals(meter_id, ts, value) VALUES (?,?,?)", (mid, S.ts(t0 + timedelta(minutes=15 * i)), v))
    db.commit()
    return f2, day, a, b, c


def test_build_levels_kpis_tracker(app, db):
    f2, day, a, _b, c = _plant(app, db)
    O = OV.build(db, day, f2)
    assert O["level"] == "grp" and O["level_th"] == "หน่วยงาน"                       # ไม่มี Project → ข้ามไปหน่วยงาน
    K = O["kpis"]
    assert abs(K["kwh"]["value"] - 336) < 1e-6 and abs(K["kwh"]["cmp"] - 230.4) < 1e-6 and K["kwh"]["pct"] == round(100 * (336 - 230.4) / 230.4, 1)
    assert abs(K["kw"]["value"] - 3.5 * 4) < 1e-6                                  # ช่องสุดท้าย 3.5 kWh/15 นาที = 14 kW
    assert K["baht"]["value"] > 0 and K["co2"]["value"] > 0
    top = {r["name"]: r for r in O["top"]}
    assert [r["name"] for r in O["top"]] == ["Paint", "Press"] and top["Paint"]["sum"] == 192 and top["Press"]["sum"] == 144
    assert top["Paint"]["st"] == "w" and top["Paint"]["chg"] == 100.0 and top["Press"]["st"] == "n"
    assert top["Press"]["q"] == {"grp": "Press"}
    trk = {t["name"]: t for t in O["tracker"]}
    assert all(x["st"] == "c" for x in trk["Paint"]["cells"]) and trk["Press"]["ok"] == 24     # ไม่ใช่วันนี้ → ไม่มีช่องอนาคต
    assert O["hourly"]["peak_v"] == 14 and len(O["hourly"]["today"]) == 24 and O["hourly"]["diff"] > 0
    assert O["health"]["n"] == 3 and O["health"]["n_data"] == 3 and O["health"]["pct"] == 100
    assert len(O["flow"]["nodes"]) == 2 and O["flow"]["nodes"][0]["w"] > O["flow"]["nodes"][1]["w"]
    # เจาะลึก: หน่วยงาน → ไลน์ → มิเตอร์
    P = OV.build(db, day, f2, grp="Press")
    assert P["level"] == "line" and {r["name"] for r in P["top"]} == {"L1", "L2"} and abs(P["kpis"]["kwh"]["value"] - 144) < 1e-6
    L = OV.build(db, day, f2, grp="Press", line="L1")
    assert L["level"] == "meter" and L["top"][0]["meter_id"] == a
    U = OV.build(db, day, f2, grp="Paint")                                           # ไลน์เดียว (ไม่ระบุ) → ข้ามไปมิเตอร์
    assert U["level"] == "meter" and U["top"][0]["meter_id"] == c


def test_overview_page_filters_and_links(app, db, client):
    f2, day, a, _b, _c = _plant(app, db)
    login(client, "t_admin")
    html = client.get(f"/energy/overview?factory={f2}&day={day.isoformat()}").get_data(as_text=True)
    for x in ("ภาพรวมพลังงาน", "ไฟฟ้ากำลังไหลไปที่ไหน", "หน่วยงานที่ใช้มากที่สุด", "ทั้งวัน ทีละชั่วโมง", "สถานะรายชั่วโมง", "ส่งข้อมูล",
              'name="project"', 'name="grp"', 'name="line"', 'name="day"', "ovHour"):
        assert x in html, x
    assert f"/energy/live/?factory={f2}&amp;day={day.isoformat()}" in html                       # ตัวเลขใช้ไฟ → ข้อมูลราย 15 นาที (ต้นทาง)
    assert "grp=Press" in html and "/energy/dept?" in html                                      # เจาะหน่วยงาน + Scorecard
    assert "/energy/power" in html and "/energy/cost/" in html and "/energy/sources" in html
    sub = client.get(f"/energy/overview?factory={f2}&grp=Press&day={day.isoformat()}").get_data(as_text=True)
    assert "ไลน์ที่ใช้มากที่สุด" in sub and "L1" in sub and "L2" in sub and "ล้างตัวกรอง" in sub
    r = client.get(f"/energy/overview?factory={f2}&grp=Press&line=L1&meter={a}&day={day.isoformat()}")
    assert r.status_code == 302 and f"/energy/meters/{a}" in r.headers["Location"]
    j = client.get(f"/energy/overview.json?factory={f2}&day={day.isoformat()}").get_json()
    assert j["kwh"] == 336.0 and j["groups"][0]["name"] == "Paint" and j["groups"][0]["state"] == "w" and len(j["hourly"]) == 24
    empty = client.get(f"/energy/overview?factory={f2}&grp=NoSuchSection").get_data(as_text=True)
    assert "ไม่มีมิเตอร์ไฟฟ้าในขอบเขตนี้" in empty
    today = client.get(f"/energy/overview?factory={f2}").get_data(as_text=True)                # วันนี้ยังไม่มีข้อมูลราย 15 นาที
    assert "ยังไม่มีข้อมูลราย 15 นาทีของวันนี้" in today and "LIVE" in today


def test_overview_remembers_filters_menu_and_scope(app, db, client):
    f2, _day, *_ = _plant(app, db)
    login(client, "t_view")
    client.get(f"/energy/overview?factory={f2}&grp=Press")
    r = client.get("/energy/overview")
    assert r.status_code == 302 and "grp=Press" in r.headers["Location"]                      # จำตัวกรองล่าสุด
    page = client.get(r.headers["Location"]).get_data(as_text=True)
    assert 'href="/energy/overview"' in page and "ภาพรวมรายเดือน" in page                     # เมนู: ภาพรวมใหม่ + แบบเดิมยังอยู่
    assert client.get("/energy/").status_code in (200, 302)                                    # หน้าเดิมยังใช้ได้
    login(client, "t_sup")                                                                     # หัวหน้างานที่จำกัดโรงงาน F1
    html = client.get(f"/energy/overview?factory={f2}").get_data(as_text=True)
    assert 'aria-label="เลือกโรงงาน"' not in html
