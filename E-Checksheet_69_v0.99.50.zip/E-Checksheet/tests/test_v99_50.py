"""v0.99.50: ความถูกต้องของข้อมูล — กระทบยอด 2 แหล่ง · ผังมิเตอร์แม่–ลูก · ค่าไฟตาม TOU จริง + Ft + VAT · ค่าปรับ PF · งบรายเดือน"""
from datetime import date, datetime, timedelta

import pytest
from conftest import login

from ecs import energy as EN
from ecs import energy_bill as BL
from ecs import energy_interval as EI
from ecs import energy_power as PW
from ecs import energy_recon as RC
from ecs import services as S
from ecs.services import ValidationError


def _rd(db, mid, day, v):
    db.execute("INSERT OR REPLACE INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,?,?)", (mid, day.isoformat(), v, "manual", S.ts()))


def _iv(db, mid, day, per_slot):
    t0 = datetime.combine(day, datetime.min.time())
    for i in range(96):
        db.execute("INSERT OR REPLACE INTO en_intervals(meter_id, ts, value) VALUES (?,?,?)", (mid, S.ts(t0 + timedelta(minutes=15 * i)), per_slot))


def _m(db, f, code, **kw):
    return EN.save_meter(db, None, {"factory_id": f, "kind": "elec", "code": code, "name": code, **kw}, None)


def _daily(db, mid, d0, d1, per_day):
    v = 1000.0
    d = d0 - timedelta(days=1)
    while d <= d1:
        _rd(db, mid, d, v)
        v += per_day
        d += timedelta(days=1)


def test_reconcile_statuses(app, db):
    EI.ensure(db)
    f2 = app.config["F2"]
    today = S.now_dt().date()
    d0, d1 = today - timedelta(days=4), today - timedelta(days=1)
    ok, ct, only_r, only_i = (_m(db, f2, c) for c in ("OK1", "CT2", "RD1", "IV1"))
    for mid in (ok, ct, only_r):
        _daily(db, mid, d0, d1 + timedelta(days=1), 96.0)
    db.commit()
    ser = EN.series(db, [m for m in EN.meters(db, f2, "elec") if m["id"] in (ok, ct)], d0, d1)
    for mid, mul in ((ok, 1.0), (ct, 2.0)):
        for d, x in ser[mid].items():
            if x.get("u") is not None:
                _iv(db, mid, date.fromisoformat(d), x["u"] / 96 * mul)
    for i in range(4):
        _iv(db, only_i, d0 + timedelta(days=i), 0.5)
    db.commit()
    R = RC.reconcile(db, f2, "elec", d0, d1)
    st = {r["id"]: r for r in R["rows"]}
    assert st[ok]["st"] == "ok" and abs(st[ok]["pct"]) <= 0.1 and st[ok]["days_both"] >= 3
    assert st[ct]["st"] == "bad" and abs(st[ct]["pct"] - 100) < 0.5                     # ตัวคูณ CT ×2
    assert st[only_r]["st"] == "only_r" and st[only_i]["st"] == "only_i"
    assert R["rows"][0]["id"] == ct and R["cnt"]["bad"] == 1 and R["cnt"]["ok"] == 1     # ต่างมากขึ้นก่อน
    assert len(st[ok]["per_day"]) == 4 and R["facs"][0]["n_bad"] == 1


def test_meter_tree_balance(app, db):
    f2 = app.config["F2"]
    today = S.now_dt().date()
    d0, d1 = today - timedelta(days=5), today - timedelta(days=1)
    main = _m(db, f2, "MAIN", is_main="1")
    a = _m(db, f2, "SA", grp="Press")
    b = _m(db, f2, "SB", grp="Paint")
    for mid, per in ((main, 100.0), (a, 40.0), (b, 30.0)):
        _daily(db, mid, d0, d1 + timedelta(days=1), per)
    db.commit()
    T = RC.tree(db, f2, "elec", d0, d1)
    root = T["nodes"][0]
    assert root["id"] == main and {k["id"] for k in root["kids"]} == {a, b}
    assert root["pct"] == 30.0 and root["flag"] == "loss" and T["n_loss"] == 1 and T["unmeasured"] == root["gap"] > 0
    db.execute("DELETE FROM en_readings WHERE meter_id=?", (main,))
    _daily(db, main, d0, d1 + timedelta(days=1), 60.0)                                   # แม่ < ลูกรวม → ตั้งค่าผิด
    db.commit()
    T2 = RC.tree(db, f2, "elec", d0, d1)
    assert T2["nodes"][0]["flag"] == "over" and T2["n_over"] == 1


def test_tou_day_cost_ft_vat_and_pf():
    cfg = dict(PW.DEFAULT_TARIFF)
    cfg.update({"ft": 0.2, "vat": 7.0})
    day = date(2026, 11, 11)                                                             # วันพุธ
    c = BL.slot_cost(cfg, [1.0] * 96, day, {})
    assert c["on"] == 52 and c["off"] == 44                                              # On-Peak 09:00–22:00 = 52 ช่อง
    energy = 52 * cfg["on_rate"] + 44 * cfg["off_rate"]
    assert abs(c["energy"] - energy) < 1e-9 and abs(c["ft"] - 96 * 0.2) < 1e-9
    assert abs(c["total"] - (energy + 96 * 0.2) * 1.07) < 1e-6
    we = BL.slot_cost(cfg, [1.0] * 96, date(2026, 11, 14), {})                            # เสาร์ = Off-Peak ทั้งวัน
    assert we["on"] == 0 and we["off"] == 96
    hol = BL.slot_cost(cfg, [1.0] * 96, day, {day.isoformat(): "holiday"})
    assert hol["on"] == 0
    flat = BL.slot_cost({**cfg, "tou": 0}, [1.0] * 96, day, {})
    assert abs(flat["energy"] - 96 * cfg["flat_rate"]) < 1e-9
    assert BL.pf_charge(cfg, 100, None) is None and BL.pf_charge(cfg, 100, 50) == 0.0
    assert abs(BL.pf_charge(cfg, 100, 100) - (100 - 61.97) * cfg["kvar_rate"]) < 1e-6


def test_budget_and_pf_in_bill_estimate(app, db):
    EI.ensure(db)
    PW.ensure(db)
    f2 = app.config["F2"]
    n = BL.save_budget_year(db, f2, 2026, {1: "1,000,000", 2: "", 11: "900000"}, None)
    db.commit()
    assert n == 2 and BL.budget(db, f2, date(2026, 11, 1)) == 900000 and BL.budget_year(db, f2, 2026) == {1: 1000000.0, 11: 900000.0}
    with pytest.raises(ValidationError):
        BL.save_budget_year(db, f2, 2026, {3: "abc"}, None)
    with pytest.raises(ValidationError):
        BL.save_budget_year(db, None, 2026, {3: "1"}, None)
    # ค่าปรับ PF เข้าประมาณบิลเมื่อมี Tag kVAR
    today = S.now_dt().date()
    m = _m(db, f2, "PFM")
    d = today - timedelta(days=1) if today.day > 1 else today
    _daily(db, m, d - timedelta(days=1), today, 2400.0)
    _iv(db, m, d, 25.0)                                                                  # 100 kW
    db.execute("INSERT INTO en_param_tags(meter_id, param, tag) VALUES (?,?,?)", (m, "kvar", "KVAR1"))
    db.execute("INSERT INTO en_params(meter_id, param, ts, value) VALUES (?,?,?,?)", (m, "kvar", S.ts(datetime.combine(d, datetime.min.time()) + timedelta(hours=10)), 90.0))
    db.commit()
    t = PW.tou(db, f2, d.replace(day=1), today)
    assert t["est"]["kvar"] == 90.0 and t["est"]["pf"] == round((90 - 0.6197 * 100) * PW.DEFAULT_TARIFF["kvar_rate"])
    BL._CACHE.clear()
    M = BL.month_status(db, [f2], d.replace(day=1), today)
    assert M["rows"][0]["pf"] == t["est"]["pf"] and M["mtd"] == t["est"]["total"] and M["forecast"] is None or M["forecast"] >= M["mtd"] * 0.99


def test_pages(app, db, client):
    EI.ensure(db)
    f2 = app.config["F2"]
    today = S.now_dt().date()
    d1 = today - timedelta(days=1)
    m = _m(db, f2, "PG1", grp="Press")
    w = EN.save_meter(db, None, {"factory_id": f2, "kind": "water", "code": "W1", "name": "Water main"}, None)
    _daily(db, m, d1 - timedelta(days=3), today, 96.0)
    _iv(db, m, d1, 1.0)
    _iv(db, w, d1, 0.2)
    db.commit()
    login(client, "t_view")
    r = client.get(f"/energy/reconcile?factory={f2}").get_data(as_text=True)
    assert "กระทบยอดข้อมูล" in r and "PG1" in r and "ตรงกัน" in r
    assert client.get(f"/energy/reconcile?factory={f2}&format=csv").status_code == 200
    t = client.get(f"/energy/tree?factory={f2}").get_data(as_text=True)
    assert "ผังมิเตอร์แม่–ลูก" in t and "PG1" in t
    ov = client.get(f"/energy/overview?factory={f2}&day={d1.isoformat()}").get_data(as_text=True)
    assert "TOU จริง" in ov and "ค่าไฟเดือนนี้" in ov and "ประเภทพลังงาน" in ov
    wv = client.get(f"/energy/overview?factory={f2}&kind=water&day={d1.isoformat()}").get_data(as_text=True)
    assert "ใช้น้ำ" in wv and "ค่าไฟเดือนนี้" not in wv
    j = client.get(f"/energy/overview/month.json?factory={f2}").get_json()
    assert "mtd" in j and "time_pct" in j
    menu = client.get("/energy/overview", follow_redirects=True).get_data(as_text=True)
    assert 'href="/energy/reconcile"' in menu and 'href="/energy/tree"' in menu
    tok = login(client, "t_admin")
    r = client.post("/energy/power/save", data={"csrf_token": tok, "act": "budget", "factory": f2, "year": 2026, "b_11": "750,000"}, follow_redirects=True)
    assert "บันทึกงบค่าไฟ" in r.get_data(as_text=True) and BL.budget(db, f2, date(2026, 11, 1)) == 750000
    page = client.get(f"/energy/power?tab=rate&factory={f2}&year=2026").get_data(as_text=True)
    assert 'name="b_11"' in page and "750,000" in page


# ───────────── ข้อ 5: อุณหภูมิ · ค่าฐาน 2 ตัวแปร · นำเข้ายอดผลิต · PF · น้ำ/ลม ─────────────

def test_weather_fetch_import_and_daily(app, db):
    from ecs import energy_weather as WX
    WX.ensure(db)
    with pytest.raises(ValidationError):
        WX.fetch(db, date(2026, 1, 1), date(2026, 1, 2))                       # ยังไม่ตั้งพิกัด
    WX.save_location(db, "13.36", "101.0", None)
    with pytest.raises(ValidationError):
        WX.save_location(db, "abc", "1", None)
    calls = []

    def fake(url):
        calls.append(url)
        return {"hourly": {"time": [f"2026-01-01T{h:02d}:00" for h in range(24)], "temperature_2m": [20 + h * 0.5 for h in range(24)]}}
    n = WX.fetch(db, date(2026, 1, 1), date(2026, 1, 1), opener=fake)
    assert n == 24 and "archive-api.open-meteo.com" in calls[0] and "latitude=13.36" in calls[0]
    assert WX.hourly(db, date(2026, 1, 1))[10] == 25.0
    d = WX.daily(db, date(2026, 1, 1), date(2026, 1, 1))["2026-01-01"]
    assert d["mean"] == 25.75 and d["cdd"] == 0.75 and d["max"] == 31.5
    assert WX.import_text(db, "วันที่,อุณหภูมิ\n2026-01-02 14:00, 33.5\n2026-01-03, 30") == 25
    assert WX.hourly(db, date(2026, 1, 2))[14] == 33.5 and WX.daily(db, date(2026, 1, 3), date(2026, 1, 3))["2026-01-03"]["cdd"] == 5.0
    with pytest.raises(ValidationError):
        WX.import_text(db, "ไม่ใช่ข้อมูล")


def test_baseline_with_temperature(app, db):
    from ecs import energy_perf as PF
    from ecs import energy_weather as WX
    PF.ensure(db)
    WX.ensure(db)
    f2 = app.config["F2"]
    m = _m(db, f2, "WX1", grp="Cool")
    today = S.now_dt().date()
    start, r0, r1 = today - timedelta(days=45), today - timedelta(days=8), today - timedelta(days=1)
    v = 0.0
    _rd(db, m, start - timedelta(days=1), v)
    d, i = start, 0
    rows = []
    while d <= r1:
        p = 100 + (i % 5) * 20
        cdd = (i * 7 % 6) * 1.0                                                  # อากาศแปรผันไม่ขึ้นกับยอดผลิต
        use = 200 + 2 * p + 30 * cdd
        if d >= r0:
            use *= 0.9
        v += use
        _rd(db, m, d, v)
        db.execute("INSERT INTO en_shift_prod(factory_id, grp, day, shift, qty) VALUES (?,?,?,?,?)", (f2, "Cool", d.isoformat(), "A", p))
        rows += [(f"{d.isoformat()} {h:02d}:00", 25 + cdd) for h in range(24)]
        d += timedelta(days=1)
        i += 1
    WX.store(db, rows, "test")
    db.commit()
    B1 = PF.baseline(db, f2, "elec", "Cool", None, start, r0 - timedelta(days=1), r0, r1)
    B2 = PF.baseline(db, f2, "elec", "Cool", None, start, r0 - timedelta(days=1), r0, r1, wx=True)
    assert B1["wx_avail"] and B1["mode"] == "daily" and B2["mode"] == "daily_wx"
    M = B2["model"]
    assert abs(M["a"] - 200) < 0.5 and abs(M["b"] - 2) < 1e-3 and abs(M["c"] - 30) < 0.01 and M["r2"] > 0.999
    assert B2["model"]["r2"] > (B1["model"]["r2"] or 0) and abs(B2["save_pct"] - 10) < 0.01
    assert abs(B2["chg_total"] - (B2["chg_prod"] + B2["chg_wx"] + B2["chg_eff"])) < 0.5


def test_production_import(app, db):
    from ecs import energy_perf as PF
    PF.ensure(db)
    f2 = app.config["F2"]
    rows = PF.read_prod_rows(None, "", "วันที่\tกะ\tหน่วยงาน\tจำนวน\n2026-11-10\tA\tPress\t1,200\n10/11/2569\tบ่าย\tPress\t950\n2026-11-10\tดึก\t\t300\n2026-11-11\tX\tPress\t5")
    r = PF.import_prod(db, f2, rows, "", None)
    db.commit()
    assert r["rows"] == 3 and r["n_bad"] == 1 and "ไม่รู้จักกะ" in r["bad"][0]
    assert PF.prod_rows(db, f2, "Press", date(2026, 11, 10), date(2026, 11, 10))["2026-11-10"] == {"A": 1200.0, "B": 950.0}
    assert PF.prod_rows(db, f2, "", date(2026, 11, 10), date(2026, 11, 10))["2026-11-10"] == {"C": 300.0}
    import io

    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["วันที่", "กะ", "หน่วยงาน", "จำนวน"])
    ws.append([datetime(2026, 11, 12), "เช้า", "Paint", 777])
    buf = io.BytesIO()
    wb.save(buf)
    r = PF.import_prod(db, f2, PF.read_prod_rows(buf.getvalue(), "p.xlsx", ""), "", None)
    assert r["rows"] == 1 and PF.prod_rows(db, f2, "Paint", date(2026, 11, 12), date(2026, 11, 12))["2026-11-12"]["A"] == 777
    with pytest.raises(ValidationError):
        PF.read_prod_rows(b"not excel", "x.xlsx", "")
    with pytest.raises(ValidationError):
        PF.import_prod(db, f2, [["หัว", "ตาราง", "เท่านั้น"]], "", None)


def test_overview_pf_temperature_and_pages(app, db, client):
    from ecs import energy_overview as OV
    from ecs import energy_weather as WX
    EI.ensure(db)
    PW.ensure(db)
    WX.ensure(db)
    f2 = app.config["F2"]
    d1 = S.now_dt().date() - timedelta(days=1)
    m = _m(db, f2, "PFO", grp="Press")
    _iv(db, m, d1, 1.0)
    for i, v in enumerate((0.92, 0.80)):
        mm = m if i == 0 else _m(db, f2, f"PF{i}", grp="Press")
        _iv(db, mm, d1, 0.5)
        db.execute("INSERT INTO en_params(meter_id, param, ts, value) VALUES (?,?,?,?)", (mm, "pf", S.ts(datetime.combine(d1, datetime.min.time()) + timedelta(hours=23)), v))
    WX.store(db, [(f"{d1.isoformat()} {h:02d}:00", 30.0) for h in range(24)], "test")
    db.commit()
    O = OV.build(db, d1, f2)
    assert O["pf"]["n"] == 2 and O["pf"]["low"] == 1 and O["pf"]["avg"] == 0.86
    assert O["hourly"]["temp"][12] == 30.0
    login(client, "t_admin")
    html = client.get(f"/energy/overview?factory={f2}&day={d1.isoformat()}").get_data(as_text=True)
    assert "PF 0.86" in html and "ต่ำกว่าเกณฑ์" in html and "อุณหภูมิ °C" in html
    w = client.get("/energy/weather").get_data(as_text=True)
    assert "อุณหภูมิอากาศ" in w and "Open-Meteo" in w and 'name="lat"' in w
    tok = login(client, "t_admin")
    r = client.post("/energy/weather", data={"csrf_token": tok, "act": "import", "text": "2026-02-01, 31"}, follow_redirects=True)
    assert "นำเข้าแล้ว 24 ชั่วโมง" in r.get_data(as_text=True)
    r = client.post("/energy/shifts/setup", data={"csrf_token": tok, "act": "import", "factory": f2, "grp": "Press", "month": "2026-11",
                                                  "text": "2026-11-05\tA\t\t500"}, follow_redirects=True)
    assert "นำเข้ายอดผลิต 1 แถว" in r.get_data(as_text=True)
    t = client.get(f"/energy/shifts/template.csv?factory={f2}")
    assert t.status_code == 200 and "วันที่,กะ,หน่วยงาน,จำนวน" in t.get_data(as_text=True)
    login(client, "t_view")
    assert client.post("/energy/weather", data={"act": "import", "text": "x"}).status_code in (302, 400, 403)
