"""ecs/energy_perf.py — v0.99.48 วิเคราะห์ประสิทธิภาพพลังงาน

1) กะ (shift)        ตั้งกะของโรงงาน (เช้า / บ่าย / ดึก ฯลฯ) · ยอดผลิตรายกะ · การใช้ต่อกะ (จากข้อมูลราย 15 นาที) · kWh ต่อชิ้นต่อกะ
2) ค่าฐาน + CUSUM    ค่าฐานที่ปรับตามยอดผลิต (Regression kWh = a + b × ยอดผลิต · แนวทาง ISO 50006 / IPMVP)
                     → ยอดลดได้จริง (หลังหักผลจากยอดผลิตที่เปลี่ยน) · กราฟ CUSUM · แยก “ลดเพราะผลิตน้อย” กับ “ลดเพราะประหยัดได้จริง”
3) การไหลของพลังงาน แผนภาพ Sankey: รวมโรงงาน → หน่วยงาน → ไลน์ (+ ส่วนที่มิเตอร์ย่อยไม่ได้วัด / Solar)

ใช้ตัวคำนวณเดียวกับทุกหน้า: EN.series (รายวัน) · EN.counted (ไม่นับซ้ำหลัก/ย่อย) · energy_live._sums_range (ราย 15 นาที)
"""
from __future__ import annotations

import json
import math
import re
from datetime import date, datetime, timedelta
from itertools import pairwise

from . import energy as EN
from . import services as S
from .services import ValidationError

NO_SEC = "-"
SLOT = 15
NSLOT = 96

SCHEMA = """
CREATE TABLE IF NOT EXISTS en_shift_cfg (
    factory_id  INTEGER PRIMARY KEY,
    data        TEXT NOT NULL,
    updated_by  INTEGER,
    updated_at  TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS en_shift_prod (
    factory_id  INTEGER NOT NULL,
    grp         TEXT NOT NULL DEFAULT '',
    day         TEXT NOT NULL,
    shift       TEXT NOT NULL,
    qty         REAL NOT NULL,
    updated_by  INTEGER,
    updated_at  TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (factory_id, grp, day, shift)
);
CREATE INDEX IF NOT EXISTS ix_en_shift_prod_day ON en_shift_prod(factory_id, day);
"""

DEFAULT_SHIFTS = [{"code": "A", "name": "เช้า", "start": "08:00", "end": "16:00"},
                  {"code": "B", "name": "บ่าย", "start": "16:00", "end": "00:00"},
                  {"code": "C", "name": "ดึก", "start": "00:00", "end": "08:00"}]
COLORS = ["#2a78d6", "#e0a100", "#6d4fc2", "#0ca30c"]


def ensure(db) -> None:
    db.executescript(SCHEMA)


# ───────────────────────── กะ ─────────────────────────

def _hm(s: str) -> int:
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", (s or "").strip())
    if not m or int(m.group(1)) > 24 or int(m.group(2)) > 59 or (int(m.group(1)) == 24 and int(m.group(2))):
        raise ValidationError([f"เวลา “{s}” ไม่ถูกต้อง (ใช้รูปแบบ ชม.:นาที เช่น 08:00)"])
    v = int(m.group(1)) * 60 + int(m.group(2))
    if v % SLOT:
        raise ValidationError([f"เวลา “{s}” ต้องลงตัวทุก 15 นาที (เช่น 07:45 · 08:00) — ข้อมูลไฟฟ้าเก็บราย 15 นาที"])
    return v % 1440


def layout(shifts: list[dict]) -> list[dict]:
    """ตรวจ + คำนวณตำแหน่งของแต่ละกะใน “วันผลิต” (เริ่มที่เวลาเข้ากะแรก ยาว 24 ชม.)
    กะที่ข้ามเที่ยงคืน (เช่น ดึก 00:00–08:00 หลังกะบ่าย) เป็นของวันผลิตเดียวกับกะแรก"""
    if not shifts:
        raise ValidationError(["ต้องมีอย่างน้อย 1 กะ"])
    if len(shifts) > 4:
        raise ValidationError(["ตั้งได้ไม่เกิน 4 กะ"])
    t0 = _hm(shifts[0]["start"])
    out, codes = [], set()
    for i, s in enumerate(shifts):
        name = (s.get("name") or "").strip()[:30]
        code = (s.get("code") or "ABCD"[i]).strip()[:4] or "ABCD"[i]
        if not name:
            raise ValidationError([f"กะที่ {i + 1}: ต้องมีชื่อกะ"])
        if code in codes:
            raise ValidationError([f"รหัสกะ “{code}” ซ้ำ"])
        codes.add(code)
        a, b = _hm(s["start"]), _hm(s["end"])
        dur = (b - a) % 1440 or 1440
        out.append({"code": code, "name": name, "start": s["start"].strip().zfill(5), "end": s["end"].strip().zfill(5),
                    "off": (a - t0) % 1440, "dur": dur, "hours": round(dur / 60, 2), "color": COLORS[i % len(COLORS)]})
    srt = sorted(out, key=lambda x: x["off"])
    for x, y in pairwise(srt):
        if x["off"] + x["dur"] > y["off"]:
            raise ValidationError([f"กะ “{x['name']}” กับ “{y['name']}” เวลาทับกัน"])
    if srt[-1]["off"] + srt[-1]["dur"] > 1440:
        raise ValidationError(["รวมทุกกะเกิน 24 ชั่วโมง / เวลาทับกัน"])
    return out


def shifts(db, fid: int | None) -> dict:
    """{'list': [...], 't0': นาทีที่เริ่มวันผลิต, 'custom': ตั้งเองหรือค่าเริ่มต้น}"""
    ensure(db)
    data, custom = DEFAULT_SHIFTS, False
    if fid:
        r = db.execute("SELECT data FROM en_shift_cfg WHERE factory_id=?", (fid,)).fetchone()
        if r:
            try:
                data, custom = json.loads(r[0]), True
            except ValueError:
                pass
    lst = layout(data)
    return {"list": lst, "t0": _hm(lst[0]["start"]), "custom": custom}


def save_shifts(db, fid: int, rows: list[dict], actor) -> None:
    if not fid:
        raise ValidationError(["เลือกโรงงานก่อนตั้งกะ"])
    rows = [r for r in rows if (r.get("name") or "").strip() or (r.get("start") or "").strip()]
    lst = layout(rows)
    ensure(db)
    data = json.dumps([{k: x[k] for k in ("code", "name", "start", "end")} for x in lst], ensure_ascii=False)
    db.execute("""INSERT INTO en_shift_cfg(factory_id, data, updated_by, updated_at) VALUES (?,?,?,?)
                  ON CONFLICT(factory_id) DO UPDATE SET data=excluded.data, updated_by=excluded.updated_by, updated_at=excluded.updated_at""",
               (fid, data, actor, S.now_dt().isoformat(timespec="seconds")))


def slot_map(sh: dict) -> list[int | None]:
    """ช่อง 15 นาทีของวันผลิต (96 ช่อง เริ่มที่ t0) → index ของกะ (None = นอกกะ)"""
    out: list = [None] * NSLOT
    for i, s in enumerate(sh["list"]):
        for k in range(s["off"] // SLOT, (s["off"] + s["dur"]) // SLOT):
            out[k] = i
    return out


def prod_rows(db, fid: int | None, grp: str | None, d0: date, d1: date) -> dict[str, dict[str, float]]:
    """ยอดผลิตรายกะ {วัน: {รหัสกะ: จำนวน}} — grp None = ทั้งโรงงาน (ใช้แถวรวมโรงงาน ถ้าไม่มีใช้ผลรวมทุกหน่วยงาน)"""
    ensure(db)
    if not fid:
        return {}
    out: dict[str, dict[str, float]] = {}
    if grp is not None:
        q = db.execute("SELECT day, shift, qty FROM en_shift_prod WHERE factory_id=? AND grp=? AND day BETWEEN ? AND ?",
                       (fid, "" if grp == NO_SEC else grp, d0.isoformat(), d1.isoformat()))
        for d, s, v in q:
            out.setdefault(d, {})[s] = float(v)
        return out
    tot = db.execute("SELECT day, shift, qty FROM en_shift_prod WHERE factory_id=? AND grp='' AND day BETWEEN ? AND ?",
                     (fid, d0.isoformat(), d1.isoformat())).fetchall()
    if tot:
        for d, s, v in tot:
            out.setdefault(d, {})[s] = float(v)
        return out
    for d, s, v in db.execute("""SELECT day, shift, SUM(qty) FROM en_shift_prod WHERE factory_id=? AND day BETWEEN ? AND ?
                                 GROUP BY day, shift""", (fid, d0.isoformat(), d1.isoformat())):
        out.setdefault(d, {})[s] = float(v)
    return out


def save_prod(db, fid: int, grp: str, cells: dict[tuple[str, str], str], codes: set[str], actor) -> int:
    """บันทึกยอดผลิตรายกะ cells {(วัน, กะ): ข้อความ} — ช่องว่าง = ลบ"""
    if not fid:
        raise ValidationError(["เลือกโรงงานก่อน"])
    ensure(db)
    n, bad = 0, []
    for (d, code), raw in cells.items():
        if code not in codes:
            continue
        try:
            date.fromisoformat(d)
        except ValueError:
            continue
        raw = (raw or "").replace(",", "").strip()
        if raw == "":
            n += db.execute("DELETE FROM en_shift_prod WHERE factory_id=? AND grp=? AND day=? AND shift=?", (fid, grp, d, code)).rowcount
            continue
        try:
            v = float(raw)
            if v < 0 or math.isnan(v) or math.isinf(v):
                raise ValueError
        except ValueError:
            bad.append(f"{d} กะ {code}: “{raw}”")
            continue
        db.execute("""INSERT INTO en_shift_prod(factory_id, grp, day, shift, qty, updated_by, updated_at) VALUES (?,?,?,?,?,?,?)
                      ON CONFLICT(factory_id, grp, day, shift) DO UPDATE SET qty=excluded.qty, updated_by=excluded.updated_by,
                      updated_at=excluded.updated_at""", (fid, grp, d, code, v, actor, S.now_dt().isoformat(timespec="seconds")))
        n += 1
    if bad:
        raise ValidationError(["ยอดผลิตต้องเป็นตัวเลข ≥ 0: " + " · ".join(bad[:5]) + (" …" if len(bad) > 5 else "")])
    return n


def _scope_meters(db, fid, kind, grp, line) -> list[dict]:
    ms = EN.meters(db, fid, kind, True)
    if grp:
        ms = [m for m in ms if ((m.get("grp") or "").strip() or NO_SEC) == grp]
    if line:
        ms = [m for m in ms if ((m.get("line") or "").strip() or "-") == line]
    return [m for m in EN.counted(ms)]


def last_full_day(sh: dict, now: datetime) -> date:
    """วันผลิตล่าสุดที่จบครบทุกกะแล้ว"""
    d = now.date() - timedelta(days=1)
    while datetime.combine(d + timedelta(days=1), datetime.min.time()) + timedelta(minutes=sh["t0"]) > now:
        d -= timedelta(days=1)
    return d


def shift_report(db, fid: int | None, kind: str, grp: str | None, line: str | None, d0: date, d1: date) -> dict:
    """การใช้ต่อกะ (ราย 15 นาที) + ยอดผลิตรายกะ → kWh/ชิ้น ต่อกะ"""
    from . import energy_live as LV
    kind = kind if kind in EN.KINDS else "elec"
    sh = shifts(db, fid)
    smap = slot_map(sh)
    ms = _scope_meters(db, fid, kind, grp, line)
    nd = (d1 - d0).days + 1
    days = [(d0 + timedelta(days=i)).isoformat() for i in range(nd)]
    a = datetime.combine(d0, datetime.min.time()) + timedelta(minutes=sh["t0"])
    b = a + timedelta(days=nd)
    pos = [m["id"] for m in ms if EN.sign(m) > 0]
    neg = [m["id"] for m in ms if EN.sign(m) < 0]
    sl = LV._sums_range(db, pos, a, b) if pos else [None] * nd * NSLOT
    if neg:
        for k, v in enumerate(LV._sums_range(db, neg, a, b)):
            if v is not None:
                sl[k] = (sl[k] or 0.0) - v
    ns = len(sh["list"])
    U = [[0.0] * ns for _ in days]
    have = [[0] * ns for _ in days]
    need = [sum(1 for x in smap if x == i) for i in range(ns)]
    gap = 0.0
    for i in range(nd):
        for k in range(NSLOT):
            v = sl[i * NSLOT + k]
            j = smap[k]
            if v is None:
                continue
            if j is None:
                gap += v
            else:
                U[i][j] += v
                have[i][j] += 1
    P = prod_rows(db, fid, grp, d0, d1)
    lst = []
    tot_u = sum(U[i][j] for i in range(nd) for j in range(ns) if have[i][j])
    for j, s in enumerate(sh["list"]):
        full = [i for i in range(nd) if have[i][j] == need[j] and need[j]]
        u = sum(U[i][j] for i in range(nd) if have[i][j])
        pd = [i for i in full if s["code"] in P.get(days[i], {})]
        pu = sum(U[i][j] for i in pd)
        pq = sum(P[days[i]][s["code"]] for i in pd)
        lst.append({**s, "u": round(u, 1), "share": round(100 * u / tot_u, 1) if tot_u else None,
                    "avg": round(sum(U[i][j] for i in full) / len(full), 1) if full else None,
                    "per_h": round(sum(U[i][j] for i in full) / len(full) / s["hours"], 1) if full else None,
                    "days": len(full), "cover": round(100 * sum(have[i][j] for i in range(nd)) / (need[j] * nd), 1) if need[j] else None,
                    "prod": round(pq, 1) if pd else None, "prod_days": len(pd),
                    "per_unit": round(pu / pq, 4) if pq else None})
    best = [x for x in lst if x["per_unit"]]
    note = None
    if len(best) >= 2:
        lo, hi = min(best, key=lambda x: x["per_unit"]), max(best, key=lambda x: x["per_unit"])
        if hi["per_unit"] > lo["per_unit"] * 1.03:
            note = {"hi": hi["name"], "lo": lo["name"], "pct": round(100 * (hi["per_unit"] / lo["per_unit"] - 1), 1),
                    "extra": round((hi["per_unit"] - lo["per_unit"]) * (hi["prod"] or 0), 0)}
    daily = [{"day": days[i], "u": [round(U[i][j], 1) if have[i][j] else None for j in range(ns)],
              "full": [have[i][j] == need[j] for j in range(ns)],
              "q": [P.get(days[i], {}).get(s["code"]) for s in sh["list"]]} for i in range(nd)]
    for r in daily:
        r["pu"] = [round(u / q, 4) if (u is not None and q and f) else None for u, q, f in zip(r["u"], r["q"], r["full"])]
    meta = EN.KINDS[kind]
    return {"kind": kind, "th": meta["th"], "unit": meta["unit"], "icon": meta["icon"], "shifts": sh, "rows": lst, "daily": daily,
            "days": days, "d0": d0, "d1": d1, "gap": round(gap, 1), "total": round(tot_u + gap, 1), "n_meters": len(ms),
            "has_15m": any(v is not None for v in sl), "has_prod": bool(P), "note": note}


# ───────────────────────── ค่าฐาน + CUSUM ─────────────────────────

def _ols(xs: list[float], ys: list[float]) -> dict | None:
    n = len(xs)
    if n < 3:
        return None
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx <= 1e-9:
        return None
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
    a = my - b * mx
    ssr = sum((y - (a + b * x)) ** 2 for x, y in zip(xs, ys))
    sst = sum((y - my) ** 2 for y in ys)
    r2 = 1 - ssr / sst if sst > 0 else 0.0
    cv = math.sqrt(ssr / (n - 2)) / my * 100 if n > 2 and my else None
    return {"a": a, "b": b, "r2": r2, "cv": cv, "n": n, "mx": mx, "my": my}


def _daily_use(db, ms, d0, d1) -> dict[str, float]:
    """การใช้รายวันของชุดมิเตอร์ — เฉพาะวันที่มีค่าครบทุกมิเตอร์ที่ส่งข้อมูลในช่วงนี้ (วันข้อมูลขาดไม่เอามาคิด)"""
    if not ms:
        return {}
    ser = EN.series(db, ms, d0, d1)
    live = [m for m in ms if any(x.get("u") is not None for x in (ser.get(m["id"]) or {}).values())]
    out: dict[str, float] = {}
    cnt: dict[str, int] = {}
    for m in live:
        for d, x in (ser.get(m["id"]) or {}).items():
            if x.get("u") is not None:
                out[d] = out.get(d, 0.0) + EN.sign(m) * x["u"]
                cnt[d] = cnt.get(d, 0) + 1
    return {d: v for d, v in out.items() if cnt[d] == len(live)}


def _daily_prod(db, fid, grp, d0, d1, cfg, hol) -> dict[str, float]:
    from . import energy_power as PW
    P = prod_rows(db, fid, grp, d0, d1)
    if not P:
        return {}
    out = {d: sum(v.values()) for d, v in P.items()}
    d = d0
    while d <= d1:                                   # วันหยุด/ไม่ได้ทำงานที่ไม่ได้กรอก = ผลิต 0
        if d.isoformat() not in out and not PW.work_day(d, cfg, hol):
            out[d.isoformat()] = 0.0
        d += timedelta(days=1)
    return out


def _month_prod(db, fid, grp, line, m: date) -> float | None:
    ym = m.strftime("%Y-%m")
    try:
        if grp or line:
            w, a = ["factory_id=?", "month=?"], [fid, ym]
            if grp:
                w.append("grp=?")
                a.append("" if grp == NO_SEC else grp)
            if line:
                w.append("line=?")
                a.append("" if line == "-" else line)
            r = db.execute(f"SELECT SUM(qty) FROM en_line_prod WHERE {' AND '.join(w)}", a).fetchone()
            return float(r[0]) if r and r[0] else None
        r = db.execute("SELECT qty FROM en_production WHERE factory_id=? AND month=?", (fid, ym)).fetchone()
        if r and r[0]:
            return float(r[0])
        r = db.execute("SELECT SUM(qty) FROM en_line_prod WHERE factory_id=? AND month=?", (fid, ym)).fetchone()
        return float(r[0]) if r and r[0] else None
    except Exception:                                # noqa: BLE001
        return None


def _months(d0: date, d1: date) -> list[date]:
    out, m = [], d0.replace(day=1)
    while m <= d1:
        out.append(m)
        m = (m + timedelta(days=32)).replace(day=1)
    return out


def default_periods(today: date, mark: date | None = None) -> tuple[date, date, date, date]:
    """ช่วงฐาน / ช่วงติดตาม เริ่มต้น: มีวันเริ่มปรับปรุง → ฐาน = 60 วันก่อนหน้า · ติดตาม = ตั้งแต่วันนั้นถึงเมื่อวาน
    ไม่มี → ติดตาม = เดือนนี้ (ถึงเมื่อวาน) · ฐาน = 3 เดือนก่อนหน้า"""
    y = today - timedelta(days=1)
    if mark and mark <= y:
        return mark - timedelta(days=60), mark - timedelta(days=1), mark, y
    r0 = y.replace(day=1)
    b1 = r0 - timedelta(days=1)
    b0 = (b1.replace(day=1) - timedelta(days=62)).replace(day=1)
    return b0, b1, r0, y


def _ols2(x1: list[float], x2: list[float], ys: list[float]) -> dict | None:
    """v0.99.50 ถดถอย 2 ตัวแปร: y = a + b·x1 + c·x2 (ยอดผลิต + CDD อุณหภูมิ)"""
    n = len(ys)
    if n < 5:
        return None
    m1, m2, my = sum(x1) / n, sum(x2) / n, sum(ys) / n
    s11 = sum((x - m1) ** 2 for x in x1)
    s22 = sum((x - m2) ** 2 for x in x2)
    s12 = sum((a - m1) * (b - m2) for a, b in zip(x1, x2))
    s1y = sum((a - m1) * (y - my) for a, y in zip(x1, ys))
    s2y = sum((b - m2) * (y - my) for b, y in zip(x2, ys))
    det = s11 * s22 - s12 * s12
    if abs(det) < 1e-9 or s22 < 1e-9:
        return None
    b = (s1y * s22 - s2y * s12) / det
    c = (s2y * s11 - s1y * s12) / det
    a = my - b * m1 - c * m2
    ssr = sum((y - (a + b * u + c * v)) ** 2 for u, v, y in zip(x1, x2, ys))
    sst = sum((y - my) ** 2 for y in ys)
    return {"a": a, "b": b, "c": c, "r2": 1 - ssr / sst if sst > 0 else 0.0,
            "cv": math.sqrt(ssr / (n - 3)) / my * 100 if n > 3 and my else None, "n": n, "mx": m1, "my": my}


def baseline(db, fid: int | None, kind: str, grp: str | None, line: str | None,
             b0: date, b1: date, r0: date, r1: date, wx: bool = False) -> dict:
    """ค่าฐานที่ปรับตามยอดผลิต + CUSUM
    โหมด: daily (ยอดผลิตรายวันจากยอดผลิตรายกะ) → monthly (ยอดผลิตรายเดือน) → daytype (ไม่มียอดผลิต: เฉลี่ยวันทำงาน/วันหยุด)"""
    from . import energy_dept as DP
    from . import energy_power as PW
    kind = kind if kind in EN.KINDS else "elec"
    meta = EN.KINDS[kind]
    if r0 <= b1:
        raise ValidationError(["ช่วงติดตามต้องเริ่มหลังช่วงฐาน"])
    ms = _scope_meters(db, fid, kind, grp, line)
    use = _daily_use(db, ms, b0, r1)
    cfg = PW.tariff(db, fid) if fid else PW.tariff(db, 0)
    hol = PW.holidays(db, fid or 0, b0, r1)
    rate, ef = DP._rate(db, fid, kind, r0), DP._ef(db, kind)
    res = {"kind": kind, "th": meta["th"], "unit": meta["unit"], "icon": meta["icon"], "color": meta["color"],
           "b0": b0, "b1": b1, "r0": r0, "r1": r1, "n_meters": len(ms), "rate": rate, "ef": ef, "mode": None, "model": None,
           "points": [], "msg": None, "wx_avail": False}
    if not use:
        res["msg"] = "ไม่มีข้อมูลการใช้ในช่วงที่เลือก"
        return res
    pts = []
    prod = _daily_prod(db, fid, grp, b0, r1, cfg, hol) if not line else {}          # ยอดผลิตรายกะเก็บระดับหน่วยงาน
    base_n = sum(1 for d in use if b0.isoformat() <= d <= b1.isoformat() and d in prod)
    from . import energy_weather as WX
    W = WX.daily(db, b0, r1)
    if base_n >= 10:
        mode = "daily"
        for d in sorted(use):
            if d in prod:
                pts.append({"x": d, "p": prod[d], "y": use[d], "base": d <= b1.isoformat(), "rep": d >= r0.isoformat(), "t": (W.get(d) or {}).get("cdd")})
    else:
        mpts = []
        for m in _months(b0, r1):
            last = (m + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            ds = [(m + timedelta(days=i)).isoformat() for i in range((last - m).days + 1)]
            if not all(d in use for d in ds):
                continue
            q = _month_prod(db, fid, grp, line, m)
            if q:
                mpts.append({"x": m.strftime("%Y-%m"), "p": q, "y": sum(use[d] for d in ds),
                             "base": last <= b1, "rep": m >= r0.replace(day=1) and last <= r1 and m >= r0})
        if sum(1 for p in mpts if p["base"]) >= 3 and any(p["rep"] for p in mpts):
            mode, pts = "monthly", mpts
        else:
            mode = "daytype"
            for d in sorted(use):
                w = PW.work_day(date.fromisoformat(d), cfg, hol)
                pts.append({"x": d, "p": 1.0 if w else 0.0, "y": use[d], "base": d <= b1.isoformat(), "rep": d >= r0.isoformat(), "work": w})
    res["mode"] = mode
    base = [p for p in pts if p["base"]]
    rep = [p for p in pts if p["rep"]]
    if len(base) < 3 or not rep:
        res["msg"] = (f"ข้อมูลช่วงฐานมี {len(base)} จุด (ต้องอย่างน้อย 3) " if len(base) < 3 else "") + ("· ช่วงติดตามยังไม่มีข้อมูล" if not rep else "")
        res["points"] = pts
        return res
    if mode == "daytype":
        wk = [p["y"] for p in base if p["p"] == 1.0]
        hd = [p["y"] for p in base if p["p"] == 0.0]
        aw = sum(wk) / len(wk) if wk else sum(p["y"] for p in base) / len(base)
        ah = sum(hd) / len(hd) if hd else aw
        model = {"a": ah, "b": aw - ah, "r2": None, "cv": None, "n": len(base), "mx": None, "my": sum(p["y"] for p in base) / len(base),
                 "aw": aw, "ah": ah}
    else:
        wx_ok = mode == "daily" and sum(1 for p in base if p.get("t") is not None) >= 0.8 * len(base) and any(p.get("t") is not None for p in rep)
        res["wx_avail"] = wx_ok
        model = None
        if wx and wx_ok:                                       # v0.99.50 ปรับตามอุณหภูมิด้วย (ตัดวันที่ไม่มีข้อมูลอากาศ)
            pts = [p for p in pts if p.get("t") is not None]
            base = [p for p in pts if p["base"]]
            rep = [p for p in pts if p["rep"]]
            model = _ols2([p["p"] for p in base], [p["t"] for p in base], [p["y"] for p in base])
            if model:
                mode = "daily_wx"
                res["mode"] = mode
        if model is None:
            model = _ols([p["p"] for p in base], [p["y"] for p in base])
        if model is None:
            my = sum(p["y"] for p in base) / len(base)
            model = {"a": my, "b": 0.0, "r2": None, "cv": None, "n": len(base), "mx": None, "my": my, "flat": True}
    a, b, cw = model["a"], model["b"], model.get("c") or 0.0
    cus = 0.0
    for p in pts:
        p["e"] = round(a + b * p["p"] + cw * (p.get("t") or 0.0), 2)
        p["d"] = round(p["y"] - p["e"], 2)
    for p in pts:                                    # CUSUM เริ่มนับตั้งแต่ช่วงติดตาม (ช่วงฐานแสดงความคลาดเคลื่อนของแบบจำลองเอง)
        if p["rep"]:
            cus += p["d"]
            p["c"] = round(cus, 1)
        else:
            p["c"] = None
    bc = 0.0
    for p in pts:
        if p["base"]:
            bc += p["d"]
            p["cb"] = round(bc, 1)
    n = len(rep)
    act = sum(p["y"] for p in rep)
    exp = sum(p["e"] for p in rep)
    save = exp - act
    ab = sum(p["y"] for p in base) / len(base)
    ar, er = act / n, exp / n
    pb = sum(p["p"] for p in base) / len(base)
    pr = sum(p["p"] for p in rep) / n
    tb = sum((p.get("t") or 0.0) for p in base) / len(base)
    tr = sum((p.get("t") or 0.0) for p in rep) / n
    q = {"r2": model.get("r2"), "cv": model.get("cv")}
    if mode == "daytype":
        quality, qmsg = "info", "ไม่มียอดผลิต — ค่าฐาน = เฉลี่ยวันทำงาน / วันหยุดของช่วงฐาน (ยังแยกผลจากยอดผลิตไม่ได้ → กรอกยอดผลิตรายกะ)"
    elif model.get("flat"):
        quality, qmsg = "warn", "ยอดผลิตช่วงฐานเท่ากันทุกจุด → ใช้ค่าเฉลี่ยแทน"
    elif b < 0:
        quality, qmsg = "warn", "ยิ่งผลิตมากยิ่งใช้น้อย (ความสัมพันธ์กลับทิศ) — ตรวจยอดผลิต/การจัดหมวดมิเตอร์"
    elif q["r2"] is not None and q["r2"] >= 0.75 and (q["cv"] or 0) <= 20:
        quality, qmsg = "good", "แบบจำลองเชื่อถือได้ (R² ≥ 0.75 · CV ≤ 20%)"
    elif q["r2"] is not None and q["r2"] >= 0.5:
        quality, qmsg = "ok", "แบบจำลองพอใช้ (R² 0.5–0.75) — ผลประหยัดเป็นค่าประมาณ"
    else:
        quality, qmsg = "warn", "ยอดผลิตอธิบายการใช้ได้น้อย (R² < 0.5) — มีปัจจัยอื่น เช่น อากาศ / โหลดคงที่สูง"
    res.update({
        "points": pts, "model": {**model, "a": round(a, 3), "b": round(b, 5), "c": round(cw, 3) if cw else None}, "quality": quality, "qmsg": qmsg,
        "n_base": len(base), "n_rep": n, "act": round(act, 1), "exp": round(exp, 1), "save": round(save, 1),
        "save_pct": round(100 * save / exp, 1) if exp else None,
        "baht": round(save * rate, 0) if rate else None, "co2": round(save * ef / 1000, 3) if ef else None,
        "base_avg": round(ab, 1), "rep_avg": round(ar, 1), "exp_avg": round(er, 1), "pb": round(pb, 2), "pr": round(pr, 2),
        # แยกส่วนการเปลี่ยนแปลง (ต่อจุด × จำนวนจุดช่วงติดตาม): ทั้งหมด = จากยอดผลิต + จากประสิทธิภาพ
        "chg_total": round((ar - ab) * n, 1), "chg_prod": round((er - ab - cw * (tr - tb)) * n, 1), "chg_wx": round(cw * (tr - tb) * n, 1) if cw else None,
        "chg_eff": round((ar - er) * n, 1), "tb": round(tb, 2) if cw else None, "tr": round(tr, 2) if cw else None,
        "chg_pct": round(100 * (ar - ab) / ab, 1) if ab else None,
        "per_b": round(ab / pb, 4) if mode != "daytype" and pb else None, "per_r": round(ar / pr, 4) if mode != "daytype" and pr else None,
    })
    return res


# ───────────────────────── การไหลของพลังงาน (Sankey) ─────────────────────────

def flow(db, fid: int | None, kind: str, d0: date, d1: date) -> dict:
    """โหนด/ลิงก์ ของแผนภาพ: แหล่ง (มิเตอร์หลัก · Solar) → รวม → หน่วยงาน → ไลน์ · ส่วนที่ไม่ได้วัด"""
    kind = kind if kind in EN.KINDS else "elec"
    meta = EN.KINDS[kind]
    allm = [m for m in EN.meters(db, fid, kind, True) if (m.get("is_main") or 0) != 2]
    cv = EN.covers(allm)
    ids = {m["id"] for m in allm}
    covered_by = {x for m in allm for x in (cv.get(m["id"]) or set()) if x in ids}       # มิเตอร์ที่ครอบมิเตอร์อื่นอยู่ (หลัก)
    ser = EN.series(db, allm, d0, d1) if allm else {}
    tot = {m["id"]: sum(x["u"] for x in (ser.get(m["id"]) or {}).values() if x.get("u") is not None) for m in allm}
    cnt = [m for m in EN.counted(allm)]
    T = sum(EN.sign(m) * tot[m["id"]] for m in cnt)                                       # ยอดรวมโรงงาน (ตัวเลขเดียวกับทุกหน้า)
    leaves = [m for m in allm if m["id"] not in covered_by and EN.sign(m) > 0]
    D = sum(tot[m["id"]] for m in allm if EN.sign(m) < 0)
    L = sum(tot[m["id"]] for m in leaves)
    root_v = max(L, T + D)
    nodes, links = [], []
    seen = set()

    def node(name, depth, role, color=None):
        if name not in seen:
            seen.add(name)
            nodes.append({"name": name, "depth": depth, "role": role, **({"itemStyle": {"color": color}} if color else {})})

    ROOT = f"รวม{meta['th']}"
    node(ROOT, 1, "root", meta["color"])
    if D > 0:
        node("Solar / หักออก", 0, "src", "#0ca30c")
        node("จากมิเตอร์หลัก", 0, "src", "#64748b")
        links.append({"source": "Solar / หักออก", "target": ROOT, "value": round(D, 1)})
        links.append({"source": "จากมิเตอร์หลัก", "target": ROOT, "value": round(max(root_v - D, 0), 1)})
    deps: dict[str, dict[str, float]] = {}
    for m in leaves:
        g = (m.get("grp") or "").strip() or "ไม่ระบุหน่วยงาน"
        ln = (m.get("line") or "").strip() or f"{g} · ไม่ระบุไลน์"
        deps.setdefault(g, {})
        deps[g][ln] = deps[g].get(ln, 0.0) + tot[m["id"]]
    rows = []
    for g, lines in sorted(deps.items(), key=lambda kv: -sum(kv[1].values())):
        gv = sum(lines.values())
        if gv <= 0:
            continue
        gname = g if g not in seen else f"{g} (หน่วยงาน)"
        node(gname, 2, "dept")
        links.append({"source": ROOT, "target": gname, "value": round(gv, 1)})
        for ln, v in sorted(lines.items(), key=lambda kv: -kv[1]):
            if v <= 0:
                continue
            lname = ln if ln not in seen else f"{ln} ({g})"
            node(lname, 3, "line")
            links.append({"source": gname, "target": lname, "value": round(v, 1)})
        rows.append({"grp": g, "u": round(gv, 1), "share": round(100 * gv / root_v, 1) if root_v else None,
                     "lines": [{"line": k, "u": round(v, 1)} for k, v in sorted(lines.items(), key=lambda kv: -kv[1])]})
    unm = T + D - L
    if unm > 0.005 * max(root_v, 1) and covered_by:
        node("ไม่ได้วัด / ส่วนกลาง / สูญเสีย", 2, "unm", "#d03b3b")
        links.append({"source": ROOT, "target": "ไม่ได้วัด / ส่วนกลาง / สูญเสีย", "value": round(unm, 1)})
    over = round(100 * (L - (T + D)) / (T + D), 1) if covered_by and T + D > 0 and L > (T + D) * 1.005 else None
    if D <= 0:                                       # ไม่มี Solar → ไม่มีคอลัมน์แหล่งจ่าย เลื่อนทุกโหนดไปทางซ้าย
        for x in nodes:
            x["depth"] -= 1
    return {"kind": kind, "th": meta["th"], "unit": meta["unit"], "icon": meta["icon"], "d0": d0, "d1": d1,
            "nodes": nodes, "links": links, "rows": rows, "total": round(T, 1), "root": round(root_v, 1),
            "unmeasured": round(unm, 1) if unm > 0 and covered_by else 0.0,
            "unm_pct": round(100 * unm / (T + D), 1) if covered_by and T + D > 0 and unm > 0 else None,
            "solar": round(D, 1), "over_pct": over, "has_main": bool(covered_by), "n_meters": len(allm)}


# ───────────────────────── v0.99.50 นำเข้ายอดผลิตจากไฟล์ (CSV / Excel / วางจาก Excel) ─────────────────────────

def _parse_day(v) -> date | None:
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v or "").strip()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T].*)?", s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        m = re.fullmatch(r"(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})", s)
        if not m:
            return None
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2500 if y > 60 else 2000
    if y > 2400:                                                     # พ.ศ. → ค.ศ.
        y -= 543
    try:
        return date(y, mo, d)
    except ValueError:
        return None


def read_prod_rows(raw: bytes | None, filename: str, text: str) -> list[list]:
    """แถวดิบจากไฟล์ .xlsx / .csv หรือข้อความที่วาง (Tab/คอมมา) — คอลัมน์: วันที่ · กะ · หน่วยงาน (ไม่บังคับ) · จำนวน"""
    rows: list[list] = []
    if raw and filename.lower().endswith((".xlsx", ".xlsm")):
        import io

        from openpyxl import load_workbook
        try:
            wb = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
            for r in wb.worksheets[0].iter_rows(values_only=True):
                if any(c not in (None, "") for c in r):
                    rows.append(list(r))
        except Exception:                                # noqa: BLE001
            raise ValidationError(["อ่านไฟล์ Excel ไม่ได้ — บันทึกเป็น .xlsx หรือ .csv แล้วลองใหม่"]) from None
    else:
        import csv
        body = raw.decode("utf-8-sig", errors="replace") if raw else (text or "")
        for ln in body.splitlines():
            if not ln.strip():
                continue
            if "\t" in ln:                                            # วางจาก Excel: แยกด้วย Tab (ตัวเลขมีคอมมาหลักพันได้)
                rows.append([c.strip() for c in ln.split("\t")])
            else:                                                     # CSV: รองรับ "1,200" ในเครื่องหมายคำพูด
                rows.append([c.strip() for c in next(csv.reader([ln], delimiter=";" if ln.count(";") > ln.count(",") else ","))])
    return rows


def import_prod(db, fid: int, rows: list[list], default_grp: str, actor) -> dict:
    """บันทึกยอดผลิตรายกะหลายวัน/หลายหน่วยงานในครั้งเดียว · ข้ามหัวตาราง · บอกบรรทัดที่อ่านไม่ได้"""
    if not fid:
        raise ValidationError(["เลือกโรงงานก่อนนำเข้า"])
    sh = shifts(db, fid)["list"]
    key = {}
    for s in sh:
        key[s["code"].lower()] = s["code"]
        key[s["name"].lower()] = s["code"]
        key[("กะ" + s["name"]).lower()] = s["code"]
    cells: dict[str, dict] = {}
    bad, n = [], 0
    for i, r in enumerate(rows, 1):
        r = [c for c in r if c is not None]
        if len(r) < 3:
            continue
        d = _parse_day(r[0])
        if d is None:
            if i > 1:                                               # บรรทัดแรกที่อ่านวันที่ไม่ได้ = หัวตาราง
                bad.append(f"บรรทัด {i}: วันที่ “{r[0]}”")
            continue
        code = key.get(str(r[1]).strip().lower())
        if not code:
            bad.append(f"บรรทัด {i}: ไม่รู้จักกะ “{r[1]}”")
            continue
        grp = str(r[2]).strip() if len(r) >= 4 else default_grp
        qty = r[3] if len(r) >= 4 else r[2]
        cells.setdefault(grp, {})[(d.isoformat(), code)] = str(qty)
        n += 1
    saved = 0
    for grp, c in cells.items():
        saved += save_prod(db, fid, grp, c, {s["code"] for s in sh}, actor)
    if not n:
        raise ValidationError(["ไม่พบแถวข้อมูล — คอลัมน์: วันที่ · กะ · หน่วยงาน (ไม่บังคับ) · จำนวน" + (f" ({bad[0]})" if bad else "")])
    return {"rows": n, "saved": saved, "groups": sorted(g or "ทั้งโรงงาน" for g in cells), "bad": bad[:10], "n_bad": len(bad)}
