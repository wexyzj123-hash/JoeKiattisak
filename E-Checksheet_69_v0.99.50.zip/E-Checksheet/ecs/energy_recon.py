"""ecs/energy_recon.py — v0.99.50 ความถูกต้องของข้อมูล

reconcile()  กระทบยอด 2 แหล่งต่อมิเตอร์: ค่าอ่านรายวัน (en_readings → EN.series) vs ผลรวมราย 15 นาที (SCADA → energy_live._sums)
             → ต่าง % · สถานะ ตรงกัน / ต่างเล็กน้อย / ต่างมาก / มีแหล่งเดียว / ไม่มีข้อมูล · ยอดรวมต่อโรงงาน
tree()       ผังมิเตอร์แม่–ลูก (ตามกติกาเดียวทั้งระบบ EN.covers): การใช้ของแม่ · ผลรวมลูก · ส่วนที่ไม่ได้วัด/สูญเสีย % · ลูกมากกว่าแม่
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta

from . import energy as EN
from . import energy_live as LV

OK_PCT = 2.0          # ต่างไม่เกิน 2% = ตรงกัน
WARN_PCT = 10.0       # ต่างเกิน 10% = ต่างมาก


def _days(d0: date, d1: date) -> list[date]:
    return [d0 + timedelta(days=i) for i in range((d1 - d0).days + 1)]


def reconcile(db, fid: int | None, kind: str, d0: date, d1: date) -> dict:
    kind = kind if kind in EN.KINDS else "elec"
    if (d1 - d0).days > 61:
        d0 = d1 - timedelta(days=61)
    ms = [m for m in EN.meters(db, fid, kind, True) if (m.get("is_main") or 0) != 2]
    days = _days(d0, d1)
    ser = EN.series(db, ms, d0, d1) if ms else {}
    ids = [m["id"] for m in ms]
    iv: dict[int, dict[str, float]] = {}
    for d in days:                                           # ราย 15 นาที → รวมต่อวัน (ทั้งค่าต่อช่วง และเลขสะสม)
        a = datetime.combine(d, time(0, 0))
        for mid, row in (LV._sums(db, ids, a, a + timedelta(days=1)) if ids else {}).items():
            xs = [v for v in row if v is not None]
            if xs:
                iv.setdefault(mid, {})[d.isoformat()] = sum(xs)
    rows = []
    for m in ms:
        r = {d: x["u"] for d, x in (ser.get(m["id"]) or {}).items() if x.get("u") is not None}
        i = iv.get(m["id"], {})
        both = sorted(set(r) & set(i))
        rb, ib = sum(r[d] for d in both), sum(i[d] for d in both)
        diff = ib - rb
        pct = round(100 * diff / rb, 1) if rb else (None if not ib else 100.0)
        if not r and not i:
            st = "none"
        elif not i:
            st = "only_r"
        elif not r:
            st = "only_i"
        elif pct is not None and abs(pct) <= OK_PCT:
            st = "ok"
        elif pct is not None and abs(pct) <= WARN_PCT:
            st = "warn"
        else:
            st = "bad"
        worst = None
        for d in both:
            dp = 100 * (i[d] - r[d]) / r[d] if r[d] else None
            if dp is not None and (worst is None or abs(dp) > abs(worst[1])):
                worst = (d, round(dp, 1))
        rows.append({"id": m["id"], "label": EN.label(m), "factory_id": m.get("factory_id"), "factory": m.get("factory_name") or "",
                     "grp": m.get("grp") or "", "src": m.get("scada_tag") or "", "r": round(sum(r.values()), 2), "i": round(sum(i.values()), 2),
                     "rb": round(rb, 2), "ib": round(ib, 2), "diff": round(diff, 2), "pct": pct, "st": st,
                     "days_r": len(r), "days_i": len(i), "days_both": len(both), "worst": worst,
                     "per_day": [{"day": d.isoformat(), "r": r.get(d.isoformat()), "i": i.get(d.isoformat())} for d in days]})
    order = {"bad": 0, "warn": 1, "only_r": 2, "only_i": 3, "ok": 4, "none": 5}
    rows.sort(key=lambda x: (order[x["st"]], -abs(x["diff"])))
    cnt = {k: sum(1 for x in rows if x["st"] == k) for k in order}
    rb, ib = sum(x["rb"] for x in rows), sum(x["ib"] for x in rows)
    facs: dict = {}
    for x in rows:
        f = facs.setdefault(x["factory_id"], {"name": x["factory"], "rb": 0.0, "ib": 0.0, "n": 0, "n_bad": 0})
        f["rb"] += x["rb"]
        f["ib"] += x["ib"]
        f["n"] += 1
        f["n_bad"] += x["st"] in ("bad", "warn")
    for f in facs.values():
        f["pct"] = round(100 * (f["ib"] - f["rb"]) / f["rb"], 1) if f["rb"] else None
    meta = EN.KINDS[kind]
    return {"kind": kind, "th": meta["th"], "unit": meta["unit"], "d0": d0, "d1": d1, "days": [d.isoformat() for d in days], "rows": rows, "cnt": cnt,
            "rb": round(rb, 1), "ib": round(ib, 1), "pct": round(100 * (ib - rb) / rb, 1) if rb else None, "facs": list(facs.values()),
            "n": len(rows), "match": round(100 * cnt["ok"] / max(1, cnt["ok"] + cnt["warn"] + cnt["bad"]), 1)}


def tree(db, fid: int | None, kind: str, d0: date, d1: date) -> dict:
    kind = kind if kind in EN.KINDS else "elec"
    ms = EN.meters(db, fid, kind, True)
    by = {m["id"]: m for m in ms}
    cv = EN.covers(ms)
    ser = EN.series(db, ms, d0, d1) if ms else {}
    use = {m["id"]: sum(x["u"] for x in (ser.get(m["id"]) or {}).values() if x.get("u") is not None) for m in ms}
    has = {m["id"]: any(x.get("u") is not None for x in (ser.get(m["id"]) or {}).values()) for m in ms}
    kids: dict[int, list[int]] = {}
    roots = []
    for m in ms:
        if (m.get("is_main") or 0) == 2:
            continue
        ps = [p for p in (cv.get(m["id"]) or set()) if p in by and (by[p].get("is_main") or 0) != 2]
        if ps:
            for p in ps:
                kids.setdefault(p, []).append(m["id"])
        else:
            roots.append(m["id"])

    def node(mid: int, depth: int, seen: frozenset) -> dict:
        m = by[mid]
        ch = [node(c, depth + 1, seen | {mid}) for c in sorted(kids.get(mid, []), key=lambda c: -use.get(c, 0)) if c not in seen]
        u = use.get(mid, 0.0)
        cs = sum(EN.sign(by[c["id"]]) * c["u"] for c in ch)
        gap = u - cs if ch else None
        pct = round(100 * gap / u, 1) if ch and u else None
        flag = None
        if ch and has.get(mid):
            if pct is not None and pct < -2:
                flag = "over"            # ลูกรวมมากกว่าแม่ → ตรวจ CT / การตั้งมิเตอร์แม่
            elif pct is not None and pct > 15:
                flag = "loss"            # ไม่ได้วัด / สูญเสียสูง
        if not has.get(mid):
            flag = "nodata"
        return {"id": mid, "label": EN.label(m), "role": m.get("is_main") or 0, "grp": m.get("grp") or "", "line": m.get("line") or "",
                "u": round(u, 2), "has": has.get(mid), "kids": ch, "kids_u": round(cs, 2) if ch else None, "gap": round(gap, 2) if gap is not None else None,
                "pct": pct, "flag": flag, "depth": depth, "explicit": bool(m.get("parent_id"))}
    nodes = [node(r, 0, frozenset()) for r in sorted(roots, key=lambda r: (-(by[r].get("is_main") == 1), -use.get(r, 0)))]
    excluded = [{"id": m["id"], "label": EN.label(m), "u": round(use.get(m["id"], 0.0), 2)} for m in ms if (m.get("is_main") or 0) == 2]

    def walk(ns):
        for n in ns:
            yield n
            yield from walk(n["kids"])
    flat = list(walk(nodes))
    parents = [n for n in flat if n["kids"]]
    meta = EN.KINDS[kind]
    return {"kind": kind, "th": meta["th"], "unit": meta["unit"], "d0": d0, "d1": d1, "nodes": nodes, "excluded": excluded,
            "n": len(ms), "n_parents": len(parents), "n_over": sum(1 for n in parents if n["flag"] == "over"),
            "n_loss": sum(1 for n in parents if n["flag"] == "loss"), "n_nodata": sum(1 for n in flat if n["flag"] == "nodata"),
            "total": round(sum(EN.sign(by[n["id"]]) * n["u"] for n in nodes), 2),
            "unmeasured": round(sum(n["gap"] for n in parents if n["gap"] and n["gap"] > 0 and n["depth"] == 0), 2)}
