"""ecs/energy.py — Energy Data: มิเตอร์ไฟฟ้า / ลม / น้ำ / น้ำ RO / ชั่วโมงเดินเครื่อง

ข้อมูลหลัก
  en_meters    มิเตอร์ 1 ตัว = (โรงงาน, ประเภท, key) — key มาจากหัวตาราง Excel เดิม จึงนำเข้าไฟล์ซ้ำได้ไม่เกิดมิเตอร์ซ้ำ
  en_readings  ค่าอ่านสะสม (หน้าปัด) รายวัน 1 ค่า/มิเตอร์/วัน
  en_imports   ประวัติการนำเข้าไฟล์

การใช้ต่อวัน = (ค่าวันนี้ − ค่าอ่านครั้งก่อนหน้า) × ตัวคูณ
  - ค่าครั้งก่อนอยู่ห่างหลายวัน → ยอดรวมนับเป็นของวันนี้ (flag gap)
  - ค่าน้อยกว่าครั้งก่อน → มิเตอร์ถูกรีเซ็ต/เปลี่ยน/อ่านผิด (flag reset, ไม่นำมารวม)
  - สูงผิดปกติ ≥ 4 เท่าของค่ากลาง 14 วันล่าสุด → flag spike
ยอดรวมของโรงงาน/ประเภท = มิเตอร์หลัก (is_main) ถ้ามี ไม่งั้นรวมทุกตัว (กันนับซ้ำมิเตอร์หลัก + มิเตอร์ย่อย)
"""
from __future__ import annotations

import calendar
import json
import re
import statistics
from datetime import date, datetime, timedelta

from . import services as S
from .services import ts

KINDS = {
    "elec": {"th": "ไฟฟ้า", "unit": "kWh", "icon": "⚡", "color": "#f59e0b"},
    "air": {"th": "ลมอัด", "unit": "m³", "icon": "💨", "color": "#0ea5e9"},
    "water": {"th": "น้ำใช้", "unit": "m³", "icon": "💧", "color": "#2563eb"},
    "ro": {"th": "น้ำ RO", "unit": "m³", "icon": "🚰", "color": "#14b8a6"},
    "hours": {"th": "ชั่วโมงเดินเครื่อง", "unit": "ชม.", "icon": "⏱", "color": "#8b5cf6"},
}
KIND_ORDER = ["elec", "air", "water", "ro", "hours"]
_DEFAULT_KINDS = [(k, v) for k, v in KINDS.items()]
PROTECTED_KINDS = ("elec",)        # ใช้กับบิลค่าไฟ/CO₂/สัดส่วนมิเตอร์ย่อย — เปลี่ยนชื่อ/สีได้ แต่ลบไม่ได้
DEFAULTS = {"ef_elec": 0.4999, "price_elec": 4.2, "spike_x": 4.0, "target_pct": 5.0,   # v0.69 เป้าประหยัด % จากค่าเฉลี่ยเดือนก่อน (เส้น Target บน Dashboard)
            # v0.63 เกณฑ์ตรวจความผิดปกติ (ปรับได้ที่หน้า ตั้งค่า)
            "z_high": 3.0, "z_warn": 2.2, "stuck_days": 3, "missing_days": 3, "holiday_ratio": 0.70,
            "baseload_rise": 1.30, "balance_tol": 0.15, "min_u": 5.0, "sunday_off": 1,
            # v0.64 จดมิเตอร์หน้างาน
            "photo_rule": 1,          # 0 ไม่บังคับ · 1 บังคับเมื่อค่าผิดปกติ/เปลี่ยนมิเตอร์ · 2 บังคับทุกค่า
            "tech_back_days": 0,      # ช่างแก้ค่าย้อนหลังได้กี่วัน (0 = ไม่จำกัด)
            "scada_hh": 8, "scada_mm": 0, "scada_window": 90,   # เวลาอ่านค่าจาก SCADA ต่อวัน ± นาที
            "ocr": 1,                 # อ่านตัวเลขจากรูปหน้าปัด
            "usage_day": 1,           # v0.89 1 = การใช้ลงวันที่ใช้จริง (ค่าอ่านวันถัดไป − วันนี้) · 0 = ลงวันที่อ่านค่า (แบบเดิม)
            "split_gap": 1,
            "wx_lat": 0.0, "wx_lon": 0.0}  # v0.99.50 พิกัดโรงงานสำหรับดึงอุณหภูมิอากาศ (0 = ไม่ดึง)           # v0.90 ค่าอ่านห่างหลายวัน → 1 เฉลี่ยลงทุกวัน (ทุกหน้าเหมือนกัน) · 0 รวมเป็นก้อนเดียว

DDL = """
CREATE TABLE IF NOT EXISTS en_meters (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factory_id  INTEGER REFERENCES factories(id),
    kind        TEXT NOT NULL,
    key         TEXT NOT NULL,
    code        TEXT NOT NULL DEFAULT '',
    name        TEXT NOT NULL DEFAULT '',
    grp         TEXT NOT NULL DEFAULT '',
    unit        TEXT NOT NULL DEFAULT '',
    price       REAL,
    multiplier  REAL NOT NULL DEFAULT 1,
    is_main     INTEGER NOT NULL DEFAULT 0,
    active      INTEGER NOT NULL DEFAULT 1,
    sort_no     INTEGER NOT NULL DEFAULT 0,
    note        TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL,
    UNIQUE (factory_id, kind, key)
);
CREATE TABLE IF NOT EXISTS en_readings (
    meter_id    INTEGER NOT NULL REFERENCES en_meters(id) ON DELETE CASCADE,
    day         TEXT NOT NULL,
    value       REAL NOT NULL,
    u_override  REAL,
    src         TEXT NOT NULL DEFAULT 'web',
    user_id     INTEGER,
    updated_at  TEXT NOT NULL,
    PRIMARY KEY (meter_id, day)
);
CREATE INDEX IF NOT EXISTS idx_enr_day ON en_readings(day);
CREATE TABLE IF NOT EXISTS en_import_rows (
    import_id   INTEGER NOT NULL,
    meter_id    INTEGER NOT NULL,
    day         TEXT NOT NULL,
    old_value   REAL,
    new_value   REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_enir ON en_import_rows(import_id);
CREATE TABLE IF NOT EXISTS en_import_meters (
    import_id   INTEGER NOT NULL,
    meter_id    INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS en_kinds (
    key         TEXT PRIMARY KEY,
    th          TEXT NOT NULL,
    unit        TEXT NOT NULL DEFAULT '',
    icon        TEXT NOT NULL DEFAULT '•',
    color       TEXT NOT NULL DEFAULT '#64748b',
    sort_no     INTEGER NOT NULL DEFAULT 0,
    active      INTEGER NOT NULL DEFAULT 1,
    price       REAL,                    -- ราคาเริ่มต้น/หน่วย (มิเตอร์ที่ไม่ได้ตั้งราคาเอง)
    ef          REAL,                    -- kgCO₂e ต่อหน่วย (ว่าง = ไม่คิด CO₂)
    created_at  TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS en_imports (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    filename    TEXT NOT NULL,
    factory_id  INTEGER,
    kind        TEXT,
    year        INTEGER,
    user_id     INTEGER,
    created_at  TEXT NOT NULL,
    n_meters    INTEGER NOT NULL DEFAULT 0,
    n_new       INTEGER NOT NULL DEFAULT 0,
    n_readings  INTEGER NOT NULL DEFAULT 0,
    n_changed   INTEGER NOT NULL DEFAULT 0,
    months      TEXT NOT NULL DEFAULT ''
);
"""


def ensure(db) -> None:
    db.executescript(DDL)
    if not db.execute("SELECT 1 FROM en_kinds LIMIT 1").fetchone():
        for i, (k, v) in enumerate(_DEFAULT_KINDS):
            db.execute("INSERT OR IGNORE INTO en_kinds(key, th, unit, icon, color, sort_no, created_at) VALUES (?,?,?,?,?,?,?)",
                       (k, v["th"], v["unit"], v["icon"], v["color"], (i + 1) * 10, ts(S.now_dt())))
    load_kinds(db)
    cols = {r[1] for r in db.execute("PRAGMA table_info(en_readings)")}
    if "u_override" not in cols:
        db.execute("ALTER TABLE en_readings ADD COLUMN u_override REAL")
    mcols = {r[1] for r in db.execute("PRAGMA table_info(en_meters)")}
    icols = {r[1] for r in db.execute("PRAGMA table_info(en_imports)")}
    for col, typ in (("mode", "TEXT NOT NULL DEFAULT 'all'"), ("undone_at", "TEXT"), ("undone_by", "INTEGER")):
        if col not in icols:
            db.execute(f"ALTER TABLE en_imports ADD COLUMN {col} {typ}")
    for col in ("ext", "location", "scada_tag"):              # v0.63 ทะเบียนมิเตอร์: ตำแหน่ง/จ่ายไฟให้ · tag SCADA
        if col not in mcols:
            db.execute(f"ALTER TABLE en_meters ADD COLUMN {col} TEXT NOT NULL DEFAULT ''")
    if "parent_id" not in mcols:                              # v0.90 มิเตอร์แม่ (โครงสร้างวัดซ้อน)
        db.execute("ALTER TABLE en_meters ADD COLUMN parent_id INTEGER")
    from .energy_ops import ensure_ops
    ensure_ops(db)
    from .energy_field import ensure_field
    ensure_field(db)
    from .energy_forms import ensure_forms
    ensure_forms(db)
    from .energy_cost import ensure_cost
    ensure_cost(db)
    from .energy_struct import ensure_struct
    ensure_struct(db)
    from .energy_src import ensure_src
    ensure_src(db)
    from .energy_power import ensure as ensure_power
    ensure_power(db)


# ───────────────────────── หมวดหมู่ (ประเภทมิเตอร์) — ผู้ใช้เพิ่ม/แก้ได้เอง ─────────────────────────

def load_kinds(db) -> None:
    """โหลดหมวดหมู่จากฐานข้อมูลเข้าตัวแปรกลาง (ทุกหน้าที่เรียก ensure ได้ค่าล่าสุดเสมอ)"""
    rows = db.execute("SELECT * FROM en_kinds ORDER BY sort_no, key").fetchall()
    if not rows:
        return
    KINDS.clear()
    for r in rows:
        KINDS[r["key"]] = {"th": r["th"], "unit": r["unit"], "icon": r["icon"] or "•", "color": r["color"] or "#64748b",
                           "active": r["active"], "price": r["price"], "ef": r["ef"], "sort_no": r["sort_no"]}
    KIND_ORDER[:] = [r["key"] for r in rows if r["active"]]


def kinds_admin(db) -> list[dict]:
    ensure(db)
    out = []
    for r in db.execute("""SELECT k.*, (SELECT COUNT(*) FROM en_meters m WHERE m.kind=k.key) AS n_meters,
                                  (SELECT COUNT(*) FROM en_meters m WHERE m.kind=k.key AND m.active=1) AS n_active
                           FROM en_kinds k ORDER BY k.sort_no, k.key"""):
        out.append(dict(r, protected=r["key"] in PROTECTED_KINDS))
    return out


_COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")


def save_kind(db, data: dict, actor, key: str | None = None) -> str:
    ensure(db)
    th = str(data.get("th") or "").strip()[:40]
    if not th:
        raise S.ValidationError("กรุณาตั้งชื่อหมวดหมู่")
    unit = str(data.get("unit") or "").strip()[:20]
    if not unit:
        raise S.ValidationError("กรุณาระบุหน่วย (เช่น kWh, m³, ลิตร, kg)")
    icon = str(data.get("icon") or "•").strip()[:4] or "•"
    color = str(data.get("color") or "#64748b").strip()
    if not _COLOR_RE.match(color):
        raise S.ValidationError("สีไม่ถูกต้อง")

    def num(k):
        v = str(data.get(k) if data.get(k) is not None else "").replace(",", "").strip()
        if v == "":
            return None
        try:
            x = float(v)
        except ValueError:
            raise S.ValidationError(f"{'ราคา' if k == 'price' else 'ค่า EF'} ต้องเป็นตัวเลข") from None
        if x < 0:
            raise S.ValidationError("ค่าต้องไม่ติดลบ")
        return x
    price, ef = num("price"), num("ef")
    try:
        sort_no = int(str(data.get("sort_no") or "0").strip() or 0)
    except ValueError:
        sort_no = 0
    active = 1
    if "active_present" in data:
        active = 1 if data.get("active") in ("1", "on", 1, True) else 0
    if db.execute("SELECT 1 FROM en_kinds WHERE th=? AND key<>?", (th, key or "")).fetchone():
        raise S.ValidationError("มีหมวดหมู่ชื่อนี้แล้ว")
    stamp = ts(S.now_dt())
    if key:
        before = db.execute("SELECT * FROM en_kinds WHERE key=?", (key,)).fetchone()
        if not before:
            raise S.ValidationError("ไม่พบหมวดหมู่")
        if key in PROTECTED_KINDS and not active:
            raise S.ValidationError("หมวดไฟฟ้าใช้กับบิลค่าไฟ/CO₂ — ปิดใช้งานไม่ได้")
        db.execute("UPDATE en_kinds SET th=?, unit=?, icon=?, color=?, sort_no=?, active=?, price=?, ef=? WHERE key=?",
                   (th, unit, icon, color, sort_no, active, price, ef, key))
        if before["unit"] != unit and data.get("apply_unit"):
            db.execute("UPDATE en_meters SET unit=? WHERE kind=? AND unit=?", (unit, key, before["unit"]))
        S.audit(db, actor, "energy_kind", "en_kinds", None, before=dict(before),
                after={"key": key, "th": th, "unit": unit, "icon": icon, "color": color, "active": active, "price": price, "ef": ef})
    else:
        base = re.sub(r"[^a-z0-9]+", "_", str(data.get("key") or "").lower()).strip("_")[:20] or "k"
        key = base
        n = 1
        while db.execute("SELECT 1 FROM en_kinds WHERE key=?", (key,)).fetchone():
            n += 1
            key = f"{base}{n}"
        if not sort_no:
            sort_no = (db.execute("SELECT MAX(sort_no) FROM en_kinds").fetchone()[0] or 0) + 10
        db.execute("""INSERT INTO en_kinds(key, th, unit, icon, color, sort_no, active, price, ef, created_at)
                      VALUES (?,?,?,?,?,?,?,?,?,?)""", (key, th, unit, icon, color, sort_no, active, price, ef, stamp))
        S.audit(db, actor, "energy_kind_new", "en_kinds", None, after={"key": key, "th": th, "unit": unit})
    load_kinds(db)
    return key


def delete_kind(db, key: str, actor) -> None:
    ensure(db)
    if key in PROTECTED_KINDS:
        raise S.ValidationError("หมวดไฟฟ้าลบไม่ได้")
    r = db.execute("SELECT * FROM en_kinds WHERE key=?", (key,)).fetchone()
    if not r:
        raise S.ValidationError("ไม่พบหมวดหมู่")
    if db.execute("SELECT 1 FROM en_meters WHERE kind=?", (key,)).fetchone():
        raise S.ValidationError("ยังมีมิเตอร์ในหมวดนี้ — ย้ายมิเตอร์ไปหมวดอื่นหรือปิดใช้งานหมวดแทน")
    if db.execute("SELECT 1 FROM en_cases WHERE kind=?", (key,)).fetchone():
        raise S.ValidationError("มีเคสความผิดปกติอ้างอิงหมวดนี้ — ปิดใช้งานหมวดแทนการลบ")
    db.execute("DELETE FROM en_kinds WHERE key=?", (key,))
    S.audit(db, actor, "energy_kind_del", "en_kinds", None, before=dict(r))
    load_kinds(db)


def sections(db, factory_id: int | None = None, kind: str | None = None) -> list[dict]:
    """Section (กลุ่ม) ที่ใช้อยู่ + จำนวนมิเตอร์ — ใช้แนะนำตอนกรอก และเปลี่ยนชื่อ/รวม Section"""
    ensure(db)
    w, a = ["1=1"], []
    if factory_id:
        w.append("m.factory_id=?")
        a.append(factory_id)
    if kind:
        w.append("m.kind=?")
        a.append(kind)
    return [dict(r) for r in db.execute(f"""SELECT m.factory_id, f.name AS factory_name, m.kind, m.grp, COUNT(*) AS n,
                                             SUM(m.active) AS n_active FROM en_meters m LEFT JOIN factories f ON f.id=m.factory_id
                                             WHERE {' AND '.join(w)} GROUP BY m.factory_id, m.kind, m.grp
                                             ORDER BY f.sort_no, m.kind, m.grp""", a)]


def rename_section(db, factory_id, kind: str, old: str, new: str, actor, scope_factory=None) -> int:
    ensure(db)
    new = (new or "").strip()[:80]
    if scope_factory and factory_id and int(factory_id) != int(scope_factory):
        raise S.ValidationError("แก้ได้เฉพาะ Section ของโรงงานตัวเอง")
    n = db.execute("UPDATE en_meters SET grp=? WHERE factory_id IS ? AND kind=? AND grp=?",
                   (new, int(factory_id) if factory_id else None, kind, old or "")).rowcount
    S.audit(db, actor, "energy_section", "en_meters", None, before={"factory_id": factory_id, "kind": kind, "grp": old},
            after={"grp": new, "meters": n})
    return n


def delete_meter(db, mid: int, actor) -> None:
    m = meter(db, mid)
    if not m:
        raise S.ValidationError("ไม่พบมิเตอร์")
    if db.execute("SELECT 1 FROM en_readings WHERE meter_id=? LIMIT 1", (mid,)).fetchone():
        raise S.ValidationError("มิเตอร์นี้มีค่าอ่านแล้ว — ลบไม่ได้ (ปิดใช้งานแทน เพื่อเก็บประวัติ)")
    db.execute("DELETE FROM en_meters WHERE id=?", (mid,))
    for t in ("en_skips", "en_swaps", "en_fix_log"):
        db.execute(f"DELETE FROM {t} WHERE meter_id=?", (mid,))
    S.audit(db, actor, "energy_meter_del", "en_meters", mid, before=m)


# ───────────────────────── ตั้งค่า ─────────────────────────

def settings(db) -> dict:
    cfg = dict(DEFAULTS)
    row = db.execute("SELECT value FROM cs_meta WHERE key='energy'").fetchone()
    if row and row[0]:
        try:
            cfg.update({k: float(v) for k, v in json.loads(row[0]).items() if k in DEFAULTS})
        except (ValueError, TypeError):
            pass
    return cfg


def save_settings(db, data: dict, actor) -> dict:
    cfg = settings(db)
    for k in DEFAULTS:
        if k in data and str(data[k]).strip() != "":
            try:
                v = float(data[k])
            except ValueError:
                raise S.ValidationError(f"ค่า {k} ต้องเป็นตัวเลข") from None
            if v < 0:
                raise S.ValidationError("ค่าต้องไม่ติดลบ")
            if k == "scada_hh" and v > 23 or k == "scada_mm" and v > 59 or k == "photo_rule" and v > 2:
                raise S.ValidationError("ค่าเวลา/ตัวเลือกไม่ถูกต้อง")
            cfg[k] = v
    db.execute("INSERT OR REPLACE INTO cs_meta(key, value) VALUES('energy', ?)", (json.dumps(cfg),))
    S.audit(db, actor, "energy_settings", "cs_meta", None, after=cfg)
    return cfg


# ───────────────────────── มิเตอร์ ─────────────────────────

def meters(db, factory_id: int | None = None, kind: str | None = None, active_only: bool = True,
           project_id: int | None = None, grp: str | None = None, line: str | None = None) -> list[dict]:
    ensure(db)
    w, a = ["1=1"], []
    if active_only:
        w.append("m.active=1")
    if factory_id:
        w.append("m.factory_id=?")
        a.append(factory_id)
    if kind:
        w.append("m.kind=?")
        a.append(kind)
    rows = [dict(r) for r in db.execute(f"""SELECT m.*, f.name AS factory_name, f.sort_no AS f_sort, p.name AS project_name,
                                            p.color AS project_color FROM en_meters m
                                            LEFT JOIN factories f ON f.id=m.factory_id LEFT JOIN en_projects p ON p.id=m.project_id
                                            WHERE {' AND '.join(w)} ORDER BY f.sort_no, m.kind, m.sort_no, m.id""", a)]
    cv = covers(rows)                                    # v0.90 โครงสร้างวัดซ้อนจากชุดเต็มของโรงงาน/ประเภท (ก่อนกรอง)
    for m in rows:
        m["_cv"] = tuple(sorted(cv.get(m["id"], set())))
    if project_id or grp or line:
        from .energy_struct import apply_filter
        rows = apply_filter(rows, project_id, grp, line)
    return rows


def meter(db, mid: int) -> dict | None:
    ensure(db)
    r = db.execute("""SELECT m.*, f.name AS factory_name, p.name AS project_name, p.color AS project_color FROM en_meters m
                      LEFT JOIN factories f ON f.id=m.factory_id LEFT JOIN en_projects p ON p.id=m.project_id
                      WHERE m.id=?""", (mid,)).fetchone()
    return dict(r) if r else None


def label(m: dict) -> str:
    code, name = (m.get("code") or "").strip(), (m.get("name") or "").strip()
    if code and name and (name == code or name.startswith(code)):
        return name
    return " ".join(x for x in (code, name) if x).strip() or m.get("key", "")


def auto_main(text: str) -> bool:
    """มิเตอร์หลักขาเข้า (ใช้คิดยอดรวม): น้ำเข้าจากนิคม / Raw water / MAIN METER ลม HI-LOW — ไม่นับที่เขียนว่า ERROR"""
    t = text.upper()
    if "ERROR" in t:
        return False
    return "นิคม" in text or "RAW WATER" in t or ("MAIN" in t and any(k in t for k in ("PRESSURE", "LOW", "HIGH", "HI ")))


def upsert_meter(db, factory_id, kind, key, code="", name="", grp="", unit="", price=None, sort_no=0) -> tuple[int, bool]:
    ensure(db)
    r = db.execute("SELECT id FROM en_meters WHERE factory_id IS ? AND kind=? AND key=?", (factory_id, kind, key)).fetchone()
    if r:
        if price is not None:
            db.execute("UPDATE en_meters SET price=COALESCE(price, ?) WHERE id=?", (price, r[0]))
        return r[0], False
    mid = db.execute("""INSERT INTO en_meters(factory_id, kind, key, code, name, grp, unit, price, is_main, sort_no, created_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                     (factory_id, kind, key, code, name, grp, unit or KINDS[kind]["unit"], price,
                      1 if auto_main(f"{grp} {code} {name}") else 0, sort_no, ts(S.now_dt()))).lastrowid
    return mid, True


def save_meter(db, mid: int | None, data: dict, actor) -> int:
    ensure(db)
    kind = data.get("kind") or (meter(db, mid) or {}).get("kind")
    if kind not in KINDS:
        raise S.ValidationError("ประเภทมิเตอร์ไม่ถูกต้อง")
    name = str(data.get("name") or "").strip()[:120]
    code = str(data.get("code") or "").strip()[:60]
    if not (name or code):
        raise S.ValidationError("กรุณาระบุรหัสหรือชื่อมิเตอร์")

    def num(k, default=None):
        v = str(data.get(k) if data.get(k) is not None else "").strip()
        if v == "":
            return default
        try:
            return float(v)
        except ValueError:
            raise S.ValidationError(f"{k} ต้องเป็นตัวเลข") from None
    mult = num("multiplier", 1.0) or 1.0
    vals = {"code": code, "name": name, "grp": str(data.get("grp") or "").strip()[:80],
            "unit": str(data.get("unit") or KINDS[kind]["unit"]).strip()[:20], "price": num("price"),
            "multiplier": mult, "is_main": {"1": 1, "on": 1, "-1": -1, "2": 2}.get(str(data.get("is_main")), 0),
            "active": (1 if data.get("active") in (1, "1", "on", True) else 0) if "active_present" in data else
            (0 if data.get("active") in (0, "0", False) else 1), "note": str(data.get("note") or "").strip()[:300],
            "location": str(data.get("location") or "").strip()[:200], "scada_tag": str(data.get("scada_tag") or "").strip()[:80]}
    if "line" in data:
        vals["line"] = str(data.get("line") or "").strip()[:80]
    if "project_id" in data:
        pv = str(data.get("project_id") or "").strip()
        if pv and not db.execute("SELECT 1 FROM en_projects WHERE id=?", (pv,)).fetchone():
            raise S.ValidationError("ไม่พบ Project")
        vals["project_id"] = int(pv) if pv else None
    # v0.64 ผูกเครื่อง (แจ้งซ่อม) · แหล่ง SCADA · จำนวนหลักหน้าปัด — แก้เฉพาะเมื่อฟอร์มส่งมา
    for k in ("equipment_id", "scada_source_id", "digits"):
        if k in data:
            v = str(data.get(k) or "").strip()
            if v and not v.isdigit():
                raise S.ValidationError(f"{k} ไม่ถูกต้อง")
            vals[k] = int(v) if v and int(v) > 0 else None
    if "parent_id" in data:                                   # v0.90 มิเตอร์แม่ (ว่าง = ตามกติกาอัตโนมัติ)
        pv = str(data.get("parent_id") or "").strip()
        vals["parent_id"] = int(pv) if pv.isdigit() and int(pv) > 0 else None
    if vals.get("digits") and not 3 <= vals["digits"] <= 12:
        raise S.ValidationError("จำนวนหลักหน้าปัดต้องอยู่ระหว่าง 3–12")
    if vals.get("equipment_id") and not db.execute("SELECT 1 FROM equipment WHERE id=?", (vals["equipment_id"],)).fetchone():
        raise S.ValidationError("ไม่พบเครื่อง/ตู้ที่เลือก")
    if mid:
        before = meter(db, mid)
        if not before:
            raise S.ValidationError("ไม่พบมิเตอร์")
        if vals.get("parent_id"):
            check_parent(db, mid, vals["parent_id"], kind, int(data["factory_id"]) if str(data.get("factory_id") or "").isdigit() else before["factory_id"])
        # ย้ายหมวดหมู่ / โรงงาน (ถ้าฟอร์มส่งมา)
        nf = before["factory_id"]
        if "factory_id" in data and str(data.get("factory_id") or "").isdigit():
            nf = int(data["factory_id"])
        if kind != before["kind"] or nf != before["factory_id"]:
            if db.execute("SELECT 1 FROM en_meters WHERE factory_id IS ? AND kind=? AND key=? AND id<>?",
                          (nf, kind, before["key"], mid)).fetchone():
                raise S.ValidationError("หมวด/โรงงานปลายทางมีมิเตอร์ชื่อเดียวกันอยู่แล้ว")
            vals["kind"], vals["factory_id"] = kind, nf
        db.execute(f"UPDATE en_meters SET {', '.join(k + '=?' for k in vals)} WHERE id=?", [*vals.values(), mid])
        from .energy_struct import ensure_catalog
        ensure_catalog(db, vals.get("factory_id", before["factory_id"]), vals["grp"], vals.get("line", before.get("line") or ""))
        S.audit(db, actor, "energy_meter", "en_meters", mid, before=before, after=vals)
        return mid
    fid = int(data.get("factory_id") or 0) or None
    key = f"manual:{code or name}"
    if db.execute("SELECT 1 FROM en_meters WHERE factory_id IS ? AND kind=? AND key=?", (fid, kind, key)).fetchone():
        raise S.ValidationError("มีมิเตอร์รหัส/ชื่อนี้ในโรงงานและประเภทเดียวกันแล้ว")
    mid = db.execute("""INSERT INTO en_meters(factory_id, kind, key, code, name, grp, unit, price, multiplier, is_main, active, note,
                        location, scada_tag, sort_no, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (fid, kind, key, vals["code"], vals["name"], vals["grp"], vals["unit"], vals["price"], mult,
                      vals["is_main"], vals["active"], vals["note"], vals["location"], vals["scada_tag"], 999,
                      ts(S.now_dt()))).lastrowid
    if vals.get("parent_id"):
        check_parent(db, mid, vals["parent_id"], kind, fid)
    for k in ("equipment_id", "scada_source_id", "digits", "project_id", "line", "parent_id"):
        if vals.get(k):
            db.execute(f"UPDATE en_meters SET {k}=? WHERE id=?", (vals[k], mid))
    from .energy_struct import ensure_catalog
    ensure_catalog(db, fid, vals["grp"], vals.get("line", ""))
    S.audit(db, actor, "energy_meter_new", "en_meters", mid, after=dict(vals, kind=kind, factory_id=fid))
    return mid


def check_parent(db, mid: int | None, pid: int, kind: str, factory_id) -> None:
    """มิเตอร์แม่ต้องเป็นโรงงาน/ประเภทเดียวกัน และไม่วนกลับมาที่ตัวเอง"""
    p = db.execute("SELECT id, kind, factory_id, parent_id FROM en_meters WHERE id=?", (pid,)).fetchone()
    if not p:
        raise S.ValidationError("ไม่พบมิเตอร์แม่")
    if p["kind"] != kind or p["factory_id"] != factory_id:
        raise S.ValidationError("มิเตอร์แม่ต้องเป็นโรงงานและประเภทเดียวกัน")
    seen, cur = set(), pid
    while cur:
        if cur == mid or cur in seen:
            raise S.ValidationError("มิเตอร์แม่วนกลับมาที่มิเตอร์นี้")
        seen.add(cur)
        r = db.execute("SELECT parent_id FROM en_meters WHERE id=?", (cur,)).fetchone()
        cur = r[0] if r else None


def children(db, mid: int) -> list[dict]:
    """มิเตอร์ที่มิเตอร์นี้ครอบอยู่ (ตั้งเอง + ตามกติกาอัตโนมัติ)"""
    m = meter(db, mid)
    if not m:
        return []
    ms = meters(db, m["factory_id"], m["kind"])
    cv = covers(ms)
    return [x for x in ms if mid in cv.get(x["id"], set())]


# ───────────────────────── ค่าอ่าน ─────────────────────────

def set_reading(db, mid: int, day: str, value, actor, src="web") -> str:
    """บันทึก/แก้/ลบ (value ว่าง) ค่าอ่านของวัน → 'new' | 'changed' | 'same' | 'deleted' | 'none'"""
    old = db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (mid, day)).fetchone()
    if value is None or str(value).strip() == "":
        if old:
            db.execute("DELETE FROM en_readings WHERE meter_id=? AND day=?", (mid, day))
            S.audit(db, actor, "energy_reading_del", "en_readings", mid, before={"day": day, "value": old[0]})
            return "deleted"
        return "none"
    try:
        v = float(str(value).replace(",", ""))
    except ValueError:
        raise S.ValidationError(f"ค่าอ่าน '{value}' ไม่ใช่ตัวเลข") from None
    if v < 0:
        raise S.ValidationError("ค่าอ่านต้องไม่ติดลบ")
    if old and abs(old[0] - v) < 1e-9:
        return "same"
    db.execute("""INSERT INTO en_readings(meter_id, day, value, src, user_id, updated_at) VALUES (?,?,?,?,?,?)
                  ON CONFLICT(meter_id, day) DO UPDATE SET value=excluded.value, src=excluded.src,
                  user_id=excluded.user_id, updated_at=excluded.updated_at""", (mid, day, v, src, actor, ts(S.now_dt())))
    if old and src == "web":
        S.audit(db, actor, "energy_reading", "en_readings", mid, before={"day": day, "value": old[0]}, after={"day": day, "value": v})
    return "changed" if old else "new"


def readings(db, meter_ids: list[int], d_from: date, d_to: date, lookback: int = 45, lookahead: int = 0) -> dict[int, list[tuple[str, float]]]:
    """{meter_id: [(day, value)]} เรียงตามวัน รวมค่าก่อนช่วง (lookback วัน) ไว้คำนวณวันแรก · lookahead = ค่าหลังช่วง (นับวันที่ใช้จริง)"""
    out: dict[int, list] = {m: [] for m in meter_ids}
    if not meter_ids:
        return out
    for i in range(0, len(meter_ids), 400):
        chunk = meter_ids[i:i + 400]
        for r in db.execute(f"""SELECT meter_id, day, value, u_override FROM en_readings WHERE meter_id IN ({','.join('?' * len(chunk))})
                                AND day>=? AND day<=? ORDER BY meter_id, day""",
                            [*chunk, (d_from - timedelta(days=lookback)).isoformat(),
                             min(d_to + timedelta(days=lookahead), S.now_dt().date()).isoformat()]):   # v0.99.37 ค่าลงวันในอนาคต (ผิด) ไม่ใช้คำนวณ
            out[r[0]].append((r[1], r[2], r[3]))
    return out


BAD_U = 10_000_000.0                      # v0.88 การใช้ต่อวันเกินนี้ = ค่าอ่านเพี้ยน (เช่น register เสีย 2,157,641,728) → ไม่นับ


def usage(rows: list[tuple], mult: float, d_from: date, d_to: date, spike_x: float = 4.0, split: bool = False,
          bad_u: float = BAD_U, actual: bool = False) -> dict[str, dict]:
    """{day: {u, flag, gap, v}} การใช้รายวันจากค่าอ่าน
    actual=False (แบบเดิม): การใช้ลงวันที่อ่านค่า — วัน D = ค่าอ่าน D − ค่าอ่านก่อนหน้า
    actual=True (v0.89 นับตามวันที่ใช้จริง): วัน D = ค่าอ่านถัดไป − ค่าอ่าน D (ช่วงเวลาอ่านวัน D → วันถัดไป) · v = ค่าอ่านต้นวัน
    ค่าหน่วยที่แก้ไว้ (u_override บนค่าอ่าน) ใช้แทนผลต่างของช่วงนั้นเสมอ
    split=True: ค่าอ่านห่างกันหลายวัน → เฉลี่ยลงทุกวันในช่วงนั้น (flag 'split') แทนรวมก้อนเดียว
    การใช้ต่อวันเกิน bad_u = ค่าเพี้ยน (flag 'bad', u=None ไม่นับรวม)"""
    out: dict[str, dict] = {}
    prev = None
    hist: list[float] = []
    f0, f1 = d_from.isoformat(), d_to.isoformat()

    def put(day_end: str, day_start: str | None, u, flag, gap, v_end, v_start):
        """ช่วง (day_start, day_end] แบบเดิม → ลง day_end · แบบใช้จริง → ลง day_start (ช่วง [day_start, day_end))"""
        if actual:
            if day_start is None:
                return
            d0 = date.fromisoformat(day_start)
            days = [(d0 + timedelta(days=k)).isoformat() for k in range(max(1, gap))]
            anchor, vv = day_start, v_start
        else:
            d1 = date.fromisoformat(day_end)
            days = [(d1 - timedelta(days=k)).isoformat() for k in range(max(1, gap))]
            anchor, vv = day_end, v_end
        if split and u is not None and gap > 1:
            for k, dk in enumerate(days):
                if f0 <= dk <= f1:
                    out[dk] = {"u": u / gap, "flag": flag or "split", "gap": gap, "v": vv if dk == anchor else None, "split": True}
        elif f0 <= anchor <= f1:
            out[anchor] = {"u": u, "flag": flag, "gap": gap, "v": vv}

    for row in rows:
        day, val = row[0], row[1]
        ovr = row[2] if len(row) > 2 else None
        if ovr is not None:
            gap = (date.fromisoformat(day) - date.fromisoformat(prev[0])).days if prev else 1
            start = prev[0] if prev else (date.fromisoformat(day) - timedelta(days=1)).isoformat()
            if actual:
                if f0 <= start <= f1:
                    out[start] = {"u": ovr, "flag": "fix", "gap": 1, "v": prev[1] if prev else None}
            elif f0 <= day <= f1:
                out[day] = {"u": ovr, "flag": "fix", "gap": 1, "v": val}
            hist.append(ovr)
            prev = (day, val)
            continue
        if prev is not None:
            u = (val - prev[1]) * (mult or 1)
            gap = (date.fromisoformat(day) - date.fromisoformat(prev[0])).days
            flag = ""
            if u < 0:
                flag, u = "reset", None
            elif bad_u and u / max(1, gap) > bad_u:
                flag, u = "bad", None
            else:
                pos = [x for x in hist[-14:] if x > 0]
                if len(pos) >= 5 and u > spike_x * statistics.median(pos) * max(1, gap) and u > 1:
                    flag = "spike"
                hist.append(u / max(1, gap))
            put(day, prev[0], u, flag, gap, val, prev[1])
        elif not actual and f0 <= day <= f1:
            out[day] = {"u": None, "flag": "first", "gap": 0, "v": val}
        prev = (day, val)
    return out


def _days(d_from: date, d_to: date) -> list[str]:
    return [(d_from + timedelta(days=i)).isoformat() for i in range((d_to - d_from).days + 1)]


def month_bounds(month: date) -> tuple[date, date]:
    first = month.replace(day=1)
    return first, first.replace(day=calendar.monthrange(first.year, first.month)[1])


def actual_day(db) -> bool:
    """v0.89 นับการใช้ตามวันที่ใช้จริง (ค่าเริ่มต้น) — ตั้งที่หน้า ตั้งค่า"""
    return bool(int(settings(db).get("usage_day", 1)))


def series(db, ms: list[dict], d_from: date, d_to: date, split: bool | None = None) -> dict[int, dict[str, dict]]:
    """การใช้รายวันของทุกหน้าในระบบ (ตัวคำนวณเดียว) — split ไม่ระบุ = ตามตั้งค่า split_gap (ค่าเริ่มต้น: เฉลี่ยวันที่ขาดค่าอ่าน)"""
    cfg = settings(db)
    if split is None:
        split = bool(int(cfg.get("split_gap", 1)))
    act = bool(int(cfg.get("usage_day", 1)))
    rd = readings(db, [m["id"] for m in ms], d_from, d_to, lookahead=45 if act else 0)
    bad = float(cfg.get("bad_u") or BAD_U)
    return {m["id"]: usage(rd[m["id"]], m["multiplier"], d_from, d_to, cfg["spike_x"], split=split, bad_u=bad, actual=act) for m in ms}


ROLES = {1: "หลัก", 0: "ย่อย", -1: "หักออก", 2: "ไม่นับรวม"}


def covers(ms: list[dict]) -> dict[int, set]:
    """v0.90 โครงสร้างมิเตอร์ (ใครวัดซ้อนใคร) → {id: ชุดมิเตอร์ที่ครอบมิเตอร์นี้อยู่}
    - ตั้ง “มิเตอร์แม่” (parent_id) ไว้ → ใช้ตามนั้น
    - ไม่ตั้ง: มิเตอร์ย่อยใน Section ที่มีมิเตอร์หลัก → ถูกมิเตอร์หลักของ Section ครอบ
      · ไม่มีมิเตอร์หลักใน Section แต่โรงงานมีมิเตอร์หลักรวม (หลัก + ไม่ระบุ Section) → ถูกมิเตอร์หลักรวมครอบ
      · มิเตอร์หลักของ Section → ถูกมิเตอร์หลักรวมของโรงงานครอบ (ถ้ามี)
    - หักออก (−1 เช่น Solar) ไม่ถูกครอบ · ไม่นับรวม (2) ไม่เข้าการรวมเลย"""
    if ms and all("_cv" in m for m in ms):              # คำนวณไว้แล้วจากชุดเต็มตอนโหลด (meters()) → กลุ่มย่อยได้ผลเดียวกันเสมอ
        return {m["id"]: set(m["_cv"]) for m in ms}
    out: dict[int, set] = {}
    groups: dict[tuple, list] = {}
    for m in ms:
        groups.setdefault((m.get("factory_id"), m.get("kind")), []).append(m)
    for g in groups.values():
        with_sub = {(m.get("grp") or "").strip() for m in g if (m.get("is_main") or 0) == 0}
        # มิเตอร์หลักรวมของโรงงาน = หลักที่ไม่ระบุ Section หรืออยู่ใน Section ที่มีแต่มิเตอร์หลัก (เช่น “MAIN METER”)
        fmain = {m["id"] for m in g if m.get("is_main") == 1 and not m.get("parent_id")
                 and (not (m.get("grp") or "").strip() or (m.get("grp") or "").strip() not in with_sub)}
        smain: dict[str, set] = {}
        for m in g:
            if m.get("is_main") == 1 and m["id"] not in fmain and (m.get("grp") or "").strip():
                smain.setdefault(m["grp"].strip(), set()).add(m["id"])
        for m in g:
            role, grp = m.get("is_main") or 0, (m.get("grp") or "").strip()
            if m.get("parent_id"):
                c = {m["parent_id"]}
            elif role == -1:
                c = set()
            elif role == 1:
                c = set() if m["id"] in fmain else set(fmain)
            elif grp and smain.get(grp):
                c = set(smain[grp])
            else:
                c = set(fmain)
            c.discard(m["id"])
            out[m["id"]] = c
    return out


def factory_mains(ms: list[dict]) -> set:
    """มิเตอร์หลักรวมของโรงงาน (ครอบมิเตอร์อื่น แต่ไม่ถูกใครครอบ และไม่ใช่หลักของ Section ใด)"""
    cv = covers(ms)
    by_id = {m["id"]: m for m in ms}
    out = set()
    for m in ms:
        if m.get("is_main") == 1 and not cv.get(m["id"]) and not m.get("parent_id"):
            kids = [by_id[k] for k, c in cv.items() if m["id"] in c and k in by_id]
            g = (m.get("grp") or "").strip()
            if not g or not any((k.get("grp") or "").strip() == g for k in kids) or not kids:
                out.add(m["id"])
    return out


def counted(ms: list[dict]) -> list[dict]:
    """v0.90 กติกาเดียวทั้งระบบ: ยอดรวมของกลุ่มใดก็ได้ (โรงงาน · Section · Line · Project · พื้นที่)
    = มิเตอร์ในกลุ่มที่ไม่มีมิเตอร์ที่ครอบมันอยู่ในกลุ่มเดียวกัน → ไม่นับซ้ำหลัก+ย่อย และไม่ทิ้งมิเตอร์ที่ไม่มีหลักครอบ"""
    cv = covers(ms)
    ids = {m["id"] for m in ms}
    return [m for m in ms if (m.get("is_main") or 0) != 2 and not (cv.get(m["id"], set()) & ids)]


def totals_set(ms: list[dict]) -> list[dict]:
    """มิเตอร์ที่ใช้คิดยอดรวม (เดิม: มิเตอร์หลักถ้ามี) — v0.90 ใช้กติกาเดียวกับทุกหน้า (counted)"""
    return counted(ms)


def balance(ms: list[dict], use: dict[int, float]) -> list[dict]:
    """สมดุล มิเตอร์หลัก vs ผลรวมมิเตอร์ย่อยที่มันครอบ (use = {id: การใช้}) → ส่วนต่าง = ไม่ได้วัด/สูญเสีย"""
    cv = covers(ms)
    by_id = {m["id"]: m for m in ms}
    sets: dict[frozenset, list] = {}
    for m in ms:
        c = frozenset(x for x in cv.get(m["id"], set()) if x in by_id)
        if c and (m.get("is_main") or 0) != 2:
            sets.setdefault(c, []).append(m)
    out = []
    for parents, kids in sets.items():
        kids_c = counted(kids)
        pu = sum(sign(p) * (use.get(p["id"]) or 0) for p in counted([by_id[x] for x in parents]))   # หลักซ้อนหลัก → นับตัวบน
        ku = sum(sign(k) * (use.get(k["id"]) or 0) for k in kids_c)
        ps = [by_id[p] for p in sorted(parents)]
        out.append({"parents": ps, "kids": kids_c, "factory_id": ps[0].get("factory_id"), "kind": ps[0].get("kind"),
                    "grp": ps[0].get("grp") or "", "pu": round(pu, 2), "ku": round(ku, 2), "diff": round(pu - ku, 2),
                    "pct": round(100 * (pu - ku) / pu, 1) if pu else None})
    out.sort(key=lambda x: (x["factory_id"] or 0, x["kind"] or "", -abs(x["diff"])))
    return out


def sign(m: dict) -> int:
    """มิเตอร์หักออก (is_main = −1 เช่น Solar) ลบออกจากยอดรวม"""
    return -1 if m.get("is_main") == -1 else 1


# ───────────────────────── Dashboard ─────────────────────────

def dashboard(db, month: date, factory_id: int | None = None, kind: str | None = None, today: date | None = None, grp: str | None = None,
              project_id: int | None = None, line: str | None = None) -> dict:
    ensure(db)
    cfg = settings(db)
    today = today or S.now_dt().date()
    d_from, d_to = month_bounds(month)
    d_end = min(d_to, today)
    ms = meters(db, factory_id)
    if kind:
        ms = [m for m in ms if m["kind"] == kind]
    if grp or project_id or line:
        from .energy_struct import apply_filter
        ms = apply_filter(ms, project_id, grp, line)
    # เดือนก่อนช่วงวันเดียวกัน (เทียบแบบยุติธรรม)
    p_from = (d_from - timedelta(days=1)).replace(day=1)
    p_to = min(month_bounds(p_from)[1], p_from + timedelta(days=(d_end - d_from).days))
    ser = series(db, ms, d_from, d_end)
    have = [d for s_ in ser.values() for d, x in s_.items() if x.get("u") is not None]
    if have:                                             # v0.92 เทียบเท่าจำนวนวันที่มีข้อมูลจริง (นับตามวันที่ใช้ วันล่าสุดยังไม่มีค่า)
        last = date.fromisoformat(max(have))
        p_to = min(month_bounds(p_from)[1], p_from + timedelta(days=(last - d_from).days))
    ser_prev = series(db, ms, p_from, p_to)
    ser_yday = series(db, ms, today - timedelta(days=1), today)
    tot = {m["id"] for m in totals_set(ms)}
    days = _days(d_from, d_end) if d_end >= d_from else []
    factories = {}
    for m in ms:
        factories.setdefault(m["factory_id"], m["factory_name"] or "ไม่ระบุโรงงาน")
    kinds = []
    rates: dict = {}
    for k in KIND_ORDER:
        km = [m for m in ms if m["kind"] == k]
        if not km:
            continue
        tm = [m for m in km if m["id"] in tot]
        total = sum(sign(m) * ((ser[m["id"]].get(d) or {}).get("u") or 0) for m in tm for d in days)
        # v0.99.46 มิเตอร์ที่เดือนนี้ไม่มีค่าเลย (หยุดส่งข้อมูล) ไม่นับในยอดเดือนก่อน — ไม่ให้กลายเป็น “ลดได้”
        live_ids = {m["id"] for m in tm if any((ser[m["id"]].get(d) or {}).get("u") is not None for d in days)}
        prev = sum(sign(m) * (x.get("u") or 0) for m in tm if m["id"] in live_ids for x in ser_prev[m["id"]].values())
        nodata = [label(m) for m in tm if m["id"] not in live_ids and any((x.get("u") or 0) for x in ser_prev[m["id"]].values())]
        cost = sum(sign(m) * ((ser[m["id"]].get(d) or {}).get("u") or 0) * (m["price"] if m["price"] is not None else
                   (KINDS[k].get("price") if KINDS[k].get("price") is not None else
                    (rates.setdefault(m["factory_id"], _rate(db, m["factory_id"], d_from, cfg)) if k == "elec" else 0)))
                   for m in tm for d in days)
        daily = {f: [round(sum(sign(m) * ((ser[m["id"]].get(d) or {}).get("u") or 0) for m in tm if m["factory_id"] == f), 2) for d in days]
                 for f in factories if any(m["factory_id"] == f for m in tm)}
        tday = today.isoformat()
        have_today = sum(1 for m in km if any(r for r in (ser_yday[m["id"]].get(tday),) if r))
        yd = (today - timedelta(days=1)).isoformat()
        y_use = sum(sign(m) * ((ser_yday[m["id"]].get(yd) or {}).get("u") or 0) for m in tm)
        t_use = sum(sign(m) * ((ser_yday[m["id"]].get(tday) or {}).get("u") or 0) for m in tm)
        per_m = []
        for m in km:
            s = ser[m["id"]]
            u = sum((x.get("u") or 0) for x in s.values())
            flags = [(d, x["flag"]) for d, x in s.items() if x["flag"] in ("reset", "spike")]
            last = max(s) if s else None
            per_m.append({"id": m["id"], "label": label(m), "grp": m["grp"], "factory_id": m["factory_id"], "kind": m["kind"],
                          "parent_id": m.get("parent_id"), "_cv": m.get("_cv", ()), "line": m.get("line") or "", "factory": m["factory_name"], "u": round(u, 2),
                          "is_main": m["is_main"], "flags": flags, "last": last,
                          "spark": [round((s.get(d) or {}).get("u") or 0, 2) for d in days[-14:]],
                          "has": [(s.get(d) or {}).get("u") is not None for d in days]})          # v0.92 วันที่มีค่าจริง (ความครบ)
        per_m.sort(key=lambda x: -x["u"])
        top_sub = [x for x in per_m if x["is_main"] == 0][:10] or [x for x in per_m if x["is_main"] != 2][:10]
        kinds.append({
            "kind": k, **KINDS[k], "unit": km[0]["unit"] or KINDS[k]["unit"], "n_meters": len(km), "n_total_meters": len(tm),
            "total": round(total, 2), "prev": round(prev, 2), "change": round(100 * (total - prev) / prev, 1) if prev else None,
            "nodata": nodata,
            "cost": round(cost, 0), "co2": (round(total * (KINDS[k]["ef"] if KINDS[k].get("ef") is not None else cfg["ef_elec"]) / 1000, 2)
                    if (KINDS[k].get("ef") is not None or k == "elec") else None),
            "today": round(t_use, 2), "yday": round(y_use, 2), "have_today": have_today,
            "daily": daily, "top": top_sub, "meters": per_m,
            "flags": sum(len(x["flags"]) for x in per_m),
            "avg_day": round(total / len(days), 2) if days else 0,
        })
    missing = []
    for m in ms:
        last = db.execute("SELECT MAX(day) FROM en_readings WHERE meter_id=?", (m["id"],)).fetchone()[0]
        if not last or last < (today - timedelta(days=1)).isoformat():
            if db.execute("SELECT 1 FROM en_skips WHERE meter_id=? AND day>=?", (m["id"], (today - timedelta(days=1)).isoformat())).fetchone():
                continue                                   # แจ้งอ่านไม่ได้พร้อมเหตุผลแล้ว
            missing.append({"id": m["id"], "label": label(m), "kind": m["kind"], "factory": m["factory_name"], "last": last})
    from .energy_ops import case_summary
    return {"cases": case_summary(db, factory_id), "month": d_from, "d_from": d_from, "d_to": d_to, "d_end": d_end, "days": days, "kinds": kinds,
            "factories": factories, "missing": missing, "cfg": cfg, "today": today,
            "n_meters": len(ms), "last_update": db.execute("SELECT MAX(updated_at) FROM en_readings").fetchone()[0]}


def _rate(db, factory_id, month: date, cfg: dict) -> float:
    """ค่าไฟบาท/kWh: บิลจริงของเดือนนั้น → ไม่มีใช้บิลเดือนล่าสุดก่อนหน้า → ไม่มีใช้ค่าตั้งค่า"""
    from .energy_ops import bill_rate
    r = bill_rate(db, factory_id, month.strftime("%Y-%m"))
    if r:
        return r
    row = db.execute("""SELECT kwh, amount, vat FROM en_bills WHERE factory_id IS ? AND month<? AND kwh>0
                         ORDER BY month DESC LIMIT 1""", (factory_id, month.strftime("%Y-%m"))).fetchone()
    return (row[1] + row[2]) / row[0] if row else cfg["price_elec"]


def meter_detail(db, mid: int, days: int = 60) -> dict:
    from .energy_ops import cases, fix_log
    m = meter(db, mid)
    if not m:
        raise S.ValidationError("ไม่พบมิเตอร์")
    today = S.now_dt().date()
    d_from = today - timedelta(days=days - 1)
    s = series(db, [m], d_from, today, split=True)[mid]
    dl = _days(d_from, today)
    meta = {r[0]: {"photo": r[1], "src": r[2], "note": r[3], "rv": r[4], "read_at": r[5]} for r in db.execute(
        "SELECT day, photo, src, note, value, read_at FROM en_readings WHERE meter_id=? AND day>=? AND day<=?",
        (mid, d_from.isoformat(), today.isoformat()))}
    empty = {"photo": "", "src": "", "note": "", "rv": None, "read_at": None}
    rows = [dict(day=d, **(s.get(d) or {"u": None, "flag": "", "gap": 0, "v": None}), **meta.get(d, empty)) for d in reversed(dl)]
    cfg = settings(db)
    t_read = S.now_dt().replace(hour=int(cfg["scada_hh"]), minute=int(cfg["scada_mm"]), second=0)
    first_day = db.execute("SELECT MIN(day) FROM en_readings WHERE meter_id=?", (mid,)).fetchone()[0] or today.isoformat()
    for r in rows:                                         # v0.89 เลขหน้าปัดของวันนั้นจากค่าอ่านจริง (ไม่ขึ้นกับวิธีนับวัน)
        r["v"] = r.pop("rv")
        # v0.99.37 ทุกวันแสดงในตาราง: มีค่า · ประมาณ (≈) · ยังไม่ถึงเวลาอ่าน (วันนี้) · ขาดค่า — ก่อนวันแรกที่มีค่าไม่แสดง
        r["approx"] = str(r.get("note") or "").startswith("≈")
        if r["v"] is not None:
            r["state"] = "approx" if r["approx"] else "ok"
        elif r["day"] == today.isoformat() and S.now_dt() < t_read + timedelta(minutes=int(cfg["scada_window"])):
            r["state"] = "wait"
        else:
            r["state"] = "missing"
        r["show"] = r["v"] is not None or r["day"] >= first_day
    rows = [r for r in rows if r["show"]]
    vals = [x["u"] for x in s.values() if x.get("u") is not None]
    have = set(meta)
    first = db.execute("SELECT MIN(day) FROM en_readings WHERE meter_id=?", (mid,)).fetchone()[0] or "9999"
    issues = [{"day": r[0], "kind": "future"} for r in db.execute(              # v0.99.37 ค่าอ่านลงวันในอนาคต (นาฬิกา/วันที่ผิด) → ไม่ถูกใช้คำนวณ
        "SELECT day FROM en_readings WHERE meter_id=? AND day>? ORDER BY day", (mid, today.isoformat()))]
    for d in reversed(dl):
        x = s.get(d) or {}
        if x.get("flag") in ("bad", "reset", "spike"):
            issues.append({"day": d, "kind": x["flag"]})
        elif d > first and d not in have and d != today.isoformat() and (x.get("split") or not x):
            issues.append({"day": d, "kind": "missing"})
    return {"m": m, "days": dl, "u": [None if (s.get(d) or {}).get("u") is None else round(s[d]["u"], 3) for d in dl],
            "flags": [(s.get(d) or {}).get("flag") or "" for d in dl], "issues": issues[:60],
            "rows": rows, "read_time": f"{int(cfg['scada_hh']):02d}:{int(cfg['scada_mm']):02d}", "window": int(cfg["scada_window"]),
            "actual": bool(int(cfg.get("usage_day", 1))),
            "n_missing": sum(1 for r in rows if r["state"] == "missing"), "n_approx": sum(1 for r in rows if r["state"] == "approx"),
            "total": round(sum(vals), 2), "avg": round(sum(vals) / len(vals), 2) if vals else None,
            "max": round(max(vals), 2) if vals else None,
            "n": db.execute("SELECT COUNT(*), MIN(day), MAX(day) FROM en_readings WHERE meter_id=?", (mid,)).fetchone(),
            "fixes": fix_log(db, mid), "cases": [c for c in cases(db, None) if c["meter_id"] == mid][:20]}


# ───────────────────────── กรอกค่ารายวัน / ตารางรายเดือน ─────────────────────────

def entry_rows(db, factory_id: int, kind: str, day: date) -> list[dict]:
    return entry_rows_for(db, meters(db, factory_id, kind), day)


def entry_rows_for(db, ms: list[dict], day: date) -> list[dict]:
    out = []
    for m in ms:
        cur = db.execute("SELECT value, src, updated_at, photo, read_at, note FROM en_readings WHERE meter_id=? AND day=?",
                         (m["id"], day.isoformat())).fetchone()
        sk = db.execute("SELECT reason, note FROM en_skips WHERE meter_id=? AND day=?", (m["id"], day.isoformat())).fetchone()
        prev = db.execute("SELECT day, value FROM en_readings WHERE meter_id=? AND day<? ORDER BY day DESC LIMIT 1",
                          (m["id"], day.isoformat())).fetchone()
        p2 = db.execute("""SELECT value FROM en_readings WHERE meter_id=? AND day<? ORDER BY day DESC LIMIT 15""",
                        (m["id"], day.isoformat())).fetchall()
        vals = [x[0] for x in p2][::-1]
        diffs = [b - a for a, b in zip(vals, vals[1:]) if b >= a]
        out.append({**m, "label": label(m), "cur": cur[0] if cur else None, "src": cur[1] if cur else "",
                    "photo": cur[3] if cur else "", "read_at": cur[4] if cur else None, "note": cur[5] if cur else "",
                    "skip": dict(sk) if sk else None, "auto": bool(m.get("scada_source_id") and m.get("scada_tag")),
                    "prev_day": prev[0] if prev else None, "prev": prev[1] if prev else None,
                    "typ": round(statistics.median(diffs) * (m["multiplier"] or 1), 3) if diffs else None})
    return out


def save_entry(db, factory_id: int, kind: str, day: date, values: dict, actor, reason: str = "", allowed_ids=None) -> dict:
    """บันทึกค่าทั้งตาราง — แก้ค่าที่มีอยู่แล้วต้องมีเหตุผล (เก็บประวัติ) · ช่างแก้ย้อนหลังได้ตามที่ตั้งค่า
    allowed_ids = มิเตอร์ในแบบฟอร์มที่เลือก (ข้ามหมวดได้) แทนการกรองตามโรงงาน/หมวด"""
    from .energy_field import back_limit_ok
    today = S.now_dt().date()
    if day > today:
        raise S.ValidationError("บันทึกค่าล่วงหน้าไม่ได้")
    allowed = set(allowed_ids) if allowed_ids is not None else {m["id"] for m in meters(db, factory_id, kind)}
    reason = (reason or "").strip()[:300]
    changes = []
    for k, v in (values or {}).items():
        try:
            mid = int(k)
        except ValueError:
            continue
        if mid not in allowed:
            continue
        old = db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
        if old and (v is None or str(v).strip() == "" or abs(old[0] - float(str(v).replace(",", "") or 0)) > 1e-9):
            changes.append((mid, old[0], v))
    if changes:
        if not back_limit_ok(db, actor, day.isoformat(), settings(db)):
            raise S.ValidationError(f"แก้ค่าย้อนหลังได้ไม่เกิน {int(settings(db)['tech_back_days'])} วัน — แจ้งหัวหน้างาน")
        if len(reason) < 3:
            raise S.ValidationError("NEED_REASON")
    res = {"new": 0, "changed": 0, "deleted": 0, "same": 0, "none": 0}
    stamp = ts(S.now_dt())
    for k, v in (values or {}).items():
        try:
            mid = int(k)
        except ValueError:
            continue
        if mid not in allowed:
            continue
        r = set_reading(db, mid, day.isoformat(), v, actor)
        res[r] += 1
        if r == "new" and day == today:
            db.execute("UPDATE en_readings SET read_at=COALESCE(read_at, ?) WHERE meter_id=? AND day=?", (stamp, mid, day.isoformat()))
        if r in ("new", "changed"):
            db.execute("DELETE FROM en_skips WHERE meter_id=? AND day=?", (mid, day.isoformat()))
    for mid, ov, nv in changes:
        nvf = None if nv is None or str(nv).strip() == "" else float(str(nv).replace(",", ""))
        db.execute("""INSERT INTO en_fix_log(meter_id, day, field, old_value, new_value, reason, user_id, created_at)
                      VALUES (?,?,?,?,?,?,?,?)""", (mid, day.isoformat(), "value", ov, nvf, reason, actor, stamp))
    return res


def month_sheet(db, factory_id: int, kind: str, month: date, project_id: int | None = None, grp: str | None = None,
                line: str | None = None) -> dict:
    d_from, d_to = month_bounds(month)
    ms = meters(db, factory_id, kind, True, project_id, grp, line)
    ser = series(db, ms, d_from, d_to, split=True)                 # v0.88 วันที่ขาดค่า → เฉลี่ยลงรายวัน ไม่รวมก้อน
    days = _days(d_from, d_to)
    tot = {m["id"] for m in totals_set(ms)}
    rv: dict[tuple, float] = {}                                  # v0.92.1 เลขหน้าปัดของวันนั้นจากค่าอ่านจริง (ไม่ขึ้นกับวิธีนับวัน/เฉลี่ย)
    ids = [m["id"] for m in ms]
    for i in range(0, len(ids), 500):
        ch = ids[i:i + 500]
        for r in db.execute(f"SELECT meter_id, day, value FROM en_readings WHERE day BETWEEN ? AND ? AND meter_id IN ({','.join('?' * len(ch))})",
                            [d_from.isoformat(), d_to.isoformat(), *ch]):
            rv[(r[0], r[1])] = r[2]

    def cell(m, d):
        x, v = ser[m["id"]].get(d), rv.get((m["id"], d))
        if x is None and v is None:
            return None
        return {**(x or {"u": None, "flag": "", "gap": 0}), "v": v}
    grid = [{"day": d, "cells": [cell(m, d) for m in ms],
             "total": round(sum(sign(m) * ((ser[m["id"]].get(d) or {}).get("u") or 0) for m in ms if m["id"] in tot), 2)} for d in days]
    sums = [round(sum((x.get("u") or 0) for x in ser[m["id"]].values()), 2) for m in ms]
    return {"meters": [dict(m, label=label(m), in_total=m["id"] in tot) for m in ms], "grid": grid, "sums": sums,
            "d_from": d_from, "d_to": d_to, "grand": round(sum(r["total"] for r in grid), 2)}


def sheet_xlsx(db, factory_id: int, kind: str, month: date, project_id=None, grp=None, line=None) -> bytes:
    import io

    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    sh = month_sheet(db, factory_id, kind, month, project_id, grp, line)
    fac = db.execute("SELECT name FROM factories WHERE id=?", (factory_id,)).fetchone()
    wb = Workbook()
    head = Font(bold=True)
    fill = PatternFill("solid", fgColor="DBEAFE")
    for title, key in (("ค่าอ่านมิเตอร์", "v"), ("การใช้ต่อวัน", "u")):
        ws = wb.active if key == "v" else wb.create_sheet()
        ws.title = title
        ws.append([f"Energy Data · {KINDS[kind]['th']} · {fac[0] if fac else ''} · {month:%m/%Y} · {title}"])
        ws["A1"].font = Font(bold=True, size=13)
        ws.append(["กลุ่ม"] + [m["grp"] for m in sh["meters"]])
        ws.append(["วันที่"] + [m["label"] for m in sh["meters"]] + (["รวม"] if key == "u" else []))
        for c in ws[3]:
            c.font, c.fill = head, fill
            c.alignment = Alignment(wrap_text=True, horizontal="center")
        for r in sh["grid"]:
            ws.append([r["day"]] + [(x or {}).get(key) for x in r["cells"]] + ([r["total"]] if key == "u" else []))
        if key == "u":
            ws.append(["รวมเดือน"] + sh["sums"] + [sh["grand"]])
            for c in ws[ws.max_row]:
                c.font = head
        ws.column_dimensions["A"].width = 12
        for i in range(2, len(sh["meters"]) + 3):
            ws.column_dimensions[ws.cell(row=3, column=i).column_letter].width = 13
        ws.freeze_panes = "B4"
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


# ───────────────────────── นำเข้าไฟล์ Excel บันทึกมิเตอร์ (รูปแบบเดิมของโรงงาน) ─────────────────────────
CODE_RE = re.compile(r"^[A-Z]{2}\s?\d{3,5}$|^SCT\d+|^SLT\d+|^NEW\s?B", re.I)
UNIT_RE = re.compile(r"\(?\s*m3\s*\)?|\(\s*\)", re.I)
PRICE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(?:B|บาท)?\s*/\s*m3", re.I)


def guess(filename: str, factories: list[dict]) -> dict:
    n = filename.lower()
    if "compressor" in n or "ชั่วโมง" in n or "ชัวโมง" in n:
        kind = "hours"
    elif "ลม" in n or "air" in n:
        kind = "air"
    elif "ro" in n.replace("room", ""):
        kind = "ro"
    elif "ไฟ" in n or "kwh" in n or "elec" in n or "power" in n:
        kind = "elec"
    else:
        kind = "water"
    fid = None
    m = re.search(r"(?:โรง|ไอชิน|aisin|f|factory)\s*(\d)", n)
    if m:
        idx = int(m.group(1))
        hit = [f for f in factories if re.search(rf"(?<!\d){idx}(?!\d)", f["name"] + " " + f["code"])]
        if hit:
            fid = hit[0]["id"]
        elif 0 < idx <= len(factories):
            fid = factories[idx - 1]["id"]
    return {"kind": kind, "factory_id": fid}


def _cell(v):
    if isinstance(v, str):
        v = v.strip()
        if not v:
            return None
        try:
            return float(v.replace(",", ""))
        except ValueError:
            return v
    return v


def _open_book(raw: bytes, filename: str) -> list[tuple[str, list[list]]]:
    """[(ชื่อชีต, แถว[คอลัมน์])] — รองรับ .xls (xlrd ในตัว) และ .xlsx (openpyxl)"""
    if filename.lower().endswith((".xlsx", ".xlsm")):
        import io

        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(raw), data_only=True, read_only=True)
        return [(ws.title, [[_cell(c) for c in row] for row in ws.iter_rows(values_only=True)]) for ws in wb.worksheets]
    try:
        import xlrd
    except ImportError:
        from ._vendor import xlrd
    book = xlrd.open_workbook(file_contents=raw)
    return [(s.name, [[_cell(v) for v in s.row_values(r)] for r in range(s.nrows)]) for s in book.sheets()]


def _is_day(v, n) -> bool:
    return isinstance(v, (int, float)) and float(v) == n


def parse_sheet(rows: list[list]) -> dict | None:
    """ตารางรายวันชุดแรกของชีต: หัวตาราง (≤4 แถวเหนือวันที่ 1) + ค่าอ่านวันที่ 1–31"""
    start = next((i for i, r in enumerate(rows) if r and _is_day(r[0], 1)), None)
    if start is None:
        return None
    end = start
    for i in range(start, min(len(rows), start + 31)):
        r = rows[i]
        if r and isinstance(r[0], (int, float)) and 1 <= float(r[0]) <= 31 and float(r[0]) == i - start + 1:
            end = i
        else:
            break
    top = start - 1
    while top >= 0 and top >= start - 5:
        first = rows[top][0] if rows[top] else None
        if isinstance(first, str) and re.match(r"^(day|วันที่|no\.?)$", first.strip(), re.I):
            break
        top -= 1
    if top < start - 5 or top < 0:
        top = max(0, start - 4)
    hdr = rows[top:start]
    ncol = max(len(r) for r in rows[top:end + 1])
    cols = []
    ff = [None] * len(hdr)
    for c in range(1, ncol):
        labs = []
        for hi, hr in enumerate(hdr):
            v = hr[c] if c < len(hr) else None
            v = None if v is None or isinstance(v, (int, float)) else str(v).strip()
            if v:
                ff[hi] = v
            elif hi < len(hdr) - 1 and ff[hi] and hi <= 1:      # หัวกลุ่ม/รหัส ลากต่อคอลัมน์ขวา (ช่องรวมเซลล์)
                v = ff[hi]
            labs.append(v)
        vals = []
        for i in range(start, end + 1):
            v = rows[i][c] if c < len(rows[i]) else None
            vals.append(float(v) if isinstance(v, (int, float)) else None)
        own = [hr[c] for hr in hdr if c < len(hr) and isinstance(hr[c], str) and hr[c].strip()]
        if not own and not any(v is not None for v in vals):
            continue
        cols.append({"col": c, "labels": labs, "vals": vals})
    if not cols:
        return None
    return {"cols": cols, "ndays": end - start + 1, "hdr_rows": len(hdr)}


def _norm_code(p: str) -> str:
    return re.sub(r"^([A-Z]{2})\s?(\d)", r"\1\2", p.strip())


def _meter_from_labels(labs: list, shared_top: bool) -> dict:
    """หัวตาราง → (key, code, name, grp, price)
    labs[0] = แถวบนสุด (หัวกลุ่ม ลากต่อคอลัมน์) · shared_top = หัวบนสุดนี้ครอบหลายคอลัมน์ → เป็นชื่อกลุ่ม"""
    price = None
    clean = []
    for p in labs:
        if not p:
            clean.append("")
            continue
        m = PRICE_RE.search(p)
        if m:
            price = float(m.group(1))
            p = PRICE_RE.sub("", p)
        p = re.sub(r"\(\s*m3\s*\)|\bm3\b|\(\s*\)|\(\s*$", "", p, flags=re.I).strip(" ()")
        clean.append(re.sub(r"\s+", " ", p).strip())
    code = ""
    for p in clean:
        if p and (CODE_RE.match(p.replace(" ", "")) or re.match(r"^[A-Z]{2}\s?\d{3,5}\b", p)):
            code = _norm_code(p)
            break
    top = clean[0] if clean else ""
    grp = top if top and shared_top and _norm_code(top) != code else ""
    rest = []
    for i, p in enumerate(clean):
        if not p or _norm_code(p) == code or (i == 0 and grp):
            continue
        if p not in rest:
            rest.append(p)
    name = " ".join(rest) or code or grp
    key = " | ".join(x for x in (grp, code, " ".join(rest)) if x).upper() or "?"
    return {"key": key[:150], "code": code, "name": name[:120], "grp": grp[:80], "price": price}


def parse_file(raw: bytes, filename: str, year: int) -> dict:
    """ทุกชีตที่ชื่อเป็นเดือน (1–12) → มิเตอร์ + ค่าอ่านรายวัน"""
    try:
        sheets = _open_book(raw, filename)
    except Exception as exc:          # noqa: BLE001 — ไฟล์เสีย/ไม่ใช่ Excel
        raise S.ValidationError(f"อ่านไฟล์ไม่ได้: {exc}") from None
    meters_: dict[str, dict] = {}
    months = []
    skipped = []
    future = 0
    today = S.now_dt().date()
    for name, rows in sheets:
        nm = name.strip()
        if not nm.isdigit() or not 1 <= int(nm) <= 12:
            skipped.append(nm)
            continue
        mo = int(nm)
        p = parse_daily_rows(rows) or parse_sheet(rows) or parse_sheet_rows(rows)
        if not p:
            skipped.append(nm)
            continue
        n_here = 0
        last_day = calendar.monthrange(year, mo)[1]
        tops: dict[str, int] = {}
        for c in p["cols"]:
            t = (c["labels"][0] or "") if c["labels"] else ""
            tops[t] = tops.get(t, 0) + 1
        for c in p["cols"]:
            t = (c["labels"][0] or "") if c["labels"] else ""
            info = c.get("info") or _meter_from_labels(c["labels"], tops.get(t, 0) > 1 and len([x for x in c["labels"] if x]) > 1)
            mm = meters_.setdefault(info["key"], {**info, "order": len(meters_), "readings": {}})
            if c.get("carry") is not None:                 # “ยกมา” = ค่าอ่านสิ้นเดือนก่อน
                dprev = (date(year, mo, 1) - timedelta(days=1)).isoformat()
                mm["readings"].setdefault(dprev, c["carry"])
            for i, v in enumerate(c["vals"]):
                if v is None or i + 1 > last_day:
                    continue
                dd = date(year, mo, i + 1)
                if dd > today:                       # ค่าที่ลากสูตรล่วงหน้าในไฟล์ → ไม่นำเข้า
                    future += 1
                    continue
                mm["readings"][dd.isoformat()] = v
                n_here += 1
        months.append({"month": mo, "values": n_here})
    meters_ = {k: v for k, v in meters_.items() if v["readings"]}
    if not meters_:
        raise S.ValidationError("ไม่พบตารางค่าอ่านรายวัน (ชีตชื่อ 1–12 ที่มีคอลัมน์วันที่ 1–31)")
    return {"meters": list(meters_.values()), "months": sorted(months, key=lambda x: x["month"]), "skipped": skipped,
            "future": future}


SUSPECT_RE = re.compile(r"รวม|error|เสีย|total|sum\b|เฉลี่ย|average|avg|ผลต่าง|diff|บาท|baht|cost|ราคา|kwh\s*/|ต่อหน่วย|%|ratio", re.I)


def preview(db, parsed: dict, factory_id: int | None, kind: str) -> dict:
    ensure(db)
    from .energy_register import norm_section, standard_for
    std = standard_for(db, factory_id, kind)
    out = []
    n_new_r = n_chg = 0
    for i, m in enumerate(parsed["meters"]):
        sr = std.get(m["key"])                             # v0.90 ตรงทะเบียนมาตรฐาน → ใช้ Section/บทบาทตามทะเบียน
        m = {**m, "grp": sr["grp"] if sr else norm_section(m["grp"])}
        r = db.execute("SELECT id, code, name, grp, is_main, active FROM en_meters WHERE factory_id IS ? AND kind=? AND key=?",
                       (factory_id, kind, m["key"])).fetchone()
        exist = {}
        if r:
            exist = {x[0]: x[1] for x in db.execute("SELECT day, value FROM en_readings WHERE meter_id=?", (r[0],))}
        new = sum(1 for d in m["readings"] if d not in exist)
        chg = sum(1 for d, v in m["readings"].items() if d in exist and abs(exist[d] - v) > 1e-9)
        n_new_r += new
        n_chg += chg
        days = sorted(m["readings"])
        txt = f"{m['grp']} {m['code']} {m['name']}"
        suspect = bool(SUSPECT_RE.search(txt)) or len(m["readings"]) < 3
        out.append({"idx": i, "mid": r[0] if r else None, "suspect": suspect,
                    "cur": ({"code": r[1], "name": r[2], "grp": r[3], "is_main": r[4], "active": r[5]} if r else None),
                    "key": m["key"], "code": m["code"], "name": m["name"], "grp": m["grp"], "price": m["price"], "exists": bool(r),
                    "n": len(m["readings"]), "new": new, "chg": chg, "first": days[0] if days else None,
                    "last": days[-1] if days else None, "last_v": m["readings"][days[-1]] if days else None,
                    "main": (sr["role"] == 1) if sr else auto_main(f"{m['grp']} {m['code']} {m['name']}"),
                    "role": sr["role"] if sr else (1 if auto_main(f"{m['grp']} {m['code']} {m['name']}") else 0), "std": bool(sr)})
    return {"meters": out, "n_new_meters": sum(1 for x in out if not x["exists"]), "n_new": n_new_r, "n_chg": n_chg}


def commit(db, parsed: dict, factory_id: int | None, kind: str, year: int, filename: str, actor, overwrite: bool = False,
           select: list[int] | None = None, edits: dict | None = None, mode: str = "all") -> dict:
    """นำเข้าเฉพาะมิเตอร์ที่เลือก (select = ลำดับในไฟล์) · แก้ชื่อ/รหัส/Section/บทบาทก่อนนำเข้าได้ (edits)
    mode: all = มิเตอร์ + ค่าอ่าน · meters = เฉพาะทะเบียนมิเตอร์ · readings = เฉพาะค่าอ่านของมิเตอร์ที่มีอยู่แล้ว
    ทุกค่าที่เพิ่ม/ทับเก็บไว้ใน en_import_rows เพื่อ “ยกเลิกการนำเข้า” ได้ภายหลัง"""
    ensure(db)
    if kind not in KINDS:
        raise S.ValidationError("ประเภทมิเตอร์ไม่ถูกต้อง")
    if mode not in ("all", "meters", "readings"):
        mode = "all"
    chosen = set(range(len(parsed["meters"]))) if select is None else {int(i) for i in select}
    if not chosen:
        raise S.ValidationError("ยังไม่ได้เลือกมิเตอร์ที่จะนำเข้า")
    edits = edits or {}
    from .energy_register import norm_section, standard_for
    std = standard_for(db, factory_id, kind)
    made: dict[str, int] = {}
    res = {"meters": 0, "new_meters": 0, "readings": 0, "changed": 0, "skipped_meters": 0}
    stamp = ts(S.now_dt())
    iid = db.execute("""INSERT INTO en_imports(filename, factory_id, kind, year, user_id, created_at, months)
                        VALUES (?,?,?,?,?,?,?)""", (filename[:200], factory_id, kind, year, actor, stamp,
                                                    ",".join(str(x["month"]) for x in parsed["months"]))).lastrowid
    for i, m in enumerate(parsed["meters"]):
        if i not in chosen:
            continue
        e = edits.get(str(i)) or edits.get(i) or {}
        code = str(e.get("code", m["code"]) or "").strip()[:60]
        name = str(e.get("name", m["name"]) or "").strip()[:120]
        sr = std.get(m["key"])
        grp = str(e.get("grp", sr["grp"] if sr else norm_section(m["grp"])) or "").strip()[:80]
        r = db.execute("SELECT id FROM en_meters WHERE factory_id IS ? AND kind=? AND key=?", (factory_id, kind, m["key"])).fetchone()
        if mode == "readings" and not r:
            res["skipped_meters"] += 1
            continue
        if r:
            mid, created = r[0], False
        else:
            mid, created = upsert_meter(db, factory_id, kind, m["key"], code, name, grp, KINDS[kind]["unit"], m["price"], m["order"])
            db.execute("INSERT INTO en_import_meters(import_id, meter_id) VALUES (?,?)", (iid, mid))
            if sr and created:                                 # v0.90 มิเตอร์ใหม่ตามทะเบียนมาตรฐาน: บทบาท · Line · หมายเหตุ
                db.execute("UPDATE en_meters SET is_main=?, line=?, note=? WHERE id=?",
                           (sr["role"], sr.get("line") or "", sr.get("note") or "", mid))
                made[m["key"]] = mid
        if e:
            upd = {"code": code, "name": name, "grp": grp}
            if "is_main" in e and str(e["is_main"]) in ("-1", "0", "1", "2"):
                upd["is_main"] = int(e["is_main"])
            db.execute(f"UPDATE en_meters SET {', '.join(k + '=?' for k in upd)} WHERE id=?", [*upd.values(), mid])
        res["meters"] += 1
        res["new_meters"] += 1 if created else 0
        if mode == "meters":
            continue
        for d, v in m["readings"].items():
            old = db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (mid, d)).fetchone()
            if old and (not overwrite or abs(old[0] - v) < 1e-9):
                continue
            db.execute("""INSERT INTO en_readings(meter_id, day, value, src, user_id, updated_at) VALUES (?,?,?,?,?,?)
                          ON CONFLICT(meter_id, day) DO UPDATE SET value=excluded.value, src=excluded.src,
                          user_id=excluded.user_id, updated_at=excluded.updated_at""", (mid, d, v, "excel", actor, stamp))
            db.execute("INSERT INTO en_import_rows(import_id, meter_id, day, old_value, new_value) VALUES (?,?,?,?,?)",
                       (iid, mid, d, old[0] if old else None, v))
            res["changed" if old else "readings"] += 1
    for key, mid in made.items():                          # มิเตอร์แม่ตามทะเบียน (เฉพาะที่สร้างใหม่ในรอบนี้)
        pk = std[key].get("parent_key")
        if pk:
            p = db.execute("SELECT id FROM en_meters WHERE factory_id IS ? AND kind=? AND key=?", (factory_id, kind, pk)).fetchone()
            if p:
                db.execute("UPDATE en_meters SET parent_id=? WHERE id=?", (p[0], mid))
    db.execute("""UPDATE en_imports SET n_meters=?, n_new=?, n_readings=?, n_changed=?, mode=? WHERE id=?""",
               (res["meters"], res["new_meters"], res["readings"], res["changed"], mode, iid))
    S.audit(db, actor, "energy_import", "en_imports", iid, after=dict(res, mode=mode, selected=len(chosen)))
    res["import_id"] = iid
    return res


def undo_import(db, iid: int, actor) -> dict:
    """ยกเลิกการนำเข้า: ลบค่าที่เพิ่ม · คืนค่าเดิมที่ถูกทับ · ลบมิเตอร์ที่สร้างจากการนำเข้านี้ (ถ้าไม่มีค่าอื่นเหลือ)
    ค่าที่ถูกแก้หลังนำเข้า (ไม่ตรงกับค่าที่นำเข้า) จะไม่ถูกแตะ"""
    ensure(db)
    imp = db.execute("SELECT * FROM en_imports WHERE id=?", (iid,)).fetchone()
    if not imp:
        raise S.ValidationError("ไม่พบประวัติการนำเข้า")
    if imp["undone_at"]:
        raise S.ValidationError("ยกเลิกการนำเข้านี้ไปแล้ว")
    res = {"removed": 0, "restored": 0, "kept": 0, "meters_removed": 0}
    for r in db.execute("SELECT * FROM en_import_rows WHERE import_id=?", (iid,)).fetchall():
        cur = db.execute("SELECT value FROM en_readings WHERE meter_id=? AND day=?", (r["meter_id"], r["day"])).fetchone()
        if not cur or abs(cur[0] - r["new_value"]) > 1e-9:
            res["kept"] += 1
            continue
        if r["old_value"] is None:
            db.execute("DELETE FROM en_readings WHERE meter_id=? AND day=?", (r["meter_id"], r["day"]))
            res["removed"] += 1
        else:
            db.execute("UPDATE en_readings SET value=?, src='web', updated_at=? WHERE meter_id=? AND day=?",
                       (r["old_value"], ts(S.now_dt()), r["meter_id"], r["day"]))
            res["restored"] += 1
    for (mid,) in db.execute("SELECT meter_id FROM en_import_meters WHERE import_id=?", (iid,)).fetchall():
        if not db.execute("SELECT 1 FROM en_readings WHERE meter_id=? LIMIT 1", (mid,)).fetchone():
            db.execute("DELETE FROM en_meters WHERE id=?", (mid,))
            res["meters_removed"] += 1
    db.execute("UPDATE en_imports SET undone_at=?, undone_by=? WHERE id=?", (ts(S.now_dt()), actor, iid))
    S.audit(db, actor, "energy_import_undo", "en_imports", iid, after=res)
    return res


def imports(db, limit: int = 30) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.execute("""SELECT i.*, f.name AS factory_name, u.name AS user_name,
                                           (EXISTS(SELECT 1 FROM en_import_rows x WHERE x.import_id=i.id)
                                            OR EXISTS(SELECT 1 FROM en_import_meters y WHERE y.import_id=i.id)) AS trackable
                                           FROM en_imports i
                                           LEFT JOIN factories f ON f.id=i.factory_id LEFT JOIN users u ON u.id=i.user_id
                                           ORDER BY i.id DESC LIMIT ?""", (limit,))]


# ───────────────────────── ไฟล์ไฟฟ้าแบบเดิม (แถว = มิเตอร์ · คอลัมน์ = วันที่ 1–31) ─────────────────────────

def parse_sheet_rows(rows: list[list]) -> dict | None:
    """รูปแบบ Electric_used_*.xls: แถวหัวที่มีเลข 1..31 เรียงกัน · ชื่อมิเตอร์อยู่คอลัมน์ข้อความก่อนวันที่ 1"""
    for hi, r in enumerate(rows[:40]):
        idx = {}
        for c, v in enumerate(r):
            if isinstance(v, (int, float)) and float(v).is_integer() and 1 <= v <= 31:
                idx.setdefault(int(v), c)
        if len(idx) >= 20 and all(idx.get(d) is not None for d in range(1, 11)) and idx[2] == idx[1] + 1:
            c1 = idx[1]
            name_c = None
            for rr in rows[hi + 1:hi + 40]:
                for c in range(c1 - 1, -1, -1):
                    if c < len(rr) and isinstance(rr[c], str) and rr[c].strip():
                        name_c = c if name_c is None else min(name_c, c)
                        break
            if name_c is None:
                return None
            cols = []
            grp = ""
            for rr in rows[hi + 1:]:
                nm = rr[name_c] if name_c < len(rr) else None
                vals = [rr[idx[d]] if d in idx and idx[d] < len(rr) and isinstance(rr[idx[d]], (int, float)) else None for d in range(1, 32)]
                if not isinstance(nm, str) or not nm.strip():
                    continue
                nm = nm.strip()
                if nm.upper() in ("TOTAL KWH", "BATH", "VAT 7%", "BATH/KWH", "SUM", "SLIP", "TOTAL"):
                    continue
                if not any(v for v in vals):
                    grp = nm                       # แถวหัวข้อ Section
                    continue
                extra = [str(rr[c]).strip() for c in range(name_c + 1, c1) if c < len(rr) and rr[c] not in (None, "")]
                cols.append({"col": len(cols), "labels": [grp, nm] + extra[:1],
                             "vals": [float(v) if v and v > 0 else None for v in vals]})
            return {"cols": cols, "ndays": 31, "hdr_rows": 1} if cols else None
    return None


# ───────────────────────── v0.67 ไฟล์ประจำวัน Daily_Aisin*_YYYY (แถว = มิเตอร์ · F–AJ = เลขอ่านสะสมวันที่ 1–31) ─────────────────────────

def parse_daily_rows(rows: list[list]) -> dict | None:
    """หัว: Section | Name Meter | No. | Modbus | ยกมา | 1..31 (เลขอ่าน) | 1..31 (หน่วยใช้ — สูตร ไม่อ่าน)
    Section/Name เขียนเฉพาะแถวแรกของกลุ่ม → ลากต่อให้แถวล่าง · คีย์มิเตอร์ = Section | Name | No. (ตรงกับไฟล์ Energy management)"""
    from .energy_cost import meter_key
    hi = None
    for i, r in enumerate(rows[:10]):
        t = [str(x).strip().lower() for x in r[:6] if isinstance(x, str)]
        if any(x.startswith("section") for x in t) and any("name" in x for x in t):
            hi = i
            break
    if hi is None:
        return None
    hdr = [str(x).strip().lower() if isinstance(x, str) else "" for x in rows[hi]]
    c_sec = next((c for c, x in enumerate(hdr) if x.startswith("section")), 0)
    c_name = next((c for c, x in enumerate(hdr) if "name" in x), 1)
    c_no = next((c for c, x in enumerate(hdr) if re.match(r"^no\.?$", x)), None)
    c_carry = next((c for c, x in enumerate(hdr) if "ยกมา" in x or "carry" in x or "b/f" in x), None)
    day_c = None
    for r in rows[hi:hi + 3]:
        idx = {}
        for c, v in enumerate(r):
            if isinstance(v, (int, float)) and float(v).is_integer() and 1 <= v <= 31 and int(v) not in idx:
                idx[int(v)] = c
        if len(idx) >= 28 and idx.get(2) == idx.get(1, -9) + 1:
            day_c = idx
            start = rows.index(r) + 1
            break
    if not day_c:
        return None
    cols = []
    sec = name = ""
    for r in rows[start:]:
        g = lambda c: (r[c] if c is not None and c < len(r) else None)  # noqa: E731
        s_, n_, no_ = g(c_sec), g(c_name), g(c_no)
        if isinstance(s_, str) and s_.strip():
            sec, name = s_.strip(), ""
        if isinstance(n_, str) and n_.strip():
            name = n_.strip()
            if re.match(r"^(รวม|sum|total)\b", name, re.I):
                continue
        if no_ in (None, "") and not (isinstance(n_, str) and n_.strip()):
            continue
        vals = [r[day_c[d]] if d in day_c and day_c[d] < len(r) and isinstance(r[day_c[d]], (int, float)) else None for d in range(1, 32)]
        vals = [float(v) if v else None for v in vals]
        carry = g(c_carry)
        carry = float(carry) if isinstance(carry, (int, float)) and carry else None
        if isinstance(no_, float) and no_.is_integer():
            no_ = int(no_)
        key = meter_key(sec, name, no_)
        if any(c["info"]["key"] == key for c in cols):
            key = f"{key} #{sum(1 for c in cols if c['info']['key'].split(' #')[0] == key) + 1}"[:150]
        cols.append({"col": len(cols), "labels": [sec, name, str(no_ or "")], "vals": vals, "carry": carry,
                     "info": {"key": key, "code": str(no_ or "")[:60], "name": (name or str(no_ or ""))[:120], "grp": sec[:80], "price": None}})
    return {"cols": cols, "ndays": 31, "hdr_rows": 1} if cols else None
