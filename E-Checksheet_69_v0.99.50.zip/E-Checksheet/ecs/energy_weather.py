"""ecs/energy_weather.py — v0.99.50 อุณหภูมิอากาศ (ใช้อธิบายการใช้ไฟของ Chiller / แอร์ และปรับค่าฐาน)

แหล่งข้อมูล: Open-Meteo (ฟรี ไม่ต้องใช้คีย์) ตามพิกัดโรงงาน — ดึงอัตโนมัติชั่วโมงละครั้งโดยงานเบื้องหลัง
หรือกรอก/วาง/นำเข้าไฟล์ CSV เอง (เครือข่ายโรงงานที่ออกอินเทอร์เน็ตไม่ได้)
CDD (Cooling Degree Days) = max(0, อุณหภูมิเฉลี่ยวัน − ฐาน 25 °C) ใช้เป็นตัวแปรที่ 2 ของค่าฐาน
"""
from __future__ import annotations

import json
import logging
import re
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta

from . import energy as EN
from . import services as S
from .services import ValidationError

CDD_BASE = 25.0
TIMEOUT = 15
log = logging.getLogger(__name__)

DDL = """
CREATE TABLE IF NOT EXISTS en_weather (
    ts      TEXT PRIMARY KEY,          -- YYYY-MM-DD HH:00 (เวลาไทย)
    temp    REAL NOT NULL,
    src     TEXT NOT NULL DEFAULT 'manual'
);
"""


def ensure(db) -> None:
    db.executescript(DDL)


def location(db) -> tuple[float, float] | None:
    cfg = EN.settings(db)
    lat, lon = float(cfg.get("wx_lat") or 0), float(cfg.get("wx_lon") or 0)
    return (lat, lon) if lat and lon else None


def save_location(db, lat: str, lon: str, actor) -> None:
    try:
        la, lo = float(lat), float(lon)
    except (TypeError, ValueError):
        raise ValidationError(["พิกัดต้องเป็นตัวเลข เช่น 13.36 และ 101.00"]) from None
    if not (-90 <= la <= 90 and -180 <= lo <= 180):
        raise ValidationError(["พิกัดไม่ถูกต้อง"])
    EN.save_settings(db, {"wx_lat": la, "wx_lon": lo}, actor)


def store(db, rows: list[tuple[str, float]], src: str) -> int:
    ensure(db)
    n = 0
    for t, v in rows:
        db.execute("INSERT INTO en_weather(ts, temp, src) VALUES (?,?,?) ON CONFLICT(ts) DO UPDATE SET temp=excluded.temp, src=excluded.src", (t, float(v), src))
        n += 1
    return n


def _get(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8"))


def fetch(db, d0: date, d1: date, opener=None) -> int:
    """ดึงอุณหภูมิรายชั่วโมงจาก Open-Meteo (ย้อนหลังใช้ archive · 7 วันล่าสุดใช้ forecast/past_days)"""
    loc = location(db)
    if not loc:
        raise ValidationError(["ยังไม่ได้ตั้งพิกัดโรงงาน"])
    get = opener or _get
    today = S.now_dt().date()
    rows: list = []
    base = {"latitude": loc[0], "longitude": loc[1], "hourly": "temperature_2m", "timezone": "Asia/Bangkok"}
    old_end = min(d1, today - timedelta(days=6))
    if d0 <= old_end:
        q = urllib.parse.urlencode({**base, "start_date": d0.isoformat(), "end_date": old_end.isoformat()})
        rows += _parse(get("https://archive-api.open-meteo.com/v1/archive?" + q))
    if d1 > today - timedelta(days=6):
        q = urllib.parse.urlencode({**base, "past_days": 7, "forecast_days": 1})
        rows += [r for r in _parse(get("https://api.open-meteo.com/v1/forecast?" + q)) if d0.isoformat() <= r[0][:10] <= d1.isoformat()]
    return store(db, rows, "open-meteo")


def _parse(js: dict) -> list[tuple[str, float]]:
    h = js.get("hourly") or {}
    out = []
    for t, v in zip(h.get("time") or [], h.get("temperature_2m") or []):
        if v is not None:
            out.append((t.replace("T", " ")[:13] + ":00", float(v)))
    return out


def import_text(db, text: str) -> int:
    """วางจาก Excel/CSV: “วันที่ เวลา, อุณหภูมิ” หรือ “วันที่, อุณหภูมิ” (ค่าเฉลี่ยวัน)"""
    rows, bad = [], []
    for ln in (text or "").splitlines():
        ln = ln.strip()
        if not ln or ln.lower().startswith(("date", "วันที่", "ts")):
            continue
        parts = [p.strip() for p in re.split(r"[,\t;]", ln) if p.strip()]
        m = re.match(r"(\d{4}-\d{2}-\d{2})(?:[ T](\d{1,2})(?::\d{2})?)?$", parts[0]) if parts else None
        if not m or len(parts) < 2:
            bad.append(ln)
            continue
        try:
            v = float(parts[-1])
            date.fromisoformat(m.group(1))
        except ValueError:
            bad.append(ln)
            continue
        if not -30 <= v <= 60:
            bad.append(ln)
            continue
        if m.group(2) is not None:
            rows.append((f"{m.group(1)} {int(m.group(2)):02d}:00", v))
        else:
            rows += [(f"{m.group(1)} {h:02d}:00", v) for h in range(24)]       # ค่าเฉลี่ยวัน → ใช้ทุกชั่วโมง
    if bad and not rows:
        raise ValidationError([f"อ่านไม่ได้ {len(bad)} บรรทัด เช่น “{bad[0][:40]}” — รูปแบบ: 2026-11-10 14:00, 33.5 หรือ 2026-11-10, 29.8"])
    return store(db, rows, "manual")


def hourly(db, day: date) -> list[float | None]:
    ensure(db)
    out: list = [None] * 24
    for t, v in db.execute("SELECT ts, temp FROM en_weather WHERE ts LIKE ?", (day.isoformat() + "%",)):
        out[int(t[11:13])] = round(v, 1)
    return out


def daily(db, d0: date, d1: date) -> dict[str, dict]:
    ensure(db)
    acc: dict = {}
    for t, v in db.execute("SELECT ts, temp FROM en_weather WHERE ts >= ? AND ts < ?", (d0.isoformat(), (d1 + timedelta(days=1)).isoformat())):
        a = acc.setdefault(t[:10], [])
        a.append(v)
    return {d: {"mean": round(sum(v) / len(v), 2), "max": max(v), "min": min(v), "n": len(v), "cdd": round(max(0.0, sum(v) / len(v) - CDD_BASE), 2)}
            for d, v in acc.items() if len(v) >= 12}


def due_fetch(db, now: datetime | None = None) -> int:
    """งานเบื้องหลัง: ดึง 3 วันล่าสุดชั่วโมงละครั้ง (เมื่อมีพิกัด) — ออกเน็ตไม่ได้ก็แค่ข้าม"""
    if not location(db):
        return 0
    now = now or S.now_dt()
    ensure(db)
    last = db.execute("SELECT value FROM cs_meta WHERE key='wx_fetch'").fetchone()
    if last and last[0] and now - datetime.fromisoformat(last[0]) < timedelta(hours=1):
        return 0
    db.execute("INSERT INTO cs_meta(key, value) VALUES ('wx_fetch', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (now.isoformat(timespec="seconds"),))
    try:
        n = fetch(db, now.date() - timedelta(days=3), now.date())
    except Exception as exc:                                # noqa: BLE001
        log.warning("weather fetch failed: %s", exc)
        n = 0
    db.commit()
    return n
