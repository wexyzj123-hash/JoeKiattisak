"""v0.99.48 วิเคราะห์ประสิทธิภาพ: ค่าฐานตามยอดผลิต + CUSUM · วิเคราะห์ตามกะ · การไหลของพลังงาน (Sankey) · ตั้งกะ + ยอดผลิตรายกะ"""
from __future__ import annotations

import calendar
import csv
import io
from datetime import date, timedelta

from flask import Response, flash, redirect, render_template, request, session, url_for

from .. import energy as EN
from .. import energy_field as EF
from .. import energy_perf as PF
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import ValidationError, now_dt
from .energy import ENTRY_ROLES, _ctx, _default_fk, _month, bp

SETUP_ROLES = ("admin", "supervisor")


def _scope():
    """โรงงาน + ประเภท (ผู้ใช้ที่จำกัดโรงงาน → โรงงานของตัวเอง) · หน่วยงาน · ไลน์"""
    db = get_db()
    kind = request.values.get("kind") if request.values.get("kind") in EN.KINDS and request.values.get("kind") != "hours" else None
    fid, kind = _default_fk(db, request.values.get("factory", type=int), kind or "elec")
    sc = EF.user_scope(db, current_user_id())
    if sc["factory_id"]:
        fid = sc["factory_id"]
    grp = (request.values.get("grp") or "")[:80] or None
    line = (request.values.get("line") or "")[:80] or None
    return db, fid, kind, grp, line


def _opts(db, fid, kind) -> dict:
    ms = EN.meters(db, fid, kind, True)
    grps = sorted({(m.get("grp") or "").strip() or PF.NO_SEC for m in ms}, key=lambda g: (g == PF.NO_SEC, g))
    lines: dict[str, list] = {}
    for m in ms:
        lines.setdefault((m.get("grp") or "").strip() or PF.NO_SEC, set()).add((m.get("line") or "").strip() or "-")
    return {"grps": grps, "lines": {g: sorted(v) for g, v in lines.items()}}


def _date(k: str, dflt: date, hi: date) -> date:
    try:
        return min(date.fromisoformat(request.args.get(k) or ""), hi)
    except ValueError:
        return dflt


@bp.route("/baseline")
@require_role(*ALL_ROLES)
def baseline():
    db, fid, kind, grp, line = _scope()
    today = now_dt().date()
    yd = today - timedelta(days=1)
    mark = _date("mark", None, yd) if request.args.get("mark") else None
    db0, db1, dr0, dr1 = PF.default_periods(today, mark)
    b0, b1 = _date("b0", db0, yd), _date("b1", db1, yd)
    r0, r1 = _date("r0", dr0, yd), _date("r1", dr1, yd)
    if b0 > b1:
        b0, b1 = b1, b0
    if r0 > r1:
        r0, r1 = r1, r0
    err = None
    try:
        B = PF.baseline(db, fid, kind, grp, line, b0, b1, r0, r1, wx=request.args.get("wx") == "1")
    except ValidationError as exc:
        err, B = exc.errors[0], None
    if B and request.args.get("format") == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow([f"ค่าฐาน {B['th']} · ฐาน {b0}–{b1} · ติดตาม {r0}–{r1} · โหมด {B['mode']}"
                    + (f" · {B['unit']} = {B['model']['a']} + {B['model']['b']} × ยอดผลิต" if B.get("model") else "")])
        w.writerow(["ช่วง", "วัน/เดือน", "ยอดผลิต", f"ใช้จริง ({B['unit']})", f"ค่าฐาน ({B['unit']})", "ส่วนต่าง", "CUSUM"])
        for p in B["points"]:
            w.writerow(["ฐาน" if p["base"] else ("ติดตาม" if p["rep"] else "-"), p["x"], p["p"], round(p["y"], 1), p.get("e"), p.get("d"), p.get("c")])
        return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=baseline_{r0}_{r1}.csv"})
    return render_template("energy/perf_baseline.html", **_ctx(B=B, err=err, fid=fid, kind=kind, grp=grp, line=line, b0=b0, b1=b1, r0=r0, r1=r1,
                                                               mark=mark, today=today, yd=yd, O=_opts(db, fid, kind), tab="base",
                                                               can_edit=session.get("role") in ENTRY_ROLES))


@bp.route("/shifts")
@require_role(*ALL_ROLES)
def shifts():
    db, fid, kind, grp, _line = _scope()
    now = now_dt()
    month = _month(request.args.get("month"))
    sh = PF.shifts(db, fid)
    last = PF.last_full_day(sh, now)
    m_last = month.replace(day=calendar.monthrange(month.year, month.month)[1])
    d0, d1 = month, min(m_last, last)
    R = PF.shift_report(db, fid, kind, grp, None, d0, d1) if d1 >= d0 else None
    if R and request.args.get("format") == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        names = [s["name"] for s in R["shifts"]["list"]]
        w.writerow(["วันผลิต"] + [f"{n} ({R['unit']})" for n in names] + [f"{n} ยอดผลิต" for n in names] + [f"{n} {R['unit']}/ชิ้น" for n in names])
        for r in R["daily"]:
            w.writerow([r["day"], *r["u"], *r["q"], *r["pu"]])
        return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=shifts_{month.strftime('%Y-%m')}.csv"})
    return render_template("energy/perf_shift.html", **_ctx(R=R, sh=sh, fid=fid, kind=kind, grp=grp, month=month, d0=d0, d1=d1, last=last,
                                                            today=now.date(), O=_opts(db, fid, kind), tab="shift",
                                                            can_edit=session.get("role") in ENTRY_ROLES,
                                                            can_setup=session.get("role") in SETUP_ROLES))


@bp.route("/flow")
@require_role(*ALL_ROLES)
def flow():
    db, fid, kind, _grp, _line = _scope()
    today = now_dt().date()
    month = _month(request.args.get("month"))
    m_last = month.replace(day=calendar.monthrange(month.year, month.month)[1])
    d1 = min(m_last, today - timedelta(days=1)) if today > month else month
    F = PF.flow(db, fid, kind, month, d1)
    return render_template("energy/perf_flow.html", **_ctx(F=F, fid=fid, kind=kind, month=month, today=today, tab="flow",
                                                           can_edit=session.get("role") in ENTRY_ROLES))


@bp.route("/shifts/setup", methods=["GET", "POST"])
@require_role(*ENTRY_ROLES)
def shift_setup():
    """ตั้งกะ (หัวหน้า/ผู้ดูแล) + กรอกยอดผลิตรายกะ ทั้งเดือนในตารางเดียว (ทีมบันทึกค่า)"""
    db, fid, kind, grp, _line = _scope()
    month = _month(request.values.get("month"))
    g = "" if not grp else grp
    if request.method == "POST":
        act = request.form.get("act")
        try:
            if act == "import":
                f = request.files.get("file")
                raw = f.read() if f and f.filename else None
                rows = PF.read_prod_rows(raw, f.filename if f else "", request.form.get("text", ""))
                r = PF.import_prod(db, fid, rows, g, current_user_id())
                db.commit()
                flash(f"นำเข้ายอดผลิต {r['rows']} แถว ({', '.join(r['groups'])})" + (f" · ข้าม {r['n_bad']} แถว: {'; '.join(r['bad'][:3])}" if r["n_bad"] else ""), "ok")
            elif act == "cfg":
                if session.get("role") not in SETUP_ROLES:
                    raise ValidationError(["ตั้งกะได้เฉพาะหัวหน้างาน / ผู้ดูแลระบบ"])
                rows = [{"code": request.form.get(f"code_{i}", ""), "name": request.form.get(f"name_{i}", ""),
                         "start": request.form.get(f"start_{i}", ""), "end": request.form.get(f"end_{i}", "")} for i in range(4)]
                PF.save_shifts(db, fid, rows, current_user_id())
                db.commit()
                flash("บันทึกเวลากะแล้ว", "ok")
            else:
                codes = {s["code"] for s in PF.shifts(db, fid)["list"]}
                cells = {}
                for k, v in request.form.items():
                    if k.startswith("q_"):
                        _, d, c = k.split("_", 2)
                        cells[(d, c)] = v
                n = PF.save_prod(db, fid, g, cells, codes, current_user_id())
                db.commit()
                flash(f"บันทึกยอดผลิตแล้ว ({n} ช่อง)", "ok")
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0], "error")
        return redirect(url_for("energy.shift_setup", factory=fid or "", kind=kind, grp=grp or "", month=month.strftime("%Y-%m")))
    sh = PF.shifts(db, fid)
    dim = calendar.monthrange(month.year, month.month)[1]
    days = [month + timedelta(days=i) for i in range(dim)]
    P = PF.prod_rows(db, fid, g, days[0], days[-1]) if fid else {}
    return render_template("energy/shift_setup.html", **_ctx(sh=sh, fid=fid, kind=kind, grp=grp, month=month, days=days, P=P,
                                                             O=_opts(db, fid, kind), can_setup=session.get("role") in SETUP_ROLES,
                                                             today=now_dt().date()))


@bp.route("/shifts/template.csv")
@require_role(*ALL_ROLES)
def shift_template():
    """แม่แบบไฟล์นำเข้ายอดผลิตรายกะ"""
    db, fid, _kind, grp, _line = _scope()
    sh = PF.shifts(db, fid)["list"]
    today = now_dt().date()
    lines = ["วันที่,กะ,หน่วยงาน,จำนวน"] + [f"{today.isoformat()},{s['code']},{grp or ''},0" for s in sh]
    return Response("\ufeff" + "\n".join(lines) + "\n", mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=shift_production_template.csv"})
