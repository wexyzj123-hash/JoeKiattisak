"""v0.99.49 หน้าภาพรวมพลังงานแบบ Pro — ตัวกรอง โรงงาน · Project · หน่วยงาน · ไลน์ · วันที่ · ทุกตัวเลขกดไปข้อมูลต้นทาง"""
from __future__ import annotations

from datetime import date, timedelta

from flask import jsonify, redirect, render_template, request, session, url_for

from .. import energy as EN
from .. import energy_field as EF
from .. import energy_overview as OV
from .. import energy_struct as ST
from ..db import get_db
from ..security import ALL_ROLES, current_user_id, require_role
from ..services import now_dt
from .energy import _ctx, bp

KEEP = ("factory", "project", "grp", "line", "kind")


def _filters():
    db = get_db()
    fid = request.args.get("factory", type=int) or None
    sc = EF.user_scope(db, current_user_id())
    if sc["factory_id"]:
        fid = sc["factory_id"]
    project_id = request.args.get("project", type=int) or None
    grp = (request.args.get("grp") or "")[:80] or None
    line = (request.args.get("line") or "")[:80] or None
    today = now_dt().date()
    try:
        day = min(date.fromisoformat(request.args.get("day") or ""), today)
    except ValueError:
        day = today
    kind = request.args.get("kind") if request.args.get("kind") in EN.KINDS and request.args.get("kind") != "hours" else "elec"
    return db, fid, project_id, grp, line, day, today, kind


@bp.route("/overview")
@require_role(*ALL_ROLES)
def overview():
    if not request.args and session.get("en_ov"):            # จำตัวกรองล่าสุด
        return redirect(url_for("energy.overview", **session["en_ov"]))
    if request.args:
        session["en_ov"] = {k: request.args[k] for k in KEEP if request.args.get(k)}
    db, fid, project_id, grp, line, day, today, kind = _filters()
    if request.args.get("meter", type=int):                   # กดมิเตอร์ (ระดับล่างสุด) → หน้ามิเตอร์
        return redirect(url_for("energy.meter_detail", mid=request.args.get("meter", type=int)) + f"?pday={day.isoformat()}#prof")
    O = OV.build(db, day, fid, project_id, grp, line, kind=kind)
    base = EN.meters(db, fid, kind, True)
    kinds = [k for k in EN.KIND_ORDER if k != "hours" and db.execute("SELECT 1 FROM en_meters WHERE active=1 AND kind=?" + (" AND factory_id=?" if fid else "") + " LIMIT 1",
                                                                       (k, fid) if fid else (k,)).fetchone()]
    fc = ST.facets(base)
    fc_s = ST.facets(ST.apply_filter(base, project_id)) if project_id else fc
    fc_l = ST.facets(ST.apply_filter(base, project_id, grp)) if grp else fc_s
    q = {k: v for k, v in (("factory", fid), ("project", project_id), ("grp", grp), ("line", line), ("kind", kind if kind != "elec" else None)) if v}
    qd = {**q, "day": day.isoformat()} if day != today else dict(q)

    def drill(extra: dict | None) -> str | None:
        if extra is None:
            return None
        return url_for("energy.overview", **{**qd, **{k: v for k, v in extra.items() if v is not None}})
    src = {
        "live": url_for("energy_live.page", **{**q, "day": day.isoformat()}),
        "power": url_for("energy_pw.power", factory=fid or ""),
        "rate": url_for("energy_pw.power", tab="rate", factory=fid or "") + "#budget",
        "month_json": url_for("energy.overview_month", factory=fid or "") if kind == "elec" and not (project_id or grp or line) else None,
        "cost": url_for("energy_cost.home", factory=fid or ""),
        "co2": url_for("energy_sum.summary"),
        "dept": url_for("energy.dept", factory=fid or ""),
        "month": url_for("energy.dashboard", **q),
        "health": url_for("energy_src.sources") if session.get("role") == "admin" else url_for("energy.meters", factory=fid or ""),
        "compare": url_for("energy.compare", factory=fid or "", grp=grp or ""),
    }
    for r in O["top"]:
        r["url"] = drill(r["q"])
        r["dept_url"] = url_for("energy.dept", factory=fid or "", grp=r["q"].get("grp")) if O["level"] == "grp" else None
    for x in O["flow"]["nodes"]:
        x["url"] = drill(x.get("q"))
    for t in O["tracker"]:
        lq = {**q, **{k: v for k, v in t["q"].items() if k != "meter"}, "day": day.isoformat()}
        t["url"] = drill(t["q"])
        t["live"] = url_for("energy_live.page", **lq)
    names = {"factory": None, "project": None}
    from .. import masterdata as M
    facs = M.list_factories(db)
    crumbs = [{"label": "ทุกโรงงาน", "url": url_for("energy.overview", factory="", **({"day": day.isoformat()} if day != today else {}))}]
    if fid:
        crumbs.append({"label": next((f["name"] for f in facs if f["id"] == fid), f"#{fid}"), "url": drill({}) if not (project_id or grp or line) else
                       url_for("energy.overview", factory=fid, **({"day": day.isoformat()} if day != today else {}))})
    if project_id:
        names["project"] = next((p["name"] for p in fc["projects"] if p["id"] == project_id), "Project")
        crumbs.append({"label": names["project"], "url": url_for("energy.overview", **{k: v for k, v in qd.items() if k not in ("grp", "line")})})
    if grp:
        crumbs.append({"label": "ไม่ระบุหน่วยงาน" if grp == "-" else grp, "url": url_for("energy.overview", **{k: v for k, v in qd.items() if k != "line"})})
    if line:
        crumbs.append({"label": "ไม่ระบุไลน์" if line == "-" else line, "url": drill({})})
    chart = {"today": O["hourly"]["today"], "yday": O["hourly"]["yday"], "cur": O["hourly"]["cur"], "is_today": O["is_today"], "live": src["live"],
             "temp": O["hourly"]["temp"],
             "unit": O["unit"]}
    return render_template("energy/overview.html", **_ctx(O=O, fid=fid, project_id=project_id, grp=grp, line=line, day=day, today=today,
                                                         fc=fc, fc_s=fc_s, fc_l=fc_l, crumbs=crumbs, src=src, chart=chart, q=q, now=now_dt(), kind=kind, kinds=kinds,
                                                         can_lead=session.get("role") in ("admin", "supervisor"),
                                                         scoped=bool(EF.user_scope(db, current_user_id())["factory_id"])))


@bp.route("/overview.json")
@require_role(*ALL_ROLES)
def overview_json():
    """ข้อมูลเดียวกับหน้าภาพรวม (สำหรับจอทีวี / ระบบอื่นดึงไปใช้)"""
    db, fid, project_id, grp, line, day, _today, kind = _filters()
    O = OV.build(db, day, fid, project_id, grp, line, kind=kind)
    k = O["kpis"]
    return jsonify({"day": day.isoformat(), "upto": O["upto"], "level": O["level"], "kind": O["kind"], "unit": O["unit"],
                    "kwh": round(k["kwh"]["value"], 1), "kwh_cmp": round(k["kwh"]["cmp"], 1), "pct": k["kwh"]["pct"],
                    "kw": k["kw"]["value"], "baht": round(k["baht"]["value"]), "co2_t": round(k["co2"]["value"], 3),
                    "groups": [{"name": r["name"], "kwh": round(r["sum"], 1), "kw": r["kw"], "chg": r["chg"], "state": r["st"]} for r in O["top"]],
                    "hourly": O["hourly"]["today"], "hourly_yday": O["hourly"]["yday"],
                    "meters": O["health"]["n"], "meters_data": O["health"]["n_data"]})


@bp.route("/overview/month.json")
@require_role(*ALL_ROLES)
def overview_month():
    """v0.99.50 ค่าไฟเดือนนี้ (ประมาณบิลเต็ม TOU + Demand + Ft + PF + VAT) · คาดการณ์สิ้นเดือน · เทียบงบ — โหลดแยกหลังหน้าเปิด (ใช้ข้อมูลทั้งเดือน)"""
    from .. import energy_bill as BL
    from .. import masterdata as M
    db, fid, _p, _g, _l, day, _t, _k = _filters()
    fids = [fid] if fid else [f["id"] for f in M.list_factories(db)]
    r = BL.month_status(db, fids, day.replace(day=1), day)
    return jsonify({"mtd": round(r["mtd"]), "forecast": round(r["forecast"]) if r["forecast"] is not None else None, "budget": r["budget"],
                    "mtd_pct": r["mtd_pct"], "fc_pct": r["fc_pct"], "time_pct": r["time_pct"], "n_days": r["n_days_i"], "dim": r["dim"],
                    "pf": sum(x["pf"] or 0 for x in r["rows"]) if any(x["pf"] is not None for x in r["rows"]) else None,
                    "bills": sum(1 for x in r["rows"] if x["bill"]), "n": len(r["rows"])})


def _range(default_days: int = 7):
    today = now_dt().date()
    try:
        d1 = min(date.fromisoformat(request.args.get("to") or ""), today)
    except ValueError:
        d1 = today - timedelta(days=1)
    try:
        d0 = min(date.fromisoformat(request.args.get("from") or ""), d1)
    except ValueError:
        d0 = d1 - timedelta(days=default_days - 1)
    return d0, d1, today


@bp.route("/reconcile")
@require_role(*ALL_ROLES)
def reconcile():
    """v0.99.50 กระทบยอด: ค่าอ่านรายวัน vs ราย 15 นาที ต่อมิเตอร์"""
    from .. import energy_recon as RC
    db, fid, _p, _g, _l, _d, _t, kind = _filters()
    d0, d1, today = _range(7)
    R = RC.reconcile(db, fid, kind, d0, d1)
    st = request.args.get("st") if request.args.get("st") in ("bad", "warn", "only_r", "only_i", "ok", "none") else None
    rows = [r for r in R["rows"] if not st or r["st"] == st]
    if request.args.get("format") == "csv":
        import csv
        import io

        from flask import Response
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["มิเตอร์", "โรงงาน", "หน่วยงาน", "Tag", f"ค่าอ่านรายวัน ({R['unit']})", f"ราย 15 นาที ({R['unit']})", "ต่าง", "ต่าง %", "สถานะ", "วันที่มีทั้งสองแหล่ง"])
        for r in rows:
            w.writerow([r["label"], r["factory"], r["grp"], r["src"], r["rb"], r["ib"], r["diff"], r["pct"], r["st"], r["days_both"]])
        return Response("﻿" + buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename=reconcile_{d0}_{d1}.csv"})
    cfg = EN.settings(db)
    return render_template("energy/reconcile.html", **_ctx(R=R, rows=rows[:400], n_rows=len(rows), st=st, fid=fid, kind=kind, d0=d0, d1=d1, today=today,
                                                          read_at=f"{int(cfg.get('scada_hh') or 0):02d}:{int(cfg.get('scada_mm') or 0):02d}"))


@bp.route("/tree")
@require_role(*ALL_ROLES)
def meter_tree():
    """v0.99.50 ผังมิเตอร์แม่–ลูก: แม่ vs ผลรวมลูก · ส่วนที่ไม่ได้วัด/สูญเสีย"""
    from .. import energy_recon as RC
    db, fid, _p, _g, _l, _d, _t, kind = _filters()
    d0, d1, today = _range(30)
    T = RC.tree(db, fid, kind, d0, d1)
    return render_template("energy/tree.html", **_ctx(T=T, fid=fid, kind=kind, d0=d0, d1=d1, today=today,
                                                     can_edit=session.get("role") in ("admin", "supervisor", "technician")))


@bp.route("/weather", methods=["GET", "POST"])
@require_role(*ALL_ROLES)
def weather():
    """v0.99.50 อุณหภูมิอากาศ: ตั้งพิกัด · ดึงจาก Open-Meteo · วางข้อมูลเอง"""
    from flask import flash

    from .. import energy_weather as WX
    from ..services import ValidationError
    db = get_db()
    WX.ensure(db)
    lead = session.get("role") in ("admin", "supervisor")
    if request.method == "POST":
        if not lead:
            return render_template("error.html", code=403, message="เฉพาะหัวหน้างาน/ผู้ดูแลระบบ"), 403
        act = request.form.get("act")
        try:
            if act == "loc":
                WX.save_location(db, request.form.get("lat"), request.form.get("lon"), current_user_id())
                msg = "บันทึกพิกัดแล้ว — ระบบจะดึงอุณหภูมิให้อัตโนมัติชั่วโมงละครั้ง"
            elif act == "fetch":
                days = max(1, min(400, request.form.get("days", type=int) or 30))
                today = now_dt().date()
                n = WX.fetch(db, today - timedelta(days=days), today)
                msg = f"ดึงอุณหภูมิแล้ว {n} ชั่วโมง"
            elif act == "import":
                n = WX.import_text(db, request.form.get("text", ""))
                msg = f"นำเข้าแล้ว {n} ชั่วโมง"
            else:
                raise ValidationError(["คำสั่งไม่ถูกต้อง"])
            db.commit()
            flash(msg, "ok")
        except ValidationError as exc:
            db.rollback()
            flash(exc.errors[0] if isinstance(exc.errors, list) else str(exc.errors), "error")
        except Exception as exc:                                # noqa: BLE001
            db.rollback()
            flash(f"ดึงข้อมูลไม่สำเร็จ ({type(exc).__name__}) — เครือข่ายอาจออกอินเทอร์เน็ตไม่ได้ ใช้การวางข้อมูลแทนได้", "error")
        return redirect(url_for("energy.weather"))
    today = now_dt().date()
    D = WX.daily(db, today - timedelta(days=30), today)
    rows = [{"day": d, **D[d]} for d in sorted(D, reverse=True)]
    return render_template("energy/weather.html", **_ctx(loc=WX.location(db), rows=rows, lead=lead, today=today,
                                                        last=db.execute("SELECT MAX(ts) FROM en_weather").fetchone()[0], base=WX.CDD_BASE))
