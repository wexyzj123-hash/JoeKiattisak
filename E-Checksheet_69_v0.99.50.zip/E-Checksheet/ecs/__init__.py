"""E-Checksheet — ระบบตรวจเช็คออนไลน์ (แยกอิสระจาก UT-CMMS)

create_app() สร้างแอป Flask พร้อมฐานข้อมูลของตัวเอง
"""
from __future__ import annotations

import logging
import os
from datetime import timedelta

from flask import Flask, redirect, request, session, url_for

from . import cmms_bridge
from . import db as dbmod
from .security import ROLE_TH, check_csrf, csrf_token
from .settings import load_config, secret_key

__version__ = "0.99.50"


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(load_config())
    app.secret_key = secret_key()
    app.config.update(
        MAX_CONTENT_LENGTH=200 * 1024 * 1024,        # 1 การส่งผลตรวจรวมรูปต้นฉบับไม่เกิน 200 MB (ระบบย่อรูปก่อนเก็บ)
        SEND_FILE_MAX_AGE_DEFAULT=0,
        SESSION_COOKIE_NAME="ecs_session",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
    )
    if test_config:
        app.config.update(test_config)
    app.config["SESSION_COOKIE_SECURE"] = bool(app.config.get("SECURE_COOKIES"))
    app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=int(app.config["SESSION_TIMEOUT_MIN"]))
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    dbmod.init_app(app)

    @app.before_request
    def _before():
        session.permanent = True        # ต่ออายุทุกครั้งที่ใช้งาน → หมดอายุเมื่อไม่ได้ใช้งานนานเกิน
        check_csrf()
        cmms_bridge.sync_session()      # รวมกับ UT-CMMS: login/logout ร่วมกัน (ไม่ทำอะไรถ้า CMMS_LINK ปิด)
        # บังคับเปลี่ยนรหัสผ่านครั้งแรก (บัญชีที่ผู้ดูแลสร้าง/รีเซ็ตให้)
        if session.get("must_change_pw") and request.endpoint not in (
                "auth.password", "auth.logout", "static", "mobile.service_worker", "mobile.manifest"):
            if request.path.startswith("/api/"):
                from flask import jsonify
                return jsonify({"error": "กรุณาเปลี่ยนรหัสผ่านก่อนใช้งาน", "code": "must_change_password"}), 403
            return redirect(url_for("auth.password"))
        from . import perms as _perms
        blocked = _perms.guard_view_as()    # v0.52 ดูหน้าจอแทนผู้ใช้ = อ่านอย่างเดียว
        if blocked is not None:
            return blocked
        from . import view_scope
        return view_scope.guard()           # v0.29 บัญชีที่ถูกจำกัด (ENV/SAFETY) เห็นเฉพาะเช็คชีทที่มีสิทธิ์อนุมัติ

    @app.after_request
    def _headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        return resp

    @app.template_global()
    def static_v(filename: str) -> str:
        path = os.path.join(app.static_folder, filename)
        try:
            ver = int(os.path.getmtime(path))
        except OSError:
            ver = 0
        return f"{url_for('static', filename=filename)}?v={ver}"

    @app.context_processor
    def _globals():
        return {"csrf_token": csrf_token, "ROLE_TH": ROLE_TH, "APP_NAME": app.config["APP_NAME"],
                "APP_VERSION": __version__, "CMMS_LINK": bool(app.config.get("CMMS_LINK")),
                "CMMS_HOME": app.config.get("CMMS_HOME") or "/", "CMMS_LINKED_USER": bool(session.get("cmms_uid")),
                "VIEW_AS": session.get("view_as")}

    from . import roster as _roster
    _roster.bind(app.config)                # v0.51 งานเบื้องหลังอ่านตารางกะ UT-CMMS ได้
    from .views import register
    register(app)
    app.register_blueprint(cmms_bridge.bp)

    @app.route("/")
    def index():
        if "user_id" not in session:
            return redirect(url_for("auth.login"))
        if session.get("role") == "technician":
            return redirect(url_for("mobile.home"))
        return redirect(url_for("dash.dashboard"))

    if app.config.get("ENABLE_JOBS") and not app.config.get("TESTING"):
        from .jobs import start_jobs
        from .notify import start_notifier
        start_jobs(app)
        start_notifier(app)
    return app
