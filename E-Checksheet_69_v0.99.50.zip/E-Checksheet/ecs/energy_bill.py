"""ecs/energy_bill.py — v0.99.50 ค่าไฟที่ตรงบิล

day_cost()      ค่าไฟของวัน/ช่วง จากค่าราย 15 นาที: แยก On-Peak / Off-Peak ตามเวลาจริง (TOU) + Ft + VAT ตามอัตราของแต่ละโรงงาน
kvar_peak()     kVAR สูงสุดของเดือน (รวมทุกมิเตอร์ที่มี Tag kVAR ณ เวลาเดียวกัน) → ค่าปรับ PF (kVAR เกิน 61.97% ของ kW สูงสุด)
budget          งบค่าไฟรายเดือนต่อโรงงาน (en_budget) · ตั้งทั้งปีในตารางเดียว
month_status()  ค่าไฟเดือนนี้ถึงวันนี้ (ประมาณบิลเต็ม: พลังงาน TOU + Demand + Ft + ค่าบริการ + ค่าปรับ PF + VAT) · คาดการณ์สิ้นเดือน · เทียบงบ
"""
from __future__ import annotations

import calendar
import time as _time
from datetime import date, datetime, time, timedelta

from . import energy_power as PW
from . import services as S
from .services import ValidationError

PF_KVAR_RATIO = 0.6197      # kVAR เกิน 61.97% ของ kW สูงสุด (PF < 0.85) คิดค่าปรับ ตามประกาศการไฟฟ้า
SLOT = 15

DDL = """
CREATE TABLE IF NOT EXISTS en_budget (
    factory_id  INTEGER NOT NULL,
    month       TEXT NOT NULL,
    baht        REAL NOT NULL,
    updated_by  INTEGER,
    updated_at  TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (factory_id, month)
);
"""


def ensure(db) -> None:
    db.executescript(DDL)


def slot_cost(cfg: dict, slots: list, day: date, hol: dict) -> dict:
    """ค่าพลังงานของ 1 วัน (96 ช่อง) ตามอัตรา TOU / อัตราปกติ + Ft + VAT (ยังไม่รวม Demand / ค่าบริการ ซึ่งคิดรายเดือน)"""
    on = off = 0.0
    a = datetime.combine(day, time(0, 0))
    for i, v in enumerate(slots):
        if v is None:
            continue
        if cfg["tou"] and PW.is_on_peak(a + timedelta(minutes=SLOT * i), cfg, hol):
            on += v
        else:
            off += v
    kwh = on + off
    energy = on * cfg["on_rate"] + off * cfg["off_rate"] if cfg["tou"] else kwh * cfg["flat_rate"]
    ft = kwh * (cfg.get("ft") or 0)
    vat = (energy + ft) * (cfg.get("vat") or 0) / 100
    return {"kwh": kwh, "on": on, "off": off, "energy": energy, "ft": ft, "vat": vat, "total": energy + ft + vat}


def add(a: dict, b: dict) -> dict:
    return {k: a.get(k, 0.0) + b.get(k, 0.0) for k in set(a) | set(b)}


def day_cost(db, per_meter: dict[int, list], meters: list[dict], day: date) -> dict:
    """per_meter = {meter_id: 96 ช่อง} ของมิเตอร์ที่นับ (ไม่ซ้อน) — คิดตามอัตราของโรงงานที่มิเตอร์อยู่"""
    by_f: dict = {}
    for m in meters:
        row = per_meter.get(m["id"])
        if not row:
            continue
        acc = by_f.setdefault(m.get("factory_id") or 0, [None] * len(row))
        for i, v in enumerate(row):
            if v is not None:
                acc[i] = (acc[i] or 0.0) + v
    out = {"kwh": 0.0, "on": 0.0, "off": 0.0, "energy": 0.0, "ft": 0.0, "vat": 0.0, "total": 0.0}
    tou = False
    for f, row in by_f.items():
        cfg = PW.tariff(db, f)
        tou = tou or bool(cfg["tou"])
        out = add(out, slot_cost(cfg, row, day, PW.holidays(db, f, day, day)))
    out["rate"] = out["total"] / out["kwh"] if out["kwh"] else None
    out["on_pct"] = round(100 * out["on"] / out["kwh"], 1) if out["kwh"] else None
    out["tou"] = tou
    return out


def kvar_peak(db, fid: int, d0: date, d1: date) -> float | None:
    """kVAR สูงสุดของช่วง: รวมทุกมิเตอร์ (ที่นับ ไม่ซ้อน) ที่มี Tag kVAR ณ เวลาเดียวกัน"""
    PW.ensure(db)
    ids = [m["id"] for m in PW._elec_counted(db, fid)]
    if not ids:
        return None
    rows = db.execute(f"""SELECT ts, SUM(value) FROM en_params WHERE param='kvar' AND meter_id IN ({','.join('?' * len(ids))})
                           AND ts>=? AND ts<? GROUP BY ts ORDER BY 2 DESC LIMIT 1""",
                      [*ids, S.ts(datetime.combine(d0, time(0, 0))), S.ts(datetime.combine(d1 + timedelta(days=1), time(0, 0)))]).fetchone()
    return float(rows[1]) if rows and rows[1] is not None else None


def pf_charge(cfg: dict, demand_kw: float, kvar: float | None) -> float | None:
    if kvar is None:
        return None
    return max(0.0, kvar - PF_KVAR_RATIO * (demand_kw or 0)) * (cfg.get("kvar_rate") or 0)


# ── งบประมาณ ──

def budget(db, fid: int, month: date) -> float | None:
    ensure(db)
    r = db.execute("SELECT baht FROM en_budget WHERE factory_id=? AND month=?", (fid, month.strftime("%Y-%m"))).fetchone()
    return float(r[0]) if r else None


def budget_year(db, fid: int, year: int) -> dict[int, float]:
    ensure(db)
    return {int(m[5:7]): float(b) for m, b in db.execute("SELECT month, baht FROM en_budget WHERE factory_id=? AND month LIKE ?", (fid, f"{year}-%"))}


def save_budget_year(db, fid: int, year: int, vals: dict[int, str], actor) -> int:
    if not fid:
        raise ValidationError(["เลือกโรงงานก่อนตั้งงบ"])
    ensure(db)
    n, bad = 0, []
    for mo, raw in vals.items():
        if not 1 <= mo <= 12:
            continue
        ym = f"{year}-{mo:02d}"
        raw = (raw or "").replace(",", "").strip()
        if raw == "":
            n += db.execute("DELETE FROM en_budget WHERE factory_id=? AND month=?", (fid, ym)).rowcount
            continue
        try:
            v = float(raw)
            if v < 0:
                raise ValueError
        except ValueError:
            bad.append(f"เดือน {mo}: “{raw}”")
            continue
        db.execute("""INSERT INTO en_budget(factory_id, month, baht, updated_by, updated_at) VALUES (?,?,?,?,?)
                      ON CONFLICT(factory_id, month) DO UPDATE SET baht=excluded.baht, updated_by=excluded.updated_by, updated_at=excluded.updated_at""",
                   (fid, ym, v, actor, S.now_dt().isoformat(timespec="seconds")))
        n += 1
    if bad:
        raise ValidationError(["งบต้องเป็นตัวเลข ≥ 0: " + " · ".join(bad)])
    return n


# ── สถานะเดือน (แคช 10 นาที: ใช้ข้อมูลราย 15 นาทีทั้งเดือน) ──

def _data_days(per_day: list[dict], fallback: float) -> float:
    """จำนวนวันที่มีข้อมูลจริง: วันเต็ม + เศษของวันสุดท้าย (เทียบค่ากลางของวันก่อนหน้า)"""
    vals = [(d.get("on") or 0) + (d.get("off") or 0) for d in per_day]
    while vals and not vals[-1]:
        vals.pop()
    if not vals:
        return fallback
    full = sorted(v for v in vals[:-1] if v > 0)
    if not full:
        return float(len(vals))
    med = full[len(full) // 2]
    return len(vals) - 1 + (min(1.0, vals[-1] / med) if med else 1.0)



_CACHE: dict = {}
TTL = 600


def month_status(db, fids: list[int], month: date, today: date | None = None) -> dict:
    today = today or S.now_dt().date()
    key = (tuple(sorted(fids)), month, today)
    hit = _CACHE.get(key)
    if hit and _time.time() - hit[0] < TTL:
        return hit[1]
    dim = calendar.monthrange(month.year, month.month)[1]
    if month == today.replace(day=1):                         # เดือนปัจจุบัน: นับวันที่ผ่านไปจริง (รวมเศษของวันนี้)
        now = S.now_dt()
        n_days = (today - month).days + (now.hour * 60 + now.minute) / 1440
    else:
        n_days = dim if month < today.replace(day=1) else 0
    rows = []
    for f in fids:
        t = PW.tou(db, f, month, today)
        est = t.get("est")
        b = budget(db, f, month)
        cfg = t["cfg"]
        if not est and not b:
            continue
        total = est["total"] if est else 0
        svc = (cfg.get("service") or 0) * (1 + (cfg.get("vat") or 0) / 100)
        dem = (est["demand"] if est else 0) * (1 + (cfg.get("vat") or 0) / 100)
        pfc = (est.get("pf") or 0) * (1 + (cfg.get("vat") or 0) / 100) if est else 0
        var = total - svc - dem - pfc                          # ส่วนที่โตตามจำนวนวัน
        nd = _data_days(t.get("per_day") or [], n_days)        # นับวันตามข้อมูลที่เข้ามาจริง (SCADA ล่าช้า → ไม่ทำให้คาดการณ์เพี้ยน)
        fc = var / nd * dim + svc + dem + pfc if nd > 0 and est else None
        rows.append({"fid": f, "mtd": total, "forecast": fc, "budget": b, "peak": t.get("peak_on"), "target": t.get("target"),
                     "pf": est.get("pf") if est else None, "bill": t.get("bill"), "cover": t.get("cover")})
    mtd = sum(r["mtd"] for r in rows)
    fc = sum(r["forecast"] or 0 for r in rows) if rows and all(r["forecast"] is not None for r in rows) else None
    bud = sum(r["budget"] for r in rows if r["budget"]) if rows and all(r["budget"] for r in rows) else None
    res = {"month": month, "rows": rows, "mtd": mtd, "forecast": fc, "budget": bud, "n_days": n_days, "dim": dim,
           "mtd_pct": round(100 * mtd / bud, 1) if bud else None, "fc_pct": round(100 * fc / bud, 1) if bud and fc else None,
           "time_pct": round(100 * n_days / dim, 1), "n_days_i": int(n_days)}
    _CACHE[key] = (_time.time(), res)
    if len(_CACHE) > 200:
        _CACHE.clear()
    return res
