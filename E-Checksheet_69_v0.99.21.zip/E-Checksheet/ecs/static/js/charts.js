/* charts.js — Phase 3: กราฟ Dashboard / แนวโน้ม (Apache ECharts, ไม่พึ่ง CDN)
 *
 * หลักการ: สีอ่านจาก CSS token (สลับ Light/Dark อัตโนมัติ) · สีหมวดหมู่ใช้ตามลำดับคงที่ ไม่วน
 * สีสถานะ (เขียว/เหลือง/แดง/เทา) มีข้อความกำกับเสมอ · แกนเดียว · มีตารางข้อมูลให้ดูทุกกราฟ
 */
(function () {
  'use strict';
  const charts = [];

  function tok() {
    const cs = getComputedStyle(document.documentElement);
    const v = (n) => cs.getPropertyValue(n).trim();
    return {
      grid: v('--viz-grid'), axis: v('--viz-axis'), muted: v('--muted') || v('--viz-muted'), ink: v('--text') || v('--viz-ink'),
      ink2: v('--viz-ink2'), surface: v('--surface'),
      s: [v('--viz-s1'), v('--viz-s2'), v('--viz-s3')],
      good: v('--st-good'), warning: v('--st-warning'), serious: v('--st-serious'), critical: v('--st-critical'), none: v('--st-none'),
      font: getComputedStyle(document.body).fontFamily,
    };
  }

  const fmtDay = (iso) => iso ? iso.slice(8, 10) + '/' + iso.slice(5, 7) : '';
  const fmtTs = (s) => s ? s.slice(8, 10) + '/' + s.slice(5, 7) + ' ' + s.slice(11, 16) : '';
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
  const num = (v, d) => v == null ? '–' : (Math.round(v * Math.pow(10, d == null ? 2 : d)) / Math.pow(10, d == null ? 2 : d)).toLocaleString('th-TH');

  function base(t) {
    return {
      backgroundColor: 'transparent',
      textStyle: {fontFamily: t.font, color: t.ink},
      animationDuration: 300,
      tooltip: {
        backgroundColor: t.surface, borderColor: t.axis, textStyle: {color: t.ink, fontFamily: t.font, fontSize: 13},
        extraCssText: 'box-shadow:0 4px 14px rgba(0,0,0,.15);border-radius:8px;',
      },
    };
  }
  const axisCommon = (t) => ({
    axisLine: {lineStyle: {color: t.axis}}, axisTick: {show: false},
    axisLabel: {color: t.muted, fontSize: 12}, splitLine: {lineStyle: {color: t.grid}},
  });

  // v0.26.2 iPhone/iPad: จำกัดความละเอียด canvas (จอ Retina 3x กินหน่วยความจำจน Safari ไม่วาดกราฟ)
  const DPR = Math.min(window.devicePixelRatio || 1, 2);
  function fallback(el, err) {
    // วาดกราฟไม่ได้ → บอกผู้ใช้และเปิดตารางข้อมูลแทน (ถ้ามี)
    if (window.ECSLog) window.ECSLog('chart ' + (el && el.id) + ': ' + (err && err.message || err));
    if (!el) return;
    el.innerHTML = '<div class="chart-fail">แสดงกราฟไม่ได้บนเบราว์เซอร์นี้ — ดูข้อมูลในตารางด้านล่าง</div>';
    el.style.height = 'auto';
    const card = el.closest('.chart-card, .card, .dcard');
    const tb = card && card.querySelector('[data-table-toggle]');
    if (tb) { const host = document.getElementById(tb.getAttribute('data-table-toggle')); if (host && host.hidden) tb.click(); }
  }
  function mount(el, render) {
    if (!el) return null;
    if (!window.echarts) { fallback(el, 'echarts not loaded'); return null; }
    let chart;
    try {
      chart = echarts.getInstanceByDom(el) || echarts.init(el, null, {renderer: 'canvas', devicePixelRatio: DPR});
      const entry = {chart, render: () => { try { chart.clear(); chart.setOption(render(tok()), true); } catch (e) { fallback(el, e); } }};
      entry.render();
      charts.push(entry);
      let t = null;                                   // Safari: resize ถี่ตอนแถบที่อยู่เลื่อน → หน่วงไว้
      if (window.ResizeObserver) new ResizeObserver(() => { clearTimeout(t); t = setTimeout(() => chart.resize(), 150); }).observe(el);
      else window.addEventListener('resize', () => chart.resize());
    } catch (e) { fallback(el, e); return null; }
    return chart;
  }

  function table(host, headers, rows, link) {
    if (!host) return;
    host.innerHTML = '<div class="table-wrap"><table class="tbl"><thead><tr>' +
      headers.map((h) => '<th>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>' +
      rows.map((r, i) => '<tr>' + r.map((c, j) => '<td>' + (link && j === 0 ? '<a href="' + esc(link(r, i)) + '">' + esc(c) + '</a>' : esc(c)) + '</td>').join('') + '</tr>').join('') +
      '</tbody></table></div>';
  }

  // ── อัตราตรวจตรงเวลา รายวัน แยกโรงงาน ──
  function compliance(el, data, opts) {
    const order = (opts && opts.factoryOrder) || data.series.map((s) => s.id);
    const vals = data.series.flatMap((s) => s.data).filter((v) => v != null);
    const lo = vals.length ? Math.max(0, Math.floor((Math.min(...vals, data.warn) - 5) / 10) * 10) : 0;
    mount(el, (t) => ({
      ...base(t),
      grid: {left: 44, right: 96, top: 16, bottom: 28},
      tooltip: {...base(t).tooltip, trigger: 'axis', axisPointer: {type: 'line', lineStyle: {color: t.axis}},
        formatter: (ps) => '<b>' + fmtDay(data.days[ps[0].dataIndex]) + '</b><br>' + ps.map((p) =>
          p.marker + esc(p.seriesName) + ' <b>' + (p.value == null ? 'ไม่มีรอบ' : p.value + '%') + '</b>').join('<br>')},
      xAxis: {type: 'category', data: data.days.map(fmtDay), boundaryGap: false, ...axisCommon(t), splitLine: {show: false}},
      yAxis: {type: 'value', min: lo, max: 100, ...axisCommon(t), axisLabel: {color: t.muted, formatter: '{value}%'}},
      series: data.series.map((s, i) => {
        const slot = Math.max(0, order.indexOf(s.id)) % 3;
        return {
          name: s.name, type: 'line', data: s.data, connectNulls: false, showSymbol: data.days.length <= 31, symbolSize: 6,
          lineStyle: {width: 2, color: t.s[slot]}, itemStyle: {color: t.s[slot], borderColor: t.surface, borderWidth: 1},
          endLabel: {show: true, formatter: (p) => s.name + (p.value == null ? '' : ' ' + p.value + '%'), color: t.ink, fontSize: 12},
          emphasis: {focus: 'series'},
          labelLayout: {moveOverlap: 'shiftY'},
          markLine: i ? undefined : {
            silent: true, symbol: 'none', label: {position: 'insideStartTop', fontSize: 11, color: t.muted},
            data: [
              {yAxis: data.good, lineStyle: {color: t.good, type: 'dashed', width: 1}, label: {formatter: 'เป้าหมาย ' + data.good + '%'}},
              {yAxis: data.warn, lineStyle: {color: t.critical, type: 'dashed', width: 1}, label: {formatter: 'ต่ำกว่า ' + data.warn + '% = ต้องแก้ไข'}},
            ],
          },
        };
      }),
    }));
    table(opts && opts.table, ['วันที่'].concat(data.series.map((s) => s.name)),
      data.days.map((d, i) => [fmtDay(d)].concat(data.series.map((s) => s.data[i] == null ? '–' : s.data[i] + '%'))));
  }

  // ── Heatmap อัตราตรวจตรงเวลา: พื้นที่ × วัน (สีตามสถานะ + ตัวเลขใน tooltip/ตาราง) ──
  const ST_IDX = {good: 0, warning: 1, critical: 2, none: 3};
  function heatmap(el, data, opts) {
    if (!data.rows.length) return;
    el.style.height = Math.max(160, data.rows.length * 30 + 60) + 'px';
    const narrow = el.clientWidth < 520;
    mount(el, (t) => {
      const colors = [t.good, t.warning, t.critical, t.none];
      return {
        ...base(t),
        grid: {left: narrow ? 110 : 190, right: 8, top: 8, bottom: 28},
        tooltip: {...base(t).tooltip, formatter: (p) => {
          const c = data.cells[p.dataIndex];
          return '<b>' + esc(data.rows[c.y]) + '</b><br>' + fmtDay(data.days[c.x]) + ' · ' +
            (c.rate == null ? 'ยังไม่มีรอบที่ปิด' : 'ตรงเวลา <b>' + c.rate + '%</b>') +
            '<br>ตรงเวลา ' + c.on_time + ' · ล่าช้า ' + c.late + ' · ขาด ' + c.missed + ' / ' + c.due + ' รอบ';
        }},
        xAxis: {type: 'category', data: data.days.map(fmtDay), ...axisCommon(t), axisLine: {show: false}, splitLine: {show: false}},
        yAxis: {type: 'category', data: data.rows, inverse: true, ...axisCommon(t), axisLine: {show: false}, splitLine: {show: false},
          axisLabel: {color: t.ink, fontSize: 12, width: narrow ? 100 : 180, overflow: 'truncate'}},
        visualMap: {show: false, type: 'piecewise', dimension: 2,
          pieces: colors.map((c, i) => ({value: i, color: c}))},
        series: [{type: 'heatmap', data: data.cells.map((c) => [c.x, c.y, ST_IDX[c.status]]),
          itemStyle: {borderColor: t.surface, borderWidth: 2, borderRadius: 3},
          emphasis: {itemStyle: {borderColor: t.ink, borderWidth: 1}}}],
      };
    });
    table(opts && opts.table, ['พื้นที่', 'วันที่', 'ตรงเวลา %', 'ตรงเวลา', 'ล่าช้า', 'ขาดตรวจ', 'รอบทั้งหมด'],
      data.cells.map((c) => [data.rows[c.y], fmtDay(data.days[c.x]), c.rate == null ? '–' : c.rate, c.on_time, c.late, c.missed, c.due]));
  }

  // ── Pareto หัวข้อที่ NG บ่อย: แท่งแนวนอน + % สะสมเป็นป้ายข้อความ (ไม่ใช้แกนคู่) ──
  function pareto(el, data, opts) {
    const items = data.items.slice().reverse();
    el.style.height = Math.max(160, items.length * 32 + 40) + 'px';
    const labelW = Math.round(Math.min(280, Math.max(110, el.clientWidth * 0.45)));
    const chart = mount(el, (t) => ({
      ...base(t),
      grid: {left: labelW + 10, right: 84, top: 4, bottom: 8},
      tooltip: {...base(t).tooltip, trigger: 'item', formatter: (p) => {
        const it = items[p.dataIndex];
        return '<b>' + esc(it.label) + '</b><br>NG ' + it.ng + ' ครั้ง · สะสม ' + it.cum_pct + '% ของ NG ทั้งหมด<br><span style="opacity:.7">คลิกเพื่อดูผลตรวจ</span>';
      }},
      xAxis: {type: 'value', ...axisCommon(t), axisLabel: {show: false}, splitLine: {show: false}},
      yAxis: {type: 'category', data: items.map((i) => i.label), ...axisCommon(t),
        axisLabel: {color: t.ink, fontSize: 12, width: labelW, overflow: 'truncate'}},
      series: [{type: 'bar', data: items.map((i) => i.ng), barMaxWidth: 20, cursor: 'pointer',
        itemStyle: {color: t.s[0], borderRadius: [0, 4, 4, 0]},
        label: {show: true, position: 'right', color: t.ink, fontSize: 12,
          formatter: (p) => p.value + '  ·  ' + items[p.dataIndex].cum_pct + '%'}}],
    }));
    if (chart && opts && opts.link) chart.on('click', (p) => { location.href = opts.link(items[p.dataIndex]); });
    table(opts && opts.table, ['หัวข้อ', 'NG (ครั้ง)', '% สะสม'], data.items.map((i) => [i.label, i.ng, i.cum_pct + '%']));
  }

  // ── กราฟแนวโน้มของหัวข้อตัวเลข: mode 'spec' (เกณฑ์) หรือ 'spc' (Control chart) ──
  const FLAG_TH = {roc: 'เปลี่ยนเร็ว', spc_sigma: 'หลุด ±kσ', spc_run: 'อยู่ฝั่งเดียว', spc_trend: 'แนวโน้มต่อเนื่อง',
                   stuck: 'ค่าค้าง', baseline: 'ต่างจากช่วงเวลาเดิม'};
  function trend(el, data, opts) {
    const mode = (opts && opts.mode) || 'spec';
    const it = data.item, lim = data.limits;
    const unit = it.unit ? ' ' + it.unit : '';
    const pts = data.points;
    const chart = mount(el, (t) => {
      const lines = [];
      const add = (y, color, type, label) => { if (y != null) lines.push({yAxis: y, lineStyle: {color, type, width: type === 'solid' ? 1.5 : 1}, label: {formatter: label}}); };
      if (mode === 'spc' && lim) {
        add(lim.mean, t.ink2, 'solid', 'Mean ' + num(lim.mean));
        add(lim.ucl, t.ink2, 'dashed', 'UCL ' + num(lim.ucl));
        add(lim.lcl, t.ink2, 'dashed', 'LCL ' + num(lim.lcl));
      } else {
        add(it.max_value, t.critical, 'solid', 'สูงสุด ' + num(it.max_value));
        add(it.min_value, t.critical, 'solid', 'ต่ำสุด ' + num(it.min_value));
        add(it.warn_high, t.warning, 'dashed', 'เตือน ' + num(it.warn_high));
        add(it.warn_low, t.warning, 'dashed', 'เตือน ' + num(it.warn_low));
      }
      // เส้นเกณฑ์ที่อยู่ไกลจากข้อมูลมาก (เช่น ต่ำสุด 0) จะบีบกราฟจนมองไม่เห็นความเปลี่ยนแปลง → ไม่วาด แต่บอกไว้มุมกราฟ
      const dv = pts.map((p) => p.v);
      const dmin = Math.min(...dv), dmax = Math.max(...dv);
      const reach = Math.max((dmax - dmin) * 1.5, Math.abs((dmin + dmax) / 2) * 0.05, 1e-9);
      const far = lines.filter((l) => l.yAxis < dmin - reach || l.yAxis > dmax + reach);
      lines.splice(0, lines.length, ...lines.filter((l) => far.indexOf(l) < 0));
      const ys = dv.concat(lines.map((l) => l.yAxis));
      const pad = ys.length ? (Math.max(...ys) - Math.min(...ys)) * 0.08 || 1 : 1;
      const data2 = pts.map((p) => {
        const flagged = p.flags && p.flags.length;
        let color = t.s[0], symbol = 'circle', size = pts.length > 120 ? 4 : 6;
        if (p.judgement === 'ng') { color = t.critical; symbol = 'triangle'; size = 11; }
        else if (p.judgement === 'warn') { color = t.warning; symbol = 'diamond'; size = 10; }
        return {value: [p.t.replace(' ', 'T'), p.v], symbol, symbolSize: flagged ? Math.max(size, 10) : size,
          itemStyle: {color, borderColor: flagged ? t.ink : t.surface, borderWidth: flagged ? 2 : 1}};
      });
      return {
        ...base(t),
        grid: {left: 56, right: 104, top: far.length ? 30 : 16, bottom: pts.length > 60 ? 64 : 30},
        title: far.length ? {text: far.map((l) => l.label.formatter).join(' · ') + ' — อยู่นอกช่วงกราฟ', right: 8, top: 0,
          textStyle: {fontSize: 12, fontWeight: 'normal', color: t.muted}} : undefined,
        tooltip: {...base(t).tooltip, trigger: 'axis', axisPointer: {type: 'line', lineStyle: {color: t.axis}},
          formatter: (ps) => {
            const p = pts[ps[0].dataIndex];
            const j = p.judgement === 'ng' ? ' <b style="color:' + t.critical + '">NG</b>' : (p.judgement === 'warn' ? ' <b>ช่วงเตือน</b>' : '');
            return '<b>' + fmtTs(p.t) + '</b><br>' + esc(it.name) + ': <b>' + num(p.v, 4) + unit + '</b>' + j +
              (p.flags.length ? '<br>⚑ ' + p.flags.map((f) => FLAG_TH[f] || f).join(', ') : '') +
              '<br><span style="opacity:.75">' + esc(p.inspector || '') + (p.remark ? ' · ' + esc(p.remark) : '') + '</span>' +
              '<br><span style="opacity:.6">คลิกเพื่อเปิดผลตรวจ</span>';
          }},
        xAxis: {type: 'time', ...axisCommon(t), splitLine: {show: false},
          axisLabel: {color: t.muted, fontSize: 12, hideOverlap: true, formatter: {day: '{dd}/{MM}', hour: '{HH}:{mm}', month: '{MM}/{yyyy}'}}},
        yAxis: {type: 'value', scale: true, ...axisCommon(t), axisLabel: {color: t.muted, fontSize: 12, showMinLabel: false, showMaxLabel: false},
          min: ys.length ? (v) => +(Math.min(v.min, ...lines.map((l) => l.yAxis)) - pad).toPrecision(4) : null,
          max: ys.length ? (v) => +(Math.max(v.max, ...lines.map((l) => l.yAxis)) + pad).toPrecision(4) : null},
        dataZoom: pts.length > 60 ? [{type: 'inside'}, {type: 'slider', height: 18, bottom: 8, borderColor: t.axis, textStyle: {color: t.muted}}] : [],
        series: [{
          name: it.name, type: 'line', data: data2, showAllSymbol: true, cursor: 'pointer',
          lineStyle: {width: 2, color: t.s[0]}, emphasis: {scale: 1.4},
          markLine: {silent: true, symbol: 'none', data: lines,
            label: {position: 'end', color: t.ink, fontSize: 11, backgroundColor: t.surface, padding: [1, 3]}},
        }],
      };
    });
    if (chart) chart.on('click', (p) => { const s = pts[p.dataIndex]; if (s && s.sub_id) location.href = (window.U ? U('/submissions/') : '/submissions/') + s.sub_id; });
    table(opts && opts.table, ['เวลา', 'ค่า' + unit, 'ผล', 'สัญญาณ', 'ผู้ตรวจ', 'หมายเหตุ'],
      pts.slice().reverse().map((p) => [fmtTs(p.t), num(p.v, 4), p.judgement === 'ng' ? 'NG' : (p.judgement === 'warn' ? 'เตือน' : 'ปกติ'),
        p.flags.map((f) => FLAG_TH[f] || f).join(', ') || '–', p.inspector || '', p.remark || '']));
  }


  // ── หัวข้อสำคัญบน Dashboard: ค่าเฉลี่ยรายวัน + เส้นเกณฑ์ (สลับหัวข้อด้วยแท็บ) ──
  let keyCur = null, keyEntry = null;
  function keyOpt(t, k) {
    const unit = k.unit ? ' ' + k.unit : '';
    const vals = k.avg.filter((v) => v != null).concat(k.min.filter((v) => v != null), k.max.filter((v) => v != null));
    const lines = [];
    const add = (y, color, type, label) => { if (y != null) lines.push({yAxis: y, lineStyle: {color, type, width: 1.5}, label: {formatter: label}}); };
    add(k.max_value, t.critical, 'dashed', 'สูงสุด ' + num(k.max_value));
    add(k.min_value, t.critical, 'dashed', 'ต่ำสุด ' + num(k.min_value));
    add(k.warn_high, t.warning, 'dotted', 'เตือน ' + num(k.warn_high));
    add(k.warn_low, t.warning, 'dotted', 'เตือน ' + num(k.warn_low));
    let shown = lines;
    if (vals.length) {
      const dmin = Math.min(...vals), dmax = Math.max(...vals);
      const reach = Math.max((dmax - dmin) * 1.5, Math.abs((dmin + dmax) / 2) * 0.08, 1e-9);
      shown = lines.filter((l) => l.yAxis >= dmin - reach && l.yAxis <= dmax + reach);
    }
    const ys = vals.concat(shown.map((l) => l.yAxis));
    const pad = ys.length ? ((Math.max(...ys) - Math.min(...ys)) * 0.12 || 1) : 1;
    return {
      ...base(t),
      grid: {left: 44, right: 78, top: 14, bottom: 26},
      tooltip: {...base(t).tooltip, trigger: 'axis', axisPointer: {type: 'line', lineStyle: {color: t.axis}},
        formatter: (ps) => {
          const i = ps[0].dataIndex;
          if (k.avg[i] == null) return '<b>' + fmtDay(k.days[i]) + '</b><br>ไม่มีการตรวจ';
          return '<b>' + fmtDay(k.days[i]) + '</b><br>เฉลี่ย <b>' + num(k.avg[i], 3) + unit + '</b><br>ต่ำสุด ' + num(k.min[i], 3) + ' · สูงสุด ' + num(k.max[i], 3);
        }},
      xAxis: {type: 'category', data: k.days.map(fmtDay), boundaryGap: false, ...axisCommon(t), splitLine: {show: false}},
      yAxis: {type: 'value', scale: true, ...axisCommon(t), axisLabel: {color: t.muted, fontSize: 11, showMinLabel: false, showMaxLabel: false},
        min: ys.length ? +(Math.min(...ys) - pad).toPrecision(4) : null, max: ys.length ? +(Math.max(...ys) + pad).toPrecision(4) : null},
      series: [
        {name: 'ช่วงต่ำสุด–สูงสุด', type: 'line', data: k.min, stack: 'band', symbol: 'none', lineStyle: {opacity: 0}, silent: true, connectNulls: true},
        {name: 'band', type: 'line', data: k.max.map((v, i) => v == null || k.min[i] == null ? null : +(v - k.min[i]).toPrecision(6)), stack: 'band',
          symbol: 'none', lineStyle: {opacity: 0}, areaStyle: {color: t.s[0], opacity: 0.1}, silent: true, connectNulls: true},
        {name: 'ค่าเฉลี่ย', type: 'line', data: k.avg, connectNulls: true, symbolSize: 8, lineStyle: {width: 2.5, color: t.s[0]},
          itemStyle: {color: t.s[0], borderColor: t.surface, borderWidth: 2},
          endLabel: {show: true, color: t.ink, fontWeight: 600, formatter: (p) => p.value == null ? '' : num(p.value, 3)},
          markLine: {silent: true, symbol: 'none', data: shown, label: {position: 'end', color: t.ink2, fontSize: 11}}},
      ],
    };
  }
  function keyItem(el, k) {
    keyCur = k;
    if (keyEntry) { keyEntry.render(); return keyEntry.chart; }
    const chart = mount(el, (t) => keyOpt(t, keyCur));
    keyEntry = charts[charts.length - 1];
    return chart;
  }

  // ── รอบที่กำหนด เทียบ ตรวจแล้ว 7 วัน (แท่งคู่ แกนเดียว) ──
  function week(el, w, opts) {
    if (!el) return;
    const chart = mount(el, (t) => ({
      ...base(t),
      grid: {left: 36, right: 8, top: 18, bottom: 24},
      tooltip: {...base(t).tooltip, trigger: 'axis', axisPointer: {type: 'shadow', shadowStyle: {color: 'rgba(127,127,127,.08)'}},
        formatter: (ps) => {
          const i = ps[0].dataIndex, due = w.due[i], done = w.done[i];
          return '<b>' + fmtDay(w.days[i]) + '</b><br>รอบที่กำหนด <b>' + due + '</b><br>ตรวจแล้ว <b>' + done + '</b>' +
            (due ? ' (' + Math.round(100 * done / due) + '%)' : '') + '<br>ขาดตรวจ ' + w.missed[i] + ' · NG ' + w.ng[i] + ' หัวข้อ';
        }},
      xAxis: {type: 'category', data: w.days.map(fmtDay), ...axisCommon(t), splitLine: {show: false}},
      yAxis: {type: 'value', minInterval: 1, ...axisCommon(t)},
      series: [
        {name: 'รอบที่กำหนด', type: 'bar', data: w.due, barMaxWidth: 22, barGap: '15%', itemStyle: {color: t.s[0], borderRadius: [4, 4, 0, 0]}},
        {name: 'ตรวจแล้ว', type: 'bar', data: w.done, barMaxWidth: 22, itemStyle: {color: t.s[2], borderRadius: [4, 4, 0, 0]},
          label: {show: true, position: 'top', fontSize: 11, color: t.ink2,
            formatter: (p) => w.due[p.dataIndex] ? Math.round(100 * p.value / w.due[p.dataIndex]) + '%' : ''}},
      ],
    }));
    if (chart && opts && opts.link) {               // v0.98 คลิกวันไหน (แท่งหรือพื้นที่ของวันนั้น) → เปิดรอบตรวจของวันนั้น
      el.style.cursor = 'pointer';
      chart.getZr().on('click', (ev) => {
        const pt = [ev.offsetX, ev.offsetY];
        if (!chart.containPixel('grid', pt)) return;
        const i = Math.round(chart.convertFromPixel({seriesIndex: 0}, pt)[0]);
        if (i >= 0 && i < w.days.length) location.href = opts.link(w.days[i]);
      });
    }
    table(opts && opts.table, ['วันที่', 'รอบที่กำหนด', 'ตรวจแล้ว', 'ตรงเวลา', 'ขาดตรวจ', 'NG'],
      w.days.map((d, i) => [fmtDay(d), w.due[i], w.done[i], w.on_time[i], w.missed[i], w.ng[i]]),
      opts && opts.link ? (row, i) => opts.link(w.days[i]) : null);
  }

  // ── v0.33 จำนวนการตรวจรายวันของเครื่อง (แท่งซ้อน: ปกติ / พบ NG · แกนเดียว) ──
  function daily(el, d, opts) {
    if (!el) return;
    const okv = d.subs.map((n, i) => n - d.ng[i]);
    const many = d.days.length > 45;
    const chart = mount(el, (t) => ({
      ...base(t),
      grid: {left: 34, right: 8, top: 14, bottom: many ? 48 : 24},
      tooltip: {...base(t).tooltip, trigger: 'axis', axisPointer: {type: 'shadow', shadowStyle: {color: 'rgba(127,127,127,.08)'}},
        formatter: (ps) => { const i = ps[0].dataIndex;
          return '<b>' + fmtDay(d.days[i]) + '</b><br>ตรวจ <b>' + d.subs[i] + '</b> ครั้ง' + (d.ng[i] ? '<br><span style="color:' + t.critical + '">พบ NG ' + d.ng[i] + ' ครั้ง</span>' : ''); }},
      xAxis: {type: 'category', data: d.days.map(fmtDay), ...axisCommon(t), splitLine: {show: false}},
      yAxis: {type: 'value', minInterval: 1, ...axisCommon(t)},
      dataZoom: many ? [{type: 'inside'}, {type: 'slider', height: 16, bottom: 6, borderColor: t.axis, textStyle: {color: t.muted}}] : [],
      series: [
        {name: 'ปกติ', type: 'bar', stack: 'n', data: okv, barMaxWidth: 26, itemStyle: {color: t.s[0]}},
        {name: 'พบ NG', type: 'bar', stack: 'n', data: d.ng, barMaxWidth: 26, itemStyle: {color: t.critical, borderRadius: [4, 4, 0, 0]}},
      ],
    }));
    // v0.99.18 กดแท่งของวันใดก็ได้ = ดูเฉพาะวันนั้น (opts.onDay)
    if (chart && opts && opts.onDay && d.days.length > 1) {               // ทั้งคอลัมน์ของวัน (รวมวันที่ไม่มีผลตรวจ)
      chart.getZr().on('click', (e) => {
        const pt = [e.offsetX, e.offsetY]; if (!chart.containPixel('grid', pt)) return;
        const i = Math.round(chart.convertFromPixel({seriesIndex: 0}, pt)[0]);
        if (d.days[i]) opts.onDay(d.days[i]);
      });
      chart.getZr().on('mousemove', (e) => { chart.getZr().setCursorStyle(chart.containPixel('grid', [e.offsetX, e.offsetY]) ? 'pointer' : 'default'); });
    }
    table(opts && opts.table, ['วันที่', 'ตรวจ (ครั้ง)', 'พบ NG (ครั้ง)'], d.days.map((x, i) => [fmtDay(x), d.subs[i], d.ng[i]]).reverse(),
      opts && opts.onDay && d.days.length > 1 ? (r, i) => opts.dayHref(d.days[d.days.length - 1 - i]) : null);
  }

  // ── จำนวนผลตรวจรายชั่วโมง (กราฟพื้นที่เล็ก SVG) ──
  function hourly(el, h) {
    if (!el) return;
    const w = 300, ht = 64, mx = Math.max(1, ...h);
    const pts = h.map((v, i) => [i * w / 23, ht - 4 - (v / mx) * (ht - 12)]);
    let d = 'M' + pts[0][0] + ' ' + pts[0][1];
    for (let i = 1; i < pts.length; i++) {
      const [x0, y0] = pts[i - 1], [x1, y1] = pts[i], cx = (x0 + x1) / 2;
      d += ' C' + cx.toFixed(1) + ' ' + y0.toFixed(1) + ' ' + cx.toFixed(1) + ' ' + y1.toFixed(1) + ' ' + x1.toFixed(1) + ' ' + y1.toFixed(1);
    }
    const peak = h.indexOf(mx);
    el.innerHTML = '<svg viewBox="0 0 ' + w + ' ' + ht + '" preserveAspectRatio="none" role="img" aria-label="ผลตรวจรายชั่วโมง">' +
      '<defs><linearGradient id="hg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--viz-s1)" stop-opacity=".45"/>' +
      '<stop offset="1" stop-color="var(--viz-s1)" stop-opacity=".04"/></linearGradient></defs>' +
      '<path d="' + d + ' L' + w + ' ' + ht + ' L0 ' + ht + 'Z" fill="url(#hg)"/>' +
      '<path d="' + d + '" fill="none" stroke="var(--viz-s1)" stroke-width="2" vector-effect="non-scaling-stroke"/></svg>' +
      (h.some((v) => v) ? '<div class="hourly-peak small">มากสุด ' + mx + ' ครั้ง ช่วง ' + String(peak).padStart(2, '0') + ':00</div>' : '<div class="hourly-peak small muted">ยังไม่มีผลตรวจ</div>');
  }

  // ── Sparkline (SVG ล้วน ไม่ต้องใช้ ECharts) ──
  function spark(el, values, lo, hi) {
    if (!el || !values || !values.length) return;
    const w = 120, h = 32, pad = 3;
    const all = values.concat([lo, hi].filter((v) => v != null));
    const mn = Math.min(...all), mx = Math.max(...all), span = (mx - mn) || 1;
    const x = (i) => values.length === 1 ? w / 2 : pad + i * (w - 2 * pad) / (values.length - 1);
    const y = (v) => h - pad - (v - mn) / span * (h - 2 * pad);
    const band = (lo != null && hi != null) ? '<rect x="0" width="' + w + '" y="' + y(hi) + '" height="' + Math.max(1, y(lo) - y(hi)) + '" fill="var(--ok-bg)"/>' : '';
    const d = values.map((v, i) => (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(v).toFixed(1)).join(' ');
    const last = values[values.length - 1];
    const bad = (lo != null && last < lo) || (hi != null && last > hi);
    el.innerHTML = '<svg class="spark" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="แนวโน้ม">' + band +
      '<path d="' + d + '" fill="none" stroke="var(--viz-s1)" stroke-width="1.6"/>' +
      '<circle cx="' + x(values.length - 1) + '" cy="' + y(last) + '" r="3" fill="' + (bad ? 'var(--st-critical)' : 'var(--viz-s1)') + '"/></svg>';
  }

  // ── หมุดบนผัง: ชิดขอบเมื่ออยู่ริม + ยกป้ายขึ้นเมื่อชนกัน ──
  function layoutPins(root) {
    (root || document).querySelectorAll('.pm-canvas').forEach((cv) => {
      if (!cv.offsetWidth) return;
      const box = cv.getBoundingClientRect();
      const pins = [...cv.querySelectorAll('.pin')];
      pins.forEach((p) => {
        const x = parseFloat(p.style.left);
        p.classList.toggle('edge-r', x > 82); p.classList.toggle('edge-l', x < 18);
      });
      const placed = [];
      const fits = (r) => r.top >= box.top + 2 && r.bottom <= box.bottom - 2 &&
        !placed.some((q) => !(r.right < q.left - 4 || r.left > q.right + 4 || r.bottom < q.top - 3 || r.top > q.bottom + 3));
      pins.sort((a, b) => parseFloat(a.style.top) - parseFloat(b.style.top)).forEach((p) => {
        const stem = p.querySelector('.pin-stem'), label = p.querySelector('.pin-label');
        // ลองตำแหน่ง: เหนือจุด / ใต้จุด แล้วค่อยยืดก้าน
        const tries = [[false, 14], [true, 14], [false, 44], [true, 44], [false, 74], [true, 74]];
        let ok = false;
        for (const [below, h] of tries) {
          p.classList.toggle('below', below); stem.style.height = h + 'px';
          if (fits(label.getBoundingClientRect())) { ok = true; break; }
        }
        if (!ok) { p.classList.remove('below'); stem.style.height = '14px'; }
        placed.push(label.getBoundingClientRect());
      });
    });
  }
  window.addEventListener('load', () => layoutPins());
  window.addEventListener('resize', () => layoutPins());

  // ── ปุ่ม "ดูเป็นตาราง" ──
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-table-toggle]');
    if (!b) return;
    const host = document.getElementById(b.getAttribute('data-table-toggle'));
    if (!host) return;
    const open = host.hidden;
    host.hidden = !open;
    b.textContent = open ? 'ซ่อนตาราง' : 'ดูเป็นตาราง';
    b.setAttribute('aria-expanded', String(open));
  });

  // เปลี่ยนธีมของเครื่อง → วาดใหม่ด้วยสีของโหมดนั้น
  if (window.matchMedia) {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const re = () => charts.forEach((c) => c.render());
    if (mq.addEventListener) mq.addEventListener('change', re); else if (mq.addListener) mq.addListener(re);
  }

  window.ECSCharts = {layoutPins, compliance, heatmap, pareto, trend, spark, keyItem, week, hourly, daily, rerender: () => charts.forEach((c) => c.render())};
})();
