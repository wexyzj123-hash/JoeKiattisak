/* v0.99.4 สถานะรายพื้นที่ (หน้าภาพรวม): แถวโรงงาน (กดขยาย) › แถวพื้นที่ › แผงเจาะลึก พื้นที่ › เครื่อง › สรุปเครื่อง
   สร้างองค์ประกอบด้วย textContent เท่านั้น (ไม่ใช้ innerHTML กับข้อมูล) · จำโรงงานที่ขยาย/ตัวกรองไว้ในเครื่อง */
(function () {
  'use strict';
  const card = document.getElementById('areas');
  if (!card) return;
  const $ = (s, r) => (r || card).querySelector(s);
  const $$ = (s, r) => Array.prototype.slice.call((r || card).querySelectorAll(s));
  const panel = $('[data-panel]'), F = (k) => panel.querySelector('[data-f="' + k + '"]');
  const tiles = $$('.ab-tile'), groups = $$('.ab-fac'), body = $('.ab-body');
  const GL = { critical: '✕', warning: '!', good: '✓', none: '–', pending: '◷', down: '‖' };
  const small = () => window.matchMedia('(max-width: 900px)').matches;
  const store = (k, v) => { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { /* */ } return null; };
  let flt = store('ecs_ab_flt') || 'all', more = false, cur = null, mcache = {};
  if (!$('.ab-chip[data-flt="' + flt + '"]')) flt = 'all';
  let opened = (store('ecs_ab_open') || '').split(',').filter(Boolean);
  if (groups.length === 1) opened = [groups[0].dataset.facgrp];          // โรงงานเดียว: ขยายไว้เลย

  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  const label = (m) => (m.name && m.name.indexOf(m.code) >= 0) ? m.name : m.code + ' · ' + m.name;
  function fmt(t) { if (!t) return '–'; const m = /^(\d{4})-(\d\d)-(\d\d)[ T](\d\d):(\d\d)/.exec(t); return m ? (+m[3]) + '/' + m[2] + ' ' + m[4] + ':' + m[5] : t; }

  const isOpen = (g) => opened.indexOf(g.dataset.facgrp) >= 0;
  function setOpen(g, on) {
    const id = g.dataset.facgrp; opened = opened.filter((x) => x !== id); if (on) opened.push(id);
    store('ecs_ab_open', opened.join(','));
  }

  function apply() {
    const c = { all: tiles.length, critical: 0, warning: 0, good: 0, none: 0 };
    tiles.forEach((t) => { c[t.dataset.st]++; });
    $$('[data-n]').forEach((b) => { b.textContent = c[b.dataset.n]; });
    let any = false;
    groups.forEach((g) => {
      const gt = $$('.ab-tile', g); let n = 0, none = 0;
      gt.forEach((t) => {
        const st = t.dataset.st; if (st === 'none') none++;
        t.hidden = !(flt === 'all' ? (st !== 'none' || more || gt.every((x) => x.dataset.st === 'none')) : st === flt);
        if (!t.hidden) n++;
      });
      g.hidden = flt !== 'all' && !n; any = any || !g.hidden;
      const open = !g.hidden && (isOpen(g) || (flt !== 'all' && n > 0) || (cur && g.contains(cur)));
      $('.ab-fh', g).setAttribute('aria-expanded', String(open)); $('.ab-fl', g).hidden = !open;
      const mb = $('[data-more]', g), shown = gt.filter((t) => !t.hidden).length;
      if (mb) { mb.hidden = !(flt === 'all' && !more && none && shown < gt.length); const mn = $('[data-moren]', mb); if (mn) mn.textContent = none; }
    });
    const em = $('.ab-empty'); if (em) em.hidden = any || !tiles.length;
    $$('.ab-chip').forEach((b) => { const on = b.dataset.flt === flt; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
  }

  function setIco(box, t) {
    box.textContent = ''; box.dataset.st = t.dataset.st;
    const img = t.querySelector('.ab-ico img');
    if (img) { const i = document.createElement('img'); i.src = img.src; i.alt = ''; box.appendChild(i); } else box.textContent = GL[t.dataset.st] || '–';
  }

  function showArea(t, focusPanel) {
    cur = t;
    tiles.forEach((x) => x.classList.toggle('sel', x === t));
    body.classList.add('has-sel'); apply();
    panel.querySelector('[data-view="area"]').hidden = false; panel.querySelector('[data-view="mach"]').hidden = true;
    $('[data-back]', panel).hidden = true; F('machc').hidden = true;
    F('fac').textContent = t.dataset.facname; F('area').textContent = t.dataset.name;
    setIco(F('aico'), t);
    F('aname').textContent = t.dataset.name; F('areason').textContent = t.dataset.sth + ' · ' + t.dataset.reason;
    const r = +t.dataset.rounds;
    F('kdone').textContent = r ? t.dataset.done + '/' + r : '–';
    const late = +t.dataset.late, al = +t.dataset.alerts;
    F('klate').textContent = late; F('klate').className = late ? 'warm' : '';
    F('kal').textContent = al; F('kal').className = al ? 'hot' : '';
    F('kdown').textContent = t.dataset.down || 0;
    F('meq').textContent = '(' + t.dataset.eq + ')';
    F('amap').href = t.getAttribute('href'); F('aeq').href = t.dataset.equrl;
    const form = F('iconform');
    if (form) {
      form.action = card.dataset.iconurl.replace('/0/', '/' + t.dataset.area + '/');
      F('inext').value = location.pathname + location.search + '#area-' + t.dataset.area;
      F('iremove').hidden = t.dataset.hasicon !== '1';
    }
    if (small() && focusPanel) { panel.classList.add('open'); document.documentElement.classList.add('ab-lock'); panel.focus(); }
    loadMachines(t);
  }

  function loadMachines(t) {
    const id = t.dataset.area, list = F('mlist'), state = F('mstate');
    list.textContent = ''; state.textContent = 'กำลังโหลดรายการเครื่อง…';
    const render = (d) => {
      if (cur !== t) return;
      list.textContent = '';
      F('arounds').href = d.area.rounds;
      if (!d.machines.length) { state.textContent = 'ยังไม่มีเครื่องจักรในพื้นที่นี้'; return; }
      state.textContent = '';
      d.machines.forEach((m, i) => {
        const li = el('li'), b = el('button', 'ab-mrow'); b.type = 'button'; b.dataset.st = m.status;
        b.appendChild(el('span', 'ab-msym', GL[m.status] || '–')).setAttribute('aria-hidden', 'true');
        const tx = el('span', 'ab-mtx'); tx.appendChild(el('b', null, label(m)));
        tx.appendChild(el('small', null, m.status_th + (m.reason ? ' · ' + m.reason : (m.last_at ? ' · ตรวจล่าสุด ' + fmt(m.last_at) : ''))));
        b.appendChild(tx);
        b.addEventListener('click', () => showMachine(d, i));
        li.appendChild(b); list.appendChild(li);
      });
    };
    if (mcache[id]) { render(mcache[id]); return; }
    const url = card.dataset.api.replace('/0/', '/' + id + '/') + '?date=' + encodeURIComponent(card.dataset.day);
    fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then((r) => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then((d) => { mcache[id] = d; render(d); })
      .catch(() => { if (cur === t) state.textContent = 'โหลดรายการเครื่องไม่สำเร็จ — กด “เปิดหน้าพื้นที่” เพื่อดูแทน'; });
  }

  function primaryOf(m) {
    const L = m.links;
    if (m.status === 'down') return ['ดูข้อมูลเครื่อง / แจ้งซ่อม', L.detail];
    if ((m.status === 'warning' || m.status === 'critical') && m.ng && L.latest) return ['เปิดผลตรวจล่าสุด', L.latest];
    if (m.status === 'warning' || m.status === 'critical' || m.status === 'pending') return ['ไปติดตามรอบตรวจ', L.rounds];
    if (m.status === 'good') return L.latest ? ['เปิดผลตรวจล่าสุด', L.latest] : ['ประวัติเครื่อง 360°', L.m360];
    return L.form ? ['ตั้งรอบตรวจของแบบฟอร์ม', L.form] : ['ดูข้อมูลเครื่อง', L.detail];
  }

  function showMachine(d, i) {
    const m = d.machines[i];
    panel.querySelector('[data-view="area"]').hidden = true; panel.querySelector('[data-view="mach"]').hidden = false;
    $('[data-back]', panel).hidden = false; F('machc').hidden = false; F('mach').textContent = m.code;
    const ico = F('mico'); ico.dataset.st = m.status; ico.textContent = GL[m.status] || '–';
    F('mname').textContent = label(m); F('msub').textContent = m.status_th + (m.eq_type ? ' · ' + m.eq_type : '');
    const dl = F('mfacts'); dl.textContent = '';
    const fact = (k, v) => { const w = el('div'); w.appendChild(el('dt', null, k)); w.appendChild(el('dd', null, v)); dl.appendChild(w); };
    fact('ตรวจวันนี้', m.rounds ? m.done + '/' + m.rounds + ' รอบ' : 'ไม่มีรอบ');
    fact('ตรวจล่าสุด', m.last_at ? fmt(m.last_at) + (m.last_by ? ' · ' + m.last_by : '') : '–');
    fact('ครบกำหนดถัดไป', m.status === 'down' ? 'ข้าม (เครื่องหยุด)' : fmt(m.next_deadline));
    fact('แบบฟอร์ม', m.forms.length ? m.forms.map((f) => f.code || f.name).join(', ') : 'ยังไม่มี');
    const w = F('mwarn'); w.hidden = !m.reason; w.textContent = m.reason || ''; w.dataset.st = m.status;
    const [pt, ph] = primaryOf(m); const p = F('mprimary'); p.textContent = pt; p.href = ph;
    const sec = F('msec'); sec.textContent = '';
    const add = (t, h) => { if (!h || h === ph) return; const a = el('a', 'btn', t); a.href = h; sec.appendChild(a); };
    add('ประวัติเครื่อง 360°', m.links.m360); add('แนวโน้มค่าที่ตรวจ', m.links.trends); add('ข้อมูลเครื่อง', m.links.detail);
    panel.scrollTop = 0;
    $('[data-back]', panel).focus();   // แถวที่กดถูกซ่อน → ย้ายโฟกัสมาที่ปุ่มย้อนกลับ (Esc/Tab ยังทำงานต่อได้)
  }

  function closePanel() {
    panel.classList.remove('open'); document.documentElement.classList.remove('ab-lock'); body.classList.remove('has-sel');
    const t = cur; cur = null; tiles.forEach((x) => x.classList.remove('sel'));
    try { if (/^#area-/.test(location.hash)) history.replaceState(null, '', location.pathname + location.search); } catch (err) { /* */ }
    if (t) t.focus();
  }

  // ── เหตุการณ์ ──
  card.addEventListener('click', (e) => {
    const chip = e.target.closest('.ab-chip');
    if (chip) { flt = chip.dataset.flt; more = more || flt === 'none'; store('ecs_ab_flt', flt); if (cur && !matches(cur)) closePanel(); apply(); return; }
    const fh = e.target.closest('.ab-fh');
    if (fh) { const g = fh.closest('.ab-fac'), open = fh.getAttribute('aria-expanded') !== 'true'; setOpen(g, open);
      if (!open && cur && g.contains(cur)) closePanel();
      if (!open && flt !== 'all') { fh.setAttribute('aria-expanded', 'false'); $('.ab-fl', g).hidden = true; } else apply();
      return; }
    if (e.target.closest('[data-more]')) { more = true; apply(); return; }
    if (e.target.closest('[data-back]')) { if (cur) showArea(cur, false); return; }
    if (e.target.closest('[data-close]')) { closePanel(); return; }
    const t = e.target.closest('.ab-tile');
    if (!t || e.metaKey || e.ctrlKey || e.shiftKey || e.button) return;     // Ctrl/⌘/Shift+คลิก = เปิดหน้าพื้นที่ตามลิงก์
    e.preventDefault(); showArea(t, true);
    try { history.replaceState(null, '', location.pathname + location.search + '#area-' + t.dataset.area); } catch (err) { /* */ }   // รีเฟรชแล้วกลับมาที่พื้นที่เดิม
  });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || e.defaultPrevented) return;
    const a = document.activeElement;
    if (a && a !== document.body && !card.contains(a)) return;            // โฟกัสอยู่ที่อื่น (ช่องค้นหา/เมนู) ไม่ยุ่ง
    if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) return;
    if (!cur) return;
    if (!panel.querySelector('[data-view="mach"]').hidden) showArea(cur, false); else closePanel();
  });
  const ifile = F('ifile');
  if (ifile) ifile.addEventListener('change', () => { if (ifile.files && ifile.files.length) F('iconform').submit(); });

  function matches(t) { return flt === 'all' || t.dataset.st === flt; }

  apply();
  const h = /^#area-(\d+)$/.exec(location.hash), ht = h && document.getElementById('area-' + h[1]);
  if (ht && ht.classList.contains('ab-tile')) {
    if (!matches(ht)) flt = 'all';
    if (ht.dataset.st === 'none') more = true;
    showArea(ht, false); ht.scrollIntoView({ block: 'center' });
  }
})();
