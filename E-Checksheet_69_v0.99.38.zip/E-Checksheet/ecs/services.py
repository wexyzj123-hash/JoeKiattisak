"""ecs/services.py — กฎธุรกิจ: หัวข้อตรวจ, แบบฟอร์ม, เวอร์ชัน, รอบตรวจ (ไม่ขึ้นกับ Flask)

แยกจากหน้าเว็บเพื่อให้ทดสอบได้ และนำไปใช้ซ้ำใน Scheduler / API / สคริปต์ย้ายข้อมูล
ทุกฟังก์ชันรับ `db` (sqlite3.Connection ที่ตั้ง row_factory=sqlite3.Row)
"""
from __future__ import annotations

import json
import re
import uuid
from datetime import date, datetime, time, timedelta
from typing import Any, Iterable

from .schema import FREQ_TYPES, ITEM_TYPES

TS_FMT = "%Y-%m-%d %H:%M:%S"


class ValidationError(ValueError):
    """ข้อมูลไม่ผ่านเงื่อนไข — message เป็นภาษาไทยพร้อมแสดงผู้ใช้"""

    def __init__(self, errors: list[str] | str):
        self.errors = [errors] if isinstance(errors, str) else list(errors)
        super().__init__("; ".join(self.errors))


# ───────────────────────── utilities ─────────────────────────

def now_dt() -> datetime:
    return datetime.now().replace(microsecond=0)


def ts(dt: datetime | None = None) -> str:
    return (dt or now_dt()).strftime(TS_FMT)


def parse_ts(value: str | None) -> datetime | None:
    if not value:
        return None
    value = str(value).strip().replace("T", " ")
    for fmt in (TS_FMT, "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(value[:19] if fmt == TS_FMT else value, fmt)
        except ValueError:
            continue
    return None


def new_item_key() -> str:
    return "k" + uuid.uuid4().hex[:12]


def _num(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(",", "")
    if text == "":
        return None
    try:
        return float(text)
    except ValueError:
        return None


def audit(db, actor_id: int | None, action: str, entity: str, entity_id: int | None,
          before: Any = None, after: Any = None) -> None:
    db.execute(
        "INSERT INTO cs_audit(actor_id, action, entity, entity_id, before_json, after_json, created_at)"
        " VALUES (?,?,?,?,?,?,?)",
        (actor_id, action, entity, entity_id,
         json.dumps(before, ensure_ascii=False, default=str) if before is not None else "",
         json.dumps(after, ensure_ascii=False, default=str) if after is not None else "",
         ts()))


def row_dict(row) -> dict | None:
    return dict(row) if row is not None else None


# ───────────────────────── items: validation & judgement ─────────────────────────

ITEM_FIELDS = ("section", "name", "item_type", "unit", "min_value", "max_value",
               "warn_low", "warn_high", "counter_max_step", "options_json",
               "required", "critical", "photo_on_ng", "guide", "check_freq", "check_times", "photo_required", "formula")


def normalize_item(raw: dict, index: int = 0) -> dict:
    """ตรวจและจัดรูปแบบหัวข้อตรวจ 1 หัวข้อ — คืน dict พร้อมบันทึก หรือ raise ValidationError"""
    label = f"หัวข้อที่ {index + 1}"
    errors: list[str] = []
    name = str(raw.get("name") or "").strip()
    if not name:
        errors.append(f"{label}: กรุณาระบุชื่อหัวข้อ")
    item_type = str(raw.get("item_type") or "ok_ng").strip()
    if item_type not in ITEM_TYPES:
        errors.append(f"{label}: ประเภท '{item_type}' ไม่รองรับ")

    item = {
        "item_key": str(raw.get("item_key") or "").strip() or new_item_key(),
        "section": str(raw.get("section") or "").strip()[:120],
        "name": name[:200],
        "item_type": item_type,
        "unit": str(raw.get("unit") or "").strip()[:30],
        "min_value": _num(raw.get("min_value")),
        "max_value": _num(raw.get("max_value")),
        "warn_low": _num(raw.get("warn_low")),
        "warn_high": _num(raw.get("warn_high")),
        "counter_max_step": _num(raw.get("counter_max_step")),
        "options_json": "",
        "required": 1 if raw.get("required", 1) in (1, True, "1", "true", "on") else 0,
        "critical": 1 if raw.get("critical", 0) in (1, True, "1", "true", "on") else 0,
        "photo_on_ng": 1 if raw.get("photo_on_ng", 1) in (1, True, "1", "true", "on") else 0,
        "photo_required": 1 if raw.get("photo_required", 0) in (1, True, "1", "true", "on") else 0,
        "guide": str(raw.get("guide") or "").strip()[:500],
        "legacy_item_id": raw.get("legacy_item_id"),
        "formula": str(raw.get("formula") or "").strip()[:300] if item_type == "calc" else "",
    }
    if item_type == "calc":                             # v0.95 คำนวณจากหัวข้ออื่น — ช่างไม่ต้องกรอก
        item["required"] = 0
        item["photo_required"] = 0
        item["counter_max_step"] = None
        if not item["formula"]:
            errors.append(f"{label}: หัวข้อคำนวณต้องใส่สูตร เช่น {{ค่าเข้า}} - {{ค่าออก}}")
    for fld in ("min_value", "max_value", "warn_low", "warn_high", "counter_max_step"):
        given = raw.get(fld)
        if given not in (None, "") and item[fld] is None:
            errors.append(f"{label}: ค่า {fld} ต้องเป็นตัวเลข")

    if item_type in ("number", "counter", "calc"):
        mn, mx, wl, wh = item["min_value"], item["max_value"], item["warn_low"], item["warn_high"]
        if mn is not None and mx is not None and mn > mx:
            errors.append(f"{label}: Min ต้องไม่มากกว่า Max")
        if wl is not None and wh is not None and wl > wh:
            errors.append(f"{label}: ค่าเตือนต่ำต้องไม่มากกว่าค่าเตือนสูง")
        if wl is not None and mn is not None and wl < mn:
            errors.append(f"{label}: ค่าเตือนต่ำต้องอยู่ในช่วง Min–Max")
        if wh is not None and mx is not None and wh > mx:
            errors.append(f"{label}: ค่าเตือนสูงต้องอยู่ในช่วง Min–Max")
        if item["counter_max_step"] is not None and item["counter_max_step"] <= 0:
            errors.append(f"{label}: ค่าเพิ่มสูงสุดต่อรอบต้องมากกว่า 0")
    else:
        for fld in ("min_value", "max_value", "warn_low", "warn_high", "counter_max_step"):
            item[fld] = None
        item["unit"] = "" if item_type in ("ok_ng", "choice") else item["unit"]

    if item_type == "choice":
        opts = raw.get("options")
        if opts is None and raw.get("options_json"):
            try:
                opts = json.loads(raw["options_json"])
            except (TypeError, ValueError):
                opts = None
        clean = []
        for opt in opts or []:
            if isinstance(opt, str):
                opt = {"label": opt, "ng": 0}
            lbl = str(opt.get("label") or "").strip()
            if lbl:
                clean.append({"label": lbl[:80], "ng": 1 if opt.get("ng") in (1, True, "1") else 0})
        if len(clean) < 2:
            errors.append(f"{label}: ตัวเลือกต้องมีอย่างน้อย 2 ตัวเลือก")
        if len({o["label"] for o in clean}) != len(clean):
            errors.append(f"{label}: ตัวเลือกซ้ำกัน")
        item["options_json"] = json.dumps(clean, ensure_ascii=False)

    if item_type == "text":
        item["photo_on_ng"] = 0
        item["critical"] = 0

    from .itemfreq import FreqError
    from .itemfreq import normalize as _norm_freq
    try:
        item["check_freq"], item["check_times"] = _norm_freq(raw.get("check_freq"), raw.get("check_times"))
    except FreqError as exc:
        errors.append(f"{label}: {exc}")
        item["check_freq"], item["check_times"] = "", ""

    if errors:
        raise ValidationError(errors)
    return item


def evaluate(item: dict, raw_value: Any, prev_value: float | None = None) -> dict:
    """ตัดสินผลหัวข้อตรวจ 1 ข้อ

    คืน {judgement: ok|warn|ng|na, value_num, value_text, message}
    - ค่าว่าง = na (การบังคับกรอกตรวจแยกที่ check_completeness)
    """
    t = item["item_type"]
    text = "" if raw_value is None else str(raw_value).strip()
    out = {"judgement": "ok", "value_num": None, "value_text": text, "message": ""}
    if text == "":
        out["judgement"] = "na"
        return out

    if t == "ok_ng":
        v = text.lower()
        if v in ("ok", "o", "pass", "ผ่าน", "1", "true"):
            out["value_text"] = "OK"
        elif v in ("ng", "x", "fail", "ไม่ผ่าน", "0", "false"):
            out.update(value_text="NG", judgement="ng", message="ผลตรวจ NG")
        else:
            raise ValidationError(f"{item['name']}: ค่า '{text}' ต้องเป็น OK หรือ NG")
        return out

    if t in ("number", "counter", "calc"):
        v = _num(text)
        if v is None:
            raise ValidationError(f"{item['name']}: ต้องเป็นตัวเลข (ได้รับ '{text}')")
        out["value_num"] = v
        out["value_text"] = ("%g" % v)
        mn, mx = item.get("min_value"), item.get("max_value")
        wl, wh = item.get("warn_low"), item.get("warn_high")
        unit = item.get("unit") or ""
        if mn is not None and v < mn:
            out.update(judgement="ng", message=f"ต่ำกว่าเกณฑ์ {mn:g} {unit}".strip())
        elif mx is not None and v > mx:
            out.update(judgement="ng", message=f"สูงกว่าเกณฑ์ {mx:g} {unit}".strip())
        elif wl is not None and v < wl:
            out.update(judgement="warn", message=f"ใกล้ขีดต่ำ (เตือนที่ {wl:g})")
        elif wh is not None and v > wh:
            out.update(judgement="warn", message=f"ใกล้ขีดสูง (เตือนที่ {wh:g})")
        if t == "counter" and prev_value is not None and out["judgement"] != "ng":
            if v < prev_value:
                out.update(judgement="ng",
                           message=f"ค่าลดลงจากครั้งก่อน ({prev_value:g} → {v:g}) ตรวจสอบมิเตอร์")
            else:
                step = item.get("counter_max_step")
                if step is not None and (v - prev_value) > step:
                    out.update(judgement="warn",
                               message=f"เพิ่มขึ้น {v - prev_value:g} มากกว่าปกติ (สูงสุด {step:g})")
        return out

    if t == "choice":
        try:
            opts = json.loads(item.get("options_json") or "[]")
        except ValueError:
            opts = []
        match = next((o for o in opts if o["label"] == text), None)
        if match is None:
            raise ValidationError(f"{item['name']}: ตัวเลือก '{text}' ไม่มีในรายการ")
        if match.get("ng"):
            out.update(judgement="ng", message=f"เลือก '{text}' (NG)")
        return out

    return out  # text


# ───────────────────────── forms & versions ─────────────────────────

CATEGORY_SUGGEST = ("Utility", "Safety", "Environment")


def clean_category(v) -> str:
    return " ".join(str(v or "").split())[:40]


def form_category(f: dict) -> str:
    """หมวดหมู่ที่ใช้แสดง/กรอง: ที่ตั้งไว้ในแบบฟอร์ม → ประเภทเครื่องจักร → 'ทั่วไป'"""
    c = (f.get("category") or "").strip()
    if c:
        return c
    t = " ".join((f.get("eq_type") or "").split())
    return (t.title() if t.isascii() else t) or "ทั่วไป"      # 'Air compressor' / 'Air Compressor' → กลุ่มเดียวกัน


def list_categories(db) -> list[str]:
    """หมวดหมู่ที่ใช้อยู่ + ค่าแนะนำ (สำหรับช่องเลือกหมวดหมู่)"""
    used = {form_category(dict(r)) for r in db.execute(
        "SELECT f.category, e.eq_type FROM cs_forms f LEFT JOIN equipment e ON e.id=f.equipment_id WHERE f.active=1")}
    return sorted(used | set(CATEGORY_SUGGEST), key=str.lower)


def set_category(db, form_ids: list[int], category: str, actor_id) -> int:
    cat = clean_category(category)
    n = 0
    for fid in form_ids:
        n += db.execute("UPDATE cs_forms SET category=?, updated_at=? WHERE id=?", (cat, ts(), fid)).rowcount
        audit(db, actor_id, "update", "cs_forms", fid, after={"category": cat})
    return n


def list_forms(db, factory_id: int | None = None, q: str = "", include_inactive: bool = False,
               equipment_id: int | None = None) -> list[dict]:
    where, params = ["1=1"], []
    if not include_inactive:
        where.append("f.active=1")
    if factory_id:
        where.append("f.factory_id=?")
        params.append(factory_id)
    if equipment_id:
        where.append("f.equipment_id=?")
        params.append(equipment_id)
    from .view_scope import sql as _vs_sql                  # v0.29 บัญชีที่ถูกจำกัดการดู
    vs, vp = _vs_sql("f.id")
    if vs:
        where.append(vs[5:])
        params += vp
    if q:
        where.append("(f.name LIKE ? OR f.code LIKE ? OR e.code LIKE ? OR e.name LIKE ? OR e.eq_type LIKE ? "
                     "OR ar.name LIKE ? OR f.description LIKE ?)")
        params += [f"%{q}%"] * 7
    rows = db.execute(f"""
        SELECT f.*, e.code AS eq_code, e.name AS eq_name, e.eq_type AS eq_type, fa.name AS factory_name,
               ar.name AS area_name, v.version_no AS current_version_no,
               (SELECT COUNT(*) FROM cs_submissions sc WHERE sc.form_id=f.id) AS sub_count,
               (SELECT COUNT(*) FROM cs_form_items i WHERE i.version_id=f.current_version_id) AS item_count,
               (SELECT COUNT(*) FROM cs_form_versions d WHERE d.form_id=f.id AND d.status='draft') AS has_draft,
               (SELECT COUNT(*) FROM cs_schedules s WHERE s.form_id=f.id AND s.active=1) AS schedule_count,
               (SELECT MAX(finished_at) FROM cs_submissions sb WHERE sb.form_id=f.id) AS last_submitted
        FROM cs_forms f
        LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN areas ar ON ar.id=f.area_id
        LEFT JOIN cs_form_versions v ON v.id=f.current_version_id
        WHERE {' AND '.join(where)}
        ORDER BY fa.sort_no, f.name
    """, params).fetchall()
    return [dict(r) for r in rows]


def get_form(db, form_id: int) -> dict | None:
    row = db.execute("""
        SELECT f.*, e.code AS eq_code, e.name AS eq_name, e.qr_token AS eq_qr_token, e.eq_type AS eq_type,
               fa.name AS factory_name, ar.name AS area_name
        FROM cs_forms f LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN areas ar ON ar.id=f.area_id
        WHERE f.id=?""", (form_id,)).fetchone()
    return row_dict(row)


def get_version(db, version_id: int) -> dict | None:
    return row_dict(db.execute("SELECT * FROM cs_form_versions WHERE id=?", (version_id,)).fetchone())


def get_items(db, version_id: int) -> list[dict]:
    rows = db.execute(
        "SELECT * FROM cs_form_items WHERE version_id=? ORDER BY order_no, id", (version_id,)
    ).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["options"] = json.loads(d["options_json"]) if d.get("options_json") else []
        out.append(d)
    return out


def list_versions(db, form_id: int) -> list[dict]:
    rows = db.execute("""
        SELECT v.*, u.name AS published_by_name, c.name AS created_by_name,
               (SELECT COUNT(*) FROM cs_form_items i WHERE i.version_id=v.id) AS item_count,
               (SELECT COUNT(*) FROM cs_submissions s WHERE s.form_version_id=v.id) AS submission_count
        FROM cs_form_versions v
        LEFT JOIN users u ON u.id=v.published_by
        LEFT JOIN users c ON c.id=v.created_by
        WHERE v.form_id=? ORDER BY v.version_no DESC""", (form_id,)).fetchall()
    return [dict(r) for r in rows]


def _next_form_code(db) -> str:
    row = db.execute(
        "SELECT code FROM cs_forms WHERE code LIKE 'CS-%' ORDER BY CAST(SUBSTR(code,4) AS INTEGER) DESC LIMIT 1"
    ).fetchone()
    n = 1
    if row:
        m = re.match(r"CS-(\d+)", row["code"])
        n = int(m.group(1)) + 1 if m else 1
    return f"CS-{n:04d}"


def _int_or_none(v) -> int | None:
    if v in (None, "", 0, "0"):
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        raise ValidationError(f"ค่า '{v}' ต้องเป็นตัวเลข")


def _resolve_location(db, equipment_id, factory_id, area_id, prev: dict | None = None
                      ) -> tuple[int | None, int | None, int | None, bool]:
    """ตรวจเครื่องจักร/โรงงาน/พื้นที่ของแบบฟอร์ม

    แบบฟอร์มที่ผูกเครื่องจักร ใช้ตำแหน่งเดียวกับเครื่องจักรเสมอ (แหล่งข้อมูลเดียว → ผังพื้นที่/สถานะ/แจ้งเตือนตรงกัน)
    คืน (equipment_id, factory_id, area_id, move_equipment) — move_equipment=True เมื่อผู้ใช้เลือกพื้นที่ให้เครื่อง
    (เครื่องยังไม่มีพื้นที่ หรือเปลี่ยนพื้นที่ของแบบฟอร์มเดิมที่ผูกเครื่องเดิม)
    """
    equipment_id, factory_id, area_id = _int_or_none(equipment_id), _int_or_none(factory_id), _int_or_none(area_id)
    move_equipment = False
    if equipment_id is not None:
        eq = db.execute("SELECT factory_id, area_id FROM equipment WHERE id=?", (equipment_id,)).fetchone()
        if not eq:
            raise ValidationError("ไม่พบเครื่องจักรที่เลือก")
        same_eq = prev is not None and prev.get("equipment_id") == equipment_id
        changed = same_eq and area_id is not None and area_id != prev.get("area_id")
        if area_id is not None and (eq["area_id"] is None or changed) and area_id != eq["area_id"]:
            move_equipment = True
            if eq["factory_id"] is not None and factory_id is None:
                factory_id = eq["factory_id"]
        else:
            factory_id = eq["factory_id"] if eq["factory_id"] is not None else factory_id
            area_id = eq["area_id"]
    if factory_id is not None and not db.execute("SELECT 1 FROM factories WHERE id=?", (factory_id,)).fetchone():
        raise ValidationError("ไม่พบโรงงานที่เลือก")
    if area_id is not None:
        ar = db.execute("SELECT factory_id FROM areas WHERE id=?", (area_id,)).fetchone()
        if not ar:
            raise ValidationError("ไม่พบพื้นที่ที่เลือก")
        if move_equipment:
            factory_id = ar["factory_id"]            # ย้ายเครื่องไปพื้นที่ใหม่ = ย้ายโรงงานตามพื้นที่
        elif factory_id is not None and ar["factory_id"] != factory_id:
            raise ValidationError("พื้นที่ไม่อยู่ในโรงงานที่เลือก")
        factory_id = factory_id or ar["factory_id"]
    return equipment_id, factory_id, area_id, move_equipment


def set_equipment_location(db, equipment_id: int, factory_id, area_id, actor_id=None) -> None:
    """ย้ายเครื่องจักรไปโรงงาน/พื้นที่ใหม่ แล้วให้แบบฟอร์มทุกฉบับของเครื่องนี้ตามไปด้วย"""
    before = db.execute("SELECT factory_id, area_id FROM equipment WHERE id=?", (equipment_id,)).fetchone()
    if not before:
        raise ValidationError("ไม่พบเครื่องจักร")
    db.execute("UPDATE equipment SET factory_id=?, area_id=?, updated_at=? WHERE id=?",
               (factory_id, area_id, ts(), equipment_id))
    sync_forms_to_equipment(db, equipment_id)
    if (before["factory_id"], before["area_id"]) != (factory_id, area_id):
        audit(db, actor_id, "move", "equipment", equipment_id,
              before={"factory_id": before["factory_id"], "area_id": before["area_id"]},
              after={"factory_id": factory_id, "area_id": area_id})


def sync_forms_to_equipment(db, equipment_id: int | None = None) -> int:
    """ตำแหน่งแบบฟอร์ม = ตำแหน่งเครื่องจักรที่ผูกไว้ (เฉพาะเครื่องที่ระบุโรงงานแล้ว)"""
    cond, params = ("AND e.id=?", (equipment_id,)) if equipment_id else ("", ())
    cur = db.execute(f"""UPDATE cs_forms SET
            factory_id=(SELECT e.factory_id FROM equipment e WHERE e.id=cs_forms.equipment_id),
            area_id=(SELECT e.area_id FROM equipment e WHERE e.id=cs_forms.equipment_id)
        WHERE equipment_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM equipment e WHERE e.id=cs_forms.equipment_id AND e.factory_id IS NOT NULL {cond}
              AND (IFNULL(cs_forms.factory_id, -1)<>e.factory_id OR IFNULL(cs_forms.area_id, -1)<>IFNULL(e.area_id, -1)))""",
                     params)
    return cur.rowcount


def create_form(db, data: dict, actor_id: int | None, code: str | None = None,
                legacy_template_id: int | None = None) -> int:
    name = str(data.get("name") or "").strip()
    if not name:
        raise ValidationError("กรุณาระบุชื่อแบบฟอร์ม")
    equipment_id, factory_id, area_id, move_eq = _resolve_location(
        db, data.get("equipment_id"), data.get("factory_id"), data.get("area_id"))
    if move_eq:
        set_equipment_location(db, equipment_id, factory_id, area_id, actor_id)
    now = ts()
    cur = db.execute("""
        INSERT INTO cs_forms(code, name, description, equipment_id, factory_id, area_id, category,
                             active, legacy_template_id, created_by, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,1,?,?,?,?)""",
        (code or _next_form_code(db), name[:200], str(data.get("description") or "")[:1000],
         equipment_id, factory_id, area_id,
         clean_category(data.get("category")), legacy_template_id, actor_id, now, now))
    form_id = cur.lastrowid
    db.execute("""INSERT INTO cs_form_versions(form_id, version_no, status, created_by, created_at)
                  VALUES (?,1,'draft',?,?)""", (form_id, actor_id, now))
    audit(db, actor_id, "create", "cs_forms", form_id, after={"name": name})
    return form_id


def update_form_meta(db, form_id: int, data: dict, actor_id: int | None) -> None:
    form = get_form(db, form_id)
    if not form:
        raise ValidationError("ไม่พบแบบฟอร์ม")
    name = str(data.get("name", form["name"]) or "").strip()
    if not name:
        raise ValidationError("กรุณาระบุชื่อแบบฟอร์ม")
    equipment_id, factory_id, area_id, move_eq = _resolve_location(
        db, data.get("equipment_id", form["equipment_id"]),
        data.get("factory_id", form["factory_id"]), data.get("area_id", form["area_id"]), prev=form)
    if move_eq:
        set_equipment_location(db, equipment_id, factory_id, area_id, actor_id)
    active = 1 if data.get("active", form["active"]) in (1, True, "1", "true", "on") else 0
    doc_no = str(data.get("doc_no", form.get("doc_no")) or "").strip()[:60]
    scan = 1 if data.get("require_point_scan", form.get("require_point_scan")) in (1, True, "1", "true", "on") else 0
    db.execute("""UPDATE cs_forms SET name=?, description=?, equipment_id=?, factory_id=?, area_id=?,
                  category=?, active=?, doc_no=?, require_point_scan=?, updated_at=? WHERE id=?""",
               (name[:200], str(data.get("description", form["description"]) or "")[:1000],
                equipment_id, factory_id, area_id,
                clean_category(data.get("category", form["category"])), active, doc_no, scan, ts(), form_id))
    if not active:
        _delete_future_open_rounds(db, form_id=form_id)
    audit(db, actor_id, "update", "cs_forms", form_id,
          before={k: form[k] for k in ("name", "equipment_id", "factory_id", "area_id", "active")},
          after={"name": name, "equipment_id": equipment_id, "factory_id": factory_id,
                 "area_id": area_id, "active": active})


def get_draft(db, form_id: int) -> dict | None:
    return row_dict(db.execute(
        "SELECT * FROM cs_form_versions WHERE form_id=? AND status='draft' ORDER BY version_no DESC LIMIT 1",
        (form_id,)).fetchone())


def get_or_create_draft(db, form_id: int, actor_id: int | None) -> dict:
    """คืนเวอร์ชัน draft ของฟอร์ม ถ้าไม่มีให้คัดลอกจากเวอร์ชันที่ใช้งานอยู่"""
    draft = get_draft(db, form_id)
    if draft:
        return draft
    form = get_form(db, form_id)
    if not form:
        raise ValidationError("ไม่พบแบบฟอร์ม")
    last_no = db.execute("SELECT COALESCE(MAX(version_no),0) FROM cs_form_versions WHERE form_id=?",
                         (form_id,)).fetchone()[0]
    cur = db.execute("""INSERT INTO cs_form_versions(form_id, version_no, status, created_by, created_at)
                        VALUES (?,?,'draft',?,?)""", (form_id, last_no + 1, actor_id, ts()))
    draft_id = cur.lastrowid
    if form["current_version_id"]:
        _copy_items(db, form["current_version_id"], draft_id)
    return get_version(db, draft_id)


def _copy_items(db, from_version: int, to_version: int) -> None:
    cols = ("item_key", "section", "order_no", "name", "item_type", "unit", "min_value", "max_value",
            "warn_low", "warn_high", "counter_max_step", "options_json", "required", "critical",
            "photo_on_ng", "guide", "legacy_item_id", "check_freq", "check_times", "photo_required", "formula")
    db.execute("UPDATE cs_form_versions SET sections_json=(SELECT sections_json FROM cs_form_versions WHERE id=?) "
               "WHERE id=?", (from_version, to_version))
    db.execute(f"""INSERT INTO cs_form_items(version_id, {', '.join(cols)})
                   SELECT ?, {', '.join(cols)} FROM cs_form_items WHERE version_id=?
                   ORDER BY order_no, id""", (to_version, from_version))


def save_draft_items(db, version_id: int, items: Iterable[dict], actor_id: int | None) -> int:
    """แทนที่หัวข้อทั้งหมดของ draft — ทำได้เฉพาะเวอร์ชันที่ยังไม่ Publish"""
    version = get_version(db, version_id)
    if not version:
        raise ValidationError("ไม่พบเวอร์ชัน")
    if version["status"] != "draft":
        raise ValidationError("เวอร์ชันนี้ Publish แล้ว แก้ไขไม่ได้ — กรุณาสร้างฉบับร่างใหม่")
    items = list(items)
    if len(items) > 300:
        raise ValidationError("หัวข้อต่อแบบฟอร์มต้องไม่เกิน 300 หัวข้อ")
    normalized, errors = [], []
    for idx, raw in enumerate(items):
        try:
            normalized.append(normalize_item(raw, idx))
        except ValidationError as exc:
            errors.extend(exc.errors)
    keys = [i["item_key"] for i in normalized]
    if len(keys) != len(set(keys)):
        errors.append("พบหัวข้อซ้ำกัน (item_key ซ้ำ)")
    if not errors:                                      # v0.95 ตรวจสูตรของหัวข้อคำนวณ
        from . import formula as FM
        for idx, it in enumerate(normalized, start=1):
            if it["item_type"] == "calc":
                errors.extend(f"หัวข้อที่ {idx}: {e}" for e in FM.check(it["formula"], it["item_key"], normalized))
    if errors:
        raise ValidationError(errors)
    before = [{"key": i["item_key"], "name": i["name"]} for i in get_items(db, version_id)]
    db.execute("DELETE FROM cs_form_items WHERE version_id=?", (version_id,))
    for order_no, it in enumerate(normalized, start=1):
        db.execute("""
            INSERT INTO cs_form_items(version_id, item_key, section, order_no, name, item_type, unit,
                min_value, max_value, warn_low, warn_high, counter_max_step, options_json,
                required, critical, photo_on_ng, guide, legacy_item_id, check_freq, check_times, photo_required, formula)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (version_id, it["item_key"], it["section"], order_no, it["name"], it["item_type"], it["unit"],
             it["min_value"], it["max_value"], it["warn_low"], it["warn_high"], it["counter_max_step"],
             it["options_json"], it["required"], it["critical"], it["photo_on_ng"], it["guide"],
             it["legacy_item_id"], it["check_freq"], it["check_times"], it["photo_required"], it["formula"]))
    audit(db, actor_id, "save_draft", "cs_form_versions", version_id,
          before=before, after=[{"key": i["item_key"], "name": i["name"]} for i in normalized])
    return len(normalized)


def get_sections(db, version_id: int | None, items: list[dict] | None = None) -> list[dict]:
    """จุดตรวจ (กลุ่มหัวข้อ) ตามลำดับที่ปรากฏ พร้อมข้อมูลเสริม {name, hint, count, no}"""
    meta = {}
    if version_id:
        row = db.execute("SELECT sections_json FROM cs_form_versions WHERE id=?", (version_id,)).fetchone()
        if row and row[0]:
            try:
                meta = {str(s.get("name") or ""): s for s in json.loads(row[0]) if isinstance(s, dict)}
            except ValueError:
                meta = {}
    items = items if items is not None else (get_items(db, version_id) if version_id else [])
    out, seen = [], {}
    for it in items:
        name = it.get("section") or ""
        if name not in seen:
            seen[name] = {"name": name, "hint": str((meta.get(name) or {}).get("hint") or ""), "count": 0,
                          "no": len(out) + 1}
            out.append(seen[name])
        seen[name]["count"] += 1
    return out


def save_sections(db, version_id: int, sections: Iterable[dict] | None) -> None:
    clean = []
    for s in sections or []:
        if not isinstance(s, dict):
            continue
        name = str(s.get("name") or "").strip()[:120]
        hint = str(s.get("hint") or "").strip()[:300]
        if hint:
            clean.append({"name": name, "hint": hint})
    db.execute("UPDATE cs_form_versions SET sections_json=? WHERE id=?",
               (json.dumps(clean, ensure_ascii=False) if clean else "", version_id))


def rev_label(version_no) -> str:
    """เลขแก้ไขเอกสารแบบ ISO: v1 = Rev.00, v2 = Rev.01 …"""
    try:
        return f"Rev.{max(int(version_no) - 1, 0):02d}"
    except (TypeError, ValueError):
        return ""


def publish_version(db, version_id: int, actor_id: int | None, note: str = "",
                    effective_date: str | None = None, approved_by_name: str = "") -> dict:
    version = get_version(db, version_id)
    if not version:
        raise ValidationError("ไม่พบเวอร์ชัน")
    if version["status"] != "draft":
        raise ValidationError("เวอร์ชันนี้ Publish แล้ว")
    count = db.execute("SELECT COUNT(*) FROM cs_form_items WHERE version_id=?", (version_id,)).fetchone()[0]
    if count == 0:
        raise ValidationError("ต้องมีหัวข้อตรวจอย่างน้อย 1 หัวข้อก่อน Publish")
    now = ts()
    db.execute("UPDATE cs_form_versions SET status='retired' WHERE form_id=? AND status='published'",
               (version["form_id"],))
    eff = str(effective_date or "").strip()[:10]
    if eff and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", eff):
        raise ValidationError("วันที่มีผลบังคับใช้ไม่ถูกต้อง")
    db.execute("""UPDATE cs_form_versions SET status='published', published_by=?, published_at=?,
                  change_note=?, effective_date=?, approved_by_name=? WHERE id=?""",
               (actor_id, now, str(note or "")[:500], eff or now[:10], str(approved_by_name or "").strip()[:120],
                version_id))
    db.execute("UPDATE cs_forms SET current_version_id=?, updated_at=? WHERE id=?",
               (version_id, now, version["form_id"]))
    audit(db, actor_id, "publish", "cs_form_versions", version_id,
          after={"form_id": version["form_id"], "version_no": version["version_no"], "note": note})
    return get_version(db, version_id)


def discard_draft(db, form_id: int, actor_id: int | None) -> None:
    draft = get_draft(db, form_id)
    if not draft:
        return
    form = get_form(db, form_id)
    if not form["current_version_id"]:
        raise ValidationError("แบบฟอร์มนี้ยังไม่เคย Publish ลบฉบับร่างแรกไม่ได้")
    db.execute("DELETE FROM cs_form_items WHERE version_id=?", (draft["id"],))
    db.execute("DELETE FROM cs_form_versions WHERE id=?", (draft["id"],))
    audit(db, actor_id, "discard_draft", "cs_form_versions", draft["id"])


# ───────────────────────── schedules ─────────────────────────

_TIME_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
WEEKDAY_TH = ["จ.", "อ.", "พ.", "พฤ.", "ศ.", "ส.", "อา."]


def parse_times(raw: str) -> list[time]:
    out = []
    for part in str(raw or "").split(","):
        part = part.strip()
        if not part:
            continue
        m = _TIME_RE.match(part)
        if not m:
            raise ValidationError(f"เวลา '{part}' ไม่ถูกต้อง ใช้รูปแบบ HH:MM เช่น 08:00")
        out.append(time(int(m.group(1)), int(m.group(2))))
    if not out:
        raise ValidationError("กรุณาระบุเวลาเริ่มตรวจอย่างน้อย 1 เวลา")
    return sorted(set(out))


def normalize_schedule(data: dict) -> dict:
    errors = []
    freq = str(data.get("freq_type") or "daily").strip()
    from .itemfreq import interval as _interval               # v0.34 ทุก N วัน / สัปดาห์ / เดือน (d:N · w:N · m:N)
    iv = _interval(freq)
    if freq not in FREQ_TYPES and not iv:
        errors.append(f"ความถี่ '{freq}' ไม่รองรับ")
    kind = ("weekly" if iv[0] == "w" else "monthly" if iv[0] == "m" else "daily") if iv else freq
    anchor = ""
    if iv:
        raw = str(data.get("anchor_date") or "").strip()[:10]
        try:
            anchor = date.fromisoformat(raw).isoformat() if raw else date.today().isoformat()
        except ValueError:
            errors.append("วันที่เริ่มนับรอบไม่ถูกต้อง")
    try:
        times = parse_times(data.get("times") or ("08:00,20:00" if freq == "shift" else "08:00"))
    except ValidationError as exc:
        errors.extend(exc.errors)
        times = []
    weekdays: list[int] = []
    if kind == "weekly":
        raw_wd = data.get("weekdays")
        parts = raw_wd if isinstance(raw_wd, list) else str(raw_wd or "").split(",")
        for p in parts:
            p = str(p).strip()
            if p == "":
                continue
            if not p.isdigit() or not 0 <= int(p) <= 6:
                errors.append(f"วันในสัปดาห์ '{p}' ไม่ถูกต้อง")
            else:
                weekdays.append(int(p))
        if not weekdays:
            errors.append("รายสัปดาห์ต้องเลือกวันอย่างน้อย 1 วัน")
    month_day = None
    if kind == "monthly":
        try:
            month_day = int(data.get("month_day") or 0)
        except (TypeError, ValueError):
            month_day = 0
        if not 1 <= month_day <= 28:
            errors.append("รายเดือนต้องระบุวันที่ 1–28")
    try:
        window_min = int(data.get("window_min") or 240)
    except (TypeError, ValueError):
        window_min = 0
    if not 5 <= window_min <= 60 * 24 * 7:
        errors.append("ระยะเวลาที่ต้องตรวจให้เสร็จต้องอยู่ระหว่าง 5 นาที ถึง 7 วัน")
    if errors:
        raise ValidationError(errors)
    assignee_user_id = data.get("assignee_user_id") or None
    return {
        "freq_type": freq,
        "times": ",".join(t.strftime("%H:%M") for t in times),
        "weekdays": ",".join(str(d) for d in sorted(set(weekdays))),
        "month_day": month_day,
        "window_min": window_min,
        "skip_holidays": 1 if data.get("skip_holidays") in (1, True, "1", "true", "on") else 0,
        "assignee_role": str(data.get("assignee_role") or "technician")[:30],
        "assignee_user_id": int(assignee_user_id) if assignee_user_id else None,
        "active": 0 if data.get("active") in (0, False, "0", "false") else 1,
        "anchor_date": anchor,
    }


def describe_schedule(s: dict) -> str:
    times = s["times"].replace(",", ", ")
    if s["freq_type"] == "shift":
        txt = f"ทุกกะ ({times})"
    elif s["freq_type"] == "daily":
        txt = f"ทุกวัน {times}"
    elif s["freq_type"] == "weekly":
        days = " ".join(WEEKDAY_TH[int(d)] for d in s["weekdays"].split(",") if d != "")
        txt = f"ทุกสัปดาห์ ({days}) {times}"
    elif s["freq_type"] == "semimonthly":
        return f"เดือนละ 2 ครั้ง — ครึ่งแรก 1–15 · ครึ่งหลัง 16–สิ้นเดือน (เริ่ม {times}) · ตรวจวันไหนก็ได้ภายในช่วง"
    elif ":" in (s["freq_type"] or ""):
        from .itemfreq import UNIT_TH, interval
        iv = interval(s["freq_type"])
        u, n = iv if iv else ("d", 1)
        start = s.get("anchor_date") or ""
        start_th = f" · นับรอบจาก {int(start[8:10])}/{int(start[5:7])}/{int(start[:4]) + 543}" if len(start) == 10 else ""
        if u == "w":
            days = " ".join(WEEKDAY_TH[int(d)] for d in (s["weekdays"] or "").split(",") if d != "")
            txt = f"ทุก {n} สัปดาห์ ({days}) {times}{start_th}"
        elif u == "m":
            txt = f"ทุก {n} เดือน วันที่ {s['month_day']} {times}{start_th}"
        else:
            txt = f"ทุก {n} วัน {times}{start_th}"
    else:
        txt = f"ทุกเดือน วันที่ {s['month_day']} {times}"
    hours, mins = divmod(int(s["window_min"]), 60)
    window = (f"{hours} ชม." if hours else "") + (f" {mins} นาที" if mins else "")
    return f"{txt} · ต้องเสร็จภายใน {window.strip()}"


def create_schedule(db, form_id: int, data: dict, actor_id: int | None) -> int:
    if not get_form(db, form_id):
        raise ValidationError("ไม่พบแบบฟอร์ม")
    s = normalize_schedule(data)
    now = ts()
    cur = db.execute("""INSERT INTO cs_schedules(form_id, freq_type, times, weekdays, month_day, window_min,
                        skip_holidays, assignee_role, assignee_user_id, active, created_at, updated_at, anchor_date)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (form_id, s["freq_type"], s["times"], s["weekdays"], s["month_day"], s["window_min"],
                      s["skip_holidays"], s["assignee_role"], s["assignee_user_id"], s["active"], now, now, s["anchor_date"]))
    audit(db, actor_id, "create", "cs_schedules", cur.lastrowid, after=s)
    return cur.lastrowid


def update_schedule(db, schedule_id: int, data: dict, actor_id: int | None) -> None:
    before = row_dict(db.execute("SELECT * FROM cs_schedules WHERE id=?", (schedule_id,)).fetchone())
    if not before:
        raise ValidationError("ไม่พบรอบตรวจ")
    s = normalize_schedule({**before, **data})
    db.execute("""UPDATE cs_schedules SET freq_type=?, times=?, weekdays=?, month_day=?, window_min=?,
                  skip_holidays=?, assignee_role=?, assignee_user_id=?, active=?, updated_at=?, anchor_date=? WHERE id=?""",
               (s["freq_type"], s["times"], s["weekdays"], s["month_day"], s["window_min"], s["skip_holidays"],
                s["assignee_role"], s["assignee_user_id"], s["active"], ts(), s["anchor_date"], schedule_id))
    # รอบในอนาคตที่ยังไม่มีคนตรวจ ต้องสร้างใหม่ตามเงื่อนไขใหม่
    _delete_future_open_rounds(db, schedule_id=schedule_id)
    audit(db, actor_id, "update", "cs_schedules", schedule_id, before=before, after=s)


def delete_schedule(db, schedule_id: int, actor_id: int | None) -> None:
    before = row_dict(db.execute("SELECT * FROM cs_schedules WHERE id=?", (schedule_id,)).fetchone())
    if not before:
        raise ValidationError("ไม่พบรอบตรวจ")
    # ไม่ลบจริงเพื่อเก็บประวัติรอบที่ผ่านมา
    db.execute("UPDATE cs_schedules SET active=0, updated_at=? WHERE id=?", (ts(), schedule_id))
    _delete_future_open_rounds(db, schedule_id=schedule_id)
    cleanup_orphan_rounds(db, schedule_id=schedule_id)          # v0.53 รอบที่ค้าง (เลยกำหนด) + แจ้งเตือนของรอบตรวจนี้
    audit(db, actor_id, "deactivate", "cs_schedules", schedule_id, before=before)


def list_schedules(db, form_id: int) -> list[dict]:
    rows = db.execute("""SELECT s.*, u.name AS assignee_name FROM cs_schedules s
                         LEFT JOIN users u ON u.id=s.assignee_user_id
                         WHERE s.form_id=? ORDER BY s.active DESC, s.id""", (form_id,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["description"] = describe_schedule(d)
        out.append(d)
    return out


def _delete_future_open_rounds(db, schedule_id: int | None = None, form_id: int | None = None) -> None:
    cond, params = [], []
    if schedule_id is not None:
        cond.append("schedule_id=?")
        params.append(schedule_id)
    if form_id is not None:
        cond.append("form_id=?")
        params.append(form_id)
    db.execute(f"""DELETE FROM cs_rounds WHERE {' AND '.join(cond)}
                   AND submission_id IS NULL AND status='pending' AND due_at > ?""", params + [ts()])


# ───────────────────────── rounds ─────────────────────────

def _holidays(db) -> set[date]:
    try:
        rows = db.execute("SELECT holiday_date FROM holidays").fetchall()
    except Exception:
        return set()
    out = set()
    for r in rows:
        d = parse_ts(r[0])
        if d:
            out.add(d.date())
    return out


def half_month_end(dt: datetime) -> datetime:
    """สิ้นสุดครึ่งเดือนของเวลานี้: 15 23:59:59 หรือวันสุดท้ายของเดือน 23:59:59"""
    import calendar as _cal
    last = 15 if dt.day <= 15 else _cal.monthrange(dt.year, dt.month)[1]
    return datetime(dt.year, dt.month, last, 23, 59, 59)


def _occurs_on(s: dict, day: date, holidays: set[date]) -> bool:
    if s["skip_holidays"] and day in holidays and s["freq_type"] != "semimonthly":
        return False
    if s["freq_type"] in ("shift", "daily"):
        return True
    if s["freq_type"] == "weekly":
        return str(day.weekday()) in s["weekdays"].split(",")
    if s["freq_type"] == "monthly":
        return day.day == int(s["month_day"] or 0)
    if s["freq_type"] == "semimonthly":                         # v0.35 รอบเริ่มวันที่ 1 และ 16
        return day.day in (1, 16)
    if ":" in (s["freq_type"] or ""):                           # v0.34 ทุก N วัน/สัปดาห์/เดือน นับจากวันที่เริ่ม
        from .itemfreq import interval
        iv = interval(s["freq_type"])
        if not iv:
            return False
        u, n = iv
        try:
            anchor = date.fromisoformat((s.get("anchor_date") or "")[:10])
        except ValueError:
            anchor = date(2024, 1, 1)
        if day < anchor:
            return False
        if u == "d":
            return (day - anchor).days % n == 0
        if u == "w":
            if str(day.weekday()) not in (s["weekdays"] or "").split(","):
                return False
            wk = ((day - timedelta(days=day.weekday())) - week_base(anchor, s["weekdays"])).days // 7
            return wk % n == 0
        if day.day != int(s["month_day"] or 0):
            return False
        return ((day.year * 12 + day.month) - (anchor.year * 12 + anchor.month)) % n == 0
    return False


def week_base(anchor: date, weekdays: str | None) -> date:
    """v0.38 วันจันทร์ของสัปดาห์แรกที่นับรอบ 'ทุก N สัปดาห์' = สัปดาห์ของรอบแรกที่ถึงหลังวันเริ่มนับ
    (เดิมนับจากสัปดาห์ของวันเริ่มนับเสมอ → ถ้าตั้งวันเริ่มกลางสัปดาห์หลังวันตรวจ รอบแรกเลื่อนไป N สัปดาห์ และไม่มีแจ้งเตือน)"""
    wds = sorted({int(x) for x in str(weekdays or "").split(",") if x.strip().isdigit() and 0 <= int(x) <= 6}) or [anchor.weekday()]
    first = min(anchor + timedelta(days=(w - anchor.weekday()) % 7) for w in wds)
    return first - timedelta(days=first.weekday())


def occurrences(s: dict, start: date, end: date, holidays: set[date] | None = None) -> list[datetime]:
    """เวลาเริ่มตรวจทั้งหมดของ schedule ในช่วงวันที่ [start, end]"""
    holidays = holidays or set()
    times = parse_times(s["times"])
    out, day = [], start
    while day <= end:
        if _occurs_on(s, day, holidays):
            out.extend(datetime.combine(day, t) for t in times)
        day += timedelta(days=1)
    return out


def _next_occurrence(s: dict, after: datetime, holidays: set[date]) -> datetime | None:
    span = 62 if ":" not in (s.get("freq_type") or "") else 400      # รอบทุก N เดือน อาจห่างเกิน 2 เดือน
    for dt in occurrences(s, after.date(), after.date() + timedelta(days=span), holidays):
        if dt > after:
            return dt
    return None


def round_window(s: dict, due: datetime, holidays: set[date]) -> tuple[datetime, datetime]:
    """(deadline, close) ของรอบที่เริ่ม due — ใช้ร่วมกันระหว่างสร้างรอบและคำนวณรอบใหม่ (v0.41)"""
    deadline = due + timedelta(minutes=int(s["window_min"]))
    if s["freq_type"] == "semimonthly":                     # ตรวจได้ตลอดครึ่งเดือนนั้น (ถึง 15 หรือสิ้นเดือน 23:59)
        deadline = half_month_end(due)
    nxt = _next_occurrence(s, due, holidays)
    close = max(nxt, deadline) if nxt else deadline + timedelta(days=1)
    return deadline, close


def scheduled_sql(col: str = "r.form_id") -> str:
    """v0.41 เงื่อนไข SQL: แบบฟอร์มที่มีรอบตรวจเปิดใช้งานอยู่ (แบบฟอร์มที่ยังไม่กำหนดรอบตรวจไม่นับในสถิติ)"""
    return f"EXISTS (SELECT 1 FROM cs_schedules sx WHERE sx.form_id={col} AND sx.active=1)"


def stat_exclusions(db) -> list[dict]:
    """v0.41 ช่วงวันที่ที่ผู้ดูแลระบบลบออกจากสถิติ"""
    try:
        return [dict(r) for r in db.execute("SELECT * FROM cs_stat_excl")]
    except Exception:                                       # noqa: BLE001 — ฐานข้อมูลเก่ายังไม่มีตาราง
        return []


def is_excluded(excl: list[dict], factory_id, area_id, form_id, day: date) -> bool:
    d = day.isoformat()
    for x in excl:
        if x["day_from"] <= d <= x["day_to"] \
                and (not x["factory_id"] or x["factory_id"] == factory_id) \
                and (not x["area_id"] or x["area_id"] == area_id) \
                and (not x["form_id"] or x["form_id"] == form_id):
            return True
    return False


def rounds_start_dt(db, now: datetime | None = None) -> datetime:
    row = db.execute("SELECT value FROM cs_meta WHERE key='rounds_start'").fetchone()
    return (parse_ts(row[0]) if row else None) or (now or now_dt())


# v0.99.8 เกณฑ์เดียวทั้งระบบ: รอบ "เครื่องหยุด" (skipped) = เครื่องหยุดก่อนเวลาปิดรอบ และยังหยุดอยู่ ณ เวลาปิดรอบ
# (ช่วงหยุดใน cs_downtime · หรือเครื่องที่สถานะหยุดอยู่ตอนนี้ตั้งแต่ down_since แต่ไม่มีช่วงหยุดที่เปิดอยู่ = ข้อมูลเก่า)
DOWN_COVER_SQL = """EXISTS (SELECT 1 FROM cs_forms fq JOIN equipment eq ON eq.id=fq.equipment_id WHERE fq.id={r}.form_id AND (
    EXISTS (SELECT 1 FROM cs_downtime dq WHERE dq.equipment_id=eq.id AND dq.start_at < {r}.close_at
            AND (dq.end_at IS NULL OR dq.end_at >= {r}.close_at))
    OR (COALESCE(eq.run_status, 'running')='down' AND eq.down_since IS NOT NULL AND eq.down_since < {r}.close_at
        AND NOT EXISTS (SELECT 1 FROM cs_downtime dz WHERE dz.equipment_id=eq.id AND dz.end_at IS NULL))))"""


def down_covers(db, form_id: int, close_at: str) -> bool:
    """รอบที่ปิด ณ close_at ของแบบฟอร์มนี้ เป็นรอบ "เครื่องหยุด" หรือไม่ (เกณฑ์เดียวกับ DOWN_COVER_SQL)"""
    sql = DOWN_COVER_SQL.format(r="x")
    return db.execute(f"SELECT 1 FROM (SELECT ? AS form_id, ? AS close_at) x WHERE {sql}", (form_id, close_at)).fetchone() is not None


# รอบที่งดตรวจไว้ ตรวจสอบกับช่วงหยุดได้ = เครื่องมีประวัติช่วงหยุดในตาราง (เกณฑ์เดียวกับ v0.55 fix_stale_skipped)
# (เครื่องที่ไม่มีช่วงหยุดเลย = ข้อมูลเก่าก่อนมีตารางช่วงหยุด ไม่มีหลักฐานให้ตรวจ → คงไว้)
DOWN_KNOWN_SQL = """EXISTS (SELECT 1 FROM cs_forms fk JOIN cs_downtime dk ON dk.equipment_id=fk.equipment_id
    WHERE fk.id={r}.form_id)"""


def down_known(db, form_id: int) -> bool:
    sql = DOWN_KNOWN_SQL.format(r="x")
    return db.execute(f"SELECT 1 FROM (SELECT ? AS form_id) x WHERE {sql}", (form_id,)).fetchone() is not None


def reconcile_down_rounds(db, now: datetime | None = None, form_ids=None, actor_id=None) -> dict:
    """v0.99.9 ตรวจรอบตรวจที่ยังไม่มีผลตรวจ กับช่วงหยุดเครื่อง — ย้อนหลังทั้งหมด (ทุกวันที่) ทั้ง 2 ทาง
    - เครื่องหยุดครอบเวลาปิดรอบ แต่เป็น รอตรวจ/เลยกำหนด/ขาดตรวจ → เครื่องหยุด + ปิดแจ้งเตือนขาดตรวจ
    - งดตรวจไว้ แต่ช่วงหยุดไม่ครอบเวลาปิดรอบแล้ว (แก้/ลบช่วงหยุด · เปลี่ยนเวลารอบตรวจ) → สถานะตามเวลา
    รอบที่มีผลตรวจแล้วไม่แตะ · แก้แล้วคำนวณสถิติรายวันของแบบฟอร์มนั้นใหม่"""
    now = now or now_dt()
    stamp = ts(now)
    scope, args = "", []
    if form_ids is not None:
        ids = sorted({int(x) for x in form_ids if x})
        if not ids:
            return {"down_skipped": 0, "down_restored": 0}
        scope = f" AND r.form_id IN ({','.join('?' * len(ids))})"
        args = ids
    cover = db.execute(f"""SELECT r.id, r.form_id FROM cs_rounds r WHERE r.submission_id IS NULL
                           AND r.status IN ('pending','in_progress','overdue','missed'){scope}
                           AND {DOWN_COVER_SQL.format(r='r')}""", args).fetchall()
    stale = db.execute(f"""SELECT r.id, r.form_id, r.deadline_at, r.close_at FROM cs_rounds r WHERE r.submission_id IS NULL
                           AND r.status='skipped'{scope} AND {DOWN_KNOWN_SQL.format(r='r')}
                           AND NOT {DOWN_COVER_SQL.format(r='r')}""", args).fetchall()
    if cover:
        cid = [x["id"] for x in cover]
        for i in range(0, len(cid), 500):
            part = cid[i:i + 500]
            db.execute(f"UPDATE cs_rounds SET status='skipped', updated_at=? WHERE id IN ({','.join('?' * len(part))})",
                       [stamp, *part])
        from .statfix import _close_missed_alerts
        _close_missed_alerts(db, cid, actor_id, stamp, "เครื่องหยุดก่อนปิดรอบ — นับเป็นรอบเครื่องหยุด (ไม่นับขาดตรวจ)")
    for r in stale:                                   # ไม่แตะ updated_at → ไม่เกิดแจ้งเตือนขาดตรวจย้อนหลัง
        st = "missed" if r["close_at"] <= stamp else ("overdue" if r["deadline_at"] <= stamp else "pending")
        db.execute("UPDATE cs_rounds SET status=? WHERE id=?", (st, r["id"]))
    touched = {x["form_id"] for x in cover} | {x["form_id"] for x in stale}
    if touched:
        from .analytics import refresh_form_stats
        refresh_form_stats(db, touched)
    return {"down_skipped": len(cover), "down_restored": len(stale)}


def generate_rounds(db, now: datetime | None = None, horizon_days: int = 1) -> int:
    """สร้างรอบตรวจล่วงหน้าตั้งแต่เมื่อวานถึงอีก horizon_days วัน (ทำซ้ำได้ ไม่สร้างซ้ำ)

    ไม่สร้างรอบย้อนหลังก่อนวันที่เริ่มใช้ระบบ (cs_meta.rounds_start) เพื่อไม่ให้ประวัติเก่าเป็น 'ขาดตรวจ'
    """
    now = now or now_dt()
    start_row = db.execute("SELECT value FROM cs_meta WHERE key='rounds_start'").fetchone()
    if start_row is None:                    # v0.99.38 OR IGNORE: หลายคำขอพร้อมกันตอนเริ่มใช้ระบบครั้งแรก ไม่ชน UNIQUE
        db.execute("INSERT OR IGNORE INTO cs_meta(key, value) VALUES('rounds_start', ?)", (ts(now),))
        start_row = db.execute("SELECT value FROM cs_meta WHERE key='rounds_start'").fetchone()
        rounds_start = parse_ts(start_row[0]) or now
    else:
        rounds_start = parse_ts(start_row[0]) or now
    holidays = _holidays(db)
    start_day = (now - timedelta(days=1)).date()
    end_day = (now + timedelta(days=horizon_days)).date()
    schedules = db.execute("""SELECT s.*, COALESCE(e.run_status, 'running') AS eq_run_status,
                                     f.factory_id AS f_factory, COALESCE(e.area_id, f.area_id) AS f_area
                              FROM cs_schedules s JOIN cs_forms f ON f.id=s.form_id LEFT JOIN equipment e ON e.id=f.equipment_id
                              WHERE s.active=1 AND f.active=1 AND f.is_template=0 AND f.current_version_id IS NOT NULL""").fetchall()
    excl = stat_exclusions(db)
    created = 0
    stamp = ts(now)
    for srow in schedules:
        s = dict(srow)
        for due in occurrences(s, start_day, end_day, holidays):
            if due < rounds_start:
                continue
            if excl and is_excluded(excl, s["f_factory"], s["f_area"], s["form_id"], due.date()):
                continue                                    # v0.41 ผู้ดูแลระบบลบช่วงนี้ออกจากสถิติแล้ว
            deadline, close = round_window(s, due, holidays)
            cur = db.execute("""INSERT OR IGNORE INTO cs_rounds(schedule_id, form_id, due_at, deadline_at,
                                close_at, status, updated_at) VALUES (?,?,?,?,?,?,?)""",
                             (s["id"], s["form_id"], ts(due), ts(deadline), ts(close), "pending", stamp))
            if cur.rowcount and down_covers(db, s["form_id"], ts(close)):
                # เครื่องหยุดครอบเวลาปิดรอบ → เครื่องหยุด (ไม่ต้องตรวจ ไม่นับขาดตรวจ) · v0.99.8 รวมรอบที่สร้างหลังเวลาปิดรอบแล้ว
                db.execute("UPDATE cs_rounds SET status='skipped' WHERE id=?", (cur.lastrowid,))
            created += cur.rowcount
    return created


def refresh_round_statuses(db, now: datetime | None = None) -> dict:
    """อัปเดตสถานะรอบที่ยังไม่ส่ง: เลยกำหนด (overdue) / ขาดตรวจ (missed) — v0.53 ล้างรอบของรอบตรวจที่ปิดแล้วก่อน"""
    cleaned = cleanup_orphan_rounds(db, now)
    stamp = ts(now or now_dt())
    rec = reconcile_down_rounds(db, now)            # v0.99.9 ตรวจรอบเครื่องหยุดกับช่วงหยุดเครื่องย้อนหลังทั้งหมด
    live = "AND EXISTS (SELECT 1 FROM cs_schedules sx WHERE sx.id=cs_rounds.schedule_id AND sx.active=1)"
    missed = db.execute(f"""UPDATE cs_rounds SET status='missed', updated_at=?
                           WHERE submission_id IS NULL AND status IN ('pending','in_progress','overdue')
                           AND close_at <= ? {live}""", (stamp, stamp)).rowcount
    overdue = db.execute(f"""UPDATE cs_rounds SET status='overdue', updated_at=?
                            WHERE submission_id IS NULL AND status IN ('pending','in_progress')
                            AND deadline_at <= ? {live}""", (stamp, stamp)).rowcount
    return {"missed": missed, "overdue": overdue, "cleaned": cleaned, **rec}


def cleanup_orphan_rounds(db, now: datetime | None = None, schedule_id: int | None = None) -> int:
    """v0.53 รอบตรวจที่ไม่ควรมีแล้ว (รอบตรวจถูกปิด / แบบฟอร์มถูกปิด/เป็นแม่แบบ/ไม่มีเวอร์ชันใช้งาน):
    ลบรอบที่ยังไม่ได้ส่ง (รอตรวจ / กำลังตรวจ / เลยกำหนด) และปิดแจ้งเตือน "ขาดตรวจ / เลยกำหนด" ที่ค้างของรอบเหล่านั้น
    รอบที่ส่งแล้ว / ขาดตรวจที่ปิดไปแล้ว เก็บไว้เป็นประวัติ (ไม่นับสถิติเมื่อแบบฟอร์มไม่มีรอบตรวจ)"""
    now_s = ts(now or now_dt())
    dead = """(NOT EXISTS (SELECT 1 FROM cs_schedules sx WHERE sx.id=r.schedule_id AND sx.active=1)
               OR NOT EXISTS (SELECT 1 FROM cs_forms fx WHERE fx.id=r.form_id AND fx.active=1
                              AND COALESCE(fx.is_template,0)=0 AND fx.current_version_id IS NOT NULL))"""
    cond, params = "", []
    if schedule_id is not None:
        cond, params = " AND r.schedule_id=?", [schedule_id]
    ids = [x[0] for x in db.execute(f"""SELECT r.id FROM cs_rounds r WHERE r.submission_id IS NULL
                                        AND r.status IN ('pending','in_progress','overdue') AND {dead}{cond}""", params)]
    missed = [x[0] for x in db.execute(f"""SELECT r.id FROM cs_rounds r WHERE r.status='missed' AND {dead}{cond}""", params)]
    if not ids and not missed:
        return 0
    from .anomaly import OPEN_STATUSES
    note = "ปิดอัตโนมัติ: แบบฟอร์มนี้ไม่มีรอบตรวจนี้แล้ว (ปิด/แก้รอบตรวจ)"
    for rid in ids + missed:
        for a in db.execute(f"""SELECT id FROM cs_alerts WHERE alert_type IN ('missed','overdue') AND round_id=?
                                AND status IN ({','.join('?' * len(OPEN_STATUSES))})""", (rid, *OPEN_STATUSES)).fetchall():
            db.execute("UPDATE cs_alerts SET status='closed', closed_at=?, close_note=?, updated_at=? WHERE id=?",
                       (now_s, note, now_s, a[0]))
            db.execute("INSERT INTO cs_alert_events(alert_id, event, actor_id, detail, created_at) VALUES (?,?,?,?,?)",
                       (a[0], "close", None, note, now_s))
    for rid in ids:
        db.execute("UPDATE cs_alerts SET round_id=NULL WHERE round_id=?", (rid,))
        db.execute("DELETE FROM cs_rounds WHERE id=?", (rid,))
    return len(ids)


def round_status_for_submission(round_row: dict, finished_at: datetime) -> str:
    deadline = parse_ts(round_row["deadline_at"])
    return "done_on_time" if deadline is None or finished_at <= deadline else "done_late"


def rounds_overview(db, day: date, factory_id: int | None = None) -> dict:
    """สรุปรอบตรวจของวัน สำหรับหน้าติดตาม"""
    start = datetime.combine(day, time(0, 0))
    end = start + timedelta(days=1)
    params: list[Any] = [ts(start), ts(end)]
    fac = ""
    if factory_id:
        fac = " AND f.factory_id=?"
        params.append(factory_id)
    rows = db.execute(f"""
        SELECT r.*, f.name AS form_name, f.code AS form_code, fa.name AS factory_name, e.code AS eq_code,
               f.equipment_id, e.name AS eq_name, COALESCE(e.run_status,'running') AS run_status, e.down_reason, e.down_since,
               dbu.name AS down_by_name, ar.name AS area_name,
               sb.inspector_id, u.name AS inspector_name, sb.finished_at, sb.ng_count, sb.approval_status
        FROM cs_rounds r
        JOIN cs_forms f ON f.id=r.form_id
        LEFT JOIN factories fa ON fa.id=f.factory_id
        LEFT JOIN equipment e ON e.id=f.equipment_id
        LEFT JOIN users dbu ON dbu.id=e.down_by
        LEFT JOIN areas ar ON ar.id=COALESCE(e.area_id, f.area_id)
        LEFT JOIN cs_submissions sb ON sb.id=r.submission_id
        LEFT JOIN users u ON u.id=sb.inspector_id
        WHERE r.due_at >= ? AND r.due_at < ? AND {scheduled_sql()} {fac}
        ORDER BY r.due_at, fa.sort_no, f.name""", params).fetchall()
    items = [dict(r) for r in rows]
    counts = {k: 0 for k in ("pending", "in_progress", "overdue", "done_on_time", "done_late", "missed", "returned", "skipped")}
    for it in items:
        counts[it["status"]] = counts.get(it["status"], 0) + 1
    total = len(items)
    done = counts["done_on_time"] + counts["done_late"]
    closed = done + counts["missed"]
    return {
        "date": day.isoformat(), "total": total, "counts": counts,
        "on_time_rate": round(100.0 * counts["done_on_time"] / closed, 1) if closed else None,
        "done": done, "items": items,
    }


# ───────────────────────── ลบแบบฟอร์ม ─────────────────────────

def form_delete_impact(db, form_ids: list[int]) -> list[dict]:
    """จำนวนข้อมูลที่จะหายไปเมื่อลบแต่ละแบบฟอร์ม (ใช้แสดงก่อนยืนยัน)"""
    out = []
    for fid in form_ids:
        f = db.execute("SELECT id, code, name FROM cs_forms WHERE id=?", (fid,)).fetchone()
        if not f:
            continue
        cnt = lambda sql: db.execute(sql, (fid,)).fetchone()[0]  # noqa: E731
        out.append({"id": f["id"], "code": f["code"], "name": f["name"],
                    "submissions": cnt("SELECT COUNT(*) FROM cs_submissions WHERE form_id=?"),
                    "rounds": cnt("SELECT COUNT(*) FROM cs_rounds WHERE form_id=?"),
                    "alerts": cnt("SELECT COUNT(*) FROM cs_alerts WHERE form_id=?"),
                    "actions": db.execute("""SELECT COUNT(*) FROM cs_actions WHERE form_id=? OR alert_id IN
                                  (SELECT id FROM cs_alerts WHERE form_id=?) OR submission_id IN
                                  (SELECT id FROM cs_submissions WHERE form_id=?)""", (fid, fid, fid)).fetchone()[0]})
    return out


def delete_form(db, form_id: int, actor_id: int | None) -> dict:
    """ลบแบบฟอร์มถาวร พร้อมเวอร์ชัน รอบตรวจ ผลตรวจ รูป และแจ้งเตือนของแบบฟอร์มนี้

    งานแก้ไข (CAPA) ที่เคยเปิดจากแบบฟอร์มนี้ยังเก็บไว้เป็นประวัติ (ตัดการเชื่อมโยงออก)
    คืนรายการไฟล์รูปที่ต้องลบออกจากดิสก์ (ให้ผู้เรียกลบหลัง commit สำเร็จ)
    """
    form = db.execute("SELECT id, code, name FROM cs_forms WHERE id=?", (form_id,)).fetchone()
    if not form:
        raise ValidationError("ไม่พบแบบฟอร์ม")
    subs = "SELECT id FROM cs_submissions WHERE form_id=?"
    alerts = "SELECT id FROM cs_alerts WHERE form_id=?"
    files = [r[0] for r in db.execute(f"SELECT file_path FROM cs_photos WHERE submission_id IN ({subs})", (form_id,))]
    counts = {"submissions": db.execute("SELECT COUNT(*) FROM cs_submissions WHERE form_id=?", (form_id,)).fetchone()[0]}
    db.execute(f"""UPDATE cs_actions SET form_id=NULL,
                   alert_id=CASE WHEN alert_id IN ({alerts}) THEN NULL ELSE alert_id END,
                   submission_id=CASE WHEN submission_id IN ({subs}) THEN NULL ELSE submission_id END
                   WHERE form_id=? OR alert_id IN ({alerts}) OR submission_id IN ({subs})""",
               (form_id, form_id, form_id, form_id, form_id))
    db.execute(f"UPDATE cs_msg_outbox SET alert_id=NULL WHERE alert_id IN ({alerts})", (form_id,))
    db.execute(f"DELETE FROM cs_alert_events WHERE alert_id IN ({alerts})", (form_id,))
    db.execute("DELETE FROM cs_alerts WHERE form_id=?", (form_id,))
    db.execute(f"DELETE FROM cs_photos WHERE submission_id IN ({subs})", (form_id,))
    db.execute(f"DELETE FROM cs_answers WHERE submission_id IN ({subs})", (form_id,))
    db.execute("UPDATE cs_submissions SET resubmit_of=NULL WHERE form_id=?", (form_id,))
    db.execute("UPDATE cs_rounds SET submission_id=NULL WHERE form_id=?", (form_id,))
    db.execute("DELETE FROM cs_submissions WHERE form_id=?", (form_id,))
    db.execute("DELETE FROM cs_rounds WHERE form_id=?", (form_id,))
    db.execute("DELETE FROM cs_schedules WHERE form_id=?", (form_id,))
    db.execute("DELETE FROM cs_form_items WHERE version_id IN (SELECT id FROM cs_form_versions WHERE form_id=?)", (form_id,))
    db.execute("UPDATE cs_forms SET current_version_id=NULL WHERE id=?", (form_id,))
    db.execute("DELETE FROM cs_form_versions WHERE form_id=?", (form_id,))
    for table in ("cs_daily_stats", "cs_silences", "cs_source_tags", "cs_route_stops", "cs_template_overrides", "cs_template_local_items"):
        db.execute(f"DELETE FROM {table} WHERE form_id=?", (form_id,))
    db.execute("UPDATE cs_forms SET template_id=NULL WHERE template_id=?", (form_id,))   # ลบแม่แบบ → เครื่องใช้ฉบับของตัวเองต่อ
    db.execute("DELETE FROM cs_forms WHERE id=?", (form_id,))
    audit(db, actor_id, "delete", "cs_forms", form_id,
          before={"code": form["code"], "name": form["name"], **counts})
    return {"code": form["code"], "name": form["name"], "files": files, **counts}


# ───────────────────────── ลบเครื่องจักร ─────────────────────────

def equipment_delete_impact(db, ids: list[int]) -> list[dict]:
    out = []
    for eid in ids:
        e = db.execute("SELECT id, code, name FROM equipment WHERE id=?", (eid,)).fetchone()
        if not e:
            continue
        out.append({"id": e["id"], "code": e["code"], "name": e["name"],
                    "forms": db.execute("SELECT COUNT(*) FROM cs_forms WHERE equipment_id=?", (eid,)).fetchone()[0],
                    "submissions": db.execute("""SELECT COUNT(*) FROM cs_submissions WHERE equipment_id=? OR form_id IN
                                                 (SELECT id FROM cs_forms WHERE equipment_id=?)""", (eid, eid)).fetchone()[0]})
    return out


def delete_equipment(db, equipment_id: int, actor_id, delete_forms: bool = False) -> dict:
    """ลบเครื่องจักรถาวร
    delete_forms=True  → ลบแบบฟอร์มของเครื่องพร้อมผลตรวจ (เหมือนลบแบบฟอร์ม)
    delete_forms=False → เก็บแบบฟอร์มไว้เป็นแบบฟอร์มที่ไม่ผูกเครื่อง (อยู่พื้นที่เดิม) ผลตรวจเดิมยังอยู่
    """
    e = db.execute("SELECT id, code, name, factory_id, area_id FROM equipment WHERE id=?", (equipment_id,)).fetchone()
    if not e:
        raise ValidationError("ไม่พบเครื่องจักร")
    files, forms_deleted = [], 0
    form_ids = [r[0] for r in db.execute("SELECT id FROM cs_forms WHERE equipment_id=?", (equipment_id,))]
    if delete_forms:
        for fid in form_ids:
            files += delete_form(db, fid, actor_id)["files"]
            forms_deleted += 1
    else:
        db.execute("UPDATE cs_forms SET equipment_id=NULL, factory_id=?, area_id=?, updated_at=? WHERE equipment_id=?",
                   (e["factory_id"], e["area_id"], ts(), equipment_id))
    for table in ("cs_submissions", "cs_alerts", "cs_actions"):
        db.execute(f"UPDATE {table} SET equipment_id=NULL WHERE equipment_id=?", (equipment_id,))
    db.execute("DELETE FROM cs_silences WHERE equipment_id=?", (equipment_id,))
    db.execute("DELETE FROM equipment WHERE id=?", (equipment_id,))
    audit(db, actor_id, "delete", "equipment", equipment_id,
          before={"code": e["code"], "name": e["name"], "forms": len(form_ids), "forms_deleted": forms_deleted})
    return {"code": e["code"], "files": files, "forms_kept": 0 if delete_forms else len(form_ids),
            "forms_deleted": forms_deleted}


def remove_upload_files(upload_dir: str, rel_paths: list[str]) -> None:
    """ลบไฟล์รูปหลัง commit สำเร็จ (เฉพาะไฟล์ในโฟลเดอร์ uploads)"""
    import os
    root = os.path.abspath(upload_dir)
    for rel in rel_paths:
        path = os.path.abspath(os.path.join(root, rel or ""))
        if rel and path.startswith(root + os.sep) and os.path.isfile(path):
            try:
                os.remove(path)
            except OSError:
                pass
