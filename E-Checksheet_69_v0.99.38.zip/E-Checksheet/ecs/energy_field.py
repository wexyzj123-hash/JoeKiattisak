"""ecs/energy_field.py — Energy Data v0.64: จดมิเตอร์หน้างาน (มือถือ · ออฟไลน์ · QR · รูปหน้าปัด · SCADA)

  en_meters     + qr_token · equipment_id (ผูกเครื่อง/ตู้ใน E-Check → เปิดใบแจ้งซ่อม UT-CMMS) · scada_source_id · digits · ocr_box
  en_readings   + read_at (เวลาอ่านจริง) · note · photo · client_uuid
  en_skips      อ่านไม่ได้ + เหตุผล (มิเตอร์เสีย / เข้าไม่ถึง / เครื่องหยุด / มีงานซ่อม / อื่น ๆ)
  en_swaps      เปลี่ยนมิเตอร์: เลขสุดท้ายตัวเก่า + เลขเริ่มตัวใหม่ (+ CT ใหม่) → หน่วยของวันนั้นคำนวณถูกเอง
  en_client     กันส่งซ้ำจากคิวออฟไลน์ (client_uuid → ผลลัพธ์)

ตรวจค่าก่อนบันทึก (ทั้งในเครื่องและที่เซิร์ฟเวอร์):
  - น้อยกว่าครั้งก่อน → ผิด (เสนอ “มิเตอร์วนรอบ” ถ้าเข้ากับจำนวนหลัก หรือ “เปลี่ยนมิเตอร์”)
  - จำนวนหลักไม่ตรงครั้งก่อน → เตือน (กรอกตกหลัก/เกินหลัก)
  - นอกช่วงที่ควรเป็น (จากการใช้ต่อวันย้อนหลัง) → เตือน · ค่าผิดปกติต้องมีหมายเหตุ และรูปหน้าปัดตามที่ตั้งค่า
"""
from __future__ import annotations

import json
import os
import secrets
import statistics
import uuid as _uuid
from datetime import date, datetime, timedelta

from . import services as S
from .services import ts

SKIP_REASONS = {
    "broken": "มิเตอร์เสีย / จอดับ",
    "no_access": "เข้าไม่ถึง / ถูกล็อก",
    "stopped": "เครื่อง/ไลน์หยุด",
    "repair": "มีงานซ่อม / ปิดวงจร",
    "other": "อื่น ๆ",
}

DDL = """
CREATE TABLE IF NOT EXISTS en_skips (
    meter_id    INTEGER NOT NULL,
    day         TEXT NOT NULL,
    reason      TEXT NOT NULL,
    note        TEXT NOT NULL DEFAULT '',
    photo       TEXT NOT NULL DEFAULT '',
    user_id     INTEGER,
    wo_number   TEXT NOT NULL DEFAULT '',
    case_id     INTEGER,
    created_at  TEXT NOT NULL,
    PRIMARY KEY (meter_id, day)
);
CREATE TABLE IF NOT EXISTS en_swaps (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    meter_id    INTEGER NOT NULL,
    day         TEXT NOT NULL,
    old_final   REAL,
    new_start   REAL NOT NULL DEFAULT 0,
    new_value   REAL NOT NULL,
    old_mult    REAL NOT NULL DEFAULT 1,
    new_mult    REAL NOT NULL DEFAULT 1,
    usage       REAL,
    note        TEXT NOT NULL DEFAULT '',
    photo       TEXT NOT NULL DEFAULT '',
    user_id     INTEGER,
    created_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS en_client (
    uuid        TEXT PRIMARY KEY,
    result      TEXT NOT NULL,
    created_at  TEXT NOT NULL
);
"""

_COLS = {
    "en_meters": (("qr_token", "TEXT"), ("equipment_id", "INTEGER"), ("scada_source_id", "INTEGER"), ("digits", "INTEGER"),
                  ("ocr_box", "TEXT NOT NULL DEFAULT ''")),
    "en_readings": (("read_at", "TEXT"), ("note", "TEXT NOT NULL DEFAULT ''"), ("photo", "TEXT NOT NULL DEFAULT ''")),
}


def ensure_field(db) -> None:
    db.executescript(DDL)
    for table, cols in _COLS.items():
        have = {r[1] for r in db.execute(f"PRAGMA table_info({table})")}
        for name, typ in cols:
            if name not in have:
                db.execute(f"ALTER TABLE {table} ADD COLUMN {name} {typ}")
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_enm_qr ON en_meters(qr_token) WHERE qr_token IS NOT NULL")


# ───────────────────────── สิทธิ์ / ขอบเขต ─────────────────────────

def user_scope(db, uid) -> dict:
    """{role, factory_id (None = ทุกโรงงาน)} — ช่าง/หัวหน้างานที่ผูกโรงงาน เห็นเฉพาะมิเตอร์โรงงานตัวเอง"""
    u = db.execute("SELECT role, factory_id FROM users WHERE id=?", (uid,)).fetchone() if uid else None
    if not u:
        return {"role": "", "factory_id": None}
    return {"role": u["role"], "factory_id": None if u["role"] == "admin" else u["factory_id"]}


def can_touch(db, uid, m: dict) -> bool:
    sc = user_scope(db, uid)
    if sc["role"] not in ("admin", "supervisor", "technician"):
        return False
    return not sc["factory_id"] or not m.get("factory_id") or sc["factory_id"] == m["factory_id"]


def back_limit_ok(db, uid, day: str, cfg: dict) -> bool:
    """ช่างแก้ค่าที่มีอยู่แล้วย้อนหลังได้ไม่เกิน tech_back_days วัน (0 = ไม่จำกัด) · หัวหน้างาน/ผู้ดูแลไม่จำกัด"""
    lim = int(cfg.get("tech_back_days") or 0)
    if not lim or user_scope(db, uid)["role"] in ("admin", "supervisor"):
        return True
    return (S.now_dt().date() - date.fromisoformat(day)).days <= lim


# ───────────────────────── QR ─────────────────────────

def qr_token(db, mid: int) -> str:
    r = db.execute("SELECT qr_token FROM en_meters WHERE id=?", (mid,)).fetchone()
    if r and r[0]:
        return r[0]
    for _ in range(20):
        tok = "m" + secrets.token_urlsafe(6).replace("-", "x").replace("_", "y")
        try:
            db.execute("UPDATE en_meters SET qr_token=? WHERE id=?", (tok, mid))
            return tok
        except Exception:                                    # noqa: BLE001 — ชนกัน (ยากมาก) → สุ่มใหม่
            continue
    raise S.ValidationError("สร้างรหัส QR ไม่สำเร็จ")


def by_token(db, tok: str) -> dict | None:
    from . import energy as EN
    EN.ensure(db)
    r = db.execute("SELECT id FROM en_meters WHERE qr_token=?", (tok,)).fetchone()
    return EN.meter(db, r[0]) if r else None


# ───────────────────────── ค่าที่ควรเป็น + ตรวจค่า ─────────────────────────

def _int_digits(v) -> int:
    return len(str(int(abs(float(v))))) if v is not None else 0


def expect(db, m: dict, day: date) -> dict:
    """ค่าครั้งก่อน/ครั้งถัดไป + ช่วงเลขหน้าปัดที่ควรเป็นของวันนั้น"""
    d = day.isoformat()
    prev = db.execute("SELECT day, value FROM en_readings WHERE meter_id=? AND day<? ORDER BY day DESC LIMIT 1", (m["id"], d)).fetchone()
    nxt = db.execute("SELECT day, value FROM en_readings WHERE meter_id=? AND day>? ORDER BY day LIMIT 1", (m["id"], d)).fetchone()
    hist = db.execute("SELECT day, value FROM en_readings WHERE meter_id=? AND day<? ORDER BY day DESC LIMIT 22", (m["id"], d)).fetchall()[::-1]
    per = []
    for a, b in zip(hist, hist[1:]):
        gap = (date.fromisoformat(b[0]) - date.fromisoformat(a[0])).days or 1
        if b[1] >= a[1]:
            per.append((b[1] - a[1]) / gap)
    out = {"prev_day": prev[0] if prev else None, "prev": prev[1] if prev else None,
           "next_day": nxt[0] if nxt else None, "next": nxt[1] if nxt else None,
           "digits": int(m.get("digits") or 0) or (_int_digits(prev[1]) if prev else 0),
           "mult": m.get("multiplier") or 1, "typ": None, "lo": None, "hi": None, "days": None}
    if prev:
        days = max(1, (day - date.fromisoformat(prev[0])).days)
        out["days"] = days
        out["lo"] = prev[1]
        if len(per) >= 3:
            q = sorted(per)
            med = statistics.median(q)
            p90 = q[min(len(q) - 1, int(round(0.9 * (len(q) - 1))))]
            out["typ"] = round(med * (m.get("multiplier") or 1), 3)
            out["hi"] = round(prev[1] + max(p90 * 2.5, med * 3, 1.0) * days, 6)
    return out


def check(ex: dict, value: float) -> dict:
    """ระดับ ok / warn / bad + ข้อความ + หน่วยที่ใช้ + (ถ้าเข้าเค้า) หน่วยแบบมิเตอร์วนรอบ"""
    msgs, level = [], "ok"
    mult = ex.get("mult") or 1
    prev = ex.get("prev")
    u = None
    roll = None
    if prev is None:
        return {"level": "ok", "msgs": ["ค่าแรกของมิเตอร์นี้ — ยังคำนวณการใช้ไม่ได้"], "u": None, "rollover": None}
    if value < prev:
        level = "bad"
        msgs.append(f"น้อยกว่าครั้งก่อน ({prev:,.2f}) — กรอกผิด / มิเตอร์วนรอบ / เปลี่ยนมิเตอร์?")
        dg = ex.get("digits") or 0
        if dg:
            mod = 10 ** dg
            ru = (mod - prev + value)
            if 0 < ru and (ex.get("hi") is None or prev + ru <= ex["hi"] * 1.0 + 1e-9 or ru < mod * 0.02):
                roll = round(ru * mult, 4)
    else:
        u = round((value - prev) * mult, 4)
        if ex.get("next") is not None and value > ex["next"]:
            level = "bad"
            msgs.append(f"มากกว่าค่าวันถัดไป ({ex['next']:,.2f} วันที่ {ex['next_day'][8:]}/{ex['next_day'][5:7]})")
        if ex.get("hi") is not None and value > ex["hi"]:
            level = "warn" if level == "ok" else level
            msgs.append(f"สูงกว่าปกติ — ใช้ {u:,.2f} (ปกติ ~{ex['typ']:,.2f}/วัน)" if ex.get("typ") is not None else "สูงกว่าปกติ")
    dg = ex.get("digits") or 0
    if dg and _int_digits(value) != dg and not (value < prev and roll is not None):
        level = "warn" if level == "ok" else level
        msgs.append(f"จำนวนหลักไม่ตรง (เดิม {dg} หลัก · ใส่ {_int_digits(value)} หลัก) — ตกหลัก/เกินหลัก?")
    return {"level": level, "msgs": msgs, "u": u, "rollover": roll}


# ───────────────────────── รูป ─────────────────────────

def _store_photo(fs, upload_dir: str, max_bytes: int = 12 * 1024 * 1024) -> str:
    data = fs.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise S.ValidationError("รูปใหญ่เกิน 12 MB")
    if not data:
        raise S.ValidationError("ไฟล์รูปว่างเปล่า")
    from .imaging import ImageError, process
    try:
        data, ext = process(data)
    except ImageError as exc:
        raise S.ValidationError(str(exc)) from None
    now = S.now_dt()
    rel = f"energy/{now:%Y}/{now:%m}/{_uuid.uuid4().hex}.{ext}"
    full = os.path.join(upload_dir, *rel.split("/"))
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "wb") as fh:
        fh.write(data)
    return rel


def _num(v, label, allow_empty=False):
    s = str(v if v is not None else "").replace(",", "").strip()
    if s == "":
        if allow_empty:
            return None
        raise S.ValidationError(f"กรุณากรอก{label}")
    try:
        x = float(s)
    except ValueError:
        raise S.ValidationError(f"{label} ต้องเป็นตัวเลข") from None
    if x < 0:
        raise S.ValidationError(f"{label} ต้องไม่ติดลบ")
    return x


# ───────────────────────── บันทึกจากหน้างาน ─────────────────────────

def submit(db, payload: dict, files: dict, actor, upload_dir: str, app_config=None) -> dict:
    """type = read | skip | swap — ส่งซ้ำ (client_uuid เดิม) ได้ผลเดิม ไม่บันทึกซ้ำ"""
    from . import energy as EN
    from . import energy_ops as OPS
    EN.ensure(db)
    cu = str(payload.get("client_uuid") or "")[:64]
    if cu:
        r = db.execute("SELECT result FROM en_client WHERE uuid=?", (cu,)).fetchone()
        if r:
            return dict(json.loads(r[0]), duplicate=True)
    try:
        mid = int(payload.get("meter_id") or 0)
    except (TypeError, ValueError):
        mid = 0
    m = EN.meter(db, mid)
    if not m or not m["active"]:
        raise S.ValidationError("ไม่พบมิเตอร์ (อาจถูกปิดใช้งาน)")
    if not can_touch(db, actor, m):
        raise S.ValidationError("ไม่มีสิทธิ์บันทึกมิเตอร์ของโรงงานนี้")
    try:
        day = date.fromisoformat(str(payload.get("day") or "")[:10])
    except ValueError:
        raise S.ValidationError("วันที่ไม่ถูกต้อง") from None
    today = S.now_dt().date()
    if day > today:
        raise S.ValidationError("บันทึกค่าล่วงหน้าไม่ได้")
    cfg = EN.settings(db)
    typ = payload.get("type") or "read"
    note = str(payload.get("note") or "").strip()[:300]
    read_at = None
    if payload.get("read_at"):
        dt = S.parse_ts(str(payload.get("read_at")))
        if dt and dt.date() == day and dt <= S.now_dt() + timedelta(minutes=10):
            read_at = ts(dt)
    stamp = ts(S.now_dt())
    photo_key = str(payload.get("photo") or "")
    photo = ""
    if photo_key and photo_key in files:
        photo = _store_photo(files[photo_key], upload_dir)
    old = db.execute("SELECT value, u_override, src FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
    res: dict = {"ok": True, "type": typ, "meter_id": mid, "day": day.isoformat(), "label": EN.label(m)}

    if typ == "skip":
        reason = payload.get("reason")
        if reason not in SKIP_REASONS:
            raise S.ValidationError("เลือกเหตุผลที่อ่านไม่ได้")
        if reason == "other" and not note:
            raise S.ValidationError("ระบุรายละเอียดเหตุผล")
        if old:
            raise S.ValidationError("วันนี้มีค่าอ่านแล้ว — แก้ค่าแทนการแจ้งอ่านไม่ได้")
        wo = ""
        case_id = None
        if reason == "broken":
            case_id = OPS.open_case(db, {"rule": "fault", "severity": "warn", "title": f"มิเตอร์เสีย/อ่านไม่ได้ — {EN.label(m)}",
                                         "detail": f"แจ้งจากหน้างาน: {SKIP_REASONS[reason]}" + (f" · {note}" if note else ""),
                                         "meter_id": mid, "factory_id": m["factory_id"], "kind": m["kind"], "grp": m["grp"],
                                         "day": day.isoformat()}, actor)
            if payload.get("wo") and m.get("equipment_id") and app_config is not None:
                from . import cmms_wo
                if cmms_wo.available(app_config):
                    try:
                        r = cmms_wo.create_generic(db, app_config, m["equipment_id"], f"[Energy Data] มิเตอร์เสีย {EN.label(m)}",
                                                   f"มิเตอร์ {EN.label(m)} ({m['factory_name'] or ''} · {m['grp'] or ''}) อ่านค่าไม่ได้ "
                                                   f"วันที่ {day:%d/%m/%Y}\nเหตุผล: {SKIP_REASONS[reason]}" + (f"\n{note}" if note else ""),
                                                   actor, "high", ref=f"meter {mid}")
                        wo = r["wo_number"]
                    except S.ValidationError as exc:
                        res["wo_error"] = exc.errors[0]
        db.execute("""INSERT INTO en_skips(meter_id, day, reason, note, photo, user_id, wo_number, case_id, created_at)
                      VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(meter_id, day) DO UPDATE SET reason=excluded.reason, note=excluded.note,
                      photo=CASE WHEN excluded.photo<>'' THEN excluded.photo ELSE en_skips.photo END, user_id=excluded.user_id,
                      wo_number=CASE WHEN excluded.wo_number<>'' THEN excluded.wo_number ELSE en_skips.wo_number END,
                      case_id=COALESCE(excluded.case_id, en_skips.case_id), created_at=excluded.created_at""",
                   (mid, day.isoformat(), reason, note, photo, actor, wo, case_id, stamp))
        S.audit(db, actor, "energy_skip", "en_meters", mid, after={"day": day.isoformat(), "reason": reason, "note": note, "wo": wo})
        res.update(reason=reason, reason_th=SKIP_REASONS[reason], wo_number=wo, case_id=case_id)

    elif typ == "swap":
        if not note:
            raise S.ValidationError("ระบุเหตุผล/รายละเอียดการเปลี่ยนมิเตอร์")
        if cfg.get("photo_rule", 1) >= 1 and not photo:
            raise S.ValidationError("เปลี่ยนมิเตอร์ต้องถ่ายรูปหน้าปัดมิเตอร์ใหม่")
        sw = payload.get("swap") or {}
        ex = expect(db, m, day)
        old_final = _num(sw.get("old_final"), "เลขสุดท้ายของมิเตอร์เก่า", allow_empty=ex["prev"] is None)
        new_start = _num(sw.get("new_start"), "เลขเริ่มของมิเตอร์ใหม่", allow_empty=True) or 0.0
        new_value = _num(sw.get("new_value"), "เลขปัจจุบันของมิเตอร์ใหม่", allow_empty=True)
        new_value = new_start if new_value is None else new_value
        new_mult = _num(sw.get("new_mult"), "CT ratio ใหม่", allow_empty=True) or (m["multiplier"] or 1)
        if new_value < new_start:
            raise S.ValidationError("เลขปัจจุบันของมิเตอร์ใหม่ต้องไม่น้อยกว่าเลขเริ่ม")
        if ex["prev"] is not None and old_final is not None and old_final < ex["prev"]:
            raise S.ValidationError(f"เลขสุดท้ายของมิเตอร์เก่าต้องไม่น้อยกว่าค่าครั้งก่อน ({ex['prev']:,.2f})")
        old_mult = m["multiplier"] or 1
        u = (((old_final - ex["prev"]) * old_mult) if ex["prev"] is not None and old_final is not None else 0.0) \
            + (new_value - new_start) * new_mult
        u = round(u, 4)
        db.execute("""INSERT INTO en_readings(meter_id, day, value, u_override, src, user_id, updated_at, read_at, note, photo)
                      VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(meter_id, day) DO UPDATE SET value=excluded.value,
                      u_override=excluded.u_override, src=excluded.src, user_id=excluded.user_id, updated_at=excluded.updated_at,
                      read_at=excluded.read_at, note=excluded.note, photo=excluded.photo""",
                   (mid, day.isoformat(), new_value, u, "swap", actor, stamp, read_at or stamp, note, photo))
        db.execute("""INSERT INTO en_swaps(meter_id, day, old_final, new_start, new_value, old_mult, new_mult, usage, note, photo, user_id, created_at)
                      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                   (mid, day.isoformat(), old_final, new_start, new_value, old_mult, new_mult, u, note, photo, actor, stamp))
        if abs(new_mult - old_mult) > 1e-12:
            db.execute("UPDATE en_meters SET multiplier=? WHERE id=?", (new_mult, mid))
        db.execute("UPDATE en_meters SET digits=NULL WHERE id=?", (mid,))
        db.execute("""INSERT INTO en_fix_log(meter_id, day, field, old_value, new_value, reason, user_id, created_at)
                      VALUES (?,?,?,?,?,?,?,?)""", (mid, day.isoformat(), "swap", old[0] if old else None, new_value,
                                                    f"เปลี่ยนมิเตอร์: เก่า {old_final if old_final is not None else '–'} · ใหม่เริ่ม {new_start:g}"
                                                    f"{' · CT ' + format(new_mult, 'g') if abs(new_mult - old_mult) > 1e-12 else ''} · {note}"[:300],
                                                    actor, stamp))
        db.execute("DELETE FROM en_skips WHERE meter_id=? AND day=?", (mid, day.isoformat()))
        S.audit(db, actor, "energy_swap", "en_meters", mid, after={"day": day.isoformat(), "old_final": old_final, "new_start": new_start,
                                                                   "new_value": new_value, "new_mult": new_mult, "usage": u})
        res.update(u=u, value=new_value)

    else:
        value = _num(payload.get("value"), "เลขหน้าปัด")
        if old and not back_limit_ok(db, actor, day.isoformat(), cfg):
            raise S.ValidationError(f"แก้ค่าย้อนหลังได้ไม่เกิน {int(cfg['tech_back_days'])} วัน — แจ้งหัวหน้างาน")
        ex = expect(db, m, day)
        chk = check(ex, value)
        rollover = bool(payload.get("rollover")) and chk["rollover"] is not None
        if chk["level"] != "ok" and not payload.get("confirm") and not rollover:
            raise S.ValidationError(["ค่าผิดปกติ: " + " · ".join(chk["msgs"]) + " — ตรวจเลขอีกครั้ง หรือยืนยันพร้อมหมายเหตุ"])
        if chk["level"] != "ok" and not rollover and not note:
            raise S.ValidationError("ค่าผิดปกติต้องใส่หมายเหตุ")
        rule = int(cfg.get("photo_rule", 1))
        if payload.get("form_id"):
            fi = db.execute("SELECT photo FROM en_form_items WHERE form_id=? AND meter_id=? AND type='meter'",
                            (payload.get("form_id"), mid)).fetchone()
            if fi and fi[0]:
                rule = 2                                   # แบบฟอร์มกำหนดให้ถ่ายรูปทุกครั้ง
        if not photo and (rule >= 2 or (rule >= 1 and (chk["level"] != "ok" or rollover))):
            keep = db.execute("SELECT photo FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
            if not (keep and keep[0]):
                raise S.ValidationError("ต้องถ่ายรูปหน้าปัด" + (" (ค่าผิดปกติ)" if rule == 1 else ""))
        changed = bool(old) and abs(old[0] - value) > 1e-9
        if changed and not note:
            raise S.ValidationError("แก้ค่าที่บันทึกไว้แล้วต้องระบุเหตุผลในหมายเหตุ")
        u_ovr = chk["rollover"] if rollover else (old[1] if old and not changed and old[2] in ("fix", "swap") else None)
        db.execute("""INSERT INTO en_readings(meter_id, day, value, u_override, src, user_id, updated_at, read_at, note, photo)
                      VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(meter_id, day) DO UPDATE SET value=excluded.value,
                      u_override=excluded.u_override, src=excluded.src, user_id=excluded.user_id, updated_at=excluded.updated_at,
                      read_at=COALESCE(excluded.read_at, en_readings.read_at), note=excluded.note,
                      photo=CASE WHEN excluded.photo<>'' THEN excluded.photo ELSE en_readings.photo END""",
                   (mid, day.isoformat(), value, u_ovr, "mobile" if payload.get("from") == "m" else "web", actor, stamp,
                    read_at or (stamp if day == today else None), note, photo))
        if changed:
            db.execute("""INSERT INTO en_fix_log(meter_id, day, field, old_value, new_value, reason, user_id, created_at)
                          VALUES (?,?,?,?,?,?,?,?)""", (mid, day.isoformat(), "value", old[0], value, note, actor, stamp))
        if rollover:
            db.execute("""INSERT INTO en_fix_log(meter_id, day, field, old_value, new_value, reason, user_id, created_at)
                          VALUES (?,?,?,?,?,?,?,?)""", (mid, day.isoformat(), "u_override", None, chk["rollover"],
                                                        "มิเตอร์วนรอบ" + (f" · {note}" if note else ""), actor, stamp))
        db.execute("DELETE FROM en_skips WHERE meter_id=? AND day=?", (mid, day.isoformat()))
        if changed or chk["level"] != "ok":
            S.audit(db, actor, "energy_read", "en_readings", mid, before={"day": day.isoformat(), "value": old[0] if old else None},
                    after={"day": day.isoformat(), "value": value, "level": chk["level"], "note": note, "rollover": rollover})
        res.update(value=value, u=chk["rollover"] if rollover else chk["u"], level=chk["level"], msgs=chk["msgs"], changed=changed)
    if photo:
        res["photo"] = photo
    if cu:
        db.execute("INSERT OR REPLACE INTO en_client(uuid, result, created_at) VALUES (?,?,?)", (cu, json.dumps(res, ensure_ascii=False), stamp))
        db.execute("DELETE FROM en_client WHERE created_at<?", (ts(S.now_dt() - timedelta(days=30)),))
    return res


def save_ocr_box(db, mid: int, box, actor) -> None:
    try:
        b = [round(float(x), 4) for x in (box or [])][:4]
    except (TypeError, ValueError):
        return
    if len(b) == 4 and all(0 <= x <= 1 for x in b) and b[2] > 0.02 and b[3] > 0.02:
        db.execute("UPDATE en_meters SET ocr_box=? WHERE id=?", (json.dumps(b), mid))


# ───────────────────────── แพ็กข้อมูลสำหรับมือถือ (ใช้ออฟไลน์ได้) ─────────────────────────

def pack(db, uid, factory_id: int | None = None) -> dict:
    from . import energy as EN
    EN.ensure(db)
    cfg = EN.settings(db)
    sc = user_scope(db, uid)
    fid = sc["factory_id"] or factory_id
    ms = EN.meters(db, fid)
    today = S.now_dt().date()
    d7 = (today - timedelta(days=7)).isoformat()
    out = []
    for m in ms:
        tok = m.get("qr_token") or qr_token(db, m["id"])
        ex = expect(db, m, today)
        cur = db.execute("""SELECT r.value, r.read_at, r.photo, r.note, r.src, u.name FROM en_readings r LEFT JOIN users u ON u.id=r.user_id
                            WHERE r.meter_id=? AND r.day=?""", (m["id"], today.isoformat())).fetchone()
        sk = db.execute("SELECT reason, note, wo_number FROM en_skips WHERE meter_id=? AND day=?", (m["id"], today.isoformat())).fetchone()
        hist = [{"day": r[0], "v": r[1], "src": r[2], "note": r[3], "photo": r[4]} for r in db.execute(
            "SELECT day, value, src, note, photo FROM en_readings WHERE meter_id=? AND day>=? AND day<? ORDER BY day DESC",
            (m["id"], d7, today.isoformat()))]
        skips = {r[0]: r[1] for r in db.execute("SELECT day, reason FROM en_skips WHERE meter_id=? AND day>=?", (m["id"], d7))}
        try:
            box = json.loads(m.get("ocr_box") or "null")
        except ValueError:
            box = None
        out.append({"id": m["id"], "label": EN.label(m), "code": m["code"], "name": m["name"], "kind": m["kind"], "unit": m["unit"],
                    "grp": m["grp"], "line": m.get("line") or "", "project": m.get("project_name") or "", "loc": m.get("location") or "", "factory_id": m["factory_id"], "factory": m["factory_name"] or "",
                    "mult": m["multiplier"] or 1, "main": m["is_main"], "auto": bool(m.get("scada_source_id") and m.get("scada_tag")),
                    "tok": tok, "box": box, "has_eq": bool(m.get("equipment_id")), "ex": ex,
                    "today": ({"v": cur[0], "at": cur[1], "photo": cur[2], "note": cur[3], "src": cur[4], "by": cur[5]} if cur else None),
                    "skip": ({"reason": sk[0], "note": sk[1], "wo": sk[2]} if sk else None), "hist": hist, "skips": skips})
    from . import masterdata as M
    facs = [f for f in M.list_factories(db) if not sc["factory_id"] or f["id"] == sc["factory_id"]]
    return {"today": today.isoformat(), "now": ts(S.now_dt()), "factory_id": fid, "factories": facs, "meters": out,
            "kinds": {k: v for k, v in EN.KINDS.items()}, "kind_order": list(EN.KIND_ORDER), "reasons": SKIP_REASONS, "reason_order": list(SKIP_REASONS),
            "cfg": {"photo_rule": int(cfg["photo_rule"]), "tech_back_days": int(cfg["tech_back_days"]), "ocr": int(cfg["ocr"])},
            "role": sc["role"], "lead": sc["role"] in ("admin", "supervisor"), "forms": _forms_pack(db, uid)}


def _forms_pack(db, uid) -> list[dict]:
    from .energy_forms import for_pack
    return for_pack(db, uid)


# ───────────────────────── SCADA → ค่าอ่านรายวันอัตโนมัติ ─────────────────────────

INTERP_MARK = "≈"                                         # v0.99.37 หมายเหตุค่าประมาณ (เส้นตรงระหว่างค่าก่อน/หลังเวลาอ่าน)


def scada_pick(db, source: dict, rows, only_meter: int | set | None = None) -> dict:
    """เลือกค่าต่อ (มิเตอร์, วัน): ค่าที่ใกล้เวลาอ่านที่ตั้งไว้ที่สุดภายใน ± ช่วงที่ยอมให้ → {(mid, day): (ห่างกี่นาที, เวลา, ค่า×ตัวคูณ+ค่าบวก)}"""
    from . import energy as EN
    EN.ensure(db)
    q = "SELECT id, scada_tag FROM en_meters WHERE scada_source_id=? AND scada_tag<>'' AND active=1"
    a = [source["id"]]
    if only_meter:                                       # มิเตอร์เดียว (int) หรือหลายตัว (set/list) — v0.99.37
        ids = sorted(only_meter) if isinstance(only_meter, (set, list, tuple)) else [only_meter]
        q += f" AND id IN ({','.join('?' * len(ids))})"
        a += ids
    tagmap: dict[str, list[int]] = {}
    for r in db.execute(q, a):
        tagmap.setdefault(r[1].strip(), []).append(r[0])
    if not tagmap:
        return {}
    sc = {r[0]: (r[1], r[2], r[3], r[4]) for r in db.execute(
        "SELECT tag, scale, add_offset, valid_min, valid_max FROM en_source_tags WHERE source_id=?", (source["id"],))}
    cfg = EN.settings(db)
    hh, mm, win = int(cfg["scada_hh"]), int(cfg["scada_mm"]), int(cfg["scada_window"])
    best: dict[tuple[int, str], tuple[float, datetime, float]] = {}
    future = S.now_dt() + timedelta(minutes=10)           # v0.99.37 เวลาในอนาคต (นาฬิกา SQL/โซนเวลาเพี้ยน) → ไม่ใช้ ไม่ให้เกิดค่าอ่านล่วงหน้า
    for tag, dt, val in rows:
        mids = tagmap.get(str(tag).strip())
        if not mids or val is None or val < 0 or dt > future:
            continue
        target = dt.replace(hour=hh, minute=mm, second=0, microsecond=0)
        dist = abs((dt - target).total_seconds()) / 60
        if dist > win:
            continue
        k_, o_, lo_, hi_ = sc.get(str(tag).strip(), (1.0, 0.0, None, None))
        v = float(val) * (k_ or 1.0) + (o_ or 0.0)
        if (lo_ is not None and v < lo_) or (hi_ is not None and v > hi_):     # v0.77 นอกช่วงที่เป็นไปได้ → ไม่ใช้
            continue
        for mid in mids:
            k = (mid, target.date().isoformat())
            if k not in best or dist < best[k][0]:
                best[k] = (dist, dt, v)
    return best


def scada_ingest(db, source: dict, rows, only_meter: int | set | None = None) -> int:
    """ค่าจาก Tag ที่ผูกกับมิเตอร์ → ค่าอ่านของวัน ณ เวลาอ่านที่ตั้งไว้ (ใกล้ที่สุดภายใน ± ช่วงที่ตั้ง) — ไม่ทับค่าที่ช่างแก้ไว้"""
    from . import energy as EN
    best = scada_pick(db, source, rows, only_meter)
    if not best:
        return 0
    cfg = EN.settings(db)
    hh, mm = int(cfg["scada_hh"]), int(cfg["scada_mm"])
    n = 0
    stamp = ts(S.now_dt())
    for (mid, day), (dist, dt, val) in best.items():
        if db.execute("SELECT 1 FROM en_skips WHERE meter_id=? AND day=? AND reason='scada_void'", (mid, day)).fetchone():
            continue                                    # v0.74 ผู้ดูแลยกเลิกค่า SCADA ของวันนี้ → ไม่ลงซ้ำ
        old = db.execute("SELECT value, src, read_at, note FROM en_readings WHERE meter_id=? AND day=?", (mid, day)).fetchone()
        if old and old[1] in ("fix", "swap"):
            continue
        if old and old[1] == "scada" and old[2] and not str(old[3] or "").startswith(INTERP_MARK):   # ค่าประมาณ → ค่าจริงแทนได้เสมอ
            od = S.parse_ts(old[2])
            tgt = datetime.fromisoformat(day).replace(hour=hh, minute=mm)
            if od and abs((od - tgt).total_seconds()) / 60 <= dist and abs(old[0] - val) < 1e-9:
                continue
            if od and abs((od - tgt).total_seconds()) / 60 < dist:
                continue
        db.execute("""INSERT INTO en_readings(meter_id, day, value, src, updated_at, read_at) VALUES (?,?,?,?,?,?)
                      ON CONFLICT(meter_id, day) DO UPDATE SET value=excluded.value, src=excluded.src, u_override=NULL,
                      updated_at=excluded.updated_at, read_at=excluded.read_at,
                      note=CASE WHEN COALESCE(en_readings.note, '') LIKE ? THEN '' ELSE en_readings.note END""",
                   (mid, day, val, "scada", stamp, ts(dt), INTERP_MARK + "%"))
        db.execute("DELETE FROM en_skips WHERE meter_id=? AND day=?", (mid, day))
        n += 1
    return n


def scada_backfill(db, mid: int, days: int = 31) -> dict:
    """ดึงค่าจากแหล่ง SCADA ย้อนหลังให้มิเตอร์ตัวเดียว (ใช้ตอนผูก Tag ครั้งแรก)"""
    from . import energy as EN
    from . import energy_src as ES
    m = EN.meter(db, mid)
    if not m or not m.get("scada_source_id") or not m.get("scada_tag"):
        raise S.ValidationError("มิเตอร์นี้ยังไม่ได้ผูกแหล่ง SCADA และ Tag")
    src = ES.get_source(db, m["scada_source_id"])
    if not src:
        raise S.ValidationError("ไม่พบแหล่งข้อมูล SCADA")
    if src["kind"] == "csv":
        raise S.ValidationError("แหล่ง CSV ดึงย้อนหลังไม่ได้ — ระบบอ่านไฟล์ใหม่ให้อัตโนมัติ")
    # v0.99.37 ทีละวัน เฉพาะ Tag ของมิเตอร์นี้ ช่วงเวลาอ่าน (เดิมดึงทุก Tag ทั้งก้อน → ถูกตัดที่ 50,000 แถว วันหลัง ๆ หาย)
    now = S.now_dt()
    r = ES.sync_days(db, src, (now - timedelta(days=max(1, min(int(days), 400)) - 1)).date(), now.date(), now, meter_ids={mid})
    return {"rows": r["days"], "days": r["readings"], "interp": r["interp"], "no_data": r["no_data"]}


def scada_sources(db) -> list[dict]:
    try:
        return [dict(r) for r in db.execute("SELECT id, name, kind, active FROM en_sources ORDER BY active DESC, name")]
    except Exception:                                    # noqa: BLE001
        return []


def scada_tags(db, sid: int) -> list[str]:
    return [r[0] for r in db.execute("SELECT tag FROM en_source_tags WHERE source_id=? ORDER BY tag LIMIT 2000", (sid,))]
