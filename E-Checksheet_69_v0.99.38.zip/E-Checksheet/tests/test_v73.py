"""v0.73: ดึงค่า SCADA อัตโนมัติให้ครบ — ข้อมูลมาช้า (late data) · ข้อมูลมาก (ดึงต่อจนทัน) · เติมช่องที่ขาดเอง · ดึงเฉพาะ Tag ที่จับคู่"""
import sqlite3
from datetime import datetime, time, timedelta

from conftest import login, uid

from ecs import connectors as CN
from ecs import services as S
from ecs import srcmap as SM
from ecs.services import ts


def _day():
    return (S.now_dt() - timedelta(days=1)).date()


def _rows(day, tag="OIL", start=6 * 60, end=23 * 60, step=10, skip=None):
    out = []
    for m in range(start, end, step):
        if skip and skip[0] <= m < skip[1]:
            continue
        t = datetime.combine(day, time(m // 60, m % 60))
        out.append((tag, ts(t), round(m // 60 + (m % 60) / 100, 2)))
    return out


def _hist(path, rows, reset=False):
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE IF NOT EXISTS h (tag TEXT, ts TEXT, value REAL)")
    if reset:
        con.execute("DELETE FROM h")
    con.executemany("INSERT INTO h VALUES (?,?,?)", rows)
    con.commit()
    con.close()


def _setup(db, form, path):
    fid = form["form_id"]
    S.create_schedule(db, fid, {"freq_type": "shift", "times": "08:30,20:30", "window_min": 240}, uid(db, "t_admin"))
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    db.execute("INSERT INTO cs_meta(key, value) VALUES('rounds_start', ?)", (ts(S.now_dt() - timedelta(days=3)),))
    S.generate_rounds(db)
    sid = CN.save_source(db, {"name": "SCADA", "kind": "sqlite", "bucket_min": 60, "agg": "last", "prefill": "0",
                              "config": {"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                         "backfill_days": 3}}, None)
    CN.save_mapping(db, sid, [{"tag": "OIL", "target": f"{fid}:oil"}], None)
    db.commit()
    return sid


def _slots(db, day):
    return [r[0] for r in db.execute("""SELECT s.finished_at FROM cs_submissions s WHERE s.source='auto' AND s.finished_at LIKE ?
                                        ORDER BY s.finished_at""", (f"{day}%",))]


def _at(day, h, m=0):
    return datetime.combine(day, time(h, m))


def test_late_data_is_picked_up(app, db, published_form, tmp_path):
    """Historian เขียนค่าช่วง 20:00–20:50 ช้า (เวลาเดิม) หลังรอบดึงผ่านไปแล้ว → รอบถัดไปต้องลงช่อง 20:30 ได้เอง ไม่ต้องกดลงค่าใหม่"""
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day, skip=(19 * 60 + 40, 21 * 60 + 20)) + _rows(day, tag="OTHER"))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 23))
    db.commit()
    assert _slots(db, day) == [f"{day} 08:30:00"]
    st = SM.slot_status(db, sid, day, now=_at(day, 23))
    assert [x["state"] for f in st for x in f["slots"]] == ["done", "missing"]
    _hist(path, [r for r in _rows(day) if r[1][11:13] in ("19", "20", "21")])     # ค่าที่มาช้า
    CN.run_source(db, sid, now=_at(day, 23, 20))
    db.commit()
    assert _slots(db, day) == [f"{day} 08:30:00", f"{day} 20:30:00"]


def test_overlap_rereads_recent_late_rows(app, db, published_form, tmp_path):
    """ค่าที่มาช้าภายในช่วงย้อนทับ (late_min) ถูกอ่านซ้ำในรอบปกติ — ไม่ต้องรอการเติมช่อง"""
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day, end=21 * 60, skip=(19 * 60 + 40, 21 * 60)) + _rows(day, tag="OTHER", end=21 * 60 + 30))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 21, 5))
    db.commit()
    assert _slots(db, day) == [f"{day} 08:30:00"]
    _hist(path, [r for r in _rows(day, end=21 * 60) if r[1][11:13] in ("19", "20")])
    CN.run_source(db, sid, now=_at(day, 21, 10))                        # ยังไม่ถึงรอบเติมช่อง (15 นาที) — ได้จากการย้อนทับ
    db.commit()
    assert _slots(db, day) == [f"{day} 08:30:00", f"{day} 20:30:00"]


def test_large_volume_catches_up(app, db, published_form, tmp_path, monkeypatch):
    """ข้อมูลมากเกินรอบละ MAX_ROWS → ดึงเฉพาะ Tag ที่จับคู่ และดึงต่อเป็นชุดจนทัน"""
    day = _day()
    path = str(tmp_path / "h.db")
    noise = [r for i in range(40) for r in _rows(day, tag=f"N{i}", step=5)]
    _hist(path, _rows(day) + noise)
    sid = _setup(db, published_form, path)
    monkeypatch.setattr(CN, "MAX_ROWS", 60)
    for i in range(5):
        CN.run_source(db, sid, now=_at(day, 23, i))
    db.commit()
    assert _slots(db, day) == [f"{day} 08:30:00", f"{day} 20:30:00"]
    assert db.execute("SELECT COUNT(*) FROM cs_source_values WHERE source_id=? AND tag LIKE 'N%'", (sid,)).fetchone()[0] == 0


def test_truncated_run_schedules_next_now(app, db, published_form, tmp_path, monkeypatch):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day, step=1))
    sid = _setup(db, published_form, path)
    monkeypatch.setattr(CN, "MAX_ROWS", 100)
    now = _at(day, 23)
    res = CN.run_source(db, sid, now=now)
    src = CN.get_source(db, sid)
    assert res["ok"] and "ดึงต่อ" in res["message"] and src["catchup"] == 1
    assert src["next_run_at"] <= ts(now)
    for i in range(10):
        CN.run_source(db, sid, now=now + timedelta(minutes=i + 1))
    db.commit()
    assert CN.get_source(db, sid)["catchup"] == 0
    assert _slots(db, day) == [f"{day} 08:30:00", f"{day} 20:30:00"]


def test_gap_heal_and_status(app, db, published_form, tmp_path):
    """ค่าดิบช่วง 20:30 หายจากที่เก็บไว้ (เช่น ระบบดับ) → รอบถัดไปเติมช่องที่ขาดเองโดยดึงย้อนหลังเฉพาะช่วงนั้น"""
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid, now=_at(day, 23))
    db.commit()
    from ecs import submissions as SUB
    ids = [r[0] for r in db.execute("SELECT id FROM cs_submissions WHERE client_uuid LIKE ? AND finished_at LIKE ?",
                                    (f"src{sid}:%", f"{day} 20:30%"))]
    SUB.delete_submissions(db, ids, uid(db, "t_admin"), "ทดสอบ")
    db.execute("DELETE FROM cs_source_values WHERE source_id=? AND ts >= ? AND ts <= ?", (sid, f"{day} 19:50", f"{day} 21:10"))
    db.commit()
    st = SM.slot_status(db, sid, day, now=_at(day, 23, 30))
    s2030 = [s for f in st for s in f["slots"] if s["t"] == "20:30"]
    assert s2030 and s2030[0]["state"] == "missing"
    assert SM.health(db, sid, _at(day, 23, 30))["count"]["missing"] >= 1
    CN.run_source(db, sid, now=_at(day, 23, 30))
    db.commit()
    assert f"{day} 20:30:00" in _slots(db, day)
    st = SM.slot_status(db, sid, day, now=_at(day, 23, 30))
    assert all(s["state"] == "done" for f in st for s in f["slots"])


def test_tag_filter_sql_and_preview_tags(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day) + _rows(day, tag="OTHER"))
    sid = _setup(db, published_form, path)
    src = CN.get_source(db, sid)
    rows, _k, _b = CN.fetch(db, src, _at(day, 23), tags=["OIL"])
    assert rows and {r[0] for r in rows} == {"OIL"}
    rows, _k, _b = CN.fetch(db, src, _at(day, 23), tags=["OIL"], since=_at(day, 20), until=_at(day, 21))
    assert rows[0][1] > _at(day, 20) and rows[-1][1] <= _at(day, 21)
    db.execute("DELETE FROM cs_source_tags WHERE source_id=? AND tag='OTHER'", (sid,))
    CN.preview(db, sid)
    assert db.execute("SELECT 1 FROM cs_source_tags WHERE source_id=? AND tag='OTHER'", (sid,)).fetchone()
    assert CN._wrap_tags("WITH x AS (SELECT 1) SELECT * FROM x", 2) is None


def test_status_pages(app, db, published_form, tmp_path):
    day = _day()
    path = str(tmp_path / "h.db")
    _hist(path, _rows(day))
    sid = _setup(db, published_form, path)
    CN.run_source(db, sid)
    db.commit()
    c = app.test_client()
    tok = login(c, "t_admin")
    page = c.get(f"/admin/sources/{sid}?sday={day}").get_data(as_text=True)
    assert "สถานะการลงค่าอัตโนมัติ" in page
    lst = c.get("/admin/sources").get_data(as_text=True)
    assert "ลงครบ" in lst or "ขาด" in lst
    r = c.post(f"/admin/sources/{sid}/heal", data={"csrf_token": tok})
    assert r.status_code in (302, 303)


# ───────────────────────── Energy Data ─────────────────────────

def test_energy_late_and_heal(app, db, client, tmp_path):
    """Energy: ค่าช่วงเวลาอ่าน (08:00) มาช้า → เติมเอง · ดึงเฉพาะ Tag ที่จับคู่ · หน้าสถานะ"""
    import json
    from ecs import energy as EN
    from ecs import energy_src as ES
    f1 = app.config["F1"]
    day = _day()
    path = str(tmp_path / "e.db")
    rows = [("KWH1", ts(datetime.combine(day, time(h, m))), 1000 + h * 10 + m / 10) for h in range(0, 23) for m in (0, 30)
            if not (6 <= h < 10)]
    rows += [("NOISE", r[1], 1) for r in rows]
    _hist(path, rows)
    sid = ES.save_source(db, {"name": "E", "kind": "sqlite", "active": "1",
                              "config": json.dumps({"path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts",
                                                    "backfill_days": 3})}, None)
    mid = EN.save_meter(db, None, {"factory_id": f1, "kind": "elec", "code": "K1", "name": "K1", "scada_source_id": str(sid),
                                   "scada_tag": "KWH1"}, None)
    ES.run_source(db, sid, now=_at(day, 23))
    st = ES.day_status(db, sid, day, now=_at(day, 23))
    # v0.99.37: ไม่มีค่าในช่วงเวลาอ่าน (Logger ดับ 06–10 น.) → ประมาณจากค่าก่อน/หลัง (หมายเหตุ ≈) แทนการปล่อยขาด
    assert st["count"]["missing"] == 0
    r = db.execute("SELECT value, note FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
    assert r and r[1].startswith("≈") and abs(r[0] - (1053 + (1100 - 1053) * 150 / 270)) < 1e-6   # 05:30=1053 → 10:00=1100 ที่ 08:00
    assert db.execute("SELECT COUNT(*) FROM en_source_tags WHERE source_id=? AND tag='NOISE'", (sid,)).fetchone()[0] == 0
    _hist(path, [("KWH1", ts(datetime.combine(day, time(8, 5))), 5555.0)])          # ค่าเวลาอ่านมาช้า
    ES.run_source(db, sid, now=_at(day, 23, 20))                                   # ค่าจริงมาช้า → แทนค่าประมาณ
    v = db.execute("SELECT value, src FROM en_readings WHERE meter_id=? AND day=?", (mid, day.isoformat())).fetchone()
    assert v and v[0] == 5555.0 and v[1] == "scada"
    assert ES.day_status(db, sid, day, now=_at(day, 23, 20))["count"]["scada"] == 1
    db.commit()
    tok = login(client, "t_admin")
    assert "สถานะค่าอ่านรายวันจาก SCADA" in client.get(f"/energy/sources/{sid}?sday={day}").get_data(as_text=True)
    assert client.get("/energy/sources").status_code == 200
    assert client.post(f"/energy/sources/{sid}/heal", data={"csrf_token": tok}).status_code in (302, 303)
