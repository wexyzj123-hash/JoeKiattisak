"""v0.99.37: Energy — ค่ารายวันจาก SQL ครบทุกวัน (ข้อมูลจำลองแบบโรงงานจริงใน _scada_sim.py)
· เติมย้อนหลังเองอัตโนมัติ 62 วัน (เดิม 2) · ดึงทีละวันเฉพาะ Tag ที่ขาด (ไม่ติดเพดาน 50,000 แถว)
· ไม่มีค่าในช่วงเวลาอ่าน → ประมาณแบบเส้นตรงจากค่าก่อน/หลัง (≈) และค่าจริงที่มาทีหลังแทนได้ · ไม่ใช้เวลาในอนาคต · หน้ามิเตอร์แสดงครบทุกวัน"""
import json
import sqlite3
from datetime import datetime, time, timedelta

from _scada_sim import build, value
from conftest import login
from ecs import energy as EN
from ecs import energy_field as EF
from ecs import energy_src as ES
from ecs import services as S


def _setup(app, db, tmp_path, tags=("KA", "KB", "KC"), days=60):
    now = S.now_dt()
    path = str(tmp_path / "scada.db")
    t0 = build(path, now, days=days)
    sid = ES.save_source(db, {"name": "SQL", "kind": "sqlite", "active": "1", "config": json.dumps({
        "path": path, "query": "SELECT tag, ts, value FROM h WHERE ts > ? ORDER BY ts", "backfill_days": 1})}, None)
    ms = {t: EN.save_meter(db, None, {"factory_id": app.config["F1"], "kind": "elec", "code": t, "name": t,
                                       "scada_source_id": str(sid), "scada_tag": t}, None) for t in tags}
    db.commit()
    return now, path, t0, sid, ms


def _due_days(now, t0):
    """วันที่ควรมีค่าอ่าน: ตั้งแต่วันแรกของข้อมูลถึงวันนี้ ที่เลยเวลาอ่าน 08:00 + 90 นาทีแล้ว"""
    out, d = [], t0.date()
    while d <= now.date():
        if now >= datetime.combine(d, time(9, 30)):
            out.append(d.isoformat())
        d += timedelta(days=1)
    return out


def _readings(db, mid):
    return {r[0]: (r[1], r[2] or "") for r in db.execute("SELECT day, value, note FROM en_readings WHERE meter_id=?", (mid,))}


def test_sql_history_fills_every_day_automatically(app, db, tmp_path):
    now, _p, t0, sid, ms = _setup(app, db, tmp_path)
    due = _due_days(now, t0)
    assert len(due) >= 60
    for k in range(7):                                              # รอบปกติ → ไล่เติมจนครบ (รอบละ ≤ 10 วัน: 61 วัน = 7 รอบ)
        ES.run_source(db, sid, now=now - timedelta(minutes=5) + timedelta(seconds=k))
        db.execute("UPDATE en_sources SET last_heal_at=NULL WHERE id=?", (sid,))
        db.commit()
    for tag, mid in ms.items():
        got = _readings(db, mid)
        want = due
        if tag == "KC" and (now - timedelta(minutes=5)).time() < time(10, 0):              # v0.99.38 KC บันทึก 03/10/17 น.:
            want = [d for d in due if d != now.date().isoformat()]                          # ก่อน 10:00 ยังไม่มีค่าหลังเวลาอ่าน → รอ (ไม่เดา)
            assert now.date().isoformat() not in got
        assert sorted(d for d in got if d in want) == want, (tag, len(got), len(want))      # ครบทุกวัน
        for d in want:
            exact = value(tag, datetime.combine(datetime.fromisoformat(d).date(), time(8, 0)), t0)
            v, note = got[d]
            assert abs(v - exact) < 1e-6, (tag, d, v, exact)                                  # ค่าถูกต้อง ณ 08:00
            outage = tag == "KB" and datetime.fromisoformat(d).day % 5 == 0
            assert note.startswith("≈") == (tag == "KC" or outage), (tag, d, note)            # ≈ เฉพาะที่ไม่มีค่าจริงในช่วงเวลาอ่าน
    rows = EN.series(db, [EN.meter(db, ms["KA"])], datetime.fromisoformat(due[1]).date(), datetime.fromisoformat(due[-2]).date())[ms["KA"]]
    assert all(abs(x["u"] - 50.0 * 24) < 1e-6 and not x["flag"] for x in rows.values())   # การใช้รายวันถูกต้อง แยกวันละแถว


def test_bind_backfill_is_not_truncated(app, db, tmp_path):
    now, _p, t0, sid, ms = _setup(app, db, tmp_path, tags=("KA", "KB"))
    kd = EN.save_meter(db, None, {"factory_id": app.config["F1"], "kind": "elec", "code": "KD", "name": "KD",
                                  "scada_source_id": str(sid), "scada_tag": "KD"}, None)
    r = EF.scada_backfill(db, kd, 31)                                # เดิม: ดึงทุก Tag ทั้งก้อน → ถูกตัด 50,000 แถว ได้ 23/31 วัน
    want = [d for d in _due_days(now, t0) if d >= (now.date() - timedelta(days=30)).isoformat()]
    got = _readings(db, kd)
    assert sorted(got) == want and r["days"] == len(want) and not r["no_data"]
    assert not _readings(db, ms["KA"])                               # เติมเฉพาะมิเตอร์ที่สั่ง


def test_late_real_value_replaces_estimate_and_future_ignored(app, db, tmp_path):
    now, path, t0, sid, ms = _setup(app, db, tmp_path, tags=("KC",), days=5)
    d = (now - timedelta(days=2)).date()
    ES.sync_days(db, ES.get_source(db, sid), d, d, now)
    v, note = _readings(db, ms["KC"])[d.isoformat()]
    assert note.startswith("≈ ประมาณจาก SQL") and abs(v - value("KC", datetime.combine(d, time(8, 0)), t0)) < 1e-6
    con = sqlite3.connect(path)
    con.execute("INSERT INTO h VALUES ('KC', ?, 123456.0)", (datetime.combine(d, time(8, 1)).strftime("%Y-%m-%d %H:%M:%S"),))
    tomorrow = (now + timedelta(days=1)).date()
    con.execute("INSERT INTO h VALUES ('KC', ?, 999999.0)", (datetime.combine(tomorrow, time(8, 0)).strftime("%Y-%m-%d %H:%M:%S"),))
    con.commit()
    con.close()
    ES.sync_days(db, ES.get_source(db, sid), d, d, now)               # ค่าจริงมาทีหลัง → แทนค่าประมาณ + ล้างหมายเหตุ ≈
    assert _readings(db, ms["KC"])[d.isoformat()] == (123456.0, "")
    ES.run_source(db, sid, now=now)
    assert tomorrow.isoformat() not in _readings(db, ms["KC"])           # เวลาในอนาคตไม่ถูกใช้


def test_no_data_day_retries_later(app, db, tmp_path):
    now, path, _t0, sid, _ms = _setup(app, db, tmp_path, tags=("KA",), days=10)
    gap = (now - timedelta(days=5)).date()
    con = sqlite3.connect(path)                                      # SQL ไม่มีข้อมูลทั้งวัน (± 1 วัน) ของวันนั้น
    con.execute("DELETE FROM h WHERE ts >= ? AND ts < ?", (f"{gap - timedelta(days=1)} 00:00:00", f"{gap + timedelta(days=1)} 23:59:59"))
    con.commit()
    con.close()
    src = ES.get_source(db, sid)
    r = ES.sync_days(db, src, gap, gap, now, respect_retry=True)
    assert r["no_data"] == [gap] and r["readings"] == 0
    assert ES.sync_days(db, src, gap, gap, now + timedelta(hours=1), respect_retry=True)["days"] == 0     # ยังไม่ครบ 6 ชม.
    assert ES.sync_days(db, src, gap, gap, now + timedelta(hours=7), respect_retry=True)["days"] == 1     # ครบแล้วลองใหม่


def test_meter_page_lists_every_day_and_pulls_one_day(app, db, client, tmp_path):
    now, _p, _t0, sid, ms = _setup(app, db, tmp_path, tags=("KB",), days=12)
    mid = ms["KB"]
    src = ES.get_source(db, sid)
    ES.sync_days(db, src, now.date() - timedelta(days=11), now.date(), now)
    miss = (now - timedelta(days=3)).date()
    db.execute("DELETE FROM en_readings WHERE meter_id=? AND day=?", (mid, miss.isoformat()))
    db.commit()
    tok = login(client, "t_admin")
    page = client.get(f"/energy/meters/{mid}").get_data(as_text=True)
    daily = page[page.index('id="daily"'):]
    daily = daily[:daily.index("</section>")]
    assert f"{miss:%d/%m/%Y}" in daily and "ขาดค่าอ่าน" in daily and "ดึงจาก SQL" in daily and "ขาด 1 วัน" in daily
    assert daily.count('class="en-d en-d-') >= 11 and "08:00" in daily                    # แสดงครบทุกวัน + เวลาที่อ่าน
    if any(d.day % 5 == 0 for d in (now.date() - timedelta(days=k) for k in range(1, 11))):
        assert "≈ ประมาณ" in daily
    res = client.post(f"/energy/meters/{mid}/scada-day", data={"csrf_token": tok, "day": miss.isoformat()})
    assert res.status_code in (302, 303)
    assert miss.isoformat() in _readings(db, mid)
    res = client.post(f"/energy/meters/{mid}/scada", data={"csrf_token": tok, "days": "62"}, follow_redirects=True)
    assert "ดึงจาก SQL แล้ว" in res.get_data(as_text=True)


def test_future_dated_reading_is_flagged_not_used(app, db, client, tmp_path):
    """ค่าอ่านที่ลงวันในอนาคต (เช่นนาฬิกาเครื่อง SQL ผิด) → ไม่ทำให้วันล่าสุดขึ้น “ค่าลดลง/รีเซ็ต” และแสดงในวันที่ต้องตรวจ"""
    now, _p, _t0, sid, ms = _setup(app, db, tmp_path, tags=("KA",), days=6)
    mid = ms["KA"]
    ES.sync_days(db, ES.get_source(db, sid), now.date() - timedelta(days=5), now.date(), now)
    last = max(_readings(db, mid))
    fut = (now + timedelta(days=2)).date().isoformat()
    db.execute("INSERT INTO en_readings(meter_id, day, value, src, updated_at) VALUES (?,?,?,?,?)", (mid, fut, 1.0, "scada", S.ts()))
    db.commit()
    s = EN.series(db, [EN.meter(db, mid)], now.date() - timedelta(days=5), now.date())[mid]
    assert all(x["flag"] != "reset" for x in s.values()) and (last not in s or s[last]["u"] is None or s[last]["u"] > 0)
    login(client, "t_admin")
    page = client.get(f"/energy/meters/{mid}").get_data(as_text=True)
    assert "ค่าลงวันที่ล่วงหน้า" in page
