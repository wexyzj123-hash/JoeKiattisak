"""ระบบรวม UT-CMMS + E-Checksheet (portal.py) — ใช้ UT-CMMS จำลองในโฟลเดอร์ชั่วคราว ไม่แตะระบบจริง"""
import hashlib
import os
import re
import sqlite3
import sys
import textwrap

import pytest
from werkzeug.test import Client

FAKE_APP = '''
import os
from flask import Flask, jsonify, request, session
from helpers import started

def create_app():
    app = Flask(__name__)
    app.secret_key = "fake-cmms-secret"
    base = os.path.dirname(os.path.abspath(__file__))
    app.config["DATABASE"] = os.path.join(base, "utility_cmms.db")

    @app.route("/")
    def index():
        return "<html><body><h1>UT-CMMS</h1></body></html>"

    @app.route("/api/login", methods=["POST"])
    def login():
        import hashlib, sqlite3
        d = request.json
        con = sqlite3.connect(app.config["DATABASE"]); con.row_factory = sqlite3.Row
        u = con.execute("SELECT * FROM users WHERE username=? AND active=1", (d["username"],)).fetchone()
        if u and u["password"] == hashlib.sha256(d["password"].encode()).hexdigest():
            session["user_id"], session["role"], session["username"] = u["id"], u["role"], u["username"]
            return jsonify(success=True)
        return jsonify(success=False), 401

    @app.route("/api/logout", methods=["POST"])
    def logout():
        session.clear()
        return jsonify(success=True)

    @app.route("/api/me")
    def me():
        return jsonify(user_id=session.get("user_id"))

    @app.route("/api/echo", methods=["POST", "PUT"])
    def echo():
        return jsonify(request.json)

    @app.route("/api/form-echo", methods=["POST"])
    def form_echo():
        return jsonify(request.form.to_dict())

    @app.route("/uploads/<name>")
    def uploads(name):
        return "file " + name

    @app.route("/checksheet/login")
    def cs_login():
        return "login next=" + request.args.get("next", "")

    @app.route("/checksheet/<int:eq_id>")
    def old_checksheet(eq_id):
        return f"old checksheet {eq_id}"

    from routes.meetings import start_meeting_scheduler
    from routes.telegram_polling import start_telegram_poller
    start_meeting_scheduler(app)
    start_telegram_poller(app)
    return app

app = create_app()
'''

CMMS_USERS = [  # id, username, name, role, active
    (1, "somchai", "สมชาย ใจดี", "admin", 1),
    (2, "manee", "มานี มีนา", "manager", 1),
    (3, "chujai", "ชูใจ ช่างดี", "technician", 1),
    (4, "oldman", "ลาออกแล้ว", "technician", 0),
]
PW = "cmms#pass1"


def _purge_modules():
    for name in list(sys.modules):
        if name in ("app", "helpers", "routes") or name.startswith("routes."):
            del sys.modules[name]


@pytest.fixture()
def cmms_dir(tmp_path):
    d = tmp_path / "UT-CMMS"
    (d / "routes").mkdir(parents=True)
    (d / "app.py").write_text(FAKE_APP, encoding="utf-8")
    (d / "helpers.py").write_text("started = []\n", encoding="utf-8")
    (d / "routes" / "__init__.py").write_text("", encoding="utf-8")
    (d / "routes" / "meetings.py").write_text(
        "from helpers import started\ndef start_meeting_scheduler(app):\n    started.append('meetings')\n", encoding="utf-8")
    (d / "routes" / "telegram_polling.py").write_text(
        "from helpers import started\ndef start_telegram_poller(app):\n    started.append('telegram')\n", encoding="utf-8")
    con = sqlite3.connect(d / "utility_cmms.db")
    con.execute("""CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, name TEXT,
                   role TEXT, dept TEXT DEFAULT 'Utility', phone TEXT DEFAULT '', email TEXT DEFAULT '', active INTEGER)""")
    con.execute("CREATE TABLE equipment (id INTEGER PRIMARY KEY, code TEXT)")
    for uid_, un, name, role, active in CMMS_USERS:
        con.execute("INSERT INTO users(id, username, password, name, role, email, active) VALUES (?,?,?,?,?,?,?)",
                    (uid_, un, hashlib.sha256(PW.encode()).hexdigest(), name, role, f"{un}@example.com", active))
    con.commit()
    con.close()
    _purge_modules()
    yield d
    _purge_modules()
    if str(d) in sys.path:
        sys.path.remove(str(d))


def _build(cmms_dir, tmp_path, **pcfg_over):
    import portal
    pcfg = {"CMMS_DIR": str(cmms_dir), "PREFIX": "/echeck", "HOST": "127.0.0.1", "PORT": 0, "HTTPS_PORT": 0,
            "CMMS_BACKGROUND": True, "LAUNCHER": True, "LEGACY_QR": True, "CMMS_SECRET_KEY": ""}
    pcfg.update(pcfg_over)
    return portal.build(pcfg, {"TESTING": True, "DATABASE": str(tmp_path / "ecs.db"),
                               "UPLOAD_FOLDER": str(tmp_path / "up"), "ENABLE_JOBS": False})


@pytest.fixture()
def portal_env(cmms_dir, tmp_path):
    wsgi, cmms, ecs_app = _build(cmms_dir, tmp_path)
    return Client(wsgi), cmms, ecs_app


def _ecs_db(ecs_app):
    con = sqlite3.connect(ecs_app.config["DATABASE"])
    con.row_factory = sqlite3.Row
    return con


def _cmms_login(c, username="somchai", password=PW):
    r = c.post("/api/login", json={"username": username, "password": password})
    assert r.status_code == 200, r.get_data(as_text=True)


def _ecs_csrf(c):
    html = c.get("/echeck/login").get_data(as_text=True)
    return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)


# ───────────────────────── ทดสอบ ─────────────────────────

def test_cmms_pages_untouched_and_launcher_injected(portal_env):
    c, _, _ = portal_env
    html = c.get("/").get_data(as_text=True)
    assert "<h1>UT-CMMS</h1>" in html
    assert 'src="/echeck/static/portal/launcher.js' in html and html.index("launcher.js") < html.index("</body>")
    assert c.get("/echeck/static/portal/launcher.js").status_code == 200
    # หน้าอื่นของ UT-CMMS ไม่ถูกแทรก
    assert "launcher.js" not in c.get("/api/me").get_data(as_text=True)


def test_background_threads_follow_setting(cmms_dir, tmp_path):
    _build(cmms_dir, tmp_path, CMMS_BACKGROUND=False)
    assert sys.modules["helpers"].started == []
    _purge_modules()
    (tmp_path / "b").mkdir()
    _build(cmms_dir, tmp_path / "b", CMMS_BACKGROUND=True)
    assert sorted(sys.modules["helpers"].started) == ["meetings", "telegram"]


def test_sso_from_cmms_provisions_user(portal_env):
    c, _, ecs_app = portal_env
    r = c.get("/echeck/dashboard")
    assert r.status_code == 302 and r.headers["Location"].startswith("/echeck/login")
    _cmms_login(c, "manee")
    r = c.get("/echeck/dashboard")
    assert r.status_code == 200, r.headers.get("Location")
    html = r.get_data(as_text=True)
    assert "มานี มีนา" in html and ">UT-CMMS</a>" in html
    u = _ecs_db(ecs_app).execute("SELECT * FROM users WHERE legacy_id=2").fetchone()
    assert u["username"] == "manee" and u["role"] == "supervisor" and u["email"] == "manee@example.com"
    assert u["password"] == "!cmms"
    # badge สำหรับปุ่มลัด
    d = c.get("/echeck/api/portal/badge").get_json()
    assert d["logged_in"] is True and "alerts" in d and "rounds" in d


def test_badge_when_logged_out_is_quiet(portal_env):
    c, _, _ = portal_env
    r = c.get("/echeck/api/portal/badge")
    assert r.status_code == 200 and r.get_json() == {"logged_in": False}


def test_single_sign_out_from_cmms(portal_env):
    c, _, _ = portal_env
    _cmms_login(c)
    assert c.get("/echeck/dashboard").status_code == 200
    c.post("/api/logout")
    r = c.get("/echeck/dashboard")
    assert r.status_code == 302 and "/echeck/login" in r.headers["Location"]


def test_switching_cmms_user_switches_ecs_user(portal_env):
    c, _, _ = portal_env
    _cmms_login(c, "somchai")
    assert "สมชาย ใจดี" in c.get("/echeck/dashboard").get_data(as_text=True)
    _cmms_login(c, "chujai")
    assert c.get("/echeck/m/").status_code == 200
    with_name = c.get("/echeck/actions").get_data(as_text=True)
    assert "ชูใจ ช่างดี" in with_name and "สมชาย ใจดี" not in with_name


def test_login_at_ecs_with_cmms_password_logs_into_both(portal_env):
    c, _, _ = portal_env
    tok = _ecs_csrf(c)
    r = c.post("/echeck/login", data={"username": "SomChai", "password": PW, "csrf_token": tok,
                                      "next": "/echeck/alerts"})
    assert r.status_code == 302 and r.headers["Location"] == "/echeck/alerts"
    assert c.get("/api/me").get_json()["user_id"] == 1          # ได้ session ของ UT-CMMS ด้วย
    assert c.get("/echeck/alerts").status_code == 200
    # ออกจาก E-Checksheet = ออกจาก UT-CMMS ด้วย
    html = c.get("/echeck/alerts").get_data(as_text=True)
    tok = re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)
    r = c.post("/echeck/logout", data={"csrf_token": tok})
    assert r.status_code == 302 and r.headers["Location"] == "/echeck/login"      # v0.99.38 หน้า login ของ E-Checksheet
    assert c.get("/api/me").get_json()["user_id"] is None
    assert c.get("/echeck/alerts").status_code == 302


def test_wrong_password_and_inactive_cmms_user_rejected(portal_env):
    c, _, _ = portal_env
    tok = _ecs_csrf(c)
    r = c.post("/echeck/login", data={"username": "somchai", "password": "nope", "csrf_token": tok})
    assert r.status_code == 200 and "ไม่ถูกต้อง" in r.get_data(as_text=True)
    r = c.post("/echeck/login", data={"username": "oldman", "password": PW, "csrf_token": tok})
    assert r.status_code == 200


def test_linked_user_cannot_use_local_password(portal_env):
    c, _, ecs_app = portal_env
    from ecs.security import hash_password
    con = _ecs_db(ecs_app)
    con.execute("""INSERT INTO users(username, password, name, role, active, must_change_pw, legacy_id, created_at, updated_at)
                   VALUES ('chujai', ?, 'ชูใจ', 'technician', 1, 0, 3, '2026-01-01 00:00:00', '2026-01-01 00:00:00')""",
                (hash_password("local#pass9"),))
    con.commit()
    tok = _ecs_csrf(c)
    r = c.post("/echeck/login", data={"username": "chujai", "password": "local#pass9", "csrf_token": tok})
    assert r.status_code == 200                                  # รหัสเก่าของ E-Checksheet ใช้ไม่ได้แล้ว
    r = c.post("/echeck/login", data={"username": "chujai", "password": PW, "csrf_token": tok})
    assert r.status_code == 302


def test_local_only_account_still_works(portal_env):
    c, _, ecs_app = portal_env
    from ecs.security import hash_password
    con = _ecs_db(ecs_app)
    con.execute("""INSERT INTO users(username, password, name, role, active, must_change_pw, created_at, updated_at)
                   VALUES ('kiosk', ?, 'จอห้องควบคุม', 'viewer', 1, 0, '2026-01-01 00:00:00', '2026-01-01 00:00:00')""",
                (hash_password("kiosk#pass1"),))
    con.commit()
    tok = _ecs_csrf(c)
    r = c.post("/echeck/login", data={"username": "kiosk", "password": "kiosk#pass1", "csrf_token": tok})
    assert r.status_code == 302
    assert c.get("/echeck/dashboard").status_code == 200        # ไม่ถูกเตะออกแม้ไม่มี session ของ UT-CMMS


def test_existing_username_gets_linked_not_duplicated(portal_env):
    c, _, ecs_app = portal_env
    con = _ecs_db(ecs_app)
    con.execute("""INSERT INTO users(username, password, name, role, active, must_change_pw, created_at, updated_at)
                   VALUES ('Somchai', 'x', 'เดิม', 'viewer', 1, 0, '2026-01-01 00:00:00', '2026-01-01 00:00:00')""")
    con.commit()
    _cmms_login(c, "somchai")
    assert c.get("/echeck/dashboard").status_code == 200
    rows = _ecs_db(ecs_app).execute("SELECT * FROM users WHERE username='Somchai' COLLATE NOCASE").fetchall()
    assert len(rows) == 1 and rows[0]["legacy_id"] == 1 and rows[0]["role"] == "viewer"   # บทบาทเดิมใน E-Checksheet คงไว้


def test_deactivation_in_cmms_ends_session(portal_env, cmms_dir, monkeypatch):
    c, _, _ = portal_env
    from ecs import cmms_bridge
    _cmms_login(c, "chujai")
    assert c.get("/echeck/m/").status_code == 200
    con = sqlite3.connect(cmms_dir / "utility_cmms.db")
    con.execute("UPDATE users SET active=0 WHERE id=3")
    con.commit()
    con.close()
    monkeypatch.setattr(cmms_bridge, "RECHECK_SEC", -1)
    r = c.get("/echeck/m/")
    assert r.status_code == 302 and "/echeck/login" in r.headers["Location"]


def test_disabled_in_ecs_blocks_sso(portal_env):
    c, _, ecs_app = portal_env
    _cmms_login(c, "chujai")
    c.get("/echeck/m/")
    c2 = Client(c.application)
    con = _ecs_db(ecs_app)
    con.execute("UPDATE users SET active=0 WHERE legacy_id=3")
    con.commit()
    _cmms_login(c2, "chujai")
    r = c2.get("/echeck/m/")
    assert r.status_code == 302


def test_forged_cmms_cookie_ignored(portal_env):
    c, _, _ = portal_env
    from flask import Flask
    from flask.sessions import SecureCookieSessionInterface
    evil = Flask("evil")
    evil.secret_key = "guessed-wrong"
    value = SecureCookieSessionInterface().get_signing_serializer(evil).dumps({"user_id": 1, "role": "admin"})
    c.set_cookie("session", value, domain="localhost")
    assert c.get("/echeck/dashboard").status_code == 302


def test_custom_secret_key_replaces_hardcoded(cmms_dir, tmp_path):
    wsgi, cmms, ecs_app = _build(cmms_dir, tmp_path, CMMS_SECRET_KEY="a-much-better-secret-0123456789")
    assert cmms.secret_key == ecs_app.config["CMMS_SECRET_KEY"] == "a-much-better-secret-0123456789"
    c = Client(wsgi)
    _cmms_login(c)
    assert c.get("/echeck/dashboard").status_code == 200


def test_legacy_qr_redirects(portal_env):
    c, _, ecs_app = portal_env
    con = _ecs_db(ecs_app)
    eq = con.execute("SELECT id, qr_token FROM equipment LIMIT 1").fetchone()
    if not eq:
        fid = con.execute("SELECT id FROM factories LIMIT 1").fetchone()[0]
        con.execute("""INSERT INTO equipment(code, name, factory_id, qr_token, active, legacy_id, created_at, updated_at)
                       VALUES ('CH-1', 'Chiller 1', ?, 'tok123', 1, 5, '2026-01-01', '2026-01-01')""", (fid,))
        token = "tok123"
    else:
        con.execute("UPDATE equipment SET legacy_id=5 WHERE id=?", (eq["id"],))
        token = eq["qr_token"]
    con.commit()
    r = c.get("/checksheet/5")
    assert r.status_code == 302 and r.headers["Location"] == "/echeck/legacy/checksheet/5"
    r = c.get("/echeck/legacy/checksheet/5")
    assert r.status_code == 302 and r.headers["Location"] == f"/echeck/e/{token}"
    r = c.get(f"/echeck/e/{token}")                              # ยังไม่ login → login แล้วกลับมาที่ QR เดิม
    assert r.status_code == 302 and r.headers["Location"].startswith("/echeck/login?next=")
    nxt = r.headers["Location"].split("next=", 1)[1]
    r = c.post("/echeck/login", data={"username": "chujai", "password": PW, "csrf_token": _ecs_csrf(c), "next": nxt})
    assert r.headers["Location"] == f"/echeck/e/{token}"        # หลัง login กลับมาที่ QR ใน /echeck เสมอ
    # เครื่องที่ยังไม่อยู่ในระบบใหม่ → หน้าสแกนของ E-Checksheet (ไม่กลับไปใช้โมดูลเดิม)
    r = c.get("/echeck/legacy/checksheet/77")
    assert r.headers["Location"] == "/echeck/m/scan"
    # หน้าเช็คชีตมือถือเดิมทั้งหมดใช้ระบบใหม่แทน
    for old in ("/checksheet/login", "/checksheet/template/4", "/checksheet/77?old=1"):
        r = c.get(old)
        assert r.status_code == 302 and r.headers["Location"].startswith("/echeck/"), old


def test_all_links_carry_prefix(portal_env):
    """ทุกหน้า (GET ที่ไม่มีพารามิเตอร์) ต้องไม่มีลิงก์หลุดออกจาก /echeck — ไม่งั้นจะไปโผล่หน้า UT-CMMS"""
    c, _, ecs_app = portal_env
    _cmms_login(c)
    pages = sorted({r.rule for r in ecs_app.url_map.iter_rules()
                    if "GET" in r.methods and not r.arguments and not r.rule.startswith(("/api/", "/static"))
                    and r.endpoint not in ("auth.logout", "cmms.badge")})
    assert len(pages) > 25
    bad, checked = {}, 0
    for path in pages:
        r = c.get("/echeck" + path)
        if r.status_code in (301, 302):
            loc = r.headers["Location"]
            assert loc.startswith("/echeck") or loc == "/", (path, loc)
            continue
        assert r.status_code == 200, (path, r.status_code)
        if r.mimetype != "text/html":
            continue
        checked += 1
        html = r.get_data(as_text=True)
        found = [m for m in re.findall(r'(?:href|src|action)="(/[^"]*)"', html) if m != "/" and not m.startswith("/echeck/")]
        if found:
            bad[path] = found
    assert checked > 20 and not bad, bad
    man = c.get("/echeck/m/manifest.webmanifest").get_json()
    assert man["start_url"] == "/echeck/m/" and man["scope"] == "/echeck/m/"
    assert "self.registration.scope" in c.get("/echeck/m/sw.js").get_data(as_text=True)


def test_notification_link_keeps_prefix(portal_env):
    c, _, ecs_app = portal_env
    _cmms_login(c)
    c.get("/echeck/dashboard")
    con = _ecs_db(ecs_app)
    uid = con.execute("SELECT id FROM users WHERE legacy_id=1").fetchone()[0]
    cols = {r[1] for r in con.execute("PRAGMA table_info(cs_notifications)")}
    data = {"user_id": uid, "kind": "alert", "title": "t", "body": "b", "url": "/alerts/9", "severity": "warning",
            "created_at": "2026-09-24 08:00:00"}
    data = {k: v for k, v in data.items() if k in cols}
    nid = con.execute(f"INSERT INTO cs_notifications({','.join(data)}) VALUES ({','.join('?' * len(data))})",
                      tuple(data.values())).lastrowid
    con.commit()
    r = c.get(f"/echeck/n/{nid}")
    assert r.status_code == 302 and r.headers["Location"] == "/echeck/alerts/9"


def test_standalone_mode_unchanged(client):
    """รันแยก (python run.py) ต้องทำงานเหมือนเดิม ไม่มีลิงก์ UT-CMMS"""
    r = client.get("/login")
    html = r.get_data(as_text=True)
    assert r.status_code == 200 and "UT-CMMS" not in html
    assert client.get("/api/portal/badge").get_json() == {"logged_in": False}


def test_setup_disabled_when_linked(portal_env):
    c, _, _ = portal_env
    r = c.get("/echeck/setup")
    assert r.status_code == 302 and r.headers["Location"].endswith("/echeck/login")


def test_static_js_syntax():
    """ไฟล์ JS ทุกไฟล์ต้องไม่มี syntax error (ตรวจด้วย node ถ้ามีในเครื่อง)"""
    import glob
    import shutil
    import subprocess
    node = shutil.which("node")
    if not node:
        pytest.skip("ไม่มี node")
    root = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ecs", "static")
    files = [f for f in glob.glob(os.path.join(root, "**", "*.js"), recursive=True) if "vendor" not in f]
    assert files
    for f in files:
        r = subprocess.run([node, "--check", f], capture_output=True, text=True)
        assert r.returncode == 0, (f, r.stderr[-400:])


def test_guard_neutralizes_html_but_keeps_normal_text(portal_env):
    c, _, _ = portal_env
    _cmms_login(c, "chujai")
    payload = {"title": 'ปั๊มรั่ว <img src=x onerror="alert(1)">', "note": "แรงดัน < 5 bar, ท่อ 1/2\" และ a<b",
               "items": [{"name": "<script>x</script>"}], "password": "<keep>", "n": 5,
               "desc": 'x" onfocus="alert(1)" autofocus="'}
    d = c.post("/api/echo", json=payload).get_json()
    assert "<img" not in d["title"] and "＜img" in d["title"] and d["title"].startswith("ปั๊มรั่ว")
    assert d["note"] == 'แรงดัน < 5 bar, ท่อ 1/2" และ a＜b'      # "< 5" และเครื่องหมายนิ้วคงเดิม; "<b" = แท็กจริงจึงถูกแปลง
    assert d["items"][0]["name"] == "＜script>x＜/script>"
    assert d["password"] == "<keep>" and d["n"] == 5
    assert '"' not in d["desc"] and "onfocus" in d["desc"]      # หลุดออกจาก attribute ไม่ได้แล้ว
    f = c.post("/api/form-echo", data={"msg": "<b>hi</b>", "ok": "a < b"}).get_json()
    assert f == {"msg": "＜b>hi＜/b>", "ok": "a < b"}


def test_guard_uploads_need_login_and_no_open_redirect(portal_env):
    c, _, _ = portal_env
    assert c.get("/uploads/wo1_x.jpg").status_code == 401
    r = c.get("/checksheet/login?next=https://evil.example/")
    assert r.status_code == 302 and "evil" not in r.headers["Location"]


def test_guard_open_redirect_without_legacy_redirect(cmms_dir, tmp_path):
    wsgi, _, _ = _build(cmms_dir, tmp_path, LEGACY_QR=False)
    c = Client(wsgi)
    r = c.get("/checksheet/login?next=https://evil.example/")
    assert r.status_code == 302 and "evil" not in r.headers["Location"]
    assert c.get("/checksheet/login?next=/checksheet/3").get_data(as_text=True) == "login next=/checksheet/3"
    _cmms_login(c)
    assert c.get("/uploads/wo1_x.jpg").get_data(as_text=True) == "file wo1_x.jpg"


def test_scan_and_fix_html_in_db(tmp_path):
    from ecs.cmms_guard import scan_db
    db = tmp_path / "c.db"
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE meetings (id INTEGER PRIMARY KEY, description TEXT, n INTEGER)")
    con.execute("INSERT INTO meetings(description, n) VALUES ('แผน <Succession Plan> ปี 2569', 1), ('a < b', 2)")
    con.commit()
    con.close()
    assert scan_db(str(db)) == [("meetings", "description", 1)]
    scan_db(str(db), fix=True)
    con = sqlite3.connect(db)
    assert [r[0] for r in con.execute("SELECT description FROM meetings ORDER BY id")] == ["แผน ＜Succession Plan> ปี 2569", "a < b"]
    assert scan_db(str(db)) == []


def _logout(c, page="/echeck/dashboard"):
    html = c.get(page).get_data(as_text=True)
    tok = re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)
    return c.post("/echeck/logout", data={"csrf_token": tok})


def test_v99_38_logout_from_cmms_session_lands_on_ecs_login(portal_env):
    """v0.99.38 เข้าจาก UT-CMMS → ออกจากระบบใน E-Checksheet → ไปหน้าเข้าสู่ระบบของ E-Checksheet (ไม่ใช่หน้า UT-CMMS)"""
    c, _, _ = portal_env
    _cmms_login(c)
    assert c.get("/echeck/dashboard").status_code == 200
    r = _logout(c)
    assert r.status_code == 302 and r.headers["Location"] == "/echeck/login"
    page = c.get("/echeck/login")                                # ไม่ถูกพากลับเข้าระบบอัตโนมัติ
    body = page.get_data(as_text=True)
    assert page.status_code == 200 and 'name="password"' in body and "<h1>UT-CMMS</h1>" not in body
    assert c.get("/api/me").get_json()["user_id"] is None        # ออกจาก UT-CMMS ด้วย (single sign-out เดิม)
    assert c.get("/echeck/dashboard").status_code == 302
    tok = _ecs_csrf(c)                                           # เข้าใหม่ได้จากหน้าเดียวกัน
    r = c.post("/echeck/login", data={"username": "somchai", "password": PW, "csrf_token": tok})
    assert r.status_code == 302 and c.get("/echeck/dashboard").status_code == 200


def test_v99_38_logout_mobile_and_local_account(portal_env):
    c, _, ecs_app = portal_env
    _cmms_login(c, "chujai")
    r = _logout(c, "/echeck/m/")                                 # หน้ามือถือ
    assert r.status_code == 302 and r.headers["Location"] == "/echeck/login"
    from ecs.security import hash_password
    con = _ecs_db(ecs_app)
    con.execute("""INSERT INTO users(username, password, name, role, active, must_change_pw, created_at, updated_at)
                   VALUES ('kiosk2', ?, 'จอ', 'viewer', 1, 0, '2026-01-01 00:00:00', '2026-01-01 00:00:00')""",
                (hash_password("kiosk#pass1"),))
    con.commit()
    tok = _ecs_csrf(c)
    c.post("/echeck/login", data={"username": "kiosk2", "password": "kiosk#pass1", "csrf_token": tok})
    r = _logout(c)
    assert r.status_code == 302 and r.headers["Location"] == "/echeck/login"
    assert c.get("/echeck/login").status_code == 200
