"""v0.99.38 ออกจากระบบ → กลับหน้าเข้าสู่ระบบของ E-Checksheet เสมอ (ทั้งแบบเดี่ยวและแบบรวมกับ UT-CMMS ดู test_merge.py)"""
from conftest import login


def test_logout_standalone_goes_to_ecs_login(client):
    tok = login(client, "t_sup")
    r = client.post("/logout", data={"csrf_token": tok})
    assert r.status_code == 302 and r.headers["Location"].endswith("/login")
    assert client.get("/login").status_code == 200
    assert client.get("/dashboard").status_code == 302




def test_generate_rounds_first_run_tolerates_existing_start(db):
    """คำขอพร้อมกันตอนเริ่มใช้ครั้งแรก: อีกคำขอเขียน rounds_start ไปก่อนแล้ว → ไม่ error และใช้ค่าที่มีอยู่"""
    from datetime import datetime

    from ecs import services as S
    db.execute("DELETE FROM cs_meta WHERE key='rounds_start'")
    real = db.execute

    class Racy:                                                   # จำลอง: SELECT แรกไม่เห็น แต่ตอน INSERT มีแถวแล้ว
        n = 0

        def execute(self, sql, *a):
            if "SELECT value FROM cs_meta WHERE key='rounds_start'" in sql and Racy.n == 0:
                Racy.n = 1
                real("INSERT INTO cs_meta(key, value) VALUES('rounds_start', '2026-01-05 08:00:00')")
                return real("SELECT value FROM cs_meta WHERE key='__none__'")
            return real(sql, *a)

        def __getattr__(self, k):
            return getattr(db, k)

    S.generate_rounds(Racy(), now=datetime.fromisoformat("2026-01-06 09:00:00"))
    assert db.execute("SELECT value FROM cs_meta WHERE key='rounds_start'").fetchone()[0] == "2026-01-05 08:00:00"
