"""ข้อมูล SCADA จำลองแบบโรงงานจริง (ใช้ในชุดทดสอบ v0.99.37): ตัวนับ kWh สะสม บันทึกทุก 2 นาที ย้อนหลังหลายสิบวัน
KA = ครบทุกช่วง · KB = Logger ดับ 06:00–10:30 ทุกวันที่ 5 · KC = บันทึกห่าง (03:00 / 10:00 / 17:00 เท่านั้น) · KD = ครบ (ผูกทีหลัง)"""
import sqlite3
from datetime import datetime, time, timedelta

RATE = {"KA": 50.0, "KB": 30.0, "KC": 20.0, "KD": 10.0}       # kWh ต่อชั่วโมง
BASE = {"KA": 600000.0, "KB": 120000.0, "KC": 80000.0, "KD": 5000.0}


def value(tag: str, t: datetime, t0: datetime) -> float:
    return round(BASE[tag] + RATE[tag] * (t - t0).total_seconds() / 3600, 3)


def build(path: str, now: datetime, days: int = 60, step_min: int = 2) -> datetime:
    t0 = datetime.combine((now - timedelta(days=days)).date(), time(0, 0))
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE h (tag TEXT, ts TEXT, value REAL)")
    con.execute("CREATE INDEX ix_h ON h(ts, tag)")
    rows = []
    t = t0
    while t <= now:
        for tag in ("KA", "KB", "KD"):
            if tag == "KB" and t.day % 5 == 0 and time(6, 0) <= t.time() < time(10, 30):
                continue
            rows.append((tag, t.strftime("%Y-%m-%d %H:%M:%S"), value(tag, t, t0)))
        if t.time() in (time(3, 0), time(10, 0), time(17, 0)):
            rows.append(("KC", t.strftime("%Y-%m-%d %H:%M:%S"), value("KC", t, t0)))
        t += timedelta(minutes=step_min)
    con.executemany("INSERT INTO h VALUES (?,?,?)", rows)
    con.commit()
    con.close()
    return t0
